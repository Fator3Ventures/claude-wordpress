<?php
/**
 * Relatório em estados fechados.
 *
 * Regras que este arquivo IMPLEMENTA — não descreve:
 *
 * - **Estados fechados:** OK, FALHA, BLOCKED, N/A, WAIVED, WARN. Nenhum outro.
 * - **O contador de falhas mora DENTRO da função que imprime o estado.**
 *   Checagem que depende de alguém lembrar de incrementar por fora vai, um dia,
 *   imprimir FALHA e não reprovar — foi o caso medido em que `php_lint` e
 *   `json_valido` imprimiam FALHA com código de saída 0.
 * - **Toda checagem emite nos DOIS ramos.** `avaliar()` existe para tornar isso
 *   estrutural: ela recebe a condição e as duas mensagens, e sempre imprime.
 * - **WAIVED tem efeito no funil de estado.** O casamento waiver → checagem é
 *   por igualdade ou por prefixo terminado em `:`, e a linha convertida MANTÉM
 *   a medição: waiver que apaga o número transforma "desvio aceito" em "não
 *   medimos mais".
 * - **A sanitização é recursiva ANTES da serialização.** Redigir dentro de SQL
 *   serializado corrompe comprimentos e engana a leitura.
 * - **Métrica sai nomeada, nunca só contada.** A pergunta do operador nunca é
 *   "quantos?", é "o X que esta release mudou está no ar?".
 * - **"Edição manual" é afirmação sobre uma pessoa:** só se imprime quando
 *   existe registro do que a implantação gravou E ele diverge do observado.
 *   Sem registro, o estado é "origem não registrada".
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Acumulador e formatador do relatório.
 */
final class F3Base_Imp_Relatorio {

	/**
	 * Option onde o log persiste entre lotes.
	 */
	public const OPTION_LOG = 'f3base_log';

	/**
	 * Estados fechados. Nenhuma seção cria estado novo.
	 */
	public const OK      = 'OK';
	public const FALHA   = 'FALHA';
	public const BLOCKED = 'BLOCKED';
	public const NA      = 'N/A';
	public const WAIVED  = 'WAIVED';
	public const WARN    = 'WARN';

	/**
	 * GATES fechados de uma linha. TRÊS, e cada um responde a uma pergunta.
	 *
	 * - `aplicacao`: o host mede, e a resposta DECIDE — o veredito da unidade, a
	 *   suspensão do que depende dela e a autodesativação.
	 * - `fase`: evidência que este host NÃO PRODUZ (navegador, campo, suíte
	 *   externa). Sai nomeada, entra nas contagens e não decide.
	 * - `relato`: o host MEDE, a linha é completa e acionável, e ela não decide
	 *   gate nenhum. É o PADRÃO.
	 *
	 * O QUARTO SAIU NA 2.1.0. `convergencia` existia para o dado que só o
	 * operador tem — razão social do controlador, hipótese legal —, e alimentava
	 * um terceiro eixo do encerramento cuja saída era sempre a mesma frase:
	 * "preencha e execute de novo". O implantador é executado UMA VEZ por site,
	 * e o que vem depois é feito pelo canal MCP; dado do operador é
	 * responsabilidade do operador, preenchido ANTES da execução ou ajustado
	 * DEPOIS pelo canal, e não é estado que o host cobre. O eixo saiu inteiro,
	 * com o metadado `precondicao` que o derivava.
	 *
	 * POR QUE O QUARTO NASCEU NA 1.7.3, e ele é uma correção de vocabulário.
	 * Até a 1.7.2 `fase` acumulava DOIS significados que não são o mesmo: o
	 * declarado — "evidência que este host não produz" — e o que o uso real
	 * fazia dele, que era "esta linha não decide nada". O padrão caía em `fase`
	 * desde a 1.3.1 (a inversão que impediu uma linha descritiva de suspender 39
	 * unidades, e essa metade continua valendo), e com ela 43 emissões sem
	 * classificação entravam numa lista cuja documentação prometia outra coisa.
	 * Somaram-se a elas seis nomes que declararam `fase` EXPLICITAMENTE para
	 * dizer "não decide" — `preflight.baseline`, `preflight.contrato_de_caminho`,
	 * `entrega.site_no_ar`, `entrega.daqui_em_diante`, `fases.registro_de_execucao`
	 * e a linha de convergência que a 2.1.0 retirou —, todos medidos aqui mesmo.
	 *
	 * O preço saiu impresso: `pode_autodesativar()` escrevia, sobre cada nome da
	 * lista, *"evidência que este host não produz trava o gate da fase, não a
	 * ferramenta"* — uma frase FALSA para a maioria deles. Medido na 1.7.2, com
	 * `release.versao_site_core` (FALHA): este host produziu a evidência, leu o
	 * cabeçalho do plugin instalado e comparou com o que o pacote carrega.
	 *
	 * A separação não afrouxa nada. `relato` tem exatamente os mesmos poderes
	 * que `fase` tinha — nenhum: não promove a unidade, não suspende dependente
	 * e não entra na condição do gate de aplicação. O que muda é que a frase
	 * impressa sobre `fase` volta a ser verdadeira de todo nome que ela lista, e
	 * que uma linha de gate de fase deixa de poder fechar FALHA sem ser acusada
	 * — quem acusa é `lotes.gate_de_fase_nao_derruba_estado`.
	 */
	public const GATE_APLICACAO = 'aplicacao';
	public const GATE_FASE      = 'fase';
	public const GATE_RELATO    = 'relato';

	/**
	 * Linhas emitidas.
	 *
	 * @var array<int,array<string,mixed>>
	 */
	private static array $linhas = array();

	/**
	 * ESCOPO 1 — CHECAGENS: uma entrada por LINHA emitida no relatório.
	 *
	 * Alimentado SÓ dentro de `emitir()`. É o número de linhas que o relatório
	 * carrega, e inclui as checagens que rodam DENTRO de uma unidade.
	 *
	 * @var array<string,int>
	 */
	private static array $contagem = array(
		self::OK      => 0,
		self::FALHA   => 0,
		self::BLOCKED => 0,
		self::NA      => 0,
		self::WAIVED  => 0,
		self::WARN    => 0,
	);

	/**
	 * ESCOPO 2 — UNIDADES: uma entrada por unidade do plano, uma por lote.
	 *
	 * Alimentado SÓ dentro de `emitir_unidade()`. Existe porque três números
	 * apareceram no mesmo relatório dizendo "FALHA" e contando coisas
	 * diferentes: `FALHA: 7` (linhas do relatório), `(5 FALHA, 9 BLOCKED)` no
	 * encerramento (as mesmas linhas, medidas antes de o encerramento emitir as
	 * suas) e 2 linhas visíveis na tela (uma por unidade). Escopos diferentes
	 * exigem CONTADORES diferentes, cada um com nome próprio — e nunca duas
	 * contagens com a mesma palavra.
	 *
	 * @var array<string,int>
	 */
	private static array $contagem_unidades = array(
		self::OK      => 0,
		self::FALHA   => 0,
		self::BLOCKED => 0,
		self::NA      => 0,
		self::WAIVED  => 0,
		self::WARN    => 0,
	);

	/**
	 * Desvios aceitos, com responsável, motivo, risco e data.
	 *
	 * @var array<int,array<string,string>>
	 */
	private static array $waivers = array();

	/**
	 * Estados fechados aceitos.
	 *
	 * @return string[]
	 */
	public static function estados(): array {
		return array( self::OK, self::FALHA, self::BLOCKED, self::NA, self::WAIVED, self::WARN );
	}

	/**
	 * ORDEM DE SEVERIDADE — declarada AQUI, e em nenhum outro lugar.
	 *
	 * `FALHA > BLOCKED > WARN`, e SÓ ESSES TRÊS PROMOVEM. Abaixo deles a ordem
	 * não continua: `N/A`, `OK` e `WAIVED` pesam zero, empatados, e um empate
	 * conserva o estado que já estava — quem chama mantém o próprio veredito.
	 *
	 * A 1.0.9 tentou uma cadeia completa, com `N/A` acima de `OK`, e a medição
	 * mostrou o defeito no mesmo dia: uma unidade que INSTALOU e ATIVOU um
	 * plugin com sucesso passava a fechar `N/A` porque a supressão de onboarding
	 * daquele slug não se aplicava. `N/A` quer dizer "condição de aplicabilidade
	 * falsa", não "pior que OK" — promover por causa dele é o relatório mentindo
	 * para baixo, que é o mesmo defeito de mentir para cima com o sinal
	 * trocado. Um veredito só pode ser puxado por aquilo que é reprovação
	 * (FALHA), pré-condição ausente (BLOCKED) ou observação que sobreviveu à
	 * medição (WARN).
	 *
	 * `WAIVED` pesa zero pelo motivo oposto e igualmente deliberado: desvio
	 * ACEITO, com responsável, motivo, risco e data, já passou pelo funil de
	 * `emitir()`, que converte a FALHA no momento da emissão. Promover por causa
	 * dele seria a reprovação voltando pela porta dos fundos depois de alguém
	 * ter assinado por ela.
	 *
	 * Uma ordem por arquivo é o mesmo defeito que uma medição por arquivo: dois
	 * lugares divergem, e a divergência aparece como um relatório que se
	 * contradiz. `estatica.unidade_reflete_internas` confere que esta declaração
	 * é única no pacote.
	 *
	 * @return array<string,int> Estado fechado => peso. Zero não promove.
	 */
	public static function ordem_de_severidade(): array {
		return array(
			self::WAIVED  => 0,
			self::NA      => 0,
			self::OK      => 0,
			self::WARN    => 1,
			self::BLOCKED => 2,
			self::FALHA   => 3,
		);
	}

	/**
	 * O estado que PREVALECE entre o incumbente e um candidato. HELPER ÚNICO.
	 *
	 * Assimétrico de propósito, e a assimetria é a regra: `$a` é o estado que já
	 * vale e `$b` só o substitui quando PROMOVE — quando pesa mais na ordem
	 * acima. Empate no peso zero (`OK`, `N/A`, `WAIVED`) conserva `$a`, e é isso
	 * que faz uma unidade com internas em OK e N/A fechar OK, e uma composição
	 * de "ativou OK" com "supressão não se aplica" continuar OK.
	 *
	 * Nasceu em `F3Base_Imp_Plugins`, onde resolvia um problema local: uma
	 * unidade que ativa e suprime tem DOIS vereditos e precisa sair com um só,
	 * sem esconder o pior. O problema, porém, nunca foi local — a linha 48 do
	 * relatório de 1.0.8 dizia `OK entrega` e a linha 49, DENTRO dela, dizia
	 * `FALHA ↳ mcp.canal_unico`. Quem lê o resumo por unidade via verde onde
	 * havia vermelho, que é a mesma discrepância que escondeu as FALHAs até a
	 * 1.0.7.
	 *
	 * Por isso a função subiu para cá e virou uma só: quem compõe estado no
	 * pacote chama ESTA, e `processar()` a aplica sobre TODA unidade de uma vez,
	 * em vez de cada unidade lembrar de fazê-lo à mão.
	 *
	 * @param string $a Estado incumbente.
	 * @param string $b Estado candidato.
	 * @return string
	 */
	public static function estado_mais_severo( string $a, string $b ): string {
		$ordem = self::ordem_de_severidade();

		/* Estado fora da lista fechada não vira estado novo: vira FALHA. */
		$a = isset( $ordem[ $a ] ) ? $a : self::FALHA;
		$b = isset( $ordem[ $b ] ) ? $b : self::FALHA;

		return $ordem[ $b ] > $ordem[ $a ] ? $b : $a;
	}

	/**
	 * Declara os desvios aceitos.
	 *
	 * @param array<int,array<string,string>> $waivers Cada um com `checagem`, `responsavel`, `motivo`, `risco`, `data`.
	 * @return void
	 */
	public static function declarar_waivers( array $waivers ): void {
		self::$waivers = array();

		foreach ( $waivers as $waiver ) {
			if ( ! is_array( $waiver ) || empty( $waiver['checagem'] ) ) {
				continue;
			}

			self::$waivers[] = array(
				'checagem'    => (string) $waiver['checagem'],
				'responsavel' => isset( $waiver['responsavel'] ) ? (string) $waiver['responsavel'] : '',
				'motivo'      => isset( $waiver['motivo'] ) ? (string) $waiver['motivo'] : '',
				'risco'       => isset( $waiver['risco'] ) ? (string) $waiver['risco'] : '',
				'data'        => isset( $waiver['data'] ) ? (string) $waiver['data'] : '',
			);
		}
	}

	/**
	 * Casamento waiver → checagem, por igualdade ou por prefixo terminado em `:`.
	 *
	 * Função pura e única: é o único código do pacote cuja função é silenciar
	 * reprovação, e por isso ela é exercitada pelo piso da suíte com as formas
	 * de virar curinga — nenhuma delas pode casar.
	 *
	 * @param string $checagem Nome da checagem.
	 * @param string $padrao   Padrão declarado no waiver.
	 * @return bool
	 */
	public static function waiver_casa( string $checagem, string $padrao ): bool {
		if ( '' === $padrao || '' === $checagem ) {
			return false;
		}

		if ( $checagem === $padrao ) {
			return true;
		}

		if ( ! str_ends_with( $padrao, ':' ) ) {
			return false;
		}

		return str_starts_with( $checagem, $padrao ) && strlen( $checagem ) > strlen( $padrao );
	}

	/**
	 * Emite uma linha e CONTA o estado. Ponto único de contagem.
	 *
	 * @param string              $estado   Estado fechado.
	 * @param string              $nome     Nome da checagem.
	 * @param string              $mensagem Mensagem.
	 * @param array<string,mixed> $extra    `evidencia` (classe/fase), `medida`, `gate`.
	 * @return string Estado efetivo depois do funil de waiver.
	 */
	public static function emitir( string $estado, string $nome, string $mensagem, array $extra = array() ): string {
		if ( ! in_array( $estado, self::estados(), true ) ) {
			/* Estado fora da lista fechada é FALHA do instrumento, não do site. */
			$mensagem = sprintf(
				/* translators: 1: estado recebido, 2: mensagem original. */
				__( 'estado fora da lista fechada (%1$s) — defeito do instrumento. Mensagem original: %2$s', 'f3base' ),
				$estado,
				$mensagem
			);
			$estado   = self::FALHA;
		}

		$waiver = null;

		if ( self::FALHA === $estado ) {
			foreach ( self::$waivers as $candidato ) {
				if ( self::waiver_casa( $nome, $candidato['checagem'] ) ) {
					$waiver = $candidato;
					$estado = self::WAIVED;
					break;
				}
			}
		}

		if ( null !== $waiver ) {
			$mensagem .= sprintf(
				/* translators: 1: responsável, 2: motivo, 3: risco, 4: data. */
				__( ' [desvio aceito por %1$s — motivo: %2$s; risco: %3$s; data: %4$s. A medição acima permanece: waiver silencia o veredito, nunca a medição.]', 'f3base' ),
				$waiver['responsavel'],
				$waiver['motivo'],
				$waiver['risco'],
				$waiver['data']
			);
		}

		++self::$contagem[ $estado ];

		/*
		 * O GATE PADRÃO NÃO DECIDE NADA, e a inversão custou uma implantação
		 * inteira em produção.
		 *
		 * Até a 1.3.0 a ausência de `gate` significava GATE DE APLICAÇÃO: toda
		 * linha que ninguém tivesse classificado podia reprovar a unidade e
		 * suspender tudo que dependesse dela. `preflight.baseline` era uma
		 * dessas — uma linha DESCRITIVA, que só relatava os plugins já
		 * instalados no site — e no dia em que ela passou a ter um achado
		 * legítimo, 39 unidades foram suspensas e o site não recebeu nem tema
		 * nem plugins nem conteúdo.
		 *
		 * Agora é o contrário: para IMPEDIR a instalação, a checagem precisa
		 * dizer que impede. Quem não diz, relata. A porta que se abre por
		 * esquecimento passa a ser a inofensiva, e o preço de esquecer é uma
		 * linha que não bloqueia quando deveria — visível no relatório — em vez
		 * de uma que bloqueia tudo quando não deveria, que é invisível até
		 * acontecer em produção.
		 *
		 * O PADRÃO PASSOU A SE CHAMAR PELO QUE ELE É, na 1.7.3. Ele era
		 * `GATE_FASE`, e daí saía uma afirmação falsa: a lista de gates de fase
		 * é derivada deste metadado, e o relatório escreve sobre cada nome dela
		 * que "este host não produz" a evidência. Quem cai aqui por não ter sido
		 * classificado é justamente o contrário — é medido aqui, agora, pelo
		 * host. O padrão é `GATE_RELATO`: mesmos poderes de antes (nenhum), nome
		 * que não mente. Trocar este valor por `GATE_APLICACAO` reabre a
		 * catástrofe de 1.3.0; trocá-lo por `GATE_FASE` reabre a frase falsa.
		 */
		$gate = ( isset( $extra['gate'] ) ? (string) $extra['gate'] : self::GATE_RELATO );

		/*
		 * DOIS DESTINOS, e é o filtro inteiro da tela.
		 *
		 * O padrão é o LOG: uma linha só chega à tela se alguém escreveu para
		 * ela uma frase curta, em português comum, dizendo o que aconteceu. Sem
		 * essa frase, a linha é diagnóstico — útil para depurar, ruído para
		 * quem quer saber se o site está no ar.
		 *
		 * FALHA sempre aparece: alguma coisa quebrou e quem opera precisa saber.
		 * BLOCKED só aparece quando há AÇÃO DO OPERADOR — `extra['operador']`
		 * com a frase do que ele precisa fazer. BLOCKED por medição não feita,
		 * por fase que não roda aqui ou por dado que ninguém vai preencher fica
		 * no log: assustar sem dar o que fazer é pior do que não dizer nada.
		 */
		$na_tela  = isset( $extra['tela'] ) ? (string) $extra['tela'] : '';
		$operador = isset( $extra['operador'] ) ? (string) $extra['operador'] : '';

		self::$linhas[] = array(
			'estado'    => $estado,
			'nome'      => $nome,
			'unidade'   => false,
			'mensagem'  => $mensagem,
			'tela'      => $na_tela,
			'operador'  => $operador,
			'evidencia' => isset( $extra['evidencia'] ) ? (string) $extra['evidencia'] : '',
			'fase'      => isset( $extra['fase'] ) ? (string) $extra['fase'] : '',
			'gate'      => $gate,
			'em'        => time(),
		);

		return $estado;
	}

	/**
	 * Emite a linha de uma UNIDADE do plano e conta o escopo de unidades.
	 *
	 * Ponto único de contagem do escopo 2, pela mesma razão do escopo 1: um
	 * contador que dependa de alguém lembrar de incrementar por fora vai, um
	 * dia, descrever outra coisa que não o que saiu na tela. O estado contado é
	 * o EFETIVO, depois do funil de waiver — contar o pedido faria a contagem
	 * divergir da linha impressa logo acima dela.
	 *
	 * @param string              $estado   Estado fechado da unidade.
	 * @param string              $nome     Nome da checagem da unidade.
	 * @param string              $mensagem Mensagem.
	 * @param array<string,mixed> $extra    Evidência e fase.
	 * @return string Estado efetivo.
	 */
	public static function emitir_unidade( string $estado, string $nome, string $mensagem, array $extra = array() ): string {
		$efetivo = self::emitir( $estado, $nome, $mensagem, $extra );

		if ( ! isset( self::$contagem_unidades[ $efetivo ] ) ) {
			self::$contagem_unidades[ $efetivo ] = 0;
		}

		++self::$contagem_unidades[ $efetivo ];

		/*
		 * A linha recém-emitida é MARCADA como unidade. Sem a marca, o escopo
		 * "unidades" teria contagem e não teria nomes — e contagem sem nome é
		 * exatamente o defeito que esta release fecha.
		 */
		$ultima = array_key_last( self::$linhas );

		if ( null !== $ultima ) {
			self::$linhas[ $ultima ]['unidade'] = true;
		}

		return $efetivo;
	}

	/**
	 * Emite nos DOIS ramos a partir de uma condição medida.
	 *
	 * A condição vem de fora já calculada; as duas mensagens são obrigatórias.
	 * Não existe caminho em que o rótulo deixe de aparecer — que é exatamente o
	 * defeito de emitir só dentro do `if` de fracasso.
	 *
	 * @param bool                $condicao Resultado medido.
	 * @param string              $nome     Nome da checagem.
	 * @param string              $quando_ok Mensagem do ramo verdadeiro.
	 * @param string              $quando_falha Mensagem do ramo falso.
	 * @param array<string,mixed> $extra    Evidência e fase.
	 * @return string
	 */
	public static function avaliar( bool $condicao, string $nome, string $quando_ok, string $quando_falha, array $extra = array() ): string {
		return $condicao
			? self::emitir( self::OK, $nome, $quando_ok, $extra )
			: self::emitir( self::FALHA, $nome, $quando_falha, $extra );
	}

	/**
	 * Checagem condicional: fecha N/A com a condição declarada, nunca some.
	 *
	 * @param bool                $aplicavel Condição de aplicabilidade.
	 * @param string              $condicao  Texto da condição, para o N/A.
	 * @param bool                $condicao_medida Resultado quando aplicável.
	 * @param string              $nome      Nome da checagem.
	 * @param string              $quando_ok Mensagem do ramo verdadeiro.
	 * @param string              $quando_falha Mensagem do ramo falso.
	 * @param array<string,mixed> $extra     Evidência e fase.
	 * @return string
	 */
	public static function condicional( bool $aplicavel, string $condicao, bool $condicao_medida, string $nome, string $quando_ok, string $quando_falha, array $extra = array() ): string {
		if ( ! $aplicavel ) {
			return self::emitir(
				self::NA,
				$nome,
				sprintf(
					/* translators: %s: condição de aplicabilidade declarada. */
					__( 'condição de aplicabilidade falsa: %s', 'f3base' ),
					$condicao
				),
				$extra
			);
		}

		return self::avaliar( $condicao_medida, $nome, $quando_ok, $quando_falha, $extra );
	}

	/**
	 * Linhas emitidas.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function linhas(): array {
		return self::$linhas;
	}

	/**
	 * NOMES emitidos com um GATE declarado no metadado. Fonte única da lista.
	 *
	 * O defeito medido na 1.0.17: havia DUAS fontes para "quais checagens são de
	 * gate de fase" — uma lista literal com UM nome em `gates_de_fase()` e o
	 * metadado `gate` por checagem, com DOIS emissores. As duas divergiam, e a
	 * divergência saía impressa: a mesma linha do log dizia "Nenhuma pendência
	 * de fase em aberto" (pela lista) e "Pendência(s) de FASE dentro desta
	 * unidade — 1 … orcamento.medicao_de_pagina (BLOCKED)" (pelo metadado).
	 *
	 * Daqui em diante a lista SAI DO METADADO: quem emitiu com `gate` declarado
	 * está na lista, e não existe segundo lugar onde acrescentar um nome.
	 * `estatica.gate_de_fase_do_metadado` é o detector que impede a lista
	 * paralela de voltar.
	 *
	 * @param string $gate Valor do metadado `gate` (`aplicacao`, `fase`).
	 * @return string[]
	 */
	public static function nomes_com_gate( string $gate ): array {
		$nomes = array();

		foreach ( self::$linhas as $linha ) {
			if ( $gate !== (string) ( $linha['gate'] ?? '' ) ) {
				continue;
			}

			$nome = (string) ( $linha['nome'] ?? '' );

			if ( '' !== $nome && ! in_array( $nome, $nomes, true ) ) {
				$nomes[] = $nome;
			}
		}

		return $nomes;
	}

	/**
	 * Marca o ponto atual do acumulador, para recortar o que vier depois.
	 *
	 * Existe para que a resposta de um lote possa carregar AS CHECAGENS que
	 * rodaram DENTRO daquela unidade. Sem o recorte, elas ficavam só na option
	 * do log e o operador via um número no cabeçalho sem um nome na tela.
	 *
	 * @return int
	 */
	public static function marcar(): int {
		return count( self::$linhas );
	}

	/**
	 * Linhas emitidas DEPOIS de uma marca.
	 *
	 * @param int $marca Valor devolvido por `marcar()`.
	 * @return array<int,array<string,mixed>>
	 */
	public static function desde( int $marca ): array {
		if ( $marca < 0 ) {
			$marca = 0;
		}

		return array_values( array_slice( self::$linhas, $marca ) );
	}

	/**
	 * NOMES por estado — o par obrigatório de toda contagem por estado.
	 *
	 * A regra que esta função existe para tornar estrutural: **contagem e lista
	 * de nomes saem juntas, sempre**. O caso medido: o cabeçalho do log dizia
	 * "5 FALHA e 6 BLOCKED" em checagens e a tela mostrava UMA unidade em FALHA;
	 * as outras quatro rodavam DENTRO de unidades que fecharam OK e o operador
	 * tinha o número e nenhum nome — nada que ele pudesse abrir, procurar ou
	 * corrigir.
	 *
	 * @param string $escopo `checagens` (toda linha) ou `unidades` (só as marcadas).
	 * @return array<string,array<int,string>>
	 */
	public static function nomes_por_estado( string $escopo = 'checagens' ): array {
		$saida = array();

		foreach ( self::estados() as $estado ) {
			$saida[ $estado ] = array();
		}

		foreach ( self::$linhas as $linha ) {
			$estado = (string) ( $linha['estado'] ?? '' );

			if ( ! isset( $saida[ $estado ] ) ) {
				continue;
			}

			if ( 'unidades' === $escopo && true !== ( $linha['unidade'] ?? false ) ) {
				continue;
			}

			$nome = (string) ( $linha['nome'] ?? '' );

			if ( '' === $nome || in_array( $nome, $saida[ $estado ], true ) ) {
				continue;
			}

			$saida[ $estado ][] = $nome;
		}

		return $saida;
	}

	/**
	 * Um estado e os NOMES que fecharam nele. Formatador único.
	 *
	 * @param string        $estado Estado fechado.
	 * @param array<int,string> $nomes  Nomes.
	 * @return string
	 */
	public static function nomes_em( string $estado, array $nomes ): string {
		return sprintf(
			/* translators: 1: estado fechado, 2: nomes das checagens naquele estado. */
			__( '%1$s: %2$s', 'f3base' ),
			$estado,
			array() === $nomes ? __( 'nenhum', 'f3base' ) : implode( ', ', $nomes )
		);
	}

	/**
	 * Resumo por estado com CONTAGEM E NOMES na mesma saída.
	 *
	 * Ponto único: qualquer bloco do pacote que imprima quantos fecharam em cada
	 * estado passa por aqui, e por aqui a lista de nomes vem junto. Checagem OK
	 * dentro de unidade OK continua resumida — o que não pode existir é estado
	 * ruim invisível.
	 *
	 * @param array<string,int>               $contagem Contagem por estado.
	 * @param array<string,array<int,string>> $nomes    Nomes por estado.
	 * @return string
	 */
	public static function resumo_por_estado( array $contagem, array $nomes ): string {
		$partes = array();

		foreach ( self::estados() as $estado ) {
			$quantas = isset( $contagem[ $estado ] ) ? (int) $contagem[ $estado ] : 0;
			$lista   = isset( $nomes[ $estado ] ) && is_array( $nomes[ $estado ] ) ? $nomes[ $estado ] : array();

			if ( self::OK === $estado ) {
				$partes[] = sprintf(
					/* translators: 1: estado OK, 2: quantidade. */
					__( '%1$s: %2$d (não nomeadas: checagem OK sai resumida, por desenho)', 'f3base' ),
					$estado,
					$quantas
				);
				continue;
			}

			$partes[] = sprintf(
				/* translators: 1: estado, 2: quantidade, 3: nomes. */
				__( '%1$s: %2$d — %3$s', 'f3base' ),
				$estado,
				$quantas,
				self::nomes_em( $estado, $lista )
			);
		}

		return implode( ' | ', $partes );
	}

	/**
	 * ESCOPO CHECAGENS: contagem por estado das LINHAS emitidas.
	 *
	 * @return array<string,int>
	 */
	public static function contagem(): array {
		return self::$contagem;
	}

	/**
	 * ESCOPO UNIDADES: contagem por estado das UNIDADES do plano.
	 *
	 * @return array<string,int>
	 */
	public static function contagem_unidades(): array {
		return self::$contagem_unidades;
	}

	/**
	 * Rótulo humano de cada escopo de contagem, para a linha que o imprime.
	 *
	 * A regra que este mapa executa: **cada número diz o que conta, no próprio
	 * texto**. Número solto ao lado da palavra FALHA é o que produziu três
	 * contagens contraditórias no mesmo relatório.
	 *
	 * @return array<string,string>
	 */
	public static function escopos(): array {
		return array(
			'checagens' => __( 'checagens do relatório (uma linha por checagem emitida, inclusive as que rodam dentro de uma unidade)', 'f3base' ),
			'unidades'  => __( 'unidades do plano (uma por lote)', 'f3base' ),
		);
	}

	/**
	 * ESCOPO CHECAGENS: quantas LINHAS fecharam FALHA.
	 *
	 * @return int
	 */
	public static function checagens_em_falha(): int {
		return self::$contagem[ self::FALHA ];
	}

	/**
	 * ESCOPO CHECAGENS: quantas LINHAS fecharam BLOCKED.
	 *
	 * @return int
	 */
	public static function checagens_em_blocked(): int {
		return self::$contagem[ self::BLOCKED ];
	}

	/**
	 * ESCOPO UNIDADES: quantas UNIDADES fecharam FALHA.
	 *
	 * @return int
	 */
	public static function unidades_em_falha(): int {
		return self::$contagem_unidades[ self::FALHA ];
	}

	/**
	 * ESCOPO UNIDADES: quantas UNIDADES fecharam BLOCKED.
	 *
	 * @return int
	 */
	public static function unidades_em_blocked(): int {
		return self::$contagem_unidades[ self::BLOCKED ];
	}

	/**
	 * Zera o acumulador (início de execução).
	 *
	 * @return void
	 */
	public static function zerar(): void {
		self::$linhas            = array();
		self::$contagem          = array(
			self::OK      => 0,
			self::FALHA   => 0,
			self::BLOCKED => 0,
			self::NA      => 0,
			self::WAIVED  => 0,
			self::WARN    => 0,
		);
		self::$contagem_unidades = array(
			self::OK      => 0,
			self::FALHA   => 0,
			self::BLOCKED => 0,
			self::NA      => 0,
			self::WAIVED  => 0,
			self::WARN    => 0,
		);
	}

	/**
	 * Carrega as linhas persistidas de lotes anteriores.
	 *
	 * @return void
	 */
	public static function carregar(): void {
		$bruto = get_option( self::OPTION_LOG, array() );

		if ( ! is_array( $bruto ) || ! isset( $bruto['linhas'] ) || ! is_array( $bruto['linhas'] ) ) {
			return;
		}

		self::$linhas = $bruto['linhas'];

		if ( isset( $bruto['contagem'] ) && is_array( $bruto['contagem'] ) ) {
			foreach ( self::estados() as $estado ) {
				self::$contagem[ $estado ] = isset( $bruto['contagem'][ $estado ] ) ? (int) $bruto['contagem'][ $estado ] : 0;
			}
		}

		if ( isset( $bruto['contagem_unidades'] ) && is_array( $bruto['contagem_unidades'] ) ) {
			foreach ( self::estados() as $estado ) {
				self::$contagem_unidades[ $estado ] = isset( $bruto['contagem_unidades'][ $estado ] ) ? (int) $bruto['contagem_unidades'][ $estado ] : 0;
			}
		}
	}

	/**
	 * Persiste o log.
	 *
	 * @param array<string,mixed> $extra Campos adicionais do log.
	 * @return void
	 */
	public static function persistir( array $extra = array() ): void {
		F3Base_Imp_Gravador::persistir_infra(
			self::OPTION_LOG,
			array(
				'linhas'            => self::$linhas,
				'contagem'          => self::$contagem,
				'contagem_unidades' => self::$contagem_unidades,
				'em'                => time(),
				'release'           => (string) F3Base_Imp_Config::obter( 'release.identidade', '' ),
			) + $extra
		);
	}

	/**
	 * Procedência de uma option gerenciada, com a regra de honestidade.
	 *
	 * @param string $option Nome da option.
	 * @return array{origem:string,detalhe:string}
	 */
	public static function proveniencia_de( string $option ): array {
		$registro = get_option( F3Base_Imp_Gravador::OPTION_PROVENIENCIA, array() );
		$registro = is_array( $registro ) ? $registro : array();

		if ( ! isset( $registro[ $option ] ) || ! is_array( $registro[ $option ] ) ) {
			return array(
				'origem'  => 'origem-nao-registrada',
				'detalhe' => __( 'origem não registrada: não existe registro do que a implantação gravou nesta chave, e sem registro não se afirma quem mexeu no site.', 'f3base' ),
			);
		}

		$entrada = $registro[ $option ];
		$gravado = isset( $entrada['valor_hash'] ) ? (string) $entrada['valor_hash'] : '';
		$origem  = isset( $entrada['origem'] ) ? (string) $entrada['origem'] : F3Base_Imp_Gravador::ORIGEM_IMPLANTADOR;
		$atual   = F3Base_Imp_Gravador::impressao( get_option( $option, null ) );

		if ( '' === $gravado ) {
			return array(
				'origem'  => 'origem-nao-registrada',
				'detalhe' => __( 'há registro de origem, mas sem impressão do valor gravado: não é possível afirmar divergência.', 'f3base' ),
			);
		}

		if ( $gravado === $atual ) {
			return array(
				'origem'  => $origem,
				'detalhe' => sprintf(
					/* translators: 1: origem registrada, 2: data da escrita. */
					__( 'valor observado idêntico ao registrado pela origem %1$s em %2$s.', 'f3base' ),
					$origem,
					isset( $entrada['em'] ) ? (string) wp_date( 'Y-m-d H:i', (int) $entrada['em'] ) : '—'
				),
			);
		}

		return array(
			'origem'  => F3Base_Imp_Gravador::ORIGEM_MANUAL,
			'detalhe' => sprintf(
				/* translators: %s: data da escrita registrada. */
				__( 'edição manual: existe registro do valor gravado pela implantação em %s e o valor observado hoje diverge dele.', 'f3base' ),
				isset( $entrada['em'] ) ? (string) wp_date( 'Y-m-d H:i', (int) $entrada['em'] ) : '—'
			),
		);
	}

	/**
	 * Formata uma métrica NOMEADA.
	 *
	 * @param string   $rotulo Rótulo da métrica.
	 * @param float    $valor  Valor numérico.
	 * @param string   $unidade Unidade.
	 * @param string[] $nomes  Nomes dos itens medidos.
	 * @return string
	 */
	public static function metrica( string $rotulo, float $valor, string $unidade, array $nomes ): string {
		return sprintf(
			/* translators: 1: rótulo, 2: valor, 3: unidade, 4: nomes dos itens. */
			__( '%1$s: %2$s %3$s em %4$s', 'f3base' ),
			$rotulo,
			number_format_i18n( $valor, 1 ),
			$unidade,
			array() === $nomes ? __( 'nenhum item', 'f3base' ) : implode( ', ', $nomes )
		);
	}

	/**
	 * Sanitiza recursivamente ANTES de qualquer serialização.
	 *
	 * Nunca chaves, salts, senhas, hashes de autenticação, e-mails de usuário,
	 * tokens, leads ou conteúdo de visitante. Hash técnico de estado FICA — é
	 * ele que sustenta a rastreabilidade da release. Valor proibido é redigido
	 * PRESERVANDO a estrutura: nome da chave, tipo, tamanho e um marcador
	 * estável, para que a existência da configuração continue visível.
	 *
	 * @param mixed  $valor Valor.
	 * @param string $chave Nome da chave que carrega o valor.
	 * @return mixed
	 */
	public static function sanitizar( $valor, string $chave = '' ): mixed {
		if ( '' !== $chave && self::chave_proibida( $chave ) ) {
			return self::redigir( $valor );
		}

		if ( is_array( $valor ) ) {
			$saida = array();

			foreach ( $valor as $sub => $item ) {
				$saida[ $sub ] = self::sanitizar( $item, (string) $sub );
			}

			return $saida;
		}

		if ( is_object( $valor ) ) {
			return self::sanitizar( get_object_vars( $valor ), $chave );
		}

		if ( is_string( $valor ) && is_email( $valor ) ) {
			return self::redigir( $valor );
		}

		if ( is_string( $valor ) && str_contains( $valor, 'a:' ) && str_contains( $valor, '{' ) ) {
			$interno = maybe_unserialize( $valor );

			if ( is_array( $interno ) ) {
				/*
				 * Alcança o array PHP serializado POR DENTRO: redigir "no lugar"
				 * dentro da string corromperia os comprimentos declarados.
				 */
				return self::sanitizar( $interno, $chave );
			}
		}

		return $valor;
	}

	/**
	 * A chave carrega valor proibido?
	 *
	 * @param string $chave Nome da chave.
	 * @return bool
	 */
	public static function chave_proibida( string $chave ): bool {
		$tecnicas = array( 'sha256', 'valor_hash', 'config_hash', 'hash_pacote', 'identificador_hash', 'hash_config' );

		if ( in_array( strtolower( $chave ), $tecnicas, true ) ) {
			return false;
		}

		return 1 === preg_match(
			'/(senha|password|passwd|pwd|salt|secret|segredo|token|nonce|auth|cookie|credential|apikey|api_key|_key$|^key$|user_pass|user_login|user_email|e-?mail|lead|visitante)/i',
			$chave
		);
	}

	/**
	 * Redige um valor preservando a estrutura.
	 *
	 * @param mixed $valor Valor.
	 * @return array<string,mixed>
	 */
	private static function redigir( $valor ): array {
		$serializado = is_scalar( $valor ) ? (string) $valor : (string) wp_json_encode( $valor );

		return array(
			'__redigido' => true,
			'tipo'       => gettype( $valor ),
			'bytes'      => strlen( $serializado ),
		);
	}

	/**
	 * Dump lógico sanitizado da instalação.
	 *
	 * Terceiros entram por ALLOW-LIST POR FINALIDADE: nomes de options
	 * permitidas, versões, hashes técnicos e resultados de leitura de volta —
	 * nunca payload integral de plugin. O dump não é backup: backup restaurável
	 * é outro artefato, com criptografia, acesso, retenção e descarte próprios.
	 *
	 * @return array<string,mixed>
	 */
	public static function dump(): array {
		$options_wp = array(
			'blogname',
			'blogdescription',
			'WPLANG',
			'timezone_string',
			'gmt_offset',
			'blog_public',
			'show_on_front',
			'page_on_front',
			'page_for_posts',
			'permalink_structure',
			'site_icon',
			'site_logo',
			'wp_page_for_privacy_policy',
			'template',
			'stylesheet',
		);

		$wordpress = array();

		foreach ( $options_wp as $nome ) {
			$wordpress[ $nome ] = self::sanitizar( get_option( $nome, null ), $nome );
		}

		$gerenciadas = array();

		foreach ( self::options_gerenciadas() as $nome ) {
			$proveniencia         = self::proveniencia_de( $nome );
			$gerenciadas[ $nome ] = array(
				'valor'        => self::sanitizar( get_option( $nome, null ), $nome ),
				'proveniencia' => $proveniencia['origem'],
				'detalhe'      => $proveniencia['detalhe'],
			);
		}

		$terceiros = array();

		foreach ( F3Base_Imp_Seo::options() as $nome ) {
			$valor = get_option( $nome, null );

			$terceiros[ $nome ] = array(
				'existe'  => null !== $valor,
				'chaves'  => is_array( $valor ) ? array_keys( $valor ) : array(),
				'sha256'  => F3Base_Imp_Gravador::impressao( $valor ),
				'gravada' => self::proveniencia_de( $nome )['origem'],
			);
		}

		return array(
			'ambiente'    => array(
				'wordpress' => get_bloginfo( 'version' ),
				'php'       => PHP_VERSION,
				'home_url'  => home_url(),
				'site_url'  => site_url(),
				'multisite' => is_multisite(),
				'locale'    => get_locale(),
				'fuso'      => (string) get_option( 'timezone_string', '' ),
			),
			'release'     => array(
				'identidade'  => (string) F3Base_Imp_Config::obter( 'release.identidade', '' ),
				'implantador' => f3base_imp_versao(),
				'config_hash' => F3Base_Imp_Config::hash(),
				'aplicada'    => (string) get_option( 'f3base_release', '' ),
			),
			'tema'        => array(
				'ativo'  => get_stylesheet(),
				'versao' => (string) wp_get_theme()->get( 'Version' ),
			),
			'plugins'     => F3Base_Imp_Plugins::inventario(),
			'wordpress'   => $wordpress,
			'gerenciadas' => $gerenciadas,
			'terceiros'   => $terceiros,
			'journal'     => F3Base_Imp_Journal::resumo(),
			'checagens'   => self::$linhas,
			'contagem'    => array(
				'escopos'         => self::escopos(),
				'checagens'       => self::contagem(),
				'unidades'        => self::contagem_unidades(),
				'checagens_nomes' => self::nomes_por_estado( 'checagens' ),
				'unidades_nomes'  => self::nomes_por_estado( 'unidades' ),
			),
		);
	}

	/**
	 * Options gerenciadas do pacote — lidas do catálogo do `site-core` quando
	 * ele estiver carregado, e da convenção de nomes do contrato quando não.
	 *
	 * @return string[]
	 */
	public static function options_gerenciadas(): array {
		if ( class_exists( 'F3Base_Options' ) ) {
			return F3Base_Options::nomes();
		}

		return array(
			'f3base_contato',
			'f3base_consentimento',
			'f3base_atribuicao',
			'f3base_retencao_meses',
			'f3base_linkedin_partner_id',
			'f3base_llms',
			'f3base_redirects',
			'f3base_seo_entidade',
			'f3base_cabecalhos',
			/*
			 * `f3base_copy_contrato` SAIU NA 1.1.0, junto com a escrita dela no
			 * implantador e com a entrada no catálogo do site-core: nenhum
			 * módulo a lia, e uma option gerenciada que ninguém lê dá ao próximo
			 * leitor do dump a impressão de que algo está sendo conferido dentro
			 * da instância. O contrato de copy é artefato de BUILD, e quem o
			 * confere é `copy.contrato`, na suíte.
			 *
			 * AS CINCO DE MEDIÇÃO ENTRARAM na mesma release: o site-core as lê
			 * desde a decisão 55, o implantador passou a gravá-las, e um dump
			 * que as omitisse esconderia justamente as options que o agente mais
			 * opera depois da entrega.
			 */
			'f3base_gtm_container_id',
			'f3base_ga4_measurement_id',
			'f3base_google_ads',
			'f3base_meta_pixel_id',
			'f3base_linkedin_conversion_id',
			/*
			 * AS TRÊS DA 1.1.2: as duas de verificação de domínio, que o
			 * implantador grava, e o TOKEN da Conversions API, que ele não
			 * grava e o agente sim. O token entra nesta lista porque ela é o
			 * escopo do que o modo somente-relatório RELÊ — e uma option que o
			 * agente opera e o relatório não enxerga é exatamente o ponto cego
			 * que esta release está fechando.
			 */
			'f3base_verificacao_google',
			'f3base_verificacao_meta',
			'f3base_meta_capi_token',
			'f3base_nav_id',
			'f3base_mcp_files_audit',
		);
	}

	/**
	 * Log em texto puro — a forma que o operador cola de volta.
	 *
	 * @return string
	 */
	public static function texto(): string {
		$saida = array();

		$escopos_do_cabecalho = self::escopos();

		$saida[] = sprintf(
			/* translators: 1: nome do site, 2: release, 3: hash da configuração, 4: escopo que as linhas abaixo formam, 5: contagem de linhas. */
			__( 'Implantação — %1$s | release %2$s | config %3$s | as linhas abaixo são %4$s, e são %5$d', 'f3base' ),
			(string) F3Base_Imp_Config::obter( 'site.nome', '' ),
			(string) F3Base_Imp_Config::obter( 'release.identidade', '' ),
			substr( F3Base_Imp_Config::hash(), 0, 12 ),
			(string) ( $escopos_do_cabecalho['checagens'] ?? '' ),
			count( self::$linhas )
		);
		$saida[] = str_repeat( '-', 72 );

		foreach ( self::$linhas as $linha ) {
			$texto = sprintf(
				'%-8s %s — %s',
				(string) $linha['estado'],
				(string) $linha['nome'],
				(string) $linha['mensagem']
			);

			if ( '' !== (string) $linha['evidencia'] ) {
				$texto .= sprintf(
					/* translators: 1: classe de evidência, 2: fase. */
					__( '  evidência: %1$s/%2$s', 'f3base' ),
					(string) $linha['evidencia'],
					(string) $linha['fase']
				);
			}

			$saida[] = $texto;
		}

		$saida[] = str_repeat( '-', 72 );

		/*
		 * CADA NÚMERO DIZ O QUE CONTA. Antes desta release o rodapé imprimia
		 * `FALHA: 7` sem escopo declarado, o encerramento imprimia `(5 FALHA, 9
		 * BLOCKED)` da mesma origem medida em outro instante e a tela mostrava 2
		 * linhas com FALHA — três números, a mesma palavra, três escopos. Agora
		 * cada bloco nomeia o escopo que resume, e nenhum estado aparece contado
		 * duas vezes sob a mesma palavra.
		 */
		$escopos = self::escopos();

		foreach (
			array(
				'checagens' => self::contagem(),
				'unidades'  => self::contagem_unidades(),
			) as $escopo => $contagem
		) {
			/*
			 * CONTAGEM E NOMES SAEM JUNTAS. O rodapé que imprimia só o número
			 * respondia "quantos?" e a pergunta do operador é "quais?".
			 */
			$saida[] = sprintf(
				/* translators: 1: nome do escopo, 2: o que ele conta, 3: contagem com os nomes por estado. */
				__( 'RESUMO por escopo — %1$s, %2$s: %3$s', 'f3base' ),
				$escopo,
				(string) ( $escopos[ $escopo ] ?? '' ),
				self::resumo_por_estado( $contagem, self::nomes_por_estado( $escopo ) )
			);
		}

		$dump = wp_json_encode( self::sanitizar( self::dump() ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

		$saida[] = '';
		$saida[] = __( '--- dump lógico sanitizado (recursivo, antes da serialização) ---', 'f3base' );
		$saida[] = is_string( $dump ) ? $dump : '{}';

		return implode( "\n", $saida );
	}

		/**
	 * A TELA: o que aconteceu, em português comum, uma linha por assunto.
	 *
	 * Quem abre esta página quer três respostas: o site está no ar? o que
	 * falhou? o que falta eu fazer? Tudo que não responde a uma dessas três é
	 * diagnóstico e mora no log.
	 *
	 * @return string
	 */
	public static function html_da_tela(): string {
		$feito     = array();
		$problemas = array();
		$pendentes = array();

		foreach ( self::$linhas as $linha ) {
			$estado = (string) $linha['estado'];
			$curta  = (string) ( $linha['tela'] ?? '' );
			$acao   = (string) ( $linha['operador'] ?? '' );

			if ( self::FALHA === $estado ) {
				$problemas[] = '' !== $curta ? $curta : (string) $linha['mensagem'];
				continue;
			}

			if ( '' !== $acao ) {
				$pendentes[] = $acao;
				continue;
			}

			if ( '' !== $curta ) {
				$feito[] = $curta;
			}
		}

		$html = '';

		if ( array() !== $problemas ) {
			$html .= '<h2>' . esc_html__( 'O que não deu certo', 'f3base' ) . '</h2><ul class="f3base-tela-problemas">';

			foreach ( $problemas as $item ) {
				$html .= '<li>' . esc_html( $item ) . '</li>';
			}

			$html .= '</ul>';
		}

		if ( array() !== $pendentes ) {
			$html .= '<h2>' . esc_html__( 'O que falta você fazer', 'f3base' ) . '</h2><ul class="f3base-tela-pendentes">';

			foreach ( array_unique( $pendentes ) as $item ) {
				$html .= '<li>' . esc_html( $item ) . '</li>';
			}

			$html .= '</ul>';
		}

		if ( array() !== $feito ) {
			$html .= '<h2>' . esc_html__( 'O que foi feito', 'f3base' ) . '</h2><ul class="f3base-tela-feito">';

			foreach ( $feito as $item ) {
				$html .= '<li>' . esc_html( $item ) . '</li>';
			}

			$html .= '</ul>';
		}

		if ( '' === $html ) {
			$html = '<p>' . esc_html__( 'Nada a relatar nesta execução.', 'f3base' ) . '</p>';
		}

		return $html;
	}

	/**
	 * O LOG: o texto completo, sem perder nada.
	 *
	 * Ele fica recolhido na tela porque é onde alguém vai procurar quando
	 * precisar entender POR QUE — e só nessa hora.
	 *
	 * @return string
	 */
	public static function html_do_log(): string {
		$html = '<details class="f3base-imp-detalhe"><summary>'
			. esc_html__( 'Detalhes técnicos desta execução', 'f3base' )
			. '</summary>';

		$html .= '<table class="widefat f3base-imp-log"><thead><tr>';
		$html .= '<th scope="col">' . esc_html__( 'Estado', 'f3base' ) . '</th>';
		$html .= '<th scope="col">' . esc_html__( 'Checagem', 'f3base' ) . '</th>';
		$html .= '<th scope="col">' . esc_html__( 'Mensagem', 'f3base' ) . '</th>';
		$html .= '<th scope="col">' . esc_html__( 'Evidência', 'f3base' ) . '</th>';
		$html .= '</tr></thead><tbody>';

		foreach ( self::$linhas as $linha ) {
			$html .= '<tr class="f3base-estado-' . esc_attr( sanitize_html_class( str_replace( '/', '-', (string) $linha['estado'] ) ) ) . '">';
			$html .= '<td><strong>' . esc_html( (string) $linha['estado'] ) . '</strong></td>';
			$html .= '<td><code>' . esc_html( (string) $linha['nome'] ) . '</code></td>';
			$html .= '<td>' . esc_html( (string) $linha['mensagem'] ) . '</td>';
			$html .= '<td>' . esc_html( trim( (string) $linha['evidencia'] . '/' . (string) $linha['fase'], '/' ) ) . '</td>';
			$html .= '</tr>';
		}

		$html .= '</tbody></table></details>';

		return $html;
	}

	/**
	 * A tela e o log, nesta ordem.
	 *
	 * @return string
	 */
	public static function html(): string {
		return self::html_da_tela() . self::html_do_log();
	}
}
