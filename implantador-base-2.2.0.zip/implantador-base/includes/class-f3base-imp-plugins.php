<?php
/**
 * Instalação de tema, `site-core` e plugins.
 *
 * Política, escrita como código e não como prosa:
 *
 * - Plugin de terceiro instala-se **sempre na última versão da fonte oficial**,
 *   pela API do próprio WordPress — o mesmo artefato que a página de plugins do
 *   wp-admin baixaria. **Sem número de versão declarado, sem intervalo homologado, sem checksum
 *   de terceiro**: não se conhece de antemão o hash de uma versão que ainda não
 *   saiu. A versão instalada entra NOMEADA no relatório como fato observado, e
 *   nunca como gate — gate por número reprovaria site saudável no dia seguinte a
 *   uma atualização automática.
 * - **Nunca downgrade.** Presente numa versão igual ou maior que a disponível, o
 *   plugin fica onde está e o fato é registrado.
 * - **O gate é a leitura de volta** de cada option gravada — e ela vive no
 *   gravador único, não aqui.
 * - **Atualização automática ligada para TODO plugin instalado**, conferida por
 *   leitura de volta plugin a plugin, nomeando quem faltar.
 *
 * Três regras que este arquivo passou a garantir depois de uma execução real:
 *
 * 1. **Precedência de origem, nesta ordem:** `assets/<slug>.zip` embutido (sem
 *    rede) → `url` declarada, em **https** → WordPress.org. A primeira que
 *    resolver ganha, e o relatório diz qual respondeu. Endereço que não é https
 *    é BLOCKED **sem download**: sem TLS não há autenticidade de origem nem
 *    integridade em trânsito, e é isso que separa "baixar o artefato do projeto"
 *    de "baixar o que estiver naquele endereço hoje". Falha de rede é BLOCKED com
 *    o host e o código HTTP nomeados — nunca FALHA, porque ausência de
 *    pré-condição externa não é defeito do site. **A guarda é revalidada DEPOIS
 *    de cada redirecionamento**, e não só antes do download: um endereço https
 *    que responda 302 para `http://` entregaria o artefato por canal aberto, e a
 *    guarda estaria sendo conferida no endereço que ninguém baixou.
 * 1b. **Digesto do artefato, e o que ele garante em cada ramo.** `sha256` é
 *    OPCIONAL na entrada de origem `url`. Declarado, é o teto: divergência é
 *    FALHA nomeando os dois valores, e nada é instalado. Ausente, o digesto é
 *    medido e FIXADO na primeira observação — o que defende contra a origem
 *    MUDAR embaixo das execuções seguintes e **não** defende a primeira busca.
 *    O ramo ausente existe porque o template precisa funcionar como produção sem
 *    configuração extra; o limite dele sai escrito na mensagem, porque TOFU que
 *    se apresenta como verificação de integridade é pior que nenhuma.
 * 2. **A pasta criada pela instalação por URL não se presume.** Zip de código-fonte
 *    extrai para `<repo>-<branch>`: instalar `wp-mcp-ultimate-main.zip` cria
 *    `wp-mcp-ultimate-main/` e ativar por `wp-mcp-ultimate/…` falharia. A pasta
 *    vem do RESULTADO do upgrader, e diverge de `pasta_esperada` é renomeada para
 *    ela — com as duas formas, a observada e a final, no relatório.
 * 3. **Supressão de redirecionamento de ativação na MESMA unidade que ativa.**
 *    O plugin de terceiro registra o assistente dele em `admin_init`, que roda
 *    ANTES do `admin_post_*` do implantador: a chave precisa estar no banco antes
 *    da próxima requisição administrativa, ou o lote seguinte volta uma página
 *    inteira do wp-admin em vez do JSON. O mapa é declarado em
 *    `plugins.supressao_onboarding`; slug sem entrada não faz nada, e isso não é erro.
 *
 * `version_compare()` aparece aqui só com operadores da lista permitida
 * (`< lt <= le > gt >= ge == = eq != <> ne`).
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Instalação e atualização dos artefatos.
 */
final class F3Base_Imp_Plugins {

	/**
	 * Option do core com a lista de plugins em atualização automática.
	 */
	public const OPTION_AUTOUPDATE = 'auto_update_plugins';

	/**
	 * REGISTRO DA INSTALAÇÃO: digesto observado de cada artefato baixado por URL.
	 *
	 * Ele existe por causa do que a configuração desta base declara: os dois
	 * plugins do canal descem de uma `ref` MUTÁVEL (`.../raw/main/...zip`), e
	 * `main` de hoje não é `main` de amanhã. Com `sha256` declarado na entrada,
	 * este registro não decide nada — o declarado é o teto. Sem ele, o digesto
	 * da PRIMEIRA busca é fixado aqui e passa a ser o teto das execuções
	 * seguintes.
	 *
	 * O QUE ISSO NÃO É, dito antes que alguém leia mais do que está escrito:
	 * não é verificação de integridade do artefato. Fixar na primeira
	 * observação (TOFU) defende contra a origem MUDAR embaixo das execuções
	 * seguintes e **não** defende a primeira busca — se o artefato já veio
	 * trocado, é o artefato trocado que fica fixado. TOFU que se apresenta como
	 * verificação é pior do que nenhuma verificação, porque produz confiança.
	 */
	public const OPTION_DIGESTOS = 'f3base_digestos';

	/**
	 * Saltos de redirecionamento seguidos antes de desistir.
	 *
	 * É o mesmo teto que o `redirection` padrão do `wp_remote_get()` do núcleo
	 * usa. O número existe aqui porque este arquivo passou a seguir os saltos
	 * ELE MESMO: `download_url()` segue redirecionamento sem consultar guarda
	 * nenhuma, e um endereço https que responda 302 para `http://` entregaria o
	 * artefato por canal aberto — a guarda seria conferida no endereço que
	 * ninguém baixou.
	 */
	public const SALTOS_MAXIMOS = 5;

	/**
	 * Marca de nome que identifica uma cópia preservada por este pacote.
	 *
	 * Só para RECONHECER diretório existente. A CONSTRUÇÃO do caminho novo mora
	 * em `caminho_do_backup()`, e lá o literal traz o ponto na frente — que é o
	 * que `pacote.backup_sempre_oculto` confere na análise estática. Separar as
	 * duas é o ponto: reconhecer o nome antigo (sem ponto) é obrigação da
	 * migração, e escrevê-lo de novo é o defeito que o detector proíbe.
	 */
	public const MARCA_ANTERIOR = '-f3base-anterior-';

	/**
	 * PREFIXO do nome de uma cópia preservada por este pacote — com o ponto.
	 *
	 * Ponto único de CONSTRUÇÃO: `caminho_do_backup()` monta a partir dele, e a
	 * poda reconhece a série a partir dele. O ponto na frente é o que mantém a
	 * cópia fora de `get_plugins()`; `pacote.backup_sempre_oculto` confere que
	 * nenhuma outra linha do pacote monta esse caminho sem ele.
	 */
	public const PREFIXO_BACKUP = '.f3base-anterior-';

	/**
	 * Ação inversa registrada no journal quando um diretório é renomeado.
	 */
	public const INVERSA_RENOMEAR = 'diretorio.renomear';

	/**
	 * Ação inversa registrada no journal quando uma cópia preservada é PODADA.
	 *
	 * A poda é irreversível por natureza — o diretório sai do disco. O journal
	 * registra o que saiu, com o nome, para que o operador consiga reconstruir a
	 * história; a reversão automática não é prometida, e dizer isso é parte do
	 * registro.
	 */
	public const INVERSA_PODAR = 'diretorio.podado';

	/**
	 * PREFIXOS onde um zip embutido pode estar, na ordem de precedência.
	 *
	 * Lista de UM lugar só, por uma razão medida na 1.0.15: `zip_embutido()`
	 * procurava aqui, `F3Base_Imp_Entrega` procurava em outra lista escrita à
	 * mão, e um zip que viajava no pacote fora das duas não era lido por
	 * ninguém — peso morto que ainda por cima servia de prova falsa de entrega.
	 * Quem resolve o artefato de um papel é `artefato_do_papel()`, e é dele que
	 * a instalação E a conferência de entregável saem.
	 */
	public const PREFIXOS_DE_ZIP = array( 'assets/plugins/', 'assets/' );

	/**
	 * Último plugin ATIVADO nesta requisição, conferido por leitura de volta.
	 *
	 * Viaja na resposta do lote e o cliente o guarda: quando a requisição
	 * SEGUINTE volta sequestrada por um `admin_init` de terceiro, o diagnóstico
	 * consegue nomear quem entrou em cena logo antes.
	 *
	 * @var string
	 */
	private static string $ultimo_ativado = '';

	/**
	 * As ENTRADAS de uma lista declarada de plugins, venha ela do catálogo de
	 * decisões ou da configuração.
	 *
	 * `plugins.instalaveis` é decisão do pacote — quais plugins este implantador
	 * instala, em que papel e de que origem — e mora em `config/decisoes.tsv`.
	 * `plugins.embarcados` continua na configuração porque é estado interno do
	 * artefato. Os dois são percorridos pelos MESMOS laços, e é por isso que a
	 * escolha entre as duas fontes mora AQUI, num lugar só: espalhá-la pelos
	 * chamadores faria cada laço conhecer de onde vem cada lista, e a próxima que
	 * mudasse de casa quebraria todos eles.
	 *
	 * O catálogo responde primeiro. Lista que ele não conhece cai na configuração,
	 * e lista que nenhum dos dois conhece volta VAZIA — que é o lado seguro:
	 * nenhum plugin declarado é melhor do que um plugin inventado.
	 *
	 * @param string $lista Nome pontilhado da lista.
	 * @return array<int|string,mixed>
	 */
	public static function entradas_declaradas( string $lista ): array {
		$do_catalogo = F3Base_Imp_Decisoes::bloco( $lista );

		if ( array() !== $do_catalogo ) {
			return $do_catalogo;
		}

		return F3Base_Imp_Config::lista( $lista );
	}

	/**
	 * Um CAMPO de uma entrada de lista declarada, da MESMA fonte que a entrada.
	 *
	 * @param string     $lista  Nome pontilhado da lista.
	 * @param int|string $indice Índice da entrada.
	 * @param string     $campo  Nome do campo.
	 * @return string
	 */
	public static function campo_declarado( string $lista, $indice, string $campo ): string {
		if ( array() !== F3Base_Imp_Decisoes::bloco( $lista ) ) {
			return F3Base_Imp_Decisoes::campo( $lista . '.' . $indice, $campo );
		}

		return (string) F3Base_Imp_Config::obter( $lista . '.' . $indice . '.' . $campo, '' );
	}

	/**
	 * Último plugin ativado, para o diagnóstico do cliente.
	 *
	 * @return string Slug, ou vazio quando nada foi ativado nesta requisição.
	 */
	public static function ultimo_ativado(): string {
		return self::$ultimo_ativado;
	}

		/**
	 * A VERSÃO DO `site-core`, lida do cabeçalho do próprio plugin.
	 *
	 * O `site-core` tem release PRÓPRIA e numeração própria: ele é instalado
	 * pelo catálogo como qualquer outro plugin, e uma correção nele não obriga
	 * mais uma release do implantador. Por isso o número NÃO mora em
	 * `config/site.json`: ele mora onde o WordPress vai lê-lo, no cabeçalho
	 * `Version:` do arquivo principal — que é a mesma fonte que a lista de
	 * plugins mostra.
	 *
	 * @param string $arquivo Caminho do arquivo principal do plugin.
	 * @return string Versão declarada, ou vazio quando o cabeçalho não existe.
	 */
	public static function versao_do_cabecalho( string $arquivo ): string {
		if ( '' === $arquivo || ! is_file( $arquivo ) || ! is_readable( $arquivo ) ) {
			return '';
		}

		$topo = (string) file_get_contents( $arquivo, false, null, 0, 8192 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- arquivo do próprio pacote, sem rede.

		if ( 1 !== preg_match( '/^[\s*#@]*Version:\s*(\S+)\s*$/mi', $topo, $achou ) ) {
			return '';
		}

		return trim( $achou[1] );
	}

/**
	 * Versão instalada de um plugin pelo slug do diretório.
	 *
	 * Fato observado, para NOMEAR o relatório. Nunca decide nada.
	 *
	 * @param string $slug Slug do diretório.
	 * @return string Versão, ou vazio quando não instalado.
	 */
	public static function versao_instalada( string $slug ): string {
		$arquivo = self::arquivo_principal( $slug );

		if ( '' === $arquivo ) {
			return '';
		}

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$todos = get_plugins();

		return isset( $todos[ $arquivo ]['Version'] ) ? (string) $todos[ $arquivo ]['Version'] : '';
	}

	/**
	 * Arquivo principal de um plugin pelo slug do diretório.
	 *
	 * @param string $slug Slug.
	 * @return string Caminho relativo, ou vazio.
	 */
	public static function arquivo_principal( string $slug ): string {
		if ( '' === $slug ) {
			return '';
		}

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		foreach ( array_keys( get_plugins() ) as $arquivo ) {
			if ( F3Base_Imp_Preflight::slug_de( (string) $arquivo ) === $slug ) {
				return (string) $arquivo;
			}
		}

		return '';
	}

	/**
	 * O arquivo ÚNICO que declara os emissores de tag conhecidos.
	 *
	 * O DONO dele é o repositório do plugin, e o site o recebe dentro do zip.
	 * O que mora em `partilhado/` é uma CÓPIA VENDORIZADA, declarada em
	 * `partilhado/VENDORIZADO.tsv` e conferida byte a byte, a cada rodada da
	 * suíte, contra a reserva — o zip publicado copiado para a árvore. O
	 * implantador lê daqui porque o preflight roda ANTES de o plugin existir na
	 * instalação; a declaração continua sendo uma, porque a cópia que diverge
	 * do zip é acusada por `pacote.copia_vendorizada_confere`.
	 *
	 * ATÉ A 1.6.6 ELE ERA LIDO DE DENTRO DA FONTE DO PLUGIN, e era essa leitura
	 * que obrigava aquela fonte a viajar dentro do bundle do implantador. Da
	 * 1.7.0 à 1.7.4 a cópia daqui era a ORIGEM que o empacotamento levava para
	 * o zip; desde a 2.0.0 é o contrário — o zip publicado é a origem, e esta
	 * é a cópia.
	 *
	 * @return string
	 */
	public static function arquivo_de_emissores(): string {
		return F3BASE_IMP_DIR . 'partilhado/dados/emissores-conhecidos.tsv';
	}

		/**
	 * Carrega uma REGRA COMPARTILHADA com o `site-core`, venha ela de onde vier.
	 *
	 * Estas classes rodam em DOIS runtimes que não se enxergam: o `site-core`
	 * as carrega pelo autoload dele, e o implantador precisa das mesmas regras
	 * para escrever o que o plugin depois vai ler. Uma segunda cópia dentro do
	 * implantador divergiria na primeira condição acrescentada.
	 *
	 * A ORDEM É PLUGIN INSTALADO PRIMEIRO, e é o que muda com a release própria
	 * do `site-core`: ele deixou de ser fonte que o implantador grava e passou a
	 * ser plugin instalado pelo catálogo, possivelmente numa versão mais nova do
	 * que a que viajou no zip. Ler a cópia do pacote quando o plugin já está
	 * instalado faria o implantador escrever segundo uma regra ANTIGA em cima de
	 * um plugin novo — e nada acusaria, porque a gravação funciona.
	 *
	 * A cópia de `partilhado/` é a RESERVA, e ela responde no único momento em
	 * que o plugin ainda não existe: o preflight, que roda antes de instalar
	 * nada. O caminho relativo é o MESMO dos dois lados — `includes/x.php` —
	 * porque `partilhado/` é uma cópia VENDORIZADA do zip publicado, arquivo a
	 * arquivo no mesmo caminho relativo (`partilhado/VENDORIZADO.tsv` declara
	 * qual entrada do zip cada um espelha, e a suíte confere os bytes); um
	 * caminho diferente de cada lado obrigaria esta função a traduzir, e a
	 * tradução é onde a divergência começa.
	 *
	 * @param string $classe   Nome da classe compartilhada.
	 * @param string $relativo Caminho do arquivo dentro do plugin.
	 * @return bool A regra está disponível?
	 */
	public static function carregar_do_site_core( string $classe, string $relativo ): bool {
		if ( class_exists( $classe ) ) {
			return true;
		}

		$slug = (string) F3Base_Imp_Config::obter( 'site.site_core_slug', '' );

		$candidatos = array();

		if ( '' !== $slug && defined( 'WP_PLUGIN_DIR' ) ) {
			$candidatos[] = WP_PLUGIN_DIR . '/' . $slug . '/' . $relativo;
		}

		$candidatos[] = F3BASE_IMP_DIR . 'partilhado/' . $relativo;

		foreach ( $candidatos as $arquivo ) {
			if ( ! is_file( $arquivo ) ) {
				continue;
			}

			require_once $arquivo;

			if ( class_exists( $classe ) ) {
				return true;
			}
		}

		return false;
	}

/**
	 * Carrega a REGRA compartilhada do segundo emissor.
	 *
	 * A classe é a mesma do `site-core`, carregada do arquivo de origem: a
	 * alternativa era uma segunda cópia da regra dentro do implantador, e duas
	 * cópias divergem na primeira condição acrescentada. A guarda existe porque
	 * os dois plugins alcançam o arquivo por caminhos diferentes, e
	 * `require_once` não os reconhece como o mesmo.
	 *
	 * @return bool A regra está disponível?
	 */
	public static function carregar_regra_de_emissores(): bool {
		return self::carregar_do_site_core( 'F3Base_Emissores', 'includes/class-f3base-emissores.php' );
	}

	/**
	 * Carrega a REGRA compartilhada do censo de conteúdo demonstrativo.
	 *
	 * Mesmo desenho e mesmo motivo de `carregar_regra_de_emissores()`: a regra
	 * roda em dois runtimes que não se enxergam — no `site-core`, na cadência, e
	 * aqui, no relatório do implantador, que precisa dela mesmo antes de o
	 * plugin persistente existir na instalação. O arquivo é UM só, alcançado por
	 * dois caminhos, com guarda de `class_exists` porque `require_once` não
	 * reconhece os dois como o mesmo.
	 *
	 * @return bool A regra está disponível?
	 */
	public static function carregar_regra_do_censo_demonstrativo(): bool {
		return self::carregar_do_site_core( 'F3Base_Censo_Demonstrativo', 'includes/class-f3base-censo-demonstrativo.php' );
	}

		/**
	 * Carrega o VOCABULÁRIO compartilhado a partir da cópia de origem.
	 *
	 * Mesmo caminho e mesmo motivo de `carregar_vocabulario_do_seo()`: a classe
	 * roda em dois runtimes que não se enxergam, e o implantador a alcança pelo
	 * arquivo que vai virar o `site-core` no empacotamento.
	 *
	 * @return bool Verdadeiro quando a classe está disponível.
	 */
	public static function carregar_vocabulario(): bool {
		return self::carregar_do_site_core( 'F3Base_Vocabulario', 'includes/class-f3base-vocabulario.php' );
	}

/**
	 * Carrega o VOCABULÁRIO das chaves do plugin de SEO.
	 *
	 * Mesmo desenho e mesmo motivo de `carregar_regra_do_censo_demonstrativo()`:
	 * o arquivo é UM só, alcançado por dois caminhos. Aqui ele importa porque
	 * este pacote toca as mesmas chaves dos DOIS lados — o implantador ESCREVE a
	 * meta de cada conteúdo e o `site-core` a LÊ —, e sem fonte comum uma
	 * renomeação do fornecedor quebraria os dois em lugares diferentes, cada um
	 * calado.
	 *
	 * @return bool O vocabulário está disponível?
	 */
	public static function carregar_vocabulario_do_seo(): bool {
		return self::carregar_do_site_core( 'F3Base_Chaves_Seo', 'includes/class-f3base-chaves-seo.php' );
	}

	/**
	 * A declaração dos emissores conhecidos, por slug.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public static function emissores_declarados(): array {
		if ( ! self::carregar_regra_de_emissores() ) {
			return array();
		}

		return F3Base_Emissores::declarados( self::arquivo_de_emissores() );
	}

	/**
	 * O veredito de emissão de um slug — delegado à regra compartilhada.
	 *
	 * @param array<string,mixed> $declaracao Entrada declarada do slug.
	 * @param array<string,mixed> $observadas Options observadas, por nome.
	 * @return array{veredito:string,motivo:string}
	 */
	public static function veredito_de_emissao( array $declaracao, array $observadas ): array {
		if ( ! self::carregar_regra_de_emissores() ) {
			return array(
				'veredito' => 'nao-medido',
				'motivo'   => __( 'a regra compartilhada de emissores não pôde ser carregada do arquivo de origem: sem ela nada foi medido, e o que não foi medido não absolve.', 'f3base' ),
			);
		}

		return F3Base_Emissores::veredito( $declaracao, $observadas );
	}

	/**
	 * As options de CONDIÇÃO declaradas, lidas do banco desta instalação.
	 *
	 * Só as options que a declaração NOMEIA são lidas — a leitura não varre o
	 * banco atrás de nada. Option ausente não entra no mapa, e é a ausência que
	 * faz o veredito fechar `nao-medido` em vez de absolver.
	 *
	 * @param array<string,array<string,mixed>> $declarados Declaração por slug.
	 * @return array<string,mixed>
	 */
	public static function options_de_condicao( array $declarados ): array {
		$saida = array();

		foreach ( $declarados as $declaracao ) {
			foreach ( (array) ( $declaracao['condicoes'] ?? array() ) as $condicao ) {
				$nome = (string) ( $condicao['option'] ?? '' );

				if ( '' === $nome || array_key_exists( $nome, $saida ) ) {
					continue;
				}

				$lido = get_option( $nome, null );

				if ( null !== $lido ) {
					$saida[ $nome ] = $lido;
				}
			}
		}

		return $saida;
	}

	/**
	 * Instala ou atualiza um plugin declarado em `plugins.instalaveis`.
	 *
	 * @param int $indice Índice na lista.
	 * @return array<string,mixed>
	 */
	public static function aplicar_instalavel( int $indice ): array {
		$slug     = (string) F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $indice, 'slug' );
		$papel    = (string) F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $indice, 'papel' );
		$origem   = (string) F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $indice, 'origem' );
		$esperada = (string) F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $indice, 'pasta_esperada' );
		$rotulo   = 'plugins.instalado:' . $slug;

		if ( '' === $slug ) {
			return self::saida( 'BLOCKED', 'plugins.instalado', __( 'entrada de plugin sem slug declarado.', 'f3base' ) );
		}

		$instalada = self::versao_instalada( $slug );

		$disponivel = self::resolver_origem( $indice, $slug );

		if ( $disponivel['bloqueado'] ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				sprintf(
					/* translators: 1: motivo do bloqueio, 2: origem declarada, 3: ordem de resolução tentada. */
					__( '%1$s Origem declarada: %2$s. Precedência tentada, nesta ordem — %3$s', 'f3base' ),
					$disponivel['motivo'],
					$origem,
					implode( ' · ', $disponivel['tentativas'] )
				)
			);
		}

		if ( '' === $disponivel['pacote'] ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				sprintf(
					/* translators: 1: slug, 2: origem declarada, 3: motivo da fonte, 4: versão observada, 5: ordem de resolução tentada. */
					__( 'nenhuma origem de %1$s (origem declarada: %2$s) resolveu um artefato para instalar: %3$s. Instalação manual pelo wp-admin é o caminho de contingência declarado. Versão observada no site: %4$s. Precedência tentada, nesta ordem — %5$s', 'f3base' ),
					$slug,
					$origem,
					$disponivel['erro'],
					'' !== $instalada ? $instalada : __( 'não instalado', 'f3base' ),
					implode( ' · ', $disponivel['tentativas'] )
				)
			);
		}

		if ( '' !== $instalada && '' !== $disponivel['versao'] && ! version_compare( $instalada, $disponivel['versao'], '<' ) ) {
			$ativou    = self::ativar( $slug );
			$supressao = self::suprimir_redirecionamento_de_ativacao( $slug );

			return self::saida(
				F3Base_Imp_Relatorio::estado_mais_severo( $ativou['estado'], $supressao['estado'] ),
				$rotulo,
				sprintf(
					/* translators: 1: slug, 2: versão instalada, 3: versão disponível, 4: papel declarado, 5: resultado da ativação, 6: resultado da supressão. */
					__( '%1$s permanece na versão instalada %2$s (disponível na fonte oficial: %3$s) — nunca downgrade. Papel: %4$s. %5$s %6$s', 'f3base' ),
					$slug,
					$instalada,
					$disponivel['versao'],
					$papel,
					$ativou['motivo'],
					$supressao['motivo']
				)
			);
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida(
				'N/A',
				$rotulo,
				sprintf(
					/* translators: 1: slug, 2: versão observada, 3: versão da fonte, 4: origem que respondeu, 5: ordem de resolução tentada. */
					__( 'modo simulação: instalaria %1$s (observada: %2$s) na versão %3$s vinda de %4$s. Precedência tentada, nesta ordem — %5$s', 'f3base' ),
					$slug,
					'' !== $instalada ? $instalada : __( 'não instalado', 'f3base' ),
					'' !== $disponivel['versao'] ? $disponivel['versao'] : __( 'última da origem', 'f3base' ),
					$disponivel['fonte'],
					implode( ' · ', $disponivel['tentativas'] )
				)
			);
		}

		/*
		 * NÃO TROCAR O QUE NÃO MUDOU. Antes de qualquer escrita: a versão
		 * observada é igual à do artefato E o conteúdo bate por hash? Então a
		 * troca é pulada. Cada troca pulada é um `.f3base-anterior-*` que não
		 * nasce — sete deles depois de quatro execuções foi o crescimento sem
		 * teto que esta regra fecha pela raiz. Só vale para artefato LOCAL: o
		 * hash de um zip que ainda está do outro lado da rede não existe, e
		 * baixar para comparar seria pagar o custo que a regra evita.
		 */
		/*
		 * O artefato REMOTO desce ANTES da comparação, e o instalador recebe o
		 * arquivo local. É a única forma de comparar com "o artefato baixado":
		 * o hash de um zip que ainda está do outro lado da rede não existe. O
		 * download é o mesmo par que a página de plugins do wp-admin usa, e a
		 * falha dele continua sendo BLOCKED com host e código HTTP nomeados.
		 */
		$artefato      = (string) $disponivel['pacote'];
		$baixado       = '';
		$cadeia        = '';
		$digesto       = '';
		$sha256_medido = '';
		$endereco      = '';
		$sobrescreve   = '' !== $instalada || (bool) $disponivel['remota'];

		if ( $disponivel['remota'] ) {
			$download = self::baixar_artefato( $artefato );

			if ( ! $download['ok'] ) {
				/*
				 * A RESERVA VERSIONADA RESPONDE QUANDO A URL NÃO RESPONDE — 2.0.0.
				 *
				 * O DEFEITO MEDIDO, e ele durou da 1.7.0 à 1.7.4 com todos os
				 * documentos afirmando o contrário: o resolvedor só conhecia o
				 * slot do OPERADOR (`assets/plugins/<slug>.zip`, sem número), e a
				 * reserva versionada que o build embutia
				 * (`assets/plugins/<slug>-<versão>.zip`) era resolvida por
				 * `artefato_do_papel()` — para a linha de versão e para os
				 * entregáveis — e por mais ninguém. Com a URL fora do ar a
				 * instalação fechava BLOCKED, e a frase "se a URL não responder,
				 * cai na reserva" era falsa em todo lugar em que estava escrita.
				 * A bancada não via porque MONTAVA o slot do operador para se
				 * testar, exercitando o caminho que não era o da entrega.
				 *
				 * SÓ PARA A ORIGEM `url` DECLARADA — a que tem digesto. A reserva
				 * versionada é artefato NOSSO; um plugin do wordpress.org não tem
				 * reserva que este pacote responda por, e responder por uma que
				 * calhasse de existir instalaria sem conferência nenhuma. E só
				 * depois de a URL ter sido tentada: a precedência declarada
				 * continua sendo operador → URL → reserva. A reserva passa pelo
				 * MESMO digesto que o download passaria, logo abaixo.
				 */
				$reserva = self::digesto_se_aplica( $origem ) ? self::reserva_versionada( $slug ) : array( 'caminho' => '', 'relativo' => '', 'versao' => '', 'motivo' => '' );

				if ( '' === $reserva['caminho'] ) {
					return self::saida(
						'BLOCKED',
						$rotulo,
						sprintf(
							/* translators: 1: motivo do download, 2: origem que respondeu, 3: o que se sabe da reserva versionada. */
							__( '%1$s Origem que respondeu: %2$s. Reserva versionada: %3$s.', 'f3base' ),
							$download['motivo'],
							$disponivel['fonte'],
							'' !== (string) $reserva['motivo']
								? (string) $reserva['motivo']
								: ( self::digesto_se_aplica( $origem )
									/* translators: %s: caminho esperado da reserva. */
									? sprintf( __( 'nenhuma em %s, então não há artefato local que responda no lugar da URL', 'f3base' ), 'assets/plugins/' . $slug . '-<versão>.zip' )
									: __( 'não se aplica — só artefato de origem url declarada tem reserva embutida', 'f3base' ) )
						)
					);
				}

				/*
				 * NUNCA DOWNGRADE vale para a reserva também. A guarda de cima
				 * comparou a instalada com a versão que a origem ANUNCIOU, e a
				 * URL não anuncia; a reserva tem versão, e ela é lida do
				 * CABEÇALHO de dentro do zip — a mesma fonte de `$instalada`.
				 */
				$versao_da_reserva = self::versao_do_zip( $reserva['caminho'] );

				if ( '' !== $instalada && '' !== $versao_da_reserva && ! version_compare( $instalada, $versao_da_reserva, '<' ) ) {
					$ativou    = self::ativar( $slug );
					$supressao = self::suprimir_redirecionamento_de_ativacao( $slug );

					return self::saida(
						F3Base_Imp_Relatorio::estado_mais_severo( $ativou['estado'], $supressao['estado'] ),
						$rotulo,
						sprintf(
							/* translators: 1: slug, 2: versão instalada, 3: versão da reserva, 4: caminho da reserva, 5: motivo do download, 6: papel, 7: ativação, 8: supressão. */
							__( '%1$s permanece na versão instalada %2$s: a URL declarada não respondeu (%5$s) e a reserva versionada (%4$s) carrega %3$s — nunca downgrade. Papel: %6$s. %7$s %8$s', 'f3base' ),
							$slug,
							$instalada,
							$versao_da_reserva,
							$reserva['relativo'],
							$download['motivo'],
							$papel,
							$ativou['motivo'],
							$supressao['motivo']
						)
					);
				}

				$disponivel['tentativas'][] = sprintf(
					/* translators: 1: caminho relativo da reserva, 2: motivo pelo qual a URL não respondeu. */
					__( '3) reserva versionada (%1$s): respondeu, porque a URL declarada não respondeu — %2$s', 'f3base' ),
					$reserva['relativo'],
					$download['motivo']
				);
				$disponivel['fonte']  = sprintf(
					/* translators: 1: caminho relativo da reserva, 2: motivo pelo qual a URL não respondeu. */
					__( 'reserva versionada embutida no pacote (%1$s), porque a URL declarada não respondeu: %2$s', 'f3base' ),
					$reserva['relativo'],
					$download['motivo']
				);
				$disponivel['remota'] = false;
				$artefato             = $reserva['caminho'];
				$sha256_medido        = (string) hash_file( 'sha256', $artefato );
				$endereco             = $reserva['relativo'];
			} else {
				$artefato      = $download['arquivo'];
				$baixado       = $download['arquivo'];
				$cadeia        = (string) $download['motivo'];
				$sha256_medido = (string) $download['sha256'];
				$endereco      = (string) $download['url_final'];
			}
		} elseif ( is_file( $artefato ) ) {
			/*
			 * ARTEFATO LOCAL — o slot do operador — TAMBÉM É MEDIDO, e o digesto
			 * declarado vale para ele quando a origem declarada é `url`: o zip
			 * que o operador embutiu por decisão explícita instala no lugar do
			 * publicado, e instalar sem conferir seria aceitar qualquer arquivo
			 * com aquele nome. Ele nunca FIXA digesto: fixar é coisa de
			 * download, porque o que se fixa é "o que a origem serviu".
			 */
			$sha256_medido = (string) hash_file( 'sha256', $artefato );
			$dir_do_pacote = rtrim( str_replace( '\\', '/', F3BASE_IMP_DIR ), '/' ) . '/';
			$caminho_local = str_replace( '\\', '/', $artefato );
			$endereco      = str_starts_with( $caminho_local, $dir_do_pacote ) ? substr( $caminho_local, strlen( $dir_do_pacote ) ) : $caminho_local;
		}

		/*
		 * O DIGESTO SÓ VALE PARA A ORIGEM `url` DECLARADA, e a fronteira é o
		 * CONTRATO, regra 20: "sempre a última versão da
		 * fonte oficial", sem número de versão declarado e SEM CHECKSUM DE
		 * TERCEIRO.
		 *
		 * A razão daquela regra é que não se conhece de antemão o hash de uma
		 * versão que ainda não saiu — e ela vale inteira para o WordPress.org,
		 * cuja URL é POR VERSÃO e cujo artefato MUDA de propósito a cada
		 * atualização. Fixar o digesto ali transformaria a próxima versão
		 * legítima em FALHA, que é o oposto da política.
		 *
		 * A origem `url` declarada é outra coisa: o artefato é NOSSO, e a URL
		 * aponta para uma ref MUTÁVEL (`.../raw/main/...zip`) — o mesmo
		 * endereço servindo conteúdo diferente sem que nada no site mude. É
		 * exatamente o caso que a regra 20 não cobre, e é só nele que a
		 * conferência acontece. O schema executa a mesma fronteira: `sha256`
		 * existe no ramo `origem: "url"` e o outro ramo continua fechado.
		 *
		 * A CONFERÊNCIA RODA MESMO SEM MEDIÇÃO: digesto que não pôde ser medido
		 * é recusa, nunca silêncio — `veredito_do_digest()` fecha esse ramo, e
		 * pular a chamada por medição vazia seria instalar sem conferência
		 * justamente na origem em que ela existe.
		 */
		if ( self::digesto_se_aplica( $origem ) ) {
			/*
			 * A CONFERÊNCIA ACONTECE ANTES DE INSTALAR, e a divergência apaga o
			 * arquivo baixado: instalar primeiro e reclamar depois deixaria no
			 * site o binário que a conferência acabou de recusar.
			 *
			 * ARTEFATO LOCAL NÃO FIXA. O digesto fixado é "o que a origem
			 * serviu na primeira observação", e um zip do slot do operador ou
			 * da reserva não foi servido por origem nenhuma: fixá-lo faria a
			 * execução seguinte reprovar o download legítimo da URL como
			 * "divergente do fixado". O local confere contra o DECLARADO, e
			 * sem declaração instala como a 1.7.4 instalava — sem fixar.
			 */
			$declarado = (string) F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $indice, 'sha256' );

			if ( '' === $baixado && '' === $declarado ) {
				$digesto = sprintf(
					/* translators: %s: sha256 medido do artefato local. */
					__( 'Digesto NÃO declarado no catálogo, e o artefato é LOCAL (%1$s): nada a conferir e nada a fixar — fixar é coisa de download, porque o que se fixa é o que a origem serviu. Digesto observado, como fato de diagnóstico: sha256 %2$s.', 'f3base' ),
					$endereco,
					'' !== $sha256_medido ? $sha256_medido : __( 'não pôde ser medido', 'f3base' )
				);
			} else {
				$veredito = self::veredito_do_digest(
					$declarado,
					$sha256_medido,
					'' === $baixado ? '' : self::digesto_fixado( $slug )
				);

				if ( ! $veredito['ok'] ) {
					if ( '' !== $baixado && file_exists( $baixado ) ) {
						wp_delete_file( $baixado );
					}

					return self::saida(
						'FALHA',
						$rotulo,
						sprintf(
							/* translators: 1: slug, 2: motivo do digesto, 3: endereço final de onde o artefato desceu ou caminho local da reserva, 4: cadeia de hosts conferida. */
							__( '%1$s NÃO foi instalado. %2$s Endereço final: %3$s. %4$s', 'f3base' ),
							$slug,
							$veredito['motivo'],
							$endereco,
							$cadeia
						)
					);
				}

				if ( $veredito['fixar'] && '' !== $baixado && ! F3Base_Imp_Gravador::em_simulacao() ) {
					self::fixar_digesto( $slug, $sha256_medido, $endereco );
				}

				$digesto = (string) $veredito['motivo'];
			}
		} elseif ( '' !== $baixado ) {
			$digesto = sprintf(
				/* translators: 1: origem declarada, 2: sha256 observado. */
				__( 'Digesto NÃO conferido e NÃO fixado, por decisão de contrato: a origem declarada é "%1$s", a URL do artefato é por VERSÃO e o conteúdo dela muda de propósito a cada atualização — fixar o digesto aqui faria a próxima versão legítima reprovar, que é o oposto de "sempre a última versão da fonte oficial". Digesto observado deste download, como fato de diagnóstico e nada além disso: sha256 %2$s.', 'f3base' ),
				'' !== $origem ? $origem : __( 'não declarada', 'f3base' ),
				$sha256_medido
			);
		}

		$mesmo = self::artefato_identico( WP_PLUGIN_DIR . '/' . $slug, $instalada, $disponivel['versao'], $artefato );

		if ( $mesmo['identico'] ) {
			if ( '' !== $baixado && file_exists( $baixado ) ) {
				wp_delete_file( $baixado );
			}

			$ativou    = self::ativar( $slug );
			$supressao = self::suprimir_redirecionamento_de_ativacao( $slug );

			return self::saida(
				F3Base_Imp_Relatorio::estado_mais_severo( $ativou['estado'], $supressao['estado'] ),
				$rotulo,
				sprintf(
					/* translators: 1: slug, 2: motivo da identidade, 3: papel, 4: origem que respondeu, 5: cadeia de hosts conferida, 6: veredito do digesto, 7: resultado da ativação, 8: resultado da supressão. */
					__( '%1$s: %2$s Papel: %3$s. Origem que respondeu: %4$s. %5$s %6$s %7$s %8$s', 'f3base' ),
					$slug,
					$mesmo['motivo'],
					$papel,
					$disponivel['fonte'],
					$cadeia,
					$digesto,
					$ativou['motivo'],
					$supressao['motivo']
				)
			);
		}

		/*
		 * Medido ANTES de instalar: o destino da renomeação já existia? É o que
		 * separa "substituo a instalação anterior deste mesmo artefato, com
		 * preimagem no journal" de "o destino é de outro dono, e aí é BLOCKED".
		 */
		$destino_ja_existia = '' !== $esperada && is_dir( WP_PLUGIN_DIR . '/' . $esperada );

		$instalou = self::instalar_pacote( $artefato, $sobrescreve );

		if ( '' !== $baixado && file_exists( $baixado ) ) {
			wp_delete_file( $baixado );
		}

		if ( ! $instalou['ok'] ) {
			return self::saida(
				$instalou['bloqueado'] ? 'BLOCKED' : 'FALHA',
				$rotulo,
				sprintf(
					/* translators: 1: motivo, 2: origem que respondeu. */
					__( '%1$s Origem que respondeu: %2$s.', 'f3base' ),
					$instalou['motivo'],
					$disponivel['fonte']
				)
			);
		}

		$pasta = self::conciliar_pasta( $instalou['pasta'], $esperada, $destino_ja_existia );

		if ( 'OK' !== $pasta['estado'] ) {
			return self::saida( $pasta['estado'], $rotulo, $pasta['motivo'] );
		}

		$diretorio = '' !== $pasta['final'] ? $pasta['final'] : $slug;
		$agora     = self::versao_instalada( $diretorio );
		$ativou    = self::ativar( $diretorio );
		$supressao = self::suprimir_redirecionamento_de_ativacao( $slug );

		return self::saida(
			'' !== $agora ? F3Base_Imp_Relatorio::estado_mais_severo( $ativou['estado'], $supressao['estado'] ) : 'FALHA',
			$rotulo,
			'' !== $agora
				? sprintf(
					/* translators: 1: slug, 2: versão observada depois da instalação, 3: origem que respondeu, 4: papel, 5: cadeia de hosts conferida, 6: veredito do digesto, 7: pasta observada e final, 8: resultado da ativação, 9: resultado da supressão, 10: precedência tentada. */
					__( '%1$s instalado na versão observada %2$s (origem que respondeu: %3$s). Papel: %4$s. %5$s %6$s %7$s %8$s %9$s Precedência tentada, nesta ordem — %10$s', 'f3base' ),
					$slug,
					$agora,
					$disponivel['fonte'],
					$papel,
					$cadeia,
					$digesto,
					$pasta['motivo'],
					$ativou['motivo'],
					$supressao['motivo'],
					implode( ' · ', $disponivel['tentativas'] )
				)
				: sprintf(
					/* translators: 1: slug, 2: pasta observada e final. */
					__( '%1$s não apareceu no disco depois da instalação. %2$s', 'f3base' ),
					$slug,
					$pasta['motivo']
				)
		);
	}

	/**
	 * Resolve a origem do artefato, na ordem de precedência declarada.
	 *
	 * `assets/<slug>.zip` embutido (sem rede) → `url` declarada com host
	 * autorizado → WordPress.org. A primeira que resolver ganha, e cada tentativa
	 * entra em `tentativas` para o relatório dizer QUAL respondeu — e não apenas
	 * que alguma respondeu. É essa ordem que faz o operador dispensar a rede só
	 * pondo o zip em `assets/`, sem mudar uma linha de configuração.
	 *
	 * @param int    $indice Índice em `plugins.instalaveis`.
	 * @param string $slug   Slug declarado.
	 * @return array{pacote:string,remota:bool,versao:string,fonte:string,erro:string,bloqueado:bool,motivo:string,tentativas:array<int,string>}
	 */
	private static function resolver_origem( int $indice, string $slug ): array {
		$tentativas = array();
		$origem     = (string) F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $indice, 'origem' );
		$embutido   = self::zip_embutido( $slug );

		if ( '' !== $embutido ) {
			$tentativas[] = sprintf(
				/* translators: %s: caminho do zip embutido. */
				__( '1) %s: respondeu, e nenhuma chamada de rede foi feita', 'f3base' ),
				'assets/' . $slug . '.zip'
			);

			return self::origem_resolvida(
				$embutido,
				false,
				'',
				sprintf(
					/* translators: %s: caminho do zip embutido. */
					__( 'zip embutido no pacote (%s), sem rede', 'f3base' ),
					'assets/' . $slug . '.zip'
				),
				$tentativas
			);
		}

		$tentativas[] = sprintf(
			/* translators: %s: caminho do zip embutido. */
			__( '1) %s: ausente no pacote', 'f3base' ),
			'assets/' . $slug . '.zip'
		);

		$url = (string) F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $indice, 'url' );

		if ( '' !== $url ) {
			$guarda = self::salto_e_https( $url );

			if ( ! $guarda['ok'] ) {
				$tentativas[] = sprintf(
					/* translators: %s: host declarado na URL. */
					__( '2) url declarada (host %s): recusada antes de qualquer download', 'f3base' ),
					'' !== $guarda['host'] ? $guarda['host'] : __( 'ilegível', 'f3base' )
				);

				return self::origem_bloqueada( $guarda['motivo'], $tentativas );
			}

			$tentativas[] = sprintf(
				/* translators: %s: host da URL declarada. */
				__( '2) url declarada (host %s): https, e respondeu', 'f3base' ),
				$guarda['host']
			);

			return self::origem_resolvida(
				$url,
				true,
				'',
				sprintf(
					/* translators: 1: host, 2: URL declarada. */
					__( 'URL declarada em https, host %1$s (%2$s)', 'f3base' ),
					$guarda['host'],
					$url
				),
				$tentativas
			);
		}

		if ( 'url' === $origem ) {
			$tentativas[] = __( '2) url declarada: nenhuma, e a origem declarada exige uma', 'f3base' );

			return self::origem_bloqueada(
				sprintf(
					/* translators: 1: slug, 2: caminho da chave no arquivo de configuração. */
					__( '%1$s declara origem "url" e não declara %2$s: sem URL não há o que baixar, e adivinhar endereço de artefato seria o pacote escolhendo de onde o site baixa código.', 'f3base' ),
					$slug,
					'plugins.instalaveis[' . $indice . '].url'
				),
				$tentativas
			);
		}

		$tentativas[] = __( '2) url declarada: nenhuma', 'f3base' );

		$oficial = self::consultar_fonte_oficial( $slug );

		$tentativas[] = '' !== $oficial['url']
			? sprintf(
				/* translators: %s: versão anunciada pela fonte oficial. */
				__( '3) wordpress.org: respondeu com a versão %s', 'f3base' ),
				'' !== $oficial['versao'] ? $oficial['versao'] : __( 'não anunciada', 'f3base' )
			)
			: sprintf(
				/* translators: %s: motivo devolvido pela API. */
				__( '3) wordpress.org: não resolveu — %s', 'f3base' ),
				$oficial['erro']
			);

		return array(
			'pacote'     => $oficial['url'],
			'remota'     => '' !== $oficial['url'],
			'versao'     => $oficial['versao'],
			'fonte'      => $oficial['fonte'],
			'erro'       => $oficial['erro'],
			'bloqueado'  => false,
			'motivo'     => '',
			'tentativas' => $tentativas,
		);
	}

	/**
	 * Monta uma origem que resolveu.
	 *
	 * @param string            $pacote     URL ou caminho local do artefato.
	 * @param bool              $remota     Precisa de rede.
	 * @param string            $versao     Versão conhecida de antemão, quando houver.
	 * @param string            $fonte      Nome legível de quem respondeu.
	 * @param array<int,string> $tentativas Ordem tentada.
	 * @return array{pacote:string,remota:bool,versao:string,fonte:string,erro:string,bloqueado:bool,motivo:string,tentativas:array<int,string>}
	 */
	private static function origem_resolvida( string $pacote, bool $remota, string $versao, string $fonte, array $tentativas ): array {
		return array(
			'pacote'     => $pacote,
			'remota'     => $remota,
			'versao'     => $versao,
			'fonte'      => $fonte,
			'erro'       => '',
			'bloqueado'  => false,
			'motivo'     => '',
			'tentativas' => $tentativas,
		);
	}

	/**
	 * Monta uma origem recusada, sem download.
	 *
	 * @param string            $motivo     Motivo do bloqueio.
	 * @param array<int,string> $tentativas Ordem tentada.
	 * @return array{pacote:string,remota:bool,versao:string,fonte:string,erro:string,bloqueado:bool,motivo:string,tentativas:array<int,string>}
	 */
	private static function origem_bloqueada( string $motivo, array $tentativas ): array {
		return array(
			'pacote'     => '',
			'remota'     => false,
			'versao'     => '',
			'fonte'      => __( 'nenhuma', 'f3base' ),
			'erro'       => $motivo,
			'bloqueado'  => true,
			'motivo'     => $motivo,
			'tentativas' => $tentativas,
		);
	}

	/**
	 * O salto é HTTPS? GUARDA ÚNICA de todo endereço de artefato.
	 *
	 * A 1.0.19 tirou daqui a lista fechada de hosts, e a razão está escrita na
	 * decisão 45 da memória: uma lista de hosts declarada NO MESMO ARQUIVO que as
	 * URLs que ela restringe não é controle de segurança — quem consegue editar a
	 * URL edita a lista na linha de cima. Ela era guarda de digitação com preço
	 * de controle, e cobrava do operador uma decisão que não comprava proteção.
	 *
	 * O que ficou faz o trabalho de verdade e não pede nada: HTTPS obrigatório
	 * em TODOS os saltos — a autenticidade de origem e a integridade em trânsito
	 * são do TLS, não de um nome de host escrito ao lado da URL — e o digesto do
	 * artefato, que é o que amarra o BYTE baixado (`veredito_do_digest()`).
	 *
	 * Host continua sendo DEVOLVIDO, porque toda mensagem de falha o nomeia; ele
	 * simplesmente não decide mais nada.
	 *
	 * @param string $url URL do salto.
	 * @return array{ok:bool,host:string,motivo:string}
	 */
	private static function salto_e_https( string $url ): array {
		$host    = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		$esquema = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );

		if ( 'https' !== $esquema ) {
			return array(
				'ok'     => false,
				'host'   => $host,
				'motivo' => sprintf(
					/* translators: 1: esquema observado, 2: host observado, 3: URL do salto. */
					__( 'o endereço não é https (esquema observado: %1$s, host %2$s): artefato de plugin não desce por canal sem autenticidade de origem nem integridade em trânsito. Nenhum download foi feito. URL: %3$s', 'f3base' ),
					'' !== $esquema ? $esquema : __( 'ausente', 'f3base' ),
					'' !== $host ? $host : __( 'ilegível', 'f3base' ),
					$url
				),
			);
		}

		if ( '' === $host ) {
			return array(
				'ok'     => false,
				'host'   => '',
				'motivo' => sprintf(
					/* translators: %s: URL do salto. */
					__( 'o endereço não tem host legível e não há a quem abrir conexão. Nenhum download foi feito. URL: %s', 'f3base' ),
					$url
				),
			);
		}

		return array(
			'ok'     => true,
			'host'   => $host,
			'motivo' => '',
		);
	}

	/**
	 * Concilia a pasta REALMENTE criada com a `pasta_esperada` declarada.
	 *
	 * Zip de código-fonte do GitHub extrai para `<repo>-<branch>`: instalar
	 * `wp-mcp-ultimate-main.zip` cria `wp-mcp-ultimate-main/`, e ativar por
	 * `wp-mcp-ultimate/…` falharia — junto com a checagem `mcp.canal_configurado`,
	 * que procuraria o canal no lugar errado. A pasta vem do RESULTADO do
	 * upgrader, nunca do slug presumido.
	 *
	 * Três ramos, todos vivos: destino livre (move), destino ocupado pela
	 * instalação anterior DESTE artefato (move a anterior para o lado, com
	 * preimagem no journal, e move) e destino ocupado por quem não era nosso
	 * (BLOCKED, nomeando os dois caminhos, sem tocar em diretório algum).
	 *
	 * @param string $observada          Pasta criada, lida do resultado do upgrader.
	 * @param string $esperada           Pasta declarada em `pasta_esperada`.
	 * @param bool   $destino_ja_existia O destino já existia ANTES desta instalação.
	 * @return array{estado:string,final:string,motivo:string}
	 */
	private static function conciliar_pasta( string $observada, string $esperada, bool $destino_ja_existia ): array {
		if ( '' === $esperada ) {
			return array(
				'estado' => 'OK',
				'final'  => $observada,
				'motivo' => sprintf(
					/* translators: %s: pasta observada. */
					__( 'Pasta criada pela instalação: %s (a entrada não declara pasta_esperada, então não há divergência a conciliar).', 'f3base' ),
					'' !== $observada ? $observada : __( 'não informada pelo instalador', 'f3base' )
				),
			);
		}

		if ( '' === $observada ) {
			return array(
				'estado' => 'BLOCKED',
				'final'  => '',
				'motivo' => sprintf(
					/* translators: %s: pasta esperada. */
					__( 'o instalador do WordPress não informou a pasta criada, e presumir o slug é exatamente o defeito que pasta_esperada (%s) existe para impedir: sem saber onde o artefato caiu, a ativação e a conferência do canal procurariam no lugar errado.', 'f3base' ),
					$esperada
				),
			);
		}

		if ( $observada === $esperada ) {
			return array(
				'estado' => 'OK',
				'final'  => $esperada,
				'motivo' => sprintf(
					/* translators: 1: pasta observada, 2: pasta final. */
					__( 'Pasta observada: %1$s; pasta final: %2$s (sem divergência, nada foi renomeado).', 'f3base' ),
					$observada,
					$esperada
				),
			);
		}

		global $wp_filesystem;

		require_once ABSPATH . 'wp-admin/includes/file.php';

		if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
			WP_Filesystem();
		}

		$origem_dir  = WP_PLUGIN_DIR . '/' . $observada;
		$destino_dir = WP_PLUGIN_DIR . '/' . $esperada;

		if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
			return array(
				'estado' => 'BLOCKED',
				'final'  => '',
				'motivo' => sprintf(
					/* translators: 1: caminho de origem, 2: caminho de destino. */
					__( 'filesystem do WordPress indisponível: a pasta criada em %1$s não pôde ser renomeada para %2$s, e nenhum diretório foi tocado.', 'f3base' ),
					$origem_dir,
					$destino_dir
				),
			);
		}

		if ( ! is_dir( $origem_dir ) ) {
			return array(
				'estado' => 'FALHA',
				'final'  => '',
				'motivo' => sprintf(
					/* translators: 1: caminho de origem, 2: caminho de destino. */
					__( 'o instalador informou a pasta %1$s, e ela não existe no disco: nada foi renomeado para %2$s.', 'f3base' ),
					$origem_dir,
					$destino_dir
				),
			);
		}

		$anterior = '';

		if ( is_dir( $destino_dir ) ) {
			if ( ! $destino_ja_existia ) {
				return array(
					'estado' => 'BLOCKED',
					'final'  => '',
					'motivo' => sprintf(
						/* translators: 1: caminho de origem, 2: caminho de destino. */
						__( 'renomeação recusada: a instalação criada em %1$s deveria virar %2$s, e o destino já existe sem ter sido posto ali por esta execução. Sobrescrever seria apagar código de outro dono; nenhum dos dois diretórios foi tocado.', 'f3base' ),
						$origem_dir,
						$destino_dir
					),
				);
			}

			$anterior = self::caminho_do_backup( $destino_dir );

			if ( ! $wp_filesystem->move( $destino_dir, $anterior, true ) ) {
				return array(
					'estado' => 'BLOCKED',
					'final'  => '',
					'motivo' => sprintf(
						/* translators: 1: caminho de destino, 2: caminho da preimagem. */
						__( 'renomeação recusada: o destino %1$s existe, é a instalação anterior deste mesmo artefato, e não foi possível movê-lo para %2$s. Nenhuma escrita sobre código em uso.', 'f3base' ),
						$destino_dir,
						$anterior
					),
				);
			}

			F3Base_Imp_Journal::registrar(
				F3Base_Imp_Journal::TIPO_ARQUIVO,
				$destino_dir,
				array( 'movido_para' => $anterior ),
				array( 'origem' => $origem_dir ),
				array(),
				array(
					'reversivel' => false,
					'motivo'     => sprintf(
						/* translators: %s: caminho da cópia anterior. */
						__( 'instalação anterior preservada em %s antes da renomeação; a volta é operação de operador, fora da promessa automática de rollback.', 'f3base' ),
						$anterior
					),
				)
			);
		}

		if ( ! $wp_filesystem->move( $origem_dir, $destino_dir, true ) ) {
			if ( '' !== $anterior ) {
				$wp_filesystem->move( $anterior, $destino_dir, true );
			}

			return array(
				'estado' => 'FALHA',
				'final'  => '',
				'motivo' => sprintf(
					/* translators: 1: caminho de origem, 2: caminho de destino. */
					__( 'falha ao renomear %1$s para %2$s; o estado anterior do destino foi recolocado.', 'f3base' ),
					$origem_dir,
					$destino_dir
				),
			);
		}

		/*
		 * O diretório mudou de nome DEPOIS do instalador: o cache de plugins do
		 * núcleo precisa cair, ou a ativação seguinte procuraria o arquivo
		 * principal no caminho velho — o mesmo defeito, um passo adiante.
		 */
		if ( ! function_exists( 'wp_clean_plugins_cache' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		wp_clean_plugins_cache( false );

		return array(
			'estado' => 'OK',
			'final'  => $esperada,
			'motivo' => sprintf(
				/* translators: 1: pasta observada, 2: pasta final, 3: destino do diretório anterior. */
				__( 'Pasta observada: %1$s; pasta final: %2$s (renomeada, porque o zip de código-fonte extrai com o nome do repositório e a ativação e a conferência do canal procuram pela pasta final). %3$s', 'f3base' ),
				$observada,
				$esperada,
				'' !== $anterior
					? sprintf(
						/* translators: %s: caminho da instalação anterior. */
						__( 'A instalação anterior ficou preservada em %s.', 'f3base' ),
						$anterior
					)
					: __( 'O destino estava livre.', 'f3base' )
			),
		);
	}

	/**
	 * Suprime o redirecionamento que um plugin recém-ativado registra.
	 *
	 * Chamado depois de TODA ativação de plugin de terceiro, e não só na etapa de
	 * SEO: o plugin registra o assistente dele em `admin_init`, que roda ANTES do
	 * `admin_post_*` do implantador. A chave precisa estar gravada no banco antes
	 * da próxima requisição administrativa — depois já é tarde, e o lote seguinte
	 * volta uma página inteira do wp-admin em vez do JSON.
	 *
	 * O mapa é declarado em `plugins.supressao_onboarding` (slug → lista de
	 * `option.chave` a gravar como `false`). Slug sem entrada no mapa não faz
	 * nada, e isso NÃO é erro: nenhuma lista literal no código decide o que a
	 * configuração declara.
	 *
	 * @param string $slug Slug do plugin recém-ativado.
	 * @return array{estado:string,motivo:string}
	 */
	public static function suprimir_redirecionamento_de_ativacao( string $slug ): array {
		$mapa       = (array) F3Base_Imp_Decisoes::bloco( 'plugins.supressao_onboarding' );
		$declaradas = ( is_array( $mapa ) && isset( $mapa[ $slug ] ) && is_array( $mapa[ $slug ] ) )
			? array_map( 'strval', $mapa[ $slug ] )
			: array();

		if ( array() === $declaradas ) {
			return array(
				'estado' => 'N/A',
				'motivo' => sprintf(
					/* translators: %s: slug do plugin. */
					__( 'Supressão de redirecionamento de ativação: condição de aplicabilidade falsa — %s não tem entrada em plugins.supressao_onboarding, e slug sem entrada no mapa não grava nada.', 'f3base' ),
					$slug
				),
			);
		}

		$por_option  = array();
		$transientes = array();

		foreach ( $declaradas as $caminho ) {
			/*
			 * ASSISTENTE DECIDIDO POR TRANSIENTE — 2.1.0. O `wp-mcp-ultimate`
			 * grava `set_transient( 'wp_mcp_ultimate_activated' )` na ativação e,
			 * no `admin_init` seguinte, redireciona para a própria tela e
			 * apaga o transiente. Option não desarma isso, e foi medido: em toda
			 * instalação limpa a requisição do lote seguinte era sequestrada
			 * uma vez e repetida pelo cliente. A entrada `transiente:<nome>`
			 * declara o nome, lido do código do plugin, e a supressão o apaga
			 * na MESMA unidade que ativou — antes de qualquer `admin_init`
			 * ter a chance de lê-lo. A leitura de volta é `get_transient()`
			 * devolvendo falso.
			 */
			if ( str_starts_with( $caminho, 'transiente:' ) ) {
				$nome_do_transiente = trim( substr( $caminho, strlen( 'transiente:' ) ) );

				if ( '' === $nome_do_transiente ) {
					return array(
						'estado' => 'BLOCKED',
						'motivo' => sprintf(
							/* translators: %s: slug. */
							__( 'Supressão de redirecionamento de ativação recusada: a entrada "transiente:" declarada para %s não traz o nome do transiente, e apagar um transiente sem nome não é possível.', 'f3base' ),
							$slug
						),
					);
				}

				$transientes[] = $nome_do_transiente;
				continue;
			}

			$corte = strpos( $caminho, '.' );

			if ( false === $corte || 0 === $corte || $corte + 1 >= strlen( $caminho ) ) {
				return array(
					'estado' => 'BLOCKED',
					'motivo' => sprintf(
						/* translators: 1: entrada declarada, 2: slug. */
						__( 'Supressão de redirecionamento de ativação recusada: a entrada "%1$s" declarada para %2$s não está na forma option.chave, e gravar sem saber a option de destino seria escrever no escuro.', 'f3base' ),
						$caminho,
						$slug
					),
				);
			}

			$por_option[ substr( $caminho, 0, $corte ) ][ substr( $caminho, $corte + 1 ) ] = false;
		}

		$estado = 'OK';
		$partes = array();

		foreach ( $transientes as $nome_do_transiente ) {
			if ( F3Base_Imp_Gravador::em_simulacao() ) {
				$partes[] = sprintf(
					/* translators: %s: nome do transiente. */
					__( 'transiente %s: modo simulação, não apagado', 'f3base' ),
					$nome_do_transiente
				);
				continue;
			}

			$existia = false !== get_transient( $nome_do_transiente );

			if ( $existia ) {
				delete_transient( $nome_do_transiente );
			}

			$sumiu = false === get_transient( $nome_do_transiente );

			if ( ! $sumiu ) {
				$estado = F3Base_Imp_Relatorio::estado_mais_severo( $estado, 'FALHA' );
			}

			$partes[] = sprintf(
				/* translators: 1: nome do transiente, 2: o que aconteceu. */
				__( 'transiente %1$s: %2$s', 'f3base' ),
				$nome_do_transiente,
				$sumiu
					? ( $existia ? __( 'apagado e conferido na leitura de volta — o assistente do plugin não tem mais o que ler em admin_init', 'f3base' ) : __( 'já não existia: nada a apagar', 'f3base' ) )
					: __( 'CONTINUA EXISTINDO depois de delete_transient(): um cache de objeto pode estar respondendo pelo valor velho, e o redirecionamento do assistente vai acontecer', 'f3base' )
			);
		}

		foreach ( $por_option as $option => $chaves ) {
			$resultado = F3Base_Imp_Gravador::gravar_chaves( (string) $option, $chaves, array( 'plugin' => $slug ) );
			$estado    = F3Base_Imp_Relatorio::estado_mais_severo( $estado, (string) $resultado['estado'] );
			$partes[]  = sprintf(
				/* translators: 1: nome da option, 2: chaves gravadas, 3: mensagem do gravador. */
				__( '%1$s (%2$s): %3$s', 'f3base' ),
				(string) $option,
				implode( ', ', array_keys( $chaves ) ),
				(string) $resultado['motivo']
			);
		}

		return array(
			'estado' => $estado,
			'motivo' => sprintf(
				/* translators: 1: slug, 2: resultado por option. */
				__( 'Supressão de redirecionamento de ativação de %1$s gravada pelo gravador único na MESMA unidade que ativou, e conferida na leitura de volta — %2$s', 'f3base' ),
				$slug,
				implode( ' | ', $partes )
			),
		);
	}

	/**
	 * Instala um plugin embarcado no pacote (o complemento do canal MCP).
	 *
	 * Não há chamada de rede: o artefato é nosso e viaja dentro do bundle.
	 *
	 * @param int $indice Índice em `plugins.embarcados`.
	 * @return array<string,mixed>
	 */
	public static function aplicar_embarcado( int $indice ): array {
		$slug   = (string) F3Base_Imp_Config::obter( 'plugins.embarcados.' . $indice . '.slug', '' );
		$papel  = (string) F3Base_Imp_Config::obter( 'plugins.embarcados.' . $indice . '.papel', '' );
		$origem = (string) F3Base_Imp_Config::obter( 'plugins.embarcados.' . $indice . '.origem', '' );

		if ( 'bundle' !== $origem ) {
			return self::saida(
				'BLOCKED',
				'plugins.embarcado:' . $slug,
				sprintf(
					/* translators: 1: slug, 2: origem declarada. */
					__( 'o artefato %1$s está declarado como embarcado com origem "%2$s", e embarcado só admite origem "bundle": artefato nosso viaja dentro do pacote, sem chamada de rede durante o deploy.', 'f3base' ),
					$slug,
					$origem
				)
			);
		}

		if ( '' === $slug ) {
			return self::saida( 'BLOCKED', 'plugins.embarcado', __( 'entrada de plugin embarcado sem slug declarado.', 'f3base' ) );
		}

		$rotulo = 'plugins.embarcado:' . $slug;
		$zip    = self::zip_embutido( $slug );
		$pasta  = f3base_imp_caminho( $slug );

		if ( '' === $zip && ( '' === $pasta || ! is_dir( $pasta ) ) ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				sprintf(
					/* translators: 1: slug, 2: caminho esperado do zip. */
					__( 'artefato embarcado ausente no pacote: nem %2$s nem a pasta %1$s/ existem. Sem ele, quatro linhas da matriz de alocação não têm via de execução pelo agente.', 'f3base' ),
					$slug,
					'assets/' . $slug . '.zip'
				)
			);
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida(
				'N/A',
				$rotulo,
				sprintf(
					/* translators: 1: slug, 2: papel. */
					__( 'modo simulação: instalaria o artefato embarcado %1$s (papel: %2$s), sem chamada de rede.', 'f3base' ),
					$slug,
					$papel
				)
			);
		}

		$instalada = self::versao_instalada( $slug );
		$mesmo     = self::artefato_identico( WP_PLUGIN_DIR . '/' . $slug, $instalada, $instalada, $zip );

		if ( $mesmo['identico'] ) {
			$ativou    = self::ativar( $slug );
			$supressao = self::suprimir_redirecionamento_de_ativacao( $slug );

			return self::saida(
				F3Base_Imp_Relatorio::estado_mais_severo( $ativou['estado'], $supressao['estado'] ),
				$rotulo,
				sprintf(
					/* translators: 1: slug, 2: motivo da identidade, 3: papel, 4: resultado da ativação, 5: resultado da supressão. */
					__( '%1$s: %2$s Papel: %3$s. %4$s %5$s', 'f3base' ),
					$slug,
					$mesmo['motivo'],
					$papel,
					$ativou['motivo'],
					$supressao['motivo']
				)
			);
		}

		$instalou = '' !== $zip
			? self::instalar_pacote( $zip, '' !== $instalada )
			: self::trocar_diretorio( $pasta, WP_PLUGIN_DIR . '/' . $slug, 'plugin' );

		if ( ! $instalou['ok'] ) {
			return self::saida( 'FALHA', $rotulo, $instalou['motivo'] );
		}

		/*
		 * A MESMA leitura de volta do tema e do site-core. Este chamador tem o
		 * defeito idêntico ao deles — troca de diretório sem passar pelo
		 * upgrader, seguida de `versao_instalada()`, que lê `get_plugins()` do
		 * cache — e é por isso que a invalidação mora no trocador.
		 */
		$versao   = self::versao_instalada( $slug );
		$de_volta = self::leitura_de_volta_do_artefato( 'plugin', $slug, WP_PLUGIN_DIR . '/' . $slug, '' !== $versao );

		if ( ! $de_volta['ok'] ) {
			return self::saida( 'FALHA', $rotulo, $de_volta['motivo'] );
		}

		$ativou    = self::ativar( $slug );
		$supressao = self::suprimir_redirecionamento_de_ativacao( $slug );

		return self::saida(
			F3Base_Imp_Relatorio::estado_mais_severo( $ativou['estado'], $supressao['estado'] ),
			$rotulo,
			sprintf(
				/* translators: 1: slug, 2: versão, 3: papel, 4: resultado da ativação, 5: resultado da supressão. */
				__( '%1$s instalado do bundle na versão %2$s. Papel: %3$s. %4$s %5$s', 'f3base' ),
				$slug,
				$versao,
				$papel,
				$ativou['motivo'],
				$supressao['motivo']
			)
		);
	}

	/**
	 * Instala e ativa o tema que viaja no pacote.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_tema(): array {
		$artefato = self::artefato_do_papel( 'tema' );
		$slug     = $artefato['slug'];
		$rotulo   = 'plugins.tema:' . $slug;

		if ( '' === $slug ) {
			return self::saida( 'BLOCKED', 'plugins.tema', __( 'slug do tema não declarado na configuração.', 'f3base' ) );
		}

		/* FONTE ÚNICA: o artefato que instala é o mesmo que `entrega.tema` prova. */
		$zip   = 'zip' === $artefato['tipo'] ? $artefato['caminho'] : '';
		$pasta = 'diretorio' === $artefato['tipo'] ? $artefato['caminho'] : '';

		if ( '' === $artefato['tipo'] ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				sprintf(
					/* translators: 1: slug do tema, 2: caminhos procurados. */
					__( 'nenhum dos caminhos declarados traz o tema %1$s no pacote: %2$s. Ele não pode ser instalado.', 'f3base' ),
					$slug,
					implode( ', ', $artefato['candidatos'] )
				)
			);
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida( 'N/A', $rotulo, __( 'modo simulação: instalaria o tema do pacote por troca controlada de diretório e o ativaria depois de validado.', 'f3base' ) );
		}

		$destino_tema = trailingslashit( get_theme_root() ) . $slug;
		$versao_tema  = wp_get_theme( $slug )->exists() ? (string) wp_get_theme( $slug )->get( 'Version' ) : '';
		$mesmo        = '' !== $zip
			? self::artefato_identico( $destino_tema, $versao_tema, $versao_tema, $zip )
			: array(
				'identico' => false,
				'motivo'   => __( 'o tema vem da pasta do pacote: a comparação de conteúdo acontece na troca de diretório.', 'f3base' ),
			);

		if ( $mesmo['identico'] && get_stylesheet() === $slug ) {
			return self::saida(
				'OK',
				$rotulo,
				sprintf(
					/* translators: 1: slug do tema, 2: motivo da identidade. */
					__( 'tema %1$s: %2$s Ele continua instalado, validado e ativo.', 'f3base' ),
					$slug,
					$mesmo['motivo']
				)
			);
		}

		$instalou = '' !== $zip
			? self::instalar_pacote( $zip, wp_get_theme( $slug )->exists(), 'tema' )
			: self::trocar_diretorio( $pasta, $destino_tema, 'tema' );

		if ( ! $instalou['ok'] ) {
			return self::saida( 'FALHA', $rotulo, $instalou['motivo'] );
		}

		/*
		 * LEITURA DE VOLTA que mede o DISCO ao lado da API. Diretório ausente e
		 * cache desatualizado são dois fatos diferentes e saem com mensagens
		 * diferentes — a 1.0.15 dizia "não apareceu no disco" sobre um diretório
		 * que estava lá.
		 */
		$tema     = wp_get_theme( $slug );
		$de_volta = self::leitura_de_volta_do_artefato( 'tema', $slug, $destino_tema, $tema->exists() );

		if ( ! $de_volta['ok'] ) {
			return self::saida( 'FALHA', $rotulo, $de_volta['motivo'] );
		}

		$erros = $tema->errors();

		if ( $erros instanceof WP_Error ) {
			return self::saida(
				'FALHA',
				$rotulo,
				sprintf(
					/* translators: %s: mensagem de erro do tema. */
					__( 'o tema instalado não validou e por isso NÃO foi ativado: %s', 'f3base' ),
					$erros->get_error_message()
				)
			);
		}

		if ( get_stylesheet() !== $slug ) {
			F3Base_Imp_Journal::registrar(
				F3Base_Imp_Journal::TIPO_OPTION,
				'tema_ativo',
				get_stylesheet(),
				$slug,
				array(
					'acao'  => 'option.restaurar',
					'nome'  => 'stylesheet',
					'valor' => get_stylesheet(),
				)
			);

			switch_theme( $slug );
		}

		$ativo = get_stylesheet();

		return self::saida(
			$ativo === $slug ? 'OK' : 'FALHA',
			$rotulo,
			$ativo === $slug
				? sprintf(
					/* translators: 1: slug do tema, 2: versão do cabeçalho do style.css. */
					__( 'tema %1$s instalado, validado e ativo na versão %2$s (fonte única: cabeçalho do style.css).', 'f3base' ),
					$slug,
					(string) $tema->get( 'Version' )
				)
				: sprintf(
					/* translators: 1: slug desejado, 2: slug ativo. */
					__( 'a leitura de volta do tema ativo divergiu: desejado %1$s, ativo %2$s.', 'f3base' ),
					$slug,
					$ativo
				)
		);
	}

	/**
	 * Instala e ativa o `site-core` que viaja no pacote.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_site_core(): array {
		/*
		 * O `site-core` É INSTALADO PELO CATÁLOGO, como qualquer outro plugin.
		 *
		 * Antes, esta etapa copiava `fontes/site-core/` para dentro de
		 * `wp-content/plugins/` arquivo por arquivo, e era isso que fazia toda
		 * correção do plugin virar release do implantador: as fontes viajavam
		 * soltas no zip e a versão delas era a do pacote inteiro.
		 *
		 * Agora ele tem release própria e entra pelo mesmo caminho dos outros:
		 * a URL declarada primeiro, e a cópia embutida no zip como reserva. Um
		 * caminho só de instalação é um lugar só onde ela pode falhar.
		 */
		$indice = self::indice_do_papel( 'site-core' );

		if ( $indice < 0 ) {
			return self::saida(
				'BLOCKED',
				'plugins.site_core',
				__( 'Nenhuma entrada do catálogo declara o papel site-core: o plugin do site não tem de onde ser instalado.', 'f3base' )
			);
		}

		$resultado = self::aplicar_instalavel( $indice );

		self::relatar_versao_do_site_core();

		return $resultado;
	}

	/**
	 * A VERSÃO INSTALADA CONFRONTADA COM A QUE ESTE PACOTE TRAZ.
	 *
	 * POR QUE ESTA LINHA EXISTE. O `site-core` é instalado pela URL declarada, e
	 * a cópia embutida no zip só entra quando a URL não responde. Isso é o
	 * desenho certo — a entrega não pode falhar por um endereço que alguém
	 * moveu —, mas ele tem uma consequência que ninguém via: enquanto a versão
	 * publicada naquela URL estiver atrás da que o pacote carrega, TODA
	 * implantação instala a versão velha, com sucesso, sem nada estranho no
	 * relatório. Foi assim que um site rodou por três releases um plugin que
	 * este pacote já tinha corrigido.
	 *
	 * O QUE ELA NÃO DISTINGUE, e é declarado — 2.0.0: dois artefatos com o
	 * MESMO número e bytes diferentes. `version_compare()` não os separa, e
	 * esta linha também não. Quem separa é o DIGESTO: o catálogo declara o
	 * `sha256` do zip publicado, a instalação pela URL o confere antes de
	 * instalar, a reserva passa pela mesma conferência, e a suíte confere que
	 * a reserva embutida É o zip declarado. São dois fatos — "que versão ficou"
	 * e "que bytes ficaram" — e cada um tem a sua linha: esta responde pela
	 * versão, `plugins.instalado:<slug>` responde pelos bytes. Fundi-los aqui
	 * seria medir o mesmo fato em duas linhas, que é o defeito da 1.7.2 pelo
	 * outro lado.
	 *
	 * ESTA É A DERIVAÇÃO ÚNICA DO FATO, desde a 1.7.3. Até a 1.7.2 o mesmo par
	 * de números era medido também por `release.versao_site_core`, no
	 * orquestrador, com regra própria (`===`, que acusava o caso correto de o
	 * site estar à frente) e veredito próprio: numa execução real o fato saiu
	 * em WARN aqui e em FALHA lá. Um fato, uma linha, um veredito — a regra da
	 * decisão 17, aplicada onde ela tinha escapado.
	 *
	 * O SLUG É UM SÓ, e ele sai do resolvedor. Até a 1.7.2 a versão INSTALADA
	 * era lida no slug do catálogo e a EMBARCADA no slug de `site.site_core_slug`
	 * — duas fontes que ninguém cruza. Iguais nesta base, e nada garantia que
	 * continuassem: divergindo, esta linha compararia dois plugins diferentes e
	 * chamaria isso de versão. Quem cobra que o catálogo instalou onde a
	 * configuração declara é `entrega.site_core`, que é o lugar da pergunta.
	 *
	 * @return void
	 */
	public static function relatar_versao_do_site_core(): void {
		$artefato   = self::artefato_do_papel( 'site_core' );
		$instalada  = self::versao_instalada( (string) $artefato['slug'] );
		$embarcada  = self::versao_embarcada_do_site_core();
		$veredito   = self::veredito_da_versao_do_site_core( $instalada, $embarcada, self::endereco_da_reserva( $artefato ) );

		F3Base_Imp_Relatorio::emitir(
			$veredito['estado'],
			'plugins.site_core_versao',
			$veredito['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
				/*
				 * GATE DE RELATO, declarado. Este host PRODUZ a evidência: ele
				 * leu o cabeçalho do plugin instalado e o nome do artefato que
				 * viaja no pacote, agora, aqui. Não é pendência de fase — não
				 * falta navegador, campo nem suíte externa —, e não é gate de
				 * aplicação: o site funciona com a versão que ficou, e promover
				 * a unidade suspenderia `options_site_core`, `formularios` e
				 * `cadencia`, que dependem dela e não têm nada de errado.
				 *
				 * O QUE A FALHA FAZ: derruba o estado da aplicação no
				 * encerramento, e com ele a primeira condição da autodesativação.
				 * É o desfecho certo — um site que ficou com uma versão superada
				 * do plugin, com correções ausentes, não pode ver a ferramenta
				 * de correção sair do ar —, e agora ele é dito por um caminho
				 * que o relatório explica sem se contradizer.
				 */
				'gate'      => 'relato',
				'tela'      => $veredito['curta'],
				'operador'  => $veredito['saida'],
			)
		);
	}

	/**
	 * O ENDEREÇO da cópia embutida, dito de onde o operador consegue alcançá-la.
	 *
	 * O DEFEITO QUE ELA FECHA, medido na 1.7.2: a linha `plugins.site_core_versao`
	 * oferecia duas saídas — publicar o zip no endereço declarado, ou "instalar
	 * a cópia embutida à mão pela tela de plugins" — e a segunda não dizia ONDE
	 * está a cópia. Quem faz o upload do implantador envia o bundle inteiro e
	 * não o extrai; o zip do plugin existe, viaja dentro dele
	 * (`assets/plugins/<slug>-<versão>.zip`, conferido por
	 * `pacote.reserva_identica_ao_avulso`) e fica em disco depois da instalação,
	 * mas uma saída que o leitor não consegue seguir é uma saída que não existe.
	 * A frase passou a carregar o caminho.
	 *
	 * @param array<string,mixed> $artefato Artefato resolvido para o papel `site_core`.
	 * @return string Caminho legível, ou vazio quando não há reserva resolvida.
	 */
	private static function endereco_da_reserva( array $artefato ): string {
		$caminho = (string) ( $artefato['caminho'] ?? '' );

		if ( 'zip' !== (string) ( $artefato['tipo'] ?? '' ) || '' === $caminho ) {
			return '';
		}

		$raiz     = rtrim( str_replace( '\\', '/', F3BASE_IMP_DIR ), '/' ) . '/';
		$caminho  = str_replace( '\\', '/', $caminho );
		$relativo = str_starts_with( $caminho, $raiz ) ? substr( $caminho, strlen( $raiz ) ) : $caminho;
		$pasta    = dirname( plugin_basename( F3BASE_IMP_ARQUIVO ) );

		return 'wp-content/plugins/' . $pasta . '/' . $relativo;
	}

	/**
	 * A versão da RESERVA que este pacote carrega, lida do NOME do artefato.
	 *
	 * O QUE MUDOU NA 1.7.0, e por quê. Até a 1.6.6 esta função lia o cabeçalho
	 * de `fontes/site-core/f3base-site-core.php`, que viajava dentro do bundle.
	 * A fonte do plugin deixou de viajar — o bundle leva só o zip —, e aquele
	 * cabeçalho não chega mais ao site. A versão continua sendo LIDA DE DISCO, e
	 * não digitada: ela sai do nome do artefato que o empacotamento montou,
	 * `assets/plugins/base-site-core-fator3-<versão>.zip`, resolvido pelo MESMO
	 * `artefato_do_papel()` que instala.
	 *
	 * Reserva SEM número no nome devolve vazio, e o veredito diz isso com todas
	 * as letras: é o caso do zip que o OPERADOR embute por decisão própria, em
	 * que o pacote não tem como saber que versão ele contém.
	 *
	 * @return string
	 */
	public static function versao_embarcada_do_site_core(): string {
		$artefato = self::artefato_do_papel( 'site_core' );

		if ( 'zip' !== (string) $artefato['tipo'] || '' === (string) $artefato['caminho'] ) {
			return '';
		}

		$slug = (string) $artefato['slug'];
		$nome = basename( (string) $artefato['caminho'], '.zip' );

		if ( '' === $slug || ! str_starts_with( $nome, $slug . '-' ) ) {
			return '';
		}

		return substr( $nome, strlen( $slug ) + 1 );
	}

	/**
	 * A REGRA, pura: o que dizer sobre as duas versões. DERIVAÇÃO ÚNICA.
	 *
	 * Quatro ramos, e nenhum deles impede a instalação nem suspende unidade
	 * nenhuma: a versão do plugin no site é fato do host, e um pacote que se
	 * recusasse a entregar por causa dela estaria protegendo o processo, não o
	 * site.
	 *
	 * O RAMO "INSTALADA ATRÁS" PASSOU DE WARN PARA FALHA NA 1.7.3, e a mudança
	 * é sobre o que o estado significa. WARN é *"mediu e sobrou achado adverso"*;
	 * FALHA é *"mediu e reprovou"*. Aqui a promessa da entrega — o site fica com
	 * o `site-core` que este pacote carrega — foi medida por leitura de volta do
	 * cabeçalho instalado e NÃO foi cumprida: as correções da versão que o
	 * pacote traz não estão no site. Isso é reprovação.
	 *
	 * E É ELA QUE MANTÉM A FERRAMENTA DE CORREÇÃO NO AR. FALHA derruba o estado
	 * da aplicação para `FALHA_PARCIAL`, e `SUCESSO_APLICACAO` é a primeira das
	 * três condições de `pode_autodesativar()`. Um site que ficou com uma versão
	 * superada do plugin, com correções ausentes, não pode ver o implantador
	 * sair de cena. Antes da 1.7.3 o desfecho era o mesmo, mas pelo caminho
	 * errado: quem derrubava o estado era `release.versao_site_core`, uma
	 * SEGUNDA linha sobre o mesmo fato, declarada como gate de fase — e o
	 * relatório imprimia, na mesma tela, que ela não era somada ao gate e que a
	 * evidência dela "este host não produz".
	 *
	 * OS OUTROS TRÊS RAMOS NÃO MUDARAM, e o de "instalada à frente" é o que
	 * prova que a regra não é uma igualdade: o site com uma versão MAIS NOVA que
	 * a reserva fecha OK, porque este pacote não rebaixa artefato de terceiro.
	 *
	 * @param string $instalada Versão lida do plugin instalado.
	 * @param string $embarcada Versão que este pacote carrega.
	 * @param string $reserva   Endereço legível da cópia embutida, ou vazio.
	 * @return array{estado:string,motivo:string,curta:string,saida:string}
	 */
	public static function veredito_da_versao_do_site_core( string $instalada, string $embarcada, string $reserva = '' ): array {
		if ( '' === $embarcada ) {
			return array(
				'estado'   => F3Base_Imp_Relatorio::WARN,
				'motivo'   => __( 'Não foi possível ler a versão da cópia de reserva do plugin que este pacote carrega: ela sai do NOME do artefato resolvido (assets/plugins/<slug>-<versão>.zip), e o que foi resolvido não traz número no nome — é o caso do zip embutido à mão pelo operador. Sem ela não há com o que comparar a versão instalada, e a comparação é o que revelaria uma instalação presa numa versão anterior.', 'f3base' ),
				'curta'    => __( 'Não deu para conferir a versão do plugin do site.', 'f3base' ),
				'saida'    => __( 'Embutir o zip com o número no nome, ou conferir a versão instalada pela tela de plugins.', 'f3base' ),
			);
		}

		if ( '' === $instalada ) {
			return array(
				'estado'   => F3Base_Imp_Relatorio::NA,
				'motivo'   => sprintf(
					/* translators: %s: versão que o pacote carrega. */
					__( 'condição declarada: nenhum site-core instalado para comparar. Este pacote carrega a versão %s, e a etapa de instalação é quem relata o que aconteceu com ela.', 'f3base' ),
					$embarcada
				),
				'curta'    => '',
				'saida'    => '',
			);
		}

		if ( version_compare( $instalada, $embarcada, '<' ) ) {
			/*
			 * A SEGUNDA SAÍDA PRECISA DO ENDEREÇO. Sem ele a frase mandava
			 * "instalar a cópia embutida à mão" sem dizer onde ela está, e quem
			 * envia o implantador envia o bundle sem abri-lo. Quando o
			 * resolvedor não devolve caminho — reserva ausente —, a saída some
			 * em vez de ser prometida: caminho que não existe é pior que
			 * caminho nenhum.
			 */
			$segunda_saida = '' === $reserva
				? ''
				: sprintf(
					/* translators: %s: caminho da cópia embutida. */
					__( ' A outra saída é instalar a cópia embutida à mão: ela está em %s, tanto no site (baixe-a por FTP ou pelo gerenciador de arquivos da hospedagem) quanto dentro do zip do implantador que você enviou (basta extraí-lo), e entra por Plugins › Adicionar novo › Enviar plugin, substituindo a atual.', 'f3base' ),
					$reserva
				);

			return array(
				'estado'   => F3Base_Imp_Relatorio::FALHA,
				'motivo'   => sprintf(
					/* translators: 1: versão instalada, 2: versão que o pacote carrega, 3: a segunda saída, com o endereço da cópia embutida. */
					__( 'O site ficou com o site-core %1$s, e este pacote carrega a %2$s. O plugin é instalado pela URL declarada no catálogo, e a cópia embutida no zip só é usada quando a URL não responde: enquanto o arquivo publicado naquele endereço estiver atrás, toda implantação instalará a versão anterior com sucesso e sem nada estranho no relatório. As correções que a %2$s traz NÃO estão neste site, e é por isso que esta linha fecha FALHA: a entrega prometeu o plugin que este pacote carrega e entregou outro. A FALHA derruba o estado da aplicação, e é o estado que mantém o implantador no ar — a ferramenta que corrige isto não sai de cena enquanto o site estiver com a versão superada. A saída é publicar o zip da %2$s no endereço declarado e reexecutar.%3$s', 'f3base' ),
					$instalada,
					$embarcada,
					$segunda_saida
				),
				'curta'    => sprintf(
					/* translators: 1: versão instalada, 2: versão que o pacote carrega. */
					__( 'O plugin do site ficou na versão %1$s, e este pacote traz a %2$s.', 'f3base' ),
					$instalada,
					$embarcada
				),
				'saida'    => '' === $reserva
					? __( 'Publicar o zip novo no endereço declarado e executar de novo.', 'f3base' )
					: sprintf(
						/* translators: %s: caminho da cópia embutida. */
						__( 'Publicar o zip novo no endereço declarado e executar de novo; ou enviar à mão, por Plugins › Adicionar novo, a cópia que veio no pacote (%s).', 'f3base' ),
						$reserva
					),
			);
		}

		if ( version_compare( $instalada, $embarcada, '>' ) ) {
			return array(
				'estado'   => F3Base_Imp_Relatorio::OK,
				'motivo'   => sprintf(
					/* translators: 1: versão instalada, 2: versão que o pacote carrega. */
					__( 'O site tem o site-core %1$s, mais novo que a %2$s que este pacote carrega: a instalação veio da URL declarada, que está à frente. Nada foi rebaixado — este pacote não substitui versão mais nova por mais velha.', 'f3base' ),
					$instalada,
					$embarcada
				),
				'curta'    => '',
				'saida'    => '',
			);
		}

		return array(
			'estado'   => F3Base_Imp_Relatorio::OK,
			'motivo'   => sprintf(
				/* translators: %s: versão. */
				__( 'O site-core instalado é a versão %s, a mesma que este pacote carrega.', 'f3base' ),
				$instalada
			),
			'curta'    => '',
			'saida'    => '',
		);
	}

	/**
	 * O ÍNDICE, no catálogo, da entrada que ocupa um papel.
	 *
	 * @param string $papel Papel declarado.
	 * @return int Índice, ou -1 quando nenhuma entrada declara o papel.
	 */
	public static function indice_do_papel( string $papel ): int {
		foreach ( F3Base_Imp_Decisoes::bloco( 'plugins.instalaveis' ) as $indice => $entrada ) {
			unset( $entrada );

			if ( $papel === self::campo_declarado( 'plugins.instalaveis', $indice, 'papel' ) ) {
				return (int) $indice;
			}
		}

		return -1;
	}

	/**
	 * Nomes de plugin e tema que ESTE pacote instala, com a procedência de cada um.
	 *
	 * Serve para uma coisa só: provar propriedade antes de tocar num diretório.
	 * Nome parecido não prova nada — é a mesma regra de "slug igual não prova
	 * propriedade" que já governa a reconciliação de pasta. O nome sai do
	 * cabeçalho do artefato que viaja no pacote (fonte da verdade que não depende
	 * do que já está instalado) e, para plugin de terceiro declarado, do cabeçalho
	 * do que está no disco com aquele slug.
	 *
	 * @return array<string,string> Nome do cabeçalho => procedência declarada.
	 */
	private static function nomes_de_artefatos_do_pacote(): array {
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$nomes = array();

		/* O implantador é nosso e mora em wp-content/plugins como qualquer outro. */
		$dados = get_plugin_data( F3BASE_IMP_ARQUIVO, false, false );

		if ( is_array( $dados ) && '' !== (string) ( $dados['Name'] ?? '' ) ) {
			$nomes[ (string) $dados['Name'] ] = __( 'implantador do pacote', 'f3base' );
		}

		/*
		 * O PLUGIN DO SITE NÃO ENTRA MAIS POR AQUI, e a remoção é da 1.7.0.
		 *
		 * Até a 1.6.6 este trecho lia o cabeçalho da FONTE do plugin, que viajava
		 * dentro do bundle, para saber o nome dele. A fonte deixou de viajar — o
		 * bundle leva só o zip —, e o trecho passaria a resolver para um caminho
		 * inexistente e a não fazer nada, em silêncio. Ele foi REMOVIDO e não
		 * apontado para outro lugar: o nome do plugin do site chega ao censo pelo
		 * laço de `plugins.instalaveis` logo abaixo, que lê o cabeçalho do que
		 * está INSTALADO com aquele slug — exatamente como para qualquer outra
		 * entrada do catálogo, que é o que ele agora é.
		 */

		/* Tema: o backup dele não cai em wp-content/plugins, mas o nome entra do mesmo jeito. */
		$slug_tema = (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' );

		if ( '' !== $slug_tema ) {
			$tema = wp_get_theme( $slug_tema );

			if ( $tema->exists() && '' !== (string) $tema->get( 'Name' ) ) {
				$nomes[ (string) $tema->get( 'Name' ) ] = __( 'tema do pacote', 'f3base' );
			}
		}

		/* Plugins declarados: o nome vem do cabeçalho do que está instalado com aquele slug. */
		foreach ( array( 'plugins.instalaveis', 'plugins.embarcados' ) as $lista ) {
			foreach ( self::entradas_declaradas( $lista ) as $indice => $entrada ) {
				unset( $entrada );

				$slug = self::campo_declarado( $lista, $indice, 'slug' );

				if ( '' === $slug ) {
					continue;
				}

				$arquivo = self::arquivo_principal( $slug );

				if ( '' === $arquivo ) {
					continue;
				}

				$dados = get_plugin_data( WP_PLUGIN_DIR . '/' . $arquivo, false, false );

				if ( is_array( $dados ) && '' !== (string) ( $dados['Name'] ?? '' ) ) {
					$nomes[ (string) $dados['Name'] ] = sprintf(
						/* translators: %s: slug declarado na configuração. */
						__( 'plugin declarado %s', 'f3base' ),
						$slug
					);
				}
			}
		}

		return $nomes;
	}

	/**
	 * Cabeçalhos de plugin encontrados dentro de um diretório de `WP_PLUGIN_DIR`.
	 *
	 * Usa `get_plugins( '/<dir>' )` de propósito: é exatamente a função cujo
	 * comportamento produziu o defeito, e ler o diretório com ela é ler o que o
	 * WordPress lê — não uma segunda noção nossa de "o que tem ali dentro".
	 *
	 * @param string $dir Nome do diretório, relativo a `WP_PLUGIN_DIR`.
	 * @return array<string,string> arquivo relativo ao diretório => Name do cabeçalho.
	 */
	private static function cabecalhos_do_diretorio( string $dir ): array {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$saida = array();

		foreach ( get_plugins( '/' . $dir ) as $arquivo => $dados ) {
			$nome = is_array( $dados ) ? (string) ( $dados['Name'] ?? '' ) : '';

			if ( '' !== $nome ) {
				$saida[ (string) $arquivo ] = $nome;
			}
		}

		return $saida;
	}

	/**
	 * Quantos órfãos a migração ocultou NESTA execução.
	 *
	 * Lido do journal, que já responde por uma execução só — nem de uma estática
	 * (cada lote é uma requisição própria e a estática morre com ela) nem de uma
	 * option nova (o registro da mutação já existe e duplicá-lo criaria duas
	 * fontes para o mesmo fato).
	 *
	 * @return int
	 */
	public static function orfaos_ocultos_nesta_execucao(): int {
		$quantos = 0;

		foreach ( F3Base_Imp_Journal::entradas() as $entrada ) {
			$inversa = ( is_array( $entrada ) && isset( $entrada['inversa'] ) && is_array( $entrada['inversa'] ) )
				? $entrada['inversa']
				: array();

			if ( self::INVERSA_RENOMEAR !== (string) ( $inversa['acao'] ?? '' ) ) {
				continue;
			}

			if ( 'orfaos_anteriores' === (string) ( $inversa['migracao'] ?? '' ) ) {
				$quantos++;
			}
		}

		return $quantos;
	}

	/**
	 * MIGRAÇÃO: oculta o órfão de backup criado antes da correção do ponto.
	 *
	 * O defeito que esta unidade existe para fechar foi medido na terceira
	 * execução real. A correção do ponto vale para o backup NOVO; o diretório
	 * criado ANTES dela continua em `wp-content/plugins/<slug>-f3base-anterior-<ts>`
	 * e o WordPress continua o listando como plugin. Na tela do usuário aparecem
	 * dois "Base Site Core Fator3" 1.0.0, com a mesma descrição, um com "Desativar" e
	 * outro com "Ativar | Excluir" — e o usuário lê isso como uma substituição que
	 * não aconteceu. O desenho preserva a instalação anterior, mas preservar não
	 * é a mesma coisa que deixar instalável.
	 *
	 * Quatro regras, e nenhuma delas é opcional:
	 *
	 * - **Propriedade provada antes de tocar.** O diretório precisa conter um
	 *   `.php` com `Plugin Name:` que bata com um artefato deste pacote. Nome de
	 *   diretório parecido NÃO prova propriedade; quem não passa é relatado e não
	 *   é tocado.
	 * - **Diretório ATIVO não é renomeado.** Renomear plugin ativo derruba o
	 *   plugin no meio da requisição seguinte. Sai WARN nomeando o diretório, e a
	 *   saída é o operador desativar e reexecutar.
	 * - **Nunca apaga.** Renomear é reversível e basta: `get_plugins()` pula tudo
	 *   que começa com ponto. Apagar seria irreversível para ganhar exatamente
	 *   nada.
	 * - **Idempotente por construção.** Depois de uma passagem não existe mais
	 *   órfão sem ponto, e a unidade fecha OK dizendo isso e quantos já estão
	 *   ocultos. Emite nos DOIS ramos.
	 *
	 * @return array<string,mixed>
	 */
	public static function migrar_orfaos_anteriores(): array {
		$rotulo = 'plugins.orfaos_anteriores';

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$ocultos    = self::diretorios_ocultos();
		$candidatos = array();

		if ( is_dir( WP_PLUGIN_DIR ) ) {
			foreach ( (array) scandir( WP_PLUGIN_DIR ) as $nome ) {
				$nome = (string) $nome;

				if ( '.' === $nome || '..' === $nome || str_starts_with( $nome, '.' ) ) {
					continue;
				}

				if ( ! str_contains( $nome, self::MARCA_ANTERIOR ) ) {
					continue;
				}

				if ( is_dir( WP_PLUGIN_DIR . '/' . $nome ) ) {
					$candidatos[] = $nome;
				}
			}
		}

		sort( $candidatos );

		if ( array() === $candidatos ) {
			return self::saida(
				'OK',
				$rotulo,
				sprintf(
					/* translators: 1: quantidade de diretórios já ocultos, 2: nomes deles. */
					__( 'nenhum órfão sem ponto encontrado em wp-content/plugins (%1$d diretório(s) com ponto já ocultos: %2$s). Nada foi renomeado e nada foi apagado.', 'f3base' ),
					count( $ocultos ),
					array() === $ocultos ? __( 'nenhum', 'f3base' ) : implode( ', ', $ocultos )
				)
			);
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida(
				'N/A',
				$rotulo,
				sprintf(
					/* translators: 1: quantidade de candidatos, 2: nomes deles. */
					__( 'modo simulação: %1$d diretório(s) com a marca de backup e sem ponto seriam examinados e, com propriedade provada e inativos, renomeados para a forma oculta: %2$s. Nenhuma escrita.', 'f3base' ),
					count( $candidatos ),
					implode( ', ', $candidatos )
				)
			);
		}

		global $wp_filesystem;

		require_once ABSPATH . 'wp-admin/includes/file.php';

		if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
			WP_Filesystem();
		}

		if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				sprintf(
					/* translators: 1: quantidade de candidatos, 2: nomes deles. */
					__( 'pré-condição ausente: filesystem do WordPress indisponível, e nenhuma renomeação é segura sem ele. %1$d órfão(s) continuam visíveis como plugin: %2$s.', 'f3base' ),
					count( $candidatos ),
					implode( ', ', $candidatos )
				)
			);
		}

		$nossos     = self::nomes_de_artefatos_do_pacote();
		$estado     = 'OK';
		$ocultados  = array();
		$intocados  = array();
		$ativos     = array();
		$falharam   = array();

		foreach ( $candidatos as $dir ) {
			$cabecalhos = self::cabecalhos_do_diretorio( $dir );
			$prova      = '';
			$arquivos   = array();

			foreach ( $cabecalhos as $arquivo => $nome ) {
				if ( isset( $nossos[ $nome ] ) ) {
					$prova      = $nome;
					$arquivos[] = (string) $arquivo;
				}
			}

			if ( '' === $prova ) {
				$intocados[] = sprintf(
					/* translators: 1: diretório, 2: cabeçalhos encontrados. */
					__( '%1$s (cabeçalho encontrado: %2$s — não bate com nenhum artefato deste pacote, e nome parecido não prova propriedade)', 'f3base' ),
					$dir,
					array() === $cabecalhos ? __( 'nenhum', 'f3base' ) : implode( ', ', $cabecalhos )
				);
				$estado      = F3Base_Imp_Relatorio::estado_mais_severo( $estado, 'WARN' );
				continue;
			}

			$ativo = '';

			foreach ( $arquivos as $arquivo ) {
				if ( is_plugin_active( $dir . '/' . $arquivo ) ) {
					$ativo = $arquivo;
					break;
				}
			}

			if ( '' !== $ativo ) {
				$ativos[] = sprintf(
					/* translators: 1: diretório, 2: arquivo principal ativo. */
					__( '%1$s (ativo por %2$s)', 'f3base' ),
					$dir,
					$ativo
				);
				$estado   = F3Base_Imp_Relatorio::estado_mais_severo( $estado, 'WARN' );
				continue;
			}

			$antigo = WP_PLUGIN_DIR . '/' . $dir;
			$novo   = self::caminho_do_backup( $antigo );

			if ( ! $wp_filesystem->move( $antigo, $novo, false ) ) {
				$falharam[] = $dir;
				$estado     = F3Base_Imp_Relatorio::estado_mais_severo( $estado, 'FALHA' );
				continue;
			}

			F3Base_Imp_Journal::registrar(
				F3Base_Imp_Journal::TIPO_ARQUIVO,
				$antigo,
				array( 'diretorio' => $antigo ),
				array( 'diretorio' => $novo ),
				array(
					'acao'     => self::INVERSA_RENOMEAR,
					'de'       => $novo,
					'para'     => $antigo,
					'migracao' => 'orfaos_anteriores',
				),
				array(
					'reversivel' => true,
					'motivo'     => sprintf(
						/* translators: 1: caminho antigo, 2: caminho novo, 3: nome do cabeçalho que provou a propriedade. */
						__( 'órfão de backup ocultado: %1$s passou a %2$s. Propriedade provada pelo cabeçalho "%3$s". O conteúdo não foi tocado e a reversão é a renomeação de volta.', 'f3base' ),
						$antigo,
						$novo,
						$prova
					),
				)
			);

			$ocultados[] = sprintf(
				/* translators: 1: nome antigo, 2: nome novo, 3: cabeçalho que provou a propriedade. */
				__( '%1$s → %2$s (propriedade provada pelo cabeçalho "%3$s")', 'f3base' ),
				$dir,
				basename( $novo ),
				$prova
			);
		}

		if ( array() !== $ocultados ) {
			/*
			 * O diretório mudou de nome: a lista de plugins em cache precisa cair,
			 * ou a etapa seguinte ainda leria o órfão como plugin instalado — o
			 * mesmo defeito, um passo adiante.
			 */
			wp_clean_plugins_cache( false );
		}

		$partes = array();

		$partes[] = sprintf(
			/* translators: 1: quantidade ocultada, 2: lista nomeada. */
			__( '%1$d órfão(s) ocultados nesta execução: %2$s.', 'f3base' ),
			count( $ocultados ),
			array() === $ocultados ? __( 'nenhum', 'f3base' ) : implode( '; ', $ocultados )
		);

		if ( array() !== $ativos ) {
			$partes[] = sprintf(
				/* translators: %s: diretórios ativos. */
				__( 'NÃO renomeados por estarem ATIVOS: %s. Renomear o diretório de um plugin ativo derruba o plugin na requisição seguinte; desative-o na tela de plugins e reexecute.', 'f3base' ),
				implode( ', ', $ativos )
			);
		}

		if ( array() !== $intocados ) {
			$partes[] = sprintf(
				/* translators: %s: diretórios relatados. */
				__( 'RELATADOS e não tocados por falta de prova de propriedade: %s.', 'f3base' ),
				implode( ', ', $intocados )
			);
		}

		if ( array() !== $falharam ) {
			$partes[] = sprintf(
				/* translators: %s: diretórios cuja renomeação falhou. */
				__( 'falha ao renomear: %s. Nenhum conteúdo foi apagado.', 'f3base' ),
				implode( ', ', $falharam )
			);
		}

		$partes[] = sprintf(
			/* translators: %d: diretórios que já começavam com ponto. */
			__( 'Já ocultos antes desta unidade: %d.', 'f3base' ),
			count( $ocultos )
		);

		return self::saida( $estado, $rotulo, implode( ' ', $partes ) );
	}

	/**
	 * Diretórios de `wp-content/plugins` que começam com ponto.
	 *
	 * É onde as cópias preservadas por `caminho_do_backup()` moram. Eles NÃO são
	 * plugins e não entram na atualização automática — mas a contagem sai no
	 * relatório, porque "ignorei em silêncio" e "não havia nada" são coisas
	 * diferentes e o operador precisa distinguir as duas.
	 *
	 * @return array<int,string> Nomes dos diretórios ignorados, ordenados.
	 */
	private static function diretorios_ocultos(): array {
		$saida = array();

		if ( ! is_dir( WP_PLUGIN_DIR ) ) {
			return $saida;
		}

		foreach ( (array) scandir( WP_PLUGIN_DIR ) as $nome ) {
			$nome = (string) $nome;

			if ( '.' === $nome || '..' === $nome || ! str_starts_with( $nome, '.' ) ) {
				continue;
			}

			if ( is_dir( WP_PLUGIN_DIR . '/' . $nome ) ) {
				$saida[] = $nome;
			}
		}

		sort( $saida );

		return $saida;
	}

	/**
	 * Liga a atualização automática de TODO plugin instalado.
	 *
	 * Confere por leitura de volta a LISTA, não a option em bloco: quem falta sai
	 * pelo nome. Contagem sem nomes não responde à pergunta que o operador faz.
	 *
	 * DIRETÓRIO QUE COMEÇA COM PONTO FICA DE FORA, e a quantidade sai nomeada na
	 * linha: ali moram as cópias preservadas da instalação anterior, que não são
	 * código em uso. A filtragem é explícita mesmo com `get_plugins()` já pulando
	 * o ponto — depender do comportamento do núcleo para uma regra nossa é como
	 * não ter a regra.
	 *
	 * @return array<string,mixed>
	 */
	public static function ligar_autoupdate(): array {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$ocultos    = self::diretorios_ocultos();
		$instalados = array();

		foreach ( array_keys( get_plugins() ) as $arquivo_instalado ) {
			$arquivo_instalado = (string) $arquivo_instalado;

			if ( str_starts_with( ltrim( $arquivo_instalado, '/' ), '.' ) ) {
				continue;
			}

			$instalados[] = $arquivo_instalado;
		}

		$atual      = get_option( self::OPTION_AUTOUPDATE, array() );
		$atual      = is_array( $atual ) ? array_map( 'strval', $atual ) : array();

		$desejado = array_values( array_unique( array_merge( $atual, array_map( 'strval', $instalados ) ) ) );

		$resultado = F3Base_Imp_Gravador::gravar( self::OPTION_AUTOUPDATE, $desejado, array( 'autoload' => true ) );

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			/*
			 * CHECAGEM CONDICIONAL FECHA N/A COM A CONDIÇÃO DECLARADA, NUNCA
			 * SOME. A linha do caminho de atualização nasce depois deste retorno, e
			 * emissão ela desapareceria do relatório em modo simulação —
			 * indistinguível de checagem esquecida.
			 */
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'plugins.autoupdate_caminho',
				sprintf(
					/* translators: %d: quantidade de plugins instalados. */
					__( 'condição de aplicabilidade falsa: modo simulação. A flag não é gravada e nada é relido, então o caminho de atualização dos %d plugin(s) instalado(s) não é classificado nesta execução.', 'f3base' ),
					count( $instalados )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'local',
				)
			);

			return self::saida(
				'N/A',
				'plugins.autoupdate_conforme_politica',
				sprintf(
					/* translators: 1: quantidade de plugins, 2: quantidade de diretórios ignorados. */
					__( 'modo simulação: ligaria a atualização automática dos %1$d plugins instalados, e deixaria de fora %2$d diretório(s) começando com ponto.', 'f3base' ),
					count( $instalados ),
					count( $ocultos )
				)
			);
		}

		$lido     = get_option( self::OPTION_AUTOUPDATE, array() );
		$lido     = is_array( $lido ) ? array_map( 'strval', $lido ) : array();
		$faltam   = array();
		$nomes    = array();
		$slugs    = array();
		$arquivos = array();

		foreach ( $instalados as $arquivo ) {
			$arquivo = (string) $arquivo;
			$slug    = F3Base_Imp_Preflight::slug_de( $arquivo );
			$versao  = self::versao_instalada( $slug );
			$nomes[] = sprintf( '%s %s', $slug, '' !== $versao ? $versao : __( '(versão não legível)', 'f3base' ) );
			$slugs[] = $slug;

			$arquivos[ $slug ] = $arquivo;

			if ( ! in_array( $arquivo, $lido, true ) ) {
				$faltam[] = $slug;
			}
		}

		/*
		 * FLAG LIGADA E CAMINHO DE ATUALIZAÇÃO SAEM SEPARADOS, em duas linhas. A
		 * primeira é leitura de volta da option e sempre foi; a segunda existe
		 * porque o relatório da 1.0.17 dizia "atualização automática ligada"
		 * sobre nove plugins sem dizer por onde cada um seria atualizado. A
		 * política do usuário fica onde está: ligar a flag para todo plugin
		 * instalado continua sendo a regra.
		 *
		 * A MEDIÇÃO LOCAL ENTRA NA 1.1.7 e é ela que tira o BLOCKED permanente:
		 * o cabeçalho `Update URI` de cada plugin é lido do disco e o filtro
		 * `update_plugins_{host}` é conferido com `has_filter()`, sem rede. O
		 * que era "depende de medição por rede que este host não fez" — limite
		 * da medição, e não pré-condição ausente — virou descrição dentro do
		 * ramo OK, e sobrou UM achado adverso: o artefato que aponta Update URI
		 * para host de terceiro sem filtro que responda por ele.
		 */
		$caminho = self::veredito_do_caminho(
			self::caminhos_declarados( $slugs, self::atualizadores_medidos( $arquivos ) )
		);

		F3Base_Imp_Relatorio::emitir(
			$caminho['estado'],
			'plugins.autoupdate_caminho',
			$caminho['motivo'],
			array(
				'evidencia' => F3Base_Imp_Relatorio::BLOCKED === $caminho['estado'] ? 'pendencia-externa' : 'medida',
				'fase'      => 'local',
			)
		);

		$ignorados = sprintf(
			/* translators: 1: quantidade de diretórios ignorados, 2: nomes dos diretórios. */
			_n(
				'%1$d diretório começando com ponto ficou fora da etapa (%2$s): ali mora a cópia preservada da instalação anterior, que não é código em uso.',
				'%1$d diretórios começando com ponto ficaram fora da etapa (%2$s): ali moram as cópias preservadas de instalações anteriores, que não são código em uso.',
				count( $ocultos ),
				'f3base'
			),
			count( $ocultos ),
			array() === $ocultos ? __( 'nenhum', 'f3base' ) : implode( ', ', $ocultos )
		);

		/*
		 * Quantos DESSES a migração ocultou agora. "Ficaram de fora" e "passaram
		 * a ficar de fora nesta execução" são fatos diferentes, e o inventário de
		 * saída precisa dos dois: sem o segundo, o operador não consegue ligar o
		 * plugin duplicado que ele viu na tela ao que o implantador fez com ele.
		 */
		$migrados  = self::orfaos_ocultos_nesta_execucao();
		$ignorados = $ignorados . ' ' . sprintf(
			/* translators: %d: órfãos ocultados pela unidade de migração nesta execução. */
			_n(
				'Destes, %d foi ocultado nesta execução pela unidade plugins.orfaos_anteriores.',
				'Destes, %d foram ocultados nesta execução pela unidade plugins.orfaos_anteriores.',
				$migrados,
				'f3base'
			),
			$migrados
		);

		if ( array() !== $faltam ) {
			return self::saida(
				'FALHA',
				'plugins.autoupdate_conforme_politica',
				sprintf(
					/* translators: 1: lista de slugs faltantes, 2: motivo do gravador, 3: diretórios ignorados. */
					__( 'a leitura de volta de auto_update_plugins não encontrou: %1$s. %2$s %3$s', 'f3base' ),
					implode( ', ', $faltam ),
					$resultado['motivo'],
					$ignorados
				)
			);
		}

		return self::saida(
			'OK',
			'plugins.autoupdate_conforme_politica',
			sprintf(
				/* translators: 1: lista nomeada de plugins e versões, 2: diretórios ignorados, 3: ressalva do caminho de atualização. */
				__( 'atualização automática ligada e conferida na leitura de volta para: %1$s. %2$s %3$s', 'f3base' ),
				implode( '; ', $nomes ),
				$ignorados,
				__( 'O QUE ESTA LINHA MEDE, e só: a FLAG está ligada no banco, lida de volta plugin a plugin. Flag ligada não é atualização que acontece — por onde o núcleo procuraria a atualização de cada um é outra pergunta, medida no cabeçalho Update URI, e ela sai em plugins.autoupdate_caminho.', 'f3base' )
			)
		);
	}

	/**
	 * O CABEÇALHO `Update URI` de cada plugin instalado, medido LOCALMENTE.
	 *
	 * Esta é a medição que faltava. Antes dela, a linha do caminho só olhava a
	 * CONFIGURAÇÃO — qual origem o pacote declara para cada slug — e classificava
	 * tudo o que dependesse de rede como pendência; o resultado era BLOCKED em
	 * toda execução, com nove plugins, sem que nada estivesse errado.
	 *
	 * O que decide de fato é o NÚCLEO DO WORDPRESS, e a regra dele é local:
	 *
	 * - **sem `Update URI`**: o núcleo pergunta ao WordPress.org pelo slug;
	 * - **`Update URI` de host `wordpress.org` ou `w.org`**: quem responde é o
	 *   WordPress.org;
	 * - **`Update URI` de QUALQUER outro host**: o núcleo NÃO consulta o .org e
	 *   despacha `update_plugins_{$hostname}`. Sem esse filtro registrado, a flag
	 *   ligada não alcança nada — e `has_filter()` responde isso aqui, sem rede.
	 *
	 * @param array<string,string> $arquivos Slug => arquivo principal do plugin.
	 * @return array<string,array{update_uri:string,host:string,gancho:string,filtro:bool}>
	 */
	public static function atualizadores_medidos( array $arquivos ): array {
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$saida = array();

		foreach ( $arquivos as $slug => $arquivo ) {
			$slug    = (string) $slug;
			$caminho = defined( 'WP_PLUGIN_DIR' ) ? WP_PLUGIN_DIR . '/' . (string) $arquivo : '';
			$dados   = ( '' !== $caminho && is_readable( $caminho ) ) ? get_plugin_data( $caminho, false, false ) : array();
			$uri     = isset( $dados['UpdateURI'] ) ? trim( (string) $dados['UpdateURI'] ) : '';
			$host    = '' === $uri ? '' : (string) ( wp_parse_url( $uri, PHP_URL_HOST ) ?? '' );
			$gancho  = '' === $host ? '' : 'update_plugins_' . $host;

			$saida[ $slug ] = array(
				'update_uri' => $uri,
				'host'       => $host,
				'gancho'     => $gancho,
				'filtro'     => '' !== $gancho && false !== has_filter( $gancho ),
			);
		}

		return $saida;
	}

	/**
	 * CAMINHO DE ATUALIZAÇÃO de cada slug: o observado contra o DECLARADO.
	 *
	 * A pergunta desta função mudou na 1.1.7, e é essa mudança que tira o
	 * BLOCKED permanente do relatório. Ela era *"existe fonte alcançável?"* e
	 * respondia "não sei, isso exige rede" para metade dos plugins — pendência
	 * que ninguém podia resolver, saindo em toda execução, para sempre.
	 *
	 * Ela passa a ser: **o caminho de atualização observado corresponde ao
	 * DECLARADO?** E as classes esperadas são todas comportamento declarado
	 * pelo próprio pacote, para o qual ninguém tem ação a tomar:
	 *
	 * - `artefato-do-pacote` — o tema, o site-core e o próprio implantador. A
	 *   atualização deles é release NOSSA, por upload com sobrescrita. É o
	 *   desenho, não uma falta.
	 * - `upload-do-fornecedor` — origem `url` ou `bundle` declarada na
	 *   configuração: o artefato desce de uma URL nossa ou viaja dentro do
	 *   pacote, e a atualização é release do fornecedor, por upload.
	 * - `wordpress-org` — declarados `wordpress.org`, operacionais da hospedagem
	 *   e instalados por fora, todos SEM `Update URI` conflitante: para estes o
	 *   núcleo consulta o WordPress.org pelo slug. O que esta linha afirma é o
	 *   caminho, e não que a consulta respondeu — dizer o segundo seria afirmar
	 *   mais do que ela mediu.
	 * - `atualizador-do-fornecedor` — `Update URI` para host de terceiro COM o
	 *   filtro `update_plugins_{host}` registrado: o fornecedor traz o próprio
	 *   atualizador, e ele está de pé neste site.
	 * - `sem-consulta-declarada` — `Update URI` presente e sem host legível (o
	 *   valor `false` do núcleo, por exemplo): o próprio artefato desliga a
	 *   consulta. Declaração dele, e não pendência nossa.
	 *
	 * E SOBRA UM ÚNICO ACHADO ADVERSO, que é o que a flag ligada engana:
	 * `promessa-quebrada` — `Update URI` para host de terceiro e NENHUM filtro
	 * `update_plugins_{host}` registrado. Aí o núcleo não pergunta ao .org, o
	 * fornecedor não respondeu ao gancho, e a atualização automática não alcança
	 * o plugin apesar da flag.
	 *
	 * A MEDIÇÃO VEM POR PARÂMETRO de propósito: esta função é pura, e é por isso
	 * que ela tem teto e piso em `plugins.autoupdate_caminho_separado`. Quem
	 * toca no WordPress é `atualizadores_medidos()`.
	 *
	 * @param array<int,string>                                                                   $slugs         Slugs instalados.
	 * @param array<string,array{update_uri:string,host:string,gancho:string,filtro:bool}>        $atualizadores Cabeçalho medido por slug.
	 * @return array<string,array{classe:string,fonte:string}>
	 */
	public static function caminhos_declarados( array $slugs, array $atualizadores = array() ): array {
		$declarado = array();

		foreach ( array( 'plugins.instalaveis', 'plugins.embarcados' ) as $lista ) {
			foreach ( self::entradas_declaradas( $lista ) as $indice => $entrada ) {
				unset( $entrada );

				$slug = self::campo_declarado( $lista, $indice, 'slug' );

				if ( '' !== $slug ) {
					$declarado[ $slug ] = self::campo_declarado( $lista, $indice, 'origem' );
				}
			}
		}

		$operacionais = array();

		foreach ( F3Base_Imp_Projeto::lista( 'plugins_operacionais' ) as $indice => $entrada ) {
			unset( $entrada );

			$slug = (string) F3Base_Imp_Projeto::obter( 'plugins_operacionais.' . $indice . '.slug', '' );

			if ( '' !== $slug ) {
				$operacionais[ $slug ] = (string) F3Base_Imp_Projeto::obter( 'plugins_operacionais.' . $indice . '.responsavel', '' );
			}
		}

		$do_pacote = array();

		foreach ( F3Base_Imp_Preflight::artefatos_do_pacote() as $artefato ) {
			$do_pacote[ (string) $artefato['slug'] ] = (string) $artefato['papel'];
		}

		$saida = array();

		foreach ( $slugs as $slug ) {
			$slug = (string) $slug;

			$uri    = (string) ( $atualizadores[ $slug ]['update_uri'] ?? '' );
			$host   = (string) ( $atualizadores[ $slug ]['host'] ?? '' );
			$gancho = (string) ( $atualizadores[ $slug ]['gancho'] ?? '' );
			$filtro = (bool) ( $atualizadores[ $slug ]['filtro'] ?? false );

			/*
			 * O CABEÇALHO MEDIDO DECIDE ANTES DA ORIGEM DECLARADA, porque é ele
			 * que o núcleo obedece: com `Update URI` de terceiro, o WordPress
			 * não consulta o .org — o que a configuração declara sobre a origem
			 * do artefato deixa de governar o caminho da atualização.
			 */
			if ( '' !== $uri && '' !== $host && ! in_array( $host, array( 'wordpress.org', 'w.org' ), true ) ) {
				$saida[ $slug ] = $filtro
					? array(
						'classe' => 'atualizador-do-fornecedor',
						'fonte'  => sprintf(
							/* translators: 1: Update URI declarado, 2: host, 3: nome do gancho. */
							__( 'Update URI "%1$s" aponta para o host de terceiro %2$s, e o filtro %3$s ESTÁ registrado neste site: quem responde pela atualização é o atualizador do próprio fornecedor, e ele está de pé', 'f3base' ),
							$uri,
							$host,
							$gancho
						),
					)
					: array(
						'classe' => 'promessa-quebrada',
						'fonte'  => sprintf(
							/* translators: 1: Update URI declarado, 2: host, 3: nome do gancho. */
							__( 'Update URI "%1$s" aponta para o host de terceiro %2$s e NENHUM filtro %3$s está registrado neste site: o núcleo não consulta o WordPress.org para este plugin — o cabeçalho o tira da consulta por slug — e não há quem responda ao gancho, então a flag ligada não alcança nada', 'f3base' ),
							$uri,
							$host,
							$gancho
						),
					);
				continue;
			}

			if ( '' !== $uri && '' === $host ) {
				$saida[ $slug ] = array(
					'classe' => 'sem-consulta-declarada',
					'fonte'  => sprintf(
						/* translators: %s: valor do cabeçalho Update URI. */
						__( 'Update URI "%s" não tem host legível — é assim que um artefato DESLIGA a consulta de atualização (o valor "false" do núcleo): o WordPress não pergunta ao WordPress.org nem despacha filtro nenhum. É declaração do próprio artefato, e a atualização dele é por upload', 'f3base' ),
						$uri
					),
				);
				continue;
			}

			if ( isset( $do_pacote[ $slug ] ) ) {
				$saida[ $slug ] = array(
					'classe' => 'artefato-do-pacote',
					'fonte'  => sprintf(
						/* translators: %s: papel do artefato no pacote. */
						__( 'artefato deste pacote (%s): a atualização dele é release NOSSA, por upload com sobrescrita — é o desenho declarado, e o atualizador do WordPress não participa dele', 'f3base' ),
						$do_pacote[ $slug ]
					),
				);
				continue;
			}

			$origem = $declarado[ $slug ] ?? '';

			if ( 'url' === $origem || 'bundle' === $origem ) {
				$saida[ $slug ] = array(
					'classe' => 'upload-do-fornecedor',
					'fonte'  => sprintf(
						/* translators: %s: origem declarada na configuração. */
						__( 'origem "%s" DECLARADA no catálogo: o artefato desce de uma URL nossa ou da cópia embutida neste pacote. Quem tem release própria e URL declarada TEM caminho de atualização: basta publicar a versão nova no mesmo endereço, e a execução seguinte do implantador a instala. O atualizador do WordPress não participa disso — ele só conhece o que vem do WordPress.org.', 'f3base' ),
						$origem
					),
				);
				continue;
			}

			if ( 'wordpress.org' === $origem ) {
				$saida[ $slug ] = array(
					'classe' => 'wordpress-org',
					'fonte'  => __( 'origem "wordpress.org" DECLARADA e nenhum Update URI conflitante no cabeçalho: o núcleo consulta o WordPress.org por este slug, que é o caminho declarado. O que esta linha mede é o caminho, e não a resposta da consulta — afirmar que o .org respondeu exigiria rede, e ela não a faz', 'f3base' ),
				);
				continue;
			}

			if ( isset( $operacionais[ $slug ] ) ) {
				$saida[ $slug ] = array(
					'classe' => 'wordpress-org',
					'fonte'  => sprintf(
						/* translators: %s: responsável declarado. */
						__( 'plugin operacional, responsável declarado: %s. Sem Update URI conflitante, o núcleo consulta o WordPress.org por este slug — e quem responde por ele é o responsável declarado, não este pacote', 'f3base' ),
						$operacionais[ $slug ]
					),
				);
				continue;
			}

			$saida[ $slug ] = array(
				'classe' => 'wordpress-org',
				'fonte'  => '' !== $origem
					? sprintf(
						/* translators: %s: origem declarada. */
						__( 'origem declarada "%s" e nenhum Update URI conflitante: o núcleo consulta o WordPress.org por este slug, que é o caminho que sobra quando o cabeçalho não desvia a consulta', 'f3base' ),
						$origem
					)
					: __( 'instalado por fora: este pacote não declara origem para o slug e o cabeçalho não traz Update URI, então o núcleo consulta o WordPress.org por ele — caminho padrão do WordPress, e não pendência deste pacote', 'f3base' ),
			);
		}

		return $saida;
	}

	/**
	 * VEREDITO PURO do CAMINHO de atualização automática. Com piso nos ramos.
	 *
	 * O QUE ESTA LINHA RESPONDE: o caminho de atualização OBSERVADO corresponde
	 * ao DECLARADO? Três estados, e só três:
	 *
	 * - **OK** — todo plugin caiu numa classe ESPERADA. A mensagem nomeia cada
	 *   grupo, porque "todos conformes" sem os nomes não é medição relatada; e
	 *   ela diz o que foi medido sem afirmar mais do que mediu.
	 * - **WARN** — a promessa quebrada MEDIDA, e só ela: `Update URI` para host
	 *   de terceiro sem `update_plugins_{host}` registrado. É o único caso em que
	 *   a flag ligada engana, e plugin e host saem nomeados.
	 * - **BLOCKED** — escopo vazio: nenhum plugin classificado. Continua sendo
	 *   pré-condição ausente de verdade, e escopo vazio não aprova nada.
	 *
	 * O QUE SAIU NA 1.1.7, e por quê: a classe `pendente`, que fazia BLOCKED.
	 * Ela dizia "depende de medição por rede que este host não fez", e isso é
	 * LIMITE DA MEDIÇÃO, não pré-condição ausente — não falta ação de ninguém.
	 * O efeito medido em produção era um BLOCKED com nove plugins, quatro
	 * sem-fonte e cinco pendentes, promovendo a unidade inteira em toda
	 * execução, sem que nada estivesse errado. Aviso que sai sempre, sobre uma
	 * ausência por desenho, é o defeito do aviso que sai sempre. A descrição
	 * ficou; o estado adverso, não.
	 *
	 * @param array<string,array{classe:string,fonte:string}> $fontes Classificação por slug.
	 * @return array{estado:string,motivo:string}
	 */
	public static function veredito_do_caminho( array $fontes ): array {
		if ( array() === $fontes ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'motivo' => __( 'pré-condição ausente: nenhum plugin instalado foi classificado, e escopo vazio não aprova nada.', 'f3base' ),
			);
		}

		$grupos = array(
			'promessa-quebrada'         => array(),
			'artefato-do-pacote'        => array(),
			'upload-do-fornecedor'      => array(),
			'wordpress-org'             => array(),
			'atualizador-do-fornecedor' => array(),
			'sem-consulta-declarada'    => array(),
		);

		foreach ( $fontes as $slug => $dados ) {
			$classe = (string) $dados['classe'];
			$linha  = $slug . ' — ' . (string) $dados['fonte'];

			$grupos[ $classe ]   = $grupos[ $classe ] ?? array();
			$grupos[ $classe ][] = $linha;
		}

		$rotulos = array(
			'artefato-do-pacote'        => __( 'ARTEFATO DESTE PACOTE (release nossa, por upload)', 'f3base' ),
			'upload-do-fornecedor'      => __( 'ORIGEM url/bundle DECLARADA (release do fornecedor, por upload)', 'f3base' ),
			'wordpress-org'             => __( 'DEPENDEM DO WORDPRESS.ORG POR SLUG (declarados wordpress.org, operacionais ou instalados por fora, todos sem Update URI conflitante)', 'f3base' ),
			'atualizador-do-fornecedor' => __( 'ATUALIZADOR DO FORNECEDOR DE PÉ (Update URI de terceiro com o filtro registrado)', 'f3base' ),
			'sem-consulta-declarada'    => __( 'CONSULTA DESLIGADA PELO PRÓPRIO ARTEFATO (Update URI sem host legível)', 'f3base' ),
		);

		$partes = array(
			sprintf(
				/* translators: %d: quantidade de plugins com a flag ligada. */
				__( 'FLAG e CAMINHO DE ATUALIZAÇÃO são fatos diferentes, e esta linha mede o segundo: o caminho OBSERVADO no cabeçalho Update URI de cada um dos %d plugin(s) com a flag ligada, comparado com o DECLARADO. A medição é local — cabeçalho lido do disco e has_filter() —, e nenhuma consulta de rede acontece aqui: o que se afirma é por onde o núcleo procuraria a atualização, nunca que a fonte respondeu.', 'f3base' ),
				count( $fontes )
			),
		);

		foreach ( $rotulos as $classe => $rotulo ) {
			if ( array() === ( $grupos[ $classe ] ?? array() ) ) {
				continue;
			}

			$partes[] = sprintf(
				/* translators: 1: rótulo do grupo, 2: plugins do grupo, nomeados. */
				__( '%1$s: %2$s.', 'f3base' ),
				$rotulo,
				implode( ' | ', $grupos[ $classe ] )
			);
		}

		if ( array() !== $grupos['promessa-quebrada'] ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::WARN,
				'motivo' => sprintf(
					/* translators: 1: plugins com a promessa quebrada, nomeados com o host, 2: o resto da medição. */
					__( 'PROMESSA QUEBRADA, medida: %1$s. Este é o único caso em que a flag ligada engana — o cabeçalho tira o plugin da consulta ao WordPress.org e ninguém respondeu pelo gancho do host, então nada o alcança. Saídas: registrar o filtro do host, corrigir o Update URI ou aceitar que a atualização dele é por upload e declará-la assim. %2$s', 'f3base' ),
					implode( ' | ', $grupos['promessa-quebrada'] ),
					implode( ' ', $partes )
				),
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::OK,
			'motivo' => sprintf(
				/* translators: %s: a medição por grupo, com os plugins nomeados. */
				__( 'todo plugin instalado caiu numa classe ESPERADA de caminho de atualização: o observado corresponde ao declarado, e não há promessa quebrada — nenhum artefato aponta Update URI para um host de terceiro sem filtro que responda por ele. %s', 'f3base' ),
				implode( ' ', $partes )
			),
		);
	}

	/**
	 * Reescreve, no fim da fase de plugins, TODA supressão declarada no mapa.
	 *
	 * A supressão que impede o sequestro já aconteceu na unidade que ativou cada
	 * plugin — aqui ela é reafirmada, e continua valendo por dois motivos: é
	 * idempotente (o gravador único não regrava o que não mudou) e cobre o plugin
	 * que já estava instalado e ativo antes desta execução, que não passou por
	 * nenhuma ativação nossa.
	 *
	 * Quem decide o que gravar é `plugins.supressao_onboarding`, nunca uma lista
	 * escrita aqui dentro.
	 *
	 * @return array<string,mixed>
	 */
	public static function suprimir_onboarding(): array {
		$rotulo = 'plugins.onboarding_suprimido';
		$mapa   = (array) F3Base_Imp_Decisoes::bloco( 'plugins.supressao_onboarding' );
		$mapa   = is_array( $mapa ) ? $mapa : array();

		$instalados = array();
		$ausentes   = array();

		foreach ( array_keys( $mapa ) as $chave ) {
			$slug = (string) $chave;

			if ( '' === self::arquivo_principal( $slug ) ) {
				$ausentes[] = $slug;
				continue;
			}

			$instalados[] = $slug;
		}

		if ( array() === $instalados ) {
			return self::saida(
				'N/A',
				$rotulo,
				sprintf(
					/* translators: %s: slugs declarados no mapa e não encontrados no disco. */
					__( 'condição de aplicabilidade falsa: nenhum dos slugs declarados em plugins.supressao_onboarding está instalado (declarados: %s), então não há assistente de terceiro para suprimir.', 'f3base' ),
					array() === $ausentes ? __( 'nenhum', 'f3base' ) : implode( ', ', $ausentes )
				)
			);
		}

		$estado = 'OK';
		$partes = array();

		foreach ( $instalados as $slug ) {
			$resultado = self::suprimir_redirecionamento_de_ativacao( $slug );
			$estado    = F3Base_Imp_Relatorio::estado_mais_severo( $estado, $resultado['estado'] );
			$versao    = self::versao_instalada( $slug );

			$partes[] = sprintf(
				/* translators: 1: slug, 2: versão observada, 3: resultado da gravação. */
				__( '%1$s (versão observada: %2$s) — %3$s', 'f3base' ),
				$slug,
				'' !== $versao ? $versao : __( 'não legível', 'f3base' ),
				$resultado['motivo']
			);
		}

		return self::saida(
			$estado,
			$rotulo,
			sprintf(
				/* translators: 1: resultado por plugin, 2: slugs declarados e ausentes do disco. */
				__( 'reescrita idempotente da supressão declarada, depois de todos os plugins: %1$s. Declarados no mapa e ausentes do disco: %2$s.', 'f3base' ),
				implode( ' | ', $partes ),
				array() === $ausentes ? __( 'nenhum', 'f3base' ) : implode( ', ', $ausentes )
			)
		);
	}

	/**
	 * Inventário nomeado dos plugins instalados, para o relatório.
	 *
	 * @return array<int,array<string,string|bool>>
	 */
	public static function inventario(): array {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$saida = array();

		foreach ( get_plugins() as $arquivo => $dados ) {
			$saida[] = array(
				'arquivo' => (string) $arquivo,
				'slug'    => F3Base_Imp_Preflight::slug_de( (string) $arquivo ),
				'nome'    => isset( $dados['Name'] ) ? (string) $dados['Name'] : '',
				'versao'  => isset( $dados['Version'] ) ? (string) $dados['Version'] : '',
				'ativo'   => is_plugin_active( (string) $arquivo ),
			);
		}

		return $saida;
	}

	/* ------------------------------------------------------------------ *
	 * Internos
	 * ------------------------------------------------------------------ */

	/**
	 * Consulta a fonte oficial pela última versão.
	 *
	 * @param string $slug Slug.
	 * @return array{url:string,versao:string,fonte:string,erro:string}
	 */
	private static function consultar_fonte_oficial( string $slug ): array {
		if ( ! function_exists( 'plugins_api' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		}

		$info = plugins_api(
			'plugin_information',
			array(
				'slug'   => $slug,
				'fields' => array(
					'sections'      => false,
					'screenshots'   => false,
					'reviews'       => false,
					'banners'       => false,
					'icons'         => false,
					'contributors'  => false,
					'compatibility' => false,
				),
			)
		);

		if ( is_wp_error( $info ) ) {
			return array(
				'url'    => '',
				'versao' => '',
				'fonte'  => 'wordpress.org',
				'erro'   => $info->get_error_message(),
			);
		}

		$url    = ( is_object( $info ) && isset( $info->download_link ) ) ? (string) $info->download_link : '';
		$versao = ( is_object( $info ) && isset( $info->version ) ) ? (string) $info->version : '';

		return array(
			'url'    => $url,
			'versao' => $versao,
			'fonte'  => 'wordpress.org',
			'erro'   => '' === $url ? __( 'a API respondeu sem link de download.', 'f3base' ) : '',
		);
	}

	/**
	 * Zip embutido no pacote para um slug.
	 *
	 * @param string $slug Slug.
	 * @return string Caminho absoluto, ou vazio.
	 */
	private static function zip_embutido( string $slug ): string {
		/*
		 * Dois caminhos, nesta ordem, e a lista vem de `PREFIXOS_DE_ZIP` — nunca
		 * escrita aqui dentro. O slot declarado é `assets/plugins/<slug>.zip`: é
		 * onde o operador põe o artefato para dispensar a chamada de rede, e é o
		 * caminho que a allow-list do empacotamento declara como prefixo. O
		 * caminho antigo `assets/<slug>.zip` continua sendo lido para não quebrar
		 * pacote montado antes do slot existir — e nunca vence o novo.
		 */
		foreach ( self::PREFIXOS_DE_ZIP as $prefixo ) {
			$caminho = f3base_imp_caminho( $prefixo . $slug . '.zip' );

			if ( '' !== $caminho && is_readable( $caminho ) ) {
				return $caminho;
			}
		}

		return '';
	}

	/**
	 * As RESERVAS VERSIONADAS que existem no pacote para um nome-base.
	 *
	 * Ela existe porque a versão da cópia embutida deixou de ter cabeçalho para
	 * ser lida: com a fonte do plugin fora do bundle, o nome do arquivo é a
	 * única fonte que sobra, e ela é lida de disco.
	 *
	 * DEVOLVE TODAS AS QUE ENCONTRAR, em ordem, e NÃO escolhe: quem escolhe é
	 * `artefato_do_papel()`, com a mesma precedência de sempre, e
	 * `reserva_versionada()`, que RECUSA quando há mais de uma. Duas reservas do
	 * mesmo slug no mesmo pacote seriam um pacote que carrega duas versões do
	 * mesmo plugin, e quem acusa isso é `estatica.artefato_do_pacote_e_lido`,
	 * que varre todo `.zip` que viaja — aqui, escolher em silêncio esconderia o
	 * defeito em vez de mostrá-lo.
	 *
	 * @param string $base Caminho relativo sem o sufixo de versão nem `.zip`.
	 * @return array<int,string> Caminhos relativos, em ordem.
	 */
	public static function reservas_versionadas( string $base ): array {
		$absoluto = f3base_imp_caminho( $base . '-*.zip' );

		if ( '' === $absoluto ) {
			return array();
		}

		$achados = glob( $absoluto ) ?: array();
		$saida   = array();
		$raiz    = rtrim( str_replace( '\\', '/', F3BASE_IMP_DIR ), '/' ) . '/';

		foreach ( $achados as $caminho ) {
			$caminho = str_replace( '\\', '/', (string) $caminho );

			if ( is_file( $caminho ) && str_starts_with( $caminho, $raiz ) ) {
				$saida[] = substr( $caminho, strlen( $raiz ) );
			}
		}

		sort( $saida );

		return $saida;
	}

	/**
	 * A RESERVA VERSIONADA de um slug: caminho, caminho relativo e versão do nome.
	 *
	 * É o que `aplicar_instalavel()` usa quando a URL declarada não responde, e
	 * é a única leitura de versão dela: o NOME do arquivo, porque o cabeçalho
	 * de dentro não chega ao host. Mais de uma reserva do mesmo slug NÃO escolhe:
	 * devolve vazio com o motivo nomeando as duas. Para o slug do site-core a
	 * suíte já recusa duas reservas no build (`f3b_reserva_do_site_core()`);
	 * para os outros slugs o host é a única linha de defesa, e ela recusa.
	 *
	 * @param string $slug Slug do plugin.
	 * @return array{caminho:string,relativo:string,versao:string,motivo:string} Caminho vazio quando não há reserva, ou quando há mais de uma (com o motivo).
	 */
	public static function reserva_versionada( string $slug ): array {
		$vazio = array(
			'caminho'  => '',
			'relativo' => '',
			'versao'   => '',
			'motivo'   => '',
		);

		if ( '' === $slug ) {
			return $vazio;
		}

		$candidatos = array();

		foreach ( self::PREFIXOS_DE_ZIP as $prefixo ) {
			foreach ( self::reservas_versionadas( $prefixo . $slug ) as $relativo ) {
				/* O sufixo é `-A.B.C.zip` colado ao slug: `<slug>-tema-1.6.2.zip` é outro artefato. */
				if ( 1 !== preg_match( '/^' . preg_quote( $prefixo . $slug, '/' ) . '-(\d+\.\d+\.\d+)\.zip$/', $relativo, $achou ) ) {
					continue;
				}

				$absoluto = f3base_imp_caminho( $relativo );

				if ( '' === $absoluto || ! is_file( $absoluto ) || ! is_readable( $absoluto ) ) {
					continue;
				}

				$candidatos[ $relativo ] = array(
					'caminho'  => $absoluto,
					'relativo' => $relativo,
					'versao'   => $achou[1],
					'motivo'   => '',
				);
			}
		}

		if ( array() === $candidatos ) {
			return $vazio;
		}

		/*
		 * DUAS RESERVAS NÃO ESCOLHEM UMA. Ordenar por nome escolheria `x-1.10.0`
		 * antes de `x-1.2.0`, que não é a maior versão nem uma regra que alguém
		 * declarou; e o host não tem suíte para acusar. A resposta é recusar,
		 * nomeando as duas — o operador que embutiu duas decide qual fica.
		 */
		if ( 1 < count( $candidatos ) ) {
			$vazio['motivo'] = sprintf(
				/* translators: %s: caminhos das reservas encontradas. */
				__( 'mais de uma reserva versionada do mesmo slug no pacote (%s), e escolher uma em silêncio esconderia o defeito — deixe uma só', 'f3base' ),
				implode( ', ', array_keys( $candidatos ) )
			);

			return $vazio;
		}

		return (array) reset( $candidatos );
	}

		/**
	 * FONTE ÚNICA do artefato que instala cada papel do pacote.
	 *
	 * O defeito que esta função fecha, medido na 1.0.15 e nomeado em três
	 * lugares diferentes do código: quem INSTALAVA o tema procurava
	 * `assets/<slug>-tema.zip` e, na falta dele, `fontes/tema/`; quem PROVAVA o
	 * entregável tinha a própria lista escrita à mão, que não conhecia o slot
	 * `assets/plugins/`; e o empacotamento ainda embarcava um terceiro artefato,
	 * `<slug>.zip` na RAIZ do bundle, que nenhum dos dois lia. Três listas para
	 * o mesmo fato, e o pacote viajava com 104.021 bytes que só serviam de prova
	 * falsa de entrega.
	 *
	 * A partir daqui a lista é UMA: quem instala e quem confere chamam esta
	 * função, e `estatica.artefato_do_pacote_e_lido` reprova qualquer artefato
	 * instalável que viaje no pacote fora dos caminhos que ela devolve.
	 *
	 * A precedência não mudou: o zip que o OPERADOR embute vence, porque ele é a
	 * decisão explícita de quem monta o pacote; a fonte em `fontes/` é o padrão
	 * do template.
	 *
	 * @param string $papel `tema` ou `site_core`.
	 * @return array{papel:string,slug:string,tipo:string,caminho:string,principal:string,candidatos:array<int,string>}
	 */
	public static function artefato_do_papel( string $papel ): array {
		$papeis = array(
			'tema'      => array(
				'slug'      => (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' ),
				'sufixo'    => '-tema',
				'fonte'     => 'fontes/tema',
				'principal' => 'style.css',
			),
			/*
			 * O PLUGIN NÃO TEM MAIS FONTE NO BUNDLE, e é por isso que o campo
			 * está vazio. Ele é artefato próprio desde a 1.7.0: o bundle leva a
			 * reserva em `assets/plugins/<slug>-<versão>.zip` e nada mais. Um
			 * `fonte` apontando para um diretório que não viaja resolveria para
			 * um caminho inexistente no host e faria a instalação falhar
			 * dizendo que a fonte sumiu, quando o que existe é o zip.
			 */
			'site_core' => array(
				'slug'      => (string) F3Base_Imp_Config::obter( 'site.site_core_slug', '' ),
				'sufixo'    => '',
				'fonte'     => '',
				'principal' => '',
			),
		);

		$vazio = array(
			'papel'      => $papel,
			'slug'       => '',
			'tipo'       => '',
			'caminho'    => '',
			'principal'  => '',
			'candidatos' => array(),
		);

		if ( ! isset( $papeis[ $papel ] ) ) {
			return $vazio;
		}

		$dados = $papeis[ $papel ];
		$slug  = $dados['slug'];

		if ( '' === $slug ) {
			return $vazio;
		}

		$candidatos = array();

		foreach ( self::PREFIXOS_DE_ZIP as $prefixo ) {
			$candidatos[] = $prefixo . $slug . $dados['sufixo'] . '.zip';
		}

		/*
		 * A RESERVA VERSIONADA vem DEPOIS do slot sem número, e a ordem é a
		 * regra de sempre: o zip que o OPERADOR embute vence, porque ele é
		 * decisão explícita de quem monta o pacote. A reserva do build é o
		 * padrão, e traz o número no nome porque é do nome que a versão dela é
		 * lida — o cabeçalho do plugin não viaja mais no bundle.
		 */
		foreach ( self::PREFIXOS_DE_ZIP as $prefixo ) {
			foreach ( self::reservas_versionadas( $prefixo . $slug . $dados['sufixo'] ) as $relativo_versionado ) {
				$candidatos[] = $relativo_versionado;
			}
		}

		if ( '' !== $dados['fonte'] ) {
			$candidatos[] = $dados['fonte'];
		}

		$tipo    = '';
		$caminho = '';

		foreach ( $candidatos as $relativo ) {
			$absoluto = f3base_imp_caminho( $relativo );

			if ( '' === $absoluto ) {
				continue;
			}

			if ( str_ends_with( $relativo, '.zip' ) && is_readable( $absoluto ) && is_file( $absoluto ) ) {
				$tipo    = 'zip';
				$caminho = $absoluto;
				break;
			}

			if ( ! str_ends_with( $relativo, '.zip' ) && is_dir( $absoluto ) ) {
				$tipo    = 'diretorio';
				$caminho = $absoluto;
				break;
			}
		}

		return array(
			'papel'      => $papel,
			'slug'       => $slug,
			'tipo'       => $tipo,
			'caminho'    => $caminho,
			'principal'  => $dados['principal'],
			'candidatos' => $candidatos,
		);
	}

	/**
	 * ÂNCORA da fonte única do artefato: quem resolve, quem instala e quem prova.
	 *
	 * A lista mora no PACOTE e não na suíte, pela razão de sempre: escrevê-la na
	 * suíte seria a segunda fonte para o mesmo fato, que é exatamente o defeito
	 * que esta regra existe para impedir. Quem cobra é
	 * `estatica.artefato_do_pacote_e_lido`: as funções nomeadas aqui precisam
	 * chamar o resolvedor e não podem montar caminho de artefato por conta
	 * própria — nem `.zip`, nem `fontes/`.
	 *
	 * @return array<string,string>
	 */
	public static function artefato_fonte_unica_declarada(): array {
		return array(
			'resolvedor' => 'artefato_do_papel',
			'instala'    => 'aplicar_tema',
			'prova'      => 'conferir_tema',
		);
	}

	/**
	 * ÂNCORA da troca de diretório: quem troca, quem invalida e quem relê.
	 *
	 * Existe para que `estatica.troca_invalida_cache` cobre a regra do pacote em
	 * vez de reescrevê-la na suíte. A regra, e o defeito que a produziu, estão
	 * em `trocar_diretorio()`.
	 *
	 * @return array<string,string>
	 */
	public static function troca_de_diretorio_declarada(): array {
		return array(
			'trocador'    => 'trocar_diretorio',
			'invalidador' => 'invalidar_cache_do_artefato',
			'leitura'     => 'leitura_de_volta_do_artefato',
			'tema'        => 'wp_clean_themes_cache',
			'plugin'      => 'wp_clean_plugins_cache',
		);
	}

	/**
	 * Derruba o cache do núcleo para o artefato que ACABOU de trocar de lugar.
	 *
	 * O DEFEITO QUE ESTA FUNÇÃO FECHA, e ele custou uma instalação limpa
	 * inteira. `Theme_Upgrader::install()` chama `wp_clean_themes_cache()` e
	 * `Plugin_Upgrader::install()` chama `wp_clean_plugins_cache()`;
	 * `trocar_diretorio()` não passa pelo upgrader e não chamava nem um nem
	 * outro. Numa instalação recém-criada o caminho é este:
	 *
	 * 1. a etapa consulta o estado ANTES — `wp_get_theme( $slug )->exists()`, ou
	 *    a versão instalada do site-core — e o núcleo memoriza o NEGATIVO na
	 *    mesma requisição (`search_theme_directories()` guarda a varredura,
	 *    `get_plugins()` guarda a lista no grupo `plugins`);
	 * 2. a troca de diretório acontece e o diretório passa a existir no disco;
	 * 3. a leitura de volta pergunta de novo, o núcleo responde do cache — que
	 *    ainda diz que não existe — e a unidade fecha FALHA dizendo "não
	 *    apareceu no disco" sobre um diretório que está lá.
	 *
	 * Por que só apareceu na 1.0.15: toda execução anterior rodou em site que já
	 * tinha tema e site-core instalados. Ali a consulta prévia memorizava o
	 * POSITIVO e a leitura de volta passava por acidente, quinze releases
	 * seguidas, sem que o piso jamais tivesse exercitado alvo inexistente.
	 *
	 * A invalidação mora AQUI, dentro de quem trocou o diretório, e não no
	 * chamador: chamador que esquece é o defeito voltando.
	 *
	 * @param string $tipo `tema` ou `plugin`.
	 * @return void
	 */
	public static function invalidar_cache_do_artefato( string $tipo ): void {
		if ( 'tema' === $tipo ) {
			/*
			 * `wp_clean_themes_cache()` é a MESMA chamada que o
			 * `Theme_Upgrader::install()` faz: ela força
			 * `search_theme_directories( true )` — a varredura que memoriza o
			 * negativo — e apaga o cache de cada `WP_Theme`.
			 */
			if ( function_exists( 'wp_clean_themes_cache' ) ) {
				wp_clean_themes_cache( false );
			}

			return;
		}

		if ( ! function_exists( 'wp_clean_plugins_cache' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		wp_clean_plugins_cache( false );
	}

	/**
	 * LEITURA DE VOLTA de um artefato trocado: mede o disco AO LADO da API.
	 *
	 * A mensagem tem de distinguir dois fatos diferentes, e a 1.0.15 os
	 * confundia num só. "Não apareceu no disco" dito sobre um diretório que está
	 * lá manda o operador procurar no lugar errado — foi o que o relatório fez,
	 * enquanto a unidade de auto-update, três linhas abaixo, enumerava o mesmo
	 * artefato entre os instalados.
	 *
	 * Os fatos medidos são três, e cada um tem mensagem própria:
	 *
	 * - o DIRETÓRIO existe? (`is_dir`)
	 * - o ARQUIVO PRINCIPAL existe dentro dele? (`style.css` no tema, qualquer
	 *   `.php` na raiz do plugin — a mesma regra que valida a montagem antes da
	 *   troca)
	 * - a API do WordPress o enxerga?
	 *
	 * Diretório ausente é "não apareceu no disco". Diretório presente com a API
	 * discordando é DEFEITO DE CACHE, nomeado como tal — nunca a mensagem de
	 * disco.
	 *
	 * @param string $tipo    `tema` ou `plugin`.
	 * @param string $slug    Slug do artefato.
	 * @param string $destino Diretório de destino, absoluto.
	 * @param bool   $api_ve  A API do WordPress enxerga o artefato?
	 * @return array{ok:bool,diagnostico:string,motivo:string,diretorio:bool,principal:bool,api:bool}
	 */
	public static function leitura_de_volta_do_artefato( string $tipo, string $slug, string $destino, bool $api_ve ): array {
		$destino   = rtrim( str_replace( '\\', '/', $destino ), '/' );
		$diretorio = '' !== $destino && is_dir( $destino );
		$principal = $diretorio && (
			'tema' === $tipo
				? is_file( $destino . '/style.css' )
				: array() !== ( glob( $destino . '/*.php' ) ?: array() )
		);

		/*
		 * A API MANDA NO "ESTÁ INSTALADO?", e a medição de disco existe para
		 * DISCRIMINAR a falha, não para criar uma. Um site com mais de uma raiz
		 * de temas registrada pode ter o artefato numa raiz diferente da que
		 * este caminho aponta: ali a API o enxerga e `is_dir` do caminho medido
		 * não. Isso não é falha — é o artefato em outro lugar, e a mensagem diz
		 * exatamente isso em vez de reprovar uma instalação que está de pé.
		 */
		if ( $api_ve && ( ! $diretorio || ! $principal ) ) {
			return array(
				'ok'          => true,
				'diagnostico' => 'presente_fora_do_caminho',
				'diretorio'   => $diretorio,
				'principal'   => $principal,
				'api'         => true,
				'motivo'      => sprintf(
					/* translators: 1: slug, 2: caminho medido. */
					__( '%1$s: a API do WordPress o enxerga instalado, e o caminho medido (%2$s) não traz o artefato completo. A instalação está de pé numa raiz diferente da medida — fato registrado, não falha.', 'f3base' ),
					$slug,
					$destino
				),
			);
		}

		if ( ! $diretorio ) {
			return array(
				'ok'          => false,
				'diagnostico' => 'ausente_no_disco',
				'diretorio'   => false,
				'principal'   => false,
				'api'         => $api_ve,
				'motivo'      => sprintf(
					/* translators: 1: slug, 2: caminho medido. */
					__( '%1$s não apareceu no disco depois da instalação: o diretório %2$s NÃO existe (medido por is_dir). A troca de diretório não chegou a colocar o artefato no lugar.', 'f3base' ),
					$slug,
					$destino
				),
			);
		}

		if ( ! $principal ) {
			return array(
				'ok'          => false,
				'diagnostico' => 'principal_ausente',
				'diretorio'   => true,
				'principal'   => false,
				'api'         => $api_ve,
				'motivo'      => sprintf(
					/* translators: 1: slug, 2: caminho medido, 3: arquivo principal esperado. */
					__( '%1$s: o diretório %2$s EXISTE no disco e o arquivo principal (%3$s) não está dentro dele. O artefato foi movido incompleto — não é cache, e não é ausência de diretório.', 'f3base' ),
					$slug,
					$destino,
					'tema' === $tipo ? 'style.css' : __( 'qualquer .php na raiz do plugin', 'f3base' )
				),
			);
		}

		if ( ! $api_ve ) {
			return array(
				'ok'          => false,
				'diagnostico' => 'cache_desatualizado',
				'diretorio'   => true,
				'principal'   => true,
				'api'         => false,
				'motivo'      => sprintf(
					/* translators: 1: slug, 2: caminho medido, 3: função de invalidação esperada. */
					__( 'DEFEITO DE CACHE em %1$s, não ausência no disco: o diretório %2$s existe e tem o arquivo principal dentro dele, e a API do WordPress ainda NÃO o enxerga. O cache do núcleo não caiu depois da troca de diretório — quem o derruba é %3$s(), chamada por quem trocou o diretório. Não procure o artefato no disco: ele está lá.', 'f3base' ),
					$slug,
					$destino,
					'tema' === $tipo ? 'wp_clean_themes_cache' : 'wp_clean_plugins_cache'
				),
			);
		}

		return array(
			'ok'          => true,
			'diagnostico' => 'presente',
			'diretorio'   => true,
			'principal'   => true,
			'api'         => true,
			'motivo'      => sprintf(
				/* translators: 1: slug, 2: caminho medido. */
				__( '%1$s conferido por leitura de volta: o diretório %2$s existe, tem o arquivo principal e a API do WordPress o enxerga.', 'f3base' ),
				$slug,
				$destino
			),
		);
	}

	/**
	 * Instala um pacote (URL remota ou zip local) pelo upgrader do core.
	 *
	 * Pacote remoto desce por `baixar_artefato()` ANTES do upgrader, e não por
	 * `download_url()`: é ali que os saltos de redirecionamento são seguidos um a
	 * um com o host REVALIDADO em cada um, e é por isso que a falha de rede sai
	 * nomeada, com host e código HTTP, em vez de virar uma mensagem genérica do
	 * instalador. Falha de rede é BLOCKED: pré-condição externa ausente não é
	 * defeito do site.
	 *
	 * Devolve também a PASTA criada, lida do resultado do upgrader: o nome do
	 * diretório é fato observado do zip, nunca o slug presumido.
	 *
	 * @param string $pacote      URL ou caminho local.
	 * @param bool   $sobrescreve Já existe instalação a substituir.
	 * @param string $tipo        `plugin` ou `tema`.
	 * @return array{ok:bool,motivo:string,pasta:string,bloqueado:bool}
	 */
	private static function instalar_pacote( string $pacote, bool $sobrescreve, string $tipo = 'plugin' ): array {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		$arquivo = $pacote;
		$baixado = '';

		if ( 1 === preg_match( '#^https?://#i', $pacote ) ) {
			$download = self::baixar_artefato( $pacote );

			if ( ! $download['ok'] ) {
				return array(
					'ok'        => false,
					'motivo'    => $download['motivo'],
					'pasta'     => '',
					'bloqueado' => true,
				);
			}

			$arquivo = $download['arquivo'];
			$baixado = $download['arquivo'];
		}

		$skin = new Automatic_Upgrader_Skin();

		$upgrader = 'tema' === $tipo ? new Theme_Upgrader( $skin ) : new Plugin_Upgrader( $skin );

		add_filter( 'upgrader_package_options', array( __CLASS__, 'permitir_sobrescrita' ) );

		$resultado = $upgrader->install( $arquivo, array( 'overwrite_package' => $sobrescreve ) );

		remove_filter( 'upgrader_package_options', array( __CLASS__, 'permitir_sobrescrita' ) );

		if ( '' !== $baixado && file_exists( $baixado ) ) {
			wp_delete_file( $baixado );
		}

		if ( is_wp_error( $resultado ) ) {
			return array(
				'ok'        => false,
				'motivo'    => $resultado->get_error_message(),
				'pasta'     => '',
				'bloqueado' => false,
			);
		}

		if ( false === $resultado || null === $resultado ) {
			$mensagens = $skin->get_upgrade_messages();

			return array(
				'ok'        => false,
				'motivo'    => sprintf(
					/* translators: %s: mensagens do instalador. */
					__( 'o instalador do WordPress não concluiu: %s', 'f3base' ),
					implode( ' | ', array_map( 'wp_strip_all_tags', is_array( $mensagens ) ? $mensagens : array() ) )
				),
				'pasta'     => '',
				'bloqueado' => false,
			);
		}

		return array(
			'ok'        => true,
			'motivo'    => '',
			'pasta'     => self::pasta_do_upgrader( $upgrader ),
			'bloqueado' => false,
		);
	}

	/**
	 * A CONFERÊNCIA DE DIGESTO SE APLICA A ESTA ORIGEM? Função pura, com piso.
	 *
	 * A fronteira é o CONTRATO, regra 20 — "sempre a última versão da fonte
	 * oficial; sem número de versão declarado e **sem checksum de
	 * terceiro**" —, e ela existe porque não se conhece de antemão o hash de uma
	 * versão que ainda não saiu. Ela vale inteira para o WordPress.org, cuja URL
	 * é por VERSÃO e cujo artefato MUDA de propósito a cada atualização: fixar o
	 * digesto ali faria a próxima versão legítima reprovar.
	 *
	 * A origem `url` DECLARADA é o caso que a regra 20 não cobre: o artefato é
	 * nosso e a URL aponta para uma ref MUTÁVEL — o mesmo endereço servindo
	 * conteúdo diferente sem que nada no site mude. Só nele a conferência roda.
	 *
	 * @param string $origem Origem declarada na entrada.
	 * @return bool
	 */
	public static function digesto_se_aplica( string $origem ): bool {
		return 'url' === $origem;
	}

	/**
	 * VEREDITO PURO do digesto do artefato: função sem WordPress, com piso.
	 *
	 * Três ramos, e eles não afirmam a mesma coisa — a diferença entre eles é o
	 * ponto inteiro desta regra:
	 *
	 * - **Declarado e batendo.** O `sha256` da entrada é o teto. O artefato que
	 *   chegou é o artefato que a configuração nomeia, e isso vale para a
	 *   primeira busca também.
	 * - **Declarado e divergindo.** FALHA nomeando os DOIS valores, e nada é
	 *   instalado. Não é BLOCKED: pré-condição externa ausente é uma coisa,
	 *   artefato que chegou diferente do declarado é outra, e essa é defeito.
	 * - **Ausente.** O digesto é medido e FIXADO na primeira observação, e a
	 *   mensagem diz, com todas as letras, o que isso protege e o que não
	 *   protege: defende contra a origem mudar embaixo das execuções SEGUINTES
	 *   e NÃO defende esta busca. Execução seguinte com digesto diferente do
	 *   fixado é FALHA, pelo mesmo motivo do ramo anterior.
	 *
	 * Por que o ramo ausente existe: o template precisa funcionar como produção
	 * sem configuração extra, e exigir digesto declarado quebraria a primeira
	 * execução de todo projeto novo. O preço está escrito na mensagem em vez de
	 * ficar escondido atrás de uma linha verde.
	 *
	 * @param string $declarado Digesto declarado na entrada (vazio quando não há).
	 * @param string $medido    Digesto do artefato que acabou de descer.
	 * @param string $fixado    Digesto fixado por uma execução anterior (vazio na primeira).
	 * @return array{ok:bool,fixar:bool,motivo:string}
	 */
	public static function veredito_do_digest( string $declarado, string $medido, string $fixado ): array {
		$declarado = strtolower( trim( $declarado ) );
		$medido    = strtolower( trim( $medido ) );
		$fixado    = strtolower( trim( $fixado ) );

		if ( '' === $medido ) {
			return array(
				'ok'     => false,
				'fixar'  => false,
				'motivo' => __( 'o digesto do artefato baixado não pôde ser medido: sem digesto não há o que conferir nem o que fixar, e instalar assim seria afirmar uma conferência que não aconteceu.', 'f3base' ),
			);
		}

		if ( '' !== $declarado ) {
			if ( $declarado === $medido ) {
				return array(
					'ok'     => true,
					'fixar'  => false,
					'motivo' => sprintf(
						/* translators: %s: digesto conferido. */
						__( 'Digesto DECLARADO conferido antes de instalar: sha256 %s. O artefato que desceu é o que a configuração nomeia, e essa garantia vale inclusive para a primeira busca.', 'f3base' ),
						$medido
					),
				);
			}

			return array(
				'ok'     => false,
				'fixar'  => false,
				'motivo' => sprintf(
					/* translators: 1: digesto declarado, 2: digesto medido. */
					__( 'DIGESTO DIVERGENTE do declarado: a configuração declara sha256 %1$s e o artefato que desceu tem sha256 %2$s. NADA foi instalado. O artefato do canal é o que expõe as rotas de arquivo e de banco, e instalar um binário que não é o declarado seria a cadeia de suprimentos entrando pela porta que a lista de hosts existe para fechar.', 'f3base' ),
					$declarado,
					$medido
				),
			);
		}

		if ( '' === $fixado ) {
			return array(
				'ok'     => true,
				'fixar'  => true,
				'motivo' => sprintf(
					/* translators: 1: digesto medido e fixado, 2: caminho da chave que declararia o digesto. */
					__( 'Digesto NÃO declarado: medido e FIXADO nesta primeira observação — sha256 %1$s. O QUE ISSO PROTEGE: a execução seguinte que baixar um artefato com digesto diferente deste FALHA, então a origem não muda embaixo das execuções seguintes sem que alguém saiba. O QUE ISSO NÃO PROTEGE: esta busca. Se o artefato já veio trocado, é o trocado que acabou de ser fixado — fixar na primeira observação não é verificação de integridade, e chamá-la assim produziria a confiança que ela não sustenta. Para ter a garantia na primeira busca, declare %2$s.', 'f3base' ),
					$medido,
					'sha256'
				),
			);
		}

		if ( $fixado === $medido ) {
			return array(
				'ok'     => true,
				'fixar'  => false,
				'motivo' => sprintf(
					/* translators: %s: digesto conferido contra o fixado. */
					__( 'Digesto não declarado, conferido contra o FIXADO na primeira observação: sha256 %s. A origem não mudou entre as execuções — que é exatamente, e só, o que esta conferência sustenta.', 'f3base' ),
					$medido
				),
			);
		}

		return array(
			'ok'     => false,
			'fixar'  => false,
			'motivo' => sprintf(
				/* translators: 1: digesto fixado, 2: digesto medido. */
				__( 'DIGESTO DIVERGENTE do fixado: a primeira observação fixou sha256 %1$s e o artefato que desceu agora tem sha256 %2$s. NADA foi instalado. A URL declarada aponta para uma ref MUTÁVEL, e é exatamente esta mudança que fixar o digesto existe para acusar; se a troca for legítima, declare o novo sha256 na entrada ou apague o registro fixado deste slug e reexecute.', 'f3base' ),
				$fixado,
				$medido
			),
		);
	}

	/**
	 * REGISTRO dos digestos fixados, por slug.
	 *
	 * @return array<string,array{sha256:string,url:string,em:int}>
	 */
	public static function digestos_fixados(): array {
		$registro = get_option( self::OPTION_DIGESTOS, array() );

		return is_array( $registro ) ? $registro : array();
	}

	/**
	 * Digesto fixado para um slug, ou vazio quando nunca houve um.
	 *
	 * @param string $slug Slug do plugin.
	 * @return string
	 */
	public static function digesto_fixado( string $slug ): string {
		$registro = self::digestos_fixados();

		return isset( $registro[ $slug ]['sha256'] ) ? (string) $registro[ $slug ]['sha256'] : '';
	}

	/**
	 * Fixa o digesto observado de um slug no registro da instalação.
	 *
	 * @param string $slug   Slug do plugin.
	 * @param string $sha256 Digesto medido.
	 * @param string $url    URL de onde o artefato desceu.
	 * @return void
	 */
	private static function fixar_digesto( string $slug, string $sha256, string $url ): void {
		$registro = self::digestos_fixados();

		$registro[ $slug ] = array(
			'sha256' => $sha256,
			'url'    => $url,
			'em'     => time(),
		);

		F3Base_Imp_Gravador::persistir_infra( self::OPTION_DIGESTOS, $registro );
	}

	/**
	 * SEGUE os redirecionamentos revalidando a GUARDA a CADA salto. Função pura.
	 *
	 * O defeito que ela fecha: a guarda era conferida no endereço declarado
	 * ANTES do download e `download_url()` seguia redirecionamento sozinho. Um
	 * endereço aprovado que respondesse 302 para outro entregaria o artefato
	 * desse outro — a guarda seria conferida no endereço que ninguém baixou, e a
	 * garantia inteira valeria para a URL errada.
	 *
	 * O que a guarda mede desde a 1.0.19 é UMA coisa: o salto continua em https.
	 * Ela entra por PARÂMETRO, como o buscador, para que o piso possa exercitar
	 * a cadeia sem rede: é a mesma função que roda contra o pacote, com a ponta
	 * de rede trocada.
	 *
	 * @param string           $url    URL inicial.
	 * @param callable         $buscar fn(string $url): array{codigo:int,location:string,erro:string}.
	 * @param callable         $guarda fn(string $url): array{ok:bool,host:string,motivo:string}.
	 * @param int              $maximo Teto de saltos.
	 * @return array{ok:bool,url:string,host:string,saltos:array<int,string>,motivo:string}
	 */
	public static function seguir_redirecionamentos( string $url, callable $buscar, callable $guarda, int $maximo ): array {
		$saltos = array();
		$atual  = $url;

		for ( $i = 0; $i <= $maximo; $i++ ) {
			$autorizacao = $guarda( $atual );

			if ( ! $autorizacao['ok'] ) {
				return array(
					'ok'     => false,
					'url'    => $atual,
					'host'   => (string) $autorizacao['host'],
					'saltos' => $saltos,
					'motivo' => 0 === $i
						? (string) $autorizacao['motivo']
						: sprintf(
							/* translators: 1: número do salto, 2: URL do salto, 3: motivo da recusa, 4: cadeia percorrida. */
							__( 'REDIRECIONAMENTO recusado no salto %1$d (%2$s): %3$s Nada foi baixado. Cadeia percorrida: %4$s. Conferir a guarda só na URL declarada a deixaria valendo para um endereço que ninguém baixa.', 'f3base' ),
							$i,
							$atual,
							(string) $autorizacao['motivo'],
							implode( ' → ', array_merge( array( $url ), $saltos ) )
						),
				);
			}

			$resposta = $buscar( $atual );

			if ( '' !== (string) $resposta['erro'] ) {
				return array(
					'ok'     => false,
					'url'    => $atual,
					'host'   => (string) $autorizacao['host'],
					'saltos' => $saltos,
					'motivo' => (string) $resposta['erro'],
				);
			}

			if ( '' === (string) $resposta['location'] ) {
				return array(
					'ok'     => true,
					'url'    => $atual,
					'host'   => (string) $autorizacao['host'],
					'saltos' => $saltos,
					'motivo' => '',
				);
			}

			$atual    = (string) $resposta['location'];
			$saltos[] = $atual;
		}

		return array(
			'ok'     => false,
			'url'    => $atual,
			'host'   => '',
			'saltos' => $saltos,
			'motivo' => sprintf(
				/* translators: 1: teto de saltos, 2: cadeia percorrida. */
				__( 'a cadeia de redirecionamentos passou do teto de %1$d saltos e o download foi abandonado. Cadeia percorrida: %2$s. Seguir indefinidamente seria deixar a origem decidir quantas vezes o site a persegue.', 'f3base' ),
				$maximo,
				implode( ' → ', array_merge( array( $url ), $saltos ) )
			),
		);
	}

	/**
	 * Baixa o artefato remoto, nomeando host e código HTTP quando falha.
	 *
	 * O TRANSPORTE MUDOU NA 1.0.18, e a razão é medida: `download_url()` segue
	 * redirecionamento por conta própria e não consulta guarda nenhuma. Aqui os
	 * saltos são seguidos com `redirection => 0`, um a um, com a guarda de https
	 * REVALIDADA em cada um; o corpo só desce do endereço final, que é o único
	 * que teve a guarda conferida. A camada HTTP continua sendo a do núcleo — a
	 * mesma que `download_url()` usa por dentro —, e a falha continua saindo com
	 * host e código HTTP nomeados.
	 *
	 * @param string $url URL já conferida pela guarda de https.
	 * @return array{ok:bool,arquivo:string,motivo:string,sha256:string,url_final:string}
	 */
	private static function baixar_artefato( string $url ): array {
		$cadeia = self::seguir_redirecionamentos(
			$url,
			static function ( string $endereco ): array {
				/*
				 * O SALTO É SONDADO COM HEAD, e não com GET: um GET no último
				 * endereço traria o zip inteiro para a memória só para descobrir
				 * que ele não redireciona, e depois o traria de novo para o
				 * disco. Servidor que recusa HEAD (405/501) é tratado abaixo
				 * como "não há mais salto a descobrir daqui" — e isso NÃO abre
				 * buraco: a transferência também vai com `redirection => 0`, e um
				 * redirecionamento na hora do corpo falha nomeado, sem baixar.
				 */
				$resposta = wp_remote_head(
					$endereco,
					array(
						'timeout'     => 300,
						'redirection' => 0,
					)
				);

				if ( is_wp_error( $resposta ) ) {
					return array(
						'codigo'   => 0,
						'location' => '',
						'erro'     => sprintf(
							/* translators: 1: host, 2: código do erro, 3: mensagem, 4: URL. */
							__( 'o artefato não respondeu — host %1$s, erro %2$s: %3$s. Pré-condição externa ausente é BLOCKED, nunca FALHA. Contingência declarada: pôr o zip em assets/plugins/<slug>.zip, que resolve ANTES da URL e dispensa a rede — com os MESMOS bytes que o catálogo declara por sha256, quando declara; a reserva versionada do pacote responde sozinha quando a origem é url. URL: %4$s', 'f3base' ),
							(string) wp_parse_url( $endereco, PHP_URL_HOST ),
							(string) $resposta->get_error_code(),
							(string) $resposta->get_error_message(),
							$endereco
						),
					);
				}

				$codigo = (int) wp_remote_retrieve_response_code( $resposta );
				$local  = (string) wp_remote_retrieve_header( $resposta, 'location' );

				if ( $codigo >= 300 && $codigo < 400 && '' !== $local ) {
					return array(
						'codigo'   => $codigo,
						'location' => 1 === preg_match( '#^https?://#i', $local ) ? $local : (string) self::endereco_absoluto( $endereco, $local ),
						'erro'     => '',
					);
				}

				if ( 405 === $codigo || 501 === $codigo ) {
					/* O servidor recusa HEAD: não há mais salto a descobrir daqui. */
					return array(
						'codigo'   => $codigo,
						'location' => '',
						'erro'     => '',
					);
				}

				if ( $codigo < 200 || $codigo >= 300 ) {
					return array(
						'codigo'   => $codigo,
						'location' => '',
						'erro'     => sprintf(
							/* translators: 1: host, 2: código HTTP, 3: URL. */
							__( 'o download do artefato não completou — host %1$s, código HTTP %2$d. Pré-condição externa ausente é BLOCKED, nunca FALHA. Contingência declarada: pôr o zip em assets/plugins/<slug>.zip, que resolve ANTES da URL e dispensa a rede — com os MESMOS bytes que o catálogo declara por sha256, quando declara; a reserva versionada do pacote responde sozinha quando a origem é url. URL: %3$s', 'f3base' ),
							(string) wp_parse_url( $endereco, PHP_URL_HOST ),
							$codigo,
							$endereco
						),
					);
				}

				return array(
					'codigo'   => $codigo,
					'location' => '',
					'erro'     => '',
				);
			},
			static fn( string $endereco ): array => self::salto_e_https( $endereco ),
			self::SALTOS_MAXIMOS
		);

		if ( ! $cadeia['ok'] ) {
			return array(
				'ok'        => false,
				'arquivo'   => '',
				'motivo'    => $cadeia['motivo'],
				'sha256'    => '',
				'url_final' => $cadeia['url'],
			);
		}

		$destino = self::transferir( $cadeia['url'] );

		if ( is_wp_error( $destino ) ) {
			$dados  = $destino->get_error_data();
			$codigo = ( is_array( $dados ) && isset( $dados['code'] ) ) ? (int) $dados['code'] : 0;

			return array(
				'ok'        => false,
				'arquivo'   => '',
				'motivo'    => sprintf(
					/* translators: 1: host, 2: código HTTP observado, 3: código do erro, 4: mensagem do erro, 5: URL final conferida. */
					__( 'o download do artefato não completou — host %1$s, código HTTP %2$s, erro %3$s: %4$s. Pré-condição externa ausente é BLOCKED, nunca FALHA. Contingência declarada: pôr o zip em assets/plugins/<slug>.zip, que resolve ANTES da URL e dispensa a rede — com os MESMOS bytes que o catálogo declara por sha256, quando declara; a reserva versionada do pacote responde sozinha quando a origem é url. URL: %5$s', 'f3base' ),
					'' !== (string) $cadeia['host'] ? (string) $cadeia['host'] : __( 'ilegível', 'f3base' ),
					0 !== $codigo ? (string) $codigo : __( 'nenhuma resposta HTTP', 'f3base' ),
					(string) $destino->get_error_code(),
					(string) $destino->get_error_message(),
					(string) $cadeia['url']
				),
				'sha256'    => '',
				'url_final' => (string) $cadeia['url'],
			);
		}

		return array(
			'ok'        => true,
			'arquivo'   => (string) $destino,
			'motivo'    => array() === $cadeia['saltos']
				? sprintf(
					/* translators: %s: host conferido. */
					__( 'Endereço https conferido em %s, sem redirecionamento.', 'f3base' ),
					(string) $cadeia['host']
				)
				: sprintf(
					/* translators: 1: quantidade de saltos, 2: cadeia percorrida, 3: host final. */
					__( 'Guarda de https REVALIDADA em cada um dos %1$d redirecionamento(s): %2$s. O corpo desceu do endereço final, servido por https no host %3$s.', 'f3base' ),
					count( $cadeia['saltos'] ),
					implode( ' → ', array_merge( array( $url ), $cadeia['saltos'] ) ),
					(string) $cadeia['host']
				),
			'sha256'    => (string) hash_file( 'sha256', (string) $destino ),
			'url_final' => (string) $cadeia['url'],
		);
	}

	/**
	 * Resolve um `Location` relativo contra o endereço que o devolveu.
	 *
	 * @param string $base   Endereço que respondeu o redirecionamento.
	 * @param string $local  Valor do cabeçalho `Location`.
	 * @return string
	 */
	private static function endereco_absoluto( string $base, string $local ): string {
		$partes = wp_parse_url( $base );

		if ( ! is_array( $partes ) || ! isset( $partes['scheme'], $partes['host'] ) ) {
			return $local;
		}

		$raiz = $partes['scheme'] . '://' . $partes['host'] . ( isset( $partes['port'] ) ? ':' . (int) $partes['port'] : '' );

		if ( str_starts_with( $local, '/' ) ) {
			return $raiz . $local;
		}

		$caminho = isset( $partes['path'] ) ? (string) $partes['path'] : '/';

		return $raiz . substr( $caminho, 0, (int) strrpos( $caminho, '/' ) + 1 ) . $local;
	}

	/**
	 * Traz o CORPO do endereço final, sem seguir mais nenhum salto.
	 *
	 * Separada de `baixar_artefato()` para que a transferência tenha um ponto
	 * único: `redirection => 0` aqui é o que garante que o arquivo salvo veio do
	 * endereço cujo host acabou de ser conferido, e não de um salto a mais que a
	 * camada HTTP tivesse seguido sozinha depois da conferência.
	 *
	 * @param string $url Endereço final, com host já conferido.
	 * @return string|WP_Error Caminho do arquivo temporário.
	 */
	private static function transferir( string $url ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';

		$arquivo = wp_tempnam( $url );

		if ( '' === (string) $arquivo ) {
			return new WP_Error( 'f3base_sem_temporario', __( 'não foi possível criar o arquivo temporário do download.', 'f3base' ) );
		}

		$resposta = wp_remote_get(
			$url,
			array(
				'timeout'     => 300,
				'redirection' => 0,
				'stream'      => true,
				'filename'    => $arquivo,
			)
		);

		if ( is_wp_error( $resposta ) ) {
			wp_delete_file( $arquivo );

			return $resposta;
		}

		$codigo = (int) wp_remote_retrieve_response_code( $resposta );

		if ( 200 !== $codigo ) {
			wp_delete_file( $arquivo );

			return new WP_Error(
				'http_404',
				$codigo >= 300 && $codigo < 400
					? __( 'o endereço final REDIRECIONOU na hora de trazer o corpo, depois de o host já ter sido conferido: nada foi baixado. A transferência vai com redirection = 0 exatamente para que um salto tardio falhe em vez de entregar o artefato de um host que ninguém conferiu.', 'f3base' )
					: (string) wp_remote_retrieve_response_message( $resposta ),
				array( 'code' => $codigo )
			);
		}

		return $arquivo;
	}

	/**
	 * Pasta criada por uma instalação, lida do RESULTADO do upgrader.
	 *
	 * @param WP_Upgrader $upgrader Instalador que acabou de rodar.
	 * @return string Nome do diretório, ou vazio quando o instalador não informou.
	 */
	private static function pasta_do_upgrader( WP_Upgrader $upgrader ): string {
		$resultado = $upgrader->result;

		if ( is_array( $resultado ) && isset( $resultado['destination_name'] ) && '' !== (string) $resultado['destination_name'] ) {
			return (string) $resultado['destination_name'];
		}

		if ( $upgrader instanceof Plugin_Upgrader ) {
			$arquivo = $upgrader->plugin_info();

			if ( is_string( $arquivo ) && '' !== $arquivo ) {
				return F3Base_Imp_Preflight::slug_de( $arquivo );
			}
		}

		return '';
	}

	/**
	 * Autoriza a sobrescrita do diretório na instalação de release nova.
	 *
	 * @param array<string,mixed> $opcoes Opções do instalador.
	 * @return array<string,mixed>
	 */
	public static function permitir_sobrescrita( $opcoes ) {
		if ( is_array( $opcoes ) ) {
			$opcoes['clear_destination'] = true;
		}

		return $opcoes;
	}

	/**
	 * Impressão de um DIRETÓRIO: caminhos relativos e hashes, ordenados.
	 *
	 * Mesma forma do hash do pacote: o nome do diretório não entra, só o
	 * conteúdo. É o que permite responder "o artefato baixado é o mesmo que já
	 * está instalado?" sem confiar no número de versão do cabeçalho — e é
	 * exatamente a regra do gravador aplicada a arquivo: não se grava o que não
	 * mudou.
	 *
	 * @param string $dir Diretório absoluto.
	 * @return string Hash, ou vazio quando o diretório não é legível.
	 */
	public static function impressao_de_diretorio( string $dir ): string {
		$dir = rtrim( str_replace( '\\', '/', $dir ), '/' );

		if ( '' === $dir || ! is_dir( $dir ) ) {
			return '';
		}

		$itens    = array();
		$iterador = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) );

		foreach ( $iterador as $arquivo ) {
			if ( ! $arquivo instanceof SplFileInfo || ! $arquivo->isFile() ) {
				continue;
			}

			$absoluto = str_replace( '\\', '/', (string) $arquivo->getPathname() );
			$itens[]  = substr( $absoluto, strlen( $dir ) + 1 ) . ':' . (string) hash_file( 'sha256', $absoluto );
		}

		sort( $itens );

		return array() === $itens ? '' : hash( 'sha256', implode( "\n", $itens ) );
	}

	/**
	 * Impressão do CONTEÚDO de um zip de plugin, com a pasta-raiz descartada.
	 *
	 * Um zip de código-fonte extrai para `<repo>-<branch>/`, e o instalado mora
	 * em `<pasta_esperada>/`: comparar incluindo o primeiro segmento faria dois
	 * conteúdos idênticos parecerem diferentes por causa do nome da pasta.
	 *
	 * @param string $zip Caminho do zip.
	 * @return string Hash, ou vazio quando o zip não abre.
	 */
	public static function impressao_de_zip( string $zip ): string {
		if ( '' === $zip || ! is_readable( $zip ) || ! class_exists( 'ZipArchive' ) ) {
			return '';
		}

		$arquivo = new ZipArchive();

		if ( true !== $arquivo->open( $zip ) ) {
			return '';
		}

		$itens = array();

		for ( $i = 0; $i < $arquivo->numFiles; $i++ ) {
			$estado = $arquivo->statIndex( $i );

			if ( ! is_array( $estado ) ) {
				continue;
			}

			$nome = (string) $estado['name'];

			if ( str_ends_with( $nome, '/' ) ) {
				continue;
			}

			$corte = strpos( $nome, '/' );
			$rel   = false === $corte ? $nome : substr( $nome, $corte + 1 );

			$conteudo = $arquivo->getFromIndex( $i );
			$itens[]  = $rel . ':' . hash( 'sha256', is_string( $conteudo ) ? $conteudo : '' );
		}

		$arquivo->close();

		sort( $itens );

		return array() === $itens ? '' : hash( 'sha256', implode( "\n", $itens ) );
	}

	/**
	 * Versão anunciada pelo CABEÇALHO de plugin dentro de um zip.
	 *
	 * Origem por URL não anuncia versão em lugar nenhum — o zip de código-fonte
	 * do GitHub não tem API que diga qual é. O número está dentro do artefato,
	 * no mesmo cabeçalho que o WordPress vai ler depois de instalar; lê-lo aqui
	 * é ler o artefato, e não presumir nada sobre ele.
	 *
	 * @param string $zip Caminho do zip.
	 * @return string Versão, ou vazio quando nenhum cabeçalho de plugin aparece.
	 */
	public static function versao_do_zip( string $zip ): string {
		if ( '' === $zip || ! is_readable( $zip ) || ! class_exists( 'ZipArchive' ) ) {
			return '';
		}

		$arquivo = new ZipArchive();

		if ( true !== $arquivo->open( $zip ) ) {
			return '';
		}

		$versao = '';

		for ( $i = 0; $i < $arquivo->numFiles; $i++ ) {
			$nome = (string) $arquivo->getNameIndex( $i );

			if ( ! str_ends_with( strtolower( $nome ), '.php' ) || substr_count( trim( $nome, '/' ), '/' ) > 1 ) {
				continue;
			}

			$conteudo = $arquivo->getFromIndex( $i, 8192 );

			if ( ! is_string( $conteudo ) || ! str_contains( $conteudo, 'Plugin Name:' ) ) {
				continue;
			}

			if ( 1 === preg_match( '/^[ \t\/*#@]*Version:\s*(.+)$/mi', $conteudo, $m ) ) {
				$versao = trim( (string) $m[1] );
				break;
			}
		}

		$arquivo->close();

		return $versao;
	}

	/**
	 * O artefato a instalar é IDÊNTICO ao que já está no disco?
	 *
	 * Duas condições, e as duas obrigatórias: a versão observada do instalado é
	 * igual à do artefato E o conteúdo bate por hash do diretório. Versão igual
	 * sozinha não prova nada (um zip republicado com a mesma versão muda o
	 * conteúdo), e hash sozinho decidiria por um artefato que ainda nem foi
	 * baixado. Quando as duas fecham, a troca é pulada — é a mesma regra do
	 * gravador, aplicada a diretório: **não se grava o que não mudou**, e cada
	 * troca pulada é um `.f3base-anterior-*` que não nasce.
	 *
	 * @param string $destino   Diretório instalado, absoluto.
	 * @param string $instalada Versão observada no disco.
	 * @param string $versao    Versão anunciada pelo artefato.
	 * @param string $zip       Caminho do zip local, quando houver.
	 * @return array{identico:bool,motivo:string}
	 */
	public static function artefato_identico( string $destino, string $instalada, string $versao, string $zip ): array {
		if ( '' === $instalada ) {
			return array(
				'identico' => false,
				'motivo'   => __( 'não há instalação anterior no disco: não existe "idêntico" a comparar.', 'f3base' ),
			);
		}

		/*
		 * Origem por URL não anuncia versão: ela mora no cabeçalho DENTRO do
		 * artefato já baixado, e é de lá que ela sai. Sem esta leitura, todo
		 * plugin de origem URL cairia no ramo "versão não anunciada" e a troca
		 * seria executada em toda execução — que é exatamente o crescimento sem
		 * teto que esta regra fecha.
		 */
		$versao = '' !== $versao ? $versao : self::versao_do_zip( $zip );

		if ( '' === $versao || $instalada !== $versao ) {
			return array(
				'identico' => false,
				'motivo'   => sprintf(
					/* translators: 1: versão instalada, 2: versão do artefato. */
					__( 'versão observada no disco (%1$s) e versão do artefato (%2$s) não são iguais: a troca é executada.', 'f3base' ),
					$instalada,
					'' !== $versao ? $versao : __( 'não anunciada', 'f3base' )
				),
			);
		}

		$hash_zip = self::impressao_de_zip( $zip );

		if ( '' === $hash_zip ) {
			return array(
				'identico' => false,
				'motivo'   => sprintf(
					/* translators: %s: versão. */
					__( 'as versões são iguais (%s) e o conteúdo do artefato não pôde ser lido para comparação por hash: sem as DUAS condições, a troca é executada — versão igual sozinha não prova conteúdo igual.', 'f3base' ),
					$instalada
				),
			);
		}

		$hash_disco = self::impressao_de_diretorio( $destino );

		if ( '' === $hash_disco ) {
			return array(
				'identico' => false,
				'motivo'   => __( 'o diretório instalado não pôde ser lido para comparação por hash: a troca é executada.', 'f3base' ),
			);
		}

		if ( $hash_zip !== $hash_disco ) {
			return array(
				'identico' => false,
				'motivo'   => sprintf(
					/* translators: 1: versão, 2: hash do artefato, 3: hash do instalado. */
					__( 'as versões são iguais (%1$s) e o CONTEÚDO difere — artefato %2$s, instalado %3$s: a troca é executada.', 'f3base' ),
					$instalada,
					substr( $hash_zip, 0, 12 ),
					substr( $hash_disco, 0, 12 )
				),
			);
		}

		return array(
			'identico' => true,
			'motivo'   => sprintf(
				/* translators: 1: versão, 2: hash comum. */
				__( 'artefato idêntico ao instalado: nenhuma troca executada. Versão observada e versão do artefato são %1$s e o conteúdo bate por hash do diretório (%2$s) — é a mesma regra do gravador aplicada a diretório: não se grava o que não mudou, e a troca pulada é um diretório preservado que não nasce.', 'f3base' ),
				$instalada,
				substr( $hash_zip, 0, 12 )
			),
		);
	}

	/**
	 * PODA declarada das cópias preservadas, por slug.
	 *
	 * Sete diretórios `.f3base-anterior-*` depois de quatro execuções, três
	 * novos por execução: preservar sem teto é crescimento sem teto. O teto é
	 * `plugins.backups_preservados` — configuração, nunca número escrito aqui
	 * dentro —, a poda é por SLUG (cada artefato tem a própria série) e as mais
	 * antigas saem primeiro, com journal e com o nome do que saiu na mensagem.
	 * Contagem sem nomes não responde à pergunta que o operador faz.
	 *
	 * @return array<string,mixed>
	 */
	public static function podar_backups(): array {
		$rotulo = 'plugins.backups_podados';
		$teto   = (int) F3Base_Imp_Decisoes::valor( 'plugins.backups_preservados' );
		$series = self::series_de_backup();
		$total  = 0;

		foreach ( $series as $copias ) {
			$total += count( $copias );
		}

		if ( 0 === $total ) {
			return self::saida(
				'OK',
				$rotulo,
				sprintf(
					/* translators: %d: teto declarado. */
					__( 'nenhuma cópia preservada em wp-content/plugins: nada a podar, e o teto declarado em plugins.backups_preservados é %d por slug.', 'f3base' ),
					$teto
				)
			);
		}

		$excedentes = array();

		foreach ( $series as $slug => $copias ) {
			$sobra = count( $copias ) - $teto;

			if ( $sobra <= 0 ) {
				continue;
			}

			foreach ( array_slice( $copias, 0, $sobra ) as $copia ) {
				$excedentes[] = array(
					'slug' => (string) $slug,
					'dir'  => (string) $copia,
				);
			}
		}

		if ( array() === $excedentes ) {
			return self::saida(
				'OK',
				$rotulo,
				sprintf(
					/* translators: 1: total de cópias, 2: teto declarado, 3: séries por slug. */
					__( '%1$d cópia(s) preservada(s) em disco, nenhuma acima do teto declarado de %2$d por slug: nada foi removido. Séries: %3$s', 'f3base' ),
					$total,
					$teto,
					self::descrever_series( $series )
				)
			);
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida(
				'N/A',
				$rotulo,
				sprintf(
					/* translators: 1: quantidade excedente, 2: teto, 3: nomes. */
					__( 'modo simulação: %1$d cópia(s) acima do teto de %2$d por slug seriam removidas, as mais antigas primeiro: %3$s. Nenhuma escrita.', 'f3base' ),
					count( $excedentes ),
					$teto,
					implode( ', ', array_map( static fn( array $e ): string => basename( (string) $e['dir'] ), $excedentes ) )
				)
			);
		}

		global $wp_filesystem;

		require_once ABSPATH . 'wp-admin/includes/file.php';

		if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
			WP_Filesystem();
		}

		if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				sprintf(
					/* translators: 1: quantidade excedente, 2: nomes. */
					__( 'pré-condição ausente: filesystem do WordPress indisponível, e nenhuma remoção é segura sem ele. %1$d cópia(s) acima do teto continuam em disco: %2$s', 'f3base' ),
					count( $excedentes ),
					implode( ', ', array_map( static fn( array $e ): string => basename( (string) $e['dir'] ), $excedentes ) )
				)
			);
		}

		$removidos = array();
		$falharam  = array();
		$estado    = 'OK';

		foreach ( $excedentes as $excedente ) {
			$dir  = (string) $excedente['dir'];
			$slug = (string) $excedente['slug'];

			if ( ! $wp_filesystem->delete( $dir, true ) ) {
				$falharam[] = basename( $dir );
				$estado     = F3Base_Imp_Relatorio::estado_mais_severo( $estado, 'WARN' );
				continue;
			}

			F3Base_Imp_Journal::registrar(
				F3Base_Imp_Journal::TIPO_ARQUIVO,
				$dir,
				array( 'diretorio' => $dir ),
				null,
				array(
					'acao' => self::INVERSA_PODAR,
					'de'   => $dir,
					'slug' => $slug,
				),
				array(
					'reversivel' => false,
					'motivo'     => sprintf(
						/* translators: 1: caminho removido, 2: slug, 3: teto declarado. */
						__( 'cópia preservada podada: %1$s saiu do disco por estar acima do teto de %3$d cópias por slug declarado em plugins.backups_preservados para %2$s. A poda é irreversível e o registro existe para que o operador saiba o que saiu.', 'f3base' ),
						$dir,
						$slug,
						$teto
					),
				)
			);

			$removidos[] = sprintf(
				/* translators: 1: nome do diretório removido, 2: slug do artefato. */
				__( '%1$s (série de %2$s)', 'f3base' ),
				basename( $dir ),
				$slug
			);
		}

		$restantes = self::series_de_backup();

		return self::saida(
			$estado,
			$rotulo,
			sprintf(
				/* translators: 1: quantidade removida, 2: nomes removidos, 3: teto, 4: séries restantes, 5: falhas. */
				__( 'poda declarada: %1$d cópia(s) preservada(s) removida(s), as mais antigas por slug primeiro — %2$s. Teto declarado em plugins.backups_preservados: %3$d por slug. Séries depois da poda: %4$s%5$s', 'f3base' ),
				count( $removidos ),
				array() === $removidos ? __( 'nenhuma', 'f3base' ) : implode( '; ', $removidos ),
				$teto,
				self::descrever_series( $restantes ),
				array() === $falharam
					? ''
					: sprintf(
						/* translators: %s: diretórios cuja remoção falhou. */
						__( ' NÃO removidas (falha do filesystem, e nenhum conteúdo ficou pela metade): %s.', 'f3base' ),
						implode( ', ', $falharam )
					)
			)
		);
	}

	/**
	 * Slug e carimbo de um nome de cópia preservada. FUNÇÃO PURA.
	 *
	 * O DEFEITO MEDIDO NA 1.0.14, e a razão desta função existir. O site real
	 * tinha em `wp-content/plugins/` o diretório
	 * `.f3base-anterior-f3base-site-core-f3base-anterior-1788152131-1788156801`:
	 * backup de um diretório que JÁ ERA backup. Cortar o slug no último traço
	 * dava `f3base-site-core-f3base-anterior-1788152131` — uma série PRÓPRIA,
	 * com uma cópia só, que nunca alcança o teto de 2 e portanto nunca poda. O
	 * log fechou com sete cópias preservadas e a frase "nada acima do teto",
	 * cada palavra verdadeira e a conclusão errada.
	 *
	 * A normalização: marca de backup EMBUTIDA no resto colapsa na série do
	 * slug real. Tudo a partir da marca é carimbo que nós mesmos escrevemos, e
	 * o aninhamento pode ter qualquer profundidade — o laço roda até o nome
	 * parar de mudar. O carimbo que sobrevive é o EXTERNO, que é quando aquela
	 * cópia foi criada.
	 *
	 * @param string $nome Nome do diretório, sem caminho.
	 * @return array{slug:string,quando:int}|array{} Vazio quando não é cópia preservada.
	 */
	public static function serie_do_nome( string $nome ): array {
		if ( ! str_starts_with( $nome, self::PREFIXO_BACKUP ) ) {
			return array();
		}

		$resto = substr( $nome, strlen( self::PREFIXO_BACKUP ) );
		$corte = strrpos( $resto, '-' );

		if ( false === $corte || 0 === $corte ) {
			return array();
		}

		$slug = self::slug_da_serie( substr( $resto, 0, $corte ) );

		if ( '' === $slug ) {
			return array();
		}

		return array(
			'slug'   => $slug,
			'quando' => (int) substr( $resto, $corte + 1 ),
		);
	}

	/**
	 * Colapsa a marca de backup embutida num slug. FUNÇÃO PURA.
	 *
	 * As duas grafias da marca entram: a de CONSTRUÇÃO, com o ponto na frente
	 * (`PREFIXO_BACKUP`), e a que os backups criados antes da 1.0.13 deixaram em
	 * disco, sem o ponto (`MARCA_ANTERIOR`). Reconhecer o nome antigo é
	 * obrigação da migração — quem o CONSTRÓI de novo é o que
	 * `pacote.backup_sempre_oculto` proíbe.
	 *
	 * @param string $slug Slug extraído do nome do diretório.
	 * @return string Slug do artefato real.
	 */
	public static function slug_da_serie( string $slug ): string {
		$marcas = array( self::PREFIXO_BACKUP, ltrim( self::MARCA_ANTERIOR, '-' ) );

		for ( $volta = 0; $volta < 8; $volta++ ) {
			$antes = $slug;

			/* Marca no INÍCIO: o nome inteiro é cópia de cópia. */
			foreach ( $marcas as $marca ) {
				if ( ! str_starts_with( $slug, $marca ) ) {
					continue;
				}

				$slug  = substr( $slug, strlen( $marca ) );
				$corte = strrpos( $slug, '-' );

				if ( false !== $corte && 0 !== $corte && ctype_digit( substr( $slug, $corte + 1 ) ) ) {
					$slug = substr( $slug, 0, $corte );
				}
			}

			/* Marca EMBUTIDA: `<slug real>-<marca><carimbo>`. */
			$posicao = false;

			foreach ( $marcas as $marca ) {
				$achou = strpos( $slug, '-' . $marca );

				if ( false !== $achou && ( false === $posicao || $achou < $posicao ) ) {
					$posicao = $achou;
				}
			}

			if ( false !== $posicao ) {
				$slug = substr( $slug, 0, $posicao );
			}

			if ( $antes === $slug ) {
				break;
			}
		}

		return $slug;
	}

	/**
	 * Cópias preservadas agrupadas por slug do artefato, das mais ANTIGAS às novas.
	 *
	 * O nome é montado por `caminho_do_backup()`. Ler o slug e o carimbo DALI é
	 * ler o que nós mesmos escrevemos — nada de inferir idade por `filemtime()`,
	 * que muda quando o sistema de arquivos quiser. A chave da série sai de
	 * `serie_do_nome()`, que normaliza o backup de backup: sem isso cada cópia
	 * aninhada virava série própria de uma cópia só e a poda nunca acontecia.
	 *
	 * @return array<string,array<int,string>> slug => caminhos absolutos.
	 */
	private static function series_de_backup(): array {
		$series = array();

		if ( ! is_dir( WP_PLUGIN_DIR ) ) {
			return $series;
		}

		foreach ( (array) scandir( WP_PLUGIN_DIR ) as $nome ) {
			$nome = (string) $nome;

			if ( ! is_dir( WP_PLUGIN_DIR . '/' . $nome ) ) {
				continue;
			}

			$serie = self::serie_do_nome( $nome );

			if ( array() === $serie ) {
				continue;
			}

			$slug   = (string) $serie['slug'];
			$quando = (int) $serie['quando'];

			$series[ $slug ]          = $series[ $slug ] ?? array();
			$series[ $slug ][ $nome ] = $quando;
		}

		foreach ( $series as $slug => $copias ) {
			asort( $copias );
			$series[ $slug ] = array_map(
				static fn( string $n ): string => WP_PLUGIN_DIR . '/' . $n,
				array_keys( $copias )
			);
		}

		ksort( $series );

		return $series;
	}

	/**
	 * Descreve as séries de cópias preservadas, nomeadas por slug.
	 *
	 * @param array<string,array<int,string>> $series Séries.
	 * @return string
	 */
	private static function descrever_series( array $series ): string {
		if ( array() === $series ) {
			return __( 'nenhuma', 'f3base' );
		}

		$partes = array();

		foreach ( $series as $slug => $copias ) {
			$partes[] = sprintf(
				/* translators: 1: slug, 2: quantidade, 3: nomes. */
				__( '%1$s: %2$d (%3$s)', 'f3base' ),
				(string) $slug,
				count( $copias ),
				implode( ', ', array_map( 'basename', $copias ) )
			);
		}

		return implode( ' | ', $partes );
	}

	/**
	 * Caminho da cópia preservada da instalação anterior.
	 *
	 * PONTO ÚNICO, e o PONTO NA FRENTE é o que resolve o defeito medido: a troca
	 * controlada deixava a versão anterior em
	 * `wp-content/plugins/<slug>-f3base-anterior-<ts>`, e o WordPress passava a
	 * enxergar aquilo como um plugin — o log de uma execução real listou
	 * `f3base-site-core-f3base-anterior-1788152131` entre os plugins com
	 * atualização automática ligada. `get_plugins()` PULA todo diretório cujo
	 * nome começa com ponto (e `search_theme_directories()` faz o mesmo com o
	 * tema), então a preimagem em disco continua existindo, continua legível
	 * para o operador, e some das listagens que só deveriam conter código em uso.
	 *
	 * @param string $destino Diretório que vai sair do lugar.
	 * @return string Caminho absoluto da cópia, irmão do destino.
	 */
	private static function caminho_do_backup( string $destino ): string {
		$destino = rtrim( str_replace( '\\', '/', $destino ), '/' );
		$pai     = dirname( $destino );
		$slug    = basename( $destino );

		return $pai . '/' . self::PREFIXO_BACKUP . $slug . '-' . time();
	}

	/**
	 * Troca controlada de diretório: nunca copiar arquivo a arquivo sobre código ativo.
	 *
	 * O novo é montado inteiro num temporário, validado, e só então o destino é
	 * renomeado (preimagem no journal) e o novo entra no lugar.
	 *
	 * @param string $origem  Diretório de origem, dentro do pacote.
	 * @param string $destino Diretório de destino.
	 * @param string $tipo    `plugin` ou `tema`, para a validação.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function trocar_diretorio( string $origem, string $destino, string $tipo ): array {
		global $wp_filesystem;

		require_once ABSPATH . 'wp-admin/includes/file.php';

		if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
			WP_Filesystem();
		}

		if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'filesystem do WordPress indisponível: nenhuma troca de diretório é segura sem ele.', 'f3base' ),
			);
		}

		/*
		 * MESMA REGRA DO GRAVADOR, aplicada a diretório: não se grava o que não
		 * mudou. Origem e destino são os dois diretórios, então a igualdade de
		 * hash já contém a igualdade de versão — a versão mora dentro dos
		 * arquivos que o hash cobre. Pular aqui é o que impede a troca de tema e
		 * de site-core de criar uma cópia preservada por execução mesmo quando
		 * nada mudou.
		 */
		$hash_origem  = self::impressao_de_diretorio( $origem );
		$hash_destino = self::impressao_de_diretorio( $destino );

		if ( '' !== $hash_origem && $hash_origem === $hash_destino ) {
			return array(
				'ok'     => true,
				'motivo' => sprintf(
					/* translators: 1: tipo, 2: hash comum. */
					__( 'artefato idêntico ao instalado: nenhuma troca executada (%1$s, conteúdo igual por hash do diretório: %2$s). Nenhuma cópia preservada foi criada.', 'f3base' ),
					$tipo,
					substr( $hash_origem, 0, 12 )
				),
			);
		}

		$trabalho = F3Base_Imp_Gravador::diretorio_trabalho( 'troca' );

		if ( '' === $trabalho ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'diretório de trabalho em uploads indisponível.', 'f3base' ),
			);
		}

		$temporario = $trabalho . basename( $destino ) . '-' . time();

		if ( ! copy_dir( $origem, $temporario ) && ! is_dir( $temporario ) ) {
			$wp_filesystem->mkdir( $temporario );

			$copiou = copy_dir( $origem, $temporario );

			if ( is_wp_error( $copiou ) ) {
				return array(
					'ok'     => false,
					'motivo' => $copiou->get_error_message(),
				);
			}
		}

		$valido = 'tema' === $tipo
			? file_exists( $temporario . '/style.css' )
			: (bool) glob( $temporario . '/*.php' );

		if ( ! $valido ) {
			$wp_filesystem->delete( $temporario, true );

			return array(
				'ok'     => false,
				'motivo' => 'tema' === $tipo
					? __( 'o diretório montado não tem style.css: instalação abortada antes de tocar no destino.', 'f3base' )
					: __( 'o diretório montado não tem arquivo PHP principal: instalação abortada antes de tocar no destino.', 'f3base' ),
			);
		}

		$anterior = '';

		if ( is_dir( $destino ) ) {
			$anterior = self::caminho_do_backup( $destino );

			if ( ! $wp_filesystem->move( $destino, $anterior, true ) ) {
				$wp_filesystem->delete( $temporario, true );

				return array(
					'ok'     => false,
					'motivo' => __( 'não foi possível mover o diretório ativo para o lado: nenhuma escrita sobre código em uso.', 'f3base' ),
				);
			}

			F3Base_Imp_Journal::registrar(
				F3Base_Imp_Journal::TIPO_ARQUIVO,
				$destino,
				array( 'movido_para' => $anterior ),
				array( 'origem' => $origem ),
				array(),
				array(
					'reversivel' => false,
					'motivo'     => sprintf(
						/* translators: %s: caminho da cópia anterior. */
						__( 'troca de diretório: a versão anterior ficou preservada em %s e a volta é operação de operador, fora da promessa automática de rollback.', 'f3base' ),
						$anterior
					),
				)
			);
		}

		if ( ! $wp_filesystem->move( $temporario, $destino, true ) ) {
			if ( '' !== $anterior ) {
				$wp_filesystem->move( $anterior, $destino, true );
			}

			return array(
				'ok'     => false,
				'motivo' => __( 'falha ao mover o diretório novo para o destino; o anterior foi recolocado.', 'f3base' ),
			);
		}

		/*
		 * O DIRETÓRIO ACABOU DE MUDAR NO DISCO, e o cache do núcleo ainda
		 * responde pelo estado anterior. A invalidação mora aqui, no ponto que
		 * trocou, e não no chamador: são três chamadores — tema, site-core e
		 * embarcado —, e chamador que esquece é o defeito voltando. Sem esta
		 * linha, a leitura de volta de uma INSTALAÇÃO LIMPA relê o negativo que
		 * a consulta prévia memorizou na mesma requisição e a unidade fecha
		 * FALHA sobre um artefato que está no lugar.
		 */
		self::invalidar_cache_do_artefato( $tipo );

		return array(
			'ok'     => true,
			'motivo' => '',
		);
	}

	/**
	 * Ativa um plugin pelo slug, com leitura de volta.
	 *
	 * @param string $slug Slug.
	 * @return array{estado:string,motivo:string}
	 */
	private static function ativar( string $slug ): array {
		$arquivo = self::arquivo_principal( $slug );

		if ( '' === $arquivo ) {
			return array(
				'estado' => 'FALHA',
				'motivo' => __( 'arquivo principal do plugin não encontrado para ativação.', 'f3base' ),
			);
		}

		if ( is_plugin_active( $arquivo ) ) {
			self::$ultimo_ativado = $slug;

			return array(
				'estado' => 'OK',
				'motivo' => __( 'já estava ativo.', 'f3base' ),
			);
		}

		$erro = activate_plugin( $arquivo );

		if ( is_wp_error( $erro ) ) {
			return array(
				'estado' => 'FALHA',
				'motivo' => sprintf(
					/* translators: %s: mensagem de erro. */
					__( 'falha ao ativar: %s', 'f3base' ),
					$erro->get_error_message()
				),
			);
		}

		$ativo = is_plugin_active( $arquivo );

		if ( $ativo ) {
			self::$ultimo_ativado = $slug;
		}

		return array(
			'estado' => $ativo ? 'OK' : 'FALHA',
			'motivo' => $ativo
				? __( 'ativado e conferido na leitura de volta.', 'f3base' )
				: __( 'a leitura de volta não confirmou a ativação.', 'f3base' ),
		);
	}

	/**
	 * Monta o resultado de uma unidade.
	 *
	 * @param string $estado Estado fechado.
	 * @param string $rotulo Nome da checagem.
	 * @param string $motivo Mensagem.
	 * @return array<string,mixed>
	 */
	private static function saida( string $estado, string $rotulo, string $motivo ): array {
		return array(
			'estado' => $estado,
			'rotulo' => $rotulo,
			'motivo' => $motivo,
			'id'     => 0,
		);
	}
}
