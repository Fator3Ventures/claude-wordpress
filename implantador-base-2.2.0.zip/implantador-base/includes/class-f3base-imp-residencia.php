<?php
/**
 * Produtor ÚNICO da resposta "em QUE arquivo esta chave mora".
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * O DEFEITO QUE ESTA CLASSE FECHA, medido num log de implantação real.
 *
 * Numa instalação limpa o relatório imprimiu, na linha da checagem do
 * controlador (que existiu até a 2.0.0): *"pré-condição ausente: 3 chave(s) de
 * contato.controlador está(ão) vazia(s) EM CONFIG/SITE.JSON — … Caminho de
 * saída: preencha … em config/site.json e execute de novo"*.
 *
 * `contato.controlador` não existe em `config/site.json`. Ele mora em
 * `config/projeto.json`, que é o arquivo do operador. Quem seguisse a instrução
 * editaria o arquivo errado e as chaves continuariam sem existir — a mensagem
 * que existe para desbloquear o operador era a que o prendia. A checagem saiu;
 * a regra de derivar o arquivo da chave fica, porque toda mensagem que nomeia
 * uma chave continua precisando dizer onde ela mora.
 *
 * A CAUSA NÃO ERA A FRASE, e é por isso que a correção é uma classe e não um
 * `sed`. O nome do arquivo estava DIGITADO dentro da mensagem: um fato sobre o
 * pacote escrito à mão num texto que nada revalida. É a mesma família de
 * defeito que este pacote recusa em todo lugar — versão repetida em constante,
 * decisão copiada como padrão de leitura, contrato de copy congelado no banco.
 * Migrar uma chave de arquivo é uma edição de JSON; a mensagem que a citava
 * continuaria dizendo o arquivo antigo, verde, para sempre.
 *
 * A MENSAGEM PASSA A PERGUNTAR. Quem sabe onde cada chave mora são os dois
 * leitores — `F3Base_Imp_Projeto` e `F3Base_Imp_Config` —, cada um dono do seu
 * arquivo e cada um capaz de listar o que declara. Esta classe cruza as duas
 * listas e devolve o arquivo; nem o nome do arquivo é escrito aqui, ele vem da
 * constante `ARQUIVO` de cada leitor. Trocar uma chave de arquivo passa a mudar
 * a mensagem sozinho, na mesma execução.
 *
 * O QUE ELA NÃO FAZ, e é declarado: ela não adivinha. Chave que nenhum dos dois
 * arquivos declara não recebe um palpite — a frase devolvida diz que o arquivo
 * é aquele em que a chave estiver declarada, e o caminho pontilhado continua
 * nomeado ao lado. Um palpite aqui seria o defeito de volta, com derivação no
 * nome.
 */
final class F3Base_Imp_Residencia {

	/**
	 * Os arquivos de configuração que DECLARAM uma chave.
	 *
	 * Devolve lista porque a resposta honesta pode ter zero ou dois elementos:
	 * `$schema` está nos dois arquivos, e uma chave recém-removida não está em
	 * nenhum. Quem responde ao operador precisa saber distinguir os três casos.
	 *
	 * @param string $caminho Caminho pontilhado da chave.
	 * @return array<int,string> Caminhos relativos dos arquivos, na ordem em que são consultados.
	 */
	public static function arquivos_da_chave( string $caminho ): array {
		$normalizado = F3Base_Imp_Config::normalizar( $caminho );

		if ( '' === $normalizado ) {
			return array();
		}

		$arquivos = array();

		foreach ( self::mapa() as $arquivo => $chaves ) {
			if ( in_array( $normalizado, $chaves, true ) ) {
				$arquivos[] = $arquivo;
			}
		}

		return $arquivos;
	}

	/**
	 * O arquivo de uma chave quando ele é ÚNICO; vazio quando não é.
	 *
	 * Zero e dois devolvem a mesma coisa — vazio — de propósito: nos dois casos
	 * não há um arquivo a nomear, e nomear um deles seria escolher por conta
	 * própria qual metade da verdade contar.
	 *
	 * @param string $caminho Caminho pontilhado da chave.
	 * @return string Caminho relativo do arquivo, ou vazio.
	 */
	public static function arquivo_da_chave( string $caminho ): string {
		$arquivos = self::arquivos_da_chave( $caminho );

		return 1 === count( $arquivos ) ? $arquivos[0] : '';
	}

	/**
	 * O TRECHO DE FRASE que diz onde preencher um conjunto de chaves.
	 *
	 * Sempre gramatical no lugar em que entra — depois de "preencha X …" e
	 * depois de "a chave X está vazia …" —, e sempre verdadeiro:
	 *
	 * - um arquivo só para todas as chaves: `em config/projeto.json`;
	 * - arquivos diferentes: cada um com as chaves que ele declara, para que
	 *   ninguém abra o arquivo certo procurando a chave que está no outro;
	 * - nenhuma residência derivável: `no arquivo de configuração em que ela
	 *   estiver declarada` — que não afirma arquivo nenhum. O caminho da chave
	 *   continua nomeado pela mensagem, e é ele que se procura.
	 *
	 * @param array<int,string> $caminhos Caminhos pontilhados das chaves citadas.
	 * @return string Trecho de frase, sem ponto final.
	 */
	public static function onde_preencher( array $caminhos ): string {
		$por_arquivo = array();

		foreach ( $caminhos as $caminho ) {
			$caminho = (string) $caminho;
			$arquivo = self::arquivo_da_chave( $caminho );

			if ( '' === $arquivo ) {
				continue;
			}

			$por_arquivo[ $arquivo ]   = $por_arquivo[ $arquivo ] ?? array();
			$por_arquivo[ $arquivo ][] = $caminho;
		}

		if ( array() === $por_arquivo ) {
			return __( 'no arquivo de configuração em que ela estiver declarada', 'f3base' );
		}

		if ( 1 === count( $por_arquivo ) ) {
			return sprintf(
				/* translators: %s: caminho relativo do arquivo de configuração. */
				__( 'em %s', 'f3base' ),
				(string) array_key_first( $por_arquivo )
			);
		}

		$partes = array();

		foreach ( $por_arquivo as $arquivo => $chaves ) {
			$partes[] = sprintf(
				/* translators: 1: caminho relativo do arquivo, 2: chaves que moram nele. */
				__( 'em %1$s (%2$s)', 'f3base' ),
				(string) $arquivo,
				implode( ', ', $chaves )
			);
		}

		return implode( __( ' e ', 'f3base' ), $partes );
	}

	/**
	 * Mapa arquivo => chaves declaradas, montado uma vez por requisição.
	 *
	 * A ORDEM É DELIBERADA: o arquivo do operador vem primeiro porque é ele que
	 * o operador abre. Ela não muda resposta nenhuma — chave em dois arquivos
	 * devolve vazio em `arquivo_da_chave()` —, muda só a ordem em que os dois
	 * aparecem quando a mensagem cita chaves de arquivos diferentes.
	 *
	 * @return array<string,array<int,string>>
	 */
	private static function mapa(): array {
		static $mapa = null;

		if ( null === $mapa ) {
			$mapa = array(
				F3Base_Imp_Projeto::ARQUIVO => F3Base_Imp_Projeto::chaves_declaradas(),
				F3Base_Imp_Config::ARQUIVO  => F3Base_Imp_Config::chaves_declaradas(),
			);
		}

		return $mapa;
	}
}
