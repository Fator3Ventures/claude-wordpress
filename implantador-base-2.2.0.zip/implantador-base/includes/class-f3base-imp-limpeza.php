<?php
/**
 * Limpeza dos PADRÕES da instalação limpa: temas e plugins que o WordPress traz
 * de fábrica e que este pacote não usa.
 *
 * O QUE ESTA UNIDADE FAZ, e desde quando. A 2.1.0 a criou por decisão do dono,
 * depois de uma implantação real (2026-09-07) entregar um site com os três temas
 * Twenty Twenty-Três/Quatro/Cinco, o Akismet e o Hello Dolly no lugar — código
 * que ninguém pediu, que o painel lista, que a atualização automática alcança e
 * que aparece em todo relatório de segurança como superfície instalada. O que
 * a instalação traz por padrão e o pacote não usa SAI, e sai nomeado.
 *
 * O QUE ELA NÃO FAZ, e cada limite é uma guarda medida na bancada:
 *
 * - NÃO remove o tema ATIVO, nem o tema PAI do ativo, ainda que estejam na
 *   lista: um tema de fábrica declarado na lista e em uso é um erro de quem
 *   declarou, e apagar o tema em uso derruba o site. A linha diz que o pulou.
 * - NÃO remove plugin que esteja ATIVO sem antes desativá-lo, e o desativa
 *   pela API do núcleo, para que os hooks de desativação rodem.
 * - NÃO remove o que a lista não declara. Plugin do cliente, tema de terceiro,
 *   nada disso é padrão da instalação limpa — o que é de alguém é de alguém.
 * - NÃO apaga por caminho montado à mão: quem apaga é `delete_theme()` e
 *   `delete_plugins()`, do núcleo, pelo mesmo filesystem que instalou.
 *
 * A REMOÇÃO É IRREVERSÍVEL, e o journal a registra como tal, com o motivo: um
 * tema de fábrica volta pelo repositório oficial em um clique, e é isso que a
 * entrada diz. O que se perde é o estado que alguém tivesse editado dentro de
 * um tema de fábrica — e quem edita tema de fábrica no lugar de um filho já
 * perdeu esse estado na primeira atualização automática.
 *
 * O TEMA-RESERVA DO NÚCLEO. `WP_DEFAULT_THEME` aponta para o Twenty Twenty-Cinco:
 * quando o tema ativo quebra, o núcleo cai nele. Com os três de fábrica fora,
 * não há para onde cair — e a decisão é essa mesma: um tema que quebra neste
 * pacote é defeito de release, medido antes de sair, e a reserva do núcleo era
 * um site alheio no ar com a cara de outro projeto. A linha diz isso.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Remove os padrões da instalação limpa declarados no catálogo.
 */
final class F3Base_Imp_Limpeza {

	/**
	 * Ações que a regra pura devolve.
	 */
	public const REMOVER = 'remover';
	public const PULAR   = 'pular';
	public const AUSENTE = 'ausente';

	/**
	 * O PLANO da limpeza — regra PURA, com teto e piso na bancada.
	 *
	 * Recebe o que foi MEDIDO (o que está instalado, o que está ativo, qual é o
	 * tema ativo e o pai dele) e o que foi DECLARADO (as duas listas do
	 * catálogo), e devolve, item a item, o que fazer e por quê.
	 *
	 * @param array<int,string> $temas_declarados   Slugs de tema a remover.
	 * @param array<int,string> $temas_instalados   Slugs de tema presentes no disco.
	 * @param string            $tema_ativo         Slug do tema ativo (stylesheet).
	 * @param string            $tema_pai           Slug do tema pai do ativo (template), ou o próprio ativo.
	 * @param array<int,string> $plugins_declarados Arquivos principais de plugin a remover (`pasta/arquivo.php` ou `arquivo.php`).
	 * @param array<int,string> $plugins_instalados Arquivos principais presentes, como `get_plugins()` os lista.
	 * @param array<int,string> $plugins_ativos     Arquivos principais ativos.
	 * @return array{temas:array<string,array{acao:string,motivo:string}>,plugins:array<string,array{acao:string,motivo:string,desativar:bool}>}
	 */
	public static function plano( array $temas_declarados, array $temas_instalados, string $tema_ativo, string $tema_pai, array $plugins_declarados, array $plugins_instalados, array $plugins_ativos ): array {
		$temas   = array();
		$plugins = array();

		foreach ( $temas_declarados as $slug ) {
			$slug = trim( (string) $slug );

			if ( '' === $slug ) {
				continue;
			}

			if ( ! in_array( $slug, $temas_instalados, true ) ) {
				$temas[ $slug ] = array(
					'acao'   => self::AUSENTE,
					'motivo' => __( 'não está instalado: nada a remover', 'f3base' ),
				);
				continue;
			}

			if ( $slug === $tema_ativo || $slug === $tema_pai ) {
				$temas[ $slug ] = array(
					'acao'   => self::PULAR,
					'motivo' => $slug === $tema_ativo
						? __( 'é o tema ATIVO, e o tema ativo nunca é removido — a lista o declara por engano', 'f3base' )
						: __( 'é o tema PAI do ativo, e o pai do ativo nunca é removido — a lista o declara por engano', 'f3base' ),
				);
				continue;
			}

			$temas[ $slug ] = array(
				'acao'   => self::REMOVER,
				'motivo' => __( 'tema de fábrica, instalado, inativo e não é pai do ativo', 'f3base' ),
			);
		}

		foreach ( $plugins_declarados as $arquivo ) {
			$arquivo = trim( (string) $arquivo );

			if ( '' === $arquivo ) {
				continue;
			}

			if ( ! in_array( $arquivo, $plugins_instalados, true ) ) {
				$plugins[ $arquivo ] = array(
					'acao'      => self::AUSENTE,
					'motivo'    => __( 'não está instalado: nada a remover', 'f3base' ),
					'desativar' => false,
				);
				continue;
			}

			$ativo = in_array( $arquivo, $plugins_ativos, true );

			$plugins[ $arquivo ] = array(
				'acao'      => self::REMOVER,
				'motivo'    => $ativo
					? __( 'plugin de fábrica, instalado e ATIVO: será desativado pela API do núcleo e removido', 'f3base' )
					: __( 'plugin de fábrica, instalado e inativo', 'f3base' ),
				'desativar' => $ativo,
			);
		}

		return array(
			'temas'   => $temas,
			'plugins' => $plugins,
		);
	}

	/**
	 * Aplica a limpeza declarada no catálogo, com leitura de volta.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	public static function aplicar(): array {
		$rotulo = 'limpeza.padroes_da_instalacao';

		$temas_declarados   = array_map( 'strval', (array) F3Base_Imp_Decisoes::valor( 'limpeza.temas_padrao' ) );
		$plugins_declarados = array_map( 'strval', (array) F3Base_Imp_Decisoes::valor( 'limpeza.plugins_padrao' ) );

		if ( array() === $temas_declarados && array() === $plugins_declarados ) {
			return self::saida(
				'N/A',
				$rotulo,
				__( 'condição de aplicabilidade falsa: limpeza.temas_padrao e limpeza.plugins_padrao estão vazias no catálogo, e sem lista declarada nada é removido — a limpeza só remove o que está declarado.', 'f3base' )
			);
		}

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		if ( ! function_exists( 'delete_theme' ) ) {
			require_once ABSPATH . 'wp-admin/includes/theme.php';
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';

		$tema_ativo = (string) get_option( 'stylesheet', '' );
		$tema_pai   = (string) get_option( 'template', $tema_ativo );

		$plano = self::plano(
			$temas_declarados,
			array_map( 'strval', array_keys( wp_get_themes() ) ),
			$tema_ativo,
			'' !== $tema_pai ? $tema_pai : $tema_ativo,
			$plugins_declarados,
			array_map( 'strval', array_keys( get_plugins() ) ),
			array_map( 'strval', (array) get_option( 'active_plugins', array() ) )
		);

		$removeria = array();

		foreach ( $plano['temas'] as $slug => $decisao ) {
			if ( self::REMOVER === $decisao['acao'] ) {
				$removeria[] = 'tema ' . $slug;
			}
		}

		foreach ( $plano['plugins'] as $arquivo => $decisao ) {
			if ( self::REMOVER === $decisao['acao'] ) {
				$removeria[] = 'plugin ' . $arquivo;
			}
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida(
				'N/A',
				$rotulo,
				sprintf(
					/* translators: %s: o que seria removido. */
					__( 'modo simulação: removeria %s. Nenhuma escrita.', 'f3base' ),
					array() === $removeria ? __( 'nada', 'f3base' ) : implode( ', ', $removeria )
				)
			);
		}

		$estado = 'OK';
		$partes = array();

		foreach ( $plano['temas'] as $slug => $decisao ) {
			if ( self::REMOVER !== $decisao['acao'] ) {
				$partes[] = sprintf(
					/* translators: 1: slug do tema, 2: motivo. */
					__( 'tema %1$s: %2$s', 'f3base' ),
					$slug,
					$decisao['motivo']
				);

				if ( self::PULAR === $decisao['acao'] ) {
					$estado = F3Base_Imp_Relatorio::estado_mais_severo( $estado, 'WARN' );
				}

				continue;
			}

			$resultado = delete_theme( $slug );

			if ( is_wp_error( $resultado ) ) {
				$estado   = F3Base_Imp_Relatorio::estado_mais_severo( $estado, 'FALHA' );
				$partes[] = sprintf(
					/* translators: 1: slug do tema, 2: erro. */
					__( 'tema %1$s: a remoção FALHOU — %2$s', 'f3base' ),
					$slug,
					$resultado->get_error_message()
				);
				continue;
			}

			/* Leitura de volta: o tema deixou de existir para o núcleo, e não só para este processo. */
			$relido = wp_get_theme( $slug );

			if ( $relido->exists() ) {
				$estado   = F3Base_Imp_Relatorio::estado_mais_severo( $estado, 'FALHA' );
				$partes[] = sprintf(
					/* translators: %s: slug do tema. */
					__( 'tema %s: delete_theme() não acusou erro e a leitura de volta AINDA o encontra no disco', 'f3base' ),
					$slug
				);
				continue;
			}

			F3Base_Imp_Journal::registrar(
				F3Base_Imp_Journal::TIPO_ARQUIVO,
				'tema:' . $slug,
				array( 'instalado' => true ),
				array( 'instalado' => false ),
				array(),
				array(
					'reversivel' => false,
					'motivo'     => __( 'tema de fábrica removido do disco; volta pelo repositório oficial do WordPress, em Aparência > Temas > Adicionar.', 'f3base' ),
				)
			);

			$partes[] = sprintf(
				/* translators: %s: slug do tema. */
				__( 'tema %s: removido e conferido na leitura de volta', 'f3base' ),
				$slug
			);
		}

		foreach ( $plano['plugins'] as $arquivo => $decisao ) {
			if ( self::REMOVER !== $decisao['acao'] ) {
				$partes[] = sprintf(
					/* translators: 1: arquivo do plugin, 2: motivo. */
					__( 'plugin %1$s: %2$s', 'f3base' ),
					$arquivo,
					$decisao['motivo']
				);
				continue;
			}

			if ( $decisao['desativar'] ) {
				deactivate_plugins( array( $arquivo ), true );
			}

			$resultado = delete_plugins( array( $arquivo ) );

			if ( is_wp_error( $resultado ) ) {
				$estado   = F3Base_Imp_Relatorio::estado_mais_severo( $estado, 'FALHA' );
				$partes[] = sprintf(
					/* translators: 1: arquivo do plugin, 2: erro. */
					__( 'plugin %1$s: a remoção FALHOU — %2$s', 'f3base' ),
					$arquivo,
					$resultado->get_error_message()
				);
				continue;
			}

			wp_clean_plugins_cache( true );

			if ( isset( get_plugins()[ $arquivo ] ) ) {
				$estado   = F3Base_Imp_Relatorio::estado_mais_severo( $estado, 'FALHA' );
				$partes[] = sprintf(
					/* translators: %s: arquivo do plugin. */
					__( 'plugin %s: delete_plugins() não acusou erro e a leitura de volta AINDA o lista', 'f3base' ),
					$arquivo
				);
				continue;
			}

			F3Base_Imp_Journal::registrar(
				F3Base_Imp_Journal::TIPO_ARQUIVO,
				'plugin:' . $arquivo,
				array( 'instalado' => true ),
				array( 'instalado' => false ),
				array(),
				array(
					'reversivel' => false,
					'motivo'     => __( 'plugin de fábrica removido do disco; volta pelo repositório oficial do WordPress, em Plugins > Adicionar novo.', 'f3base' ),
				)
			);

			$partes[] = sprintf(
				/* translators: 1: arquivo do plugin, 2: se foi desativado antes. */
				__( 'plugin %1$s: %2$sremovido e conferido na leitura de volta', 'f3base' ),
				$arquivo,
				$decisao['desativar'] ? __( 'desativado pela API do núcleo, ', 'f3base' ) : ''
			);
		}

		$reserva_do_nucleo = defined( 'WP_DEFAULT_THEME' ) ? (string) WP_DEFAULT_THEME : '';

		if ( '' !== $reserva_do_nucleo && in_array( $reserva_do_nucleo, $temas_declarados, true ) && ! wp_get_theme( $reserva_do_nucleo )->exists() ) {
			$partes[] = sprintf(
				/* translators: %s: slug do tema-reserva do núcleo. */
				__( 'o tema-reserva do núcleo (WP_DEFAULT_THEME = %s) está entre os removidos: se o tema ativo quebrar, o núcleo não tem para onde cair — decisão declarada, porque um tema que quebra neste pacote é defeito de release medido antes de sair, e a reserva do núcleo era um site alheio no ar', 'f3base' ),
				$reserva_do_nucleo
			);
		}

		return self::saida( $estado, $rotulo, implode( ' | ', $partes ) );
	}

	/**
	 * Monta a saída padrão de uma etapa.
	 *
	 * @param string $estado Estado.
	 * @param string $rotulo Rótulo.
	 * @param string $motivo Motivo.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function saida( string $estado, string $rotulo, string $motivo ): array {
		return array(
			'estado' => $estado,
			'rotulo' => $rotulo,
			'motivo' => $motivo,
		);
	}
}
