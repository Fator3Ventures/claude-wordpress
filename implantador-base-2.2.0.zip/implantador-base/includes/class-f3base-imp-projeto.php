<?php
/**
 * Produtor ÚNICO do arquivo do projeto.
 *
 * @package F3Base_Implantador
 */

defined( 'ABSPATH' ) || exit;

/**
 * O ARQUIVO QUE O OPERADOR ABRE, e por que ele é separado.
 *
 * `config/projeto.json` guarda o que ESTE site tem de decidir, e nada mais.
 * Decisão do pacote — valor com uma resposta certa só — mora em
 * `config/decisoes.tsv`. Fato da história do pacote mora em
 * `config/releases-suportadas.tsv`. Conteúdo e referência interna moram em
 * `config/site.json`.
 *
 * A separação não é organização de gaveta: um arquivo que mistura as quatro
 * naturezas obriga quem o abre a descobrir, chave por chave, qual delas ele tem
 * o direito de responder — e a resposta errada não falha, ela entrega um site
 * diferente do que alguém queria, sem aviso.
 *
 * ESTA CLASSE É O ÚNICO LEITOR do arquivo, pelo mesmo motivo que
 * `F3Base_Imp_Decisoes` é o único do catálogo. A validação é DELEGADA a
 * `F3Base_Imp_Config::validar_contra()`: um segundo validador seria um segundo
 * conjunto de regras divergindo do primeiro no dia em que alguém corrigisse só
 * um.
 */
class F3Base_Imp_Projeto {

	/**
	 * Caminho do arquivo, relativo à raiz do pacote.
	 *
	 * @var string
	 */
	public const ARQUIVO = 'config/projeto.json';

	/**
	 * Caminho do schema, relativo à raiz do pacote.
	 *
	 * @var string
	 */
	public const SCHEMA = 'config/projeto.schema.json';

	/**
	 * Dados decodificados, ou null antes da carga.
	 *
	 * @var array<string,mixed>|null
	 */
	private static $dados = null;

	/**
	 * Erros de carga e validação.
	 *
	 * @var array<int,string>
	 */
	private static array $erros = array();

	/**
	 * Carrega e valida o arquivo do projeto. Idempotente por requisição.
	 *
	 * @return bool Verdadeiro quando o arquivo carregou E validou.
	 */
	public static function carregar(): bool {
		if ( null !== self::$dados ) {
			return array() === self::$erros;
		}

		self::$dados = array();
		self::$erros = array();

		$caminho = f3base_imp_caminho( self::ARQUIVO );

		if ( '' === $caminho || ! is_readable( $caminho ) ) {
			self::$erros[] = sprintf(
				/* translators: %s: caminho relativo do arquivo do projeto. */
				__( 'Arquivo do projeto ausente ou ilegível: %s', 'f3base' ),
				self::ARQUIVO
			);

			return false;
		}

		$bruto = file_get_contents( $caminho ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- arquivo do próprio pacote, sem rede.

		if ( ! is_string( $bruto ) ) {
			self::$erros[] = sprintf(
				/* translators: %s: caminho relativo do arquivo do projeto. */
				__( 'Falha ao ler o arquivo do projeto: %s', 'f3base' ),
				self::ARQUIVO
			);

			return false;
		}

		$decodificado = json_decode( $bruto, true );

		if ( ! is_array( $decodificado ) ) {
			self::$erros[] = sprintf(
				/* translators: 1: caminho do arquivo, 2: mensagem do decodificador. */
				__( 'JSON inválido em %1$s: %2$s', 'f3base' ),
				self::ARQUIVO,
				json_last_error_msg()
			);

			return false;
		}

		self::$dados = $decodificado;

		foreach ( F3Base_Imp_Config::validar_contra( $decodificado, self::SCHEMA ) as $erro ) {
			self::$erros[] = $erro;
		}

		return array() === self::$erros;
	}

	/**
	 * Erros de carga e validação.
	 *
	 * @return string[]
	 */
	public static function erros(): array {
		self::carregar();

		return self::$erros;
	}

	/**
	 * O valor de um caminho pontilhado do arquivo do projeto.
	 *
	 * O padrão chega por parâmetro e é o que o chamador faz quando o arquivo não
	 * responde. Ele NUNCA deve coincidir com um valor plausível do campo:
	 * coincidir seria a segunda fonte que este pacote persegue, e foi o defeito
	 * que a fatia das decisões encontrou em 42 leituras.
	 *
	 * @param string $caminho Caminho pontilhado.
	 * @param mixed  $padrao  Valor devolvido quando o caminho não existe.
	 * @return mixed
	 */
	public static function obter( string $caminho, $padrao ) {
		self::carregar();

		$no = self::$dados;

		foreach ( self::segmentos( $caminho ) as $segmento ) {
			if ( is_array( $no ) && array_key_exists( $segmento, $no ) ) {
				$no = $no[ $segmento ];
				continue;
			}

			return $padrao;
		}

		return $no;
	}

	/**
	 * Verdadeiro quando o caminho existe no arquivo do projeto.
	 *
	 * @param string $caminho Caminho pontilhado.
	 * @return bool
	 */
	public static function existe( string $caminho ): bool {
		$sentinela = new stdClass();

		return $sentinela !== self::obter( $caminho, $sentinela );
	}

	/**
	 * Uma lista do arquivo do projeto; array vazio quando ausente ou não-lista.
	 *
	 * @param string $caminho Caminho pontilhado.
	 * @return array<int|string,mixed>
	 */
	public static function lista( string $caminho ): array {
		$valor = self::obter( $caminho, array() );

		return is_array( $valor ) ? $valor : array();
	}

	/**
	 * Todas as chaves declaradas no arquivo do projeto, na forma normalizada.
	 *
	 * O achatamento é DELEGADO a `F3Base_Imp_Config::caminhos_de()` pelo mesmo
	 * motivo que a validação é: normalizar de outro jeito aqui faria a mesma
	 * chave ter dois nomes conforme o arquivo em que estivesse, e é justamente
	 * comparando as duas listas que `F3Base_Imp_Residencia` responde em qual
	 * arquivo cada chave mora.
	 *
	 * @return string[] Caminhos com `*` no lugar de índice numérico, ordenados.
	 */
	public static function chaves_declaradas(): array {
		self::carregar();

		return F3Base_Imp_Config::caminhos_de( is_array( self::$dados ) ? self::$dados : array() );
	}

	/**
	 * Os SEGMENTOS de um caminho pontilhado, com índice numérico convertido.
	 *
	 * @param string $caminho Caminho pontilhado.
	 * @return array<int,int|string>
	 */
	private static function segmentos( string $caminho ): array {
		$saida = array();

		foreach ( explode( '.', $caminho ) as $bruto ) {
			$bruto = trim( $bruto );

			if ( '' === $bruto ) {
				continue;
			}

			$saida[] = ctype_digit( $bruto ) ? (int) $bruto : $bruto;
		}

		return $saida;
	}
}
