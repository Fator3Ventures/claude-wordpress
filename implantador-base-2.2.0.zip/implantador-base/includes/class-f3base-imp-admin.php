<?php
/**
 * Superfície de administração.
 *
 * Regra dura, medida em produção: **o resultado é renderizado INLINE na resposta
 * do `admin-post.php`, nunca por redirect de volta à página do menu.** O plugin
 * se autodesativa no sucesso da aplicação, e a página do menu deixa de existir
 * no exato instante em que o redirect voltaria para ela — o operador receberia
 * "Sem permissão para acessar esta página" em vez do log que ele precisa ler.
 *
 * O botão de download é **gerado no navegador a partir do log renderizado**:
 * endpoint do próprio implantador morre com a autodesativação, então servir o
 * arquivo por rota dele seria oferecer um link que quebra exatamente no caso de
 * sucesso.
 *
 * A ativação abre a tela sozinha (transient + redirect em `admin_init` com
 * prioridade 1) e a lista de plugins ganha o link "Abrir implantação": o
 * operador nunca procura onde o plugin mora.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Menu, tela orquestradora e tela de resultado.
 */
final class F3Base_Imp_Admin {

	/**
	 * Ação do nonce do formulário de início.
	 */
	public const NONCE_INICIAR = 'f3base_imp_iniciar';

	/**
	 * Ação do nonce do rollback.
	 */
	public const NONCE_REVERTER = 'f3base_imp_reverter';

	/**
	 * Registra a página da ferramenta.
	 *
	 * @return void
	 */
	public static function menu(): void {
		add_management_page(
			__( 'Implantação F3', 'f3base' ),
			__( 'Implantação F3', 'f3base' ),
			'manage_options',
			F3BASE_IMP_SLUG_TELA,
			array( __CLASS__, 'tela' )
		);
	}

	/**
	 * Abre a tela sozinha depois da ativação.
	 *
	 * @return void
	 */
	public static function abrir_apos_ativacao(): void {
		if ( ! get_transient( 'f3base_imp_abrir_tela' ) ) {
			return;
		}

		delete_transient( 'f3base_imp_abrir_tela' );

		if ( ! current_user_can( 'manage_options' ) || wp_doing_ajax() ) {
			return;
		}

		if ( isset( $_GET['activate-multi'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- leitura do fluxo de ativação do core, sem mutação.
			return;
		}

		wp_safe_redirect( admin_url( 'tools.php?page=' . F3BASE_IMP_SLUG_TELA ) );
		exit;
	}

	/**
	 * Acrescenta o link "Abrir implantação" na lista de plugins.
	 *
	 * @param array<int|string,string> $links Links existentes.
	 * @return array<int|string,string>
	 */
	public static function link_abrir( $links ) {
		if ( ! is_array( $links ) ) {
			return $links;
		}

		$novo = sprintf(
			'<a href="%s"><strong>%s</strong></a>',
			esc_url( admin_url( 'tools.php?page=' . F3BASE_IMP_SLUG_TELA ) ),
			esc_html__( 'Abrir implantação', 'f3base' )
		);

		array_unshift( $links, $novo );

		return $links;
	}

	/**
	 * Tela do menu: escolha do modo.
	 *
	 * @return void
	 */
	public static function tela(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sem permissão para acessar esta página.', 'f3base' ) );
		}

		$valida     = F3Base_Imp_Config::carregar();
		$erros      = F3Base_Imp_Config::erros();
		$estado     = (string) get_option( F3Base_Imp_Lotes::OPTION_ESTADO, F3Base_Imp_Lotes::PRONTO );
		$checkpoint = get_option( F3Base_Imp_Lotes::OPTION_CHECKPOINT, array() );

		echo '<div class="wrap">';
		printf( '<h1>%s</h1>', esc_html__( 'Implantação F3', 'f3base' ) );

		printf(
			'<p>%s</p>',
			esc_html(
				sprintf(
					/* translators: 1: identidade da release, 2: versão do implantador, 3: hash da configuração. */
					__( 'Release %1$s · implantador %2$s · configuração %3$s', 'f3base' ),
					(string) F3Base_Imp_Config::obter( 'release.identidade', '—' ),
					f3base_imp_versao(),
					substr( F3Base_Imp_Config::hash(), 0, 12 )
				)
			)
		);

		printf(
			'<p><strong>%s</strong> %s</p>',
			esc_html__( 'Estado da aplicação:', 'f3base' ),
			esc_html( $estado )
		);

		if ( is_array( $checkpoint ) && isset( $checkpoint['unidade'] ) ) {
			printf(
				'<p>%s</p>',
				esc_html(
					sprintf(
						/* translators: 1: etapa, 2: unidade, 3: estado, 4: data. */
						__( 'Último checkpoint — etapa %1$s, unidade %2$d, estado %3$s, em %4$s. A retomada continua daí, e só com a mesma release e o mesmo hash de configuração.', 'f3base' ),
						isset( $checkpoint['etapa'] ) ? (string) $checkpoint['etapa'] : '—',
						isset( $checkpoint['unidade'] ) ? (int) $checkpoint['unidade'] : 0,
						isset( $checkpoint['estado'] ) ? (string) $checkpoint['estado'] : '—',
						isset( $checkpoint['em'] ) ? (string) wp_date( 'Y-m-d H:i', (int) $checkpoint['em'] ) : '—'
					)
				)
			);
		}

		if ( ! $valida ) {
			echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'A configuração não validou contra o schema. Nenhum modo é oferecido enquanto isso não fechar:', 'f3base' ) . '</strong></p><ul>';

			foreach ( $erros as $erro ) {
				printf( '<li><code>%s</code></li>', esc_html( $erro ) );
			}

			echo '</ul></div></div>';

			return;
		}

		$modos = array(
			F3Base_Imp_Lotes::MODO_RELATORIO => array(
				__( 'Somente relatório', 'f3base' ),
				__( 'Lê e compara o estado desejado, o último aplicado e o observado. Não grava nada. É o modo que roda em produção ANTES da primeira execução real.', 'f3base' ),
			),
			F3Base_Imp_Lotes::MODO_SIMULACAO => array(
				__( 'Simulação', 'f3base' ),
				__( 'Relata o que faria, unidade por unidade, sem gravar. Cada linha sai como N/A com a condição declarada.', 'f3base' ),
			),
			F3Base_Imp_Lotes::MODO_EXECUCAO  => array(
				__( 'Execução', 'f3base' ),
				__( 'Aplica o estado desejado em lotes, com journal, leitura de volta e checkpoint. Em sucesso integral e sem entregável em BLOCKED, o plugin se autodesativa.', 'f3base' ),
			),
		);

		foreach ( $modos as $modo => $texto ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:1.5em 0;">';
			wp_nonce_field( self::NONCE_INICIAR );
			printf( '<input type="hidden" name="action" value="%s" />', esc_attr( 'f3base_imp_iniciar' ) );
			printf( '<input type="hidden" name="modo" value="%s" />', esc_attr( $modo ) );
			printf( '<h2>%s</h2>', esc_html( $texto[0] ) );
			printf( '<p>%s</p>', esc_html( $texto[1] ) );
			printf(
				'<button type="submit" class="button %s">%s</button>',
				esc_attr( F3Base_Imp_Lotes::MODO_EXECUCAO === $modo ? 'button-primary' : 'button-secondary' ),
				esc_html(
					sprintf(
						/* translators: %s: nome do modo. */
						__( 'Iniciar: %s', 'f3base' ),
						$texto[0]
					)
				)
			);
			echo '</form>';
		}

		echo '<hr />';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( self::NONCE_REVERTER );
		printf( '<input type="hidden" name="action" value="%s" />', esc_attr( 'f3base_imp_reverter' ) );
		printf( '<h2>%s</h2>', esc_html__( 'Rollback pelo journal', 'f3base' ) );
		printf(
			'<p>%s</p>',
			esc_html__( 'Desfaz as mutações reversíveis da última execução, na ordem inversa, conferindo cada reversão pela leitura de volta. Ações declaradas irreversíveis ficam de fora, nomeadas.', 'f3base' )
		);
		printf(
			'<button type="submit" class="button button-secondary">%s</button>',
			esc_html__( 'Reverter a última execução', 'f3base' )
		);
		echo '</form>';

		echo '</div>';
	}

	/**
	 * Inicia a execução e renderiza a tela orquestradora INLINE.
	 *
	 * @return void
	 */
	public static function iniciar(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sem permissão para executar a implantação.', 'f3base' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( self::NONCE_INICIAR );

		$modo = isset( $_POST['modo'] ) ? sanitize_key( wp_unslash( (string) $_POST['modo'] ) ) : F3Base_Imp_Lotes::MODO_SIMULACAO;
		$modo = in_array( $modo, F3Base_Imp_Lotes::modos(), true ) ? $modo : F3Base_Imp_Lotes::MODO_SIMULACAO;

		$execucao = 'exec' . gmdate( 'YmdHis' ) . wp_generate_password( 6, false, false );
		$execucao = sanitize_key( $execucao );

		self::renderizar_orquestradora( $modo, $execucao );
	}

	/**
	 * Executa o rollback e renderiza o resultado INLINE.
	 *
	 * @return void
	 */
	public static function reverter(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sem permissão para reverter a implantação.', 'f3base' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( self::NONCE_REVERTER );

		F3Base_Imp_Config::carregar();
		F3Base_Imp_Relatorio::carregar();

		$resultado = F3Base_Imp_Lotes::reverter();

		self::abrir_documento( __( 'Rollback da implantação', 'f3base' ) );

		printf( '<h1>%s</h1>', esc_html__( 'Rollback pelo journal', 'f3base' ) );
		printf(
			'<p>%s</p>',
			esc_html(
				sprintf(
					/* translators: 1: revertidas, 2: falhas, 3: irreversíveis. */
					__( '%1$d mutação(ões) revertidas. Falhas: %2$d. Fora da promessa de rollback, por declaração: %3$d.', 'f3base' ),
					(int) $resultado['revertidas'],
					count( $resultado['falhas'] ),
					count( $resultado['irreversiveis'] )
				)
			)
		);

		foreach ( array( 'falhas', 'irreversiveis' ) as $grupo ) {
			if ( array() === $resultado[ $grupo ] ) {
				continue;
			}

			printf( '<h2>%s</h2><ul>', esc_html( 'falhas' === $grupo ? __( 'Falhas de reversão', 'f3base' ) : __( 'Declaradas irreversíveis', 'f3base' ) ) );

			foreach ( $resultado[ $grupo ] as $linha ) {
				printf( '<li>%s</li>', esc_html( (string) $linha ) );
			}

			echo '</ul>';
		}

		/*
		 * `details` e `summary` entram na allow-list EXPLICITAMENTE. O log fica
		 * recolhido dentro deles, e uma versão do WordPress cujo `wp_kses_post`
		 * ainda não os conheça os removeria — deixando o log inteiro aberto na
		 * tela, que é exatamente o oposto do que esta separação faz.
		 */
		$permitidos            = wp_kses_allowed_html( 'post' );
		$permitidos['details'] = array( 'class' => true, 'open' => true );
		$permitidos['summary'] = array( 'class' => true );

		echo wp_kses( F3Base_Imp_Relatorio::html(), $permitidos );

		self::fechar_documento();
	}

	/**
	 * Renderiza a tela orquestradora — resposta direta, sem redirect.
	 *
	 * @param string $modo     Modo.
	 * @param string $execucao Identificador da execução.
	 * @return void
	 */
	private static function renderizar_orquestradora( string $modo, string $execucao ): void {
		F3Base_Imp_Config::carregar();

		$total = count( F3Base_Imp_Lotes::unidades() );

		self::abrir_documento( __( 'Implantação em andamento', 'f3base' ) );

		printf( '<h1>%s</h1>', esc_html__( 'Implantação F3', 'f3base' ) );

		printf(
			'<p class="f3base-imp-cabecalho">%s</p>',
			esc_html(
				sprintf(
					/* translators: 1: modo, 2: release, 3: hash, 4: identificador da execução, 5: total de unidades. */
					__( 'Modo %1$s · release %2$s · configuração %3$s · execução %4$s · %5$d unidades idempotentes, uma por lote.', 'f3base' ),
					$modo,
					(string) F3Base_Imp_Config::obter( 'release.identidade', '—' ),
					substr( F3Base_Imp_Config::hash(), 0, 12 ),
					$execucao,
					$total
				)
			)
		);

		printf(
			'<div id="f3base-imp" data-endpoint="%1$s" data-nonce="%2$s" data-modo="%3$s" data-execucao="%4$s" data-total="%5$d" data-sentinela="%6$s" data-sentinela-inicio="%7$s" data-rotulo-etapa="%8$s" data-rotulo-erro="%9$s" data-rotulo-download="%10$s" data-rotulo-fim="%11$s" data-rotulo-sequestro="%12$s" data-rotulo-fatal="%13$s" data-rotulo-rede="%14$s" data-rotulo-nao-executada="%15$s" data-rotulo-repetindo="%16$s" data-rotulo-ultimo-plugin="%17$s" data-rotulo-sem-plugin="%18$s" data-rotulo-cadeia="%19$s" data-rotulo-supressao-sugerida="%20$s" data-rotulo-escopos="%21$s" data-rotulo-nomes="%22$s" data-rotulo-resumidas="%23$s" data-rotulo-nenhum="%24$s" data-marca-interna="%25$s" data-rotulo-lock="%26$s" data-rotulo-sem-nome="%27$s" data-rotulo-plano-parado="%28$s" data-rotulo-fora-do-plano="%29$s" data-rotulo-aplicacao="%30$s" data-rotulo-encerrada="%31$s" data-rotulo-regiao-final="%32$s" data-rotulo-onde-esta-o-resumo="%33$s" data-estados-aplicacao="%34$s" data-fecho-reserva="%35$s"></div>',
			esc_url( admin_url( 'admin-post.php' ) ),
			esc_attr( wp_create_nonce( F3Base_Imp_Lotes::NONCE ) ),
			esc_attr( $modo ),
			esc_attr( $execucao ),
			(int) $total,
			esc_attr( F3Base_Imp_Lotes::SENTINELA ),
			esc_attr( F3Base_Imp_Lotes::SENTINELA_INICIO ),
			esc_attr__( 'Etapa %1$d de %2$d', 'f3base' ),
			esc_attr__( 'Resposta não interpretável do servidor.', 'f3base' ),
			esc_attr__( 'Baixar o log desta execução', 'f3base' ),
			esc_attr__( 'Execução concluída.', 'f3base' ),
			esc_attr__( 'A requisição foi REDIRECIONADA POR UM PLUGIN DE TERCEIRO antes de chegar ao implantador: o assistente dele roda em admin_init, que acontece antes do admin_post do lote.', 'f3base' ),
			esc_attr__( 'A requisição chegou ao implantador e o lote morreu no meio: erro fatal antes do JSON final.', 'f3base' ),
			esc_attr__( 'A resposta não veio do implantador nem do wp-admin: resposta de rede ou de proxy.', 'f3base' ),
			esc_attr__( 'Esta unidade NÃO foi executada e não tem checkpoint: a retomada precisa incluí-la.', 'f3base' ),
			esc_attr__( 'Repetindo a MESMA unidade uma vez, porque ela não chegou a rodar.', 'f3base' ),
			esc_attr__( 'Último plugin ativado antes desta requisição: %1$s.', 'f3base' ),
			esc_attr__( 'nenhum plugin foi ativado nesta execução', 'f3base' ),
			esc_attr__( 'BLOCKED registrado. A execução SEGUE nas unidades independentes: só o fecho de dependência declarada desta unidade é suspenso, e cada suspensa sai no log nomeando quem a suspendeu.', 'f3base' ),
			/*
			 * COMPORTAMENTO ESPERADO, e a linha fecha OK — 2.1.0. A repetição da
			 * unidade funcionou e a execução seguiu: um plugin que decide o
			 * próprio assistente em admin_init sequestra a requisição seguinte
			 * à ativação, o cliente detecta pelo discriminante e repete a MESMA
			 * unidade uma vez. Até a 2.0.0 isso saía como WARN duas vezes por
			 * execução, sobre um evento que acontecia em toda instalação limpa
			 * e nunca impediu nada. O mapa plugins.supressao_onboarding aceita
			 * option E transiente (a entrada do wp-mcp-ultimate apaga o
			 * transiente na mesma unidade que ativa), e é por ele que a ida e
			 * volta deixa de acontecer; quando acontece mesmo assim, é
			 * observação, não defeito.
			 */
			esc_attr__( 'A requisição seguinte à ativação foi sequestrada pelo assistente do plugin %1$s (redirecionamento em admin_init) e a MESMA unidade foi repetida uma vez, com sucesso. É o comportamento esperado de um assistente decidido antes do handler do lote, e não impede nada. Uma entrada em plugins.supressao_onboarding para esse slug — option ou transiente, lidos do código do plugin — evita a ida e volta.', 'f3base' ),
			/*
			 * TRÊS ESCOPOS, e cada número diz o que conta. Sem isso, `FALHA: 7`
			 * na barra, `5 FALHA` no encerramento e 2 linhas visíveis com FALHA
			 * eram três respostas contraditórias para a mesma pergunta — e eram
			 * as três corretas, cada uma sobre um escopo que ninguém declarava.
			 */
			esc_attr__( 'Contagens por escopo, cada número dizendo o que conta — checagens do relatório (uma linha por checagem emitida no servidor, inclusive as que rodam dentro de uma unidade): %1$s FALHA e %2$s BLOCKED · unidades do plano (uma por lote): %3$s FALHA e %4$s BLOCKED · linhas renderizadas nesta tela (uma por unidade, as checagens internas nomeadas e as do cliente): %5$s FALHA e %6$s BLOCKED.', 'f3base' ),
			/*
			 * CONTAGEM E LISTA DE NOMES SAEM JUNTAS. O cabeçalho dizia "5 FALHA
			 * e 6 BLOCKED" em checagens enquanto a tela mostrava UMA unidade em
			 * FALHA: as outras rodavam DENTRO de unidades que fecharam OK e não
			 * tinham linha nenhuma. Número sem nome não responde à pergunta que
			 * o operador faz em seguida, que é "quais?".
			 */
			esc_attr__( 'Nomes do que NÃO fechou OK, por estado — checagens do relatório: %1$s · unidades do plano: %2$s · linhas desta tela: %3$s.', 'f3base' ),
			esc_attr__( 'Checagens OK dentro de unidades, resumidas por desenho: %1$s.', 'f3base' ),
			esc_attr__( 'nenhum', 'f3base' ),
			/* Marca da linha indentada: a checagem que rodou DENTRO da unidade acima. */
			esc_attr( '↳ ' ),
			/*
			 * REJEIÇÃO DE LOCK, e ela PARA a tela na primeira ocorrência. A
			 * pergunta do operador é uma só — quanto esperar —, e a linha
			 * responde com os quatro fatos que o servidor mediu, inclusive o
			 * horário exato em que o lock passa a ser assumível. A 1.0.15
			 * imprimia a mesma frase 163 vezes em 90 segundos e não respondia
			 * nenhuma delas.
			 */
			esc_attr__( 'Execução concorrente: o lock pertence a %1$s, com heartbeat há %2$s segundos (TTL %3$ss). Este lote NÃO rodou e nada foi medido. O lock passa a ser considerado ABANDONADO às %4$s: a partir daí, executar de novo assume o lock automaticamente, sem passo manual. A tela PARA aqui — repetir antes disso só produz esta mesma linha.', 'f3base' ),
			/* Nome de reserva: linha que não fecha OK nunca sai anônima da tela. */
			esc_attr__( 'lote.linha_sem_nome', 'f3base' ),
			esc_attr__( 'A resposta NÃO avançou o plano: o servidor respondeu sobre o lote %1$s enquanto o pedido era o lote %2$s. A tela para aqui, porque avançar o contador sobre resposta que não avançou o plano é contar requisição em vez de unidade.', 'f3base' ),
			esc_attr__( 'Pedido de lote FORA DO PLANO: índice %1$s com %2$s unidade(s) declarada(s). Nenhuma requisição foi enviada.', 'f3base' ),
			esc_attr__( 'estado da aplicação', 'f3base' ),
			esc_attr__( 'Execução encerrada sem concluir o plano.', 'f3base' ),
			/*
			 * NOME ACESSÍVEL DA REGIÃO DE ENCERRAMENTO. O resultado final deixou
			 * de ser escrito na barra de progresso — que é status ao vivo e mora
			 * no topo — e passou a morar no fim, depois do log. Região com nome é
			 * o que a torna alcançável pela navegação por regiões; o foco vai
			 * para ela no instante em que ela é escrita.
			 */
			esc_attr__( 'Resultado final da execução', 'f3base' ),
			/*
			 * E A LINHA CURTA DO TOPO DIZ ONDE ELE ESTÁ. Anunciar "terminou" sem
			 * dizer onde está a conclusão seria trocar um defeito de leitura por
			 * outro.
			 */
			esc_attr__( 'O resultado completo desta execução está no FIM desta página, logo depois do log.', 'f3base' ),
			/*
			 * Estados de aplicação ACEITOS pelo rodapé, declarados aqui e não no
			 * cliente: os da máquina, mais BLOCKED. BLOCKED é o fecho de uma
			 * execução que NÃO CHEGOU A RODAR — pré-condição ausente, nunca
			 * FALHA —, e ele não é gravado na option: a máquina continua com os
			 * seis estados dela.
			 */
			esc_attr( implode( ',', array_merge( F3Base_Imp_Lotes::estados(), array( F3Base_Imp_Relatorio::BLOCKED ) ) ) ),
			esc_attr( F3Base_Imp_Relatorio::BLOCKED )
		);

		printf(
			'<noscript><p class="f3base-imp-aviso">%s</p></noscript>',
			esc_html__( 'Esta tela avança por requisições sucessivas e depende de JavaScript. Sem ele, a implantação não prossegue — e o estado atual permanece intacto.', 'f3base' )
		);

		printf(
			'<script src="%s"></script>',
			esc_url( F3BASE_IMP_URL . 'includes/assets/implantador.js?ver=' . rawurlencode( f3base_imp_versao() ) )
		);

		self::fechar_documento();
	}

	/**
	 * Abre o documento HTML da resposta inline.
	 *
	 * @param string $titulo Título da página.
	 * @return void
	 */
	private static function abrir_documento( string $titulo ): void {
		if ( ! headers_sent() ) {
			header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );
			nocache_headers();
		}

		echo '<!DOCTYPE html><html ';
		language_attributes();
		echo '><head><meta charset="' . esc_attr( get_bloginfo( 'charset' ) ) . '" />';
		echo '<meta name="viewport" content="width=device-width, initial-scale=1" />';
		echo '<meta name="robots" content="noindex, nofollow" />';
		printf( '<title>%s</title>', esc_html( $titulo ) );
		printf(
			'<link rel="stylesheet" href="%s" />',
			esc_url( F3BASE_IMP_URL . 'includes/assets/implantador.css?ver=' . rawurlencode( f3base_imp_versao() ) )
		);
		echo '</head><body class="f3base-imp-corpo"><main class="f3base-imp-main">';
	}

	/**
	 * Fecha o documento.
	 *
	 * @return void
	 */
	private static function fechar_documento(): void {
		printf(
			'<p class="f3base-imp-rodape"><a href="%s">%s</a></p>',
			esc_url( admin_url() ),
			esc_html__( 'Voltar ao painel', 'f3base' )
		);

		echo '</main></body></html>';

		exit;
	}
}
