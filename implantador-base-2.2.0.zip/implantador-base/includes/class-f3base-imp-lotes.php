<?php
/**
 * Orquestrador em lotes.
 *
 * Uma única requisição síncrona estoura timeout e memória em hospedagem
 * compartilhada num site maior. Por isso: `admin-post.php` inicia e renderiza a
 * tela orquestradora, e a tela avança por requisições autenticadas sucessivas,
 * **uma unidade idempotente por lote**.
 *
 * Mecânica que este arquivo garante:
 *
 * - **Checkpoint gravado DEPOIS da leitura de volta**, com identificador da
 *   execução, identificador da release, hash da configuração, etapa, estado e
 *   fencing token. Retomada só com a MESMA release e o MESMO hash de
 *   configuração.
 * - **Lock com heartbeat e renovação atômica.** Expiração sozinha não impede
 *   duas execuções quando uma etapa longa passa do TTL: a renovação é
 *   condicional ao valor observado, e o fencing token invalida a execução
 *   velha que acordar depois.
 * - **O endpoint responde JSON bufferizando**, com `register_shutdown_function`
 *   ARMADO ANTES do trabalho: saída inesperada vai para o log, nunca para o
 *   corpo, e o erro fatal ainda responde JSON com tipo, mensagem, arquivo,
 *   linha e limites do PHP. Como a página de erro do WordPress já foi enviada
 *   quando o shutdown roda, a resposta real é "HTML + JSON" — e o cliente
 *   procura o objeto JSON no FIM do corpo.
 * - **Sentinela de INÍCIO e `Content-Type` cedo.** A requisição administrativa
 *   seguinte a uma ativação de plugin de terceiro pode nunca chegar aqui: o
 *   plugin registra o assistente dele em `admin_init`, que roda ANTES do
 *   `admin_post_*`, e o cliente recebe uma página inteira do wp-admin com HTTP
 *   200. Com um marcador nosso no começo do corpo, o cliente distingue
 *   sequestro (sem sentinela, com marcador de wp-admin) de fatal no meio do
 *   lote (com sentinela, sem JSON) e de resposta de rede (nem um nem outro).
 * - **BLOCKED não se repete.** Unidade que devolve BLOCKED é registrada UMA vez
 *   por execução, não é reexecutada e interrompe a cadeia dependente, com as
 *   etapas que ficaram sem executar nomeadas na mesma linha. Artefato ausente
 *   não aparece em nova tentativa, e a mesma linha cinco vezes esconde as
 *   outras quatro que o operador precisava ler.
 * - **O JavaScript mora em `includes/assets/implantador.js`.** Código
 *   executável não mora dentro de string: heredoc não é lintado nem executado
 *   por teste algum.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Máquina de estados, lock, checkpoint e execução por unidade.
 */
final class F3Base_Imp_Lotes {

	/**
	 * Estados da aplicação.
	 */
	public const PRONTO        = 'PRONTO';
	public const EXECUTANDO    = 'EXECUTANDO';
	public const SUCESSO       = 'SUCESSO_APLICACAO';
	public const FALHA_PARCIAL = 'FALHA_PARCIAL';
	public const FALHA         = 'FALHA';

	/**
	 * O TERCEIRO EIXO SAIU — 2.1.0. Da 1.0.17 à 2.0.0 o encerramento respondia
	 * DUAS perguntas: "o implantador aplicou o que sabia aplicar"
	 * (`SUCESSO_APLICACAO`) e "o site está completo" (a convergência, somando as
	 * pré-condições declaradas que dependiam de dado do operador — controlador,
	 * WhatsApp, mecanismo de cadência). A segunda saiu por decisão do dono: o
	 * implantador é executado UMA VEZ por site, dado do operador é preenchido
	 * antes ou ajustado depois pelo canal MCP, e um eixo cuja única saída era
	 * "preencha e execute de novo" descrevia um ciclo que a operação não tem.
	 *
	 * A autodesativação continua amarrada ao gate de aplicação: ela é sobre o
	 * CICLO DO IMPLANTADOR ter terminado, e é a única pergunta que sobrou.
	 */
	public const REVERTIDO     = 'REVERTIDO';

	/**
	 * Ação aplicada aos permalinks: sempre aplicar a estrutura declarada e
	 * cobrir com 301 o endereço antigo.
	 */
	public const PERMALINKS_COBRIR = 'aplicar-e-cobrir';

	/**
	 * Prefixo da referência lógica de objeto sem `ref` declarada.
	 *
	 * O par de redirect é chaveado por REFERÊNCIA LÓGICA — a `ref` da página ou
	 * o slug do post declarado —, e conteúdo que este pacote não gerencia não
	 * tem nenhuma das duas. A identidade dele no banco é o ID, e é ela que vira
	 * referência aqui, com prefixo para nunca colidir com uma `ref` declarada.
	 */
	public const REF_POR_ID = '#';

	/**
	 * Ações que a regra de permalinks produz — o que FAZER, não o veredito.
	 */
	public const ACAO_PERMALINK_NADA     = 'nada';
	public const ACAO_PERMALINK_APLICAR  = 'aplicar';
	public const ACAO_PERMALINK_BLOQUEAR = 'bloquear';

	/**
	 * Decisões declaráveis em `ambiente.indexar`.
	 *
	 * `medir` é o PADRÃO: o site nasce indexável e só deixa de ser quando uma
	 * guarda MEDIDA dispara. `forcar` grava 1 ignorando as guardas e registra a
	 * decisão com o motivo por que ela existia. `nunca` grava 0 sempre.
	 */
	public const INDEXAR_MEDIR  = 'medir';
	public const INDEXAR_FORCAR = 'forcar';
	public const INDEXAR_NUNCA  = 'nunca';

	/**
	 * Nomes das GUARDAS da indexação — as únicas que seguram `blog_public`.
	 *
	 * Cada uma foi escolhida por não poder dar falso positivo em site de
	 * produção real, e o nome de cada uma é o da coisa MEDIDA, para que a
	 * mensagem diga o valor observado ao lado do nome.
	 */
	public const GUARDA_AMBIENTE_WP = 'wp_get_environment_type()';
	public const GUARDA_ESQUEMA     = 'esquema de home_url()';
	public const GUARDA_TIPO        = 'ambiente.tipo';
	public const GUARDA_PREVIA      = 'ambiente.dominios_de_previa';

	/**
	 * Ambientes que o núcleo do WordPress considera NÃO produção.
	 *
	 * O padrão de `wp_get_environment_type()` é `production`: um destes três só
	 * aparece quando a hospedagem, o `wp-config.php` ou uma variável de ambiente
	 * DECLARARAM que aquele ambiente não é produção. Site de produção de verdade
	 * nunca cai aqui — e é exatamente por isso que esta é uma guarda, enquanto a
	 * lista de domínios autorizados deixou de ser.
	 */
	public const AMBIENTES_NAO_PRODUCAO = array( 'local', 'development', 'staging' );

	/**
	 * Origens de um par de `f3base_redirects` — a fonte COMPOSTA da option.
	 *
	 * `declarado` sai de `redirects` no arquivo de configuração e é rederivado a
	 * cada execução: tirar da configuração tira da option. `computado` sai de
	 * uma ETAPA da execução — a troca de estrutura de permalinks é a que existe
	 * hoje — e é PRESERVADO nas execuções seguintes, porque a URL antiga que ele
	 * redireciona continua circulando muito depois de a troca ter acontecido.
	 * `preexistente` é o par que já estava gravado sem carimbo de origem: não foi
	 * este pacote que o escreveu, e apagá-lo em silêncio seria o mesmo defeito
	 * com outro nome.
	 */
	public const REDIRECT_DECLARADO    = 'declarado';
	public const REDIRECT_COMPUTADO    = 'computado';
	public const REDIRECT_PREEXISTENTE = 'preexistente';

	/**
	 * O par que ESTAVA na base e não está mais no observado.
	 *
	 * Quarta origem, e ela não é um par: é a AUSÊNCIA de um par, registrada.
	 * Até a 1.0.19 a união recriava, a cada execução, todo par declarado na
	 * configuração ou computado por uma etapa — inclusive o que alguém tinha
	 * apagado da option pelo canal. O agente apagava um 301 obsoleto e ele
	 * voltava na reexecução seguinte, sem nada no relatório.
	 *
	 * A marca NÃO viaja dentro de `f3base_redirects`: o site-core serve TODO par
	 * da option, sem olhar a origem, e um par marcado ali continuaria
	 * redirecionando. Ela mora na base de merge da option, que é infraestrutura
	 * do implantador — e é de lá que a próxima execução sabe não ressuscitá-lo.
	 */
	public const REDIRECT_REMOVIDO = 'removido-pelo-operador';

	/**
	 * Modos de execução.
	 */
	public const MODO_SIMULACAO = 'simulacao';
	public const MODO_EXECUCAO  = 'execucao';
	public const MODO_RELATORIO = 'relatorio';

	/**
	 * Options de estado.
	 */
	public const OPTION_CHECKPOINT   = 'f3base_checkpoint';
	public const OPTION_ESTADO       = 'f3base_estado_aplicacao';
	public const OPTION_LOCK         = 'f3base_lock';
	public const OPTION_RELEASE      = 'f3base_release';
	public const OPTION_CONSUMIDORES = 'f3base_consumidores';
	public const OPTION_BLOQUEIOS    = 'f3base_bloqueios';

	/**
	 * REGISTRO DURÁVEL DE FASES deste site — irmão do `suite/fases.json` da suíte.
	 *
	 * Guarda, por fase fechada, QUANDO ela rodou pela última vez NESTE host: o
	 * carimbo de tempo, quem mediu e quantas linhas mediram. É o contrapeso da
	 * regra de fase da 1.1.6 do lado do runtime — sem ele, uma fase que este site
	 * nunca exercita ficaria calada para sempre, e silêncio permanente é aprovação
	 * por omissão.
	 *
	 * ELE NÃO MORRE NO ÍNDICE ZERO, e essa é a diferença dele para
	 * `f3base_vereditos` e `f3base_medicoes`, que morrem. Aqueles dois respondem
	 * "o que ESTA execução mediu", e veredito velho decidindo gate novo é a
	 * doença que a 1.0.7 fechou. Este responde "quando esta fase rodou alguma
	 * vez", e apagá-lo a cada execução destruiria exatamente o fato que ele
	 * existe para lembrar. Ele é da mesma família de `f3base_base_merge`:
	 * memória, e não estado da execução.
	 */
	public const OPTION_FASES        = 'f3base_fases';

	/**
	 * A FASE QUE UMA EXECUÇÃO NO HOST EXERCITA, declarada — não deduzida.
	 *
	 * Uma execução do implantador acontece num site: há WordPress, há banco, há
	 * servidor respondendo. É `producao` que nomeia isso, e é contra ela que a
	 * regra de aplicabilidade compara a fase DECLARADA de cada evidência que este
	 * host não produz. As duas linhas que passam por ela dão respostas OPOSTAS, e
	 * é isso que prova que a regra está decidindo em vez de alguém escrever o
	 * resultado à mão:
	 *
	 * - `orcamento.medicao_de_pagina` é fase `campo` — peso, requisições e nós de
	 *   DOM sobre tráfego real. Fora da fase corrente: **N/A**, e não pendência de
	 *   ninguém no momento da implantação. `mcp.autoteste_recusa_credencial` é da
	 *   mesma natureza e passou a `campo` na 1.1.7: quem produz a evidência é o
	 *   REQUISITANTE EXTERNO — uma requisição HTTP de fora com credencial sem a
	 *   capacidade exigida —, e não o host; declará-la `producao` fazia a linha
	 *   sair BLOCKED em toda execução, para sempre, sobre uma ausência por
	 *   desenho.
	 * - `cadencia.mecanismo_declarado` é fase `producao` — a fase corrente. Ali a
	 *   pergunta se aplica aqui, e quando NÃO há agendamento observado nem chave
	 *   declarada a resposta depende de alguém: **BLOCKED**, pré-condição ausente
	 *   na fase certa.
	 *
	 * O ESCOPO É ESTREITO DE PROPÓSITO. A constante governa as declarações de
	 * evidência que este host não produz, e não reescreve a fase declarada das
	 * demais linhas: as de `producao` SÃO a fase corrente e continuam medindo de
	 * verdade, e nada do que hoje mede no site deixou de medir.
	 */
	public const FASE_DA_EXECUCAO    = 'producao';

	/**
	 * Ação do nonce dos lotes.
	 */
	public const NONCE = 'f3base_imp_lote';

	/**
	 * Sentinela que precede o JSON no fim do corpo.
	 */
	public const SENTINELA = '<<<F3BASE-JSON>>>';

	/**
	 * Sentinela impressa no INÍCIO do corpo, antes de qualquer trabalho.
	 *
	 * É o discriminante do cliente: corpo sem ela e com marcador de wp-admin é
	 * requisição sequestrada por terceiro (o nosso handler nunca rodou); corpo
	 * com ela e sem JSON no fim é erro fatal no meio do lote; sem uma nem outra
	 * é resposta de rede ou de proxy.
	 */
	public const SENTINELA_INICIO = '<<<F3BASE-INICIO>>>';

	/**
	 * TTL do lock, em segundos.
	 */
	public const LOCK_TTL = 90;

	/**
	 * Pares de redirect COMPUTADOS pelas etapas DESTA execução.
	 *
	 * Chave de origem (`de`) => par. Existe porque a etapa que computa o par não
	 * é a mesma que grava a option pela última vez, e o valor desejado de
	 * `f3base_redirects` é a UNIÃO das fontes, não o que a última etapa a tocar
	 * por acaso souber.
	 *
	 * @var array<string,array{de:string,para:string,status:int,origem:string}>
	 */
	private static array $redirects_computados = array();

	/**
	 * Estados fechados da máquina.
	 *
	 * @return string[]
	 */
	public static function estados(): array {
		return array( self::PRONTO, self::EXECUTANDO, self::SUCESSO, self::FALHA_PARCIAL, self::FALHA, self::REVERTIDO );
	}

	/**
	 * Modos declarados.
	 *
	 * @return string[]
	 */
	public static function modos(): array {
		return array( self::MODO_SIMULACAO, self::MODO_EXECUCAO, self::MODO_RELATORIO );
	}

	/**
	 * Plano de unidades da execução, na ordem em que rodam.
	 *
	 * Cada unidade é idempotente e roda sozinha num lote. A ordem garante o que
	 * a etapa seguinte pressupõe: mídia antes de conteúdo (o ID do anexo entra
	 * no bloco), páginas antes das páginas especiais e da navegação (os itens
	 * são resolvidos por referência lógica), tudo antes do SEO e da entrega.
	 *
	 * @return array<int,array{etapa:string,acao:string,indice:int,rotulo:string}>
	 */
	public static function unidades(): array {
		$plano = array();

		$plano[] = self::unidade( 'preflight', 'preflight', 0, __( 'Preflight: capacidades, filesystem, disco, rede, limites, baseline, colisões e overrides', 'f3base' ) );

		/*
		 * MIGRAÇÃO, e a POSIÇÃO é parte da correção: logo depois do preflight e
		 * ANTES de qualquer etapa que leia a lista de plugins instalados. O órfão
		 * criado antes da correção do ponto ainda é lido como plugin pelo núcleo;
		 * ocultá-lo aqui faz a etapa de atualização automática já sair com a lista
		 * limpa, em vez de nomear um diretório de backup ao lado do plugin de
		 * verdade.
		 */
		$plano[] = self::unidade( 'plugins', 'orfaos_anteriores', 0, __( 'Migração: órfãos de backup anteriores à correção do ponto, ocultados com propriedade provada', 'f3base' ), 'migracao' );

		$plano[] = self::unidade( 'tema', 'tema', 0, __( 'Tema do pacote: troca controlada de diretório e ativação depois de validado', 'f3base' ) );

		/*
		 * LIMPEZA DOS PADRÕES — 2.1.0, DEPOIS do tema e ANTES dos plugins: os
		 * temas de fábrica só saem com o tema do pacote já ativo (a regra pura
		 * nunca remove o ativo nem o pai dele), e os plugins de fábrica saem
		 * antes de a lista de plugins ser lida pelas etapas seguintes — a
		 * atualização automática, por exemplo, ligaria a flag para o Akismet.
		 */
		$plano[] = self::unidade( 'limpeza', 'limpeza', 0, __( 'Padrões da instalação limpa removidos: temas de fábrica, Akismet e Hello Dolly, pela lista declarada', 'f3base' ) );

		$plano[] = self::unidade( 'site_core', 'site_core', 0, __( 'Plugin persistente do pacote', 'f3base' ) );

		foreach ( F3Base_Imp_Decisoes::bloco( 'plugins.instalaveis' ) as $indice => $entrada ) {
			unset( $entrada );

			$slug = (string) F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $indice, 'slug' );

			/*
			 * O SITE-CORE TEM UNIDADE PRÓPRIA, e não entra no laço — 2.1.0. Até
			 * a 2.0.0 ele entrava duas vezes: a unidade `site_core` o instalava
			 * e o laço o baixava DE NOVO para comparar por hash de diretório e
			 * concluir "artefato idêntico ao instalado". Medido na implantação
			 * de 2026-09-07: dois downloads de um megabyte por execução para
			 * instalar uma coisa. Um artefato, uma unidade.
			 */
			if ( 'site-core' === (string) F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $indice, 'papel' ) ) {
				continue;
			}

			/*
			 * O plugin de SEO produz um grupo PRÓPRIO. Sem isso, as etapas de SEO
			 * dependeriam de "todos os plugins instaláveis" e um BLOCKED na
			 * instalação do servidor MCP suspenderia o SEO — que é a mesma
			 * grossura de cadeia que esta release existe para desfazer.
			 */
			$plano[] = self::unidade(
				'plugins',
				'plugin_instalavel',
				(int) $indice,
				sprintf(
					/* translators: %s: slug do plugin. */
					__( 'Plugin da fonte oficial, última versão: %s', 'f3base' ),
					$slug
				),
				F3Base_Imp_Seo::slug() === $slug ? 'plugin_seo' : 'plugins',
				$slug
			);
		}

		foreach ( F3Base_Imp_Plugins::entradas_declaradas( 'plugins.embarcados' ) as $indice => $entrada ) {
			unset( $entrada );

			$plano[] = self::unidade(
				'plugins',
				'plugin_embarcado',
				(int) $indice,
				sprintf(
					/* translators: %s: slug do plugin embarcado. */
					__( 'Plugin embarcado no bundle: %s', 'f3base' ),
					(string) F3Base_Imp_Config::obter( 'plugins.embarcados.' . $indice . '.slug', '' )
				),
				'plugins',
				(string) F3Base_Imp_Config::obter( 'plugins.embarcados.' . $indice . '.slug', '' )
			);
		}

		/*
		 * PODA DECLARADA das cópias preservadas, depois de todas as instalações
		 * e antes da etapa que lista plugins: o teto vem de
		 * `plugins.backups_preservados` e o que sai do disco sai NOMEADO.
		 */
		$plano[] = self::unidade( 'plugins', 'backups_podados', 0, __( 'Poda declarada das cópias preservadas: acima do teto por slug, as mais antigas saem nomeadas', 'f3base' ), 'plugins_poda' );

		$plano[] = self::unidade( 'plugins', 'autoupdate', 0, __( 'Atualização automática ligada para TODO plugin instalado, conferida pela lista', 'f3base' ), 'plugins_autoupdate' );
		$plano[] = self::unidade( 'plugins', 'onboarding', 0, __( 'Redirecionamento de onboarding suprimido para todo slug declarado no mapa, reescrito de forma idempotente', 'f3base' ), 'plugins_onboarding' );

		/*
		 * DIAGNÓSTICO DO CANAL, cedo e SEM DEPENDÊNCIA declarada. Cedo porque o
		 * operador precisa saber do canal antes de ler trinta linhas de conteúdo;
		 * sem dependência porque foi exatamente esta linha que sumiu quando o
		 * canal era a dúvida. Unidade que diagnostica não pode ser suspensa pelo
		 * que ela diagnostica.
		 */
		$plano[] = self::unidade( 'mcp', 'mcp', 0, __( 'Canal MCP: habilidades registradas conferidas pelo nome, servidor que as expõe e configuração declarada do servidor', 'f3base' ), 'mcp' );

		/*
		 * O RESÍDUO DA INSTALAÇÃO SAI ANTES DOS PERMALINKS, e a ordem é decisão.
		 * O que vai para a lixeira deixa de ser publicado, some da medição de
		 * URLs de terceiro e não ganha 301 para um endereço que passaria a 404;
		 * o que FICA — o objeto que ocupa o slug de exemplo e deixou de ser
		 * exemplo — continua publicado e é COBERTO pelo redirect da troca de
		 * estrutura. Invertida a ordem, o pacote gravaria redirect para o que
		 * ele mesmo está prestes a remover.
		 */
		$plano[] = self::unidade( 'conteudo', 'exemplo_do_wordpress', 0, __( 'Conteúdo de exemplo INTOCADO do WordPress para a lixeira, decidido por discriminante e nunca por slug', 'f3base' ), 'exemplo_do_wordpress' );

		$plano[] = self::unidade( 'wordpress', 'opcoes_wp', 0, __( 'Nome, descrição, idioma, fuso e permalinks', 'f3base' ) );
		$plano[] = self::unidade( 'wordpress', 'indexacao', 0, __( 'Indexação: blog_public = 1 por padrão, salvo guarda medida', 'f3base' ) );

		foreach ( F3Base_Imp_Config::lista( 'midia' ) as $indice => $entrada ) {
			unset( $entrada );

			$plano[] = self::unidade(
				'midia',
				'midia',
				(int) $indice,
				sprintf(
					/* translators: %s: referência lógica da mídia. */
					__( 'Mídia por sideload local: %s', 'f3base' ),
					(string) F3Base_Imp_Config::obter( 'midia.' . $indice . '.ref', '' )
				),
				'midia',
				(string) F3Base_Imp_Config::obter( 'midia.' . $indice . '.ref', '' )
			);
		}

		foreach ( F3Base_Imp_Config::lista( 'categorias' ) as $indice => $entrada ) {
			unset( $entrada );

			$plano[] = self::unidade(
				'taxonomias',
				'categoria',
				(int) $indice,
				sprintf(
					/* translators: %s: slug da categoria. */
					__( 'Categoria: %s', 'f3base' ),
					(string) F3Base_Imp_Config::obter( 'categorias.' . $indice . '.slug', '' )
				),
				'taxonomias',
				(string) F3Base_Imp_Config::obter( 'categorias.' . $indice . '.slug', '' )
			);
		}

		foreach ( F3Base_Imp_Config::lista( 'paginas' ) as $indice => $entrada ) {
			unset( $entrada );

			$plano[] = self::unidade(
				'conteudo',
				'pagina',
				(int) $indice,
				sprintf(
					/* translators: %s: referência lógica da página. */
					__( 'Página gerenciada: %s', 'f3base' ),
					(string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' )
				),
				'conteudo',
				(string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' )
			);
		}

		foreach ( F3Base_Imp_Config::lista( 'posts' ) as $indice => $entrada ) {
			unset( $entrada );

			$plano[] = self::unidade(
				'conteudo',
				'post',
				(int) $indice,
				sprintf(
					/* translators: %s: slug do post. */
					__( 'Post gerenciado: %s', 'f3base' ),
					(string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.slug', '' )
				),
				'conteudo',
				(string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.slug', '' )
			);
		}

		/*
		 * INVENTÁRIO DO QUE NÃO É NOSSO, depois de todo conteúdo gerenciado. Sai
		 * WARN e nunca FALHA: `Sample Page` e `Hello world!` publicados não são
		 * defeito do site, são decisão em aberto do projeto — e não relatá-los
		 * era o implantador entregando um site com página de exemplo publicada
		 * sem dizer nada.
		 */
		$plano[] = self::unidade( 'conteudo', 'conteudo_nao_gerenciado', 0, __( 'Conteúdo publicado NÃO gerenciado, herdado da instalação limpa: relatado, nunca apagado', 'f3base' ), 'conteudo_nao_gerenciado' );

		$plano[] = self::unidade( 'wordpress', 'paginas_especiais', 0, __( 'Página inicial, página de posts e política de privacidade', 'f3base' ), 'paginas_especiais' );
		$plano[] = self::unidade( 'navegacao', 'navegacao', 0, __( 'Post wp_navigation idempotente e ID na option lida pelo tema', 'f3base' ), 'navegacao' );
		$plano[] = self::unidade( 'seo', 'seo_identidade', 0, __( 'Identidade da organização em wpseo_titles', 'f3base' ), 'seo' );
		$plano[] = self::unidade( 'seo', 'seo_social', 0, __( 'Open Graph, Twitter Cards e imagem social padrão', 'f3base' ), 'seo' );
		$plano[] = self::unidade( 'seo', 'seo_geral', 0, __( 'Sitemap, telemetria desligada e a lista do que nunca ligar', 'f3base' ), 'seo' );
		$plano[] = self::unidade( 'seo', 'seo_llms', 0, __( 'llms.txt próprio: emissor do plugin de SEO desligado, arquivo físico dele removido, rota do site-core respondendo', 'f3base' ), 'seo_llms' );
		$plano[] = self::unidade( 'seo', 'seo_robots', 0, __( 'robots.txt como arquivo físico, com Sitemap por home_url()', 'f3base' ), 'seo' );
		$plano[] = self::unidade( 'site_core', 'options_site_core', 0, __( 'Options operáveis e estruturais do site-core', 'f3base' ), 'options_site_core' );
		$plano[] = self::unidade( 'formularios', 'formularios', 0, __( 'Regimes de formulário declarados e seus destinos', 'f3base' ), 'formularios' );
		$plano[] = self::unidade( 'cadencia', 'cadencia', 0, __( 'Cadência do modo somente-relatório agendada, com o mecanismo nomeado', 'f3base' ), 'cadencia' );

		/*
		 * ENTREGA SEMPRE EXECUTA. Ela declara lista vazia de dependências, e isso
		 * é decisão, não omissão: a entrega é o INVENTÁRIO do que ficou de pé, e
		 * um relatório de entrega que não roda quando alguma coisa falhou é
		 * exatamente o instrumento que some quando é mais necessário. BLOCKED na
		 * entrega é RESULTADO — nunca impedimento para rodá-la.
		 */
		$plano[] = self::unidade( 'entrega', 'entrega', 0, __( 'Entregáveis, canal MCP e consumidores da configuração', 'f3base' ), 'entrega' );
		$plano[] = self::unidade( 'encerramento', 'encerramento', 0, __( 'Estado final, carimbo de release e decisão de autodesativação', 'f3base' ), 'encerramento' );

		return F3Base_Imp_Plano::resolver( $plano );
	}

	/**
	 * Monta uma unidade do plano.
	 *
	 * @param string $etapa  Etapa.
	 * @param string $acao   Ação interna.
	 * @param int    $indice Índice na lista da configuração.
	 * @param string $rotulo Rótulo humano.
	 * @param string $grupo  Grupo declarado em F3Base_Imp_Plano; vazio usa a ação.
	 * @param string $chave  Chave de instância (slug, ref) que distingue unidades da mesma ação.
	 * @return array{etapa:string,acao:string,indice:int,rotulo:string,grupo:string,id:string,depende_de:string[]}
	 */
	private static function unidade( string $etapa, string $acao, int $indice, string $rotulo, string $grupo = '', string $chave = '' ): array {
		return array(
			'etapa'      => $etapa,
			'acao'       => $acao,
			'indice'     => $indice,
			'rotulo'     => $rotulo,
			'grupo'      => '' === $grupo ? $acao : $grupo,
			'id'         => F3Base_Imp_Plano::id( $acao, $chave ),
			'depende_de' => array(),
		);
	}

	/**
	 * Índice de lote que o cliente pediu, sanitizado.
	 *
	 * Existe para que as recusas anteriores ao processamento — capacidade e
	 * nonce — respondam com o MESMO índice que o cliente enviou. Recusa que
	 * responde índice inventado impede o cliente de casar a resposta com o que
	 * ele pediu, e foi assim que uma resposta que não avançou o plano passou por
	 * uma que avançou.
	 *
	 * @return int
	 */
	private static function indice_pedido(): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- leitura de diagnóstico; o nonce é conferido por quem chama.
		return isset( $_POST['lote'] ) ? absint( wp_unslash( (string) $_POST['lote'] ) ) : 0;
	}

	/**
	 * Endpoint JSON de um lote.
	 *
	 * @return void
	 */
	public static function endpoint_lote(): void {
		/*
		 * A rede de fatal é armada ANTES de qualquer trabalho: se o próximo
		 * `require` explodir, o cliente ainda recebe diagnóstico em vez de
		 * "Unexpected token '<'".
		 */
		register_shutdown_function( array( __CLASS__, 'rede_de_fatal' ) );

		ob_start();

		if ( ! current_user_can( 'manage_options' ) ) {
			self::responder(
				self::nao_rodou(
					self::indice_pedido(),
					'lote.capacidade_ausente',
					__( 'capacidade manage_options ausente: nenhuma mutação executada e nenhum lote rodou.', 'f3base' )
				),
				403
			);
		}

		$nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['_wpnonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, self::NONCE ) ) {
			self::responder(
				self::nao_rodou(
					self::indice_pedido(),
					'lote.nonce_invalido',
					__( 'nonce inválido ou expirado: recarregue a tela da ferramenta e recomece. Nenhum lote rodou.', 'f3base' )
				),
				403
			);
		}

		$modo     = isset( $_POST['modo'] ) ? sanitize_key( wp_unslash( (string) $_POST['modo'] ) ) : self::MODO_SIMULACAO;
		$modo     = in_array( $modo, self::modos(), true ) ? $modo : self::MODO_SIMULACAO;
		$execucao = isset( $_POST['execucao'] ) ? sanitize_key( wp_unslash( (string) $_POST['execucao'] ) ) : '';
		$indice   = isset( $_POST['lote'] ) ? absint( wp_unslash( (string) $_POST['lote'] ) ) : 0;

		self::abrir_corpo();

		self::responder( self::processar( $modo, $execucao, $indice ) );
	}

	/**
	 * Marca o corpo como NOSSO antes de qualquer trabalho.
	 *
	 * O `Content-Type: application/json` e a sentinela de início saem AGORA, e
	 * não no fim: a requisição administrativa seguinte a uma ativação de plugin
	 * de terceiro pode nunca chegar até aqui — o plugin registra o assistente
	 * dele em `admin_init`, que roda ANTES do `admin_post_*`, e o cliente recebe
	 * uma página inteira do wp-admin com HTTP 200. Sem um marcador nosso no
	 * INÍCIO do corpo, essa resposta é indistinguível de um erro fatal no meio do
	 * lote, e o cliente não tem como decidir entre repetir a unidade e desistir
	 * dela.
	 *
	 * Sai depois da capacidade e do nonce de propósito: essas duas respondem com
	 * o código HTTP delas, e imprimir antes tiraria o 403 do fio.
	 *
	 * @return void
	 */
	private static function abrir_corpo(): void {
		$ruido = '';

		while ( ob_get_level() > 0 ) {
			$ruido .= (string) ob_get_clean();
		}

		if ( '' !== trim( $ruido ) ) {
			error_log( '[f3base-implantador] saída inesperada antes do lote: ' . substr( $ruido, 0, 2000 ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- ruído vai ao log, nunca ao corpo.
		}

		if ( ! headers_sent() ) {
			status_header( 200 );
			header( 'Content-Type: application/json; charset=utf-8' );
			nocache_headers();
		}

		echo self::SENTINELA_INICIO . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- constante do próprio pacote, sem entrada de usuário.

		flush();

		ob_start();
	}

	/**
	 * ÂNCORA da resposta do lote: quem emite, quem produz e o que toda uma traz.
	 *
	 * A tela do operador é montada a partir DESTA resposta: linha sem `rotulo`
	 * sai anônima e a contagem por estado fica sem a lista de nomes; resposta
	 * sem `aplicacao` fecha o rodapé em branco, e vazio não é estado fechado.
	 * Quem cobra é `estatica.resposta_de_lote_nomeada`.
	 *
	 * @return array<string,string>
	 */
	public static function resposta_declarada(): array {
		return array(
			'emissor'  => 'responder',
			'produtor' => 'processar',
			'reserva'  => 'nao_rodou',
			'exigidas' => 'rotulo,aplicacao',
		);
	}

	/**
	 * Resposta de um lote que NÃO RODOU — e por isso ENCERRA a tela.
	 *
	 * O DEFEITO QUE ESTA FUNÇÃO FECHA, medido na 1.0.15: a rejeição de lock
	 * voltava como `{ok:false, estado:BLOCKED, motivo:"…"}` — sem nome de
	 * checagem, sem etapa, sem `concluido` e sem estado da aplicação. O cliente
	 * aplicava a ela a regra "BLOCKED não para mais a execução inteira", que é
	 * correta para UNIDADE que mediu pré-condição ausente e é errada aqui: o
	 * lote não rodou, nada foi medido, e não há o que continuar. O resultado foi
	 * um laço de 163 requisições, um `Etapa 94 de 40` na tela e um rodapé com
	 * `estado da aplicação:` vazio.
	 *
	 * A resposta daqui carrega os quatro fatos que faltavam:
	 *
	 * - `rotulo`: toda linha renderizada tem NOME, ou a contagem por estado sai
	 *   sem a lista correspondente — foi o que produziu "163 BLOCKED" ao lado de
	 *   "BLOCKED: nenhum";
	 * - `parou`: o plano NÃO avançou, e o cliente não pode pedir o próximo;
	 * - `concluido`: a tela fecha aqui;
	 * - `aplicacao`: estado FECHADO, nunca vazio. Execução que não chegou a
	 *   adquirir o lock fecha BLOCKED, que é o estado de pré-condição ausente.
	 *
	 * @param int                 $indice Índice pedido pelo cliente.
	 * @param string              $rotulo Nome da checagem.
	 * @param string              $motivo Mensagem, já montada.
	 * @param array<string,mixed> $extra  Fatos estruturados da causa.
	 * @return array<string,mixed>
	 */
	private static function nao_rodou( int $indice, string $rotulo, string $motivo, array $extra = array() ): array {
		return array_merge(
			array(
				'ok'        => false,
				'concluido' => true,
				'parou'     => true,
				'lote'      => $indice,
				'etapa'     => 'lote',
				'rotulo'    => $rotulo,
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => $motivo,
				'aplicacao' => F3Base_Imp_Relatorio::BLOCKED,
			),
			$extra
		);
	}

	/**
	 * Processa um lote.
	 *
	 * @param string $modo     Modo declarado.
	 * @param string $execucao Identificador da execução.
	 * @param int    $indice   Índice da unidade.
	 * @return array<string,mixed>
	 */
	public static function processar( string $modo, string $execucao, int $indice ): array {
		if ( ! F3Base_Imp_Config::carregar() ) {
			return self::nao_rodou(
				$indice,
				'lote.configuracao_invalida',
				sprintf(
					/* translators: %s: erros de validação. */
					__( 'a configuração não validou contra o schema e o lote NÃO rodou: %s', 'f3base' ),
					implode( ' | ', F3Base_Imp_Config::erros() )
				)
			);
		}

		if ( '' === $execucao ) {
			return self::nao_rodou(
				$indice,
				'lote.execucao_ausente',
				__( 'identificador de execução ausente: o lote não sabe a que execução pertence e NÃO rodou.', 'f3base' )
			);
		}

		$lock = self::adquirir_lock( $execucao );

		if ( ! $lock['ok'] ) {
			return self::nao_rodou(
				$indice,
				'lote.lock_ocupado',
				$lock['motivo'],
				array(
					'lock' => array(
						'dono'          => (string) $lock['dono'],
						'idade'         => (int) $lock['idade'],
						'ttl'           => (int) $lock['ttl'],
						'abandonado_em' => (int) $lock['abandonado_em'],
						'abandonado_as' => 0 === (int) $lock['abandonado_em'] ? '' : wp_date( 'Y-m-d H:i:s', (int) $lock['abandonado_em'] ),
					),
				)
			);
		}

		$retomada = self::conferir_retomada( $execucao, $indice );

		if ( ! $retomada['ok'] ) {
			return self::nao_rodou( $indice, 'lote.retomada_recusada', $retomada['motivo'] );
		}

		$plano = self::unidades();
		$total = count( $plano );

		if ( $indice < 0 || $indice >= $total ) {
			/*
			 * ÍNDICE FORA DO PLANO. Antes desta release a resposta saía sem nome
			 * e sem estado da aplicação, e o cliente a renderizava como linha
			 * anônima — a mesma doença da rejeição de lock. Sai nomeada, com o
			 * índice pedido e o total, porque índice fora do plano é sempre
			 * defeito de quem pediu, e o número que ele pediu é o diagnóstico.
			 */
			return array(
				'ok'        => true,
				'concluido' => true,
				'parou'     => true,
				'lote'      => $indice,
				'total'     => $total,
				'etapa'     => 'lote',
				'rotulo'    => 'lote.plano_concluido',
				'estado'    => F3Base_Imp_Relatorio::OK,
				'aplicacao' => (string) get_option( self::OPTION_ESTADO, self::PRONTO ),
				'motivo'    => sprintf(
					/* translators: 1: índice pedido, 2: total de unidades. */
					__( 'plano concluído: não há mais unidades. Índice pedido: %1$d; o plano tem %2$d.', 'f3base' ),
					$indice,
					$total
				),
			);
		}

		F3Base_Imp_Gravador::simulacao( self::MODO_EXECUCAO !== $modo );
		/*
		 * O MODO SOMENTE-RELATÓRIO É UM SUBCONJUNTO DA SIMULAÇÃO — nada é
		 * gravado nos dois — e ainda assim precisa de bandeira própria, porque
		 * a pergunta que ele responde é outra: não "o que a aplicação faria",
		 * e sim "o que mudou desde a última aplicação". Esta é a linha que faz
		 * a comparação sair contra a BASE, e não contra a configuração.
		 */
		F3Base_Imp_Gravador::relatorio( self::MODO_RELATORIO === $modo );
		F3Base_Imp_Journal::iniciar( $execucao );
		F3Base_Imp_Relatorio::carregar();

		if ( 0 === $indice ) {
			F3Base_Imp_Relatorio::zerar();
			F3Base_Imp_Gravador::remover_infra( self::OPTION_CONSUMIDORES );
			F3Base_Imp_Gravador::remover_infra( self::OPTION_BLOQUEIOS );

			/*
			 * O registro de vereditos morre com a execução anterior. Veredito
			 * velho decidindo gate novo seria a mesma doença de outra forma: uma
			 * fonte de verdade, sim, mas desta execução.
			 */
			F3Base_Imp_Gravador::remover_infra( F3Base_Imp_Entrega::OPTION_VEREDITOS );

			/*
			 * O registro de MEDIÇÕES morre junto, e pela mesma razão: fato velho
			 * respondendo por predicado de aplicabilidade novo diria "há rotas"
			 * num site em que já não há.
			 */
			F3Base_Imp_Gravador::remover_infra( F3Base_Imp_Entrega::OPTION_MEDICOES );
			self::definir_estado( self::MODO_EXECUCAO === $modo ? self::EXECUTANDO : self::PRONTO );
		} else {
			$acumuladas = get_option( self::OPTION_CONSUMIDORES, array() );
			F3Base_Imp_Config::acumular( is_array( $acumuladas ) ? $acumuladas : array() );
		}

		$unidade = $plano[ $indice ];

		/*
		 * Unidade já registrada em BLOCKED nesta execução NÃO roda de novo, e não
		 * emite uma segunda linha: artefato ausente não aparece em nova tentativa,
		 * e a mesma linha repetida cinco vezes esconde as outras quatro que o
		 * operador precisava ler. A linha sai UMA vez, com a cadeia dependente
		 * nomeada; a saída é corrigir a pré-condição e começar uma execução nova.
		 */
		$repetida = self::bloqueio_registrado( $execucao, $indice );

		if ( array() !== $repetida ) {
			return array(
				'ok'          => false,
				'concluido'   => false,
				'lote'        => $indice,
				'total'       => $total,
				'etapa'       => $unidade['etapa'],
				'rotulo'      => $unidade['rotulo'],
				'estado'      => F3Base_Imp_Relatorio::BLOCKED,
				'repetida'    => true,
				'motivo'      => sprintf(
					/* translators: 1: data do registro, 2: motivo registrado. */
					__( 'unidade já registrada em BLOCKED nesta execução (em %1$s) e NÃO reexecutada — a linha do log sai uma vez só. Motivo registrado: %2$s', 'f3base' ),
					wp_date( 'Y-m-d H:i', (int) $repetida['em'] ),
					(string) $repetida['motivo']
				),
				'dependentes' => $repetida['dependentes'],
				'aplicacao'   => (string) get_option( self::OPTION_ESTADO, self::PRONTO ),
				'ativado'     => F3Base_Imp_Plugins::ultimo_ativado(),
			) + self::contadores_por_escopo();
		}

		/*
		 * SUSPENSÃO POR DEPENDÊNCIA DECLARADA. Não é "veio depois de alguém que
		 * falhou": é "declara depender, direta ou indiretamente, de uma unidade
		 * que fechou BLOCKED ou FALHA nesta execução". Quem não declara continua
		 * executando, e a linha nomeia QUAL unidade suspendeu esta — porque
		 * "ficou sem executar" não responde à pergunta que o operador faz em
		 * seguida.
		 */
		$suspensas = F3Base_Imp_Plano::suspensas( $plano, self::interrompidas( $execucao ) );
		$id        = (string) $unidade['id'];

		if ( isset( $suspensas[ $id ] ) ) {
			$causa  = $suspensas[ $id ];
			$motivo = sprintf(
				/* translators: 1: id da dependência direta, 2: id da unidade que originou, 3: estado observado, 4: motivo registrado. */
				__( 'unidade SUSPENSA e não executada: ela declara depender de %1$s, e a origem da suspensão é %2$s, que fechou %3$s nesta execução. Motivo registrado ali: %4$s A dependência é declarada em F3Base_Imp_Plano, não é a posição no plano — as unidades independentes desta continuaram executando.', 'f3base' ),
				(string) $causa['por'],
				(string) $causa['raiz'],
				(string) $causa['estado'],
				self::motivo_da_interrompida( $execucao, (string) $causa['raiz'] )
			);

			F3Base_Imp_Relatorio::emitir_unidade(
				F3Base_Imp_Relatorio::BLOCKED,
				$unidade['rotulo'],
				$motivo,
				array(
					'evidencia' => 'pendencia-externa',
					'fase'      => self::MODO_EXECUCAO === $modo ? 'local' : 'build',
					'gate'      => 'aplicacao',
				)
			);

			F3Base_Imp_Relatorio::persistir(
				array(
					'execucao' => $execucao,
					'modo'     => $modo,
				)
			);

			return array(
				'ok'          => true,
				'concluido'   => $indice + 1 >= $total,
				'lote'        => $indice,
				'total'       => $total,
				'etapa'       => $unidade['etapa'],
				'rotulo'      => $unidade['rotulo'],
				'estado'      => F3Base_Imp_Relatorio::BLOCKED,
				'suspensa'    => true,
				'motivo'      => $motivo,
				'aplicacao'   => (string) get_option( self::OPTION_ESTADO, self::PRONTO ),
				'dependentes' => array(),
				'ativado'     => F3Base_Imp_Plugins::ultimo_ativado(),
			) + self::contadores_por_escopo();
		}

		F3Base_Imp_Journal::etapa( $unidade['etapa'] );

		/*
		 * MARCA ANTES DE EXECUTAR. O que a unidade emitir daqui até a linha dela
		 * é o conjunto de checagens que rodaram DENTRO dela — e é ele que a
		 * resposta carrega, para que nenhum estado ruim fique invisível atrás de
		 * uma unidade que fechou OK.
		 */
		$marca = F3Base_Imp_Relatorio::marcar();

		$resultado   = self::executar( $unidade, $modo );
		$internas    = self::checagens_da_unidade( $marca );
		$dependentes = array();

		/*
		 * O VEREDITO DA UNIDADE REFLETE AS CHECAGENS QUE ELA EMITIU, e isso
		 * acontece AQUI — uma vez, para todas as unidades — em vez de em cada
		 * `etapa_*` à mão. Aplicado antes do bloco de dependentes de propósito:
		 * a promoção é o estado da unidade, e é ele que decide suspensão,
		 * registro de bloqueio e a linha que sai na tela.
		 */
		$reflexo             = self::veredito_da_unidade( $resultado['estado'], $internas['nomeadas'] );
		$resultado['estado'] = $reflexo['estado'];

		/*
		 * A nota sai quando há promoção E quando há pendência de fase: a
		 * segunda não muda o veredito, e é justamente por isso que ela precisa
		 * aparecer NOMEADA no texto — o que não decide também não pode sumir.
		 */
		if ( '' !== $reflexo['nota'] ) {
			$resultado['motivo'] .= ' ' . $reflexo['nota'];
		}

		/*
		 * SUSPENDER O QUE DEPENDE É DECISÃO DE FATO CRÍTICO, não de veredito
		 * agregado — e esta é a correção estrutural que impede a repetição do
		 * defeito medido em produção na 1.3.0.
		 *
		 * Trinta e nove unidades declaram depender de `preflight`. Enquanto a
		 * suspensão saía do ESTADO FINAL da unidade, qualquer linha adversa lá
		 * dentro — inclusive uma descritiva — derrubava a implantação inteira. É
		 * o que aconteceu: `preflight.baseline` encontrou um plugin da
		 * hospedagem, fechou FALHA com uma mensagem que dizia "eles ficam como
		 * estão", e o site ficou sem tema, sem plugins e sem conteúdo.
		 *
		 * A pergunta que decide não é "a unidade fechou bem?" e sim "os FATOS
		 * CRÍTICOS estão de pé?" — tenho as capacidades, o filesystem é direto,
		 * consigo escrever nos destinos, tem disco, o PHP atende ao mínimo. Se
		 * estão, a instalação roda, mesmo que alguma linha descritiva tenha
		 * achado algo digno de nota.
		 */
		$critico = self::fato_critico_caiu( $internas['nomeadas'] );

		if ( $critico['caiu'] ) {
			$dependentes          = self::etapas_sem_execucao( $id, $critico['estado'] );
			$resultado['motivo'] .= ' ' . $critico['motivo'] . ' ' . self::texto_dependentes( $dependentes );

			self::registrar_bloqueio( $execucao, $indice, $id, $critico['estado'], $resultado['motivo'], $dependentes );
		}

		/*
		 * A linha da UNIDADE sai por `emitir_unidade()`: ela imprime no escopo
		 * das checagens, como qualquer outra, e conta também no escopo das
		 * UNIDADES. Dois escopos, dois contadores, cada um com nome próprio.
		 */
		/*
		 * A UNIDADE É O ASSUNTO DA TELA: uma linha por etapa, com o nome da
		 * etapa em português comum e o estado dito por palavra, não por sigla.
		 * O parágrafo com a medição inteira continua no log.
		 */
		$estado_impresso = F3Base_Imp_Relatorio::emitir_unidade(
			$resultado['estado'],
			$resultado['rotulo'],
			$resultado['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => self::MODO_EXECUCAO === $modo ? 'local' : 'build',
				'gate'      => 'aplicacao',
				'tela'      => self::linha_de_tela_da_unidade( $unidade, $resultado['estado'] ),
			)
		);

		/*
		 * O REGISTRO DA EXECUÇÃO RECEBE O ESTADO FINAL DA UNIDADE — o mesmo que
		 * a linha acima acabou de imprimir, já promovido e já passado pelo funil
		 * de waiver. Sem isto, o veredito gravado por quem DERIVOU (a unidade
		 * `mcp`, antes de o autoteste rodar) ficava para trás da promoção, e o
		 * gate de aplicação lia OK sobre uma linha que o relatório imprimia em
		 * BLOCKED — a contradição medida em produção na 1.1.6. Nada é
		 * recalculado aqui: o veredito continua sendo derivado num lugar só, e
		 * esta chamada só PROPAGA o estado final para o registro, que a partir
		 * dela é a única fonte que o gate consulta.
		 */
		F3Base_Imp_Entrega::propagar_veredito_da_unidade(
			$resultado['rotulo'],
			$estado_impresso,
			$resultado['motivo']
		);

		foreach ( F3Base_Imp_Conteudo::avisos() as $aviso ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'idempotencia.registro_vs_artefato',
				$aviso,
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		}

		F3Base_Imp_Relatorio::persistir(
			array(
				'execucao' => $execucao,
				'modo'     => $modo,
			)
		);

		F3Base_Imp_Gravador::persistir_infra( self::OPTION_CONSUMIDORES, F3Base_Imp_Config::chaves_lidas() );

		/*
		 * O checkpoint é gravado DEPOIS da leitura de volta da unidade — nunca
		 * antes: checkpoint que corre à frente do artefato faz a retomada pular
		 * trabalho que não aconteceu.
		 */
		$gravou_checkpoint = self::gravar_checkpoint( $execucao, $modo, $unidade['etapa'], $indice, $resultado['estado'] );

		return array(
			'ok'          => in_array( $resultado['estado'], array( F3Base_Imp_Relatorio::OK, F3Base_Imp_Relatorio::NA, F3Base_Imp_Relatorio::WAIVED, F3Base_Imp_Relatorio::WARN ), true ),
			'concluido'   => $indice + 1 >= $total,
			'lote'        => $indice,
			'total'       => $total,
			'etapa'       => $unidade['etapa'],
			'rotulo'      => $unidade['rotulo'],
			'estado'      => $resultado['estado'],
			'motivo'      => $resultado['motivo'],
			'checkpoint'  => $gravou_checkpoint,
			'aplicacao'   => (string) get_option( self::OPTION_ESTADO, self::PRONTO ),
			'dependentes' => $dependentes,
			'ativado'     => F3Base_Imp_Plugins::ultimo_ativado(),
			'checagens'   => $internas['nomeadas'],
			'checagens_resumidas' => $internas['resumidas'],
		) + self::contadores_por_escopo();
	}

	/**
	 * Checagens que rodaram DENTRO de uma unidade, prontas para a tela.
	 *
	 * A regra, e ela é a correção desta release: **toda checagem em FALHA,
	 * BLOCKED, WARN, WAIVED ou N/A é NOMEADA no relatório, mesmo quando a
	 * unidade que a contém fecha OK.** Só o estado OK sai resumido — o que não
	 * pode existir é estado ruim invisível.
	 *
	 * PÚBLICA de propósito: é a MESMA função que a sonda funcional chama para
	 * exercitar a promoção de estado no caminho real de `processar()`. Sonda que
	 * reimplementa o recorte prova que a cópia funciona, não que o recorte
	 * funciona.
	 *
	 * @param int $marca Ponto do acumulador anterior à execução da unidade.
	 * @return array{nomeadas:array<int,array<string,string>>,resumidas:int}
	 */
	public static function checagens_da_unidade( int $marca ): array {
		$nomeadas  = array();
		$resumidas = 0;

		foreach ( F3Base_Imp_Relatorio::desde( $marca ) as $linha ) {
			$estado = (string) ( $linha['estado'] ?? '' );

			if ( F3Base_Imp_Relatorio::OK === $estado ) {
				++$resumidas;
				continue;
			}

			$nomeadas[] = array(
				'estado'    => $estado,
				'nome'      => (string) ( $linha['nome'] ?? '' ),
				'mensagem'  => (string) ( $linha['mensagem'] ?? '' ),
				'evidencia' => (string) ( $linha['evidencia'] ?? '' ),
				'fase'      => (string) ( $linha['fase'] ?? '' ),
				'gate'      => (string) ( $linha['gate'] ?? '' ),
			);
		}

		return array(
			'nomeadas'  => $nomeadas,
			'resumidas' => $resumidas,
		);
	}

	/**
	 * GATE cuja checagem DECIDE o veredito da unidade.
	 *
	 * Um só, e declarado aqui: `aplicacao`. É a mesma separação que a 1.0.7
	 * estabeleceu para a autodesativação — gate de aplicação DECIDE, gate de
	 * fase INFORMA —, aplicada agora ao veredito da unidade.
	 *
	 * A regra do que é fase, e ela é estreita de propósito: **só entra em `fase`
	 * o que depende de evidência que o host NÃO PRODUZ** — navegador, campo,
	 * suíte externa. Marcar como fase uma checagem que o host mede seria
	 * construir a porta de escape que absolve qualquer coisa, e é ela que
	 * `estatica.unidade_reflete_internas` existe para manter fechada.
	 *
	 * O QUE NÃO SE SEGUE DAÍ, e a 1.7.2 tratava como se seguisse: que tudo que
	 * é mensurável aqui seja `aplicacao`. `aplicacao` responde a uma pergunta
	 * mais estreita ainda — *"isto impede o site de funcionar?"* —, porque é ela
	 * que SUSPENDE o que depende desta unidade. Uma linha medida aqui, completa
	 * e acionável, cuja resposta não impede o site de funcionar não é nenhum dos
	 * dois: é `relato`. Era esse buraco que fazia seis nomes medidos no host
	 * declararem `fase` para não suspender nada, e a lista de gates de fase
	 * mentir sobre cada um deles.
	 */
	public const GATE_QUE_DECIDE = 'aplicacao';

	/**
	 * O VEREDITO DA UNIDADE: o mais severo entre o dela e as internas de gate
	 * `aplicacao`.
	 *
	 * O DEFEITO CORRIGIDO AQUI, medido em produção na 1.0.8: a linha 48 do
	 * relatório era `OK entrega — "todos os entregáveis do gate de aplicação
	 * fecharam sem BLOCKED"` e a linha 49, DENTRO dela, era
	 * `FALHA ↳ mcp.canal_unico`. Uma unidade não pode fechar OK contendo uma
	 * checagem em FALHA: quem lê o resumo por unidade vê verde onde há vermelho,
	 * e foi essa mesma discrepância que escondeu as FALHAs até a 1.0.7.
	 *
	 * A PROMOÇÃO É POR GATE, e sem isso a correção criava um defeito novo: a
	 * unidade `entrega` emite `orcamento.medicao_de_pagina` como BLOCKED em TODA
	 * execução — é medição de navegador, que este host não faz — e uma promoção
	 * cega faria `entrega` fechar BLOCKED para sempre, em qualquer instalação,
	 * por desenho. É a mesma armadilha que a 1.0.7 desfez no gate da
	 * autodesativação, reaparecendo no veredito da unidade.
	 *
	 * Então: decide quem é de `aplicacao`. O que é de fase **não some** — sai
	 * na sua própria linha, entra nas listas por estado e no resumo, e é
	 * NOMEADO no texto da unidade como pendência de fase. Some do veredito,
	 * nunca do relatório. Desde a 1.7.3 o mesmo vale para o gate `relato`, que
	 * sai na frase seguinte e com o nome certo: o host mediu, a linha é
	 * acionável, e nada nela se resolve rodando outra fase. O gate
	 * `convergencia` saiu na 2.1.0, com o terceiro eixo inteiro.
	 *
	 * Gate ausente conta como `aplicacao`, e isso é decisão: a ausência não pode
	 * ser o caminho barato para escapar da promoção.
	 *
	 * A ordem de severidade NÃO é declarada aqui — ela é
	 * `F3Base_Imp_Relatorio::ordem_de_severidade()`, uma só no pacote, e é o
	 * `estado_mais_severo()` daquela classe que compara. Duas ordens divergem, e
	 * a divergência sai como relatório que se contradiz.
	 *
	 * Só o que NÃO fechou OK chega aqui, e isso basta: OK não promove ninguém.
	 *
	 * @param string                          $estado_da_unidade Estado que a etapa devolveu.
	 * @param array<int,array<string,string>> $internas          Checagens da unidade que não fecharam OK.
	 * @return array{estado:string,promovida:bool,nota:string,responsaveis:array<int,string>,pendencias_de_fase:array<int,string>,linhas_de_relato:array<int,string>}
	 */
	/**
	 * Esta checagem interna DECIDE o veredito da unidade?
	 *
	 * Uma função, e não uma comparação repetida em três pontos: a regra tem um
	 * caso de borda que uma comparação distraída erra, e errou — **gate AUSENTE
	 * OU VAZIO conta como o gate que decide**. `?? ` só cobre a chave que falta;
	 * a chave presente e vazia passava direto e era lida como fase, o que fazia
	 * de "esquecer de declarar o gate" o caminho barato para escapar da
	 * promoção. Quem esquece promove como aplicação, que é o lado seguro.
	 *
	 * @param array<string,string> $interna Linha do recorte da unidade.
	 * @return bool
	 */
	private static function decide_o_veredito( array $interna ): bool {
		$gate = (string) ( $interna['gate'] ?? '' );

		return '' === $gate || self::GATE_QUE_DECIDE === $gate;
	}

	public static function veredito_da_unidade( string $estado_da_unidade, array $internas ): array {
		$estado             = $estado_da_unidade;
		$pendencias_de_fase = array();
		$linhas_de_relato   = array();

		foreach ( $internas as $interna ) {
			$estado_interno = (string) ( $interna['estado'] ?? '' );

			if ( '' === $estado_interno ) {
				continue;
			}

			if ( ! self::decide_o_veredito( $interna ) ) {
				$rotulada = (string) ( $interna['nome'] ?? '' ) . ' (' . $estado_interno . ')';

				/*
				 * LINHA DE RELATO NÃO É PENDÊNCIA DE FASE, e chamá-la assim era
				 * o defeito de nome que a 1.7.3 fechou. O host MEDIU: a linha
				 * está completa, é acionável e não falta fase nenhuma. Ela
				 * continua fora do veredito da unidade — mesmos poderes de antes,
				 * que são nenhum — e continua NOMEADA, agora pelo que ela é.
				 */
				if ( F3Base_Imp_Relatorio::GATE_RELATO === (string) ( $interna['gate'] ?? '' ) ) {
					if ( F3Base_Imp_Fases::gate_de_fase_em_aberto( $estado_interno ) ) {
						$linhas_de_relato[] = $rotulada;
					}

					continue;
				}

				/*
				 * MESMA REGRA, TERCEIRO LUGAR. Linha de fase que fecha OK ou N/A não
				 * é pendência DENTRO da unidade pelo mesmo motivo que não é no gate:
				 * a primeira respondeu, a segunda não se aplica aqui. Sem isto, a
				 * nota da unidade passaria a listar como pendente a própria linha do
				 * registro de fases quando ela fecha OK.
				 */
				if ( F3Base_Imp_Fases::gate_de_fase_em_aberto( $estado_interno ) ) {
					$pendencias_de_fase[] = $rotulada;
				}

				continue;
			}

			$estado = F3Base_Imp_Relatorio::estado_mais_severo( $estado, $estado_interno );
		}

		$responsaveis = array();

		if ( $estado !== $estado_da_unidade ) {
			foreach ( $internas as $interna ) {
				if ( $estado === (string) ( $interna['estado'] ?? '' ) && self::decide_o_veredito( $interna ) ) {
					$responsaveis[] = (string) ( $interna['nome'] ?? '' );
				}
			}
		}

		$partes = array();

		if ( array() !== $responsaveis ) {
			$partes[] = sprintf(
				/* translators: 1: estado que a etapa devolveu, 2: estado promovido, 3: checagens responsáveis, pelo nome. */
				__( 'Veredito da unidade PROMOVIDO de %1$s para %2$s: a unidade emitiu checagem(ns) de gate de aplicação em %2$s e nenhuma unidade fecha em estado menos severo do que aquilo que ela mesma mediu — %3$s. Ler a linha da unidade e a das checagens e encontrar cores diferentes foi o que escondeu as FALHAs até a 1.0.7.', 'f3base' ),
				$estado_da_unidade,
				$estado,
				implode( ', ', $responsaveis )
			);
		}

		if ( array() !== $pendencias_de_fase ) {
			$partes[] = sprintf(
				/* translators: 1: quantidade de pendências de fase, 2: as pendências, pelo nome e com o estado. */
				__( 'Pendência(s) de FASE dentro desta unidade — %1$d, nomeada(s) e FORA do veredito dela: %2$s. Evidência que este host não produz (navegador, campo, suíte externa) é relatada e não decide: some do veredito, nunca do relatório.', 'f3base' ),
				count( $pendencias_de_fase ),
				implode( ', ', $pendencias_de_fase )
			);
		}

		if ( array() !== $linhas_de_relato ) {
			$partes[] = sprintf(
				/* translators: 1: quantidade de linhas de relato adversas, 2: as linhas, pelo nome e com o estado. */
				__( 'Linha(s) de RELATO adversa(s) dentro desta unidade — %1$d, nomeada(s) e FORA do veredito dela: %2$s. Este host MEDIU cada uma, e nenhuma delas suspende o que depende desta unidade; o que uma FALHA aqui faz é derrubar o estado da aplicação no encerramento, e é isso que mantém o implantador no ar até que ela seja corrigida.', 'f3base' ),
				count( $linhas_de_relato ),
				implode( ', ', $linhas_de_relato )
			);
		}

		return array(
			'estado'             => $estado,
			'promovida'          => $estado !== $estado_da_unidade,
			'nota'               => implode( ' ', $partes ),
			'responsaveis'       => $responsaveis,
			'pendencias_de_fase' => $pendencias_de_fase,
			'linhas_de_relato'   => $linhas_de_relato,
		);
	}

	/**
	 * Contadores da resposta do lote, um por escopo e cada um NOMEADO.
	 *
	 * A resposta antiga trazia `falhas` e `bloqueados` sem escopo declarado, e o
	 * cliente imprimia esses números ao lado de uma tabela que conta outra
	 * coisa. Aqui cada chave diz o que conta, e nenhuma palavra nomeia duas
	 * contagens diferentes. O terceiro escopo — as linhas renderizadas na tela —
	 * é do cliente, e é lá que ele é contado.
	 *
	 * CONTAGEM E NOMES VIAJAM JUNTOS. A resposta que levava só os números
	 * produziu o cabeçalho "5 FALHA e 6 BLOCKED" ao lado de uma tela com UMA
	 * unidade em FALHA: as outras rodavam DENTRO de unidades que fecharam OK, e
	 * o operador tinha o número e nenhum nome para procurar.
	 *
	 * @return array<string,mixed>
	 */
	private static function contadores_por_escopo(): array {
		return array(
			'escopos'            => F3Base_Imp_Relatorio::escopos(),
			'checagens_falha'    => F3Base_Imp_Relatorio::checagens_em_falha(),
			'checagens_blocked'  => F3Base_Imp_Relatorio::checagens_em_blocked(),
			'unidades_falha'     => F3Base_Imp_Relatorio::unidades_em_falha(),
			'unidades_blocked'   => F3Base_Imp_Relatorio::unidades_em_blocked(),
			'checagens_nomes'    => F3Base_Imp_Relatorio::nomes_por_estado( 'checagens' ),
			'unidades_nomes'     => F3Base_Imp_Relatorio::nomes_por_estado( 'unidades' ),
		);
	}

	/**
	 * Unidades que ESTA unidade suspende — o fecho transitivo dela, e só ele.
	 *
	 * Era aqui que morava o defeito medido: a função devolvia TUDO que vinha
	 * depois na lista, e um BLOCKED em `formularios` derrubava `cadencia`,
	 * `entrega` e `encerramento`, que não leem nada de formulário. Agora a
	 * pergunta é "quem declarou depender desta unidade, direta ou
	 * indiretamente" — dependência declarada, nunca posição.
	 *
	 * @param string $id     Id da unidade que interrompeu.
	 * @param string $estado Estado observado (BLOCKED ou FALHA).
	 * @return array<int,string> Ids suspensos, com o rótulo humano.
	 */
	private static function etapas_sem_execucao( string $id, string $estado ): array {
		$plano     = self::unidades();
		$suspensas = F3Base_Imp_Plano::suspensas( $plano, array( $id => $estado ) );
		$pendentes = array();

		foreach ( $plano as $posicao => $unidade ) {
			$alvo = (string) $unidade['id'];

			if ( ! isset( $suspensas[ $alvo ] ) ) {
				continue;
			}

			$pendentes[] = sprintf(
				'#%1$d %2$s (depende de %3$s)',
				(int) $posicao + 1,
				$alvo,
				(string) $suspensas[ $alvo ]['por']
			);
		}

		return $pendentes;
	}

	/**
	 * Texto do fecho suspenso por esta unidade.
	 *
	 * Diz também o que NÃO foi suspenso, porque é essa metade que o operador
	 * precisa para não achar que a execução parou: as unidades independentes
	 * continuam, e a entrega roda de qualquer jeito.
	 *
	 * @param array<int,string> $dependentes Ids suspensos.
	 * @return string
	 */
	private static function texto_dependentes( array $dependentes ): string {
		if ( array() === $dependentes ) {
			return __( 'Nenhuma unidade declara depender desta: o fecho de suspensão é vazio e a execução segue em TODAS as demais, inclusive a entrega e o encerramento.', 'f3base' );
		}

		return sprintf(
			/* translators: 1: quantidade de unidades, 2: lista nomeada com a dependência de cada uma. */
			__( 'Suspensas por dependência declarada — %1$d unidade(s), e só elas: %2$s. As unidades independentes continuam executando, e a entrega roda de qualquer jeito.', 'f3base' ),
			count( $dependentes ),
			implode( ', ', $dependentes )
		);
	}

	/**
	 * Unidades interrompidas nesta execução: id => estado observado.
	 *
	 * @param string $execucao Identificador da execução.
	 * @return array<string,string>
	 */
	private static function interrompidas( string $execucao ): array {
		$atual = get_option( self::OPTION_BLOQUEIOS, array() );

		if ( ! is_array( $atual ) || ! isset( $atual['execucao'], $atual['unidades'] ) || ! is_array( $atual['unidades'] ) ) {
			return array();
		}

		if ( (string) $atual['execucao'] !== $execucao ) {
			return array();
		}

		$saida = array();

		foreach ( $atual['unidades'] as $registro ) {
			if ( ! is_array( $registro ) ) {
				continue;
			}

			$id = isset( $registro['id'] ) ? (string) $registro['id'] : '';

			if ( '' !== $id ) {
				$saida[ $id ] = isset( $registro['estado'] ) ? (string) $registro['estado'] : F3Base_Imp_Relatorio::BLOCKED;
			}
		}

		return $saida;
	}

	/**
	 * Motivo registrado de uma unidade interrompida.
	 *
	 * @param string $execucao Execução.
	 * @param string $id       Id da unidade.
	 * @return string
	 */
	private static function motivo_da_interrompida( string $execucao, string $id ): string {
		$atual = get_option( self::OPTION_BLOQUEIOS, array() );

		if ( ! is_array( $atual ) || ! isset( $atual['unidades'] ) || ! is_array( $atual['unidades'] ) ) {
			return '';
		}

		foreach ( $atual['unidades'] as $registro ) {
			if ( is_array( $registro ) && $id === (string) ( $registro['id'] ?? '' ) ) {
				return (string) ( $registro['motivo'] ?? '' );
			}
		}

		return '';
	}

	/**
	 * Registra que esta unidade fechou em BLOCKED nesta execução.
	 *
	 * @param string            $execucao    Identificador da execução.
	 * @param int               $indice      Índice da unidade.
	 * @param string            $id          Id declarado da unidade.
	 * @param string            $estado      Estado observado (BLOCKED ou FALHA).
	 * @param string            $motivo      Motivo já montado.
	 * @param array<int,string> $dependentes Unidades do fecho suspenso.
	 * @return void
	 */
	private static function registrar_bloqueio( string $execucao, int $indice, string $id, string $estado, string $motivo, array $dependentes ): void {
		$atual = get_option( self::OPTION_BLOQUEIOS, array() );

		$mesmo = is_array( $atual )
			&& isset( $atual['execucao'], $atual['unidades'] )
			&& (string) $atual['execucao'] === $execucao
			&& is_array( $atual['unidades'] );

		$registro = $mesmo
			? $atual
			: array(
				'execucao' => $execucao,
				'unidades' => array(),
			);

		$registro['unidades'][ (string) $indice ] = array(
			'id'          => $id,
			'estado'      => $estado,
			'motivo'      => $motivo,
			'dependentes' => $dependentes,
			'em'          => time(),
		);

		F3Base_Imp_Gravador::persistir_infra( self::OPTION_BLOQUEIOS, $registro );
	}

	/**
	 * Bloqueio já registrado para esta unidade nesta execução.
	 *
	 * @param string $execucao Identificador da execução.
	 * @param int    $indice   Índice da unidade.
	 * @return array<string,mixed> Registro, ou array vazio quando não há.
	 */
	private static function bloqueio_registrado( string $execucao, int $indice ): array {
		$atual = get_option( self::OPTION_BLOQUEIOS, array() );

		if ( ! is_array( $atual ) || ! isset( $atual['execucao'], $atual['unidades'] ) || ! is_array( $atual['unidades'] ) ) {
			return array();
		}

		if ( (string) $atual['execucao'] !== $execucao || ! isset( $atual['unidades'][ (string) $indice ] ) ) {
			return array();
		}

		$registro = $atual['unidades'][ (string) $indice ];

		if ( ! is_array( $registro ) ) {
			return array();
		}

		return array(
			'motivo'      => isset( $registro['motivo'] ) ? (string) $registro['motivo'] : '',
			'dependentes' => ( isset( $registro['dependentes'] ) && is_array( $registro['dependentes'] ) ) ? $registro['dependentes'] : array(),
			'em'          => isset( $registro['em'] ) ? (int) $registro['em'] : 0,
		);
	}

	/**
	 * Executa uma unidade.
	 *
	 * @param array{etapa:string,acao:string,indice:int,rotulo:string} $unidade Unidade.
	 * @param string                                                   $modo    Modo.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function executar( array $unidade, string $modo ): array {
		switch ( $unidade['acao'] ) {
			case 'preflight':
				return self::etapa_preflight( $modo );

			case 'tema':
				return self::normalizar( F3Base_Imp_Plugins::aplicar_tema() );

			case 'site_core':
				return self::normalizar( F3Base_Imp_Plugins::aplicar_site_core() );

			case 'plugin_instalavel':
				return self::normalizar( F3Base_Imp_Plugins::aplicar_instalavel( $unidade['indice'] ) );

			case 'plugin_embarcado':
				return self::normalizar( F3Base_Imp_Plugins::aplicar_embarcado( $unidade['indice'] ) );

			case 'backups_podados':
				return self::normalizar( F3Base_Imp_Plugins::podar_backups() );

			case 'autoupdate':
				return self::normalizar( F3Base_Imp_Plugins::ligar_autoupdate() );

			case 'onboarding':
				return self::normalizar( F3Base_Imp_Plugins::suprimir_onboarding() );

			case 'opcoes_wp':
				return self::etapa_opcoes_wp();

			case 'indexacao':
				return self::etapa_indexacao();

			case 'midia':
				return self::normalizar( F3Base_Imp_Conteudo::aplicar_midia( $unidade['indice'] ) );

			case 'categoria':
				return self::normalizar( F3Base_Imp_Conteudo::aplicar_categoria( $unidade['indice'] ) );

			case 'pagina':
				return self::normalizar( F3Base_Imp_Conteudo::aplicar_pagina( $unidade['indice'] ) );

			case 'post':
				return self::normalizar( F3Base_Imp_Conteudo::aplicar_post( $unidade['indice'] ) );

			case 'conteudo_nao_gerenciado':
				return self::normalizar( F3Base_Imp_Conteudo::relatar_nao_gerenciado() );

			case 'exemplo_do_wordpress':
				return self::normalizar( F3Base_Imp_Conteudo::aplicar_exemplo_do_wordpress() );

			case 'paginas_especiais':
				return self::etapa_paginas_especiais();

			case 'navegacao':
				return self::normalizar( F3Base_Imp_Navegacao::aplicar() );

			case 'seo_identidade':
				return self::com_plugin_de_seo( 'seo.identidade', array( 'F3Base_Imp_Seo', 'aplicar_identidade' ) );

			case 'seo_social':
				return self::com_plugin_de_seo( 'seo.social', array( 'F3Base_Imp_Seo', 'aplicar_social' ) );

			case 'seo_geral':
				return self::com_plugin_de_seo( 'seo.geral', array( 'F3Base_Imp_Seo', 'aplicar_geral' ) );

			case 'seo_llms':
				return self::com_plugin_de_seo( 'seo.llms_proprio', array( 'F3Base_Imp_Seo', 'aplicar_llms_proprio' ) );

			case 'seo_robots':
				return self::normalizar( F3Base_Imp_Seo::aplicar_robots_txt() );

			case 'orfaos_anteriores':
				return self::normalizar( F3Base_Imp_Plugins::migrar_orfaos_anteriores() );

			case 'limpeza':
				return self::normalizar( F3Base_Imp_Limpeza::aplicar() );

			case 'mcp':
				return F3Base_Imp_Entrega::etapa_canal_mcp();

			case 'options_site_core':
				return self::etapa_options_site_core();

			case 'formularios':
				return self::etapa_formularios();

			case 'cadencia':
				return self::etapa_cadencia();

			case 'entrega':
				return self::etapa_entrega( $modo );

			case 'encerramento':
				return self::etapa_encerramento( $modo );

			default:
				return array(
					'estado' => F3Base_Imp_Relatorio::FALHA,
					'rotulo' => 'lote.acao_desconhecida',
					'motivo' => sprintf(
						/* translators: %s: nome da ação. */
						__( 'ação de lote desconhecida: %s. Defeito do orquestrador, não do site.', 'f3base' ),
						$unidade['acao']
					),
				);
		}
	}

	/* ------------------------------------------------------------------ *
	 * Etapas
	 * ------------------------------------------------------------------ */

	/**
	 * Preflight: mede tudo e decide se pode haver mutação.
	 *
	 * @param string $modo Modo.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_preflight( string $modo ): array {
		$medido = F3Base_Imp_Preflight::executar();

		foreach ( $medido['capacidades'] as $cap => $dados ) {
			F3Base_Imp_Relatorio::condicional(
				$dados['critica'],
				sprintf(
					/* translators: 1: capacidade, 2: motivo declarado, 3: presença observada. */
					__( 'a capacidade %1$s não é crítica nesta instalação — %2$s (observada no usuário em operação: %3$s).', 'f3base' ),
					$cap,
					$dados['motivo'],
					$dados['tem'] ? __( 'presente', 'f3base' ) : __( 'ausente', 'f3base' )
				),
				$dados['tem'],
				'preflight.capacidade:' . $cap,
				sprintf(
					/* translators: %s: capacidade. */
					__( 'capacidade %s presente no usuário em operação.', 'f3base' ),
					$cap
				),
				sprintf(
					/* translators: 1: capacidade, 2: motivo da criticidade. */
					__( 'capacidade crítica ausente: %1$s. %2$s Nenhuma mutação é executada.', 'f3base' ),
					$cap,
					$dados['motivo']
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
					/* FATO CRÍTICO: sem a capacidade, a instalação não pode acontecer. */
					'gate'      => 'aplicacao',
				)
			);
		}

		F3Base_Imp_Relatorio::avaliar(
			$medido['filesystem']['direto'],
			'preflight.filesystem_direto',
			sprintf(
				/* translators: %s: método observado. */
				__( 'método de filesystem: %s.', 'f3base' ),
				$medido['filesystem']['metodo']
			),
			sprintf(
				/* translators: %s: método observado. */
				__( 'o método de filesystem é %s, não direto: instalar tema e plugins exigiria credencial do operador a cada passo.', 'f3base' ),
				$medido['filesystem']['metodo']
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
				/* FATO CRÍTICO: sem isto a instalação não pode acontecer. */
				'gate'      => 'aplicacao',
			)
		);

		foreach ( $medido['destinos'] as $nome => $destino ) {
			F3Base_Imp_Relatorio::avaliar(
				$destino['gravavel'],
				'preflight.destino:' . $nome,
				sprintf(
					/* translators: 1: nome do destino, 2: caminho. */
					__( 'destino gravável: %1$s em %2$s.', 'f3base' ),
					$nome,
					$destino['caminho']
				),
				sprintf(
					/* translators: 1: nome do destino, 2: caminho. */
					__( 'destino NÃO gravável: %1$s em %2$s.', 'f3base' ),
					$nome,
					$destino['caminho']
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
					/* FATO CRÍTICO: sem poder escrever no destino, nada é instalado. */
					'gate'      => 'aplicacao',
				)
			);
		}

		F3Base_Imp_Relatorio::avaliar(
			$medido['disco']['suficiente'],
			'preflight.disco',
			sprintf(
				/* translators: 1: bytes livres, 2: bytes necessários. */
				__( 'espaço livre %1$s bytes contra %2$s bytes necessários (pacote temporário, instalação e preimagem).', 'f3base' ),
				number_format_i18n( (float) $medido['disco']['livre'] ),
				number_format_i18n( (float) $medido['disco']['necessario'] )
			),
			sprintf(
				/* translators: 1: bytes livres, 2: bytes necessários. */
				__( 'espaço insuficiente: %1$s bytes livres contra %2$s necessários.', 'f3base' ),
				number_format_i18n( (float) $medido['disco']['livre'] ),
				number_format_i18n( (float) $medido['disco']['necessario'] )
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
				/* FATO CRÍTICO: sem isto a instalação não pode acontecer. */
				'gate'      => 'aplicacao',
			)
		);

		F3Base_Imp_Relatorio::avaliar(
			$medido['rede']['alcancavel'],
			'preflight.saida_https',
			sprintf(
				/* translators: 1: alvo, 2: detalhe. */
				__( 'saída HTTPS para a fonte oficial alcançável: %1$s (%2$s).', 'f3base' ),
				$medido['rede']['alvo'],
				$medido['rede']['detalhe']
			),
			sprintf(
				/* translators: 1: alvo, 2: detalhe. */
				__( 'saída HTTPS indisponível para %1$s: %2$s. A instalação manual pelo wp-admin é o caminho de contingência declarado.', 'f3base' ),
				$medido['rede']['alvo'],
				$medido['rede']['detalhe']
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		$php_minimo = (string) F3Base_Imp_Decisoes::valor( 'ambiente.php_minimo' );

		F3Base_Imp_Relatorio::avaliar(
			! version_compare( PHP_VERSION, $php_minimo, '<' ),
			'preflight.php_minimo',
			sprintf(
				/* translators: 1: versão em execução, 2: mínimo declarado. */
				__( 'PHP %1$s atende ao mínimo declarado %2$s.', 'f3base' ),
				PHP_VERSION,
				$php_minimo
			),
			sprintf(
				/* translators: 1: versão em execução, 2: mínimo declarado. */
				__( 'PHP %1$s abaixo do mínimo declarado %2$s.', 'f3base' ),
				PHP_VERSION,
				$php_minimo
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
				/* FATO CRÍTICO: abaixo do mínimo o próprio implantador não roda. */
				'gate'      => 'aplicacao',
			)
		);

		/*
		 * O ESTADO SAI DA MEDIÇÃO, e é aqui que a lição da 1.0.14 está escrita
		 * em código: esta linha era WARN incondicional. Ela dizia de si mesma
		 * "fato de ambiente, relatado sem decidir gate" e ainda assim promovia a
		 * unidade do preflight a amarelo, numa execução em que nada estava
		 * errado. WARN que sai sempre treina o operador a ignorar WARN — a mesma
		 * família do "24 FALHA por ausência de terceiro" e da checagem que
		 * acusava o próprio pacote.
		 *
		 * Agora: limites suficientes para a execução em lotes fecham OK NOMEANDO
		 * os valores medidos; limite abaixo do piso declarado em
		 * `ambiente.limites_minimos` fecha WARN nomeando QUAL ficou abaixo e o
		 * que ele custa. O detalhe não sumiu do relatório — mudou de estado.
		 */
		$limites = self::veredito_de_limites(
			(array) $medido['limites'],
			array(
				'max_execution_time_s'   => (int) F3Base_Imp_Decisoes::valor( 'ambiente.limites_minimos.max_execution_time_s' ),
				'memory_mb'              => (int) F3Base_Imp_Decisoes::valor( 'ambiente.limites_minimos.memory_mb' ),
				'upload_max_filesize_mb' => (int) F3Base_Imp_Decisoes::valor( 'ambiente.limites_minimos.upload_max_filesize_mb' ),
				'post_max_size_mb'       => (int) F3Base_Imp_Decisoes::valor( 'ambiente.limites_minimos.post_max_size_mb' ),
			)
		);

		F3Base_Imp_Relatorio::emitir(
			$limites['estado'],
			'preflight.limites',
			$limites['motivo'],
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
				/* FATO CRÍTICO: sem isto a instalação não pode acontecer. */
				'gate'      => 'aplicacao',
			)
		);

		$divergencias = $medido['baseline']['divergencias'];

		/*
		 * OS ARTEFATOS DO PACOTE SÃO BASELINE POR DEFINIÇÃO, e a mensagem do
		 * ramo OK os NOMEIA com a chave da configuração que os resolveu: a 1.0.7
		 * acusou `base-site-core-fator3` — o plugin que este pacote instala e ativa —
		 * como divergência a classificar, e a saída que a própria mensagem
		 * oferecia teria feito o pacote se declarar plugin de terceiro.
		 */
		$artefatos = array_map(
			static fn ( array $item ): string => $item['slug'] . ' [' . $item['tipo'] . ', de ' . $item['origem'] . ']',
			(array) $medido['baseline']['artefatos']
		);

		/*
		 * O BASELINE RELATA, E NUNCA REPROVA. Esta linha custou uma implantação
		 * inteira em produção, e o modo é o que importa registrar.
		 *
		 * Ela fechava FALHA quando encontrava plugin no site que não estava
		 * declarado em lugar nenhum — com uma mensagem que dizia, ela mesma,
		 * "eles ficam como estão". Enquanto o template declarava o plugin da
		 * hospedagem, a linha nunca disparava. Quando `plugins_operacionais`
		 * passou a nascer vazia — decisão certa, porque o plugin que a
		 * hospedagem instala é fato de UM site e não do template —, a linha
		 * passou a disparar em todo site que tivesse qualquer plugin
		 * pré-existente. Ou seja: em toda hospedagem que instala alguma coisa.
		 *
		 * O efeito medido: FALHA promoveu a unidade `preflight`, 39 unidades
		 * declaravam depender dela, e nada foi instalado. Sem tema, sem plugins,
		 * sem conteúdo — por causa de uma linha descritiva.
		 *
		 * Plugin que já estava no site é INFORMAÇÃO. O pacote não o instala, não
		 * o desativa e não o remove; ele existe e é isso. Declará-lo em
		 * `plugins_operacionais` continua servindo para nomear o responsável no
		 * relatório, e continua OPCIONAL — a lista nasce vazia por desenho, e
		 * exigir que alguém a preencha seria exigir que o operador soubesse de
		 * antemão o que a hospedagem dele instala.
		 */
		F3Base_Imp_Relatorio::emitir(
			F3Base_Imp_Relatorio::OK,
			'preflight.baseline',
			sprintf(
				/* translators: 1: versão do WordPress, 2: tema ativo, 3: quantidade de plugins, 4: artefatos do pacote, 5: plugins que já estavam no site. */
				__( 'baseline: WordPress %1$s, tema ativo %2$s, %3$d plugin(s) no disco. Instalados por este pacote: %4$s. Já estavam no site e ficam como estão: %5$s.', 'f3base' ),
				(string) $medido['baseline']['wordpress'],
				(string) $medido['baseline']['tema_ativo'],
				count( $medido['baseline']['plugins'] ),
				array() === $artefatos ? __( 'nenhum', 'f3base' ) : implode( '; ', $artefatos ),
				array() === $divergencias
					? __( 'nenhum', 'f3base' )
					: implode( ', ', array_map( static fn ( array $item ): string => $item['slug'] . ' ' . $item['versao'], $divergencias ) )
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
				/*
				 * GATE DE RELATO, e sem frase de tela: linha que só relata o que
				 * encontrou não decide se o site pode ser instalado, e não é o
				 * que alguém quer ler quando abre a página. Ela declarava `fase`
				 * até a 1.7.2 por falta de um nome para "não decide", e isso
				 * fazia o relatório afirmar que este host não produz o censo de
				 * plugins do próprio disco.
				 */
				'gate'      => 'relato',
			)
		);

		/*
		 * O SEGUNDO EMISSOR SAI NOMEADO AQUI, e este é o único momento em que
		 * nomeá-lo ainda serve para alguma coisa: antes de qualquer mutação.
		 *
		 * A linha NÃO desativa nada e não segura a aplicação. A premissa desta
		 * release é que quem opera o site é o agente, e o pacote nomeia em vez
		 * de decidir — mas contagem em dobro que ninguém acusa reescreve o
		 * lance do leilão em silêncio, e é isso que esta linha existe para
		 * impedir. Quem confere de verdade é `tracking.emissor_unico`, na
		 * contagem do HTML publicado; a classificação daqui é a dica que chega
		 * cedo o bastante para o operador decidir.
		 */
		$emissores_observados = (array) ( $medido['baseline']['emissores'] ?? array() );

		if ( array() === $emissores_observados ) {
			F3Base_Imp_Relatorio::emitir(
				'OK',
				'plugins.emissor_concorrente',
				__( 'nenhum plugin ativo classificado como emissor concorrente: a emissão de toda tag de medição é do módulo tracking do site-core, dirigida pelos IDs gravados em options. A lista declarada de emissores conhecidos é dica para classificar cedo — quem confere a contagem é tracking.emissor_unico, no HTML publicado.', 'f3base' ),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				'WARN',
				'plugins.emissor_concorrente',
				sprintf(
					/* translators: %s: plugins classificados como emissores concorrentes, com o motivo medido. */
					__( 'plugin(s) ativo(s) classificado(s) como emissor-concorrente: %s. Nada foi desativado — depois da instalação quem modifica o site é o agente. A pré-condição para o plugin ficar como LEITOR é ter o snippet e a medição automática de conversões desligados; enquanto ela não valer, a mesma conversão pode sair duas vezes e o lance do leilão é reescrito por um número que ninguém conferiu.', 'f3base' ),
					implode(
						'; ',
						array_map(
							static fn ( array $item ): string => (string) $item['slug'] . ' (' . (string) $item['emissor'] . ': ' . (string) $item['motivo_emissor'] . ')',
							$emissores_observados
						)
					)
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		}

		F3Base_Imp_Relatorio::avaliar(
			array() === $medido['colisoes']['conflitos'],
			'preflight.colisao_de_slug',
			sprintf(
				/* translators: 1: quantidade de refs livres, 2: adoções autorizadas. */
				__( 'nenhuma colisão sem propriedade: %1$d referência(s) livre(s) ou já gerenciada(s); adoções autorizadas e provadas pela instalação: %2$s.', 'f3base' ),
				count( $medido['colisoes']['livres'] ),
				array() === $medido['colisoes']['adocoes']
					? __( 'nenhuma', 'f3base' )
					: implode( ', ', array_map( static fn ( array $item ): string => $item['ref'] . ' (#' . $item['id'] . ')', $medido['colisoes']['adocoes'] ) )
			),
			sprintf(
				/* translators: %s: conflitos nomeados. */
				__( 'CONFLICT sem escrita — slug igual não prova propriedade: %s', 'f3base' ),
				implode( ' | ', array_map( static fn ( array $item ): string => $item['ref'] . ' → #' . $item['id'] . ' "' . $item['titulo'] . '": ' . $item['motivo'], $medido['colisoes']['conflitos'] ) )
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		/*
		 * OVERRIDE É PERGUNTA DE CONTEÚDO, NÃO DE EXISTÊNCIA. O WordPress cria
		 * o post `wp_global_styles` sozinho ao ativar um tema de blocos, e a
		 * versão anterior, medindo existência, reprovaria TODA instalação de
		 * tema de blocos, para sempre — a FALHA que sai sempre é a que ensina o
		 * operador a ignorar FALHA.
		 *
		 * A outra metade do erro seria sumir com o stub do relatório: ele
		 * aparece NOMEADO na linha de aprovação, como post inspecionado e
		 * inofensivo, com o motivo que o absolveu.
		 */
		$overrides    = $medido['overrides'];
		$personalizam = array_values( array_filter( $overrides, static fn ( array $item ): bool => (bool) $item['override'] ) );
		$inofensivos  = array_values( array_filter( $overrides, static fn ( array $item ): bool => ! (bool) $item['override'] ) );

		$descrever = static fn ( array $item ): string => $item['tipo'] . ':' . $item['slug'] . ' (#' . $item['id'] . ', ' . $item['bytes'] . ' bytes, ' . $item['data'] . ')';

		F3Base_Imp_Relatorio::avaliar(
			array() === $personalizam,
			'tema.sem_override_de_editor',
			sprintf(
				/* translators: 1: quantidade de posts inspecionados, 2: posts inspecionados e absolvidos, com o motivo de cada um. */
				__( 'nenhuma personalização do editor de site: %1$d post(s) de wp_template, wp_template_part e wp_global_styles inspecionado(s) POR CONTEÚDO, e o arquivo do tema continua sendo o que o visitante recebe. Inspecionado(s) e sem personalização: %2$s.', 'f3base' ),
				count( $overrides ),
				array() === $inofensivos
					? __( 'nenhum post desses tipos existe neste site', 'f3base' )
					: implode( ' | ', array_map( static fn ( array $item ): string => $descrever( $item ) . ' — ' . $item['motivo'], $inofensivos ) )
			),
			sprintf(
				/* translators: 1: overrides com personalização, com o motivo de cada um, 2: posts inspecionados e absolvidos. */
				__( 'overrides do editor de site com personalização de fato — o BANCO VENCE O ARQUIVO, e atualizar o tema não muda o que o visitante recebe enquanto eles existirem: %1$s. A política é exportar, decidir (incorporar ao arquivo ou reverter) e remover; nunca conviver. Inspecionados e sem personalização, que não entram nesta acusação: %2$s.', 'f3base' ),
				implode( ' | ', array_map( static fn ( array $item ): string => $descrever( $item ) . ' — ' . $item['motivo'], $personalizam ) ),
				array() === $inofensivos ? __( 'nenhum', 'f3base' ) : implode( ' | ', array_map( $descrever, $inofensivos ) )
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		F3Base_Imp_Relatorio::avaliar(
			$medido['origem']['suportada'],
			'preflight.contrato_de_caminho',
			sprintf(
				/* translators: %s: motivo declarado. */
				__( 'origem de release suportada: %s', 'f3base' ),
				$medido['origem']['motivo']
			),
			$medido['origem']['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
				/*
				 * DEIXOU DE SER FATO CRÍTICO na 1.4.0, e o motivo é a subida de
				 * 1.3.1 para 1.3.2 que não aconteceu. A release foi cortada sem
				 * acrescentar 1.3.1 à matriz, esta linha fechou FALHA num site
				 * onde tudo funcionava, e como ela declarava `gate: aplicacao`
				 * a unidade preflight foi promovida e suspendeu 39 unidades: o
				 * site não recebeu nada.
				 *
				 * Aplicado o teste que vale para toda trava deste pacote —
				 * "tirando isto, o site quebra?" —, a resposta é NÃO. A matriz
				 * responde por uma pergunta NOSSA, de homologação: de que versão
				 * instalada este implantador já provou saber subir. Uma versão
				 * que ninguém listou não torna a instalação perigosa; ela torna
				 * a nossa evidência incompleta, e a linha continua dizendo isso
				 * em voz alta. Bloquear a instalação do cliente por um esquecimento
				 * de processo nosso é proteger o processo, não o site.
				 *
				 * A COBRANÇA MUDOU DE LUGAR, não sumiu: quem recusa uma release
				 * que não declara a anterior é a suíte, no build, em
				 * `release.declara_a_anterior` — antes de o pacote existir, e
				 * não depois de ele chegar ao site de alguém.
				 *
				 * E O GATE PASSOU A SE CHAMAR `relato` NA 1.7.3. A 1.4.0
				 * escreveu `fase` porque era o único valor que significava "não
				 * suspende ninguém", e o efeito foi o relatório dizer, sobre
				 * esta linha, que a evidência dela vem de outra fase: ela vem
				 * daqui — leitura de volta da release instalada contra o
				 * catálogo, tudo no host, agora. Uma FALHA aqui continua sem
				 * suspender nada e continua derrubando o estado da aplicação,
				 * que é o certo: o pacote não tem prova de saber subir daquela
				 * origem, e o implantador fica no ar até que alguém decida.
				 */
				'gate'      => 'relato',
			)
		);

		/*
		 * "Declara o schema e validou contra ele" É O RAMO BOM, e sair em WARN
		 * fazia a linha dizer o contrário do que media. O estado agora vem da
		 * medição: schema declarado e sem erro de validação fecha OK com o
		 * detalhe no texto; schema não declarado, ou erro de validação
		 * registrado, fecha WARN nomeando o que está adverso.
		 */
		$schema_declarado = (string) F3Base_Imp_Config::obter( '$schema', '' );
		$erros_do_schema  = F3Base_Imp_Config::erros();

		if ( '' !== $schema_declarado && array() === $erros_do_schema ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'config.schema_declarado',
				sprintf(
					/* translators: 1: schema declarado no arquivo, 2: hash da configuração. */
					__( 'a configuração declara o schema %1$s e validou contra ele, sem erro registrado; hash da configuração: %2$s.', 'f3base' ),
					$schema_declarado,
					substr( F3Base_Imp_Config::hash(), 0, 16 )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'config.schema_declarado',
				sprintf(
					/* translators: 1: o que está adverso, 2: hash da configuração. */
					__( 'a configuração NÃO está amarrada a um schema válido: %1$s. Sem essa amarração, chave escrita errada entra em silêncio e só aparece como comportamento estranho no site. Hash da configuração: %2$s.', 'f3base' ),
					'' === $schema_declarado
						? __( 'a chave $schema está ausente ou vazia', 'f3base' )
						: sprintf(
							/* translators: 1: quantidade de erros, 2: erros nomeados. */
							__( '%1$d erro(s) de validação registrados contra %2$s', 'f3base' ),
							count( $erros_do_schema ),
							$schema_declarado
						) . ': ' . implode( ' | ', $erros_do_schema ),
					substr( F3Base_Imp_Config::hash(), 0, 16 )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		}

		if ( $medido['bloqueado'] ) {
			if ( self::MODO_EXECUCAO === $modo ) {
				self::definir_estado( self::FALHA );
			}

			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'rotulo' => 'preflight',
				'motivo' => sprintf(
					/* translators: 1: capacidades ausentes, 2: quantidade de conflitos. */
					__( 'preflight BLOCKED, sem mutação: capacidades/pré-condições ausentes (%1$s) e %2$d colisão(ões) de slug sem propriedade.', 'f3base' ),
					array() === $medido['criticas_ausentes'] ? __( 'nenhuma', 'f3base' ) : implode( ', ', $medido['criticas_ausentes'] ),
					count( $medido['colisoes']['conflitos'] )
				),
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::OK,
			'rotulo' => 'preflight',
			'motivo' => __( 'preflight completo: capacidades, filesystem, destinos, disco, rede, limites, baseline, colisões, overrides e contrato de caminho medidos, e nenhum impedimento crítico.', 'f3base' ),
		);
	}

	/**
	 * O veredito dos limites do PHP: OK quando bastam, WARN quando um não basta.
	 *
	 * FUNÇÃO PURA — recebe o que foi medido e o piso declarado, e devolve estado
	 * e texto. Nenhuma leitura de ambiente aqui dentro: é o que permite exercitar
	 * os DOIS ramos na sonda, que é o piso desta regra.
	 *
	 * `max_execution_time = 0` é AUSÊNCIA de limite, nunca limite zero — tratar
	 * o zero como "abaixo do piso" faria a checagem acusar exatamente o ambiente
	 * mais folgado que existe.
	 *
	 * @param array<string,mixed> $medido  Saída de F3Base_Imp_Preflight::medir_limites().
	 * @param array<string,int>   $minimos Piso declarado em ambiente.limites_minimos.
	 * @return array{estado:string,motivo:string,abaixo:array<int,string>}
	 */
	public static function veredito_de_limites( array $medido, array $minimos ): array {
		$tempo   = (int) ( $medido['max_execution_time'] ?? 0 );
		$memoria = (int) ( $medido['memoria_bytes'] ?? 0 );
		$upload  = (int) ( $medido['upload_bytes'] ?? 0 );
		$post    = (int) ( $medido['post_bytes'] ?? 0 );

		$piso_tempo   = (int) ( $minimos['max_execution_time_s'] ?? 0 );
		$piso_memoria = (int) ( $minimos['memory_mb'] ?? 0 ) * 1048576;
		$piso_upload  = (int) ( $minimos['upload_max_filesize_mb'] ?? 0 ) * 1048576;
		$piso_post    = (int) ( $minimos['post_max_size_mb'] ?? 0 ) * 1048576;

		$abaixo = array();

		if ( 0 !== $tempo && $tempo < $piso_tempo ) {
			$abaixo[] = sprintf(
				/* translators: 1: tempo observado, 2: piso declarado. */
				__( 'max_execution_time %1$ds contra o piso declarado de %2$ds — o servidor interrompe o lote no meio da gravação, e a retomada refaz a etapa inteira', 'f3base' ),
				$tempo,
				$piso_tempo
			);
		}

		if ( $memoria < $piso_memoria ) {
			$abaixo[] = sprintf(
				/* translators: 1: memória observada, 2: piso declarado em MB. */
				__( 'memory_limit %1$s contra o piso declarado de %2$d MB — a montagem de um lote morre sem relatório, que é a pior falha possível: nenhuma linha sai', 'f3base' ),
				(string) ( $medido['memory_limit'] ?? '' ),
				(int) ( $minimos['memory_mb'] ?? 0 )
			);
		}

		if ( $upload < $piso_upload ) {
			$abaixo[] = sprintf(
				/* translators: 1: limite observado, 2: piso declarado em MB. */
				__( 'upload_max_filesize %1$s contra o piso declarado de %2$d MB — o zip de um plugin ou o envio de mídia é recusado pelo próprio PHP, antes de qualquer código deste pacote', 'f3base' ),
				(string) ( $medido['upload_max_filesize'] ?? '' ),
				(int) ( $minimos['upload_max_filesize_mb'] ?? 0 )
			);
		}

		if ( $post < $piso_post ) {
			$abaixo[] = sprintf(
				/* translators: 1: limite observado, 2: piso declarado em MB. */
				__( 'post_max_size %1$s contra o piso declarado de %2$d MB — o corpo inteiro da requisição não cabe, e o envio falha mesmo com upload_max_filesize suficiente', 'f3base' ),
				(string) ( $medido['post_max_size'] ?? '' ),
				(int) ( $minimos['post_max_size_mb'] ?? 0 )
			);
		}

		$observados = sprintf(
			/* translators: 1: tempo, 2: memória, 3: upload, 4: post. */
			__( 'max_execution_time %1$s, memory_limit %2$s, upload_max_filesize %3$s, post_max_size %4$s', 'f3base' ),
			0 === $tempo ? __( 'sem limite', 'f3base' ) : $tempo . 's',
			(string) ( $medido['memory_limit'] ?? '' ),
			(string) ( $medido['upload_max_filesize'] ?? '' ),
			(string) ( $medido['post_max_size'] ?? '' )
		);

		if ( array() === $abaixo ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::OK,
				'motivo' => sprintf(
					/* translators: 1: limites observados, 2: piso declarado. */
					__( 'limites suficientes para a execução em lotes — %1$s. Piso declarado em ambiente.limites_minimos: %2$s. Nenhum limite ficou abaixo dele, e é por isso que esta linha é OK: medição sem achado adverso não é aviso.', 'f3base' ),
					$observados,
					sprintf(
						/* translators: 1: tempo, 2: memória, 3: upload, 4: post. */
						__( '%1$ds, %2$d MB, %3$d MB, %4$d MB', 'f3base' ),
						$piso_tempo,
						(int) ( $minimos['memory_mb'] ?? 0 ),
						(int) ( $minimos['upload_max_filesize_mb'] ?? 0 ),
						(int) ( $minimos['post_max_size_mb'] ?? 0 )
					)
				),
				'abaixo' => array(),
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::WARN,
			'motivo' => sprintf(
				/* translators: 1: quantidade abaixo do piso, 2: cada um nomeado com o custo, 3: limites observados. */
				__( '%1$d limite(s) ABAIXO do piso declarado em ambiente.limites_minimos, com o que cada um custa: %2$s. Observados: %3$s. Não bloqueia a execução — a execução em lotes existe justamente para caber em ambiente apertado —, e é aviso porque a folga que a retomada supõe deixou de existir.', 'f3base' ),
				count( $abaixo ),
				implode( '; ', $abaixo ),
				$observados
			),
			'abaixo' => $abaixo,
		);
	}

	/**
	 * Nome, descrição, idioma, fuso e permalinks.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_opcoes_wp(): array {
		$partes = array();
		$falhou = false;

		foreach (
			array(
				'blogname'        => (string) F3Base_Imp_Config::obter( 'site.nome', '' ),
				'blogdescription' => (string) F3Base_Imp_Config::obter( 'site.tagline', '' ),
				'timezone_string' => (string) F3Base_Imp_Projeto::obter( 'ambiente.fuso', '' ),
			) as $option => $valor
		) {
			$resultado = F3Base_Imp_Gravador::gravar( $option, $valor );
			$partes[]  = $option . ': ' . $resultado['motivo'];
			$falhou    = $falhou || in_array( $resultado['estado'], array( F3Base_Imp_Relatorio::FALHA, F3Base_Imp_Relatorio::BLOCKED ), true );
		}

		$locale     = (string) F3Base_Imp_Config::obter( 'ambiente.locale', 'en_US' );
		$disponivel = in_array( $locale, array_merge( array( 'en_US' ), get_available_languages() ), true );

		if ( ! $disponivel && ! F3Base_Imp_Gravador::em_simulacao() ) {
			if ( ! function_exists( 'wp_download_language_pack' ) ) {
				require_once ABSPATH . 'wp-admin/includes/translation-install.php';
			}

			$baixado    = wp_download_language_pack( $locale );
			$disponivel = false !== $baixado && in_array( $locale, array_merge( array( 'en_US' ), get_available_languages() ), true );
		}

		if ( $disponivel ) {
			$resultado = F3Base_Imp_Gravador::gravar( 'WPLANG', 'en_US' === $locale ? '' : $locale );
			$partes[]  = 'WPLANG: ' . $resultado['motivo'];
		} else {
			/*
			 * `WPLANG` sem os arquivos de tradução NÃO gera erro: o WordPress cai
			 * para o inglês, e o sintoma é discreto ("12 de July de 2026").
			 * Gravar assim mesmo produziria um site que mente sobre o idioma.
			 */
			$partes[] = sprintf(
				/* translators: %s: locale declarado. */
				__( 'WPLANG NÃO gravado: o pacote de tradução de %s não está disponível e WPLANG sem arquivos cai para o inglês em silêncio.', 'f3base' ),
				$locale
			);
			$falhou   = true;
		}

		/*
		 * OS DOIS CAMINHOS DE REESCRITA SAEM DO MESMO PRODUTOR, e a base de
		 * categoria é gravada ANTES da decisão de permalinks porque é ela que
		 * regrava as regras: duas escritas de reescrita com um flush só, e o
		 * flush do lado certo. Gravar a base DEPOIS deixaria o valor no banco
		 * e a regra velha no ar até alguém salvar permalinks à mão.
		 */
		$derivados = F3Base_Imp_Conteudo::derivados_do_blog_declarados();

		if ( ! $derivados['ok'] ) {
			$partes[] = $derivados['motivo'];
			$falhou   = true;

			return array(
				'estado' => F3Base_Imp_Relatorio::FALHA,
				'rotulo' => 'wordpress.opcoes',
				'motivo' => implode( ' | ', $partes ),
			);
		}

		$base_atual = (string) get_option( 'category_base', '' );
		$resultado  = F3Base_Imp_Gravador::gravar( 'category_base', $derivados['base_de_categoria'] );
		$partes[]   = 'category_base: ' . $resultado['motivo'];
		$falhou     = $falhou || in_array( $resultado['estado'], array( F3Base_Imp_Relatorio::FALHA, F3Base_Imp_Relatorio::BLOCKED ), true );

		$desejado  = $derivados['estrutura'];
		$observado = (string) get_option( 'permalink_structure', '' );
		$decisao   = self::aplicar_decisao_de_permalinks( $observado, $desejado, $base_atual !== $derivados['base_de_categoria'] );

		$partes[] = $decisao['resumo'];
		$falhou   = $falhou || F3Base_Imp_Relatorio::FALHA === $decisao['estado'];

		return array(
			'estado' => $falhou ? F3Base_Imp_Relatorio::FALHA : ( F3Base_Imp_Gravador::em_simulacao() ? F3Base_Imp_Relatorio::NA : F3Base_Imp_Relatorio::OK ),
			'rotulo' => 'wordpress.opcoes',
			'motivo' => implode( ' | ', $partes ),
		);
	}

	/**
	 * A DECISÃO declarada sobre permalinks, MEDIDA antes de aplicada.
	 *
	 * Até a 1.0.10 o padrão era `manter-existente`: divergiu, BLOCKED, sem
	 * escrita. O motivo do bloqueio continua válido onde nasceu — trocar a
	 * estrutura quebra TODA URL já publicada e indexada —, mas o padrão estava
	 * errado para o que este pacote É. O implantador-base é ferramenta de
	 * CONFIGURAÇÃO INICIAL, e um padrão que se recusa a aplicar a estrutura
	 * declarada devolve ao operador exatamente o ajuste manual que o pacote
	 * existe para eliminar: a promessa é "sem passo manual".
	 *
	 * A 1.0.11 conciliou as duas coisas MEDINDO, em vez de escolher um padrão
	 * fixo — a mesma regra de `blog_public`. A 1.0.17 foi além, e o padrão
	 * passou a ser `aplicar-e-cobrir`: medir e RECUSAR devolvia ao operador uma
	 * lista de opções para escolher à mão, e o que a medição encontrava era, na
	 * instalação típica, as duas páginas que o próprio WordPress cria. Aplicar
	 * COBRINDO resolve as duas obrigações de uma vez, porque o redirect é
	 * aditivo: a estrutura declarada entra e nenhuma URL publicada passa a 404.
	 *
	 * O FLUSH NÃO PODE DEPENDER SÓ DA ESTRUTURA, e é a 2.2.0 que fecha isso. A
	 * base de categoria passou a ser gravada nesta mesma etapa, e ela também é
	 * regra de reescrita. Com a estrutura já igual à declarada, o veredito sai
	 * antes de gravar e — até aqui — saía também antes de regravar as regras:
	 * a base nova ficaria no banco e a regra velha no ar, sem erro, até alguém
	 * salvar permalinks à mão. Por isso a etapa diz se A OUTRA option mudou.
	 *
	 * @param string $observado         Estrutura observada.
	 * @param string $desejado          Estrutura declarada.
	 * @param bool   $base_de_categoria_mudou A base de categoria mudou nesta execução?
	 * @return array{estado:string,resumo:string}
	 */
	private static function aplicar_decisao_de_permalinks( string $observado, string $desejado, bool $base_de_categoria_mudou = false ): array {
		$decisao = self::PERMALINKS_COBRIR;

		/*
		 * A medição só faz sentido quando há troca. Estrutura já igual não põe
		 * URL nenhuma em risco, e varrer o banco para descobrir isso seria
		 * consulta sem pergunta.
		 */
		$medicao  = $observado === $desejado ? array( 'em_risco' => array(), 'sem_caminho' => array() ) : self::medir_urls_de_terceiro();
		$veredito = self::decisao_de_permalinks( $decisao, $observado, $desejado, $medicao );

		if ( self::ACAO_PERMALINK_APLICAR !== $veredito['acao'] ) {
			$regravou = $base_de_categoria_mudou && ! F3Base_Imp_Gravador::em_simulacao();

			if ( $regravou ) {
				flush_rewrite_rules( false );
			}

			F3Base_Imp_Relatorio::emitir(
				$veredito['estado'],
				'wordpress.permalinks',
				$veredito['motivo'] . ' ' . (
					$regravou
						? __( 'A estrutura não mudou, mas a base de categoria mudou nesta execução: as regras de reescrita foram regravadas por causa dela.', 'f3base' )
						: __( 'Nem a estrutura nem a base de categoria mudaram nesta execução: nada a regravar nas regras de reescrita.', 'f3base' )
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);

			return array(
				'estado' => $veredito['estado'],
				'resumo' => $veredito['resumo'],
			);
		}

		/*
		 * As URLs são medidas ANTES da troca: depois dela `get_permalink()` já
		 * devolve o endereço novo, e o antigo — o que continua circulando —
		 * deixa de existir para quem quisesse redirecioná-lo.
		 *
		 * A COBERTURA sai do veredito, e o conjunto coberto é o MESMO que a
		 * medição já classificou como em risco: são exatamente os publicados não
		 * gerenciados com URL de caminho, os objetos por causa dos quais o
		 * padrão antigo recusava a troca. Reaproveitar a medição em vez de
		 * varrer o banco de novo é o que impede que duas varreduras com o mesmo
		 * propósito discordem sobre o mesmo banco.
		 */
		$antigas = self::urls_dos_gerenciados();

		if ( (bool) ( $veredito['cobertura'] ?? false ) ) {
			foreach ( (array) ( $medicao['em_risco'] ?? array() ) as $item ) {
				$caminho = (string) ( $item['caminho'] ?? '' );

				if ( '' === $caminho || isset( $antigas[ $caminho ] ) ) {
					continue;
				}

				$antigas[ $caminho ] = self::REF_POR_ID . (int) ( $item['id'] ?? 0 );
			}
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'wordpress.permalinks',
				sprintf(
					/* translators: 1: motivo da decisão, 2: caminhos publicados que seriam cobertos, nomeados. */
					__( 'modo simulação: nenhuma escrita. %1$s Trocaria a estrutura e gravaria o redirecionamento dos caminhos publicados hoje: %2$s.', 'f3base' ),
					$veredito['motivo'],
					array() === $antigas ? __( 'nenhum', 'f3base' ) : implode( ', ', array_keys( $antigas ) )
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);

			return array(
				'estado' => F3Base_Imp_Relatorio::NA,
				'resumo' => sprintf(
					/* translators: %s: decisão declarada. */
					__( 'permalinks: modo simulação, decisão declarada "%s".', 'f3base' ),
					$decisao
				),
			);
		}

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_OPTION,
			'permalink_structure',
			$observado,
			$desejado,
			array(
				'acao'  => 'option.restaurar',
				'nome'  => 'permalink_structure',
				'valor' => $observado,
			)
		);

		$gravou = F3Base_Imp_Gravador::gravar( 'permalink_structure', $desejado );

		/*
		 * As regras de reescrita são regravadas ANTES de recalcular os
		 * endereços novos: `get_permalink()` compõe pela estrutura, e servir a
		 * estrutura nova com as regras velhas é 404 em toda URL bonita.
		 */
		flush_rewrite_rules( false );

		$redirects = self::gravar_redirects_de_permalink( $antigas );
		$relido    = (string) get_option( 'permalink_structure', '' );
		$conferiu  = $relido === $desejado;

		$mensagem = sprintf(
			/* translators: 1: motivo da decisão, 2: motivo do gravador, 3: resultado dos redirects. */
			__( '%1$s %2$s As regras de reescrita foram regravadas. %3$s', 'f3base' ),
			$veredito['motivo'],
			$gravou['motivo'],
			$redirects['motivo']
		);

		F3Base_Imp_Relatorio::avaliar(
			$conferiu,
			'wordpress.permalinks',
			sprintf(
				/* translators: 1: mensagem da decisão, 2: valor relido. */
				__( '%1$s A leitura de volta de permalink_structure trouxe %2$s.', 'f3base' ),
				$mensagem,
				'' !== $relido ? $relido : __( 'vazio', 'f3base' )
			),
			sprintf(
				/* translators: 1: mensagem da decisão, 2: valor relido, 3: estrutura desejada. */
				__( '%1$s A leitura de volta de permalink_structure trouxe %2$s, e não %3$s: a escrita não pegou, e a estrutura servida não é a declarada.', 'f3base' ),
				$mensagem,
				'' !== $relido ? $relido : __( 'vazio', 'f3base' ),
				$desejado
			),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		return array(
			'estado' => $conferiu ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::FALHA,
			'resumo' => sprintf(
				/* translators: 1: decisão declarada, 2: estrutura desejada, 3: URLs antigas nomeadas. */
				__( 'permalinks: decisão "%1$s" aplicada para %2$s, e estas URLs antigas passam a responder por redirecionamento declarado: %3$s.', 'f3base' ),
				$decisao,
				$desejado,
				$redirects['nomeados']
			),
		);
	}

	/**
	 * A REGRA da decisão de permalinks, pura: mede-se fora, decide-se aqui.
	 *
	 * Separada do lado que escreve porque é ela que tem piso dos dois lados na
	 * sonda funcional — cada ramo com o mutante dele. O lado impuro (banco,
	 * `flush_rewrite_rules()`, journal) fica em
	 * `aplicar_decisao_de_permalinks()`.
	 *
	 * `cobertura` sai daqui junto com a ação, e não é o mesmo que aplicar: o
	 * ramo `aplicar-e-cobrir` aplica E grava o 301 do caminho antigo de todo
	 * publicado que muda de endereço, gerenciado ou não; os outros dois ramos
	 * que aplicam cobrem só o que o pacote gerencia. Quem escreve lê esta chave
	 * em vez de reconhecer a decisão de novo — a mesma decisão reconhecida em
	 * dois lugares é o terreno em que os dois lados divergem.
	 *
	 * @param string $decisao   Ação aplicada; hoje sempre `aplicar-e-cobrir`.
	 * @param string $observado Estrutura observada na instalação.
	 * @param string $desejado  Estrutura declarada pelo pacote.
	 * @param array{em_risco:array<int,array{id:int,tipo:string,slug:string,caminho:string}>,sem_caminho:array<int,array{id:int,tipo:string,slug:string,caminho:string}>} $medicao Medição das URLs de terceiro.
	 * @return array{acao:string,estado:string,motivo:string,resumo:string,cobertura:bool}
	 */
	public static function decisao_de_permalinks( string $decisao, string $observado, string $desejado, array $medicao ): array {
		$em_risco          = (array) ( $medicao['em_risco'] ?? array() );
		$observado_legivel = '' !== $observado ? $observado : __( 'vazia (permalinks simples, endereço por ?p=)', 'f3base' );
		$risco             = self::frase_do_risco( $medicao );

		if ( $observado === $desejado ) {
			return array(
				'acao'      => self::ACAO_PERMALINK_NADA,
				'estado'    => F3Base_Imp_Relatorio::OK,
				'cobertura' => false,
				'motivo'    => sprintf(
					/* translators: %s: estrutura declarada. */
					__( 'a estrutura observada JÁ É a declarada (%s): nada a gravar, nenhuma URL publicada muda e nenhum redirecionamento é necessário. Gravar o que já está gravado seria mutação sem diferença, e é por isso que este ramo não escreve.', 'f3base' ),
					$desejado
				),
				'resumo'    => sprintf(
					/* translators: %s: estrutura declarada. */
					__( 'permalinks já em %s, sem gravação.', 'f3base' ),
					$desejado
				),
			);
		}

		/*
		 * UMA DECISÃO SÓ: aplicar a estrutura declarada e COBRIR com 301 o
		 * caminho antigo de todo publicado que muda de endereço.
		 *
		 * O enum de quatro valores existia para deixar o operador recusar a
		 * troca. Recusar deixava o site com a estrutura de permalinks que
		 * ninguém escolheu — que é dano maior do que a reserva evitava — e o
		 * par de redirecionamento é ADITIVO: não altera objeto nenhum, não
		 * apaga nada e some quando a option some. Não há caso em que recusar
		 * seja o certo, e a decisão que só pode ter uma resposta não é decisão.
		 */
		return array(
			'acao'      => self::ACAO_PERMALINK_APLICAR,
			'estado'    => F3Base_Imp_Relatorio::OK,
			'cobertura' => true,
			'motivo'    => sprintf(
				/* translators: 1: estrutura observada, 2: estrutura declarada, 3: frase do risco medido, 4: frase da cobertura. */
				__( 'Endereços das páginas: de %1$s para %2$s, com redirecionamento do endereço antigo. %3$s %4$s', 'f3base' ),
				$observado_legivel,
				$desejado,
				$risco,
				self::frase_da_cobertura( $medicao )
			),
			'resumo'    => __( 'endereços aplicados, com redirecionamento do antigo', 'f3base' ),
		);
	}

	/**
	 * A frase da COBERTURA medida: o que o 301 vai alcançar, NOMEADO.
	 *
	 * Contagem responde "quantas?" e a pergunta do operador é "quais?" — as
	 * URLs cobertas saem nomeadas, uma a uma, e a lista vazia sai dita em vez de
	 * sumir. Note o que NÃO entra: o publicado não gerenciado SEM URL de
	 * caminho (endereço por `?p=N`) não muda de endereço e por isso não pode
	 * ganhar par nenhum — redirecionar um endereço para ele mesmo é laço, e é a
	 * mesma regra que `pares_de_redirect()` aplica depois sobre o caminho
	 * recalculado.
	 *
	 * @param array{em_risco?:array<int,array{id:int,tipo:string,slug:string,caminho:string}>,sem_caminho?:array<int,array{id:int,tipo:string,slug:string,caminho:string}>} $medicao Medição das URLs de terceiro.
	 * @return string
	 */
	private static function frase_da_cobertura( array $medicao ): string {
		$em_risco    = (array) ( $medicao['em_risco'] ?? array() );
		$sem_caminho = (array) ( $medicao['sem_caminho'] ?? array() );

		if ( array() === $em_risco ) {
			return array() === $sem_caminho
				? __( 'Cobertura: nenhum publicado não gerenciado tem URL de caminho a cobrir, e o 301 alcança apenas o conteúdo gerenciado que mudar de endereço.', 'f3base' )
				: sprintf(
					/* translators: %s: objetos nomeados. */
					__( 'Cobertura: nenhum publicado não gerenciado tem URL de caminho a cobrir — %s tem endereço de query (?p=N), que continua resolvendo depois da troca e não pode ganhar par, porque redirecionar um endereço para ele mesmo é laço.', 'f3base' ),
					self::nomear_publicados( $sem_caminho )
				);
		}

		return sprintf(
			/* translators: 1: objetos cobertos, nomeados; 2: complemento sobre os que não têm caminho. */
			__( 'Cobertura: o caminho publicado de %1$s passa a responder 301 para o endereço novo, pelo par gravado em f3base_redirects com origem própria.%2$s', 'f3base' ),
			self::nomear_publicados( $em_risco ),
			array() === $sem_caminho
				? ''
				: ' ' . sprintf(
					/* translators: %s: objetos nomeados. */
					__( 'Fora da cobertura, por medição e não por omissão: %s tem endereço de query (?p=N), não muda de caminho e por isso não ganha par.', 'f3base' ),
					self::nomear_publicados( $sem_caminho )
				)
		);
	}

	/**
	 * A frase do risco MEDIDO — e a lista vazia tem DUAS causas, não uma.
	 *
	 * Nenhum ramo fica em silêncio: "não há URL de terceiro em risco" é
	 * resultado de medição tanto quanto a lista de objetos, e é essa frase que
	 * sustenta o ramo que aplica. Mas a lista vazia significa duas coisas
	 * diferentes, e dizer só a primeira seria afirmar o que não se mediu:
	 *
	 * - **Nada não gerenciado publicado.** Aí sim "todo publicado é gerenciado
	 *   por este pacote" é afirmação medida.
	 * - **Não gerenciado publicado, porém sem URL de caminho.** Com permalinks
	 *   simples o endereço publicado é `?p=N`, uma URL de QUERY que continua
	 *   resolvendo depois da troca. Não há caminho a quebrar — e é isso que
	 *   torna seguro aplicar na instalação recém-criada, que é justamente o
	 *   caso em que este pacote entra. Os objetos são nomeados assim mesmo.
	 *
	 * @param array{em_risco?:array<int,array{id:int,tipo:string,slug:string,caminho:string}>,sem_caminho?:array<int,array{id:int,tipo:string,slug:string,caminho:string}>} $medicao Medição das URLs de terceiro.
	 * @return string
	 */
	private static function frase_do_risco( array $medicao ): string {
		$em_risco    = (array) ( $medicao['em_risco'] ?? array() );
		$sem_caminho = (array) ( $medicao['sem_caminho'] ?? array() );

		if ( array() !== $em_risco ) {
			$frase = sprintf(
				/* translators: 1: quantidade, 2: objetos nomeados. */
				__( 'Medição: %1$d conteúdo(s) PUBLICADO(S) e NÃO gerenciado(s) por este pacote tem URL de caminho em risco — %2$s.', 'f3base' ),
				count( $em_risco ),
				self::nomear_publicados( $em_risco )
			);

			/*
			 * O que foi medido e NÃO corre risco também sai nomeado: um objeto
			 * que some da mensagem some do relatório, e o operador que decide
			 * entre as três decisões precisa da medição inteira, não do
			 * recorte que sustenta o veredito.
			 */
			if ( array() !== $sem_caminho ) {
				$frase .= ' ' . sprintf(
					/* translators: 1: quantidade, 2: objetos nomeados. */
					__( 'Outro(s) %1$d publicado(s) não gerenciado(s) NÃO têm URL de caminho e a troca não os quebra — %2$s.', 'f3base' ),
					count( $sem_caminho ),
					self::nomear_publicados( $sem_caminho )
				);
			}

			return $frase;
		}

		if ( array() !== $sem_caminho ) {
			return sprintf(
				/* translators: 1: quantidade, 2: objetos nomeados. */
				__( 'Medição: existe(m) %1$d conteúdo(s) publicado(s) e NÃO gerenciado(s) por este pacote — %2$s —, e NENHUM deles tem URL de caminho: com a estrutura observada o endereço publicado é de query (?p=N), que continua resolvendo depois da troca. Nenhuma URL de terceiro está em risco.', 'f3base' ),
				count( $sem_caminho ),
				self::nomear_publicados( $sem_caminho )
			);
		}

		return __( 'Medição: TODO conteúdo publicado tem a meta de gestão deste pacote (a mesma medição de conteudo.nao_gerenciado_publicado), então nenhuma URL de terceiro está em risco.', 'f3base' );
	}

	/**
	 * Nomeia objetos medidos: id, tipo, slug e o caminho publicado.
	 *
	 * @param array<int,array{id:int,tipo:string,slug:string,caminho:string}> $itens Objetos medidos.
	 * @return string
	 */
	private static function nomear_publicados( array $itens ): string {
		$nomes = array();

		foreach ( $itens as $item ) {
			$nomes[] = sprintf(
				/* translators: 1: ID, 2: post_type, 3: slug, 4: caminho publicado. */
				__( '#%1$d %2$s (slug %3$s) publicado em %4$s', 'f3base' ),
				(int) $item['id'],
				(string) $item['tipo'],
				(string) $item['slug'],
				'' !== (string) $item['caminho'] ? (string) $item['caminho'] : '?p=' . (int) $item['id']
			);
		}

		return implode( '; ', $nomes );
	}

	/**
	 * Mede as URLs de TERCEIRO: quais quebrariam com a troca e quais não.
	 *
	 * O censo é o de `F3Base_Imp_Conteudo`, o mesmo de
	 * `conteudo.nao_gerenciado_publicado` — duas varreduras com o mesmo
	 * propósito é o terreno em que os dois vereditos divergem sobre o mesmo
	 * banco. Aqui entra uma separação a mais, e ela é medição, não
	 * conveniência: com permalinks simples o endereço publicado é `?p=N`, uma
	 * URL de QUERY que continua resolvendo depois da troca. Sem caminho, não há
	 * caminho a quebrar — e o objeto sai da lista de risco SEM sair do
	 * relatório: as duas listas voltam, e a mensagem nomeia as duas.
	 *
	 * @return array{em_risco:array<int,array{id:int,tipo:string,slug:string,caminho:string}>,sem_caminho:array<int,array{id:int,tipo:string,slug:string,caminho:string}>}
	 */
	private static function medir_urls_de_terceiro(): array {
		$nao_gerenciados = F3Base_Imp_Conteudo::censo_de_publicados()['nao_gerenciados'];
		$caminhos        = array();

		foreach ( $nao_gerenciados as $item ) {
			$caminhos[ (int) $item['id'] ] = (string) wp_parse_url( (string) get_permalink( (int) $item['id'] ), PHP_URL_PATH );
		}

		return self::classificar_urls_de_terceiro( $nao_gerenciados, $caminhos );
	}

	/**
	 * A CLASSIFICAÇÃO das URLs de terceiro, pura: em risco ou sem caminho.
	 *
	 * Separada da leitura do banco porque é aqui que um objeto pode sumir em
	 * silêncio — cair de uma lista sem entrar na outra —, e sumir em silêncio é
	 * exatamente o que a mensagem de risco não pode fazer. NENHUM publicado não
	 * gerenciado sai da classificação: ou está em risco, ou está sem caminho a
	 * quebrar, e nos dois casos ele é nomeado.
	 *
	 * @param array<int,array{id:int,tipo:string,slug:string,titulo:string}> $nao_gerenciados Censo dos publicados não gerenciados.
	 * @param array<int,string>                                             $caminhos        ID => caminho publicado agora.
	 * @return array{em_risco:array<int,array{id:int,tipo:string,slug:string,caminho:string}>,sem_caminho:array<int,array{id:int,tipo:string,slug:string,caminho:string}>}
	 */
	public static function classificar_urls_de_terceiro( array $nao_gerenciados, array $caminhos ): array {
		$em_risco    = array();
		$sem_caminho = array();

		foreach ( $nao_gerenciados as $item ) {
			$caminho = (string) ( $caminhos[ (int) $item['id'] ] ?? '' );
			$medido  = array(
				'id'      => (int) $item['id'],
				'tipo'    => (string) $item['tipo'],
				'slug'    => (string) $item['slug'],
				'caminho' => $caminho,
			);

			if ( '' === $caminho || '/' === $caminho ) {
				$sem_caminho[] = $medido;
				continue;
			}

			$em_risco[] = $medido;
		}

		return array(
			'em_risco'    => $em_risco,
			'sem_caminho' => $sem_caminho,
		);
	}

	/**
	 * Caminhos publicados dos objetos gerenciados, ANTES de mexer na estrutura.
	 *
	 * Medido antes da troca de propósito: depois dela `get_permalink()` já
	 * devolve o endereço novo, e o antigo — o que continua circulando — deixa de
	 * existir para quem quisesse redirecioná-lo.
	 *
	 * @return array<string,string> Caminho antigo => referência lógica.
	 */
	private static function urls_dos_gerenciados(): array {
		$antigas = array();

		foreach ( array( 'paginas' => 'page', 'posts' => 'post' ) as $lista => $tipo ) {
			foreach ( F3Base_Imp_Plugins::entradas_declaradas( $lista ) as $indice => $entrada ) {
				unset( $entrada );

				$ref = 'paginas' === $lista
					? (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' )
					: (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.slug', '' );

				$id = F3Base_Imp_Conteudo::localizar_gerenciado( $tipo, $ref );

				if ( $id <= 0 ) {
					continue;
				}

				$url     = (string) get_permalink( $id );
				$caminho = (string) wp_parse_url( $url, PHP_URL_PATH );

				if ( '' !== $caminho && '/' !== $caminho ) {
					$antigas[ $caminho ] = $ref;
				}
			}
		}

		return $antigas;
	}

	/**
	 * A REGRA dos pares de redirect, pura: caminho antigo → caminho novo.
	 *
	 * Separada do lado que escreve pelo mesmo motivo da decisão: é aqui que
	 * mora a única regra que pode errar em silêncio, e ela tem piso na sonda
	 * funcional. Duas coisas são descartadas, e as duas por medição:
	 *
	 * - **Caminho que não mudou.** Redirecionar um endereço para ele mesmo é
	 *   laço, e o módulo do site-core casa o par ANTES do 404 — um par idêntico
	 *   redirecionaria a página viva para si própria, em loop.
	 * - **Referência sem endereço novo.** Objeto que a execução não conseguiu
	 *   localizar não tem para onde apontar, e inventar destino é pior que não
	 *   redirecionar.
	 *
	 * @param array<string,string> $antigas Caminho antigo => referência lógica.
	 * @param array<string,string> $agora   Referência lógica => caminho novo.
	 * @return array<int,array{de:string,para:string,status:int}>
	 */
	public static function pares_de_redirect( array $antigas, array $agora ): array {
		$pares = array();

		foreach ( $antigas as $caminho => $ref ) {
			$novo = (string) ( $agora[ $ref ] ?? '' );

			if ( '' === $novo || $novo === $caminho ) {
				continue;
			}

			$pares[] = array(
				'de'     => (string) $caminho,
				'para'   => $novo,
				'status' => 301,
			);
		}

		return $pares;
	}

	/**
	 * Registra, em `f3base_redirects`, o par caminho-antigo → caminho-novo.
	 *
	 * A option é a mesma que o módulo de redirects do site-core já lê, e o
	 * mecanismo é NOMEADO na mensagem porque é ele que faz o endereço antigo
	 * continuar respondendo: o par declarado é casado em `template_redirect`
	 * com prioridade 1, ANTES do 404, e sai 301 para o endereço novo. O outro
	 * mecanismo do mesmo módulo — `_f3base_old_slug`, que trata `pagename` e
	 * `name` — é o de mudança de SLUG, e não cobre troca de ESTRUTURA: o
	 * caminho velho `/blog/x/` não é slug nenhum.
	 *
	 * Pares cujo caminho não mudou são descartados: redirecionar de um endereço
	 * para ele mesmo é laço.
	 *
	 * O CONJUNTO que chega aqui depende da decisão declarada, e não desta
	 * função: sob `aplicar-e-cobrir` ele traz também os publicados que este
	 * pacote não gerencia, chaveados pelo ID. A função não distingue os dois —
	 * um par de redirect é aditivo em qualquer caso, e a decisão de cobrir ou
	 * não já foi tomada e registrada por quem sabe medir.
	 *
	 * O DEFEITO MEDIDO NO BANCO DEPOIS DA 1.0.11, e a razão de esta função ter
	 * deixado de montar o valor da option: ela gravava `array_merge( $atuais,
	 * $novos )` e o log dizia, com razão, "2 URL(s) antiga(s) respondendo por
	 * redirecionamento declarado"; mais adiante, a etapa `site_core.options`
	 * gravava a MESMA option a partir de `redirects: []` do arquivo de
	 * configuração e apagava os dois pares. As duas gravações leram de volta e
	 * conferiram — as duas mensagens eram verdadeiras no instante em que foram
	 * escritas —, e o artefato final (`a:0:{}`) contradizia a primeira: as URLs
	 * antigas respondiam 404, não 301. Duas fontes para o mesmo fato.
	 *
	 * Agora esta função REGISTRA o que computou e grava a UNIÃO DECLARADA, que
	 * é a mesma que a etapa de options do site-core grava. Nenhum lado apaga o
	 * outro, e o detector `estatica.option_fonte_unica` impede que um segundo
	 * ponto do código volte a produzir o valor desejado por fora.
	 *
	 * @param array<string,string> $antigas Caminho antigo => referência lógica.
	 * @return array{motivo:string,nomeados:string}
	 */
	private static function gravar_redirects_de_permalink( array $antigas ): array {
		$agora = array();

		foreach ( $antigas as $ref ) {
			$agora[ $ref ] = self::caminho_atual_da_referencia( (string) $ref );
		}

		$novos = self::pares_de_redirect( $antigas, $agora );

		self::registrar_redirects_computados( $novos, 'wordpress.permalinks' );

		$resultado = F3Base_Imp_Gravador::gravar( 'f3base_redirects', self::valor_desejado_de_redirects(), array( 'autoload' => true ) );
		$nomeados  = implode( ', ', array_map( static fn( array $r ): string => $r['de'] . ' → ' . $r['para'], $novos ) );

		if ( array() === $novos ) {
			return array(
				'nomeados' => __( 'nenhuma, porque nenhum caminho publicado mudou', 'f3base' ),
				'motivo'   => sprintf(
					/* translators: 1: caminhos medidos antes da troca, nomeados; 2: motivo do gravador. */
					__( 'Nenhum dos caminhos publicados medidos antes da troca (%1$s) mudou de endereço: nenhum redirecionamento foi computado nesta etapa, e redirecionar um endereço para ele mesmo seria laço. A option foi gravada com a UNIÃO DECLARADA assim mesmo, que é o que preserva os pares declarados na configuração e os computados por execuções anteriores. %2$s', 'f3base' ),
					array() === $antigas ? __( 'nenhum', 'f3base' ) : implode( ', ', array_keys( $antigas ) ),
					$resultado['motivo']
				),
			);
		}

		return array(
			'nomeados' => $nomeados,
			'motivo'   => sprintf(
				/* translators: 1: pares computados, nomeados um a um; 2: motivo do gravador. */
				__( 'Estas URLs publicadas mudaram de endereço e o endereço ANTIGO de cada uma passa a responder pelo mecanismo de redirect DECLARADO do site-core — o par gravado em f3base_redirects é casado em template_redirect com prioridade 1, antes do 404, e sai 301 para o novo: %1$s. Cada par sai NOMEADO em vez de contado, porque a pergunta do operador é qual URL passou a responder, não quantas. O valor gravado é a UNIÃO DECLARADA (pares da configuração + computados desta execução + computados preservados), e não só estes pares: gravar só estes foi o que permitiu, na 1.0.11, que a etapa seguinte os apagasse. %2$s', 'f3base' ),
				$nomeados,
				$resultado['motivo']
			),
		);
	}

	/**
	 * Caminho publicado AGORA de uma referência lógica, nas duas formas dela.
	 *
	 * A referência de conteúdo gerenciado é a `ref` declarada, e ela é resolvida
	 * pela localização por meta de gestão — nunca por slug, que é a mesma regra
	 * que governa a adoção de objeto. A referência de conteúdo que este pacote
	 * NÃO gerencia é o ID prefixado: ele não tem `ref` para resolver, e o ID é a
	 * única identidade que o objeto tem no banco.
	 *
	 * Devolve vazio quando não há endereço novo, e é `pares_de_redirect()` que
	 * descarta o par: inventar destino é pior do que não redirecionar.
	 *
	 * @param string $ref Referência lógica.
	 * @return string Caminho publicado agora, ou vazio.
	 */
	private static function caminho_atual_da_referencia( string $ref ): string {
		if ( str_starts_with( $ref, self::REF_POR_ID ) ) {
			$id = (int) substr( $ref, strlen( self::REF_POR_ID ) );

			return $id > 0 ? (string) wp_parse_url( (string) get_permalink( $id ), PHP_URL_PATH ) : '';
		}

		$id = F3Base_Imp_Conteudo::localizar_gerenciado( 'page', $ref );
		$id = $id > 0 ? $id : F3Base_Imp_Conteudo::localizar_gerenciado( 'post', $ref );

		return $id > 0 ? (string) wp_parse_url( (string) get_permalink( $id ), PHP_URL_PATH ) : '';
	}

	/**
	 * Registra pares computados por uma ETAPA desta execução.
	 *
	 * Acumulador de fonte, não de valor: quem grava continua sendo o gravador
	 * único, e o valor desejado continua saindo de um lugar só —
	 * `valor_desejado_de_redirects()`.
	 *
	 * @param array<int,array{de:string,para:string,status:int}> $pares Pares computados.
	 * @param string                                             $etapa Etapa que os computou, para o carimbo de origem.
	 * @return void
	 */
	public static function registrar_redirects_computados( array $pares, string $etapa ): void {
		foreach ( $pares as $par ) {
			$de = isset( $par['de'] ) ? (string) $par['de'] : '';

			if ( '' === $de ) {
				continue;
			}

			self::$redirects_computados[ $de ] = array(
				'de'     => $de,
				'para'   => isset( $par['para'] ) ? (string) $par['para'] : '',
				'status' => isset( $par['status'] ) ? (int) $par['status'] : 301,
				'origem' => self::REDIRECT_COMPUTADO . ':' . $etapa,
			);
		}
	}

	/**
	 * Pares computados por etapas DESTA execução.
	 *
	 * @return array<int,array{de:string,para:string,status:int,origem:string}>
	 */
	public static function redirects_computados(): array {
		return array_values( self::$redirects_computados );
	}

	/**
	 * Esquece os pares computados desta execução.
	 *
	 * Existe para o exercício da regra fora de uma execução real: sem isto, dois
	 * casos seguidos na mesma sonda mediriam o acúmulo do caso anterior.
	 *
	 * @return void
	 */
	public static function esquecer_redirects_computados(): void {
		self::$redirects_computados = array();
	}

	/**
	 * Redirects DECLARADOS no arquivo de configuração, normalizados.
	 *
	 * Uma das fontes de `f3base_redirects` — nunca a option inteira.
	 *
	 * @return array<int,array{de:string,para:string,status:int,origem:string}>
	 */
	private static function redirects_declarados(): array {
		$saida = array();

		foreach ( F3Base_Imp_Config::lista( 'redirects' ) as $indice => $entrada ) {
			unset( $entrada );

			$de   = (string) F3Base_Imp_Config::obter( 'redirects.' . $indice . '.de', '' );
			$para = (string) F3Base_Imp_Config::obter( 'redirects.' . $indice . '.para', '' );

			if ( '' === $de || '' === $para ) {
				continue;
			}

			$saida[] = array(
				'de'     => $de,
				'para'   => $para,
				'status' => (int) F3Base_Imp_Config::obter( 'redirects.' . $indice . '.status', 301 ),
				'origem' => self::REDIRECT_DECLARADO,
			);
		}

		return $saida;
	}

	/**
	 * A UNIÃO DECLARADA de `f3base_redirects`. FUNÇÃO PURA.
	 *
	 * Três fontes e uma ORDEM declarada, unidas por chave de origem (`de`):
	 *
	 * 1. **Declarados** — `redirects` no arquivo de configuração. Rederivados a
	 *    cada execução: tirar da configuração tira da option.
	 * 2. **Computados nesta execução** — o que as etapas mediram agora.
	 * 3. **Preservados** — o que já estava gravado e NÃO tem origem
	 *    `declarado`: pares computados por execuções anteriores (a URL antiga
	 *    que eles redirecionam continua circulando) e pares sem carimbo, que
	 *    este pacote não escreveu e não vai apagar em silêncio.
	 *
	 * Nenhum lado apaga o outro. O par computado AGORA vence o preservado com a
	 * mesma origem porque é a mesma medição, refeita — não é colisão. Colisão
	 * de origem entre um par DECLARADO e um COMPUTADO é outra coisa: são duas
	 * afirmações diferentes sobre o mesmo endereço, e isso é FALHA nomeando as
	 * duas, nunca sobrescrita silenciosa. O declarado prevalece no valor
	 * gravado — a configuração é a afirmação explícita do operador — e a
	 * colisão sai nomeada com os dois destinos, para que ele decida.
	 *
	 * 4. **REMOVIDOS**, desde a 1.1.0, e esta quarta parcela é uma SUBTRAÇÃO. A
	 *    base da option guarda o que este pacote aplicou por último; par que
	 *    estava lá e NÃO está no observado foi apagado por quem opera o site, e
	 *    não volta — nem pela configuração, nem por uma etapa que o recompute.
	 *    A lista de removidos é durável: ela viaja na base, e é ela que impede a
	 *    execução seguinte de ressuscitar o par depois que ele sumiu do
	 *    observado. Par que o agente REFIZER volta a existir e sai da lista, e é
	 *    por isso que a marca não é permanente: presença no observado vence a
	 *    memória da remoção.
	 *
	 * @param array<int,array<string,mixed>>                                  $declarados Pares da configuração.
	 * @param array<int,array<string,mixed>>                                  $computados Pares computados nesta execução.
	 * @param array<int,array<string,mixed>>                                  $gravados   Pares já gravados na option.
	 * @param array{pares:array<int,array<string,mixed>>,removidos:array<int,string>} $base       Base da option: o valor aplicado por último e os removidos já registrados.
	 * @return array{pares:array<int,array{de:string,para:string,status:int,origem:string}>,colisoes:array<int,array{de:string,declarado:string,computado:string}>,contagem:array<string,int>,removidos:array<int,array{de:string,para:string,status:int,origem:string}>,removidos_de:array<int,string>}
	 */
	public static function uniao_de_redirects( array $declarados, array $computados, array $gravados, array $base ): array {
		$normalizar = static function ( $par, string $origem_padrao ): array {
			$par = is_array( $par ) ? $par : array();
			$de  = isset( $par['de'] ) ? (string) $par['de'] : '';

			return array(
				'de'     => $de,
				'para'   => isset( $par['para'] ) ? (string) $par['para'] : '',
				'status' => isset( $par['status'] ) ? (int) $par['status'] : 301,
				'origem' => isset( $par['origem'] ) && '' !== (string) $par['origem'] ? (string) $par['origem'] : $origem_padrao,
			);
		};

		$pares    = array();
		$colisoes = array();
		$contagem = array(
			self::REDIRECT_DECLARADO    => 0,
			self::REDIRECT_COMPUTADO    => 0,
			self::REDIRECT_PREEXISTENTE => 0,
			self::REDIRECT_REMOVIDO     => 0,
		);

		/*
		 * OS REMOVIDOS SÃO CALCULADOS ANTES DE TUDO, porque eles decidem o que
		 * as três fontes seguintes podem acrescentar. Duas origens para a mesma
		 * conclusão: o par que a base registrou como aplicado e sumiu do
		 * observado (removido AGORA), e o par que uma execução anterior já
		 * registrou como removido (removido ANTES). PRESENÇA NO OBSERVADO VENCE
		 * AS DUAS: refazer o par é o caminho de volta, e ele não precisa de
		 * release nem de edição de arquivo.
		 */
		$observados = array();

		foreach ( $gravados as $bruto ) {
			$par = $normalizar( $bruto, self::REDIRECT_PREEXISTENTE );

			if ( '' !== $par['de'] && '' !== $par['para'] ) {
				$observados[ $par['de'] ] = true;
			}
		}

		$removidos = array();

		foreach ( (array) ( $base['pares'] ?? array() ) as $bruto ) {
			$par = $normalizar( $bruto, self::REDIRECT_REMOVIDO );

			if ( '' === $par['de'] || isset( $observados[ $par['de'] ] ) ) {
				continue;
			}

			$par['origem']          = self::REDIRECT_REMOVIDO;
			$removidos[ $par['de'] ] = $par;
		}

		foreach ( (array) ( $base['removidos'] ?? array() ) as $de ) {
			$de = (string) $de;

			if ( '' === $de || isset( $observados[ $de ] ) || isset( $removidos[ $de ] ) ) {
				continue;
			}

			$removidos[ $de ] = array(
				'de'     => $de,
				'para'   => '',
				'status' => 301,
				'origem' => self::REDIRECT_REMOVIDO,
			);
		}

		$contagem[ self::REDIRECT_REMOVIDO ] = count( $removidos );

		foreach ( $declarados as $bruto ) {
			$par = $normalizar( $bruto, self::REDIRECT_DECLARADO );

			if ( '' === $par['de'] || '' === $par['para'] || isset( $removidos[ $par['de'] ] ) ) {
				continue;
			}

			$par['origem']       = self::REDIRECT_DECLARADO;
			$pares[ $par['de'] ] = $par;

			$contagem[ self::REDIRECT_DECLARADO ]++;
		}

		foreach ( $computados as $bruto ) {
			$par = $normalizar( $bruto, self::REDIRECT_COMPUTADO );

			if ( '' === $par['de'] || '' === $par['para'] || isset( $removidos[ $par['de'] ] ) ) {
				continue;
			}

			if ( isset( $pares[ $par['de'] ] ) && self::REDIRECT_DECLARADO === $pares[ $par['de'] ]['origem'] ) {
				$colisoes[] = array(
					'de'        => $par['de'],
					'declarado' => $pares[ $par['de'] ]['para'],
					'computado' => $par['para'],
				);
				continue;
			}

			$pares[ $par['de'] ] = $par;
			$contagem[ self::REDIRECT_COMPUTADO ]++;
		}

		foreach ( $gravados as $bruto ) {
			$par = $normalizar( $bruto, self::REDIRECT_PREEXISTENTE );

			if ( '' === $par['de'] || '' === $par['para'] ) {
				continue;
			}

			/*
			 * Par gravado com origem `declarado` NÃO é preservado: a fonte dele
			 * é o arquivo de configuração, e o laço acima já o rederivou de lá.
			 * Preservá-lo faria um par removido da configuração viver para
			 * sempre na option, que é o defeito espelhado do que esta release
			 * corrige.
			 */
			if ( self::REDIRECT_DECLARADO === $par['origem'] ) {
				continue;
			}

			if ( isset( $pares[ $par['de'] ] ) ) {
				if ( self::REDIRECT_DECLARADO === $pares[ $par['de'] ]['origem'] ) {
					$colisoes[] = array(
						'de'        => $par['de'],
						'declarado' => $pares[ $par['de'] ]['para'],
						'computado' => $par['para'],
					);
				}

				continue;
			}

			if ( ! str_starts_with( $par['origem'], self::REDIRECT_COMPUTADO ) ) {
				$par['origem'] = self::REDIRECT_PREEXISTENTE;
			}

			$pares[ $par['de'] ] = $par;
			$contagem[ self::REDIRECT_PREEXISTENTE ]++;
		}

		return array(
			'pares'        => array_values( $pares ),
			'colisoes'     => $colisoes,
			'contagem'     => $contagem,
			'removidos'    => array_values( $removidos ),
			'removidos_de' => array_keys( $removidos ),
		);
	}

	/**
	 * O valor desejado de `f3base_redirects` — PONTO ÚNICO que o produz.
	 *
	 * Toda gravação da option passa por aqui, e é isso que
	 * `estatica.option_fonte_unica` confere: enquanto houve duas funções
	 * montando o valor por caminhos diferentes, a segunda a rodar apagava o
	 * trabalho da primeira e o relatório saía com duas afirmações verdadeiras e
	 * contraditórias sobre o mesmo artefato.
	 *
	 * @return array<int,array{de:string,para:string,status:int,origem:string}>
	 */
	public static function valor_desejado_de_redirects(): array {
		return self::uniao_de_redirects_medida()['pares'];
	}

	/**
	 * A união, com as três fontes LIDAS: configuração, execução e artefato.
	 *
	 * @return array{pares:array<int,array<string,mixed>>,colisoes:array<int,array<string,string>>,contagem:array<string,int>}
	 */
	public static function uniao_de_redirects_medida(): array {
		$gravados = get_option( 'f3base_redirects', array() );
		$registro = F3Base_Imp_Conteudo::ler_base_de_option( 'f3base_redirects' );

		return self::uniao_de_redirects(
			self::redirects_declarados(),
			self::redirects_computados(),
			is_array( $gravados ) ? $gravados : array(),
			array(
				'pares'     => ( is_array( $registro ) && isset( $registro['valor'] ) && is_array( $registro['valor'] ) ) ? $registro['valor'] : array(),
				'removidos' => ( is_array( $registro ) && isset( $registro['removidos'] ) && is_array( $registro['removidos'] ) ) ? $registro['removidos'] : array(),
			)
		);
	}

	/**
	 * O texto da união, nos dois ramos. FUNÇÃO PURA.
	 *
	 * @param array{pares:array<int,array<string,mixed>>,colisoes:array<int,array<string,string>>,contagem:array<string,int>} $uniao União medida.
	 * @return array{estado:string,motivo:string}
	 */
	public static function veredito_da_uniao_de_redirects( array $uniao ): array {
		$contagem = (array) ( $uniao['contagem'] ?? array() );
		$colisoes = (array) ( $uniao['colisoes'] ?? array() );

		$removidos = (array) ( $uniao['removidos'] ?? array() );

		/*
		 * OS REMOVIDOS SAEM NOMEADOS, um a um, e nunca contados. O par que não
		 * voltou é a única parcela desta união que o leitor não consegue
		 * deduzir olhando a option: ele não está lá, e é justamente essa
		 * ausência que precisa ter autor declarado. Contar "1 removido" diria
		 * que houve subtração sem dizer de quê.
		 */
		$nota_removidos = array() === $removidos
			? __( ' Nenhum par removido por quem opera o site: a base da option e o valor observado declaram os mesmos endereços de origem.', 'f3base' )
			: sprintf(
				/* translators: 1: quantidade de pares removidos, 2: os endereços de origem, nomeados. */
				__( ' %1$d par(es) NÃO voltaram porque estavam na base desta option e não estão mais no valor observado — foram apagados por quem opera o site, e a união não os recria nem pela configuração nem por etapa que os recompute: %2$s. Refazer o par pelo canal o traz de volta na execução seguinte, e a marca de removido cai sozinha.', 'f3base' ),
				count( $removidos ),
				implode(
					', ',
					array_map(
						static fn( array $par ): string => (string) ( $par['de'] ?? '' ),
						$removidos
					)
				)
			);

		$resumo = sprintf(
			/* translators: 1: declarados, 2: computados, 3: preservados, 4: total, 5: nota sobre os removidos. */
			__( 'fonte COMPOSTA e ordem declarada: %1$d par(es) declarado(s) na configuração + %2$d computado(s) por etapas desta execução + %3$d preservado(s) do que já estava gravado = %4$d par(es) unidos por chave de origem.%5$s', 'f3base' ),
			(int) ( $contagem[ self::REDIRECT_DECLARADO ] ?? 0 ),
			(int) ( $contagem[ self::REDIRECT_COMPUTADO ] ?? 0 ),
			(int) ( $contagem[ self::REDIRECT_PREEXISTENTE ] ?? 0 ),
			count( (array) ( $uniao['pares'] ?? array() ) ),
			$nota_removidos
		);

		if ( array() === $colisoes ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::OK,
				'motivo' => sprintf(
					/* translators: %s: resumo da união. */
					__( 'f3base_redirects tem %s Nenhuma colisão de origem: nenhum lado apagou o outro, e o valor gravado é o mesmo em toda etapa que toca a option.', 'f3base' ),
					$resumo
				),
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::FALHA,
			'motivo' => sprintf(
				/* translators: 1: quantidade de colisões, 2: colisões nomeadas, 3: resumo da união. */
				__( 'COLISÃO DE ORIGEM em f3base_redirects: %1$d endereço(s) de origem têm um par DECLARADO na configuração e um par COMPUTADO por esta execução apontando para destinos diferentes — %2$s. Nenhuma sobrescrita silenciosa: o par declarado prevaleceu no valor gravado, e a divergência sai nomeada para que o operador decida qual das duas afirmações vale. %3$s', 'f3base' ),
				count( $colisoes ),
				implode(
					'; ',
					array_map(
						static fn( array $c ): string => sprintf(
							/* translators: 1: origem, 2: destino declarado, 3: destino computado. */
							__( '%1$s → declarado %2$s, computado %3$s', 'f3base' ),
							(string) ( $c['de'] ?? '' ),
							(string) ( $c['declarado'] ?? '' ),
							(string) ( $c['computado'] ?? '' )
						),
						$colisoes
					)
				),
				$resumo
			),
		);
	}

	/**
	 * Indexação: `blog_public`, com o ÔNUS INVERTIDO.
	 *
	 * Até a 1.0.11 esta unidade gravava `blog_public = 1` só quando TRÊS
	 * condições fechavam — `ambiente.tipo = producao`, HTTPS e o host dentro de
	 * uma lista declarada de domínios — e o template nascia com `tipo = local` e
	 * a lista vazia. O padrão, portanto, era NÃO INDEXAR, e era preciso
	 * configurar três coisas para obter o resultado normal de um site.
	 *
	 * A decisão do dono inverteu isso: o implantador existe para entregar um
	 * site pronto para produção e para ser indexado, e o padrão precisa JÁ SER
	 * esse resultado. Quem não quiser, muda a chave à mão.
	 *
	 * Então o site NASCE INDEXÁVEL e a unidade só segura a indexação quando
	 * MEDE um motivo. As guardas que sobraram são as que não podem dar falso
	 * positivo num site real. A lista de domínios saiu do gate na 1.0.12 e SAIU
	 * DO PACOTE na 1.0.19: preenchê-la só comprava um WARN quando o host
	 * divergia, e o preço era mais uma decisão pedida ao operador.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_indexacao(): array {
		$veredito = self::indexacao_medida();
		$esperado = $veredito['valor'];

		$resultado = F3Base_Imp_Gravador::gravar( 'blog_public', $esperado );
		$conferiu  = (int) get_option( 'blog_public', 0 ) === $esperado || F3Base_Imp_Gravador::em_simulacao();

		/*
		 * TRÊS RAMOS, UMA EMISSÃO. Guarda que dispara é decisão MEDIDA e
		 * correta — WARN, nunca FALHA nem BLOCKED. O que é FALHA é a leitura de
		 * volta divergir do que se pediu: aí a escrita não pegou, e isso é
		 * defeito, não decisão.
		 */
		F3Base_Imp_Relatorio::emitir(
			$conferiu ? $veredito['estado'] : F3Base_Imp_Relatorio::FALHA,
			'wordpress.blog_public',
			$conferiu
				? sprintf(
					/* translators: 1: valor gravado, 2: motivo do veredito, 3: consequência no wp-admin. */
					__( 'blog_public = %1$d. %2$s %3$s', 'f3base' ),
					$esperado,
					$veredito['motivo'],
					$veredito['consequencia']
				)
				: sprintf(
					/* translators: 1: valor esperado, 2: valor observado, 3: motivo do veredito, 4: consequência no wp-admin. */
					__( 'blog_public deveria ser %1$d e a leitura de volta trouxe %2$d: a escrita não pegou, e isto é defeito, não decisão. %3$s %4$s', 'f3base' ),
					$esperado,
					(int) get_option( 'blog_public', 0 ),
					$veredito['motivo'],
					$veredito['consequencia']
				),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		return array(
			'estado' => F3Base_Imp_Relatorio::estado_mais_severo( $resultado['estado'], $veredito['estado'] ),
			'rotulo' => 'wordpress.indexacao',
			'motivo' => sprintf(
				/* translators: 1: motivo do veredito, 2: consequência no wp-admin, 3: mensagem do gravador. */
				__( '%1$s %2$s %3$s', 'f3base' ),
				$veredito['motivo'],
				$veredito['consequencia'],
				$resultado['motivo']
			),
		);
	}

	/**
	 * MEDE o ambiente e devolve o veredito da indexação.
	 *
	 * O lado impuro: lê a configuração, `home_url()` e
	 * `wp_get_environment_type()`. A REGRA fica em `veredito_de_indexacao()`,
	 * que é pura e por isso tem piso dos dois lados na sonda funcional.
	 *
	 * @return array<string,mixed>
	 */
	public static function indexacao_medida(): array {
		$home = (string) home_url();

		return self::veredito_de_indexacao(
			array(
				'modo'        => (string) F3Base_Imp_Projeto::obter( 'ambiente.indexar', '' ),
				'tipo'        => (string) F3Base_Imp_Config::obter( 'ambiente.tipo', 'producao' ),
				'esquema'     => (string) wp_parse_url( $home, PHP_URL_SCHEME ),
				'host'        => (string) wp_parse_url( $home, PHP_URL_HOST ),
				'ambiente_wp' => function_exists( 'wp_get_environment_type' ) ? (string) wp_get_environment_type() : '',
				'previa'      => array_map( 'strval', F3Base_Imp_Projeto::lista( 'ambiente.dominios_de_previa' ) ),
			)
		);
	}

	/**
	 * A REGRA da indexação, PURA: mede-se fora, decide-se aqui.
	 *
	 * O padrão é indexar. As três guardas de `medir` existem porque cada uma,
	 * sozinha, é impossível de disparar num site de produção legítimo:
	 *
	 * 1. `wp_get_environment_type()` em `local`, `development` ou `staging`. O
	 *    padrão do núcleo é `production`; um destes três só aparece quando
	 *    alguém — hospedagem, `wp-config.php`, variável de ambiente — DECLAROU
	 *    que aquele ambiente não é produção.
	 * 2. `home_url()` fora de HTTPS. Site indexável em HTTP puro é defeito, não
	 *    escolha.
	 * 3. `ambiente.tipo` declarado diferente de `producao`. A chave continua
	 *    respeitada quando o projeto a muda de propósito.
	 *
	 * E a quarta, que só existe quando o dono a declara: host casando com um
	 * sufixo de `ambiente.dominios_de_previa`. Ela nasce VAZIA e não pode
	 * nascer preenchida — a lista de sufixos de pré-visualização de cada
	 * hospedagem é fato do mundo, muda sem release nossa, e embutida no código
	 * seria uma guarda invisível decidindo sobre o site de alguém.
	 *
	 * @param array<string,mixed> $medido O que foi medido no ambiente.
	 * @return array{valor:int,estado:string,modo:string,guardas:array<int,array{nome:string,observado:string}>,motivo:string,consequencia:string,detalhe:string}
	 */
	public static function veredito_de_indexacao( array $medido ): array {
		$modo        = (string) ( $medido['modo'] ?? self::INDEXAR_MEDIR );
		$tipo        = (string) ( $medido['tipo'] ?? '' );
		$esquema     = strtolower( (string) ( $medido['esquema'] ?? '' ) );
		$host        = strtolower( (string) ( $medido['host'] ?? '' ) );
		$ambiente_wp = strtolower( (string) ( $medido['ambiente_wp'] ?? '' ) );
		$previa      = array_map( 'strval', (array) ( $medido['previa'] ?? array() ) );

		$modo    = in_array( $modo, array( self::INDEXAR_MEDIR, self::INDEXAR_FORCAR, self::INDEXAR_NUNCA ), true ) ? $modo : self::INDEXAR_MEDIR;
		$guardas = array();

		if ( in_array( $ambiente_wp, self::AMBIENTES_NAO_PRODUCAO, true ) ) {
			$guardas[] = array(
				'nome'      => self::GUARDA_AMBIENTE_WP,
				'observado' => $ambiente_wp,
				'porque'    => __( 'o padrão do núcleo é "production": este valor só aparece quando a hospedagem, o wp-config.php ou uma variável de ambiente declararam explicitamente que este ambiente NÃO é produção', 'f3base' ),
			);
		}

		if ( 'https' !== $esquema ) {
			$guardas[] = array(
				'nome'      => self::GUARDA_ESQUEMA,
				'observado' => '' !== $esquema ? $esquema : __( '(sem esquema)', 'f3base' ),
				'porque'    => __( 'site indexável servido em HTTP puro é defeito, não escolha: o endereço indexado é o que o buscador guarda', 'f3base' ),
			);
		}

		if ( 'producao' !== $tipo ) {
			$guardas[] = array(
				'nome'      => self::GUARDA_TIPO,
				'observado' => '' !== $tipo ? $tipo : __( '(vazio)', 'f3base' ),
				'porque'    => __( 'a chave nasce "producao" e continua respeitada quando o projeto a muda de propósito: mudá-la é dizer que este não é o site de produção', 'f3base' ),
			);
		}

		$sufixo = self::sufixo_de_previa( $host, $previa );

		if ( '' !== $sufixo ) {
			$guardas[] = array(
				'nome'      => self::GUARDA_PREVIA,
				'observado' => $host . ' casa com o sufixo declarado ' . $sufixo,
				'porque'    => __( 'endereço de pré-visualização da hospedagem deixa de existir quando o domínio real aponta para o site, e o que foi indexado por ele fica órfão', 'f3base' ),
			);
		}

		$nomeadas = array_map(
			static fn( array $g ): string => sprintf(
				/* translators: 1: nome da guarda, 2: valor observado, 3: por que a guarda existe. */
				__( '%1$s (observado: %2$s — %3$s)', 'f3base' ),
				$g['nome'],
				$g['observado'],
				$g['porque']
			),
			$guardas
		);

		$como_forcar = __( 'Para indexar assim mesmo, sem tocar em nada do ambiente: declare ambiente.indexar = "forcar" — a decisão fica registrada no relatório junto com a guarda que ela ignorou.', 'f3base' );

		if ( self::INDEXAR_NUNCA === $modo ) {
			$veredito = array(
				'valor'  => 0,
				'estado' => F3Base_Imp_Relatorio::WARN,
				'motivo' => sprintf(
					/* translators: %s: guardas ativas, ou a frase de nenhuma. */
					__( 'DECISÃO DECLARADA em ambiente.indexar = "nunca": blog_public = 0 sempre, independentemente do que foi medido. Não é defeito e não é medição — é escolha do projeto, e sai em WARN porque um site não indexável é o oposto do estado normal deste pacote e o operador precisa ver por quê. Guarda(s) que estariam ativas de qualquer modo: %s. Para voltar ao padrão, declare ambiente.indexar = "medir".', 'f3base' ),
					array() === $nomeadas ? __( 'nenhuma', 'f3base' ) : implode( '; ', $nomeadas )
				),
			);
		} elseif ( self::INDEXAR_FORCAR === $modo ) {
			$veredito = array(
				'valor'  => 1,
				'estado' => array() === $guardas ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::WARN,
				'motivo' => array() === $guardas
					? __( 'DECISÃO DECLARADA em ambiente.indexar = "forcar": blog_public = 1. A decisão foi INERTE nesta execução — nenhuma guarda estava ativa, e o padrão "medir" teria gravado o mesmo 1. Registrada assim mesmo: decisão que ignora medição precisa aparecer no relatório mesmo quando não havia o que ignorar, senão ninguém percebe que ela continua ligada.', 'f3base' )
					: sprintf(
						/* translators: %s: guardas ignoradas, nomeadas com o valor observado. */
						__( 'DECISÃO DECLARADA em ambiente.indexar = "forcar": blog_public = 1 IGNORANDO a(s) guarda(s) que estavam ativas — e é este o motivo por que a decisão existia: %s. O site fica indexável apesar da medição acima; a medição não foi suprimida, só não decidiu. Para devolver a decisão à medição, declare ambiente.indexar = "medir".', 'f3base' ),
						implode( '; ', $nomeadas )
					),
			);
		} elseif ( array() === $guardas ) {
			$veredito = array(
				'valor'  => 1,
				'estado' => F3Base_Imp_Relatorio::OK,
				'motivo' => __( 'PADRÃO: o site nasce indexável e nenhuma guarda mediu motivo para segurá-lo — blog_public = 1 sem que nada precisasse ser configurado. As guardas medidas foram: wp_get_environment_type() fora de local/development/staging, home_url() em https, ambiente.tipo = "producao" e nenhum sufixo de ambiente.dominios_de_previa casando com o host.', 'f3base' ),
			);
		} else {
			$veredito = array(
				'valor'  => 0,
				'estado' => F3Base_Imp_Relatorio::WARN,
				'motivo' => sprintf(
					/* translators: 1: quantidade de guardas, 2: guardas nomeadas com o observado, 3: como forçar. */
					__( 'blog_public = 0 por %1$d guarda(s) MEDIDA(s), e isto é decisão correta, não defeito: %2$s. O padrão continua sendo indexar — nenhuma configuração é exigida para isso —, e o que segurou aqui foi medição, não ausência de configuração. %3$s', 'f3base' ),
					count( $guardas ),
					implode( '; ', $nomeadas ),
					$como_forcar
				),
			);
		}

		return $veredito + array(
			'modo'         => $modo,
			'guardas'      => $guardas,
			'consequencia' => self::consequencia_de_indexacao( 1 === $veredito['valor'], $tipo, $host ),
			'detalhe'      => sprintf(
				/* translators: 1: modo declarado, 2: ambiente do núcleo, 3: esquema, 4: host, 5: quantidade de guardas ativas. */
				__( 'medido: ambiente.indexar = %1$s; wp_get_environment_type() = %2$s; esquema de home_url() = %3$s; host = %4$s; guardas ativas = %5$d.', 'f3base' ),
				$modo,
				'' !== $ambiente_wp ? $ambiente_wp : '—',
				'' !== $esquema ? $esquema : '—',
				'' !== $host ? $host : '—',
				count( $guardas )
			),
		);
	}

	/**
	 * O sufixo de pré-visualização que casa com o host, ou vazio. FUNÇÃO PURA.
	 *
	 * Casa o host inteiro (`exemplo.wpengine.com` contra `wpengine.com`) e o
	 * host igual ao sufixo. Aceita o sufixo declarado com `*.` ou com ponto na
	 * frente, porque é assim que essas listas costumam ser escritas — e um
	 * casamento por `str_contains()` pegaria `wpengine.com.br`, que é outro
	 * domínio e outro dono.
	 *
	 * @param string            $host    Host medido, minúsculo.
	 * @param array<int,string> $sufixos Sufixos declarados.
	 * @return string Sufixo normalizado que casou, ou vazio.
	 */
	public static function sufixo_de_previa( string $host, array $sufixos ): string {
		$host = strtolower( trim( $host ) );

		if ( '' === $host ) {
			return '';
		}

		foreach ( $sufixos as $sufixo ) {
			$limpo = strtolower( ltrim( trim( (string) $sufixo ), '*.' ) );

			if ( '' === $limpo ) {
				continue;
			}

			if ( $host === $limpo || str_ends_with( $host, '.' . $limpo ) ) {
				return $limpo;
			}
		}

		return '';
	}

	/**
	 * A CONSEQUÊNCIA de `blog_public`, dita junto com a causa.
	 *
	 * O caso medido na 1.0.9: com as condições fechando falso, a unidade gravou
	 * `blog_public = 0` — o certo naquele momento — e o log disse que gravou. O
	 * que ele NÃO disse é que essa gravação faz o WordPress estampar no wp-admin
	 * "Problema grave de SEO: Você está bloqueando o acesso dos robôs". O
	 * operador ficou com um alarme vermelho no painel e um relatório que fechava
	 * OK, sem nada ligando os dois.
	 *
	 * O aviso do WordPress está CERTO e não é suprimido: esconder alarme
	 * verdadeiro é pior que explicá-lo. O que faltava era o relatório nomear a
	 * consequência e o caminho de saída. Na 1.0.12 esse caminho MUDOU, e a
	 * mensagem muda com ele: não se pede mais para declarar `producao` nem para
	 * preencher a lista de domínios — o padrão já é indexar, e o que resta é
	 * corrigir a guarda que disparou ou declarar `ambiente.indexar = "forcar"`.
	 *
	 * Pura por desenho: recebe o que foi medido e devolve texto, para ter piso
	 * dos dois lados na sonda funcional.
	 *
	 * @param bool   $indexavel O valor gravado foi 1.
	 * @param string $tipo      Ambiente declarado em `ambiente.tipo`.
	 * @param string $host      Host de `home_url()`.
	 * @return string
	 */
	public static function consequencia_de_indexacao( bool $indexavel, string $tipo, string $host ): string {
		if ( $indexavel ) {
			return __( 'Consequência: com blog_public = 1 o site é indexável e o wp-admin NÃO exibe o aviso de SEO sobre bloqueio de robôs — se ele aparecer, a causa está fora deste pacote.', 'f3base' );
		}

		return sprintf(
			/* translators: 1: ambiente declarado, 2: host de home_url(). */
			__( 'Consequência ESPERADA, e é ela que o operador está vendo: com blog_public = 0 o WordPress exibe no wp-admin o aviso "Problema grave de SEO: Você está bloqueando o acesso dos robôs". Esse aviso está CERTO e não é suprimido por este pacote — esconder alarme verdadeiro é pior que explicá-lo —, e ele permanece enquanto a guarda nomeada acima continuar valendo. O caminho de saída NÃO é mais configurar três chaves para chegar ao normal: o padrão desta release já é indexar. Ou some a causa medida (o ambiente declarado do WordPress, o https de home_url(), ambiente.tipo = "producao" — está "%1$s" —, ou o host %2$s deixar de casar com ambiente.dominios_de_previa), ou se declara ambiente.indexar = "forcar", que grava 1 e deixa a decisão registrada.', 'f3base' ),
			'' !== $tipo ? $tipo : '—',
			'' !== $host ? $host : '—'
		);
	}

	/**
	 * Página inicial, página de posts e política de privacidade.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_paginas_especiais(): array {
		$partes = array();
		$falhou = false;

		$home = 0;
		$blog = 0;

		/*
		 * QUAL página é a política sai da CONFIGURAÇÃO, de um lugar só. O
		 * literal `'privacidade'` espalhado por duas etapas era lista fechada
		 * decidindo o que a configuração declara.
		 */
		$ref_politica = F3Base_Imp_Conteudo::ref_da_politica_de_privacidade();
		$id_politica  = 0;

		foreach ( F3Base_Imp_Config::lista( 'paginas' ) as $indice => $entrada ) {
			unset( $entrada );

			$ref      = (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' );
			$template = (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.template', '' );
			$id       = F3Base_Imp_Conteudo::localizar_gerenciado( 'page', $ref );

			if ( 'front-page' === $template && $id > 0 ) {
				$home = $id;
			}

			if ( F3Base_Imp_Conteudo::grava_pagina_de_privacidade( $ref_politica, $ref, $id ) ) {
				$id_politica = $id;
				$resultado   = F3Base_Imp_Gravador::gravar( 'wp_page_for_privacy_policy', $id );
				$partes[]    = 'wp_page_for_privacy_policy: ' . $resultado['motivo'];
				$falhou      = $falhou || F3Base_Imp_Relatorio::FALHA === $resultado['estado'];
			}
		}

		if ( $home > 0 ) {
			$resultado = F3Base_Imp_Gravador::gravar( 'show_on_front', 'page' );
			$partes[]  = 'show_on_front: ' . $resultado['motivo'];
			$resultado = F3Base_Imp_Gravador::gravar( 'page_on_front', $home );
			$partes[]  = 'page_on_front: ' . $resultado['motivo'];
			$falhou    = $falhou || F3Base_Imp_Relatorio::FALHA === $resultado['estado'];
		} else {
			$partes[] = __( 'nenhuma página com template front-page gerenciada: página inicial não alterada.', 'f3base' );
		}

		/*
		 * A CONDIÇÃO É A MESMA DE `entrega.blog`, e até a 2.1.0 não era. Aqui
		 * a página de índice só nascia se houvesse ITEM DE MENU; lá o
		 * entregável já considerava posts declarados OU item de menu. Posts
		 * declarados sem item de menu produziam, então, um site em que
		 * `/artigos/<slug>/` respondia e `/artigos/` era 404 — índice órfão,
		 * com `page_for_posts` em zero e nenhuma linha adversa.
		 */
		$tem_posts = array() !== F3Base_Imp_Config::lista( 'posts' );
		$quer_blog = $tem_posts;

		foreach ( F3Base_Imp_Config::lista( 'navegacao.itens' ) as $indice => $entrada ) {
			unset( $entrada );

			if ( 'posts-page' === (string) F3Base_Imp_Config::obter( 'navegacao.itens.' . $indice . '.tipo', '' ) ) {
				$quer_blog = true;
				break;
			}
		}

		if ( $quer_blog ) {
			$blog = self::garantir_pagina_de_posts();

			if ( $blog > 0 ) {
				$resultado = F3Base_Imp_Gravador::gravar( 'page_for_posts', $blog );
				$partes[]  = 'page_for_posts: ' . $resultado['motivo'];
				$falhou    = $falhou || F3Base_Imp_Relatorio::FALHA === $resultado['estado'];

				$partes[] = self::medir_indice_no_prefixo( $blog );
			} else {
				$partes[] = __( 'página de posts não pôde ser garantida.', 'f3base' );
				$falhou   = ! F3Base_Imp_Gravador::em_simulacao();
			}
		} else {
			$partes[] = __( 'nem posts declarados nem item de menu do tipo posts-page: página de posts fora do escopo.', 'f3base' );
		}

		return array(
			'estado' => $falhou ? F3Base_Imp_Relatorio::FALHA : ( F3Base_Imp_Gravador::em_simulacao() ? F3Base_Imp_Relatorio::NA : F3Base_Imp_Relatorio::OK ),
			'rotulo' => 'wordpress.paginas_especiais',
			'motivo' => implode( ' | ', $partes ),
		);
	}

	/**
	 * A LEITURA DE VOLTA do índice contra o prefixo declarado, no host.
	 *
	 * A bancada não roteia: esta é a única linha do pacote capaz de acusar uma
	 * colisão real entre o prefixo dos posts e a página que serve o índice. O
	 * julgamento é do produtor puro; aqui só se MEDE — o slug gravado, o
	 * permalink do índice e o permalink de um post gerenciado, quando houver.
	 *
	 * @param int $indice ID da página de índice.
	 * @return string Linha para o motivo da etapa.
	 */
	private static function medir_indice_no_prefixo( int $indice ): string {
		$derivados = F3Base_Imp_Conteudo::derivados_do_blog_declarados();

		if ( ! $derivados['ok'] ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::FALHA,
				'wordpress.indice_no_prefixo',
				$derivados['motivo'],
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);

			return $derivados['motivo'];
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			$motivo = sprintf(
				/* translators: %s: o que os derivados declaram. */
				__( 'modo simulação: nenhuma escrita, e o índice não foi criado para ser medido. %s', 'f3base' ),
				$derivados['motivo']
			);

			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'wordpress.indice_no_prefixo',
				$motivo,
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);

			return $motivo;
		}

		$post_medido = '';

		foreach ( F3Base_Imp_Config::lista( 'posts' ) as $posicao => $entrada ) {
			unset( $entrada );

			$slug = (string) F3Base_Imp_Config::obter( 'posts.' . $posicao . '.slug', '' );
			$id   = '' !== $slug ? F3Base_Imp_Conteudo::localizar_gerenciado( 'post', $slug ) : 0;

			if ( $id > 0 ) {
				$post_medido = (string) get_permalink( $id );
				break;
			}
		}

		$veredito = F3Base_Imp_Conteudo::veredito_do_indice_no_prefixo(
			(string) get_post_field( 'post_name', $indice ),
			(string) get_permalink( $indice ),
			$post_medido,
			$derivados['slug'],
			trailingslashit( home_url( '/' ) )
		);

		F3Base_Imp_Relatorio::avaliar(
			$veredito['ok'],
			'wordpress.indice_no_prefixo',
			$veredito['motivo'],
			$veredito['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		return $veredito['motivo'];
	}

	/**
	 * Garante a página que hospeda o índice do blog.
	 *
	 * O TÍTULO E O SLUG SAEM DO PRODUTOR, e não do rótulo do item de menu.
	 * Até a 2.1.0 o slug era `sanitize_title()` do rótulo: trocar "Blog" por
	 * "Artigos" no menu mudava o endereço do índice, e mudar o prefixo dos
	 * posts não mudava — as duas metades do mesmo caminho tinham donos
	 * diferentes. O rótulo do menu volta a ser só o rótulo, e pode divergir do
	 * título da página de propósito.
	 *
	 * @return int ID, ou 0.
	 */
	private static function garantir_pagina_de_posts(): int {
		$ref = 'blog';
		$id  = F3Base_Imp_Conteudo::localizar_gerenciado( 'page', $ref );

		if ( $id > 0 ) {
			return $id;
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return 0;
		}

		$derivados = F3Base_Imp_Conteudo::derivados_do_blog_declarados();

		if ( ! $derivados['ok'] ) {
			return 0;
		}

		/*
		 * A página de posts é uma PÁGINA GERENCIADA como qualquer outra, e o
		 * status dela sai do mesmo produtor: um literal aqui seria o segundo
		 * lugar decidindo o que este pacote publica.
		 */
		$criado = wp_insert_post(
			wp_slash(
				array(
					'post_type'    => 'page',
					'post_status'  => F3Base_Imp_Conteudo::status_efetivo_de_pagina( $ref, 'publish' )['status'],
					'post_title'   => $derivados['titulo'],
					'post_name'    => $derivados['slug'],
					'post_content' => '',
					'meta_input'   => array(
						F3Base_Imp_Conteudo::META_ID     => F3Base_Imp_Conteudo::identidade( 'page', $ref ),
						F3Base_Imp_Conteudo::META_VERSAO => (string) F3Base_Imp_Config::obter( 'release.identidade', '' ),
					),
				)
			),
			true
		);

		if ( is_wp_error( $criado ) ) {
			return 0;
		}

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_POST,
			'page:blog',
			null,
			array( 'id' => (int) $criado ),
			array(
				'acao' => 'post.excluir',
				'id'   => (int) $criado,
			)
		);

		return (int) $criado;
	}

	/**
	 * A ÂNCORA dos produtores de seleção de `llms.txt`, e do gate que os serve.
	 *
	 * Lida por `estatica.llms_so_pagina_publicada`, do PRÓPRIO PACOTE, pela
	 * mesma razão de `uniao_declarada()`.
	 *
	 * - `gate`: a função que responde "esta página está publicada?" medindo o
	 *   artefato.
	 * - as demais entradas são `option => função produtora`. Era DUAS até a
	 *   2.0.0 — `f3base_llms` e `wpseo_llmstxt` —, e a segunda saiu na 2.1.0
	 *   com a decisão de usar o llms.txt do site-core: o implantador não grava
	 *   mais seleção nenhuma no plugin de SEO, cujo emissor fica desligado.
	 *   Voltar a gravar uma option de terceiro com ID de página é voltar a
	 *   declarar o produtor aqui, para que o detector o meça.
	 *
	 * @return array<string,string>
	 */
	public static function produtor_de_item_llms(): array {
		return array(
			'gate'        => 'id_de_pagina_publicada',
			'f3base_llms' => 'item_llms_de_pagina',
		);
	}

	/**
	 * O item de uma página no `llms.txt` do site-core — PONTO ÚNICO.
	 *
	 * O DEFEITO MEDIDO NA 1.0.12. O item da política de privacidade era montado
	 * de `localizar_gerenciado()` sem CONFERIR O STATUS: com a página em
	 * rascunho, `get_permalink()` devolvia um endereço que só responde a quem
	 * está logado e com permissão, e o `llms.txt` — que é público — publicava o
	 * permalink de um rascunho como se fosse a política vigente do site.
	 *
	 * @param string $ref Referência lógica da página.
	 * @return array<string,string> Item, ou vazio quando não há página publicada.
	 */
	public static function item_llms_de_pagina( string $ref ): array {
		$medido = F3Base_Imp_Conteudo::id_de_pagina_publicada( $ref );

		if ( $medido['id'] <= 0 ) {
			return array();
		}

		return array(
			/*
			 * O ID VIAJA JUNTO desde que o arquivo passou a ter dois eixos de
			 * seleção. O dedupe entre a curadoria e a enumeração é POR ID, nunca
			 * por URL: URL muda quando o slug muda, e o mesmo conteúdo sairia
			 * duas vezes no arquivo sem que nada acusasse.
			 */
			'id'        => (int) $medido['id'],
			'titulo'    => (string) get_the_title( $medido['id'] ),
			'url'       => (string) get_permalink( $medido['id'] ),
			'descricao' => (string) get_post_field( 'post_excerpt', $medido['id'] ),
		);
	}

	/**
	 * Options do `site-core`, todas pelo gravador único.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_options_site_core(): array {
		$paginas_llms = array();

		foreach ( F3Base_Imp_Config::lista( 'seo.llms_selecao.livres' ) as $ref ) {
			$item = self::item_llms_de_pagina( (string) $ref );

			if ( array() !== $item ) {
				$paginas_llms[] = $item;
			}
		}

		/*
		 * A SELEÇÃO REFERENCIA O PRODUTOR. A chave decide se a política ENTRA na
		 * seleção; QUAL página é a política sai do produtor único, que lê o
		 * papel declarado na entrada da página. Desligar esta chave tira a
		 * política do llms.txt e não toca em mais nada.
		 */
		$privacidade = (bool) F3Base_Imp_Decisoes::valor( 'seo.llms_selecao.incluir_politica_privacidade' )
			? self::item_llms_de_pagina( F3Base_Imp_Conteudo::ref_da_politica_de_privacidade() )
			: array();

		/*
		 * A UNIÃO DOS REDIRECTS É MEDIDA UMA VEZ, ANTES da gravação. Ela é
		 * idempotente — reaplicá-la sobre o próprio resultado devolve o mesmo
		 * valor —, mas os pares que o agente REMOVEU só existem enquanto a base
		 * ainda é a anterior: depois da escrita, a base já não sabe o que foi
		 * removido, e medir ali daria a contagem de uma execução que ainda não
		 * aconteceu. É desta medição que saem a linha do relatório e a lista de
		 * removidos que vai para a base.
		 */
		$uniao_medida = self::uniao_de_redirects_medida();

		$valores = array(
			/*
			 * `email_leads` SAIU DAQUI na 1.1.0. Ela era gravada a partir de
			 * uma chave do topo de `contato`, e a varredura de consumidores em runtime
			 * era conclusiva: nenhum módulo do site-core lia a subchave —
			 * `email_leads` aparecia no catálogo, no sanitizador e em mais lugar
			 * nenhum. Ela é o destino do regime `cf7-email`, e passou a morar
			 * DENTRO da entrada de formulário que a consome. A subchave continua
			 * existindo na option: o sanitizador do site-core a devolve vazia
			 * por padrão, e a partir da execução em que a base desta option
			 * existir, o valor que o agente gravar ali pelo canal é preservado
			 * pela regra de três vias, junto com o resto da option — este
			 * pacote deixou de ter opinião sobre ela.
			 */
			'f3base_contato'             => array(
				'whatsapp_e164'   => (string) F3Base_Imp_Projeto::obter( 'contato.whatsapp_e164', '' ),
				'mensagem_padrao' => '',
			),
			/*
			 * O PADRÃO DE CONSENTIMENTO SAI DAS DECISÕES, e não do projeto. Ele
			 * vinha de `fato_juridico.consentimento_padrao`, que nascia VAZIO —
			 * e vazio não era neutro: o site subia sem política declarada, o
			 * sanitizador do site-core caía em pré-aprovado sem que ninguém
			 * tivesse decidido, e a tela cobrava do operador uma resposta cujo
			 * lado certo é sempre o mesmo nesta base. O motivo está escrito ao
			 * lado do valor em `config/decisoes.tsv`; a recusa do visitante
			 * continua garantida pelo controle do rodapé, que é obrigatório
			 * aqui, e vale do clique em diante.
			 */
			'f3base_consentimento'       => array(
				'padrao'                => (string) F3Base_Imp_Decisoes::valor( 'consentimento.padrao' ),
				'controle_rodape'       => (bool) F3Base_Imp_Decisoes::valor( 'consentimento.controle_rodape' ),
				'aviso_primeira_visita' => (bool) F3Base_Imp_Decisoes::valor( 'consentimento.aviso_primeira_visita' ),
				'ttl_dias'              => (int) F3Base_Imp_Decisoes::valor( 'consentimento.ttl_dias' ),
			),
			'f3base_atribuicao'          => array(
				'modelo'   => (string) F3Base_Imp_Decisoes::valor( 'atribuicao.modelo' ),
				'ttl_dias' => (int) F3Base_Imp_Decisoes::valor( 'atribuicao.ttl_dias' ),
			),
			'f3base_retencao_meses'      => (int) F3Base_Imp_Projeto::obter( 'fato_juridico.retencao_leads_meses', 24 ),
			/*
			 * O RESUMO DE COMPORTAMENTO PASSA A SER GRAVADO. Ele estava na
			 * lista de operáveis desde a 1.1.4 e nenhum lote o escrevia: a
			 * option não existia no banco, o site-core respondia pelo padrão
			 * embutido e `f3base_operaveis` declarava ao agente uma option que
			 * ninguém tinha criado. Gravá-la é o que faz a instrumentação
			 * primária deste site ser um FATO DECLARADO, e não um padrão de
			 * biblioteca que a próxima release do plugin pode mudar sem que
			 * nenhuma linha do relatório perceba.
			 */
			'f3base_comportamento'       => array(
				'ligado'         => (bool) F3Base_Imp_Decisoes::valor( 'comportamento.ligado' ),
				'retencao_dias'  => (int) F3Base_Imp_Decisoes::valor( 'comportamento.retencao_dias' ),
				'dias_no_painel' => (int) F3Base_Imp_Decisoes::valor( 'comportamento.dias_no_painel' ),
			),
			'f3base_linkedin_partner_id' => (string) F3Base_Imp_Projeto::obter( 'tracking.linkedin_partner_id', '' ),
			'f3base_llms'                => array(
				'ligado'               => (bool) F3Base_Imp_Decisoes::valor( 'bots_ia.llms_txt' ),
				'introducao'           => '',
				'apresentacao'         => (string) F3Base_Imp_Projeto::obter( 'apresentacao_para_bots', '' ),
				'modo'                 => (string) F3Base_Imp_Decisoes::valor( 'bots_ia.llms_txt_modo' ),
				'tipos'                => array_map( 'strval', (array) F3Base_Imp_Decisoes::valor( 'bots_ia.llms_txt_tipos' ) ),
				'full'                 => (bool) F3Base_Imp_Decisoes::valor( 'bots_ia.llms_full_txt' ),
				'indexavel'            => (bool) F3Base_Imp_Decisoes::valor( 'bots_ia.llms_indexavel' ),
				'politica_privacidade' => $privacidade,
				'livres'               => $paginas_llms,
			),
			'f3base_redirects'           => self::valor_desejado_de_redirects(),
			/*
			 * AS QUATRO LISTAS DEIXARAM DE NASCER FIXAS EM VAZIO. Até a 1.0.19
			 * `area_servida`, `conhece_sobre`, `servicos` e `ponto_de_contato`
			 * eram gravadas como `array()` LITERAL, embora o sanitizador do
			 * site-core as aceite e o módulo de SEO as leia: a configuração não
			 * tinha por onde declará-las, e o grafo do site saía com o nome da
			 * organização e mais nada. Elas nascem vazias na configuração — e
			 * vazio continua sendo OMITIDO do grafo, nunca erro —, mas agora
			 * quem preenche o arquivo único vê a diferença no HTML servido.
			 */
			'f3base_seo_entidade'        => array(
				'nome'             => (string) F3Base_Imp_Config::obter( 'seo.organizacao.nome', '' ),
				'same_as'          => array_map( 'strval', F3Base_Imp_Projeto::lista( 'organizacao.same_as' ) ),
				'area_servida'     => array_map( 'strval', F3Base_Imp_Projeto::lista( 'organizacao.area_servida' ) ),
				'conhece_sobre'    => array_map( 'strval', F3Base_Imp_Projeto::lista( 'organizacao.conhece_sobre' ) ),
				'ponto_de_contato' => self::pontos_de_contato_declarados( 'seo.organizacao.ponto_de_contato' ),
				'organizacao_mae'  => (string) F3Base_Imp_Projeto::obter( 'organizacao.organizacao_mae', '' ),
				'servicos'         => self::servicos_declarados( 'seo.organizacao.servicos' ),
				'faq_schema'       => (bool) F3Base_Imp_Decisoes::valor( 'seo.organizacao.faq_schema' ),
			),
			'f3base_cabecalhos'          => array(
				'x_content_type_options' => (bool) F3Base_Imp_Decisoes::valor( 'cabecalhos.x_content_type_options' ),
				'x_frame_options'        => (string) F3Base_Imp_Decisoes::valor( 'cabecalhos.x_frame_options' ),
				'csp_frame_ancestors'    => (string) F3Base_Imp_Decisoes::valor( 'cabecalhos.csp_frame_ancestors' ),
				'referrer_policy'        => (string) F3Base_Imp_Decisoes::valor( 'cabecalhos.referrer_policy' ),
				'coop'                   => (string) F3Base_Imp_Decisoes::valor( 'cabecalhos.coop' ),
				'permissions_policy'     => (string) F3Base_Imp_Decisoes::valor( 'cabecalhos.permissions_policy' ),
				'hsts'                   => (bool) F3Base_Imp_Decisoes::valor( 'cabecalhos.hsts' ),
				'hsts_max_age'           => (int) F3Base_Imp_Decisoes::valor( 'cabecalhos.hsts_max_age' ),
			),
			/*
			 * A ORIGEM CONFIÁVEL É DECLARADA, NUNCA INFERIDA. Vazia por padrão:
			 * enquanto ninguém declarar o cabeçalho, o rate limit do endpoint de
			 * leads conta por REMOTE_ADDR — atrás de CDN isso junta todo mundo
			 * num balde só, e é um preço declarado; aceitar cabeçalho de proxy
			 * sem declaração seria deixar o visitante escolher o próprio balde.
			 */
			'f3base_origem_confiavel'    => array(
				'cabecalho' => (string) F3Base_Imp_Projeto::obter( 'origem_confiavel.cabecalho', '' ),
				'saltos'    => (int) F3Base_Imp_Projeto::obter( 'origem_confiavel.saltos', 1 ),
			),
			/*
			 * AS CINCO OPTIONS DE MEDIÇÃO ENTRAM AQUI na 1.1.0, e nascem
			 * vazias. O leitor delas já existe no módulo de tracking do
			 * site-core desde a decisão 55; o que faltava era a via pela qual o
			 * arquivo único as declara. Vazias, o slot é inerte: nenhuma tag
			 * chega ao navegador. `f3base_gtm_container_id` preenchido decide o
			 * caminho e desliga as tags diretas — a estrutura que impede o
			 * disparo em dobro.
			 */
			'f3base_gtm_container_id'    => (string) F3Base_Imp_Projeto::obter( 'tracking.gtm_container_id', '' ),
			'f3base_ga4_measurement_id'  => (string) F3Base_Imp_Projeto::obter( 'tracking.ga4_measurement_id', '' ),
			'f3base_google_ads'          => array(
				'conversion_id'    => (string) F3Base_Imp_Projeto::obter( 'tracking.google_ads.conversion_id', '' ),
				'conversion_label' => (string) F3Base_Imp_Projeto::obter( 'tracking.google_ads.conversion_label', '' ),
			),
			'f3base_meta_pixel_id'       => (string) F3Base_Imp_Projeto::obter( 'tracking.meta_pixel_id', '' ),
			'f3base_linkedin_conversion_id' => (string) F3Base_Imp_Projeto::obter( 'tracking.linkedin_conversion_id', '' ),
			/*
			 * AS DUAS DE VERIFICAÇÃO DE DOMÍNIO ENTRAM NA 1.1.2 e nascem vazias,
			 * como todo slot deste pacote. Elas existem na configuração para
			 * que um site cujo operador JÁ tenha os tokens nasça verificado —
			 * sem uma segunda visita ao console depois da instalação —, e
			 * continuam operáveis pelo canal para quem os obtiver depois.
			 *
			 * O TOKEN DA CONVERSIONS API DA META NÃO ESTÁ AQUI, e a ausência é
			 * a declaração: ele é SEGREDO, o arquivo único viaja dentro do zip
			 * e chega a quem faz o upload, e segredo em arquivo que viaja é
			 * segredo copiado. `f3base_meta_capi_token` é gravada pelo agente,
			 * pelo canal, e nenhum lote deste implantador a escreve.
			 */
			'f3base_verificacao_google'  => (string) F3Base_Imp_Projeto::obter( 'verificacao_dominio.google', '' ),
			'f3base_verificacao_meta'    => (string) F3Base_Imp_Projeto::obter( 'verificacao_dominio.meta', '' ),
		);

		$partes = array();
		$falhou = false;

		/*
		 * TODA OPTION DESTE BLOCO PASSA PELA REGRA DE TRÊS VIAS. O contexto
		 * `base` é o que liga a regra, e ele é declarado AQUI porque é este o
		 * conjunto que o agente opera depois da instalação: as options do
		 * site-core, operáveis ou estruturais. A infraestrutura do implantador
		 * — checkpoint, journal, procedência, a própria base — continua fora,
		 * porque ela é estado desta execução e não configuração de ninguém.
		 *
		 * `base_extra` existe por causa de UMA option: `f3base_redirects`
		 * precisa que a base carregue, além da impressão do valor aplicado, os
		 * pares que o agente REMOVEU — sem isso a união os ressuscitaria na
		 * execução seguinte, que é o defeito medido.
		 */
		$preservadas = array();
		$sobrepostas = array();
		$nasceram    = array();
		$mudaram     = array();
		$diferem     = array();

		foreach ( $valores as $option => $valor ) {
			$contexto = array(
				'plugin' => (string) F3Base_Imp_Config::obter( 'site.site_core_slug', '' ),
				'base'   => true,
			);

			if ( 'f3base_redirects' === $option ) {
				$contexto['base_extra'] = array( 'removidos' => $uniao_medida['removidos_de'] );
			}

			$resultado = F3Base_Imp_Gravador::gravar( $option, $valor, $contexto );
			$partes[]  = $option . ': ' . $resultado['motivo'];
			$falhou    = $falhou || in_array( $resultado['estado'], array( F3Base_Imp_Relatorio::FALHA, F3Base_Imp_Relatorio::BLOCKED ), true );

			$merge = (string) ( $resultado['merge'] ?? '' );

			if ( F3Base_Imp_Gravador::MERGE_PRESERVAR === $merge ) {
				$preservadas[] = sprintf(
					/* translators: 1: nome da option; 2: valor preservado; 3: valor da configuração, não aplicado. */
					__( '%1$s (preservado: %2$s; da configuração, não aplicado: %3$s)', 'f3base' ),
					$option,
					F3Base_Imp_Gravador::amostra_de_valor( $resultado['anterior'] ),
					F3Base_Imp_Gravador::amostra_de_valor( $resultado['novo'] )
				);
			} elseif ( F3Base_Imp_Gravador::MERGE_SOBREPOR === $merge ) {
				$sobrepostas[] = sprintf(
					/* translators: 1: nome da option; 2: valor sobreposto; 3: valor aplicado. */
					__( '%1$s (estava: %2$s; aplicado: %3$s)', 'f3base' ),
					$option,
					F3Base_Imp_Gravador::amostra_de_valor( $resultado['anterior'] ),
					F3Base_Imp_Gravador::amostra_de_valor( $resultado['novo'] )
				);
			} elseif ( F3Base_Imp_Gravador::MERGE_NASCER === $merge ) {
				$nasceram[] = $option;
			}

			$linha_de_relatorio = isset( $resultado['relatorio'] ) && is_array( $resultado['relatorio'] ) ? $resultado['relatorio'] : array();

			if ( ! empty( $linha_de_relatorio['mudou'] ) ) {
				$mudaram[] = $option . ' — ' . (string) $linha_de_relatorio['registro'];
			}

			if ( ! empty( $linha_de_relatorio['difere'] ) ) {
				$diferem[] = $option . ' — ' . (string) $linha_de_relatorio['segunda_linha'];
			}
		}

		/*
		 * O REGISTRO DO QUE MUDOU SÓ EXISTE NO MODO SOMENTE-RELATÓRIO, e é ele
		 * que substitui a antiga leitura de "divergência". A linha sai em OK
		 * SEMPRE: mudança feita pelo agente não é achado adverso — é o trabalho
		 * dele —, e WARN aqui treinaria o leitor a ignorar o relatório inteiro.
		 * A comparação com a configuração continua existindo, ROTULADA, na
		 * segunda linha, porque ela tem leitor: quem for reexecutar.
		 */
		if ( F3Base_Imp_Gravador::em_relatorio() ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'options.mudanca_desde_a_aplicacao',
				self::texto_do_registro_de_mudanca( count( $valores ), $mudaram, $diferem ),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		}

		F3Base_Imp_Relatorio::emitir(
			array() === $sobrepostas ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::WARN,
			'options.edicao_do_agente_preservada',
			self::texto_do_merge_de_options( count( $valores ), $preservadas, $sobrepostas, $nasceram ),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		/*
		 * A UNIÃO DE `f3base_redirects` SAI EM LINHA PRÓPRIA. Foi esta option
		 * que, na 1.0.11, teve duas fontes de valor desejado e um relatório com
		 * duas afirmações verdadeiras e contraditórias sobre o mesmo artefato:
		 * a etapa de permalinks gravou dois pares e disse a verdade, e esta
		 * etapa gravou `redirects: []` por cima e também disse a verdade. A
		 * linha existe para que a composição do valor seja LIDA, e não inferida
		 * de duas mensagens em pontos distantes do log.
		 */
		$uniao   = self::veredito_da_uniao_de_redirects( $uniao_medida );
		$falhou  = $falhou || F3Base_Imp_Relatorio::FALHA === $uniao['estado'];

		F3Base_Imp_Relatorio::emitir(
			$uniao['estado'],
			'redirects.fonte_composta',
			$uniao['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		$operaveis = self::operaveis_declaradas();

		$resultado = F3Base_Imp_Gravador::gravar( 'f3base_operaveis', $operaveis );
		$partes[]  = 'f3base_operaveis: ' . $resultado['motivo'];

		/*
		 * O ESPELHO DO CONTRATO DE COPY SAIU NA 1.1.0, e com ele a linha
		 * `copy.contrato_espelhado`. `f3base_copy_contrato` era gravada aqui e
		 * relida logo abaixo, e o site NUNCA a leu: a varredura do site-core
		 * era conclusiva — a option aparecia no catálogo, no sanitizador e em
		 * mais lugar nenhum. Pior, ela envelhecia sozinha: o contrato de copy é
		 * artefato de BUILD, verdadeiro sobre o conteúdo do template, e vira
		 * falso no instante em que o agente troca o conteúdo pelo do cliente —
		 * que é exatamente o que a premissa desta release diz que vai
		 * acontecer. Quem confere o contrato continua sendo `copy.contrato`, na
		 * suíte, lendo `config/site.json` e o conteúdo inteiro; o que deixou de
		 * existir é a impressão, dentro da instância, de que alguma coisa está
		 * sendo conferida ali.
		 */

		/*
		 * A BASE LEGAL E O PRAZO DE RETENÇÃO NÃO SÃO MAIS MEDIDOS AQUI — 2.1.0.
		 * `lgpd.base_legal_declarada` avisava que a política ia ao ar sem a
		 * hipótese do art. 7º quando `fato_juridico.base_legal` estava vazia. O
		 * que a política afirma é responsabilidade de quem responde por ela, e
		 * o implantador não é quem confere o texto jurídico de ninguém: as duas
		 * chaves continuam sendo lidas para o texto e para a retenção do
		 * site-core, e o preenchimento é do operador, antes da execução única.
		 */

		return array(
			'estado' => $falhou ? F3Base_Imp_Relatorio::FALHA : ( F3Base_Imp_Gravador::em_simulacao() ? F3Base_Imp_Relatorio::NA : F3Base_Imp_Relatorio::OK ),
			'rotulo' => 'site_core.options',
			'motivo' => implode( ' | ', $partes ),
		);
	}

	/**
	 * A LISTA DO QUE O OPERADOR PODE EDITAR NA TELA DO PLUGIN.
	 *
	 * Ela é gravada em `f3base_operaveis`, que é FRONTEIRA: o plugin persistente
	 * a lê em `F3Base_Options::operavel()` e ela só RESTRINGE — o catálogo dele
	 * é o teto, e o que não estiver aqui SOME da tela de configuração.
	 *
	 * POR QUE ELA É UM MÉTODO desde a 2.2.0. Enquanto era um array anônimo no
	 * meio da etapa, nada a comparava com o catálogo do plugin: as duas listas
	 * concordavam por coincidência, e uma release do plugin que declarasse uma
	 * option operável nova faria o campo dela desaparecer da tela assim que
	 * este implantador rodasse — sem erro, sem aviso e sem linha de relatório.
	 * Com nome próprio ela é lida de fora, e `pacote.operaveis_confere_com_o_catalogo`
	 * cruza os dois lados a cada rodada.
	 *
	 * @return array<int,string>
	 */
	public static function operaveis_declaradas(): array {
		return array(
			'f3base_contato',
			'f3base_consentimento',
			'f3base_atribuicao',
			'f3base_retencao_meses',
			'f3base_linkedin_partner_id',
			'f3base_llms',
			/*
			 * A origem confiável do rate limit é operável porque a resposta
			 * certa depende da hospedagem, e ela muda sem release: quem põe uma
			 * CDN na frente do site precisa poder declarar o cabeçalho ali, sem
			 * esperar por nós. Vazia continua sendo o padrão seguro.
			 */
			'f3base_origem_confiavel',
			/*
			 * O RESUMO DE COMPORTAMENTO É OPERÁVEL porque as três decisões
			 * dele são do projeto e mudam sem release: guardar ou não, por
			 * quantos dias, e que período a tela soma. O prazo declarado aqui
			 * é o que a política de privacidade do site promete.
			 */
			'f3base_comportamento',
			/*
			 * AS CINCO DE MEDIÇÃO SÃO OPERÁVEIS, e é o caso mais claro de
			 * todos: o ID do contêiner, o do GA4, o par do Google Ads, o Pixel
			 * da Meta e a conversão do LinkedIn são dados de CONTA, e a conta
			 * muda sem release nossa. Quem opera é o agente, pelo canal — e a
			 * lista `f3base_operaveis` é o que declara ao site-core e ao agente
			 * quais options ele pode gravar sem esperar por nós.
			 */
			'f3base_gtm_container_id',
			'f3base_ga4_measurement_id',
			'f3base_google_ads',
			'f3base_meta_pixel_id',
			'f3base_linkedin_conversion_id',
			/*
			 * AS DUAS DE VERIFICAÇÃO E O TOKEN DA CAPI SÃO OPERÁVEIS, e o
			 * token está nesta lista embora o implantador NÃO o grave: a lista
			 * declara ao agente o que ele pode escrever, e não o que este
			 * pacote escreveu. Omiti-lo faria o agente procurar autorização
			 * para a única option desta release que ele é o único a poder
			 * preencher.
			 */
			'f3base_verificacao_google',
			'f3base_verificacao_meta',
			'f3base_meta_capi_token',
		);
	}

	/**
	 * O texto de `options.edicao_do_agente_preservada`, nos dois ramos. FUNÇÃO PURA.
	 *
	 * Quatro fatos, e cada um deles precisa de nome próprio no relatório:
	 *
	 * - **Preservadas**: o pacote NÃO gravou porque alguém editou a option pelo
	 *   canal e a configuração não mudou aquilo. É o ramo bom desta release, e
	 *   ele sai em OK — preservar não é achado adverso, é a regra funcionando.
	 * - **Sobrepostas**: o pacote gravou POR CIMA de uma edição, porque a
	 *   configuração mudou a mesma coisa depois. É o único caminho pelo qual o
	 *   pacote vence quem opera o site, e por isso é o único que fecha WARN,
	 *   com os dois valores.
	 * - **Base nascida agora**: a option existia e não tinha base. Esta execução
	 *   — e só ela — não consegue distinguir "o agente editou" de "sempre foi
	 *   assim", e dizer isso é o que impede a estrutura nova de absolver a si
	 *   mesma para sempre.
	 * - **Total medido**: quantas options passaram pela regra, para que
	 *   "nenhuma preservada" seja distinguível de "nenhuma medida".
	 *
	 * @param int               $total       Quantas options passaram pela regra.
	 * @param array<int,string> $preservadas Options preservadas, já nomeadas com os dois valores.
	 * @param array<int,string> $sobrepostas Options sobrepostas, já nomeadas com os dois valores.
	 * @param array<int,string> $nasceram    Options cuja base nasceu nesta execução.
	 * @return string
	 */
	public static function texto_do_merge_de_options( int $total, array $preservadas, array $sobrepostas, array $nasceram ): string {
		$nota_nascer = array() === $nasceram
			? ''
			: sprintf(
				/* translators: 1: quantidade, 2: nomes das options. */
				__( ' A BASE NASCEU NESTA EXECUÇÃO para %1$d option(s): %2$s. Nelas o valor observado foi tratado como base — nesta execução, e só nesta, o pacote não tem como distinguir uma edição feita pelo canal de um valor que sempre esteve ali. A partir da próxima, edição sobre esse valor é reconhecida e preservada.', 'f3base' ),
				count( $nasceram ),
				implode( ', ', $nasceram )
			);

		if ( array() !== $sobrepostas ) {
			return sprintf(
				/* translators: 1: quantidade sobreposta, 2: options sobrepostas com os dois valores, 3: quantidade preservada, 4: options preservadas, 5: total medido, 6: nota da base nascida. */
				__( 'SOBREPOSIÇÃO: %1$d option(s) foram gravadas POR CIMA de uma edição feita pelo canal, porque a configuração mudou a mesma coisa depois — %2$s. Este é o único caminho pelo qual este pacote vence quem opera o site, e ele sai nomeado com os dois valores justamente por isso: quem lê decide se a configuração é que precisa acompanhar o site. Preservadas nesta execução: %3$d (%4$s). Medidas: %5$d option(s).%6$s', 'f3base' ),
				count( $sobrepostas ),
				implode( ' | ', $sobrepostas ),
				count( $preservadas ),
				array() === $preservadas ? __( 'nenhuma', 'f3base' ) : implode( ' | ', $preservadas ),
				$total,
				$nota_nascer
			);
		}

		if ( array() !== $preservadas ) {
			return sprintf(
				/* translators: 1: quantidade preservada, 2: options preservadas com os dois valores, 3: total medido, 4: nota da base nascida. */
				__( 'a decisão de quem opera o site VENCEU esta execução em %1$d option(s), e o pacote não gravou nenhuma delas: %2$s. Duas coisas caem aqui, e o motivo de cada uma sai ao lado da option no registro da etapa: a edição feita pelo canal depois de uma aplicação deste pacote, e o valor que a tela do plugin persistente já tinha gravado antes de a implantação existir. Nenhuma sobreposição — a configuração não mudou nada que alguém já tivesse decidido. Medidas: %3$d option(s).%4$s', 'f3base' ),
				count( $preservadas ),
				implode( ' | ', $preservadas ),
				$total,
				$nota_nascer
			);
		}

		return sprintf(
			/* translators: 1: total medido, 2: nota da base nascida. */
			__( 'nenhuma divergência entre o que este pacote aplicou por último e o que está na instalação: as %1$d option(s) deste bloco passaram pela regra de três vias e nenhuma foi preservada nem sobreposta. Nada foi revertido porque não havia edição a reverter.%2$s', 'f3base' ),
			$total,
			$nota_nascer
		);
	}

	/**
	 * O texto do REGISTRO DO QUE MUDOU DESDE A ÚLTIMA APLICAÇÃO. FUNÇÃO PURA.
	 *
	 * Duas listas e uma contagem, e nenhuma das três é opcional:
	 *
	 * - **Mudou desde a aplicação**: as options cujo valor observado difere do
	 *   último que este pacote aplicou. É registro, e por isso a linha fecha OK
	 *   nos dois ramos — o agente mudar uma option é o trabalho dele, e chamar
	 *   isso de divergência ensinaria o leitor a ignorar o relatório.
	 * - **Difere da configuração original**: rotulada como tal, e SEGUNDA. Ela
	 *   tem leitor — quem for reexecutar o implantador, porque é a configuração
	 *   que a reexecução aplica — e não tem veredito.
	 * - **Total medido**: para que "nada mudou" seja distinguível de "nada foi
	 *   medido", que é a mesma doença do escopo vazio que aprova sem olhar.
	 *
	 * @param int               $total   Quantas options passaram pela leitura.
	 * @param array<int,string> $mudaram Options que mudaram desde a aplicação, já nomeadas.
	 * @param array<int,string> $diferem Options que diferem da configuração original, já nomeadas.
	 * @return string
	 */
	public static function texto_do_registro_de_mudanca( int $total, array $mudaram, array $diferem ): string {
		$segunda = array() === $diferem
			? __( 'Nenhuma option difere da configuração original: uma reexecução do implantador não mudaria nada aqui.', 'f3base' )
			: sprintf(
				/* translators: 1: quantidade, 2: as options com o valor da configuração. */
				__( 'SEGUNDA LINHA — difere da configuração original em %1$d option(s): %2$s. Isto NÃO é achado: a configuração é a certidão de nascimento deste site, e não o estado corrente dele. A linha existe para quem for REEXECUTAR o implantador, porque é o valor da configuração que a reexecução leva em conta.', 'f3base' ),
				count( $diferem ),
				implode( ' | ', $diferem )
			);

		if ( array() === $mudaram ) {
			return sprintf(
				/* translators: 1: total medido, 2: a segunda linha. */
				__( 'REGISTRO DO QUE MUDOU DESDE A ÚLTIMA APLICAÇÃO: nenhuma das %1$d option(s) lidas mudou desde o valor que este pacote aplicou por último. %2$s', 'f3base' ),
				$total,
				$segunda
			);
		}

		return sprintf(
			/* translators: 1: quantidade que mudou, 2: total medido, 3: as options com os dois valores, 4: a segunda linha. */
			__( 'REGISTRO DO QUE MUDOU DESDE A ÚLTIMA APLICAÇÃO: %1$d de %2$d option(s) lidas mudaram desde o valor que este pacote aplicou por último — %3$s. Quem opera este site é o agente, e mudar é o que ele faz: isto é registro, não divergência, e nada foi revertido. %4$s', 'f3base' ),
			count( $mudaram ),
			$total,
			implode( ' | ', $mudaram ),
			$segunda
		);
	}

	/**
	 * Pontos de contato da organização, declarados no arquivo único.
	 *
	 * Entrada sem `tipo` é descartada: um ponto de contato sem tipo não tem o
	 * que virar no grafo, e emitir um `contactPoint` anônimo seria inventar
	 * dado estruturado.
	 *
	 * @param string $caminho Caminho da lista no arquivo único.
	 * @return array<int,array<string,mixed>>
	 */
	private static function pontos_de_contato_declarados( string $caminho ): array {
		$saida = array();

		foreach ( F3Base_Imp_Config::lista( $caminho ) as $indice => $entrada ) {
			unset( $entrada );

			$tipo = trim( (string) F3Base_Imp_Config::obter( $caminho . '.' . $indice . '.tipo', '' ) );

			if ( '' === $tipo ) {
				continue;
			}

			$saida[] = array(
				'tipo'     => $tipo,
				'telefone' => (string) F3Base_Imp_Config::obter( $caminho . '.' . $indice . '.telefone', '' ),
				'email'    => (string) F3Base_Imp_Config::obter( $caminho . '.' . $indice . '.email', '' ),
				'idiomas'  => array_map( 'strval', F3Base_Imp_Config::lista( $caminho . '.' . $indice . '.idiomas' ) ),
			);
		}

		return $saida;
	}

	/**
	 * Serviços da organização, declarados no arquivo único.
	 *
	 * Entrada sem `nome` é descartada pelo mesmo motivo dos pontos de contato —
	 * e é a mesma regra que o sanitizador do `site-core` aplica do outro lado.
	 *
	 * @param string $caminho Caminho da lista no arquivo único.
	 * @return array<int,array<string,mixed>>
	 */
	private static function servicos_declarados( string $caminho ): array {
		$saida = array();

		foreach ( F3Base_Imp_Config::lista( $caminho ) as $indice => $entrada ) {
			unset( $entrada );

			$nome = trim( (string) F3Base_Imp_Config::obter( $caminho . '.' . $indice . '.nome', '' ) );

			if ( '' === $nome ) {
				continue;
			}

			$saida[] = array(
				'nome'         => $nome,
				'descricao'    => (string) F3Base_Imp_Config::obter( $caminho . '.' . $indice . '.descricao', '' ),
				'url'          => (string) F3Base_Imp_Config::obter( $caminho . '.' . $indice . '.url', '' ),
				'tipo_servico' => (string) F3Base_Imp_Config::obter( $caminho . '.' . $indice . '.tipo_servico', '' ),
				'area_servida' => array_map( 'strval', F3Base_Imp_Config::lista( $caminho . '.' . $indice . '.area_servida' ) ),
			);
		}

		return $saida;
	}

	/**
	 * Veredito do destino privado de um regime de formulário. FUNÇÃO PURA.
	 *
	 * O REGIME É DERIVADO DO VALOR desde a 1.0.19: a presença do destino decide
	 * se ele existe, e não um interruptor `ativo` ao lado. Três saídas, e elas
	 * não são intercambiáveis:
	 *
	 * - **Chave declarada e VAZIA: N/A com a condição declarada.** O regime não
	 *   existe neste site. Não é pré-condição pendente nem defeito: é uma
	 *   funcionalidade que ninguém pediu, e a mensagem diz que basta preencher a
	 *   chave nomeada para ela passar a existir. Enquanto estiver vazia, o CTA
	 *   que ainda tem o destino DO MODELO não é publicado; um CTA cujo destino
	 *   alguém trocou continua na página, intocado — a 1.1.0 estreitou a
	 *   supressão porque a regra antiga apagava o trabalho do agente de
	 *   manutenção junto com o botão vazio.
	 * - **Chave preenchida e com formato errado: FALHA.** Aí o dado existe e está
	 *   errado, e isso é defeito de configuração — o lead iria para um destino
	 *   que não recebe.
	 * - **Entrada sem `destino` declarado: FALHA.** A entrada não diz para onde
	 *   mandar, e sem caminho não há nem o que preencher; a entrada é que está
	 *   quebrada.
	 *
	 * ATÉ A 1.0.18 A CHAVE VAZIA ERA BLOCKED, e o preço estava medido: uma
	 * implantação de template limpo, que tinha dado certo, terminava dizendo que
	 * algo estava errado. BLOCKED é pré-condição AUSENTE de algo que o site
	 * precisa; um regime que ninguém instanciou não precisa de nada.
	 *
	 * O formato conferido vem do regime, que o schema declara. Regime cujo
	 * conjunto fechado não declara formato para o destino sai OK DIZENDO que só a
	 * presença foi medida — silêncio ali seria a checagem afirmando mais do que
	 * mediu.
	 *
	 * O ARQUIVO DA CHAVE É DERIVADO, e o caso que obrigou: o destino declarado
	 * pelos regimes mora em `config/projeto.json` — é a entrada do formulário,
	 * lida por `F3Base_Imp_Projeto` —, e esta mensagem dizia `config/site.json`,
	 * digitado à mão. `F3Base_Imp_Residencia` responde a partir do que cada
	 * arquivo declara, então mover a chave move a instrução junto.
	 *
	 * @param string $regime  Regime declarado na entrada.
	 * @param string $caminho Caminho da chave de destino, no arquivo que a declara.
	 * @param string $valor   Valor lido daquela chave.
	 * @return array{estado:string,motivo:string,resumo:string}
	 */
	public static function veredito_destino( string $regime, string $caminho, string $valor ): array {
		if ( '' === trim( $caminho ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::FALHA,
				'motivo' => sprintf(
					/* translators: %s: regime declarado. */
					__( 'a entrada do regime %s não declara a chave "destino": não existe caminho de configuração para onde o lead deva ir, e isso é defeito da própria entrada, não pré-condição de projeto.', 'f3base' ),
					$regime
				),
				'resumo' => __( 'entrada sem destino declarado', 'f3base' ),
			);
		}

		if ( '' === trim( $valor ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::NA,
				'motivo' => sprintf(
					/* translators: 1: caminho da chave de destino, 2: regime declarado, 3: onde a chave mora, derivado dela. */
					__( 'condição de aplicabilidade falsa: a chave %1$s está vazia %3$s, e é a presença dela — e só ela — que faz o regime %2$s existir neste site. Nada está pendente: enquanto ela estiver vazia, o CTA que ainda aponta para o destino do modelo não é publicado, porque publicar um botão que não leva a lugar nenhum é pior que não ter botão; um CTA cujo destino alguém já trocou continua publicado como está. O número é preenchido ANTES da execução única em %1$s %3$s; depois dela, o ajuste é pelo canal MCP — a option f3base_contato do site-core é operável, e o CTA do modelo passa a apontar para a conversa na hora.', 'f3base' ),
					$caminho,
					$regime,
					F3Base_Imp_Residencia::onde_preencher( array( $caminho ) )
				),
				'resumo' => sprintf(
					/* translators: %s: caminho da chave de destino. */
					__( 'regime inexistente enquanto %s estiver vazia (N/A)', 'f3base' ),
					$caminho
				),
			);
		}

		$formatos = array(
			'whatsapp'  => array(
				'regex'  => '/^[0-9]{8,15}$/',
				'exige'  => __( 'somente dígitos, com código de país, de 8 a 15 dígitos (E.164 sem "+", sem espaço e sem pontuação)', 'f3base' ),
			),
			'cf7-email' => array(
				'regex'  => '',
				'exige'  => __( 'um endereço de e-mail que o núcleo aceite', 'f3base' ),
			),
		);

		if ( ! isset( $formatos[ $regime ] ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::OK,
				'motivo' => sprintf(
					/* translators: 1: caminho da chave de destino, 2: regime declarado. */
					__( 'a chave %1$s está preenchida. O conjunto fechado do regime %2$s não declara formato para o destino, então SÓ A PRESENÇA foi medida — o formato não foi conferido, e dizer isso é parte do resultado.', 'f3base' ),
					$caminho,
					$regime
				),
				'resumo' => __( 'destino presente (formato não declarado pelo regime)', 'f3base' ),
			);
		}

		$valido = 'cf7-email' === $regime
			? ( false !== is_email( $valor ) )
			: ( 1 === preg_match( (string) $formatos[ $regime ]['regex'], $valor ) );

		if ( ! $valido ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::FALHA,
				'motivo' => sprintf(
					/* translators: 1: caminho da chave de destino, 2: regime, 3: formato exigido. */
					__( 'a chave %1$s está PREENCHIDA e o valor não serve para o regime %2$s, que exige %3$s. Destino preenchido e inválido é defeito de configuração, não pré-condição ausente: o lead sairia para um destino que não recebe.', 'f3base' ),
					$caminho,
					$regime,
					(string) $formatos[ $regime ]['exige']
				),
				'resumo' => sprintf(
					/* translators: %s: caminho da chave de destino. */
					__( 'destino inválido em %s (FALHA)', 'f3base' ),
					$caminho
				),
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::OK,
			'motivo' => sprintf(
				/* translators: 1: caminho da chave de destino, 2: regime, 3: formato exigido. */
				__( 'a chave %1$s está preenchida e o valor casa com o que o regime %2$s exige: %3$s.', 'f3base' ),
				$caminho,
				$regime,
				(string) $formatos[ $regime ]['exige']
			),
			'resumo' => __( 'destino configurado e no formato do regime', 'f3base' ),
		);
	}

	/**
	 * A referência lógica da PÁGINA de um regime de formulário, lida de
	 * `config/projeto.json` — o arquivo em que o bloco `formularios` mora.
	 *
	 * Função própria porque foi aqui que o defeito morou: o regime é lido de
	 * `F3Base_Imp_Projeto` chave a chave, e uma única chave — esta — era lida
	 * de `F3Base_Imp_Config`. Uma função com nome diz de que arquivo lê, e a
	 * bancada a exercita contra a configuração REAL do pacote.
	 *
	 * @param string $regime Regime declarado (`whatsapp` ou `cf7-email`).
	 * @param string $base   Caminho pontilhado da entrada (`formularios.<n>`).
	 * @return string Referência lógica, ou vazio.
	 */
	public static function pagina_ref_do_regime( string $regime, string $base ): string {
		return (string) F3Base_Imp_Projeto::obter(
			'whatsapp' === $regime ? $base . '.pagina_canonica_ref' : $base . '.pagina_ref',
			''
		);
	}

	/**
	 * Regimes de formulário declarados.
	 *
	 * Cada regime declara o conjunto fechado de variáveis que usa; a validação
	 * do conjunto é do schema. Aqui o implantador prova que o DESTINO privado
	 * está configurado, e emite nos dois ramos por regime.
	 *
	 * O INTERRUPTOR SUMIU NA 1.0.19. Havia `ativo` na entrada E o destino na
	 * configuração, e os dois podiam discordar — foi assim que o regime whatsapp
	 * ficava declarado ATIVO e BLOCKED por falta de destino na mesma execução, e
	 * que uma implantação que deu certo terminava dizendo que algo estava errado.
	 * Agora a condição é uma só: a presença do valor do destino.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_formularios(): array {
		$partes = array();
		$falhou = false;

		foreach ( F3Base_Imp_Projeto::lista( 'formularios' ) as $indice => $entrada ) {
			unset( $entrada );

			/*
			 * O conjunto fechado do regime é lido INTEIRO, ativo ou não: chave
			 * declarada que nenhuma linha lê é decoração, e o detector geral de
			 * consumidores não abre exceção para o regime que está dormindo.
			 */
			$base         = 'formularios.' . $indice;
			$id           = (string) F3Base_Imp_Projeto::obter( $base . '.id', '' );
			$regime       = (string) F3Base_Imp_Projeto::obter( $base . '.regime', '' );
			$destino      = (string) F3Base_Imp_Projeto::obter( $base . '.destino', '' );
			$criterio     = (string) F3Base_Imp_Projeto::obter( $base . '.criterio_lead', '' );
			$degradado    = (string) F3Base_Imp_Projeto::obter( $base . '.degradado', '' );
			$escopo       = (string) F3Base_Imp_Projeto::obter( $base . '.escopo', '' );
			$obrigatorios = array_map( 'strval', F3Base_Imp_Projeto::lista( $base . '.obrigatorios' ) );
			$confirmacao  = F3Base_Imp_Projeto::obter( $base . '.pagina_confirmacao', null );

			/*
			 * LIDA DO MESMO ARQUIVO QUE O RESTO DO REGIME — 2.1.0. Até a 2.0.0
			 * esta era a única chave do bloco lida por `F3Base_Imp_Config`
			 * (config/site.json), onde `formularios` não existe: o ponteiro
			 * voltava vazio, `por_na_pagina()` devolvia vazio em silêncio, e o
			 * formulário do regime cf7-email era criado e NÃO posto em página
			 * nenhuma — com a unidade fechando OK e "formulário #24 publicado".
			 * Medido na implantação de 2026-09-07. Vinha da 1.7.4.
			 */
			$pagina_ref = self::pagina_ref_do_regime( $regime, $base );

			$anexo = F3Base_Imp_Projeto::obter( $base . '.anexo', false );

			if ( is_array( $anexo ) ) {
				$anexo = array(
					'tipos'     => array_map( 'strval', F3Base_Imp_Projeto::lista( $base . '.anexo.tipos' ) ),
					'limite_mb' => (float) F3Base_Imp_Projeto::obter( $base . '.anexo.limite_mb', 0 ),
					'validacao' => (string) F3Base_Imp_Projeto::obter( $base . '.anexo.validacao', 'nenhuma' ),
				);
			}

			if ( is_array( $confirmacao ) ) {
				$confirmacao = array(
					'slug'    => (string) F3Base_Imp_Projeto::obter( $base . '.pagina_confirmacao.slug', '' ),
					'pai_ref' => F3Base_Imp_Projeto::obter( $base . '.pagina_confirmacao.pai_ref', null ),
				);
			}

			/*
			 * O PONTEIRO RESOLVE DENTRO DO PRÓPRIO ARQUIVO. `destino` guarda o
			 * caminho pontilhado de outra chave de `config/projeto.json` — a do
			 * WhatsApp, a da caixa de leads —, e é por isso que o bloco inteiro
			 * mora lá: partido entre dois arquivos, o ponteiro apontaria para um
			 * registro que já não existe inteiro, e a leitura devolveria vazio em
			 * silêncio — o regime fecharia N/A dizendo que falta preencher uma
			 * chave que está preenchida.
			 */
			$valor_destino = (string) F3Base_Imp_Projeto::obter( $destino, '' );
			$veredito      = self::veredito_destino( $regime, $destino, $valor_destino );
			$existe        = F3Base_Imp_Relatorio::NA !== $veredito['estado'];

			/*
			 * O REGIME `cf7-email` CRIA O FORMULÁRIO, e é aqui que ele deixa de
			 * ser declaração sem consequência. Antes, esta etapa só emitia uma
			 * linha dizendo que o regime existia — o formulário nunca era
			 * criado, e a caixa de leads guardava envios que não aconteciam.
			 *
			 * Ele NÃO depende do destino estar preenchido: o destinatário é
			 * derivado do e-mail administrativo do site, e a caixa declarada é
			 * um destinatário DIFERENTE quando alguém quiser um. Vazio não
			 * desliga formulário nenhum.
			 */
			if ( 'cf7-email' === $regime ) {
				$feito = F3Base_Imp_Formulario::aplicar(
					array(
						'id'                 => $id,
						'obrigatorios'       => $obrigatorios,
						'caixa_de_leads'     => (string) F3Base_Imp_Projeto::obter( $base . '.caixa_de_leads', '' ),
						'pagina_ref'         => $pagina_ref,
						'pagina_confirmacao' => $confirmacao,
					)
				);

				F3Base_Imp_Relatorio::emitir(
					$feito['estado'],
					'formulario.' . $id,
					$feito['motivo'],
					array(
						'evidencia' => 'teste-funcional',
						'fase'      => 'local',
						'tela'      => F3Base_Imp_Relatorio::OK === $feito['estado']
							? __( 'Formulário de contato criado e publicado na página.', 'f3base' )
							: $feito['resumo'],
					)
				);

				$falhou   = $falhou || F3Base_Imp_Relatorio::FALHA === $feito['estado'];
				$partes[] = $id . ': ' . $feito['resumo'];

				continue;
			}

			$contexto = sprintf(
				/* translators: 1: regime, 2: existência derivada do valor, 3: escopo, 4: página canônica, 5: critério de lead, 6: obrigatórios, 7: anexo, 8: confirmação, 9: degradado. */
				__( 'regime %1$s %2$s, escopo %3$s, página %4$s; critério de lead: %5$s; obrigatórios: %6$s; anexo: %7$s; página de confirmação: %8$s; comportamento degradado: %9$s.', 'f3base' ),
				$regime,
				$existe
					? __( 'EXISTE porque o destino está preenchido', 'f3base' )
					: __( 'NÃO existe porque o destino está vazio', 'f3base' ),
				$escopo,
				'' !== $pagina_ref ? $pagina_ref : __( 'não declarada', 'f3base' ),
				$criterio,
				array() === $obrigatorios ? __( 'nenhum', 'f3base' ) : implode( ', ', $obrigatorios ),
				false === $anexo ? __( 'não', 'f3base' ) : wp_json_encode( $anexo ),
				null === $confirmacao ? __( 'nenhuma (o regime não a tem)', 'f3base' ) : wp_json_encode( $confirmacao ),
				$degradado
			);

			/*
			 * O REGIME NÃO "DORME" MAIS. Ele fechava N/A quando a chave de
			 * destino estava vazia, e a linha existia só para dizer que nada
			 * tinha sido feito. Nada quebrava — o CTA já degrada sozinho para a
			 * página de contato quando não há número —, então a medição virou
			 * log, e o que o operador precisa fazer sai NOMEADO, em uma linha.
			 */
			$falta_destino = '' === trim( $valor_destino );

			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::FALHA === $veredito['estado'] ? F3Base_Imp_Relatorio::FALHA : F3Base_Imp_Relatorio::OK,
				'formulario.' . $id,
				$contexto . ' ' . $veredito['motivo'],
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
					'tela'      => $falta_destino ? '' : __( 'Botão de WhatsApp publicado com o número do projeto.', 'f3base' ),
					'operador'  => $falta_destino
						? sprintf(
							/* translators: 1: onde preencher, derivado da chave, 2: caminho da chave a preencher. */
							__( 'Preencher o número de WhatsApp %1$s (%2$s) para o botão de contato abrir a conversa. Sem ele o botão leva à página de contato.', 'f3base' ),
							F3Base_Imp_Residencia::onde_preencher( array( $destino ) ),
							$destino
						)
						: '',
				)
			);

			/*
			 * Só FALHA reprova a unidade. N/A não reprova nada e não pende de
			 * nada: regime que ninguém instanciou não é pré-condição ausente.
			 */
			$falhou   = $falhou || F3Base_Imp_Relatorio::FALHA === $veredito['estado'];
			$partes[] = $id . ': ' . $veredito['resumo'];
		}

		return array(
			'estado' => $falhou ? F3Base_Imp_Relatorio::FALHA : F3Base_Imp_Relatorio::OK,
			'rotulo' => 'formularios.regimes',
			'motivo' => array() === $partes ? __( 'nenhum formulário declarado.', 'f3base' ) : implode( ' | ', $partes ),
		);
	}

	/**
	 * A recorrência de queda quando a declarada não existe no agendador.
	 *
	 * Literal do NÚCLEO, e não deste pacote: `daily` é uma das recorrências que
	 * o WordPress registra sozinho, e é ela que a cadência usa quando a
	 * declarada não está disponível. Cair para nada seria deixar o site sem
	 * cadência nenhuma.
	 */
	public const RECORRENCIA_DE_QUEDA = 'daily';

	/**
	 * A tabela de recorrências do agendador, com as do `site-core` garantidas.
	 *
	 * POR QUE ESTA FUNÇÃO EXISTE, e o defeito que ela corrige. As recorrências
	 * `f3base_quinzenal` e `f3base_mensal` são registradas pelo módulo
	 * `cadencia-relatorio` do `site-core`, num filtro `cron_schedules` — e
	 * módulo INATIVO não registra hook nenhum. O módulo fica inativo enquanto
	 * `f3base_cadencia` não existir, e quem grava `f3base_cadencia` é esta
	 * etapa. Na primeira execução, portanto, o filtro nunca esteve registrado
	 * nesta requisição: `wp_get_schedules()` devolvia a tabela do núcleo, a
	 * recorrência declarada não estava lá, e o agendamento caía para `daily`
	 * com a configuração pedindo `mensal` — medido numa execução real.
	 *
	 * A FONTE CONTINUA SENDO UMA SÓ. Esta função não escreve intervalo nenhum:
	 * ela pede a tabela ao MÓDULO, que é quem a declara, quando ele está
	 * carregado e a tabela do agendador ainda não a tem. Copiar "quinze dias" e
	 * "trinta dias" para cá criaria a segunda fonte para o mesmo fato, que é o
	 * defeito que este pacote passa a release corrigindo.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private static function recorrencias_do_agendador(): array {
		$agendadas = wp_get_schedules();
		$agendadas = is_array( $agendadas ) ? $agendadas : array();

		if ( ! class_exists( 'F3Base_Modulo_Cadencia_Relatorio' ) ) {
			return $agendadas;
		}

		if ( isset( $agendadas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL ] ) ) {
			return $agendadas;
		}

		/*
		 * O FILTRO É REGISTRADO PARA ESTA REQUISIÇÃO, e não só consultado:
		 * `wp_schedule_event()` valida a recorrência contra `wp_get_schedules()`
		 * na hora de agendar, e conhecer o nome sem que o agendador o conheça
		 * faria o agendamento falhar em vez de acontecer.
		 */
		$modulo = new F3Base_Modulo_Cadencia_Relatorio();

		add_filter( 'cron_schedules', array( $modulo, 'registrar_recorrencias' ) ); // phpcs:ignore WordPress.WP.CronInterval.ChangeDetected

		$agendadas = wp_get_schedules();

		return is_array( $agendadas ) ? $agendadas : array();
	}

	/**
	 * A recorrência com que o evento está de fato agendado, ou vazio.
	 *
	 * @param string $hook Nome do evento.
	 * @return string
	 */
	private static function recorrencia_agendada( string $hook ): string {
		if ( ! function_exists( 'wp_get_scheduled_event' ) ) {
			return '';
		}

		$evento = wp_get_scheduled_event( $hook );

		return ( is_object( $evento ) && isset( $evento->schedule ) ) ? (string) $evento->schedule : '';
	}

	/**
	 * A decisão da recorrência da cadência. FUNÇÃO PURA.
	 *
	 * Três ações fechadas, e nenhuma delas é silenciosa:
	 *
	 * - `agendar` — não há evento, ou há e ele já está com a recorrência
	 *   declarada. O agendamento acontece com o que a configuração pede.
	 * - `reagendar` — o evento existe com a recorrência DE QUEDA e a declarada é
	 *   outra E existe agora no agendador. É a reparação da degradação que uma
	 *   execução anterior produziu; sem ela, a queda para `daily` sobrevivia a
	 *   toda reexecução, porque a etapa via o evento agendado e não olhava com o
	 *   quê. O alcance é estreito de propósito: qualquer outra recorrência no
	 *   evento é decisão de quem opera o site, e esta etapa não a desfaz.
	 * - `manter` — o evento existe com outra recorrência qualquer. Não é nossa
	 *   queda, e não é nossa para desfazer.
	 *
	 * A DEGRADAÇÃO CONTINUA NOMEADA. Quando a declarada não existe no agendador,
	 * a recorrência usada é a de queda e a mensagem diz a declarada, a usada, o
	 * intervalo LIDO do agendador e a causa provável.
	 *
	 * @param string                            $periodicidade Periodicidade declarada na configuração.
	 * @param array<string,array<string,mixed>> $agendadas     Tabela de recorrências do agendador.
	 * @param string                            $observada     Recorrência com que o evento está agendado, ou vazio.
	 * @param string                            $quinzenal     Nome da recorrência quinzenal, do site-core.
	 * @param string                            $mensal        Nome da recorrência mensal, do site-core.
	 * @return array{declarada:string,recorrencia:string,acao:string,degradacao:string}
	 */
	public static function veredito_da_recorrencia( string $periodicidade, array $agendadas, string $observada, string $quinzenal, string $mensal ): array {
		$recorrencias = array(
			'semanal'   => 'weekly',
			'quinzenal' => $quinzenal,
			'mensal'    => $mensal,
		);

		$declarada   = $recorrencias[ $periodicidade ] ?? 'weekly';
		$recorrencia = $declarada;
		$degradacao  = '';

		if ( ! isset( $agendadas[ $declarada ] ) ) {
			$recorrencia = self::RECORRENCIA_DE_QUEDA;

			/*
			 * O INTERVALO DA RECORRÊNCIA USADA É LIDO DO AGENDADOR, não digitado:
			 * escrever "de 1 dia" aqui seria afirmar sobre a tabela do núcleo sem
			 * consultá-la, e é o tipo de número que envelhece calado.
			 */
			$intervalo  = isset( $agendadas[ $recorrencia ]['interval'] ) ? (int) $agendadas[ $recorrencia ]['interval'] : 0;
			$degradacao = sprintf(
				/* translators: 1: periodicidade declarada, 2: recorrência declarada, 3: recorrência usada, 4: intervalo da usada, lido do agendador. */
				__( 'DEGRADAÇÃO NOMEADA: a periodicidade declarada é "%1$s", que pede a recorrência %2$s, e essa recorrência NÃO existia no agendador no momento deste agendamento. O evento foi agendado com %3$s, cujo intervalo lido do agendador é %4$s — frequência diferente da combinada, e maior. Quem registra %2$s é o módulo cadencia-relatorio do site-core; a causa provável é ele não estar ativo nesta requisição. Reexecute com o site-core ativo e o agendamento sai com a recorrência declarada.', 'f3base' ),
				$periodicidade,
				$declarada,
				$recorrencia,
				$intervalo > 0
					? sprintf(
						/* translators: %d: intervalo em segundos. */
						__( '%d segundo(s)', 'f3base' ),
						$intervalo
					)
					: __( 'não informado pelo agendador', 'f3base' )
			);
		}

		$acao = 'agendar';

		if ( '' !== $observada && $observada !== $recorrencia ) {
			$acao = ( self::RECORRENCIA_DE_QUEDA === $observada && isset( $agendadas[ $declarada ] ) )
				? 'reagendar'
				: 'manter';
		}

		return array(
			'declarada'   => $declarada,
			'recorrencia' => $recorrencia,
			'acao'        => $acao,
			'degradacao'  => $degradacao,
		);
	}

	/**
	 * VEREDITO PURO do mecanismo da cadência. O fato MEDIDO vale mais que a
	 * declaração — e é por isso que esta função existe separada da etapa.
	 *
	 * Até a 1.1.6 a regra era de uma linha só: a chave do mecanismo — hoje
	 * `mecanismo_de_cadencia`, em `config/projeto.json` — vazia fechava BLOCKED. A chave nasce vazia POR DESENHO, então o BLOCKED
	 * saía em toda execução, para sempre, sobre uma ausência que ninguém vai
	 * mudar e para a qual ninguém tem ação — o defeito do "aviso que sai
	 * sempre".
	 *
	 * A regra nova tem três ramos, e os três são estados fechados do contrato:
	 *
	 * - chave DECLARADA: **OK** nomeando o declarado, e o OBSERVADO continua
	 *   registrado ao lado, porque são fatos diferentes;
	 * - chave vazia com AGENDAMENTO OBSERVADO — o mesmo fato que
	 *   `cadencia.agendada` acabou de medir em OK ou WARN: **OK** nomeando o
	 *   mecanismo observado, que é o gatilho que o operador desabilita para
	 *   pausar. Chave vazia aqui significa "não há gatilho externo além do
	 *   WP-Cron", que é o padrão esperado e não uma falta;
	 * - chave vazia e NENHUM agendamento observado: **BLOCKED**, e só aqui.
	 *   Não existe gatilho nenhum a nomear, nem interno nem declarado, e o
	 *   relatório de entrega fica sem o que dizer a quem for pausar ou retomar.
	 *
	 * @param bool   $agendou   Há evento agendado para o hook.
	 * @param string $declarado Valor da chave do mecanismo, lido pela etapa.
	 * @param string $observado Mecanismo medido neste host.
	 * @param string $proxima   Próxima execução observada, já formatada, ou vazio.
	 * @param string $hook      Nome do hook do agendamento.
	 * @param string $chave     Caminho da chave de configuração, para a mensagem.
	 * @return array{estado:string,motivo:string,evidencia:string}
	 */
	public static function veredito_do_mecanismo( bool $agendou, string $declarado, string $observado, string $proxima, string $hook, string $chave ): array {
		if ( '' !== $declarado ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::OK,
				'evidencia' => 'leitura-de-volta',
				'motivo'      => sprintf(
					/* translators: 1: mecanismo declarado, 2: mecanismo observado, 3: situação do agendamento observado. */
					__( 'o mecanismo externo da cadência está DECLARADO: %1$s. É ele que sai no relatório de entrega como o gatilho a desabilitar na pausa e a reabilitar na retomada. E o OBSERVADO continua registrado ao lado, porque são fatos diferentes: %2$s%3$s', 'f3base' ),
					$declarado,
					$observado,
					$agendou
						? sprintf(
							/* translators: %s: data da próxima execução observada. */
							__( ', com próxima execução em %s.', 'f3base' ),
							$proxima
						)
						: __( ', que NÃO ficou agendado nesta execução — o que cadencia.agendada mediu e nomeou.', 'f3base' )
				),
			);
		}

		if ( $agendou ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::OK,
				'evidencia' => 'leitura-de-volta',
				'motivo'      => sprintf(
					/* translators: 1: mecanismo observado, 2: próxima execução, 3: caminho da chave, 4: onde a chave mora, derivado dela. */
					__( 'o gatilho da cadência está MEDIDO neste host e é ele que o relatório de entrega nomeia: %1$s, com próxima execução em %2$s. É este o gatilho que o operador desabilita para pausar a cadência e reabilita para retomá-la. %3$s está vazia %4$s, e vazia aqui NÃO é falta: significa "não há gatilho externo além do WP-Cron", que é o padrão desta base — o nome de um agendador de hospedagem só existe onde o projeto tiver um, e declará-lo é opcional. Preenchida, a chave passa a ser o nome que sai no relatório, e o observado continua registrado ao lado.', 'f3base' ),
					$observado,
					$proxima,
					$chave,
					F3Base_Imp_Residencia::onde_preencher( array( $chave ) )
				),
			);
		}

		return array(
			'estado'    => F3Base_Imp_Relatorio::BLOCKED,
			'evidencia' => 'pendencia-externa',
			'motivo'    => sprintf(
				/* translators: 1: caminho da chave, 2: mecanismo tentado, 3: nome do hook, 4: onde a chave mora, derivado dela. */
				__( 'não há gatilho NENHUM a nomear. O agendamento por %2$s NÃO ficou de pé nesta execução — nenhum evento para o hook %3$s — e %1$s está vazia, então não há mecanismo observado nem declarado. Sem os dois, o relatório de entrega não tem o que nomear para quem for pausar ou retomar a cadência, e a leitura de volta dos adaptadores não acontece em lugar nenhum. Saídas: reexecutar com o site-core ativo, para que o agendamento fique de pé, ou declarar em %1$s, %4$s, qual é o gatilho externo — agendador do host, cron real do servidor ou tarefa do lado do agente.', 'f3base' ),
				$chave,
				$observado,
				$hook,
				F3Base_Imp_Residencia::onde_preencher( array( $chave ) )
			),
		);
	}

	/**
	 * Agenda a cadência do modo somente-relatório.
	 *
	 * Cadência sem agendamento é lembrete. O agendamento é item de ENTREGA
	 * justamente porque ninguém o cria depois — e o mecanismo usado sai nomeado.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_cadencia(): array {
		$periodicidade = (string) F3Base_Imp_Decisoes::valor( 'cadencia_relatorio.periodicidade' );
		$apos          = (int) F3Base_Imp_Decisoes::valor( 'cadencia_relatorio.apos_n_ajustes' );
		/*
		 * A CHAVE QUE A MENSAGEM CITA É A MESMA QUE ESTA LINHA LÊ, e não era.
		 * Até a 1.7.0 a leitura era `mecanismo_de_cadencia` e a mensagem mandava
		 * preencher `cadencia_relatorio.mecanismo` — o nome que a chave tinha
		 * ANTES de migrar para `config/projeto.json`. O operador procurava, no
		 * arquivo certo, uma chave que não existe em arquivo nenhum. Uma
		 * variável só para os dois usos fecha a divergência por construção.
		 */
		$chave_do_mecanismo = 'mecanismo_de_cadencia';
		$declarado          = (string) F3Base_Imp_Projeto::obter( $chave_do_mecanismo, '' );
		$hook               = 'f3base_cadencia_relatorio';

		if ( 'nenhuma' === $periodicidade ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'cadencia.agendada',
				__( 'condição de aplicabilidade falsa: a configuração declara periodicidade "nenhuma".', 'f3base' ),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);

			/* Checagem condicional fecha N/A com a condição declarada, nunca some. */
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'cadencia.mecanismo_declarado',
				__( 'condição de aplicabilidade falsa: a configuração declara periodicidade "nenhuma", e sem cadência não há mecanismo externo a nomear.', 'f3base' ),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);

			return array(
				'estado' => F3Base_Imp_Relatorio::NA,
				'rotulo' => 'cadencia',
				'motivo' => __( 'periodicidade declarada como nenhuma: nada agendado.', 'f3base' ),
			);
		}

		/*
		 * AS RECORRÊNCIAS DECLARADAS SÃO AS DO `site-core`, e não as do núcleo.
		 * Até a 1.0.17 este mapa levava `quinzenal` para `weekly` — o DOBRO da
		 * frequência — e `mensal` para `monthly`, que não existe no WordPress e
		 * caía para `daily` logo abaixo, três linhas adiante, em silêncio. As
		 * duas degradações aconteciam sem nada no relatório.
		 *
		 * Quem registra `f3base_quinzenal` (quinze dias) e `f3base_mensal`
		 * (trinta) é o módulo `cadencia-relatorio` do `site-core`, que é o
		 * componente que sobrevive à autodesativação de quem agenda. O nome sai
		 * da CONSTANTE daquele módulo quando ele está carregado, e do PREFIXO
		 * TÉCNICO declarado quando não está — nunca de um literal preso a um
		 * prefixo que a renomeação de projeto trocaria.
		 */
		$prefixo   = (string) F3Base_Imp_Config::obter( 'site.prefixo_tecnico', '' );
		$quinzenal = class_exists( 'F3Base_Modulo_Cadencia_Relatorio' )
			? (string) F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_QUINZENAL
			: $prefixo . '_quinzenal';
		$mensal    = class_exists( 'F3Base_Modulo_Cadencia_Relatorio' )
			? (string) F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL
			: $prefixo . '_mensal';

		$agendadas = self::recorrencias_do_agendador();
		$observada = self::recorrencia_agendada( $hook );
		$veredito  = self::veredito_da_recorrencia( $periodicidade, $agendadas, $observada, $quinzenal, $mensal );

		$declarada   = $veredito['declarada'];
		$recorrencia = $veredito['recorrencia'];
		$degradacao  = $veredito['degradacao'];

		$mecanismo = sprintf(
			/* translators: 1: recorrência do WP-Cron, 2: nome do hook, 3: recorrência declarada. */
			__( 'WP-Cron, recorrência %1$s (declarada: %3$s), hook %2$s', 'f3base' ),
			$recorrencia,
			$hook,
			$declarada
		);

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'cadencia.agendada',
				sprintf(
					/* translators: 1: mecanismo, 2: degradação nomeada, quando houver. */
					__( 'modo simulação: agendaria a cadência por %1$s. %2$s', 'f3base' ),
					$mecanismo,
					'' !== $degradacao ? $degradacao : ''
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);

			/* Checagem condicional fecha N/A com a condição declarada, nunca some. */
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'cadencia.mecanismo_declarado',
				sprintf(
					/* translators: %s: caminho da chave. */
					__( 'condição de aplicabilidade falsa: modo simulação, nada é gravado e o valor de %s não é conferido nesta execução.', 'f3base' ),
					$chave_do_mecanismo
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);

			return array(
				'estado' => F3Base_Imp_Relatorio::NA,
				'rotulo' => 'cadencia',
				'motivo' => $mecanismo,
			);
		}

		/*
		 * A OPTION QUE LIGA O MÓDULO É GRAVADA ANTES DO AGENDAMENTO, e a ordem
		 * é a correção. `f3base_cadencia` é a option que o módulo
		 * `cadencia-relatorio` lê para decidir o próprio estado: sem ela o
		 * módulo fecha INATIVO, e módulo inativo não registra hook nenhum —
		 * inclusive o `cron_schedules` que cria `f3base_quinzenal` e
		 * `f3base_mensal`. Gravar depois de agendar é a ordem que produzia o
		 * defeito medido: o agendamento acontecia na ÚNICA execução em que a
		 * recorrência declarada ainda não podia existir.
		 */
		$resultado = F3Base_Imp_Gravador::gravar(
			'f3base_cadencia',
			array(
				'periodicidade'  => $periodicidade,
				'apos_n_ajustes' => $apos,
				'mecanismo'      => '' !== $declarado ? $declarado : $mecanismo,
				'hook'           => $hook,
			),
			array( 'autoload' => false )
		);

		$proxima = wp_next_scheduled( $hook );

		/*
		 * REAGENDAR É REPARAR A PRÓPRIA DEGRADAÇÃO, e só ela. Uma execução
		 * anterior deixou o evento em `daily` porque a recorrência declarada não
		 * existia naquele momento; agora ela existe. Sem este ramo a degradação
		 * era PERMANENTE — a etapa encontrava o evento agendado e não olhava com
		 * o quê —, e o próprio site-core fechava degradado pedindo uma
		 * reexecução que não mudava nada.
		 *
		 * O alcance é estreito por desenho: só troca quando a observada é a
		 * recorrência de queda declarada, a declarada é outra e a declarada
		 * EXISTE agora. Qualquer outra recorrência no evento é decisão de quem
		 * opera o site, e esta etapa não a desfaz.
		 */
		if ( 'reagendar' === $veredito['acao'] && false !== $proxima ) {
			wp_unschedule_event( (int) $proxima, $hook );
			$proxima = false;
		}

		if ( false === $proxima ) {
			$quando   = time() + DAY_IN_SECONDS;
			$agendado = wp_schedule_event( $quando, $recorrencia, $hook );

			if ( false !== $agendado && ! is_wp_error( $agendado ) ) {
				F3Base_Imp_Journal::registrar(
					F3Base_Imp_Journal::TIPO_CRON,
					$hook,
					null,
					array( 'recorrencia' => $recorrencia ),
					array(
						'acao' => 'cron.desagendar',
						'hook' => $hook,
						'args' => array(),
					)
				);
			}

			$proxima = wp_next_scheduled( $hook );
		}

		/*
		 * O GATILHO POR AJUSTES DEIXA DE SER PROMESSA SEM DONO. A linha antiga
		 * imprimia "gatilho alternativo: após N ajustes" sem dizer quem mantém o
		 * contador — e até a 1.0.17 ninguém mantinha: `apos_n_ajustes` era
		 * gravado numa option que nenhuma linha do pacote lia. Quem conta, hoje,
		 * é o módulo cadencia-relatorio do site-core, e é ele que dispara; este
		 * implantador só GRAVA o número, e se autodesativa depois.
		 */
		$gatilho = $apos > 0
			? sprintf(
				/* translators: 1: número de ajustes, 2: nome da option lida pelo site-core. */
				__( 'gatilho alternativo: após %1$d ajustes, o que vier antes. Quem conta os ajustes e dispara NÃO é este implantador — que se autodesativa — e sim o módulo cadencia-relatorio do site-core, que lê o número de %2$s e conta cada escrita em option gerenciada; as escritas da própria execução da cadência não contam.', 'f3base' ),
				$apos,
				'f3base_cadencia'
			)
			: __( 'gatilho alternativo por ajustes: DESLIGADO — cadencia_relatorio.apos_n_ajustes está em zero, e o site-core não conta nem dispara nada por essa via. A única via de disparo é a recorrência acima.', 'f3base' );

		/*
		 * O ESTADO SAI DA MEDIÇÃO, e são três fatos distintos: não agendou (o
		 * evento não existe — FALHA), agendou com recorrência DIFERENTE da
		 * declarada (a cadência existe e não é a combinada — WARN, com o achado
		 * adverso medido e nomeado), e agendou com a declarada (OK).
		 */
		$agendou   = false !== $proxima;
		$degradou  = '' !== $degradacao;
		$mensagens = array(
			F3Base_Imp_Relatorio::OK    => sprintf(
				/* translators: 1: mecanismo, 2: data da próxima execução, 3: gatilho por ajustes. */
				__( 'cadência do modo somente-relatório agendada com a recorrência DECLARADA — mecanismo: %1$s; próxima execução: %2$s; %3$s O README diz como pausar e como retomar.', 'f3base' ),
				'' !== $declarado ? $declarado : $mecanismo,
				$agendou ? (string) wp_date( 'Y-m-d H:i', (int) $proxima ) : '',
				$gatilho
			),
			F3Base_Imp_Relatorio::WARN  => sprintf(
				/* translators: 1: degradação nomeada, 2: data da próxima execução, 3: gatilho por ajustes. */
				__( 'a cadência FICOU agendada, e NÃO com a recorrência declarada. %1$s Próxima execução: %2$s. %3$s', 'f3base' ),
				$degradacao,
				$agendou ? (string) wp_date( 'Y-m-d H:i', (int) $proxima ) : '',
				$gatilho
			),
			F3Base_Imp_Relatorio::FALHA => sprintf(
				/* translators: %s: mecanismo tentado. */
				__( 'a cadência NÃO ficou agendada por %s: sem agendamento, a leitura de volta dos adaptadores não acontece em lugar nenhum e o plugin muda embaixo do site sem nada conferir.', 'f3base' ),
				$mecanismo
			),
		);

		$estado_medido = F3Base_Imp_Relatorio::FALHA;

		if ( $agendou ) {
			$estado_medido = $degradou ? F3Base_Imp_Relatorio::WARN : F3Base_Imp_Relatorio::OK;
		}

		$estado_da_agenda = F3Base_Imp_Relatorio::emitir(
			$estado_medido,
			'cadencia.agendada',
			$mensagens[ $estado_medido ],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		/*
		 * O MECANISMO DA CADÊNCIA: O FATO MEDIDO VALE MAIS QUE A DECLARAÇÃO.
		 *
		 * Até a 1.1.6 esta linha fechava BLOCKED sempre que a chave do mecanismo
		 * — hoje `mecanismo_de_cadencia` — estivesse vazia, e a chave nasce vazia
		 * POR DESENHO, no template e em todo projeto que não tenha um gatilho
		 * externo além do WP-Cron. O resultado era um BLOCKED em toda execução,
		 * para sempre, sobre uma ausência que ninguém vai mudar e para a qual
		 * ninguém tem ação: o defeito do "aviso que sai sempre", que este arquivo
		 * nomeia em vários comentários.
		 *
		 * O que a linha pergunta agora: **existe gatilho a nomear no relatório de
		 * entrega?** E a resposta tem duas fontes, nesta ordem:
		 *
		 * - o AGENDAMENTO OBSERVADO — o mesmo fato que `cadencia.agendada` acabou
		 *   de medir em OK ou WARN: há evento para o hook, com recorrência e
		 *   próxima execução conferidas. Chave vazia com agendamento observado
		 *   significa "não há gatilho externo além do WP-Cron", que é o padrão
		 *   esperado e não uma falta: a linha fecha OK nomeando o mecanismo
		 *   OBSERVADO, que é o que o operador desabilita para pausar;
		 * - a CHAVE DECLARADA, quando o projeto tem um gatilho de hospedagem. Ela
		 *   fecha OK nomeando o declarado, e o observado continua registrado ao
		 *   lado — as duas coisas são fatos diferentes e as duas saem.
		 *
		 * BLOCKED sobrou para o caso REAL: NÃO há agendamento observado E a chave
		 * está vazia. Aí não existe gatilho nenhum, nem interno nem declarado, e o
		 * relatório de entrega não tem o que nomear para quem for pausar ou
		 * retomar.
		 */
		$mecanismo_medido = self::veredito_do_mecanismo(
			$agendou,
			$declarado,
			$mecanismo,
			$agendou ? (string) wp_date( 'Y-m-d H:i', (int) $proxima ) : '',
			$hook,
			$chave_do_mecanismo
		);

		$meta_do_mecanismo = array(
			'evidencia' => (string) $mecanismo_medido['evidencia'],
			'fase'      => 'producao',
		);

		F3Base_Imp_Relatorio::emitir(
			(string) $mecanismo_medido['estado'],
			'cadencia.mecanismo_declarado',
			(string) $mecanismo_medido['motivo'],
			$meta_do_mecanismo
		);

		return array(
			'estado' => false !== $proxima ? $estado_da_agenda : F3Base_Imp_Relatorio::FALHA,
			'rotulo' => 'cadencia',
			'motivo' => $mecanismo . ' — ' . $resultado['motivo']
				. ( '' !== $degradacao ? ' ' . $degradacao : '' ),
		);
	}

	/**
	 * O conteúdo demonstrativo MEDIDO NO BANCO — e não na configuração.
	 *
	 * O DEFEITO ESTAVA MEDIDO E ERA PERMANENTE. `conteudo.demonstrativo` mora no
	 * `config/site.json`; sob a premissa desta operação o agente substitui o
	 * conteúdo PELO CANAL e nunca toca em `content/` nem no arquivo único. A
	 * flag, portanto, fica `true` para sempre — e o aviso de build continuava
	 * saindo depois de o template ter sumido inteiro do site. Aviso que sai
	 * sempre é aviso que ninguém lê.
	 *
	 * A pergunta passa a ser feita ao BANCO, pela marca que já viaja dentro de
	 * cada página publicada desde a 1.0.15, e a REGRA É COMPARTILHADA com o
	 * `site-core`: a mesma classe roda aqui e na cadência, carregada do arquivo
	 * de origem quando o plugin ainda não está na instalação. Duas cópias dela
	 * divergiriam na primeira condição acrescentada.
	 *
	 * A checagem de BUILD continua conferindo o pacote — ela responde "este
	 * pacote leva conteúdo de template?", que é outra pergunta e tem outro
	 * leitor.
	 *
	 * E O SEGUNDO DEFEITO PERMANENTE, medido em produção (2026-09-04): "7 de 9
	 * página(s) publicada(s) ainda carrega(m) a marca" — e as sete tinham sido
	 * publicadas por ESTA MESMA execução, minutos antes, porque publicar o
	 * conteúdo declarado é o que o implantador faz. A unidade `entrega` fechava
	 * WARN por ter cumprido o próprio desenho. Desde a 1.1.7 o veredito
	 * discrimina QUEM escreveu cada página marcada, e o conjunto das escritas
	 * sai do JOURNAL — o registro que o pacote já mantém de cada gravação desta
	 * execução —, nunca de uma lista escrita à mão.
	 *
	 * A regra continua sendo UMA e compartilhada com o `site-core`: lá a
	 * cadência chama `medir()` sem o conjunto, porque ninguém escreveu nada
	 * naquele momento, e toda página marcada volta a ser achado adverso. É
	 * exatamente ali que a pergunta vale — um mês depois, o texto do template
	 * ainda está no ar?
	 *
	 * @return void
	 */
	private static function conferir_conteudo_demonstrativo(): void {
		if ( ! F3Base_Imp_Plugins::carregar_regra_do_censo_demonstrativo() ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::BLOCKED,
				'conteudo.demonstrativo_no_site',
				__( 'pré-condição ausente: a regra compartilhada do censo de conteúdo demonstrativo não pôde ser carregada do arquivo de origem do site-core, e sem ela nada foi medido. Não ter medido não é o mesmo que não ter achado.', 'f3base' ),
				array(
					'evidencia' => 'pendencia-externa',
					'fase'      => 'local',
				)
			);

			return;
		}

		$censo = F3Base_Censo_Demonstrativo::medir(
			(string) F3Base_Imp_Config::obter( 'site.prefixo_tecnico', '' ),
			(bool) F3Base_Imp_Config::obter( 'conteudo.demonstrativo', false ),
			F3Base_Imp_Journal::ids_de_post_escritos()
		);

		F3Base_Imp_Relatorio::emitir(
			'WARN' === $censo['estado'] ? F3Base_Imp_Relatorio::WARN : F3Base_Imp_Relatorio::OK,
			'conteudo.demonstrativo_no_site',
			$censo['motivo'],
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);
	}

	/**
	 * AS PENDÊNCIAS DE FASE DO GATE DE ENTREGA, e a nota que as nomeia. PURA.
	 *
	 * Extraída na 1.1.6 porque ela precisava de PISO e não tinha como ter: o
	 * laço morava dentro de `etapa_entrega()`, que só roda com WordPress. A
	 * regra que ela executa é a única coisa que decide se o encerramento imprime
	 * "nenhuma pendência" ou nomeia alguma, e regra que não pode ser exercitada
	 * é regra que ninguém sabe se está certa.
	 *
	 * A REGRA, num lugar só: `F3Base_Imp_Fases::gate_de_fase_em_aberto()`. Linha
	 * de fase em OK respondeu; em N/A não se aplica aqui — e nenhuma das duas é
	 * pendência. BLOCKED, FALHA, WARN, WAIVED e estado ausente deixam o gate
	 * aberto e saem NOMEADOS.
	 *
	 * O PISO QUE ELA EXISTE PARA TER: uma linha em N/A ao lado de uma em
	 * BLOCKED **não pode** produzir "nenhuma pendência de fase em aberto". Essa
	 * contradição foi medida na 1.0.17 — a mesma linha do log dizia "Nenhuma
	 * pendência de fase em aberto" e "Pendência(s) de FASE dentro desta unidade
	 * — 1" —, e a 1.1.6 podia reabri-la por outro caminho ao tirar o N/A do
	 * conjunto.
	 *
	 * @param array<string,string> $estados Estado lido por nome de checagem.
	 * @param array<int,string>    $gates   Nomes com gate de fase nesta execução.
	 * @return array{pendencias:array<int,string>,nota:string}
	 */
	public static function nota_de_pendencias_de_fase( array $estados, array $gates ): array {
		$pendencias = array();

		foreach ( $gates as $gate_de_fase ) {
			$gate_de_fase = (string) $gate_de_fase;

			if ( F3Base_Imp_Fases::gate_de_fase_em_aberto( (string) ( $estados[ $gate_de_fase ] ?? '' ) ) ) {
				$pendencias[] = $gate_de_fase;
			}
		}

		if ( array() === $pendencias ) {
			return array(
				'pendencias' => $pendencias,
				'nota'       => __( 'Nenhuma pendência de fase em aberto: toda linha de gate de fase desta execução fechou OK (respondeu) ou N/A (a fase declarada não é a fase corrente, e aplicabilidade falsa não é pendência de ninguém).', 'f3base' ),
			);
		}

		return array(
			'pendencias' => $pendencias,
			'nota'       => sprintf(
				/* translators: %s: pendências de fase, pelo nome e com o estado. */
				__( 'Pendência(s) de FASE, nomeada(s) e fora do gate da autodesativação: %s. Linha de fase em N/A não entra nesta lista: ali a fase declarada não é a fase corrente, e não falta ação de ninguém.', 'f3base' ),
				implode( ', ', array_map(
					static fn( string $nome ): string => $nome . ' (' . ( '' !== (string) ( $estados[ $nome ] ?? '' ) ? (string) $estados[ $nome ] : __( 'sem estado lido', 'f3base' ) ) . ')',
					$pendencias
				) )
			),
		);
	}

	/**
	 * Entregáveis, canal MCP, consumidores e o que só a suíte mede.
	 *
	 * @param string $modo Modo.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_entrega( string $modo ): array {
		$estados = F3Base_Imp_Entrega::conferir();

		self::conferir_consumidores();
		self::conferir_wp_html_do_tema();
		self::conferir_versoes_declaradas();
		self::conferir_conteudo_demonstrativo();
		self::declarar_evidencia_importada();

		/*
		 * DOIS GATES, DUAS LISTAS. O que decide a autodesativação são os
		 * entregáveis do gate de APLICAÇÃO; a evidência importada da suíte
		 * externa entra pelo gate de FASE, sai nomeada e não proíbe nada. A
		 * varredura antiga era por prefixo `entrega.` e engolia as duas.
		 */
		$bloqueados = array();

		foreach ( F3Base_Imp_Entrega::entregaveis_do_gate_de_aplicacao() as $entregavel ) {
			if ( F3Base_Imp_Relatorio::BLOCKED === ( $estados[ $entregavel ] ?? '' ) ) {
				$bloqueados[] = $entregavel;
			}
		}

		$de_fase            = self::nota_de_pendencias_de_fase( $estados, F3Base_Imp_Entrega::gates_de_fase() );
		$pendencias_de_fase = $de_fase['pendencias'];
		$nota_de_fase       = $de_fase['nota'];

		unset( $modo );

		return array(
			'estado' => array() === $bloqueados ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::BLOCKED,
			'rotulo' => 'entrega',
			'motivo' => array() === $bloqueados
				? sprintf(
					/* translators: %s: nota sobre as pendências de fase. */
					__( 'todos os entregáveis do gate de aplicação fecharam sem BLOCKED e o canal foi conferido pelas rotas. %s', 'f3base' ),
					$nota_de_fase
				)
				: sprintf(
					/* translators: 1: entregáveis do gate de aplicação em BLOCKED, pelo nome, 2: nota sobre as pendências de fase. */
					__( 'entregáveis do gate de aplicação em %1$s. Enquanto houver um, a autodesativação fica proibida. %2$s', 'f3base' ),
					F3Base_Imp_Relatorio::nomes_em( F3Base_Imp_Relatorio::BLOCKED, $bloqueados ),
					$nota_de_fase
				),
		);
	}

	/**
	 * DIAGNÓSTICO: quais chaves ESTA execução leu. Nunca um veredito.
	 *
	 * O defeito medido na 1.0.7: uma checagem chamada
	 * `config.toda_chave_tem_consumidor` reprovou nomeando vinte chaves —
	 * `ambiente.url_canonica`, `orcamento_pagina.*`, `release.*`, `tema.fontes`
	 * e o resto — que TÊM consumidor. Quem as lê é a suíte, o site-core ou um
	 * caminho de execução que aquele lote não percorreu.
	 *
	 * Eram DUAS implementações com o mesmo nome medindo perguntas diferentes: o
	 * detector estático cruza toda chave contra TODO o código do pacote (e fecha
	 * OK); esta contagem cruza contra o que o implantador leu NESTA EXECUÇÃO. A
	 * duplicação de fonte de verdade que a 1.0.7 eliminou para os gates,
	 * reaparecendo aqui.
	 *
	 * A DECISÃO, dita por inteiro: **o veredito de "chave sem consumidor" é da
	 * suíte, e só dela** — `estatica.detector_chave_sem_consumidor`, com piso
	 * dos dois lados. Esta linha continua existindo porque a informação é útil,
	 * mas passa a se chamar pelo que mede e JAMAIS vira FALHA.
	 * `estatica.gate_fonte_unica` é o detector que impede a derivação de voltar
	 * para cá.
	 *
	 * O QUE MUDOU NA 1.0.15: ela também deixou de sair em WARN sempre. A
	 * contagem de chaves lidas não é achado — o texto sempre disse isso —, e o
	 * estado agora mede a única coisa adversa que dá para medir daqui: se o
	 * pacote afirma, em `consumidores_declarados`, que toda chave tem
	 * consumidor. Afirma: OK. Não afirma: WARN, nomeando a garantia que o
	 * relatório perde.
	 *
	 * @return void
	 */
	private static function conferir_consumidores(): void {
		$declarou    = (bool) F3Base_Imp_Config::obter( 'consumidores_declarados', false );
		$declaradas  = F3Base_Imp_Config::chaves_declaradas();
		$lidas       = F3Base_Imp_Config::chaves_lidas();
		$nao_lidas   = F3Base_Imp_Config::chaves_sem_consumidor();
		$dono        = implode( ', ', F3Base_Imp_Entrega::vereditos_da_suite() );

		$nota = $declarou
			? sprintf(
				/* translators: %s: nome da checagem da suíte que detém o veredito. */
				__( 'A configuração declara consumidores_declarados = true, e o veredito sobre chave sem consumidor é de %s, na suíte, que cruza contra TODO o código do pacote e tem piso dos dois lados.', 'f3base' ),
				$dono
			)
			: sprintf(
				/* translators: %s: nome da checagem da suíte que detém o veredito. */
				__( 'A configuração declara consumidores_declarados = false: o pacote não afirma que toda chave tem consumidor, e o cruzamento exigível continua sendo o de %s, na suíte.', 'f3base' ),
				$dono
			);

		/*
		 * A CONTAGEM NÃO É ACHADO. Chave não lida NESTE caminho de execução não
		 * é defeito — a própria mensagem diz isso —, e sair em WARN por causa
		 * dela era a linha se contradizendo. O que É medível e adverso aqui é
		 * outra coisa: se o pacote AFIRMA que toda chave tem consumidor. Com
		 * `consumidores_declarados = true` a afirmação existe e o cruzamento
		 * exigível é o da suíte, com piso — OK. Com `false` o pacote se recusa a
		 * afirmar, e o relatório perde uma garantia que ele costuma ter — WARN,
		 * nomeando o que se perde.
		 */
		if ( $declarou ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'config.chaves_lidas_nesta_execucao',
				sprintf(
					/* translators: 1: quantidade lida, 2: quantidade declarada, 3: chaves não lidas neste caminho, 4: nota sobre quem detém o veredito. */
					__( 'esta execução leu %1$d dos %2$d caminhos declarados na configuração. Chave NÃO lida aqui não é defeito: chave lida só pela suíte, só pelo site-core ou só em outro caminho de execução continua tendo consumidor — por isso esta contagem é detalhe de OK, e não aviso. Não lidas nesta execução: %3$s. %4$s', 'f3base' ),
					count( $lidas ),
					count( $declaradas ),
					array() === $nao_lidas ? __( 'nenhuma', 'f3base' ) : implode( ', ', $nao_lidas ),
					$nota
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'config.chaves_lidas_nesta_execucao',
				sprintf(
					/* translators: 1: quantidade lida, 2: quantidade declarada, 3: chaves não lidas neste caminho, 4: nota sobre quem detém o veredito. */
					__( 'a configuração declara consumidores_declarados = false: este pacote NÃO afirma que toda chave declarada tem consumidor, e quem lê o relatório perde essa garantia — chave órfã pode existir sem que nada aqui a acuse. Esta execução leu %1$d dos %2$d caminhos declarados; não lidas nesta execução: %3$s. %4$s', 'f3base' ),
					count( $lidas ),
					count( $declaradas ),
					array() === $nao_lidas ? __( 'nenhuma', 'f3base' ) : implode( ', ', $nao_lidas ),
					$nota
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		}
	}

	/**
	 * Todo bloco `wp:html` do tema instalado consta da lista declarada?
	 *
	 * @return void
	 */
	private static function conferir_wp_html_do_tema(): void {
		$declarados = array();

		foreach ( F3Base_Imp_Config::lista( 'tema.wp_html_excecoes' ) as $indice => $entrada ) {
			unset( $entrada );

			$arquivo = (string) F3Base_Imp_Config::obter( 'tema.wp_html_excecoes.' . $indice . '.arquivo', '' );
			$motivo  = (string) F3Base_Imp_Config::obter( 'tema.wp_html_excecoes.' . $indice . '.motivo', '' );

			if ( '' !== $arquivo && '' !== $motivo ) {
				$declarados[] = $arquivo;
			}
		}

		$raiz = get_stylesheet_directory();

		if ( ! is_dir( $raiz ) ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::BLOCKED,
				'tema.wp_html_declarado',
				__( 'pré-condição ausente: o diretório do tema ativo não está legível para a varredura.', 'f3base' ),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'local',
				)
			);

			return;
		}

		$fora     = array();
		$achados  = array();
		$iterador = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $raiz, FilesystemIterator::SKIP_DOTS ) );

		foreach ( $iterador as $arquivo ) {
			if ( ! $arquivo instanceof SplFileInfo || ! $arquivo->isFile() || 'html' !== strtolower( (string) $arquivo->getExtension() ) ) {
				continue;
			}

			$conteudo = (string) file_get_contents( (string) $arquivo->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- varredura estática local.

			if ( ! str_contains( $conteudo, 'wp:html' ) ) {
				continue;
			}

			$relativo  = ltrim( str_replace( array( '\\', $raiz ), array( '/', '' ), (string) $arquivo->getPathname() ), '/' );
			$achados[] = $relativo;

			if ( ! in_array( $relativo, $declarados, true ) ) {
				$fora[] = $relativo;
			}
		}

		F3Base_Imp_Relatorio::avaliar(
			array() === $fora,
			'tema.wp_html_declarado',
			sprintf(
				/* translators: 1: arquivos com wp:html, 2: arquivos declarados. */
				__( 'todo bloco wp:html do tema consta da lista declarada com motivo. Encontrados em: %1$s; declarados: %2$s.', 'f3base' ),
				array() === $achados ? __( 'nenhum arquivo', 'f3base' ) : implode( ', ', $achados ),
				array() === $declarados ? __( 'nenhum', 'f3base' ) : implode( ', ', $declarados )
			),
			sprintf(
				/* translators: %s: arquivos fora da lista. */
				__( 'bloco wp:html fora da lista de exceções declarada: %s. A lista existe para que cada exceção tenha motivo escrito; navegação nunca entra nela.', 'f3base' ),
				implode( ', ', $fora )
			),
			array(
				'evidencia' => 'analise-estatica',
				'fase'      => 'local',
			)
		);
	}

	/**
	 * Versões declaradas contra as observadas — diagnóstico, nunca gate.
	 *
	 * @return void
	 */
	private static function conferir_versoes_declaradas(): void {
		$tema_slug = (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' );

		/*
		 * O `site-core` NÃO TEM PAR AQUI, e a remoção é da 1.7.3.
		 *
		 * `release.versao_site_core` chamava exatamente as duas mesmas funções
		 * que `plugins.site_core_versao` — `versao_embarcada_do_site_core()` e
		 * `versao_instalada()` — e chegava a um veredito PRÓPRIO sobre o mesmo
		 * par de números. Medido em produção na 1.7.2, num site cujo catálogo
		 * publicava a 1.0.0 enquanto o pacote carregava a 1.0.1, o mesmo fato
		 * saiu duas vezes com severidades diferentes: `plugins.site_core_versao`
		 * em WARN e `release.versao_site_core` em FALHA. Duas linhas medindo a
		 * mesma coisa e discordando é o defeito que a decisão 17 fechou para os
		 * vereditos de canal, reaparecendo aqui.
		 *
		 * QUAL DAS DUAS MORREU, e por quê. Esta. A regra dela era `===`, e por
		 * isso ela acusava também o caso CORRETO — site com uma versão MAIS NOVA
		 * do que a reserva, que este pacote não rebaixa por desenho. A mensagem
		 * adversa dela afirmava duas coisas falsas para este par: que "a
		 * configuração declara" o número (ele sai do NOME do artefato resolvido,
		 * não de `config/site.json`) e que "é ele que o `?ver=` publica" (um
		 * plugin não publica `?ver=` nenhum; a frase é do par do TEMA, onde ela
		 * é verdadeira). E ela não tinha frase de tela nem saída para o
		 * operador. `plugins.site_core_versao` tem os quatro ramos, a causa
		 * escrita, a frase de tela e a saída — e mora na classe que É dona do
		 * fato, ao lado da instalação que o produziu.
		 *
		 * Os dois pares que ficam comparam DECLARADO contra OBSERVADO de
		 * verdade: os dois números declarados moram em `config/site.json`.
		 */
		$pares = array(
			'release.versao_tema'        => array(
				'declarada' => (string) F3Base_Imp_Config::obter( 'release.tema', '' ),
				'observada' => (string) wp_get_theme( $tema_slug )->get( 'Version' ),
			),
			'release.versao_implantador' => array(
				'declarada' => (string) F3Base_Imp_Config::obter( 'release.implantador', '' ),
				'observada' => f3base_imp_versao(),
			),
		);

		foreach ( $pares as $nome => $par ) {
			F3Base_Imp_Relatorio::condicional(
				'' !== $par['observada'],
				sprintf(
					/* translators: %s: nome da checagem. */
					__( 'o artefato de %s ainda não está instalado, então não há versão observada para comparar.', 'f3base' ),
					$nome
				),
				$par['declarada'] === $par['observada'],
				$nome,
				sprintf(
					/* translators: 1: versão declarada, 2: versão observada. */
					__( 'versão declarada %1$s confere com a observada %2$s.', 'f3base' ),
					$par['declarada'],
					$par['observada']
				),
				sprintf(
					/* translators: 1: versão declarada, 2: versão observada. */
					__( 'a configuração declara %1$s e o artefato instalado responde %2$s — o cabeçalho do arquivo é a fonte única, e é ele que o ?ver= publica.', 'f3base' ),
					$par['declarada'],
					$par['observada']
				),
				array(
					'evidencia' => 'leitura-de-volta',
					'fase'      => 'local',
				)
			);
		}

		$canonica = (string) F3Base_Imp_Config::obter( 'ambiente.url_canonica', '' );

		F3Base_Imp_Relatorio::condicional(
			'' !== $canonica,
			__( 'a configuração não declara URL canônica: nada a cruzar com home_url().', 'f3base' ),
			untrailingslashit( $canonica ) === untrailingslashit( home_url() ),
			'ambiente.url_canonica',
			sprintf(
				/* translators: %s: URL. */
				__( 'a URL canônica declarada confere com home_url(): %s.', 'f3base' ),
				home_url()
			),
			sprintf(
				/* translators: 1: URL declarada, 2: home_url observado. */
				__( 'a URL canônica declarada (%1$s) diverge de home_url() (%2$s). O cross-check é diagnóstico: nada aqui substitui home_url() na composição de URLs.', 'f3base' ),
				$canonica,
				home_url()
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		$prefixo = (string) F3Base_Imp_Config::obter( 'site.prefixo_tecnico', '' );
		$dominio = (string) F3Base_Imp_Config::obter( 'site.text_domain', '' );

		F3Base_Imp_Relatorio::avaliar(
			'' !== $prefixo && $dominio === F3BASE_IMP_TEXT_DOMAIN,
			'site.prefixo_tecnico',
			sprintf(
				/* translators: 1: prefixo técnico, 2: text domain. */
				__( 'prefixo técnico %1$s e text domain %2$s conferem com os do implantador em execução.', 'f3base' ),
				$prefixo,
				$dominio
			),
			sprintf(
				/* translators: 1: text domain declarado, 2: text domain em uso. */
				__( 'o text domain declarado (%1$s) diverge do usado pelo implantador (%2$s): strings traduzidas com dois domínios não aparecem juntas em lugar nenhum.', 'f3base' ),
				$dominio,
				F3BASE_IMP_TEXT_DOMAIN
			),
			array(
				'evidencia' => 'analise-estatica',
				'fase'      => 'build',
			)
		);

		/*
		 * "Política aplicada: ultima-da-fonte-oficial" É O RAMO BOM. O que pode
		 * estar adverso é a política NÃO estar declarada: sem ela, o instalador
		 * não tem critério e o gate de leitura de volta não tem contra o que
		 * comparar.
		 */
		$politica_versao    = trim( (string) F3Base_Imp_Decisoes::valor( 'plugins.politica_versao' ) );
		$politica_autoupdate = trim( (string) F3Base_Imp_Decisoes::valor( 'plugins.autoupdate' ) );
		$sem_politica        = array();

		if ( '' === $politica_versao ) {
			$sem_politica[] = __( 'plugins.politica_versao', 'f3base' );
		}

		if ( '' === $politica_autoupdate ) {
			$sem_politica[] = __( 'plugins.autoupdate', 'f3base' );
		}

		if ( array() === $sem_politica ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'plugins.politica_versao',
				sprintf(
					/* translators: 1: política de versão, 2: política de autoupdate. */
					__( 'Política de plugins: %1$s, atualização automática %2$s.', 'f3base' ),
					$politica_versao,
					$politica_autoupdate
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'plugins.politica_versao',
				sprintf(
					/* translators: 1: chaves de política vazias. */
					__( 'Política de plugins não declarada em %1$s: o instalador fica sem critério de versão e de atualização automática.', 'f3base' ),
					implode( ' e ', $sem_politica )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		}

		/*
		 * "Fontes auto-hospedadas: 0; fragmentos sincronizados: 0 (lista vazia é
		 * estado válido)" era a linha se contradizendo em voz alta: declarava o
		 * estado válido e saía em WARN por isso. Contar não é achado.
		 *
		 * O que É adverso, e agora decide o estado: declaração que aponta para
		 * arquivo que não existe. Fonte auto-hospedada declarada cujo arquivo
		 * não está no pacote não é servida — a página cai na fonte de sistema e
		 * ninguém percebe até alguém comparar duas telas.
		 */
		$fontes      = F3Base_Imp_Config::lista( 'tema.fontes' );
		$fragmentos  = F3Base_Imp_Config::lista( 'tema.fragmentos_sincronizados' );
		$sem_arquivo = array();

		foreach ( $fontes as $indice => $entrada ) {
			unset( $entrada );

			$familia = (string) F3Base_Imp_Config::obter( 'tema.fontes.' . $indice . '.familia', '' );
			$arquivo = (string) F3Base_Imp_Config::obter( 'tema.fontes.' . $indice . '.arquivo', '' );

			if ( '' === $arquivo || '' !== f3base_imp_caminho( $arquivo ) && is_file( f3base_imp_caminho( $arquivo ) ) ) {
				continue;
			}

			$sem_arquivo[] = sprintf(
				/* translators: 1: família declarada, 2: arquivo declarado. */
				__( '%1$s aponta para %2$s, que não existe no pacote', 'f3base' ),
				'' !== $familia ? $familia : __( '(família não declarada)', 'f3base' ),
				$arquivo
			);
		}

		if ( array() === $sem_arquivo ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'tema.declaracoes',
				sprintf(
					/* translators: 1: fontes declaradas, 2: fragmentos sincronizados. */
					__( 'fontes auto-hospedadas declaradas: %1$d, todas com arquivo presente no pacote; fragmentos sincronizados declarados: %2$d. Lista vazia é estado válido — fora dela, tudo expandido no conteúdo — e por isso a contagem é detalhe de OK, não aviso.', 'f3base' ),
					count( $fontes ),
					count( $fragmentos )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'tema.declaracoes',
				sprintf(
					/* translators: 1: quantidade sem arquivo, 2: cada uma nomeada, 3: fragmentos sincronizados. */
					__( '%1$d fonte(s) auto-hospedada(s) declarada(s) SEM o arquivo correspondente no pacote: %2$s. A página cai na fonte de sistema sem que nada quebre, e a diferença só aparece comparando duas telas. Fragmentos sincronizados declarados: %3$d.', 'f3base' ),
					count( $sem_arquivo ),
					implode( '; ', $sem_arquivo ),
					count( $fragmentos )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		}
	}

	/**
	 * Declara como BLOCKED o que este implantador não executa no host.
	 *
	 * Checagem de navegador, axe e inspeção visual entra como evidência
	 * importada da suíte externa; ausente, é BLOCKED — nunca "medido".
	 *
	 * @return void
	 */
	private static function declarar_evidencia_importada(): void {
		/*
		 * QUEM DECIDE O ESTADO É A REGRA, e não esta função. A fase desta linha
		 * é `campo` — peso, requisições e nós de DOM sobre tráfego REAL —, e a
		 * fase de uma execução no host é `producao`. Fora da fase dela, a
		 * condição "esta fase produz esta evidência" é falsa, e isso é N/A: não
		 * falta ação de ninguém no momento da implantação, falta a fase. Até a
		 * 1.1.5 ela era BLOCKED incondicional, e um BLOCKED que nunca pode
		 * fechar em execução nenhuma ensina o operador a ignorar a cor.
		 */
		$fase       = 'campo';
		$aplicavel  = F3Base_Imp_Fases::aplicabilidade( $fase, self::FASE_DA_EXECUCAO );

		$orcamento = sprintf(
			/* translators: 1: CSS, 2: JS próprio, 3: peso total, 4: requisições, 5: nós de DOM. */
			__( 'orçamento declarado — CSS %1$s KB, JS próprio %2$s KB, peso total %3$s KB, %4$d requisições, %5$d nós de DOM.', 'f3base' ),
			number_format_i18n( (float) F3Base_Imp_Decisoes::valor( 'orcamento_pagina.css_kb' ) ),
			number_format_i18n( (float) F3Base_Imp_Decisoes::valor( 'orcamento_pagina.js_proprio_kb' ) ),
			number_format_i18n( (float) F3Base_Imp_Decisoes::valor( 'orcamento_pagina.peso_total_kb' ) ),
			(int) F3Base_Imp_Decisoes::valor( 'orcamento_pagina.requisicoes' ),
			(int) F3Base_Imp_Decisoes::valor( 'orcamento_pagina.dom_nos' )
		);

		if ( $aplicavel['aplicavel'] ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::BLOCKED,
				'orcamento.medicao_de_pagina',
				sprintf(
					/* translators: 1: orçamento declarado, 2: fase corrente. */
					__( '%1$s A medição é de navegador e a fase %2$s é a fase corrente desta execução: a pré-condição está ausente aqui, e ela é de alguém.', 'f3base' ),
					$orcamento,
					self::FASE_DA_EXECUCAO
				),
				array(
					'evidencia' => 'pendencia-externa',
					'fase'      => $fase,
					'gate'      => 'fase',
				)
			);
			return;
		}

		F3Base_Imp_Relatorio::emitir(
			F3Base_Imp_Relatorio::NA,
			'orcamento.medicao_de_pagina',
			sprintf(
				/* translators: 1: orçamento declarado, 2: fase em que é medida, 3: fase corrente. */
				__( 'condição de aplicabilidade falsa: %1$s O consumo real é medido na fase %2$s — peso, requisições e nós de DOM sobre tráfego real, num navegador —, e esta execução é a fase %3$s. Não falta ação de ninguém aqui: falta a fase, e nenhuma implantação produz esse tipo de evidência. Quem cobra que a fase %2$s um dia rode é fases.registro_de_execucao, que a nomeia enquanto ela nunca tiver rodado.', 'f3base' ),
				$orcamento,
				$fase,
				self::FASE_DA_EXECUCAO
			),
			array(
				'evidencia' => 'analise-estatica',
				'fase'      => $fase,
				'gate'      => 'fase',
			)
		);
	}

	/**
	 * Emite a linha da coerência entre o que o relatório AFIRMA e o que ele FAZ.
	 *
	 * @return void
	 */
	private static function conferir_coerencia_do_gate_nao_somado(): void {
		$contraditorias = self::contradicao_de_gate_nao_somado( F3Base_Imp_Relatorio::linhas() );
		$de_fase        = F3Base_Imp_Entrega::gates_de_fase();

		F3Base_Imp_Relatorio::avaliar(
			array() === $contraditorias,
			'entrega.gate_de_fase_nao_derruba_estado',
			sprintf(
				/* translators: 1: quantidade de gates de fase desta execução, 2: os nomes. */
				__( 'nenhuma linha de gate de FASE fechou FALHA nesta execução, e por isso as duas afirmações do relatório continuam compatíveis: gate de fase não entra na condição da autodesativação, e nada que ele mediu derrubou o estado da aplicação. Escopo: os %1$d gate(s) de fase desta execução (%2$s). Toda FALHA derruba o estado, de qualquer gate — o que não pode existir é uma FALHA sobre a qual o relatório afirme que este host não produz a evidência.', 'f3base' ),
				count( $de_fase ),
				array() === $de_fase ? __( 'nenhum emissor declarou gate=fase nesta execução', 'f3base' ) : implode( ', ', $de_fase )
			),
			sprintf(
				/* translators: %s: as linhas contraditórias, pelo nome. */
				__( 'DEFEITO DO INSTRUMENTO: %s fechou FALHA declarando gate de FASE. O relatório afirma, sobre cada gate de fase, que a evidência é de algo que ESTE HOST NÃO PRODUZ e que ela não é somada ao gate da autodesativação — e ao mesmo tempo esta FALHA entra na contagem que derruba o estado da aplicação, que é a PRIMEIRA condição daquele gate. As duas coisas não podem ser verdade. A saída é classificar a linha pelo que ela é: se o host mede a evidência, o gate dela é relato (não decide, e a FALHA derruba o estado com a frase certa) ou aplicacao (decide e suspende o que depende dela); fase é só para evidência de navegador, de campo ou da suíte externa, e essa não fecha FALHA aqui.', 'f3base' ),
				implode( ', ', $contraditorias )
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
				'gate'      => 'relato',
			)
		);
	}

	/**
	 * Encerramento: estado final, carimbo de release e autodesativação.
	 *
	 * @param string $modo Modo.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_encerramento( string $modo ): array {
		/*
		 * CADA NÚMERO DIZ O QUE CONTA, e nenhuma comparação cruza escopos. A
		 * versão anterior comparava `falhas` (linhas do relatório) com
		 * `count( unidades() )` (unidades do plano) para decidir FALHA_PARCIAL:
		 * dois escopos, um `<`, e um estado de máquina decidido por uma
		 * comparação sem sentido. O gate continua sendo o das CHECAGENS — é
		 * qualquer linha em FALHA que impede o sucesso —, e a contagem de
		 * unidades entra no texto como o segundo escopo, nomeado.
		 */
		/*
		 * A COERÊNCIA DO INSTRUMENTO É MEDIDA ANTES DA CONTAGEM, e de propósito:
		 * se ela fechar FALHA, essa FALHA precisa entrar no número que decide o
		 * estado. Um instrumento que se contradiz não pode aprovar a execução
		 * que ele acabou de descrever.
		 */
		self::conferir_coerencia_do_gate_nao_somado();

		$checagens_falha = F3Base_Imp_Relatorio::checagens_em_falha();
		$escopos         = F3Base_Imp_Relatorio::escopos();

		/*
		 * CONTAGEM E NOMES SAEM JUNTOS. Esta linha imprimia "5 FALHA e 6
		 * BLOCKED" e mais nada; a tela mostrava UMA unidade em FALHA e o
		 * operador não tinha como saber quais eram as outras — elas rodaram
		 * dentro de unidades que fecharam OK. Agora o próprio log as nomeia.
		 */
		$nomes_de_checagens = F3Base_Imp_Relatorio::nomes_por_estado( 'checagens' );
		$nomes_de_unidades  = F3Base_Imp_Relatorio::nomes_por_estado( 'unidades' );

		/*
		 * CADA NÚMERO COLADO NO ESTADO QUE ELE CONTA. A linha da 1.0.17 imprimia
		 * "5 em FALHA: nenhum · BLOCKED: … · WARN: …": o 5 era FALHA MAIS
		 * BLOCKED, encostava no primeiro estado da string — e quem lê casa
		 * número com a primeira palavra — e a mesma string ainda listava WARN,
		 * que não estava nos cinco. O cliente já formatava certo na linha 2 do
		 * mesmo log, por `resumo_por_estado()`, com `ESTADO: N — nomes` por
		 * estado; é essa forma que passa a valer aqui, pelo mesmo formatador.
		 */
		$contagem_de_checagens = F3Base_Imp_Relatorio::contagem();
		$contagem_de_unidades  = F3Base_Imp_Relatorio::contagem_unidades();

		$diagnostico = sprintf(
			/* translators: 1: escopo das checagens, 2: contagem com nomes por estado das checagens, 3: escopo das unidades, 4: contagem com nomes por estado das unidades. */
			__( 'Contagens por escopo, medidas ANTES de esta unidade emitir a própria linha, cada número colado no estado que ele conta e cada estado com a LISTA DE NOMES — %1$s: %2$s; %3$s: %4$s. A contagem final de cada escopo, com os nomes, sai no rodapé do log.', 'f3base' ),
			(string) ( $escopos['checagens'] ?? '' ),
			F3Base_Imp_Relatorio::resumo_por_estado( $contagem_de_checagens, $nomes_de_checagens ),
			(string) ( $escopos['unidades'] ?? '' ),
			F3Base_Imp_Relatorio::resumo_por_estado( $contagem_de_unidades, $nomes_de_unidades )
		);

		if ( self::MODO_EXECUCAO !== $modo ) {
			/*
			 * O REGISTRO DE FASES SAI NOS DOIS RAMOS do encerramento. Ele responde
			 * "o que cada fase espera e quando ela rodou", e essa pergunta não muda
			 * de resposta porque a execução foi simulada: o modo que não grava nada
			 * é justamente aquele em que ninguém mede produção, e calar ali seria
			 * esconder a lacuna no relatório que existe para mostrá-la.
			 */
			self::registrar_fases();

			self::liberar_lock();

			return array(
				'estado' => F3Base_Imp_Relatorio::NA,
				'rotulo' => 'encerramento',
				'motivo' => sprintf(
					/* translators: 1: modo, 2: diagnóstico por escopo. */
					__( 'modo %1$s: nada foi gravado e a versão da release NÃO é carimbada. %2$s', 'f3base' ),
					$modo,
					$diagnostico
				),
			);
		}

		$estado = self::SUCESSO;

		if ( $checagens_falha > 0 ) {
			$estado = self::FALHA_PARCIAL;
		}

		if ( $checagens_falha > 0 && 0 === F3Base_Imp_Relatorio::contagem()[ F3Base_Imp_Relatorio::OK ] ) {
			$estado = self::FALHA;
		}

		self::definir_estado( $estado );

		/*
		 * O carimbo de versão aplicada avança APENAS em SUCESSO_APLICACAO. Um
		 * BLOCKED que não tocou em nada não mudou o site, e gravar a versão ali
		 * faria o contrato de caminho validar como homologada uma rota nunca
		 * exercitada.
		 */
		if ( self::SUCESSO === $estado ) {
			F3Base_Imp_Gravador::gravar( self::OPTION_RELEASE, (string) F3Base_Imp_Config::obter( 'release.identidade', '' ) );
		}

		/*
		 * O mapa é montado por NOME declarado, não por prefixo: são os dois
		 * gates — aplicação e fase — que precisam chegar separados a quem
		 * decide. Ler por prefixo `entrega.` era o que fundia os dois.
		 */
		$entregaveis = array();
		$do_gate     = array_merge(
			F3Base_Imp_Entrega::entregaveis_do_gate_de_aplicacao(),
			F3Base_Imp_Entrega::gates_de_fase()
		);

		foreach ( F3Base_Imp_Relatorio::linhas() as $linha ) {
			$nome = (string) $linha['nome'];

			if ( in_array( $nome, $do_gate, true ) ) {
				$entregaveis[ $nome ] = (string) $linha['estado'];
			}
		}

		/*
		 * OS VEREDITOS DE CANAL SÃO LIDOS DO REGISTRO DA EXECUÇÃO, e ele é a
		 * ÚNICA FONTE deles: quem deriva grava, e a promoção da unidade propaga
		 * o estado FINAL para o mesmo registro (`propagar_veredito_da_unidade()`,
		 * logo depois de `emitir_unidade()`). Este bloco não recalcula nenhum —
		 * era a segunda implementação do mesmo veredito, aqui, que fazia o
		 * encerramento contradizer a linha que a unidade `mcp` já tinha emitido
		 * no mesmo relatório, e era o registro pré-promoção que fazia o gate ler
		 * OK sobre uma linha impressa em BLOCKED.
		 */
		foreach ( F3Base_Imp_Entrega::gates_do_canal() as $gate ) {
			$entregaveis[ $gate ] = F3Base_Imp_Entrega::veredito_registrado( $gate )['estado'];
		}

		$decisao = F3Base_Imp_Entrega::pode_autodesativar( $estado, $entregaveis );

		F3Base_Imp_Relatorio::avaliar(
			$decisao['pode'],
			'entrega.autodesativacao',
			$decisao['motivo'],
			$decisao['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
				'gate'      => 'aplicacao',
			)
		);

		/*
		 * O REGISTRO DE FASES sai ANTES de persistir: ele conta as linhas desta
		 * execução, e a da autodesativação é uma delas.
		 */
		self::registrar_fases();

		F3Base_Imp_Relatorio::persistir(
			array(
				'estado_final'    => $estado,
				'autodesativacao' => $decisao['pode'],
			)
		);

		self::liberar_lock();

		if ( $decisao['pode'] ) {
			deactivate_plugins( array( plugin_basename( F3BASE_IMP_ARQUIVO ) ), true );
		}

		/*
		 * A TELA DO ENCERRAMENTO SÃO TRÊS LINHAS: o site está no ar em tal
		 * endereço, o painel fica em tal endereço, e daqui em diante quem muda
		 * o site é o agente pelo canal. O parágrafo com estado de máquina,
		 * contagens por escopo, eixo de convergência e justificativa da
		 * autodesativação continua inteiro — no log.
		 */
		F3Base_Imp_Relatorio::emitir(
			self::SUCESSO === $estado ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::FALHA,
			'entrega.site_no_ar',
			self::SUCESSO === $estado
				? sprintf(
					/* translators: 1: endereço do site, 2: endereço do painel. */
					__( 'Site publicado em %1$s. Painel em %2$s.', 'f3base' ),
					home_url( '/' ),
					admin_url()
				)
				: sprintf(
					/* translators: 1: estado da aplicação, 2: endereço do painel. */
					__( 'O site NÃO ficou pronto: a execução terminou em %1$s. O painel responde em %2$s, e o que falhou está nas linhas acima.', 'f3base' ),
					$estado,
					admin_url()
				),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
				'gate'      => 'relato',
				'tela'      => self::SUCESSO === $estado
					? sprintf(
						/* translators: %s: endereço do site. */
						__( 'O site está no ar em %s.', 'f3base' ),
						home_url( '/' )
					)
					: __( 'O site não ficou pronto nesta execução — veja acima o que não deu certo.', 'f3base' ),
			)
		);

		if ( self::SUCESSO === $estado ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'entrega.daqui_em_diante',
				__( 'Depois desta execução, o site é alterado pelo agente por MCP — tema, plugins e conteúdo.', 'f3base' ),
				array(
					'evidencia' => 'doc-externa',
					'fase'      => 'local',
					'gate'      => 'relato',
					'tela'      => sprintf(
						/* translators: %s: endereço do painel. */
						__( 'Para editar o site, o painel fica em %s. Daqui em diante as mudanças podem ser feitas pelo agente.', 'f3base' ),
						admin_url()
					),
				)
			);
		}

		return array(
			'estado' => self::SUCESSO === $estado ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::FALHA,
			'rotulo' => 'encerramento',
			'motivo' => sprintf(
				/* translators: 1: estado da máquina, 2: diagnóstico por escopo, 3: decisão de autodesativação, 4: texto do estado. */
				__( 'estado da aplicação: %1$s. %2$s %3$s %4$s', 'f3base' ),
				$estado,
				$diagnostico,
				$decisao['motivo'],
				self::texto_de_encerramento( $estado, (bool) $decisao['pode'] )
			),
		);
	}

		/**
	 * A MESMA REGRA, alcançável pela suíte.
	 *
	 * A regra é pura e precisa de piso: foi a ausência dele que deixou passar a
	 * suspensão por veredito agregado, e com ela um site inteiro sem instalação.
	 *
	 * @param array<int,array<string,mixed>> $internas Linhas internas da unidade.
	 * @return array{caiu:bool,estado:string,motivo:string}
	 */
	public static function fato_critico_caiu_publico( array $internas ): array {
		return self::fato_critico_caiu( $internas );
	}

/**
	 * ALGUM FATO CRÍTICO CAIU nesta unidade?
	 *
	 * Fato crítico é a linha que declara `gate` de APLICAÇÃO: ela responde
	 * "isto impede o site de funcionar?". Linha descritiva — inventário, censo,
	 * baseline, o que já existia, o que não foi tocado — não declara esse gate e
	 * não suspende nada, por mais adverso que seja o achado dela.
	 *
	 * @param array<int,array<string,mixed>> $internas Linhas internas da unidade.
	 * @return array{caiu:bool,estado:string,motivo:string}
	 */
	private static function fato_critico_caiu( array $internas ): array {
		$caidos = array();
		$estado = F3Base_Imp_Relatorio::BLOCKED;

		foreach ( $internas as $interna ) {
			if ( F3Base_Imp_Relatorio::GATE_APLICACAO !== (string) ( $interna['gate'] ?? '' ) ) {
				continue;
			}

			$estado_interno = (string) ( $interna['estado'] ?? '' );

			if ( ! in_array( $estado_interno, array( F3Base_Imp_Relatorio::FALHA, F3Base_Imp_Relatorio::BLOCKED ), true ) ) {
				continue;
			}

			$caidos[] = (string) ( $interna['nome'] ?? '' );
			$estado   = F3Base_Imp_Relatorio::estado_mais_severo( $estado, $estado_interno );
		}

		if ( array() === $caidos ) {
			return array(
				'caiu'   => false,
				'estado' => '',
				'motivo' => '',
			);
		}

		return array(
			'caiu'   => true,
			'estado' => $estado,
			'motivo' => sprintf(
				/* translators: %s: fatos críticos que caíram, nomeados. */
				__( 'O que segurou a execução: %s.', 'f3base' ),
				implode( ', ', $caidos )
			),
		);
	}

	/**
	 * A LINHA DA ETAPA NA TELA, em português comum.
	 *
	 * Uma linha por assunto, dizendo o que a etapa fez. Etapa que terminou bem
	 * e não tem nada a pedir some da tela quando não há nome para ela: o que
	 * interessa a quem lê é o que mudou no site, não a lista de rotinas que
	 * rodaram.
	 *
	 * @param array<string,mixed> $unidade Unidade do plano.
	 * @param string              $estado  Estado da unidade.
	 * @return string Frase curta, ou vazio para ficar só no log.
	 */
	private static function linha_de_tela_da_unidade( array $unidade, string $estado ): string {
		$nomes = array(
			'preflight'    => __( 'Ambiente do servidor conferido', 'f3base' ),
			'tema'         => __( 'Tema instalado e ativado', 'f3base' ),
			'site_core'    => __( 'Plugin do site instalado e ativado', 'f3base' ),
			'plugins'      => __( 'Plugins instalados', 'f3base' ),
			'conteudo'     => __( 'Páginas e posts publicados', 'f3base' ),
			'permalinks'   => __( 'Endereços das páginas configurados', 'f3base' ),
			'seo'          => __( 'SEO configurado', 'f3base' ),
			'formularios'  => __( 'Formulário de contato', 'f3base' ),
			'options'      => __( 'Configurações do site gravadas', 'f3base' ),
			'midia'        => __( 'Imagens enviadas', 'f3base' ),
			'cadencia'     => __( 'Relatório automático agendado', 'f3base' ),
			'mcp'          => __( 'Canal de manutenção pronto', 'f3base' ),
			'entrega'      => __( 'Entrega conferida', 'f3base' ),
			'wordpress'    => __( 'Ajustes do WordPress aplicados', 'f3base' ),
			'navegacao'    => __( 'Menu de navegação criado', 'f3base' ),
		);

		$chave = (string) ( $unidade['etapa'] ?? '' );

		if ( ! isset( $nomes[ $chave ] ) ) {
			return '';
		}

		if ( F3Base_Imp_Relatorio::OK === $estado ) {
			return $nomes[ $chave ] . '.';
		}

		if ( F3Base_Imp_Relatorio::FALHA === $estado ) {
			return self::falha_com_saida( $chave, $nomes[ $chave ] );
		}

		return '';
	}

	/**
	 * A LINHA DE FALHA DIZ O QUE QUEBROU E QUAL É A SAÍDA.
	 *
	 * "Não deu certo" é o defeito oposto ao parágrafo técnico: cabe numa linha e
	 * não serve para nada. Quem lê essa linha está lendo justamente porque a
	 * implantação falhou, e precisa de duas coisas — o que quebrou, e o que
	 * fazer agora. O diagnóstico inteiro continua no log.
	 *
	 * Cada etapa tem a sua saída porque as saídas são diferentes de verdade:
	 * plugin que não baixou se resolve tentando de novo, limite de servidor se
	 * resolve com a hospedagem, e valor errado se resolve no arquivo. Uma frase
	 * genérica para todas seria a mesma coisa que não dizer nada.
	 *
	 * Onde não há saída conhecida, a linha diz isso — e essa é a EXCEÇÃO, não o
	 * padrão: se ela virar a resposta de todas, o texto voltou a não servir.
	 *
	 * @param string $etapa Nome da etapa.
	 * @param string $nome  Nome da etapa em português.
	 * @return string
	 */
	private static function falha_com_saida( string $etapa, string $nome ): string {
		$saidas = array(
			'preflight'   => __( 'o servidor não atende ao mínimo que o site precisa. Fale com a hospedagem: os limites de memória, tempo e tamanho de upload estão no log.', 'f3base' ),
			'tema'        => __( 'o tema não ficou instalado. Rode a implantação de novo; se repetir, confira a permissão de escrita em wp-content/themes.', 'f3base' ),
			'site_core'   => __( 'o plugin do site não ficou instalado. Rode de novo; se repetir, confira a permissão de escrita em wp-content/plugins.', 'f3base' ),
			'plugins'     => __( 'algum plugin não foi instalado. Rode de novo — download costuma falhar por rede; se repetir, o log diz qual plugin e em que passo parou.', 'f3base' ),
			'conteudo'    => __( 'alguma página ou post não foi publicado. O log diz qual e por quê; rode de novo depois de corrigir.', 'f3base' ),
			'permalinks'  => __( 'os endereços das páginas não foram aplicados. Confira em Configurações › Links permanentes se o painel aceita a alteração.', 'f3base' ),
			'seo'         => __( 'a configuração de SEO não foi gravada. Confira se o plugin de SEO está ativo e rode de novo.', 'f3base' ),
			'formularios' => __( 'o formulário de contato não foi criado. Confira se o Contact Form 7 está ativo e rode de novo.', 'f3base' ),
			'options'     => __( 'as configurações do site não foram gravadas. Rode de novo; se repetir, o log diz qual configuração recusou a escrita.', 'f3base' ),
			'midia'       => __( 'alguma imagem não subiu. Confira a permissão de escrita em wp-content/uploads e o limite de upload do servidor.', 'f3base' ),
			'cadencia'    => __( 'o relatório automático não foi agendado. O site funciona sem ele. Confira se o WP-Cron está habilitado na hospedagem e rode de novo.', 'f3base' ),
			'mcp'         => __( 'o canal de manutenção não ficou pronto. Sem ele o site funciona, mas não pode ser alterado por agente; o log diz o que faltou.', 'f3base' ),
			'wordpress'   => __( 'algum ajuste do WordPress não foi aplicado. O log diz qual; rode de novo.', 'f3base' ),
			'navegacao'   => __( 'o menu não foi criado. Rode de novo; o menu também pode ser montado à mão em Aparência › Menus.', 'f3base' ),
			'entrega'     => __( 'a conferência final encontrou problema. Veja acima o que falhou e resolva antes de considerar o site entregue.', 'f3base' ),
		);

		if ( ! isset( $saidas[ $etapa ] ) ) {
			return sprintf(
				/* translators: %s: nome da etapa. */
				__( '%s falhou e não há saída conhecida para este caso: o log traz o diagnóstico completo.', 'f3base' ),
				$nome
			);
		}

		return sprintf(
			/* translators: 1: nome da etapa, 2: o que fazer. */
			__( '%1$s falhou — %2$s', 'f3base' ),
			$nome,
			$saidas[ $etapa ]
		);
	}

	/**
	 * O REGISTRO DE FASES desta execução: o que cada fase espera e quando rodou.
	 *
	 * O CONTRAPESO DA REGRA DE FASE, do lado do runtime. A 1.1.6 passou a fechar
	 * N/A — e não BLOCKED — a checagem cuja fase declarada não é a fase corrente,
	 * porque ali não falta ação de ninguém: falta a fase. Sozinha, essa regra
	 * esconde defeito, e o modo é conhecido: uma checagem que fica em N/A para
	 * sempre, porque ninguém nunca roda a fase dela, é aprovação por omissão —
	 * e "checagem que nunca falhou não é evidência" é regra da casa desde a
	 * 1.0.5. Por isso a regra veio em par com esta linha.
	 *
	 * ELA NÃO DECIDE NADA, e sai com `gate` de FASE por isso: um site que nunca
	 * exercita a fase de campo não tem defeito de aplicação, tem uma pergunta
	 * sem resposta. Promover a unidade de encerramento por causa dela fundiria
	 * outra vez as duas perguntas que a 1.0.18 separou — "o implantador
	 * terminou" e "o site está completo".
	 *
	 * A REGRA É A MESMA DOS DOIS LADOS, e é a mesma CLASSE: `F3Base_Imp_Fases`,
	 * que a suíte alcança por `suite/lib/sonda-fases.php`. O que muda é o
	 * registro durável — aqui a option, lá o arquivo —, porque os dois runtimes
	 * não se enxergam e cada um só pode responder pelas fases que ELE rodou.
	 *
	 * @return void
	 */
	private static function registrar_fases(): void {
		$anterior = get_option( self::OPTION_FASES, array() );
		$anterior = is_array( $anterior ) ? $anterior : array();

		/*
		 * O CARIMBO É O DIA, pela mesma regra dos dois lados — a razão inteira está
		 * em `F3Base_Imp_Fases::dia()`. Aqui o registro não entra em hash nenhum, e
		 * ainda assim a precisão é a mesma: "quando esta fase rodou pela última vez"
		 * é a MESMA pergunta nos dois emissores, e responder com granularidades
		 * diferentes daria duas respostas para um fato só.
		 */
		$agora    = F3Base_Imp_Fases::dia( time() );

		$registro = F3Base_Imp_Fases::registro( F3Base_Imp_Relatorio::linhas(), $anterior, $agora );
		$partes   = array();

		foreach ( F3Base_Imp_Fases::fases() as $fase ) {
			$dados   = (array) ( $registro['fases'][ $fase ] ?? array() );
			$esperam = array_map( 'strval', (array) ( $dados['esperam'] ?? array() ) );

			if ( array() === $esperam ) {
				$partes[] = sprintf(
					/* translators: %s: nome da fase. */
					__( '%s: nenhuma checagem desta execução espera esta fase — nada a cobrar, e por isso ela não é achado', 'f3base' ),
					$fase
				);
				continue;
			}

			/*
			 * FASE TODA-N/A SAI RELATADA, e não some: o que muda é que ela não
			 * vira WARN. Ninguém tem ação a tomar sobre uma fase cujas checagens
			 * este emissor não produz por desenho, e o registro continua dizendo
			 * quantas a esperam e que todas fecharam N/A.
			 */
			if ( ! empty( $dados['nao_aplicavel'] ) ) {
				$partes[] = sprintf(
					/* translators: 1: fase, 2: quantas esperam, 3: quando rodou, 4: os nomes. */
					__( '%1$s: NÃO APLICÁVEL a este host — %2$d checagem(ns) a esperam e TODAS fecharam N/A nesta execução, porque a evidência dela não é produzida aqui; última execução %3$s; esperam: %4$s', 'f3base' ),
					$fase,
					count( $esperam ),
					F3Base_Imp_Fases::quando( $dados ),
					implode( ', ', $esperam )
				);
				continue;
			}

			$partes[] = sprintf(
				/* translators: 1: fase, 2: quantas esperam, 3: quantas mediram, 4: quando rodou, 5: os nomes. */
				__( '%1$s: %2$d checagem(ns) esperam esta fase, %3$d medida(s) — última execução %4$s; esperam: %5$s', 'f3base' ),
				$fase,
				count( $esperam ),
				count( (array) ( $dados['medidas'] ?? array() ) ),
				F3Base_Imp_Fases::quando( $dados ),
				implode( ', ', $esperam )
			);
		}

		$cobrar = array_map( 'strval', (array) ( $registro['cobrar'] ?? array() ) );
		$corpo  = implode( ' | ', $partes );

		if ( array() !== $cobrar ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'fases.registro_de_execucao',
				sprintf(
					/* translators: 1: quantidade de fases, 2: fases nomeadas, 3: o registro por fase. */
					__( '%1$d fase(s) declarada(s) NUNCA foram executadas neste site e TINHAM o que medir aqui — %2$s. Uma linha que nunca fecha em estado medido não é evidência: o que falta é rodar a fase. Fase cujas checagens fecharam TODAS em N/A não entra nesta lista: ali não falta ação de ninguém, e ela sai relatada abaixo. %3$s', 'f3base' ),
					count( $cobrar ),
					implode( ', ', $cobrar ),
					$corpo
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'local',
					'gate'      => 'relato',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'fases.registro_de_execucao',
				sprintf(
					/* translators: %s: o registro por fase. */
					__( 'nenhuma fase declarada ficou por medir sem motivo: toda fase com checagem esperando já rodou pelo menos uma vez neste site, ou tem TODAS as suas checagens em N/A nesta execução — não aplicável a este emissor, por desenho, e não pendência de ninguém. %s', 'f3base' ),
					$corpo
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'local',
					'gate'      => 'relato',
				)
			);
		}

		F3Base_Imp_Gravador::persistir_infra(
			self::OPTION_FASES,
			F3Base_Imp_Fases::durar( $registro, $anterior, $agora, 'host' )
		);
	}

	/**
	 * A CONTRADIÇÃO PROIBIDA: linha declarada como NÃO somada que derruba o estado.
	 *
	 * O DEFEITO QUE ELA FECHA, medido em produção na 1.7.2. O relatório imprimia,
	 * na mesma tela, duas afirmações incompatíveis:
	 *
	 * - *"GATE(S) DE FASE em aberto, declarado(s) e NÃO somado(s) a este gate:
	 *   release.versao_site_core (FALHA) — evidência que este host não produz
	 *   trava o gate da fase, não a ferramenta."*
	 * - e, três linhas acima, `estado da aplicação: FALHA_PARCIAL` — derivado de
	 *   `checagens_em_falha()`, uma contagem CRUA que conta aquela mesma linha.
	 *
	 * A linha era declarada como não somada ao gate e era ela que derrubava o
	 * estado; e o estado é a PRIMEIRA condição do gate. Somando: ela decidia o
	 * gate por dentro, enquanto o texto dizia que não decidia.
	 *
	 * O QUE FOI MEDIDO ANTES DE DECIDIR, e é o que sustenta a saída escolhida.
	 * Varridas as emissões do runtime, TODA checagem de gate `fase` que podia
	 * fechar FALHA media evidência que este host PRODUZ — nenhuma delas era o
	 * caso em que a FALHA deveria deixar o estado de pé. Fazer
	 * `checagens_em_falha()` respeitar o gate não corrigiria caso nenhum de hoje
	 * e abriria um buraco para amanhã: uma FALHA de verdade que não derruba
	 * nada. Então a contagem continua crua — toda FALHA derruba o estado, de
	 * qualquer gate — e o que passou a ser proibido é a outra ponta: uma linha
	 * de gate `fase`, sobre a qual o relatório afirma que este host não produz a
	 * evidência, NÃO PODE fechar FALHA. Se fechar, o instrumento se contradiz, e
	 * é o instrumento que é acusado.
	 *
	 * `relato` não entra aqui, e por razão diferente de `fase`. Sobre ele o
	 * pacote não afirma que a evidência vem de outro lugar: o host mediu, a
	 * FALHA é reprovação de verdade, e derrubar o estado é o desfecho certo —
	 * a frase que ele imprime diz isso.
	 *
	 * Função PURA, para ter piso: a regra que só roda com WordPress é regra que
	 * ninguém sabe se está certa.
	 *
	 * E O PISO DELA NÃO BASTA, o que é a metade que a 1.7.3 quase entregou
	 * errada. Uma bancada que entrega linhas montadas por ela mesma prova que
	 * ESTA função reconhece a contradição; não prova que as DECLARAÇÕES do
	 * pacote não contêm nenhuma — é a bancada que mede o instrumento e não mede
	 * o objeto, a mesma forma que custou quatro releases na medição de
	 * comportamento. Quem mede o objeto é `estatica.gate_de_fase_sem_ramo_de_falha`,
	 * que varre as emissões escritas em `includes/` e cruza o gate declarado com
	 * os estados que cada emissão pode produzir. As duas existem, e não se
	 * repetem: o estático prova a invariante ANTES de o pacote sair, e esta cobre
	 * o que só se decide em execução.
	 *
	 * @param array<int,array<string,mixed>> $linhas Linhas emitidas nesta execução.
	 * @return string[] Nomes das linhas que se contradizem, vazio quando não há.
	 */
	public static function contradicao_de_gate_nao_somado( array $linhas ): array {
		$nomes = array();

		foreach ( $linhas as $linha ) {
			if ( F3Base_Imp_Relatorio::GATE_FASE !== (string) ( $linha['gate'] ?? '' ) ) {
				continue;
			}

			if ( F3Base_Imp_Relatorio::FALHA !== (string) ( $linha['estado'] ?? '' ) ) {
				continue;
			}

			$nome = (string) ( $linha['nome'] ?? '' );

			if ( '' !== $nome && ! in_array( $nome, $nomes, true ) ) {
				$nomes[] = $nome;
			}
		}

		return $nomes;
	}

	/**
	 * O parágrafo final do encerramento, CONDICIONAL AO ESTADO.
	 *
	 * O defeito medido na 1.0.10: a execução fechou em SUCESSO_APLICACAO, com
	 * zero FALHA, e a última frase do log foi "Em falha o implantador permanece
	 * ativo, preserva o log e oferece retomada idempotente e rollback das
	 * mutações reversíveis." — o parágrafo do ramo de FALHA impresso no ramo de
	 * SUCESSO. Ele não estava errado sobre o produto; estava errado sobre o que
	 * tinha acabado de acontecer, que é a única coisa que a linha de
	 * encerramento tem para dizer.
	 *
	 * No sucesso o texto diz o que DE FATO aconteceu — inclusive se o
	 * implantador se autodesativou — e para onde o operador vai a partir de
	 * agora: a tela do site-core e o canal MCP. Na falha, o texto da falha.
	 *
	 * @param string $estado        Estado da máquina.
	 * @param bool   $autodesativou A autodesativação foi executada.
	 * @return string
	 */
	public static function texto_de_encerramento( string $estado, bool $autodesativou ): string {
		if ( self::SUCESSO !== $estado ) {
			return __( 'O implantador PERMANECE ATIVO: preserva o log, oferece retomada idempotente a partir do checkpoint e rollback das mutações reversíveis pelo journal. Corrija o que está nomeado acima e execute de novo — a retomada não repete o que já foi aplicado.', 'f3base' );
		}

		if ( $autodesativou ) {
			return __( 'A aplicação terminou e o implantador SE AUTODESATIVOU: ele não roda mais, e reativá-lo pela tela de plugins é o que o traz de volta se houver o que reaplicar. O log desta execução fica preservado. Daqui em diante o site é operado pelo canal MCP e pela tela do site-core (estado dos módulos, options operáveis e atividade): o implantador é executado uma vez por site, e o que ele deixou por preencher — dado que só o operador tem — é ajustado pelo canal, sem nova execução.', 'f3base' );
		}

		return __( 'A aplicação terminou em sucesso e o implantador CONTINUA ATIVO — a autodesativação foi recusada pelo motivo nomeado acima, e não por falha da aplicação. O log fica preservado. A operação do site já é pela tela do site-core e pelo canal MCP; resolva o que segurou a autodesativação e execute de novo para que o implantador saia de cena.', 'f3base' );
	}

	/* ------------------------------------------------------------------ *
	 * Lock, checkpoint e estado
	 * ------------------------------------------------------------------ */

	/**
	 * Instante em que um lock passa a ser considerado ABANDONADO.
	 *
	 * A tomada automática acontece quando `agora - heartbeat > TTL`; o primeiro
	 * segundo em que isso é verdade é `heartbeat + TTL + 1`. O número existe
	 * porque o operador precisa saber QUANTO ESPERAR — dizer só "TTL 90s" o
	 * deixa contando de cabeça a partir de um heartbeat que ele não viu.
	 *
	 * @param int $heartbeat Epoch do último heartbeat.
	 * @return int Epoch a partir do qual o lock é assumível.
	 */
	public static function lock_abandonado_em( int $heartbeat ): int {
		return $heartbeat + self::LOCK_TTL + 1;
	}

	/**
	 * Adquire ou renova o lock com heartbeat e fencing token.
	 *
	 * A rejeição devolve os FATOS, não só a frase: dono, idade do heartbeat, TTL
	 * e o instante em que o lock passa a ser assumível. Quem os imprime é a
	 * resposta do lote e o cliente, cada um uma vez — a 1.0.15 mandava só a
	 * frase, o cliente tratava a rejeição como se fosse resultado de unidade e
	 * repetia a MESMA linha 163 vezes até o TTL vencer.
	 *
	 * @param string $execucao Identificador da execução.
	 * @return array{ok:bool,motivo:string,fencing:int,dono:string,heartbeat:int,idade:int,ttl:int,abandonado_em:int}
	 */
	public static function adquirir_lock( string $execucao ): array {
		$agora = time();
		$atual = get_option( self::OPTION_LOCK, null );

		$adquirido = array(
			'ok'            => true,
			'motivo'        => '',
			'fencing'       => 0,
			'dono'          => $execucao,
			'heartbeat'     => $agora,
			'idade'         => 0,
			'ttl'           => self::LOCK_TTL,
			'abandonado_em' => self::lock_abandonado_em( $agora ),
		);

		if ( ! is_array( $atual ) ) {
			$novo = array(
				'execucao'  => $execucao,
				'fencing'   => 1,
				'heartbeat' => $agora,
			);

			if ( F3Base_Imp_Gravador::criar_atomico( self::OPTION_LOCK, $novo ) ) {
				return array_merge( $adquirido, array( 'fencing' => 1 ) );
			}

			$atual = get_option( self::OPTION_LOCK, null );
		}

		if ( ! is_array( $atual ) ) {
			return array(
				'ok'            => false,
				'motivo'        => __( 'não foi possível ler nem criar o lock da execução.', 'f3base' ),
				'fencing'       => 0,
				'dono'          => '',
				'heartbeat'     => 0,
				'idade'         => 0,
				'ttl'           => self::LOCK_TTL,
				'abandonado_em' => 0,
			);
		}

		$dono      = isset( $atual['execucao'] ) ? (string) $atual['execucao'] : '';
		$fencing   = isset( $atual['fencing'] ) ? (int) $atual['fencing'] : 0;
		$heartbeat = isset( $atual['heartbeat'] ) ? (int) $atual['heartbeat'] : 0;

		if ( $dono === $execucao ) {
			$renovado = $atual;
			$renovado['heartbeat'] = $agora;

			/* Renovação ATÔMICA: condicional ao valor observado, não ao tempo. */
			F3Base_Imp_Gravador::trocar_atomico( self::OPTION_LOCK, $atual, $renovado );

			return array_merge( $adquirido, array( 'fencing' => $fencing ) );
		}

		if ( $agora - $heartbeat > self::LOCK_TTL ) {
			$tomado = array(
				'execucao'  => $execucao,
				'fencing'   => $fencing + 1,
				'heartbeat' => $agora,
			);

			if ( F3Base_Imp_Gravador::trocar_atomico( self::OPTION_LOCK, $atual, $tomado ) ) {
				return array_merge( $adquirido, array( 'fencing' => $fencing + 1 ) );
			}
		}

		return array(
			'ok'            => false,
			'motivo'        => sprintf(
				/* translators: 1: execução dona do lock, 2: segundos desde o último heartbeat, 3: TTL, 4: horário em que o lock passa a ser assumível. */
				__( 'execução concorrente rejeitada: o lock pertence a %1$s, com heartbeat há %2$d segundos (TTL %3$ds). Este lote NÃO rodou e nada foi medido. O lock passa a ser considerado abandonado às %4$s: a partir daí basta executar de novo, e a tomada é automática — não há passo manual. Duas execuções simultâneas gravariam por cima uma da outra.', 'f3base' ),
				$dono,
				$agora - $heartbeat,
				self::LOCK_TTL,
				wp_date( 'Y-m-d H:i:s', self::lock_abandonado_em( $heartbeat ) )
			),
			'fencing'       => $fencing,
			'dono'          => $dono,
			'heartbeat'     => $heartbeat,
			'idade'         => $agora - $heartbeat,
			'ttl'           => self::LOCK_TTL,
			'abandonado_em' => self::lock_abandonado_em( $heartbeat ),
		);
	}

	/**
	 * Libera o lock desta execução.
	 *
	 * @return void
	 */
	public static function liberar_lock(): void {
		F3Base_Imp_Gravador::remover_infra( self::OPTION_LOCK );
	}

	/**
	 * Confere se a retomada é legítima.
	 *
	 * @param string $execucao Execução.
	 * @param int    $indice   Índice pedido.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function conferir_retomada( string $execucao, int $indice ): array {
		$checkpoint = get_option( self::OPTION_CHECKPOINT, null );

		if ( ! is_array( $checkpoint ) || 0 === $indice ) {
			return array(
				'ok'     => true,
				'motivo' => '',
			);
		}

		$release_atual = (string) F3Base_Imp_Config::obter( 'release.identidade', '' );
		$hash_atual    = F3Base_Imp_Config::hash();

		$release_ck = isset( $checkpoint['release'] ) ? (string) $checkpoint['release'] : '';
		$hash_ck    = isset( $checkpoint['config_hash'] ) ? (string) $checkpoint['config_hash'] : '';

		if ( $release_ck !== $release_atual || $hash_ck !== $hash_atual ) {
			return array(
				'ok'     => false,
				'motivo' => sprintf(
					/* translators: 1: release do checkpoint, 2: release atual, 3: hash do checkpoint, 4: hash atual. */
					__( 'retomada recusada: o checkpoint é da release %1$s com config %3$s e esta execução é da release %2$s com config %4$s. Retomada só com a mesma release e o mesmo hash de configuração — divergiu, é rollback ou abandono explícito.', 'f3base' ),
					$release_ck,
					$release_atual,
					substr( $hash_ck, 0, 12 ),
					substr( $hash_atual, 0, 12 )
				),
			);
		}

		$execucao_ck = isset( $checkpoint['execucao'] ) ? (string) $checkpoint['execucao'] : '';
		$fencing_ck  = isset( $checkpoint['fencing'] ) ? (int) $checkpoint['fencing'] : 0;
		$lock        = get_option( self::OPTION_LOCK, array() );
		$fencing_ok  = is_array( $lock ) && isset( $lock['fencing'] ) ? (int) $lock['fencing'] : 0;

		if ( $execucao_ck === $execucao && $fencing_ck > $fencing_ok ) {
			return array(
				'ok'     => false,
				'motivo' => sprintf(
					/* translators: 1: fencing do checkpoint, 2: fencing do lock. */
					__( 'fencing token vencido: o checkpoint traz %1$d e o lock vigente traz %2$d. Esta execução acordou depois de outra ter assumido, e escrever agora seria gravar por cima do trabalho novo.', 'f3base' ),
					$fencing_ck,
					$fencing_ok
				),
			);
		}

		return array(
			'ok'     => true,
			'motivo' => '',
		);
	}

	/**
	 * Grava o checkpoint DEPOIS da leitura de volta da unidade.
	 *
	 * @param string $execucao Execução.
	 * @param string $modo     Modo.
	 * @param string $etapa    Etapa.
	 * @param int    $indice   Índice da unidade concluída.
	 * @param string $estado   Estado da unidade.
	 * @return bool
	 */
	private static function gravar_checkpoint( string $execucao, string $modo, string $etapa, int $indice, string $estado ): bool {
		$lock    = get_option( self::OPTION_LOCK, array() );
		$fencing = is_array( $lock ) && isset( $lock['fencing'] ) ? (int) $lock['fencing'] : 0;

		F3Base_Imp_Gravador::persistir_infra(
			self::OPTION_CHECKPOINT,
			array(
				'execucao'    => $execucao,
				'release'     => (string) F3Base_Imp_Config::obter( 'release.identidade', '' ),
				'config_hash' => F3Base_Imp_Config::hash(),
				'modo'        => $modo,
				'etapa'       => $etapa,
				'unidade'     => $indice,
				'estado'      => $estado,
				'fencing'     => $fencing,
				'em'          => time(),
			)
		);

		$lido = get_option( self::OPTION_CHECKPOINT, array() );

		return is_array( $lido ) && isset( $lido['unidade'] ) && (int) $lido['unidade'] === $indice;
	}

	/**
	 * Define o estado da máquina de aplicação.
	 *
	 * @param string $estado Estado.
	 * @return void
	 */
	public static function definir_estado( string $estado ): void {
		if ( ! in_array( $estado, self::estados(), true ) ) {
			return;
		}

		F3Base_Imp_Gravador::persistir_infra( self::OPTION_ESTADO, $estado );
	}

	/**
	 * Reverte as mutações reversíveis desta execução.
	 *
	 * @return array<string,mixed>
	 */
	public static function reverter(): array {
		$resultado = F3Base_Imp_Journal::reverter();

		self::definir_estado( self::REVERTIDO );

		F3Base_Imp_Relatorio::emitir(
			array() === $resultado['falhas'] ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::FALHA,
			'rollback.journal',
			sprintf(
				/* translators: 1: quantidade revertida, 2: falhas, 3: irreversíveis declarados. */
				__( '%1$d mutação(ões) revertidas pelo journal. Falhas de reversão: %2$s. Fora da promessa de rollback, por declaração: %3$s.', 'f3base' ),
				(int) $resultado['revertidas'],
				array() === $resultado['falhas'] ? __( 'nenhuma', 'f3base' ) : implode( ' | ', $resultado['falhas'] ),
				array() === $resultado['irreversiveis'] ? __( 'nenhuma', 'f3base' ) : implode( ' | ', $resultado['irreversiveis'] )
			),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		F3Base_Imp_Relatorio::persistir();

		return $resultado;
	}

	/* ------------------------------------------------------------------ *
	 * Resposta do endpoint
	 * ------------------------------------------------------------------ */

	/**
	 * Normaliza o retorno de uma classe de aplicação.
	 *
	 * @param array<string,mixed> $resultado Resultado.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function normalizar( array $resultado ): array {
		return array(
			'estado' => isset( $resultado['estado'] ) ? (string) $resultado['estado'] : F3Base_Imp_Relatorio::FALHA,
			'rotulo' => isset( $resultado['rotulo'] ) ? (string) $resultado['rotulo'] : 'lote',
			'motivo' => isset( $resultado['motivo'] ) ? (string) $resultado['motivo'] : '',
		);
	}

	/**
	 * Executa uma etapa de SEO com o gate estrutural do plugin.
	 *
	 * Pré-condição ausente é BLOCKED, nunca FALHA: relatório que grita FALHA por
	 * ausência de terceiro treina o leitor a ignorar FALHA.
	 *
	 * @param string   $rotulo   Nome da checagem.
	 * @param callable $callback Etapa.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function com_plugin_de_seo( string $rotulo, callable $callback ): array {
		if ( ! F3Base_Imp_Seo::plugin_ativo() ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'rotulo' => $rotulo,
				'motivo' => sprintf(
					/* translators: %s: slug do plugin. */
					__( 'pré-condição ausente: o plugin %s não está ativo, e as options que esta etapa grava são dele. BLOCKED, nunca FALHA.', 'f3base' ),
					F3Base_Imp_Seo::slug()
				),
			);
		}

		return self::normalizar( (array) call_user_func( $callback ) );
	}

	/**
	 * Rede de fatal: responde JSON no fim do corpo mesmo depois do erro do core.
	 *
	 * @return void
	 */
	public static function rede_de_fatal(): void {
		$erro = error_get_last();

		if ( null === $erro || ! in_array( (int) $erro['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR ), true ) ) {
			return;
		}

		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}

		$carga = array(
			'ok'     => false,
			'estado' => F3Base_Imp_Relatorio::FALHA,
			'fatal'  => array(
				'tipo'     => (int) $erro['type'],
				'mensagem' => (string) $erro['message'],
				'arquivo'  => (string) $erro['file'],
				'linha'    => (int) $erro['line'],
			),
			'limites' => array(
				'memory_limit'       => (string) ini_get( 'memory_limit' ),
				'max_execution_time' => (string) ini_get( 'max_execution_time' ),
				'memoria_pico'       => memory_get_peak_usage( true ),
			),
			'motivo' => __( 'erro fatal durante o lote. O log da execução foi preservado e a retomada continua do último checkpoint válido.', 'f3base' ),
		);

		$json = wp_json_encode( $carga );

		echo "\n" . self::SENTINELA . "\n" . ( is_string( $json ) ? $json : '{}' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON serializado, com Content-Type próprio.
	}

	/**
	 * Responde JSON e encerra.
	 *
	 * `wp_send_json()` NÃO limpa o buffer: qualquer saída inesperada iria junto
	 * no corpo. Aqui o buffer é capturado, mandado ao log e descartado — e o
	 * JSON sai no FIM, precedido da sentinela.
	 *
	 * @param array<string,mixed> $carga  Carga.
	 * @param int                 $codigo Código HTTP.
	 * @return void
	 */
	private static function responder( array $carga, int $codigo = 200 ): void {
		$ruido = '';

		while ( ob_get_level() > 0 ) {
			$ruido .= (string) ob_get_clean();
		}

		if ( '' !== trim( $ruido ) ) {
			$carga['ruido_bytes'] = strlen( $ruido );
			error_log( '[f3base-implantador] saída inesperada no lote: ' . substr( $ruido, 0, 2000 ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- ruído vai ao log, nunca ao corpo.
		}

		if ( ! headers_sent() ) {
			status_header( $codigo );
			header( 'Content-Type: application/json; charset=utf-8' );
			nocache_headers();
		}

		$json = wp_json_encode( $carga );

		echo self::SENTINELA . "\n" . ( is_string( $json ) ? $json : '{}' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON serializado, com Content-Type próprio.

		exit;
	}
}
