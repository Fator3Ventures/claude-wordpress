<?php
/** Inspeção limitada do JavaScript público do GTM. Nunca executa o contêiner. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Tracking_Diagnostico {
    const OPTION='f3base_gtm_evidencia';
    const EVENTO='f3base_gtm_verificar';
    public static function iniciar(): void {
        add_action('init',array(__CLASS__,'reconciliar'),25);
        add_action('updated_option',static function($n){if($n==='f3base_gtm_container_id'){self::reconciliar();}},25);
        add_action(self::EVENTO,array(__CLASS__,'coletar'));
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('tracking-encerrar-gtm','Encerrar tarefa GTM sem contêiner, com revisão e auditoria',array(__CLASS__,'encerrar'),array('revisao'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true)),array('revisao'),false);
            F3Base_Servicos::ability('tracking-diagnostico','Slots configurados e última inspeção do GTM, sem HTTP',array(__CLASS__,'ler'));
            F3Base_Servicos::ability('tracking-verificar-gtm','Inspecionar uma cópia limitada do contêiner público, sem executar JavaScript',static function(){return current_user_can('manage_options')?self::coletar():array('ok'=>false,'codigo'=>'sem_permissao');},array(),array(),false);
        });
    }
    public static function encerrar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(($e['revisao']??'')!==F3Base_Options::revisao('f3base_gtm_container_id')){return array('ok'=>false,'code'=>'revision_conflict','codigo'=>'revision_conflict','data'=>null);}
        if(F3Base_Options::ler('f3base_gtm_container_id')!==''){return array('ok'=>false,'codigo'=>'gtm_configurado');}
        return ($e['simular']??true)?array('ok'=>true,'simulado'=>true,'codigo'=>'encerramento_disponivel'):self::reconciliar($e['revisao']);
    }
    public static function reconciliar(string $esperada=''): array {
        $f=F3Base_Options::fotografia_bruta('f3base_gtm_container_id');if($f['erro']){return array('ok'=>false,'codigo'=>'configuracao_ilegivel');}
        if($esperada!==''&&$f['revisao']!==$esperada){return array('ok'=>false,'codigo'=>'revision_conflict');}
        $id=$f['existe']?$f['valor']:'';
        if($id!==''){
            if(!is_string($id)||!preg_match('/^GTM-[A-Z0-9]{4,32}$/D',$id)){return array('ok'=>false,'codigo'=>'gtm_invalido');}
            try{$blocked=F3Base_Operacao_Intencoes::da_tarefa('gtm');}catch(Throwable $e){return array('ok'=>false,'codigo'=>'intencoes_ilegivel');}
            if(array_filter($blocked,static fn($r)=>in_array($r['estado'],array('suspensa','esgotada'),true))){return array('ok'=>true,'codigo'=>'pausa_preservada');}
            if(!wp_next_scheduled(self::EVENTO)){wp_schedule_event(time()+60,'daily',self::EVENTO);}return array('ok'=>(bool)wp_next_scheduled(self::EVENTO),'codigo'=>'gtm_agendado');
        }
        $lock=F3Base_Trava::adquirir('gtm-diagnostico',30);if(!$lock){return array('ok'=>false,'codigo'=>'verificacao_em_execucao');}
        try{
            global $wpdb;$rows=F3Base_Operacao_Intencoes::da_tarefa('gtm');
            if(array_filter($rows,static fn($r)=>$r['em_execucao'])){return array('ok'=>false,'codigo'=>'ocorrencia_em_execucao');}
            if(F3Base_Options::revisao('f3base_gtm_container_id')!==$f['revisao']){return array('ok'=>false,'codigo'=>'revision_conflict');}
            foreach($rows as $r){if($r['estado']==='suspensa'){continue;}
                $n=$wpdb->query($wpdb->prepare("UPDATE %i SET estado='concluida',codigo='gtm_sem_configuracao',atualizada_em=%d WHERE chave=%s AND estado=%s AND reserva_ate<=%d",F3Base_Operacao_Intencoes::tabela(),time(),$r['intencao'],$r['estado'],time()));if($n!==1){return array('ok'=>false,'codigo'=>'encerramento_nao_confirmado');}
            }
            $checkpoint=F3Base_Options::atualizar_estado(F3Base_Operacao::OPTION,static function($v)use($f){
                if(F3Base_Options::revisao('f3base_gtm_container_id')!==$f['revisao']||($v['gtm']['lease']['ate']??0)>time()){return null;}
                if(!isset($v['gtm'])){return $v;}$v['gtm']['recuperacao']['pendente']=false;$v['gtm']['recuperacao']['tipo']='encerrada_sem_configuracao';$v['gtm']['encerrada_em']=time();$v['gtm']['encerrada_revisao']=$f['revisao'];return $v;
            });if(empty($checkpoint['persisted'])){return array('ok'=>false,'codigo'=>'checkpoint_nao_encerrado');}
            $removed=wp_clear_scheduled_hook(self::EVENTO,array(),true);if(is_wp_error($removed)||$removed===false){return array('ok'=>false,'codigo'=>'agenda_nao_removida');}
            $r=F3Base_Options::atualizar_estado(self::OPTION,static function($v)use($f){if(F3Base_Options::revisao('f3base_gtm_container_id')!==$f['revisao']){return null;}if(($v['encerramento']['revisao']??null)===$f['revisao']){return $v;}$v['encerramento']=array('em'=>time(),'revisao'=>$f['revisao'],'motivo'=>'contêiner removido','ator'=>get_current_user_id(),'politica'=>'sem_reativacao');$v['contexto_anterior']=$v['contexto']??null;$v['contexto']='';$v['estado']='nada_a_verificar';return $v;});
            // Shared wake-up is removed only if no other task has pending work.
            $wake=F3Base_Trava::adquirir('operacao-despertador',15);if($wake){try{$n=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE estado='pendente'",F3Base_Operacao_Intencoes::tabela()));if(!$wpdb->last_error&&(string)$n==='0'){wp_clear_scheduled_hook('f3base_operacao_retomar');}}finally{F3Base_Trava::liberar($wake);}}
            return array('ok'=>!empty($r['persisted']),'codigo'=>!empty($r['persisted'])?'nada_a_verificar':'encerramento_nao_confirmado','consulta_remota'=>false);
        }catch(Throwable $e){return array('ok'=>false,'codigo'=>'encerramento_indisponivel');}finally{F3Base_Trava::liberar($lock);
            $current=F3Base_Options::fotografia_bruta('f3base_gtm_container_id');if(!$current['erro']&&$current['revisao']!==$f['revisao']&&is_string($current['valor'])&&preg_match('/^GTM-[A-Z0-9]{4,32}$/D',$current['valor'])&&!wp_next_scheduled(self::EVENTO)){wp_schedule_event(time()+60,'daily',self::EVENTO);}
        }
    }
    public static function ler(): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $r=F3Base_Options::ler(self::OPTION);$atual=self::contexto();
        return array('ok'=>true,'slots'=>F3Base_Modulo_Tracking::ids(),'regime'=>'aditivo','gtm'=>$r,'vigente'=>($r['contexto']??'')===$atual&&($r['em']??0)>time()-DAY_IN_SECONDS,'proxima_verificacao'=>wp_next_scheduled(self::EVENTO),'limite'=>'IDs literais são indícios de coincidência, sem provar carregamento, consentimento ou entrega. Ausência de literal não exclui tags dinâmicas. O Core preserva os slots diretos.');
    }
    private static function contexto(): string {return hash('sha256',wp_json_encode(F3Base_Modulo_Tracking::ids()));}
    public static function inspecionar(string $js,array $ids): array {
        $out=array();
        foreach($ids as $slot=>$id){
            if($id===''||in_array($slot,array('f3base_gtm_container_id','f3base_google_ads.conversion_label'),true)){continue;}
            // Literal com fronteiras; números comuns ainda não são prova de configuração.
            if(preg_match('/(?<![A-Za-z0-9_-])'.preg_quote($id,'/').'(?![A-Za-z0-9_-])/',$js)){$out[]=array('slot'=>$slot,'id'=>$id,'evidencia'=>'literal_coincidente','acao'=>'Conferir tags e gatilhos no GTM; nenhum slot foi suprimido.');}
        }
        return $out;
    }
    public static function coletar(): array {
        $id=F3Base_Options::ler('f3base_gtm_container_id');
        if($id===''){return array('ok'=>true,'codigo'=>'nada_a_verificar','consulta_remota'=>false);}
        if(!is_string($id)||!preg_match('/^GTM-[A-Z0-9]{4,32}$/D',$id)){return array('ok'=>false,'codigo'=>'gtm_invalido');}
        $ctx=self::contexto();$old=F3Base_Options::ler(self::OPTION);
        if(($old['contexto']??'')===$ctx&&($old['em']??0)>time()-HOUR_IN_SECONDS){return array('ok'=>true,'cache'=>true,'evidencia'=>$old);}
        $trava=F3Base_Trava::adquirir('gtm-diagnostico',30);if(!$trava){return array('ok'=>false,'codigo'=>'verificacao_em_execucao');}
        try {
            $res=wp_safe_remote_get('https://www.googletagmanager.com/gtm.js?id='.rawurlencode($id),array('timeout'=>8,'redirection'=>0,'limit_response_size'=>524289,'cookies'=>array()));
            $http=is_wp_error($res)?0:wp_remote_retrieve_response_code($res);$body=is_wp_error($res)?'':wp_remote_retrieve_body($res);
            $ok=$http===200&&strlen($body)<=524288&&$body!=='';
            $r=array('em'=>time(),'contexto'=>$ctx,'container'=>$id,'http'=>$http,'estado'=>$ok?'inspecionado':(strlen($body)>524288?'resposta_acima_do_limite':'indisponivel'),'bytes'=>strlen($body),'sha256'=>$ok?hash('sha256',$body):null,'coincidencias'=>$ok?self::inspecionar($body,F3Base_Modulo_Tracking::ids()):array());
            $saved=F3Base_Options::atualizar_estado(self::OPTION,static fn()=>self::contexto()===$ctx&&F3Base_Options::ler('f3base_gtm_container_id')===$id?$r:null);
            return array('ok'=>$ok&&!empty($saved['persisted']),'evidencia'=>$r);
        } finally {F3Base_Trava::liberar($trava);}
    }
}
