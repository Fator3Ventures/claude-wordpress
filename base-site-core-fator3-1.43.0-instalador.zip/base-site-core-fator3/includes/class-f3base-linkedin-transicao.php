<?php
/** Durable, explicit provider selection. Never treats silence as drained delivery. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Linkedin_Transicao {
    public static function executar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        return F3Base_Linkedin_Integracoes::executar($e['integracao_id']??null,static fn()=>self::operar($e));
    }
    private static function preparar(array $target): array {
        return F3Base_Linkedin_Integracoes::prever($target,static function()use($target){
            $all=F3Base_Linkedin_Integracoes::colecao();$all[F3Base_Linkedin_Integracoes::id()]=$target;
            $err=F3Base_Linkedin_Integracoes::permitir_transicao(static fn()=>F3Base_Linkedin_Integracoes::validar(array('integracoes'=>$all)));
            if($err!==''){return array('ok'=>false,'codigo'=>'destino_recusado','motivo'=>$err);}
            if(F3Base_Linkedin_Cliente::externo()){
                $r=F3Base_Linkedin_Cliente::chamar('effective_status');if(empty($r['ok'])){return $r;}
                if(array_diff(F3Base_Linkedin::formularios($target),$r['data']['forms']??array())){return array('ok'=>false,'codigo'=>'formularios_sem_concessao');}
                $grant=\Fator3\LinkedIn\Api::dispatch('get-grant',array('consumer_id'=>F3Base_Linkedin_Integracoes::consumer(),'connection_id'=>$target['connection_id']));
                $connection=\Fator3\LinkedIn\Api::dispatch('get-connection',array('connection_id'=>$target['connection_id']));
                if(empty($grant['success'])||empty($connection['success'])){return array('ok'=>false,'codigo'=>'conexao_ou_grant_nao_comprovados');}
                $g=$grant['data']['grant'];$needed=!empty($target['webhook']['ativo'])?array('metadata','responses','verify','subscriptions'):array('metadata','responses');
                if(array_diff($needed,$g['permissions']??array())){return array('ok'=>false,'codigo'=>'permissoes_incompletas');}
                if(!empty($target['webhook']['ativo'])&&($g['callback_url']??'')!==F3Base_Linkedin_Webhook::url()){return array('ok'=>false,'codigo'=>'callback_nao_concedida','callback_esperada'=>F3Base_Linkedin_Webhook::url());}
                $access=F3Base_Linkedin_Cliente::chamar('check_access');if(empty($access['ok'])){return $access;}
                $checked=array_column($access['data']['forms_checked']??array(),'id');$deadline=microtime(true)+20;
                foreach(array_diff(F3Base_Linkedin::formularios($target),$checked) as $form){
                    if(microtime(true)>$deadline-3){return array('ok'=>false,'codigo'=>'metadados_cobertura_parcial','formularios_restantes'=>count(array_diff(F3Base_Linkedin::formularios($target),$checked)),'acao'=>'Repita a prévia quando o fornecedor responder dentro do orçamento; nenhuma promoção foi feita.');}
                    $one=F3Base_Linkedin_Cliente::chamar('get_form',array('form_id'=>(string)$form)+array_intersect_key($r['data'],array_flip(array('credential_revision','grant_revision'))));if(empty($one['ok'])){return $one;}$checked[]=(string)$form;
                }
                $fresh=F3Base_Linkedin_Cliente::chamar('effective_status');if(empty($fresh['ok'])||array_intersect_key($fresh['data'],array_flip(array('credential_revision','grant_revision')))!==array_intersect_key($r['data'],array_flip(array('credential_revision','grant_revision')))){return array('ok'=>false,'codigo'=>'revision_conflict');}
                return array('ok'=>true,'codigo'=>'destino_conferido','revisoes'=>array_intersect_key($r['data'],array_flip(array('credential_revision','grant_revision'))),'callback'=>F3Base_Linkedin_Webhook::url(),'leads_lidos'=>false,'consulta_remota'=>true);
            }
            $r=F3Base_Linkedin_Cliente::introspectar($target);if(empty($r['ok'])){return $r;}
            foreach(F3Base_Linkedin::formularios($target) as $id){$f=F3Base_Linkedin_Cliente::pedir('GET','leadForms/'.$id);if(empty($f['ok'])||($f['data']['owner']['sponsoredAccount']??'')!==F3Base_Linkedin::dono($target)){return array('ok'=>false,'codigo'=>'formulario_ou_proprietario_divergente');}}
            return array('ok'=>true,'codigo'=>'destino_conferido','revisoes'=>array('token'=>F3Base_Options::revisao(F3Base_Linkedin_Api::TOKEN),'secret'=>F3Base_Options::revisao(F3Base_Linkedin_Api::SECRET)),'leads_lidos'=>false,'consulta_remota'=>true);
        });
    }
    private static function concluir(array $target): array {
        $save=F3Base_Linkedin_Integracoes::atualizar_estado(static function($s){$s['cursores']=$s['cursores']??array();foreach($s['cursores'] as &$c){$c['ate']=max((int)($c['ate']??0),!empty($c['versoes'])?min(array_column($c['versoes'],'ate')):0);unset($c['cursor_opaco'],$c['janela_inicio'],$c['janela_fim'],$c['versoes']);$c['inicio']=0;$c['proxima']=time()+5;}unset($c);$s['transicao']['fase']='concluida';$s['transicao']['concluida_em']=time();return $s;});
        if(empty($save['persisted'])){return array('ok'=>false,'codigo'=>'troca_commit_pendente');}F3Base_Fila::agendar(F3Base_Linkedin::EVENTO,time()+5);return array('ok'=>true,'codigo'=>'troca_confirmada','cliente'=>$target['cliente'],'integracao_id'=>F3Base_Linkedin_Integracoes::id());
    }
    private static function operar(array $e): array {
        $cfg=F3Base_Linkedin::config();$rev=F3Base_Options::revisao(F3Base_Linkedin::OPCAO);$target=$cfg;
        foreach(array('cliente','connection_id','conta_id','formularios') as $k){if(array_key_exists($k,$e)){$target[$k]=$e[$k];}}
        $state=F3Base_Linkedin_Integracoes::estado();$journal=$state['transicao']??array();$key=(string)($e['chave_operacao']??'');$hash=hash('sha256',wp_json_encode(array(F3Base_Linkedin_Integracoes::id(),array_intersect_key($target,array_flip(array('cliente','connection_id','conta_id','formularios'))))));
        if($key!==''&&($journal['chave']??'')===$key){if(($journal['hash']??'')!==$hash){return array('ok'=>false,'codigo'=>'chave_operacao_reutilizada');}if(($journal['fase']??'')==='concluida'){return array('ok'=>true,'codigo'=>'troca_confirmada','repetida'=>true,'cliente'=>$cfg['cliente']);}}
        if(($e['simular']??true)===false&&!hash_equals($rev,(string)($e['revisao']??''))&&($journal['chave']??'')!==$key){return array('ok'=>false,'codigo'=>'revision_conflict','conflict'=>true,'data'=>null);}
        $proof=self::preparar($target);$preview=array('ok'=>!empty($proof['ok']),'simular'=>true,'integracao_id'=>F3Base_Linkedin_Integracoes::id(),'atual'=>$cfg['cliente'],'destino'=>$target['cliente'],'revisao'=>$rev,'prova'=>$proof,'efeito'=>'Pausar, conferir recebimento anterior e preservar marco confirmado; não cria contatos ou assinaturas nesta prévia.');
        if(($e['simular']??true)!==false||empty($proof['ok'])){return $preview;}
        if(!preg_match('/^[A-Za-z0-9._:-]{8,128}$/D',$key)){return array('ok'=>false,'codigo'=>'chave_operacao_obrigatoria');}
        if($journal&&!in_array($journal['fase']??'',array('concluida','cancelada'),true)&&($journal['chave']??'')!==$key){return array('ok'=>false,'codigo'=>'troca_pendente','operacao'=>$journal['chave']);}
        $locks=array();
        try{
            foreach(array('linkedin-transicao','linkedin-coleta','linkedin-assinaturas','linkedin-notificacoes','linkedin-callback') as $name){$lock=F3Base_Trava::adquirir($name.':'.F3Base_Linkedin_Integracoes::id(),60);if(!$lock){return array('ok'=>false,'codigo'=>'worker_em_curso');}$locks[]=$lock;}
            if(F3Base_Options::revisao(F3Base_Linkedin::OPCAO)!==$rev){return array('ok'=>false,'codigo'=>'revision_conflict','conflict'=>true,'data'=>null);}
            if(($journal['chave']??'')===$key&&($journal['fase']??'')==='commit_preparado'&&$cfg===($journal['destino']??null)){return self::concluir($cfg);}
            $j=array('chave'=>$key,'hash'=>$hash,'fase'=>'drenando','origem'=>$cfg,'destino'=>$target,'revisao'=>$rev,'prova'=>$proof,'em'=>$journal['em']??time());
            $save=F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($j){$s['transicao']=$j;$s['geracao']=(int)($s['geracao']??0)+1;return $s;});if(empty($save['persisted'])){return array('ok'=>false,'codigo'=>'troca_checkpoint_falhou');}
            global $wpdb;$pending=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE contexto=%s AND tipo='notificacao' AND estado IN ('pendente','revisao')",F3Base_Linkedin_Webhook::tabela(),F3Base_Linkedin::contexto()));
            if($wpdb->last_error||$pending>0){return array('ok'=>false,'codigo'=>'notificacoes_anteriores_pendentes','acao'=>'Processar os recibos autenticados pelo cliente anterior e repetir a mesma operação.');}
            $subs=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE contexto=%s AND tipo='assinatura'",F3Base_Linkedin_Webhook::tabela(),F3Base_Linkedin::contexto()));
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'diario_indisponivel');}
            if($subs>0||!empty($state['assinaturas_sdk'])){
                $drain=F3Base_Linkedin_Webhook::sincronizar('drenar');$code=empty($drain['ok'])?'assinaturas_anteriores_pendentes':'notificacoes_em_transito_sem_prova';
                F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($code,$drain){$s['transicao']['impedimento']=$code;$s['transicao']['reconciliacao']=$drain;return $s;});
                return array('ok'=>false,'codigo'=>$code,'acao'=>'A seleção anterior permanece pausada. É necessária evidência do produtor sobre encerramento do recebimento anterior; tempo decorrido ou GET vazio não comprovam drenagem.');
            }
            $fresh=self::preparar($target);if(empty($fresh['ok'])||$fresh['revisoes']!==$proof['revisoes']){return array('ok'=>false,'codigo'=>'revision_conflict','conflict'=>true,'data'=>null);}
            foreach($locks as &$lease){if(!F3Base_Trava::renovar($lease,60)){return array('ok'=>false,'codigo'=>'worker_reserva_perdida');}}unset($lease);
            // Checkpoint before commit allows replay to finish after an interrupted preference write.
            $save=F3Base_Linkedin_Integracoes::atualizar_estado(static function($s){$s['transicao']['fase']='commit_preparado';return $s;});if(empty($save['persisted'])){return array('ok'=>false,'codigo'=>'troca_checkpoint_falhou');}
            $r=F3Base_Linkedin_Integracoes::permitir_transicao(static fn()=>F3Base_Linkedin_Integracoes::salvar($target,$rev,F3Base_Options::ORIGEM_MANUAL));if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'troca_commit_pendente');}
            return self::concluir($target);
        }finally{foreach(array_reverse($locks) as $lock){F3Base_Trava::liberar($lock);}}
    }
}
