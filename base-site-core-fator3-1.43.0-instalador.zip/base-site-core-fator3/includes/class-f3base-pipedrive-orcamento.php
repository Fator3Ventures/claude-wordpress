<?php
/** Local estimates, isolated per consumer/account/site/UTC day. No provider quota claims. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Orcamento {
    const OPCOES=array('entregas'=>'f3base_pipedrive_orcamento','qualidade'=>'f3base_pipedrive_qualidade_orcamento','verificacao'=>'f3base_pipedrive_verificacao_orcamento');
    public static function contexto(array $cfg): string {$s=get_option('f3base_pipedrive_estado',array());return hash('sha256',home_url().'|'.($cfg['dominio']??'').'|'.($s['conta_id']??''));}
    public static function limite(string $consumer,array $cfg): int {return max(1,(int)($cfg[array('entregas'=>'orcamento_local_diario','qualidade'=>'orcamento_qualidade_diario','verificacao'=>'orcamento_verificacao_diario')[$consumer]]??($consumer==='entregas'?3000:600)));}
    private static function preparar(array $v,string $day,string $ctx): array {
        if(($v['dia']??'')!==$day){$v=array('dia'=>$day,'contas'=>array());}
        if(!isset($v['contas'])){$spent=(int)($v['usados']??0);$v['contas']=array($ctx=>array('usados'=>$spent,'reservados'=>0,'anterior_sem_discriminacao'=>$spent));}
        $v['contas'][$ctx]=$v['contas'][$ctx]??array('usados'=>0,'reservados'=>0,'anterior_sem_discriminacao'=>0);return $v;
    }
    public static function reservar(string $consumer,array $cfg,int $cost): array {
        $name=self::OPCOES[$consumer];$ctx=self::contexto($cfg);$day=gmdate('Y-m-d');$limit=self::limite($consumer,$cfg);$ticket=wp_generate_uuid4();
        $r=F3Base_Options::atualizar_estado($name,static function($v)use($ctx,$day,$limit,$cost,$ticket){$v=self::preparar($v,$day,$ctx);$c=&$v['contas'][$ctx];if($c['usados']+$cost>$limit){return null;}$c['usados']+=$cost;$c['reservados']+=$cost;$c['reservas'][$ticket]=$cost;$v['usados']=$c['usados'];$v['contexto']=$ctx;$v['atualizado_em']=time();return $v;});
        $confirmed=!empty($r['persisted']);if(!$confirmed&&($r['codigo']??'')==='escrita_sem_confirmacao'){$fresh=F3Base_Options::fotografia_bruta($name);$value=$fresh['valor']??array();$confirmed=($value['dia']??'')===$day&&($value['contas'][$ctx]['reservas'][$ticket]??null)===$cost;}
        return array('ok'=>$confirmed,'ticket'=>$ticket,'opcao'=>$name,'contexto'=>$ctx,'dia'=>$day,'custo'=>$cost,'consumidor'=>$consumer,'limite'=>$limit);
    }
    /** An uncertain dispatched request remains charged; only no-HTTP reservations refund. */
    public static function finalizar(array $reservation,bool $dispatch): void {
        F3Base_Options::atualizar_estado($reservation['opcao'],static function($v)use($reservation,$dispatch){$ctx=$reservation['contexto'];if(($v['dia']??'')!==$reservation['dia']||!isset($v['contas'][$ctx]['reservas'][$reservation['ticket']])){return null;}$c=&$v['contas'][$ctx];unset($c['reservas'][$reservation['ticket']]);$c['reservados']=max(0,$c['reservados']-$reservation['custo']);if(!$dispatch){$c['usados']=max(0,$c['usados']-$reservation['custo']);}if(($v['contexto']??'')===$ctx){$v['usados']=$c['usados'];}return $v;});
    }
    public static function resumo(): array {
        $cfg=F3Base_Options::ler('f3base_pipedrive');$ctx=self::contexto($cfg);$day=gmdate('Y-m-d');$out=array();
        foreach(self::OPCOES as $consumer=>$option){$v=self::preparar(get_option($option,array()),$day,$ctx);$c=$v['contas'][$ctx];$limit=self::limite($consumer,$cfg);$out[$consumer]=array('dia_utc'=>$day,'proxima_janela_em'=>strtotime('tomorrow UTC'),'atualizado_em'=>$v['atualizado_em']??null,'contexto'=>$ctx,'limite'=>$limit,'consumido_estimado'=>$c['usados']-$c['reservados'],'reservado'=>$c['reservados'],'total_comprometido'=>$c['usados'],'saldo_local'=>max(0,$limit-$c['usados']),'anterior_sem_discriminacao'=>$c['anterior_sem_discriminacao'],'esgotado'=>$c['usados']+20>$limit);}
        return array('consumidores'=>$out,'pausa_remota_ate'=>(int)(get_option('f3base_pipedrive_estado',array())['pausa_ate']??0),'unidade'=>'estimativa local: GET/pesquisa 20, escrita 10; não é o saldo oficial da conta','reservas'=>'Reservas sem confirmação de término permanecem comprometidas até a virada UTC.','alerta'=>get_option('f3base_pipedrive_orcamento_alerta',array()));
    }
    public static function painel(): void {
        $r=self::resumo();echo '<h3>Orçamento e atualização do CRM</h3><p>As cotas são estimativas locais por conta e dia UTC. Qualidade e verificação têm contadores independentes das entregas. A cota padrão de qualidade, 600 unidades, permite aproximadamente 30 leituras de custo 20 por dia; ajuste conforme o número de contatos acompanhados. Limites do Pipedrive continuam compartilhados.</p><table class="widefat striped"><thead><tr><th>Uso</th><th>Limite</th><th>Consumido estimado</th><th>Reservado</th><th>Disponível</th></tr></thead><tbody>';
        foreach($r['consumidores'] as $name=>$c){echo '<tr><td>'.esc_html(ucfirst($name)).'</td><td>'.esc_html((string)$c['limite']).'</td><td>'.esc_html((string)$c['consumido_estimado']).'</td><td>'.esc_html((string)$c['reservado']).'</td><td>'.esc_html((string)$c['saldo_local']).'</td></tr>';}
        echo '</tbody></table><p>Próxima janela: '.esc_html(wp_date('d/m/Y H:i:s T',strtotime('tomorrow UTC'))).'.</p>';$old=$r['consumidores']['entregas']['anterior_sem_discriminacao'];if($old){echo '<p>Consumo anterior sem discriminação: '.esc_html((string)$old).' unidades. Preservado na reserva até a próxima janela UTC; a separação vale para as chamadas novas.</p>';}if(!empty($r['alerta']['aberto'])){echo '<div class="notice notice-warning inline"><p>Há contatos aguardando orçamento. Os registros estão preservados; consulte os recibos dos avisos em integracoes-ler.</p></div>';}
    }
    public static function monitorar(): void {
        global $wpdb;$cfg=F3Base_Options::ler('f3base_pipedrive');$b=self::resumo();$blocked=$b['consumidores']['entregas']['esgotado']||$b['pausa_remota_ate']>time();
        $st=get_option('f3base_pipedrive_estado',array());$account=($st['dominio']??'').'|'.($st['conta_id']??'').'|'.($st['instalacao']??'');
        $pending=empty($cfg['ativo'])?array():$wpdb->get_row($wpdb->prepare("SELECT COUNT(*) quantidade,MIN(f.capturado_em) primeira_em FROM %i f JOIN %i l ON l.record_id=f.record_id WHERE f.conta=%s AND f.estado IN ('pendente','incerto','enviando') AND l.classe_trafego<>'teste' AND l.captura='aceito' AND l.lixeira=0 AND l.eliminacao_pendente=0",F3Base_Pipedrive_Fila::tabela(),F3Base_Leads_Repositorio::tabela(),$account),ARRAY_A);if($wpdb->last_error){return;}$n=(int)($pending['quantidade']??0);
        $s=get_option('f3base_pipedrive_orcamento_alerta',array());
        if(!$blocked||!$n){if(!empty($s['aberto'])){F3Base_Options::atualizar_estado('f3base_pipedrive_orcamento_alerta',static fn($v)=>array_merge($v,array('aberto'=>false,'resolvido_em'=>time())));}return;}
        if(!empty($s['aberto'])){return;}$key=wp_generate_uuid4();$save=F3Base_Options::atualizar_estado('f3base_pipedrive_orcamento_alerta',static fn($v)=>!empty($v['aberto'])?null:array('id'=>$key,'aberto'=>true,'em'=>time(),'pendentes'=>$n,'pendencia_mais_antiga_em'=>(int)($pending['primeira_em']??0),'consumidor'=>$b['pausa_remota_ate']>time()?'conta_remota':'entregas','retomada_prevista_em'=>$b['pausa_remota_ate']>time()?$b['pausa_remota_ate']:strtotime('tomorrow UTC'),'codigo'=>'entregas_aguardando_orcamento','envio'=>'reservado','recebimento'=>'nao_comprovado'));
        if(empty($save['persisted'])){return;}$text="Pipedrive — entregas aguardando orçamento\n\nSite: ".home_url()."\nContatos pendentes: ".$n."\nPendência mais antiga: ".(!empty($pending['primeira_em'])?wp_date('d/m/Y H:i:s T',(int)$pending['primeira_em']):'não informada')."\nRetomada prevista: ".wp_date('d/m/Y H:i:s T',$b['pausa_remota_ate']>time()?$b['pausa_remota_ate']:strtotime('tomorrow UTC'))."\nA cota local ou a pausa remota impede novas entregas. Os contatos estão preservados.\nConfira Conexões e entregas → Pipedrive.\n".admin_url('admin.php?page=base-site-core-fator3&secao=conexoes&integracao=f3base_pipedrive');$receipt=array('painel'=>'disponivel');
        $receipt['email']=F3Base_Alertas_Operacionais::enviar('Pipedrive — entregas aguardando orçamento — '.get_bloginfo('name'),$text);
        F3Base_Options::atualizar_estado('f3base_pipedrive_orcamento_alerta',static fn($v)=>($v['id']??'')===$key?array_merge($v,array('envio'=>'conferir_recibos','recibos'=>$receipt)):null);
    }
}
