<?php
/** Projeção única e em lote. Aceite do transporte nunca significa leitura humana. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Contato_Entregas {
    public static function lote(array $leads): array {
        if(!$leads){return array();}global $wpdb;$ids=array_values(array_unique(array_column($leads,'record_id')));$in=implode(',',array_fill(0,count($ids),'%s'));$external=array();$crm=array();$quality=array();
        foreach($wpdb->get_results($wpdb->prepare("SELECT record_id,estado,codigo,contingencia,atualizada_em FROM %i WHERE record_id IN ({$in}) ORDER BY ciclo DESC",array_merge(array(F3Base_Avisos::tabela()),$ids)),ARRAY_A)?:array() as $r){$external[$r['record_id']]=$external[$r['record_id']]??$r;}
        foreach($wpdb->get_results($wpdb->prepare("SELECT record_id,estado,codigo,atualizado_em FROM %i WHERE record_id IN ({$in}) ORDER BY atualizado_em DESC",array_merge(array(F3Base_Pipedrive_Fila::tabela()),$ids)),ARRAY_A)?:array() as $r){$crm[$r['record_id']]=$crm[$r['record_id']]??$r;}
        foreach($wpdb->get_results($wpdb->prepare("SELECT record_id,etapa,origem,ocorreu_em FROM %i WHERE record_id IN ({$in})",array_merge(array(F3Base_Qualidade::tabela('atual')),$ids)),ARRAY_A)?:array() as $r){$quality[$r['record_id']]=$r;}
        $out=array();foreach($leads as $l){$id=$l['record_id'];$d=is_string($l['dados']??null)?json_decode($l['dados'],true):($l['dados']??array());$i=$d['aviso_intencao']??array();$channel=$i['canal']??'email';$x=$external[$id]??null;$c=$crm[$id]??null;$ext=in_array($channel,array('slack','ambos'),true)?'slack':(in_array($channel,array('webhook','email_webhook'),true)?'webhook':null);
            $email=in_array($channel,array('email','ambos','email_webhook'),true)?($l['aviso']??'desconhecido'):'nao_solicitado';$channels=array('email'=>array('estado'=>$email,'confirmacao'=>$email==='processado'?'aceito_pelo_transporte_nao_confirma_leitura':null),'visitante'=>array('estado'=>$l['resposta']??'nao_solicitado'),'pipedrive'=>$c?array('estado'=>$c['estado'],'codigo'=>$c['codigo'],'em'=>(int)$c['atualizado_em']):array('estado'=>'nao_enfileirado'));
            if($ext){$channels[$ext]=$x?array('estado'=>$x['estado'],'codigo'=>$x['codigo'],'em'=>(int)$x['atualizada_em']):array('estado'=>empty($i['elegivel'])?'nao_solicitado':'aguarda_preparo');}
            $fallback=$x['contingencia']??'';$fallbackOK=in_array($fallback,array('processado','enviado','enviada','aceito'),true);$failed=$x&&in_array($x['estado'],array('falhou','incerto','suspenso'),true);$confirmed=in_array($l['aviso']??'',array('processado','resumo_processado'),true)||($x&&$x['estado']==='entregue')||$fallbackOK;
            $out[$id]=array('canais'=>$channels,'contingencia_email'=>$fallback?:'nao_acionada','resumo'=>$failed&&!$confirmed?'Aviso requer atenção':($confirmed?'Aviso aceito pelo transporte':($email==='nao_solicitado'&&!$ext?'Aviso não solicitado':'Aviso pendente ou suprimido')),'falha_sem_contingencia'=>$failed&&!$confirmed,'qualidade'=>$quality[$id]??null,'limite'=>'Entrega confirmada pelo transporte não comprova leitura humana ou venda.');
        }return $out;
    }
    public static function texto(array $r): string {
        $parts=array();foreach($r['canais']??array() as $k=>$v){$parts[]=array('email'=>'E-mail','slack'=>'Slack','webhook'=>'Webhook','pipedrive'=>'Pipedrive','visitante'=>'Resposta ao visitante')[$k].': '.str_replace('_',' ',$v['estado']);}
        if(($r['contingencia_email']??'nao_acionada')!=='nao_acionada'){$parts[]='Contingência por e-mail: '.str_replace('_',' ',$r['contingencia_email']);}return implode("\n",$parts);
    }
}
