<?php
/** Capability contracts are local diagnostics, never installation requirements. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Companheiros {
    const MCP_CONTRATO='server-integration/1.0.0';
    public static function mcp(): array {
        $r=array('regra'=>'contrato_e_capacidades','observada'=>defined('F3_MCP_FILES_VERSION')?F3_MCP_FILES_VERSION:null,'compativel'=>false,'codigo'=>'mcp_ausente');
        if(!is_callable(array('Fator3\\McpFiles\\ServerContract','capabilities'))){return $r;}
        try{$c=\Fator3\McpFiles\ServerContract::capabilities();
            $r['compativel']=is_array($c)&&($c['contract']??'')===self::MCP_CONTRATO&&($c['policy_contract']??null)===1&&($c['provider']??'')==='wp-mcp-fator3'&&($c['server_id']??'')==='wp-mcp-ultimate-server'&&is_callable(array('Fator3\\McpFiles\\ExtensionContract','register'));
            $r['codigo']=$r['compativel']?'compativel':'contrato_mcp_incompativel';
        }catch(Throwable $e){$r['codigo']='contrato_mcp_indisponivel';}return $r;
    }
    public static function google(): array {$sdk=F3Base_Gsc::registro();return array('regra'=>'contrato_e_capacidades','observada'=>defined('F3_MCP_GOOGLE_VERSION')?F3_MCP_GOOGLE_VERSION:null,'compativel'=>$sdk==='registrado','codigo'=>$sdk==='registrado'?'compativel':$sdk);}
}
