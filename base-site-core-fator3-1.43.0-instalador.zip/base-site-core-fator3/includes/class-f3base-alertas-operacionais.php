<?php
/** Canal exclusivo de alertas operacionais. A reserva/deduplicação pertence ao chamador. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Alertas_Operacionais {
    const POLITICA='admin_email/1';
    public static function destinatario(): string {
        $v=get_option('admin_email','');return is_string($v)&&is_email($v)?$v:'';
    }
    public static function enviar(string $titulo,string $texto,bool $teste=false): array {
        $r=array('politica'=>self::POLITICA,'canal'=>'email','recebimento'=>'nao_comprovado','em'=>time());
        if($teste&&F3Base_Testes::politica('email','teste')==='suprimir'){return $r+array('estado'=>'suprimido_teste','ok'=>true);}
        $to=self::destinatario();if($to===''){return $r+array('estado'=>'sem_destinatarios','codigo'=>'admin_email_invalido','ok'=>false);}
        try{$ok=wp_mail($to,($teste?'[TESTE] ':'').$titulo,$texto,array('Content-Type: text/plain; charset=UTF-8'));
            return $r+array('ok'=>$ok,'estado'=>$ok?'processado':'falhou','codigo'=>$ok?'aceito_wp_mail':'envio_recusado');
        }catch(Throwable $e){return $r+array('ok'=>false,'estado'=>'incerto','codigo'=>'envio_sem_confirmacao');}
    }
}
