<?php
/** Catálogo de qualidade: geração paginada, conta/revisão vinculadas e troca atômica do snapshot. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Qualidade_Catalogo {
    private static function conta(): string {$s=get_option('f3base_pipedrive_estado',array());return ($s['dominio']??'').'|'.($s['conta_id']??'').'|'.($s['instalacao']??'');}
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('qualidade-catalogo-carregar','Carregar funis e etapas da conta Pipedrive verificada; simulação sem HTTP',array(__CLASS__,'carregar'),array('simular'=>array('type'=>'boolean','default'=>true)),array(),false);
            F3Base_Servicos::ability('qualidade-ler','Ler configuração e catálogo local de qualidade, sem consulta remota',array(__CLASS__,'ler'),array('incluir_catalogo'=>array('type'=>'boolean','default'=>false)));
        });
    }
    public static function ler(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $s=get_option('f3base_qualidade_catalogo',array());
        $r=array('ok'=>true,'configuracao'=>F3Base_Qualidade::config(),'catalogo_disponivel'=>!empty($s['completo'])&&($s['conta']??'')===self::conta()&&F3Base_Integracoes::pipedrive_verificado()&&(!empty($s['identidade_conta'])?hash_equals($s['identidade_conta'],F3Base_Integracoes::identidade_pipedrive()):F3Base_Integracoes::revisoes_atuais($s['prova']??array(),'f3base_pipedrive','f3base_pipedrive_token')),'ultima_tentativa'=>get_option('f3base_qualidade_estado',array())['catalogo_tentativa']??null);
        if(!empty($e['incluir_catalogo'])){$r['catalogo']=$s?array_merge($s,array('vinculo_conta'=>$s['conta'],'conta'=>(string)($s['conta_id']??''))):null;}
        return $r;
    }
    private static function falha(array $r): array {
        F3Base_Options::atualizar_estado('f3base_qualidade_estado',static function($s)use($r){$s['catalogo_tentativa']=array('em'=>time(),'codigo'=>$r['codigo']??'consulta_falhou','completo'=>false);return $s;});
        return array_merge(array('ok'=>false,'persistido'=>false,'completo'=>false),$r);
    }
    public static function carregar(array $e=array()): array {return F3Base_Pipedrive_Api::com_consumidor('verificacao',static fn()=>self::carregar_interno($e));}
    private static function carregar_interno(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(!F3Base_Integracoes::pipedrive_verificado()){return array('ok'=>false,'codigo'=>'conta_crm_nao_verificada');}
        $conta=self::conta();$id=(string)(get_option('f3base_pipedrive_estado',array())['conta_id']??'');
        if($e['simular']??true){return array('ok'=>true,'simulado'=>true,'conta'=>$id,'codigo'=>'catalogo_pronto_para_carregar','efeito'=>'Consulta funis/etapas no orçamento diário e substitui o catálogo somente após completar.');}
        $lock=F3Base_Trava::adquirir('qualidade-catalogo',40);if(!$lock){return array('ok'=>false,'codigo'=>'catalogo_ocupado');}
        try {
            $proof=F3Base_Pipedrive_Api::iniciar_lote();$ctx=hash('sha256',$conta.'|'.wp_json_encode($proof));
            $state=get_option('f3base_qualidade_estado',array());$pre=$state['catalogo_preparo']??array();
            if(($pre['contexto']??'')!==$ctx||!empty($pre['concluido'])){$pre=array('contexto'=>$ctx,'geracao'=>wp_generate_uuid4(),'conta'=>$conta,'listas'=>array(),'iniciado_em'=>time());}
            foreach(array('funis'=>'v2/pipelines','etapas'=>'v2/stages') as $kind=>$path){
                $part=$pre['listas'][$kind]??array('linhas'=>array(),'cursor'=>'','vistos'=>array(),'completo'=>false);
                for($i=0;!$part['completo']&&$i<6;$i++){
                    $q=array('limit'=>100);if($part['cursor']!==''){$q['cursor']=$part['cursor'];}
                    $r=F3Base_Pipedrive_Api::pedir('GET',$path,$q);if(empty($r['ok'])){return self::falha($r+array('parcial'=>true,'geracao'=>$pre['geracao']));}
                    $items=$r['data']['items']??$r['data'];
                    if(!is_array($items)||!array_is_list($items)){return self::falha(array('codigo'=>'catalogo_formato_invalido'));}
                    foreach($items as $row){
                        if(!is_array($row)||!preg_match('/^[1-9][0-9]*$/D',(string)($row['id']??''))||!is_string($row['name']??null)||($kind==='etapas'&&!preg_match('/^[1-9][0-9]*$/D',(string)($row['pipeline_id']??'')))){return self::falha(array('codigo'=>'catalogo_item_invalido'));}
                        $active=$row['active']??$row['active_flag']??null;
                        $part['linhas'][(string)$row['id']]=array('id'=>(string)$row['id'],'nome'=>$row['name'],'name'=>$row['name'],'pipeline_id'=>$kind==='etapas'?(string)$row['pipeline_id']:null,'active'=>in_array($active,array(true,1,'1',false,0,'0'),true)?(bool)$active:null);
                    }
                    $next=$r['additional_data']['next_cursor']??null;
                    if($next!==null&&(!is_string($next)||$next===''||in_array($next,$part['vistos'],true))){return self::falha(array('codigo'=>'catalogo_cursor_invalido'));}
                    $part['completo']=$next===null;$part['cursor']=$next??'';if($next!==null){$part['vistos'][]=$next;}
                    $pre['listas'][$kind]=$part;
                    $save=F3Base_Options::atualizar_estado('f3base_qualidade_estado',static function($s)use($pre,$conta){if(!F3Base_Pipedrive_Api::lote_atual()||self::conta()!==$conta){return null;}$s['catalogo_preparo']=$pre;return $s;});
                    if(empty($save['persisted'])){return self::falha(array('codigo'=>'catalogo_checkpoint_falhou'));}
                }
                if(!$part['completo']){return self::falha(array('codigo'=>'catalogo_em_continuacao','parcial'=>true,'geracao'=>$pre['geracao']));}
            }
            $out=array('conta'=>$conta,'conta_id'=>$id,'em'=>time(),'completo'=>true,'prova'=>$proof,'identidade_conta'=>F3Base_Integracoes::identidade_pipedrive());
            foreach(array('funis','etapas') as $kind){$list=$pre['listas'][$kind]['linhas'];ksort($list,SORT_NATURAL);$out[$kind]=array_values($list);}
            $pipelines=array_column($out['funis'],'id');foreach($out['etapas'] as $row){if(!in_array($row['pipeline_id'],$pipelines,true)){return self::falha(array('codigo'=>'catalogo_vinculo_invalido'));}}
            $out['revisao']=hash('sha256',wp_json_encode(array($conta,$out['funis'],$out['etapas'])));
            $old=get_option('f3base_qualidade_catalogo',array());
            $save=F3Base_Options::atualizar_estado('f3base_qualidade_catalogo',static function()use($out,$conta){return F3Base_Pipedrive_Api::lote_atual()&&self::conta()===$conta?$out:null;});
            if(empty($save['persisted'])||get_option('f3base_qualidade_catalogo',array())!==$out){return self::falha(array('codigo'=>'catalogo_nao_persistido'));}
            $pre['concluido']=true;F3Base_Options::atualizar_estado('f3base_qualidade_estado',static function($s)use($pre){$s['catalogo_preparo']=$pre;$s['catalogo_tentativa']=array('em'=>time(),'codigo'=>'catalogo_atualizado','completo'=>true);return $s;});
            return array('ok'=>true,'persistido'=>true,'persisted'=>true,'changed'=>($old['revisao']??'')!==$out['revisao'],'codigo'=>'catalogo_atualizado','conta'=>$id,'numero_funis'=>count($out['funis']),'numero_etapas'=>count($out['etapas']),'em'=>$out['em'],'completo'=>true,'revisao'=>$out['revisao']);
        }finally{F3Base_Trava::liberar($lock);}
    }
}

