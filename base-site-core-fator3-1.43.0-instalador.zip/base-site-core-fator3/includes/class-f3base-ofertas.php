<?php
/** Offers v2: configuration, rendered-page evidence and Core emission are separate. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Ofertas {
    public const ESTADO='f3base_ofertas_evidencia_v2';
    public const EVENTO='f3base_ofertas_verificar';
    private static array $emitidas=array();
    public static function schema(): array {
        return array('type'=>'object','additionalProperties'=>false,'required'=>array('id','nome','pagina','modalidade'),'properties'=>array(
            'id'=>array('type'=>'string','pattern'=>'^[a-z0-9][a-z0-9_-]{0,79}$'),
            'nome'=>array('type'=>'string','minLength'=>1,'maxLength'=>200),
            'pagina'=>array('type'=>'integer','minimum'=>1),
            'descricao'=>array('type'=>'string','maxLength'=>2000),
            'modalidade'=>array('type'=>'string','enum'=>array('fixo','a_partir_de','sob_consulta')),
            'preco'=>array('type'=>'string','pattern'=>'^(?:0|[1-9][0-9]{0,9})(?:\.[0-9]{1,4})?$'),
            'moeda'=>array('type'=>'string','pattern'=>'^[A-Z]{3}$'),
            'periodo'=>array('type'=>'string','enum'=>array('unico','dia','semana','mes','ano'))
        ));
    }
    public static function validar(array $servicos): array {
        $erros=array();$nomes=array();
        foreach($servicos as $i=>$s){
            if(!is_array($s)){continue;}$nome=mb_strtolower(trim((string)($s['nome']??'')));
            if($nome===''||isset($nomes[$nome])){$erros[]=array('campo'=>'servicos['.$i.'].nome','codigo'=>'servico_sem_identidade_unica','motivo'=>'Informe um nome único por serviço.');}$nomes[$nome]=true;
            $ofertas=$s['ofertas']??array();if(!is_array($ofertas)||!array_is_list($ofertas)){$erros[]=array('campo'=>'servicos['.$i.'].ofertas','codigo'=>'ofertas_invalidas','motivo'=>'Ofertas deve ser uma lista.');continue;}$ids=array();foreach($ofertas as $j=>$o){
                $path='servicos['.$i.'].ofertas['.$j.']';$r=rest_validate_value_from_schema($o,self::schema(),$path);
                if(is_wp_error($r)){$erros[]=array('campo'=>$path,'codigo'=>'oferta_invalida','motivo'=>$r->get_error_message());continue;}
                $erro='';if(isset($ids[$o['id']])){$erro='ID repetido no serviço.';}$ids[$o['id']]=true;
                if($o['modalidade']==='sob_consulta'){
                    if(isset($o['preco'])||isset($o['moeda'])){$erro='Sob consulta não aceita preço nem moeda.';}
                }elseif(!isset($o['preco'],$o['moeda'],$o['periodo'])){$erro='Preço, moeda e período são obrigatórios para preço fixo ou mínimo.';}
                if(!trim($o['nome'])){$erro='Nome do plano não pode ser vazio.';}
                $p=get_post($o['pagina']);if(!$p||!is_post_publicly_viewable($p)||$p->post_password){$erro='A oferta exige uma página pública sem senha.';}
                if($erro){$erros[]=array('campo'=>$path,'codigo'=>'oferta_invalida','motivo'=>$erro);}
            }
        }return $erros;
    }
    /** Invalid stored data remains readable but never becomes public Schema. */
    private static function ofertas_validas(array $s): array {
        $r=array();if(!is_array($s['ofertas']??null)){return $r;}
        foreach($s['ofertas'] as $o){if(is_array($o)&&!self::validar(array(array('nome'=>$s['nome']??'','ofertas'=>array($o))))){$r[]=$o;}}return $r;
    }
    public static function chave(array $s,array $o): string {return hash('sha256',(string)$s['nome'].'|'.(string)$o['id']);}
    public static function contexto(array $s,array $o): string {
        $s=array_replace(array('nome'=>'','descricao'=>'','url'=>'','tipo_servico'=>'','area_servida'=>array()),array_intersect_key($s,array_flip(array('nome','descricao','url','tipo_servico','area_servida'))));
        $p=get_post($o['pagina']);$theme=wp_get_theme();$files=array();
        foreach(array(get_stylesheet_directory().'/style.css',get_stylesheet_directory().'/functions.php',get_stylesheet_directory().'/theme.json') as $file){$files[$file]=is_file($file)?filemtime($file):0;}
        return hash('sha256',wp_json_encode(array($s,$o,$p?array($p->post_content,$p->post_modified_gmt,$p->post_status,$p->post_password):null,get_permalink($o['pagina']),$theme->get_stylesheet(),$theme->get('Version'),F3BASE_PLUGIN_VERSAO,$files,get_theme_mods(),get_option('active_plugins'),self::dependencias((int)$o['pagina']))));
    }
    private static function comercial(array $s,array $o): string {
        $post=get_post($o['pagina']);
        return hash('sha256',wp_json_encode(array(array_intersect_key($s,array_flip(array('nome','descricao','url','tipo_servico','area_servida'))),$o,get_permalink($o['pagina']),$post?array($post->post_status,$post->post_password):null)));
    }
    /** A first render change starts a fixed window. Later edits cannot extend it. */
    private static function validade(array $s,array $o,array $proof,bool $materializar=false): array {
        $same=($proof['contexto']??'')===self::contexto($s,$o);
        if(($proof['conteudo']??'')!=='verified'||($proof['estado']??'')==='ocupado_por_outro_emissor'||(int)($proof['em']??0)<time()-DAY_IN_SECONDS){return array('emitir'=>false,'codigo'=>'evidencia_ausente_divergente_ou_vencida');}
        if($same){return array('emitir'=>true,'codigo'=>'verificada');}
        if(($proof['comercial']??'')!==self::comercial($s,$o)){return array('emitir'=>false,'codigo'=>'oferta_comercial_alterada');}
        $deadline=(int)($proof['transitoria_ate']??0);
        if(!$deadline&&!$materializar){return array('emitir'=>false,'codigo'=>'render_alterado_aguarda_revalidacao');}if(!$deadline){$key=self::chave($s,$o);$r=F3Base_Options::atualizar_estado(self::ESTADO,static function($state)use($key){if(empty($state['itens'][$key]['transitoria_ate'])){$state['itens'][$key]['transitoria_ate']=time()+900;$state['itens'][$key]['mudanca_render_em']=time();}return $state;});if(empty($r['persisted'])){return array('emitir'=>false,'codigo'=>'janela_nao_persistida');}$proof=F3Base_Options::ler(self::ESTADO)['itens'][$key]??array();$deadline=(int)($proof['transitoria_ate']??0);self::agendar();}
        return array('emitir'=>$deadline>time(),'codigo'=>$deadline>time()?'revalidacao_transitoria':'revalidacao_expirada','transitoria_ate'=>$deadline);
    }
    /** Dependências reais da página, sem invalidar pela edição de qualquer post do site. */
    public static function dependencias(int $id): array {
        $out=array();$vistos=array();$scan=static function(string $content,int $depth=0)use(&$scan,&$out,&$vistos){if($depth>10||count($vistos)>100){return;}
            foreach(parse_blocks($content) as $b){$ref=(int)($b['attrs']['ref']??0);if($ref&&($b['blockName']??'')==='core/block'&&!isset($vistos[$ref])){$vistos[$ref]=true;$p=get_post($ref);$out['bloco:'.$ref]=$p?hash('sha256',$p->post_content.'|'.$p->post_status):'ausente';if($p){$scan($p->post_content,$depth+1);}}
                if(($b['blockName']??'')==='core/template-part'){$slug=$b['attrs']['slug']??'';$theme=$b['attrs']['theme']??get_stylesheet();$key=$theme.'//'.$slug;if($slug&&!isset($vistos[$key])){$vistos[$key]=true;$t=get_block_template($key,'wp_template_part');$out['parte:'.$key]=$t?hash('sha256',$t->content):'ausente';if($t){$scan($t->content,$depth+1);}}}
                if(!empty($b['innerBlocks'])){$scan(serialize_blocks($b['innerBlocks']),$depth+1);}
            }};
        $p=get_post($id);if($p){$scan($p->post_content);}if(wp_is_block_theme()){$slug=get_page_template_slug($id);$candidates=$slug?array($slug):array('page-'.($p->post_name??''),'page','singular','index');foreach($candidates as $slug){$t=get_block_template(get_stylesheet().'//'.$slug,'wp_template');if($t){$out['template']=$t->id;$out['template_hash']=hash('sha256',$t->content);$scan($t->content);break;}}}else{$slug=get_page_template_slug($id);$path=locate_template(array_filter(array($slug,'page.php','singular.php','index.php')));if($path){$out['template_hash']=hash_file('sha256',$path);}}
        ksort($out);return $out;
    }
    public static function identificador(array $s,array $o): string {return 'f3base:'.hash_hmac('sha256',self::contexto($s,$o),wp_salt('auth'));}
    public static function no(array $s,array $o): array {
        $url=(string)get_permalink($o['pagina']);$n=array('@type'=>'Offer','@id'=>$url.'#f3base-offer-'.substr(self::chave($s,$o),0,24),'name'=>$o['nome'],'url'=>$url,'identifier'=>self::identificador($s,$o));
        if(!empty($o['descricao'])){$n['description']=$o['descricao'];}
        if($o['modalidade']==='sob_consulta'){return $n;}
        $periodo=$o['periodo'];$prop=$o['modalidade']==='a_partir_de'?'minPrice':'price';$price=$prop==='minPrice'?(float)$o['preco']:$o['preco'];
        if($periodo==='unico'&&$prop==='price'){$n['price']=$price;$n['priceCurrency']=$o['moeda'];return $n;}
        $spec=array('@type'=>$periodo==='unico'?'PriceSpecification':'UnitPriceSpecification',$prop=>$price,'priceCurrency'=>$o['moeda']);
        if($periodo!=='unico'){$spec['referenceQuantity']=array('@type'=>'QuantitativeValue','value'=>1,'unitCode'=>array('dia'=>'DAY','semana'=>'WEE','mes'=>'MON','ano'=>'ANN')[$periodo]);}
        $n['priceSpecification']=$spec;return $n;
    }
    public static function emitir(array $s,int $pagina): array {
        $r=array();$e=(array)F3Base_Options::ler(self::ESTADO);
        foreach(self::ofertas_validas($s) as $o){if(!is_array($o)||($o['pagina']??0)!==$pagina){continue;}
            $k=self::chave($s,$o);$p=$e['itens'][$k]??array();
            $valid=self::validade($s,$o,$p,true);if(!$valid['emitir']){if(($valid['codigo']??'')==='revalidacao_expirada'){F3Base_Cache_Pagina::solicitar(array((string)get_permalink($o['pagina'])));}continue;}
            $n=self::no($s,$o);$r[]=$n;self::$emitidas[$n['@id']]=$n['identifier'];
        }return $r;
    }
    public static function marcador(): void {
        if(self::$emitidas){echo "\n<!-- f3base-ofertas-v2 ".base64_encode(wp_json_encode(self::$emitidas))." -->\n";}
    }
    private static function texto(string $s): string {return trim(preg_replace('/\s+/u',' ',str_replace("\xc2\xa0",' ',html_entity_decode($s,ENT_QUOTES|ENT_HTML5,'UTF-8'))));}
    private static function contem(string $text,string $value): bool {return mb_stripos($text,self::texto($value))!==false;}
    private static function preco_texto(string $text,array $o): bool {
        if($o['modalidade']==='sob_consulta'){return (bool)preg_match('/sob\s+consulta|consulte(?:-nos)?|preço\s+a\s+consultar/iu',$text);}
        $periods=array('dia'=>'(?:por\s+dia|/\s*dia|diári[oa])','semana'=>'(?:por\s+semana|/\s*semana|semanal)','mes'=>'(?:por\s+m[eê]s|/\s*m[eê]s|mensal)','ano'=>'(?:por\s+ano|/\s*ano|anual)');
        $symbols=array('BRL'=>'R\$','USD'=>'US\$','EUR'=>'€','GBP'=>'£');$currency='(?:'.preg_quote($o['moeda'],'~').'|'.($symbols[$o['moeda']]??preg_quote($o['moeda'],'~')).')';
        preg_match_all('~'.$currency.'\s*([0-9]+(?:[.,][0-9]+)*)|([0-9]+(?:[.,][0-9]+)*)\s*'.$currency.'~u',$text,$matches,PREG_SET_ORDER|PREG_OFFSET_CAPTURE);
        foreach($matches as $i=>$m){$n=$m[1][0]!==''?$m[1][0]:($m[2][0]??'');if(str_contains($n,',')){$n=str_replace(',','.',str_replace('.','',$n));}elseif(preg_match('/^[0-9]{1,3}(?:\.[0-9]{3})+$/D',$n)){$n=str_replace('.','',$n);}if(!is_numeric($n)||abs((float)$n-(float)$o['preco'])>=0.00001){continue;}
            // O período pertence ao preço imediatamente anterior; o próximo preço encerra o segmento.
            $start=$m[0][1]+strlen($m[0][0]);$end=$matches[$i+1][0][1]??strlen($text);$after=substr($text,$start,min(100,$end-$start));
            $before=substr($text,max(0,$m[0][1]-40),min(40,$m[0][1]));$minimum=(bool)preg_match('/(?:a\s+partir\s+de|desde)\s*$/iu',$before);
            if(($o['modalidade']==='a_partir_de')!==$minimum){continue;}
            if($o['periodo']==='unico'){if(!preg_match('~'.implode('|',$periods).'~iu',$after)){return true;}continue;}
            if(preg_match('~'.$periods[$o['periodo']].'~iu',$after,$found,PREG_OFFSET_CAPTURE)){
                $target=$found[0][1];$other=false;foreach($periods as $k=>$pattern){if($k!==$o['periodo']&&preg_match('~'.$pattern.'~iu',$after,$f,PREG_OFFSET_CAPTURE)&&$f[0][1]<=$target){$other=true;}}if(!$other){return true;}
            }
        }
        return (float)$o['preco']===0.0&&$o['modalidade']==='fixo'&&$o['periodo']==='unico'&&(bool)preg_match('/\b(grátis|gratuito|gratuita)\b/iu',$text)&&!preg_match('/teste|trial|diagnóstico/iu',$text);
    }
    /** HTML only; scripts, hidden markup and schema cannot prove visible prices. */
    public static function analisar(string $html,array $s,array $o,array $nomes=array()): array {
        $doc=new DOMDocument();$old=libxml_use_internal_errors(true);try{$doc->loadHTML('<?xml encoding="utf-8" ?>'.$html,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);}finally{libxml_clear_errors();libxml_use_internal_errors($old);}
        $xp=new DOMXPath($doc);foreach(iterator_to_array($xp->query('//script|//style|//template|//noscript|//head|//*[@hidden or @aria-hidden="true"]')) as $n){if($n->parentNode){$n->parentNode->removeChild($n);}}
        foreach(iterator_to_array($xp->query('//*[@style]')) as $n){if(preg_match('/display\s*:\s*none|visibility\s*:\s*hidden/i',$n->getAttribute('style'))&&$n->parentNode){$n->parentNode->removeChild($n);}}
        $candidates=array();foreach($xp->query('//article|//section|//li|//div|//tr|//p|//*[@data-f3base-oferta]') as $n){
            $text=self::texto($n->textContent);if(mb_strlen($text)>1800||!self::contem($text,$o['nome'])){continue;}
            $marks=array();$cursor=$n;while($cursor instanceof DOMElement){$local=array();if($cursor->hasAttribute('data-f3base-oferta')){$local[]=$cursor->getAttribute('data-f3base-oferta');}preg_match_all('/(?:^|\s)f3base-oferta-([a-z0-9_-]+)(?=\s|$)/',$cursor->getAttribute('class'),$matches);$local=array_unique(array_merge($local,$matches[1]));if($local){$marks=$local;break;}$cursor=$cursor->parentNode;}
            if(count($marks)>1||($marks&&$marks[0]!==$o['id'])){continue;}
            $other=false;if(!$marks){foreach($nomes as $otherOffer){if(!is_array($otherOffer)||($otherOffer['id']??'')===$o['id']){continue;}if(self::contem($text,$otherOffer['nome'])&&self::preco_texto($text,$otherOffer)){$other=true;break;}}}
            if($other||!self::preco_texto($text,$o)){continue;}
            if(!empty($o['descricao'])&&!self::contem($text,$o['descricao'])){continue;}
            $candidates[]=array('texto'=>$text,'regiao'=>$n->getAttribute('id')?:($n->getAttribute('data-f3base-oferta')?:$n->nodeName));
        }
        if(!$candidates){return array('conteudo'=>'inconclusivo','codigo'=>'associacao_publica_nao_comprovada');}
        usort($candidates,static fn($a,$b)=>strlen($a['texto'])<=>strlen($b['texto']));$c=$candidates[0];
        return array('conteudo'=>'verified','codigo'=>'oferta_no_html_publico','regiao'=>$c['regiao'],'trecho'=>mb_substr($c['texto'],0,600),'sha256'=>hash('sha256',$c['texto']));
    }
    private static function nos(string $html): array {
        $nodes=array();$walk=static function($v,int $depth=0)use(&$walk,&$nodes){if(!is_array($v)||$depth>64||count($nodes)>10000){return;}if(isset($v['@type'])){$nodes[]=$v;}foreach($v as $x){if(is_array($x)){$walk($x,$depth+1);}}};
        if(preg_match_all('~<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>~is',$html,$m)){foreach($m[1] as $json){$walk(json_decode($json,true));}}return $nodes;
    }
    public static function observar(string $html,string $url): array {
        $config=F3Base_Options::ler('f3base_seo_entidade');$rev=F3Base_Options::revisao('f3base_seo_entidade');$itens=array();$nodes=self::nos($html);$markers=array();
        if(preg_match('~<!-- f3base-ofertas-v2 ([A-Za-z0-9+/=]+) -->~',$html,$m)){$markers=json_decode((string)base64_decode($m[1],true),true)?:array();}
        foreach($config['servicos']??array() as $s){$nomes=self::ofertas_validas($s);foreach(self::ofertas_validas($s) as $o){
            if((string)get_permalink($o['pagina'])!==$url){continue;}$key=self::chave($s,$o);$no=self::no($s,$o);$proof=self::analisar($html,$s,$o,$nomes);$state=$proof['conteudo']==='verified'?'verificacao_pendente':'divergente';$conflict=null;$published=false;
            foreach($nodes as $node){if(in_array('Service',(array)$node['@type'],true)&&($node['name']??'')===$s['nome']&&($node['@id']??'')!==home_url('/#/schema/service/'.md5($s['nome']))){$conflict=array('id'=>$node['@id']??null,'nome'=>$node['name'],'origem'=>'outro_emissor_ou_nao_identificada');}
                if(($node['@id']??'')===$no['@id']&&($markers[$no['@id']]??'')===$no['identifier']&&F3Base_Options::equivalente($node,$no)){$published=true;}
            }
            if($conflict){$state='ocupado_por_outro_emissor';}elseif($published&&$proof['conteudo']==='verified'){$state='publicada';}
            $itens[$key]=$proof+array('estado'=>$state,'contexto'=>self::contexto($s,$o),'comercial'=>self::comercial($s,$o),'em'=>time(),'url'=>$url,'servico'=>$s['nome'],'oferta'=>$o['id'],'no_id'=>$no['@id'],'conflito'=>$conflict,'emissor_confirmado'=>$published);
        }}
        if($itens&&hash_equals($rev,F3Base_Options::revisao('f3base_seo_entidade'))){$previous=F3Base_Options::ler(self::ESTADO)['itens']??array();$purge=false;foreach($itens as $k=>$now){$old=$previous[$k]??array();$eligible=static fn($p)=>($p['conteudo']??'')==='verified'&&($p['estado']??'')!=='ocupado_por_outro_emissor'&&($p['em']??0)>time()-DAY_IN_SECONDS; if($eligible($now)!==$eligible($old)||($now['contexto']??'')!==($old['contexto']??'')){$purge=true;}}$result=F3Base_Options::atualizar_estado(self::ESTADO,static function($old)use($itens,$rev){if(!hash_equals($rev,F3Base_Options::revisao('f3base_seo_entidade'))){return null;}$old['contrato']=2;$old['itens']=array_replace($old['itens']??array(),$itens);return $old;});if(empty($result['persisted'])){return array('codigo'=>'evidencia_nao_persistida');}if($purge){F3Base_Cache_Pagina::solicitar(array($url));}}
        return array('itens'=>array_values($itens));
    }
    public static function consultar(): array {
        $e=(array)F3Base_Options::ler(self::ESTADO);$r=array();
        foreach(F3Base_Options::ler('f3base_seo_entidade')['servicos']??array() as $s){foreach(self::ofertas_validas($s) as $o){$p=$e['itens'][self::chave($s,$o)]??array();$valid=self::validade($s,$o,$p);if($valid['codigo']!=='verificada'){$p=array_merge($p,$valid,array('estado'=>$valid['emitir']?'revalidacao_transitoria':'verificacao_pendente'));}$r[]=array('servico'=>$s['nome'],'oferta'=>$o['id'],'nome'=>$o['nome'],'pagina'=>$o['pagina'])+$p;}}
        return array('contrato'=>2,'itens'=>$r,'erros'=>self::validar(F3Base_Options::ler('f3base_seo_entidade')['servicos']??array()),'configuracao_alterada'=>false);
    }
    public static function iniciar(): void {
        add_action('wp_head',array(__CLASS__,'marcador'),PHP_INT_MAX);
        add_action(self::EVENTO,F3Base_Operacao::callback(self::EVENTO,array(__CLASS__,'cron')));
        add_action('save_post',array(__CLASS__,'agendar'));
        add_action('switch_theme',array(__CLASS__,'agendar'));
        add_action('updated_option',static function($nome){if(in_array($nome,array('f3base_seo_entidade','active_plugins','permalink_structure'),true)||str_starts_with($nome,'theme_mods_')){self::agendar();}},10,1);
        add_action('init',static function(){if(!wp_next_scheduled(self::EVENTO)&&self::paginas()){F3Base_Fila::agendar(self::EVENTO,time()+60);}});
    }
    public static function agendar(): void {
        if(!self::paginas()){return;}F3Base_Fila::agendar(self::EVENTO,time()+30);
    }
    public static function paginas(): array {$r=array();foreach(F3Base_Options::ler('f3base_seo_entidade')['servicos']??array() as $s){foreach(self::ofertas_validas($s) as $o){$r[]=(string)get_permalink($o['pagina']);}}return array_values(array_unique($r));}
    public static function cron(): void {
        $pages=self::paginas();if(!$pages){return;}$e=(array)F3Base_Options::ler(self::ESTADO);$cursor=(int)($e['cursor']??0);$batch=array_slice($pages,$cursor,5);if(!$batch){$cursor=0;$batch=array_slice($pages,0,5);}
        $fim=microtime(true)+20;$n=0;foreach($batch as $url){if(microtime(true)>$fim){break;}$h=F3Base_Http_Publico::buscar($url,2097152,$fim,'GET',F3Base_Testes::cabecalhos($url,true));if(!empty($h['ok'])){self::observar($h['corpo'],$url);}else{F3Base_Cache_Pagina::solicitar(array($url));}++$n;}
        $next=$cursor+$n;$pending=$next<count($pages);F3Base_Options::atualizar_estado(self::ESTADO,static function($v)use($next,$pending){$v['cursor']=$pending?$next:0;return $v;});$states=self::consultar()['itens'];$waiting=(bool)array_filter($states,static fn($r)=>in_array($r['estado'],array('revalidacao_transitoria','verificacao_pendente'),true));F3Base_Fila::agendar(self::EVENTO,$pending||$waiting?time()+60:F3Base_Operacao::proximo_horario('00:00',array('00:00','12:00')));
    }
}
