<?php
/** Textos de confirmação e avisos; a configuração não altera destinos ou decisões. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Textos_Contato {
    public const CAMPOS = array(
        'confirmacao_titulo' => array('Título da confirmação', 'Confirmação'),
        'confirmacao_expirada' => array('Confirmação expirada', 'Esta confirmação expirou. Volte ao formulário para continuar.'),
        'confirmacao_indisponivel' => array('Confirmação indisponível', 'Não foi possível abrir esta confirmação.'),
        'confirmacao_continuar' => array('Botão para continuar após a confirmação', 'Continuar'),
        'whatsapp_acessivel' => array('Nome acessível do botão de WhatsApp', 'Conversar pelo WhatsApp (abre em nova aba)'),
        'aviso_titulo' => array('Título do aviso de novo contato', 'Novo contato recebido'),
        'aviso_teste' => array('Título do aviso de contato de teste', 'Contato de teste'),
        'aviso_consultar' => array('Link para abrir o contato', 'Consultar contato no WordPress'),
        'aviso_login' => array('Orientação de acesso ao contato', 'O acesso ao registro exige login autorizado.'),
        'resumo_assunto' => array('Assunto do resumo de contatos', 'Resumo de contatos'),
        'resumo_titulo' => array('Título do resumo de contatos', 'Resumo de {quantidade} contatos'),
        'resumo_introducao' => array('Apresentação do resumo de contatos', '{quantidade} contatos destinados a esta equipe aguardam atendimento.'),
    );

    public static function catalogo(array $catalogo): array {
        $catalogo['f3base_contato']['rotulo'] = 'Contato, confirmação e textos dos avisos';
        $catalogo['f3base_contato']['recusa'] = array(__CLASS__, 'recusar');
        foreach (self::CAMPOS as $key => [$label, $default]) {
            $field = 'texto_' . $key;
            $catalogo['f3base_contato']['padrao'][$field] = $default;
            $catalogo['f3base_contato']['subcampos'][$field] = array('tipo'=>'texto', 'rotulo'=>$label,
                'descricao'=>str_starts_with($key, 'resumo_') ? 'Texto do resumo enviado à equipe. Use {quantidade} para incluir o número de contatos.' : 'Texto usado neste momento da confirmação ou do aviso. Confira o resultado na prévia abaixo.',
                'impacto'=>'Muda a apresentação das próximas mensagens, sem reenviar avisos nem alterar permissões ou destinos.',
                'exemplo'=>$default);
            foreach (array('schema_config', 'schema_entrada') as $schema) {
                $catalogo['f3base_contato'][$schema]['properties'][$field] = array('type'=>'string', 'maxLength'=>1000);
            }
        }
        return $catalogo;
    }

    public static function recusar($value): string {
        if (!is_array($value)) { return 'Envie os campos de contato e mensagens.'; }
        foreach (self::CAMPOS as $key => [$label]) {
            $field = 'texto_' . $key;
            if (array_key_exists($field, $value) && (!is_string($value[$field]) || mb_strlen($value[$field]) > 1000)) { return $label . ': informe um texto de até 1.000 caracteres.'; }
        }
        return '';
    }

    public static function sanitizar(array $value): array {
        $out = array();
        foreach (self::CAMPOS as $key => $_) {
            $field = 'texto_' . $key;
            if (isset($value[$field]) && is_string($value[$field])) { $out[$field] = mb_substr(sanitize_text_field($value[$field]), 0, 1000); }
        }
        return $out;
    }

    public static function ler(string $key, array $vars=array()): string {
        $default = self::CAMPOS[$key][1] ?? '';
        $cfg = F3Base_Options::ler('f3base_contato');
        $text = $cfg['texto_'.$key] ?? $default;
        $text = is_string($text) && trim($text) !== '' ? $text : $default;
        $map = array();
        foreach ($vars as $name => $value) { if (is_scalar($value)) { $map['{'.$name.'}'] = sanitize_text_field((string)$value); } }
        return strtr($text, $map);
    }

    public static function previa(): void {
        echo '<section class="f3base-config-grupo"><h2>Prévia de confirmação e avisos</h2><p>Exemplos com três contatos fictícios. Textos vazios usam o padrão indicado no campo. Salve para atualizar esta prévia.</p><dl>';
        foreach (self::CAMPOS as $key => [$label]) { echo '<dt>'.esc_html($label).'</dt><dd>'.esc_html(self::ler($key, array('quantidade'=>3))).'</dd>'; }
        echo '</dl></section>';
    }
}
