<?php
/** References captured with the contact; guards for consent retention. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Leads_Consentimento {
    private static function chave(): string { global $wpdb; return 'f3core:cons:'.substr(hash('sha256',DB_NAME.$wpdb->prefix),0,40); }
    public static function travar(): bool { global $wpdb; return (string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,1)',self::chave()))==='1'; }
    public static function liberar(): void { global $wpdb; $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',self::chave())); }
    public static function referencia(array $dados): ?string {
        $p=$dados['consentimento_snapshot']??array(); if(!is_array($p)){return null;}
        $a=$p['decisao_ref']??''; $b=$p['ref']??'';
        if($a&&$b&&$a!==$b){return null;} $ref=$a?:$b;
        return is_string($ref)&&preg_match('/^[a-f0-9]{64}$/D',$ref)?$ref:null;
    }
    /** Fail closed on malformed or unindexed references; never rewrite historical data. */
    public static function pronto(): bool {return !empty(self::resumo()['ok']);}
    public static function resumo(int $pagina=1): array {
        global $wpdb;unset($pagina);if(!F3Base_Leads_Repositorio::pronto()){return array('ok'=>false,'codigo'=>'leads_estrutura_indisponivel');}
        $t=F3Base_Leads_Repositorio::tabela();
        $json="IF(JSON_VALID(dados),dados,'{}')";$a="NULLIF(NULLIF(JSON_UNQUOTE(JSON_EXTRACT({$json},'$.consentimento_snapshot.decisao_ref')),''),'null')";$b="NULLIF(NULLIF(JSON_UNQUOTE(JSON_EXTRACT({$json},'$.consentimento_snapshot.ref')),''),'null')";
        $bad=$wpdb->get_var($wpdb->prepare("SELECT id FROM %i WHERE NOT JSON_VALID(dados) OR ({$a} IS NOT NULL AND {$b} IS NOT NULL AND {$a}<>{$b}) OR (COALESCE({$a},{$b},'')<>'' AND (COALESCE({$a},{$b}) NOT REGEXP '^[a-f0-9]{64}$' OR NOT (decisao_ref <=> COALESCE({$a},{$b})))) LIMIT 1",$t));
        return array('ok'=>!$wpdb->last_error&&$bad===null,'codigo'=>$wpdb->last_error?'leitura_referencias_falhou':($bad!==null?'referencia_sem_indice_expurgo_bloqueado':'referencias_atuais'),'preenchimento_historico'=>false,'captura'=>'Referência gravada junto ao contato; expurgo confere vínculos e consentimentos da apresentação.');
    }
}
