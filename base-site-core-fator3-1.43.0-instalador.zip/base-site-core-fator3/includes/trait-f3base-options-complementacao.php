<?php
/** Complementação técnica sem substituir a procedência da configuração. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
trait F3Base_Options_Complementacao {
    private static function caminhos_acrescentados($antes, $depois, string $prefixo=''): array {
        $r=array(); if (!is_array($antes)||!is_array($depois)) { return $r; }
        foreach ($depois as $k=>$v) {
            $path=$prefixo.(string)$k;
            if (!array_key_exists($k,$antes)) { $r[]=$path; }
            elseif (is_array($v)&&!array_is_list($v)) { $r=array_merge($r,self::caminhos_acrescentados($antes[$k],$v,$path.'.')); }
        }
        return $r;
    }
    /** Não dispara efeitos comerciais; o instalador verifica e retoma cada etapa. */
    public static function complementar_padrao(string $nome, $padrao, string $versao, $transformacao=null): array {
        $f=self::fotografia_bruta($nome); if ($f['erro']) { return array('ok'=>false,'codigo'=>'leitura_falhou'); }
        if (!$f['existe']) { $r=self::gravar($nome,$padrao,self::ORIGEM_PADRAO,$f['revisao']);return array_merge($r,array('ok'=>!empty($r['persisted'])&&in_array($r['audit']['status']??'not_required',array('recorded','not_required'),true))); }
        $novo=$transformacao!==null?$transformacao($f['valor']):F3Base_Configuracao_Medicao::completar($f['valor'],$padrao);
        $ajustadas=array();if($nome==='f3base_formularios'&&is_array($novo)){foreach($novo as &$form){if(is_array($form)&&!array_key_exists('whatsapp_nova_aba',$form)){$form['whatsapp_nova_aba']=true;}}unset($form);}
        if ($nome==='f3base_pipedrive'&&is_array($novo)&&array_key_exists('pais_telefone',$novo)&&$novo['pais_telefone']==='') { $novo['pais_telefone']='BR'; $ajustadas[]='pais_telefone'; }
        $journal=self::fotografia('f3base_config_complementacoes');
        if ($journal['erro']) { return array('ok'=>false,'codigo'=>'historico_indisponivel'); }
        $pendente=$journal['valor']['pendentes'][$nome]??null;
        if (self::equivalente($novo,$f['valor'])) {
            if (is_array($pendente)&&hash_equals($pendente['revisao_depois'],$f['revisao'])) { return self::concluir_complementacao($nome,$pendente); }
            return array('ok'=>true,'persisted'=>true,'codigo'=>'sem_alteracao','revisao'=>$f['revisao']);
        }
        $declaracao=self::declaracao($nome);$recusa=self::recusar($nome,$novo,$declaracao);
        if($recusa!==''){return array('ok'=>false,'codigo'=>'valor_recusado','motivo'=>$recusa,'persisted'=>false);}
        $prov=self::fotografia(self::OPTION_PROVENIENCIA);
        if ($prov['erro']) { return array('ok'=>false,'codigo'=>'procedencia_indisponivel'); }
        $anterior=$prov['valor'][$nome]??null;
        $rev= self::revisao_do_bruto($nome,array('option_value'=>(string)maybe_serialize($novo)));
        $id=hash('sha256',$nome.'|'.$versao.'|'.$f['revisao'].'|'.$rev.'|'.wp_json_encode($anterior));
        $evento=array('id'=>$id,'versao'=>$versao,'em'=>time(),'operacao'=>$transformacao!==null?'migrar_estrutura':'completar_padroes','subchaves_acrescentadas'=>self::caminhos_acrescentados($f['valor'],$novo),'subchaves_ajustadas'=>$ajustadas,'revisao_antes'=>$f['revisao'],'revisao_depois'=>$rev,'procedencia_anterior'=>$anterior);
        $save=self::atualizar_estado('f3base_config_complementacoes',static function($s)use($nome,$evento,$f){
            if (!hash_equals($f['revisao'],self::revisao($nome))) { return null; }
            $s=is_array($s)?$s:array(); $s['pendentes'][$nome]=$evento; return $s;
        });
        if (empty($save['persisted'])) { return array('ok'=>false,'codigo'=>'checkpoint_complementacao_falhou'); }
        $d=self::declaracao($nome); $aplicada=false;
        self::$escritas_em_curso[$nome]=(self::$escritas_em_curso[$nome]??0)+1;
        try { $ok=self::escrever_condicional($nome,$novo,(bool)($d['autoload']??true),$f['revisao'],$aplicada); }
        finally { --self::$escritas_em_curso[$nome]; }
        if (!$ok) { return array('ok'=>false,'codigo'=>'complementacao_conflito_ou_falha','persisted'=>$aplicada); }
        return self::concluir_complementacao($nome,$evento);
    }
    private static function concluir_complementacao(string $nome,array $evento): array {
        $rev=$evento['revisao_depois'];
        if (!hash_equals($rev,self::revisao($nome))) { return array('ok'=>false,'codigo'=>'complementacao_revisao_divergente'); }
        $antes=$evento['procedencia_anterior'];
        $r=self::atualizar_estado(self::OPTION_PROVENIENCIA,static function($s)use($nome,$evento,$antes,$rev){
            if (!hash_equals($rev,self::revisao($nome))) { return null; }
            $s=is_array($s)?$s:array(); $atual=$s[$nome]??null;
            if (($atual['complementacao_id']??'')===$evento['id']) { return $s; }
            if ($atual!==$antes) { return null; }
            $confirmado=is_array($antes)&&in_array($antes['origem']??'',self::origens(),true)&&hash_equals($evento['revisao_antes'],(string)($antes['revisao']??''));
            $entry=is_array($antes)?$antes:array();
            $entry['revisao_configuracao']=$entry['revisao_configuracao']??($entry['revisao']??'');
            $entry['revisao']=$rev; $entry['complementacao_id']=$evento['id'];
            $entry['composicao']=$confirmado?(($entry['origem']===self::ORIGEM_PADRAO)?'padrao_integral':'configurado_complementado'):'desconhecido';
            if (!$confirmado) { $entry['origem']=self::ORIGEM_DESCONHECIDA; }
            $s[$nome]=$entry; return $s;
        });
        if (empty($r['persisted'])) { return array('ok'=>false,'persisted'=>true,'codigo'=>'complementacao_auditoria_pendente'); }
        $saved=self::atualizar_estado('f3base_config_complementacoes',static function($s)use($nome,$evento,$rev){
            if (!hash_equals($rev,self::revisao($nome))) { return null; }
            $s['eventos'][$nome][$evento['id']]=$evento; unset($s['pendentes'][$nome]); return $s;
        });
        return array('ok'=>!empty($saved['persisted']),'persisted'=>true,'codigo'=>empty($saved['persisted'])?'complementacao_historico_pendente':'complementacao_confirmada','revisao'=>$rev,'subchaves_acrescentadas'=>$evento['subchaves_acrescentadas']);
    }
    public static function complementacoes(string $nome,int $pagina=1): array {
        $s=get_option('f3base_config_complementacoes',array());$all=array_values($s['eventos'][$nome]??array());
        $rows=array_slice($all,(max(1,$pagina)-1)*20,20);
        foreach($rows as &$row){unset($row['procedencia_anterior']);}unset($row);
        return array('eventos'=>$rows,'total'=>count($all),'pagina'=>max(1,$pagina),'proxima_pagina'=>count($all)>max(1,$pagina)*20?$pagina+1:null,'pendente'=>isset($s['pendentes'][$nome]),'reparo'=>$s['reparos'][$nome]??null);
    }
}
