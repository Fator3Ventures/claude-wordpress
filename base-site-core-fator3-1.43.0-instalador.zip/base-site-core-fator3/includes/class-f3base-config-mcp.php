<?php
/**
 * A configuração do implantador, lida e escrita pelo agente MCP.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Abilities de edição dos JSONs para a próxima execução do implantador.
 * Não aplicam configuração no site; dependência de arquivos isolada no adaptador.
 */
final class F3Base_Config_Mcp {

	/**
	 * Arquivos que a habilidade conhece, e o schema de cada um.
	 *
	 * @var array<string,array<string,string>>
	 */

	/**
	 * Registra as habilidades quando a API existir.
	 *
	 * O GANCHO E A CATEGORIA MORAM EM `F3Base_Site_Core::iniciar()`:
	 * `wp_abilities_api_init` (com o prefixo `wp_`, que é a grafia que o núcleo
	 * dispara) e `wp_abilities_api_categories_init`, que registra `f3base` antes.
	 * As duas coisas foram medidas num WordPress real: sem a categoria o núcleo
	 * recusa a habilidade, e no gancho sem prefixo nada é sequer chamado.
	 *
	 * @return void
	 */
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		F3Base_Servicos::registrar_ability(
			'f3base/config-ler',
			array(
				'label'               => __( 'Ler a configuração do implantador', 'f3base' ),
				'description'         => __( 'Lê os JSONs de entrada do implantador e seus schemas. Estes arquivos descrevem uma implantação futura; o estado aplicado no site é consultado por f3base/config-core-ler e pelo contrato do Core.', 'f3base' ),
				'category'            => F3BASE_PREFIXO,
				/*
				 * `PROPERTIES` É ARRAY PHP, e isso não é descuido de serialização: um
				 * mapa com chaves de texto já sai como `{}` no JSON. O DEFEITO MEDIDO
				 * era `(object) array(...)` aqui e em `config-escrever`: o núcleo
				 * indexa `properties` como array ao validar cada campo da entrada
				 * (`rest_validate_object_value_from_schema`), e um `stdClass` derruba
				 * a chamada com Error antes de o callback existir — a habilidade
				 * estava no registro e morria com a entrada que o próprio schema pede.
				 * Medido em `wp.habilidades_de_config_executam`.
				 */
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'arquivo' => array(
							'type'        => 'string',
							'enum'        => array( 'projeto', 'site' ),
							'description' => __( '"projeto" é o arquivo que o operador preenche; "site" guarda conteúdo e referências internas.', 'f3base' ),
						),
					),
					'required'             => array( 'arquivo' ),
					'additionalProperties' => false,
				),
				'output_schema'       => self::schema_da_leitura(),
				'execute_callback'    => array( __CLASS__, 'ler' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array(
						'public' => true,
						'type'   => 'tool',
					),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
				'permission_callback' => static function ( $entrada = null ): bool {
					unset( $entrada );

					return current_user_can( 'manage_options' );
				},
			)
		);

		F3Base_Servicos::registrar_ability(
			'f3base/config-escrever',
			array(
				'label'               => __( 'Escrever a configuração do implantador', 'f3base' ),
				'description'         => __( 'Edita somente o JSON do implantador, após validar o schema. Não aplica opções ao site. A execução do implantador deve usar a API do dono e respeitar sua recusa; para configuração imediata do Core use f3base/config-core-escrever.', 'f3base' ),
				'category'            => F3BASE_PREFIXO,
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'arquivo'  => array(
							'type'        => 'string',
							'enum'        => array( 'projeto', 'site' ),
							'description' => __( 'Qual dos dois pares de arquivo e schema será gravado.', 'f3base' ),
						),
						'conteudo' => array(
							'type'        => 'object',
							'description' => __( 'O arquivo INTEIRO, não um pedaço: leia antes, altere o que precisa e devolva o todo.', 'f3base' ),
						),
					),
					'required'             => array( 'arquivo', 'conteudo' ),
					'additionalProperties' => false,
				),
				'output_schema'       => self::schema_da_escrita(),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array(
						'public' => true,
						'type'   => 'tool',
					),
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
				'execute_callback'    => array( __CLASS__, 'escrever' ),
				'permission_callback' => static function ( $entrada = null ): bool {
					unset( $entrada );

					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	/**
	 * O QUE `config-ler` DEVOLVE, campo a campo.
	 *
	 * `ok` é o campo que decide, e ele existe nos dois desfechos: a resposta de
	 * erro traz `ok: false` e `erro`, e nunca conteúdo pela metade.
	 *
	 * @return array<string,mixed>
	 */
	public static function schema_da_leitura(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'scope'               => array(
					'type' => 'string',
					'enum' => array( 'installer_json' ),
				),
				'site_config_applied' => array(
					'type'        => 'boolean',
					'description' => 'Sempre false: esta operação edita apenas o arquivo de entrada do implantador.',
				),
				'ok'                  => array(
					'type'        => 'boolean',
					'description' => __( 'Falso quando não houve leitura: o motivo está em "erro" e nenhum outro campo é confiável.', 'f3base' ),
				),
				'erro'                => array(
					'type'        => 'string',
					'description' => __( 'O que impediu a leitura, em português: implantador ausente, arquivo inexistente ou JSON ilegível.', 'f3base' ),
				),
				'arquivo'             => array(
					'type'        => 'string',
					'description' => __( 'Caminho relativo lido, dentro do diretório do implantador.', 'f3base' ),
				),
				'conteudo'            => array(
					'type'        => 'object',
					'description' => __( 'O arquivo de configuração inteiro, decodificado.', 'f3base' ),
				),
				'schema'              => array(
					'type'        => 'object',
					'description' => __( 'O schema correspondente, com um $comment por campo dizendo o que preencher e onde obter o valor.', 'f3base' ),
				),
				'como'                => array(
					'type'        => 'string',
					'description' => __( 'Como gravar de volta o que foi lido.', 'f3base' ),
				),
			),
			'required'   => array( 'ok' ),
		);
	}

	/**
	 * O QUE `config-escrever` DEVOLVE, campo a campo.
	 *
	 * @return array<string,mixed>
	 */
	public static function schema_da_escrita(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'scope'               => array(
					'type' => 'string',
					'enum' => array( 'installer_json' ),
				),
				'site_config_applied' => array(
					'type'        => 'boolean',
					'description' => 'Sempre false: esta operação edita apenas o arquivo de entrada do implantador.',
				),
				'ok'                  => array(
					'type'        => 'boolean',
					'description' => __( 'Falso quando nada foi gravado.', 'f3base' ),
				),
				'gravou'              => array(
					'type'        => 'boolean',
					'description' => __( 'Verdadeiro só quando o arquivo foi substituído por inteiro e a contagem de bytes conferiu.', 'f3base' ),
				),
				'erro'                => array(
					'type'        => 'string',
					'description' => __( 'O que impediu a gravação. Escrita é tudo ou nada: com erro, o arquivo continua exatamente como estava.', 'f3base' ),
				),
				'campos'              => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => __( 'Os campos que não passaram no schema, um por item.', 'f3base' ),
				),
				'arquivo'             => array(
					'type'        => 'string',
					'description' => __( 'Caminho relativo gravado.', 'f3base' ),
				),
				'bytes'               => array(
					'type'        => 'integer',
					'description' => __( 'Tamanho conferido do arquivo depois da substituição.', 'f3base' ),
				),
				'aviso'               => array(
					'type'        => 'string',
					'description' => __( 'Quando o valor gravado passa a valer.', 'f3base' ),
				),
			),
			'required'   => array( 'ok' ),
		);
	}

    public static function diretorios(): array { return F3Base_Implantador_Adaptador::diretorios(); }
    public static function diretorio(): string { return F3Base_Implantador_Adaptador::diretorio(); }
    public static function ler($entrada=null): array { return F3Base_Implantador_Adaptador::ler($entrada); }
    public static function escrever($entrada=null): array { return F3Base_Implantador_Adaptador::escrever($entrada); }
    public static function validar(array $dados,string $schema): array { return F3Base_Implantador_Adaptador::validar($dados,$schema); }
}
