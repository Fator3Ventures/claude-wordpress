<?php
/** LinkedIn Lead Sync 202609. Only current public contracts, never legacy adForms. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Linkedin_Api {
    const VERSAO='202609';
    const TOKEN='f3base_anuncios_linkedin_token';
    const SECRET='f3base_anuncios_linkedin_client_secret';
    const CAMPOS='ownerInfo,associatedEntityInfo,leadMetadataInfo,owner,leadType,leadMetadata,associatedEntity,versionedLeadGenFormUrn,id,responseId,submittedAt,testLead,formResponse,form:(hiddenFields,creationLocale,name,id,versionId,content)';
    private static float $prazo=0;
    public static function prazo(float $at): void {self::$prazo=$at;}
    private static function valor($v): string {if(is_array($v)){$pairs=array();foreach($v as $k=>$x){$pairs[]=rawurlencode((string)$k).':'.self::valor($x);}return '('.implode(',',$pairs).')';}return rawurlencode(is_bool($v)?($v?'true':'false'):(string)$v);}
    public static function query(array $q): string {$parts=array();foreach($q as $k=>$v){$parts[]=rawurlencode((string)$k).'='.($k==='fields'?(string)$v:self::valor($v));}return implode('&',$parts);}
    public static function pedir(string $method,string $path,array $data=array()): array {
        $read=$method==='GET'&&preg_match('~^(leadForms(?:/[0-9]+)?|leadFormResponses(?:/[A-Za-z0-9_-]+)?|leadNotifications(?:/[0-9]+)?|adAccounts/[0-9]+|adAccountUsers|organizationAcls)$~D',$path);
        $write=$method==='POST'&&$path==='leadNotifications';$del=$method==='DELETE'&&preg_match('~^leadNotifications/[0-9]+$~D',$path);
        if(!$read&&!$write&&!$del){return array('ok'=>false,'codigo'=>'rota_linkedin_recusada');}
        $token=F3Base_Segredos::abrir(self::TOKEN);if($token===''){return array('ok'=>false,'codigo'=>'credencial_ausente');}
        $state=F3Base_Linkedin_Integracoes::estado();if((int)($state['pausa_ate']??0)>time()){return array('ok'=>false,'codigo'=>'linkedin_aguarda_limite','retry_after'=>$state['pausa_ate']-time());}
        $remaining=self::$prazo?self::$prazo-microtime(true):10;if($remaining<2){return array('ok'=>false,'codigo'=>'linkedin_orcamento_execucao','retry_after'=>60);}
        $args=array('method'=>$method,'timeout'=>min(8,max(1,(int)($remaining-1))),'redirection'=>0,'sslverify'=>true,'limit_response_size'=>1048576,'headers'=>array('Authorization'=>'Bearer '.$token,'LinkedIn-Version'=>self::VERSAO,'X-Restli-Protocol-Version'=>'2.0.0','Accept'=>'application/json','Content-Type'=>'application/json'));
        $url='https://api.linkedin.com/rest/'.$path;if($method==='GET'&&$data){$url.='?'.self::query($data);}elseif($write){$args['body']=wp_json_encode($data);}
        $r=wp_remote_request($url,$args);unset($args,$token);
        if(is_wp_error($r)){return array('ok'=>false,'codigo'=>'linkedin_transporte_sem_confirmacao','incerto'=>$write||$del,'retry_after'=>60);}
        $http=wp_remote_retrieve_response_code($r);$body=wp_remote_retrieve_body($r);$json=$body!==''?json_decode($body,true,64,JSON_BIGINT_AS_STRING):array();
        $retry=(string)wp_remote_retrieve_header($r,'retry-after');$after=ctype_digit($retry)?(int)$retry:max(0,(int)strtotime($retry)-time());
        if($http===429){$after=max(60,min(DAY_IN_SECONDS,$after));F3Base_Linkedin_Integracoes::atualizar_estado(static fn($s)=>array_merge($s,array('pausa_ate'=>time()+$after)));}
        $ok=$http>=200&&$http<300&&is_array($json);$id=(string)wp_remote_retrieve_header($r,'x-restli-id');
        return array('ok'=>$ok,'http'=>$http,'data'=>$ok?$json:array(),'id'=>$id,'codigo'=>$ok?'linkedin_aceitou':(in_array($http,array(401,403),true)?'linkedin_credencial_ou_permissao_recusada':($http===429?'linkedin_limite_remoto':($http===404?'linkedin_referencia_ausente':'linkedin_resposta_recusada'))),'retry_after'=>max(60,$after),'incerto'=>($write||$del)&&($http>=500||($http>=200&&$http<300&&!$ok)));
    }
    public static function introspectar(array $cfg): array {
        $secret=F3Base_Segredos::abrir(self::SECRET);$token=F3Base_Segredos::abrir(self::TOKEN);
        if(!$token){return array('ok'=>false,'codigo'=>'credencial_ausente');}
        if(!$secret||empty($cfg['client_id'])){return array('ok'=>true,'cobertura'=>'parcial','codigo'=>'introspeccao_nao_configurada','escopo_comprovado'=>false);}
        if(!$token){return array('ok'=>false,'codigo'=>'credencial_ausente');}
        $r=wp_remote_post('https://www.linkedin.com/oauth/v2/introspectToken',array('timeout'=>8,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>16384,'headers'=>array('Content-Type'=>'application/x-www-form-urlencoded'),'body'=>array('client_id'=>$cfg['client_id'],'client_secret'=>$secret,'token'=>$token)));unset($token,$secret);
        if(is_wp_error($r)){return array('ok'=>false,'codigo'=>'introspeccao_indisponivel');}$d=json_decode(wp_remote_retrieve_body($r),true);$scope=is_string($d['scope']??null)?preg_split('/[ ,]+/',trim($d['scope'])):array();
        $ok=wp_remote_retrieve_response_code($r)===200&&($d['active']??null)===true&&($d['auth_type']??'')==='3L'&&(!isset($d['client_id'])||$d['client_id']===$cfg['client_id'])&&in_array('r_marketing_leadgen_automation',$scope,true)&&(!isset($d['expires_at'])||(int)$d['expires_at']>time());
        $codigo='escopo_lead_sync_confirmado';
        if(wp_remote_retrieve_response_code($r)!==200||!is_array($d)){$codigo='introspeccao_recusada';}
        elseif(($d['active']??null)!==true){$codigo='token_inativo';}
        elseif(isset($d['expires_at'])&&(int)$d['expires_at']<=time()){$codigo='token_expirado';}
        elseif(($d['auth_type']??'')!=='3L'){$codigo='token_nao_e_de_membro';}
        elseif(isset($d['client_id'])&&$d['client_id']!==$cfg['client_id']){$codigo='token_aplicativo_divergente';}
        elseif(!in_array('r_marketing_leadgen_automation',$scope,true)){$codigo='escopo_lead_sync_ausente';}
        return array('ok'=>$ok,'codigo'=>$codigo,'escopo_comprovado'=>$ok,'expira_em'=>is_numeric($d['expires_at']??null)?(int)$d['expires_at']:null,'cobertura'=>$ok?'escopo_do_token':'recusada','escopos_metadados'=>array_values(array_intersect($scope,array('r_ads','rw_ads','r_organization_admin','rw_organization_admin'))),'leitura_de_respostas_testada'=>false);
    }
}
