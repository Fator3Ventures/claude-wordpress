<?php
/** Política da instalação e negativas do contato; não fabrica consentimento individual. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Publicidade {
    public static function preautorizada(): bool {return (F3Base_Options::ler('f3base_consentimento')['publicidade_politica']??'pre_autorizada')==='pre_autorizada';}
    private static function resultado(bool $ok,string $fundamento,string $evidencia=''): array {return array('permitida'=>$ok,'fundamento'=>$fundamento,'evidencia'=>$evidencia,'politica'=>self::preautorizada()?'pre_autorizada':'exigir_decisao');}
    public static function resolver(array $d): array {
        $p=is_array($d['consentimento_snapshot']??null)?$d['consentimento_snapshot']:array();$a=is_array($d['publicidade']??null)?$d['publicidade']:array();
        if(!empty($a['negativa'])||!empty($p['revogada'])){return self::resultado(false,'negativa_explicita',(string)($a['fonte']??'revogacao_registrada'));}
        $ref=F3Base_Leads_Consentimento::referencia($d);$row=null;
        if($ref){global $wpdb;$row=$wpdb->get_row($wpdb->prepare('SELECT publicidade,revogada,expira_em,politica_versao FROM %i WHERE ref=%s',$wpdb->prefix.F3Base_Consentimento_Decisoes::TABELA,$ref),ARRAY_A);if($wpdb->last_error){return self::resultado(false,'decisao_leitura_falhou');}
            if(($row&&(!empty($row['revogada'])||!(int)$row['publicidade']))||(($p['publicidade']??null)===false)){return self::resultado(false,'negativa_explicita',$row?'decisao_registrada':'snapshot_com_referencia_perdida');}
            if($row&&(int)$row['expira_em']>time()&&($p['politica_versao']??'')===$row['politica_versao']){return self::resultado(true,'decisao_explicita','decisao_registrada');}
        }
        if(($a['fundamento']??'')==='decisao_explicita'&&!empty($a['confirmada'])){return self::resultado(true,'decisao_explicita',(string)($a['fonte']??''));}
        return self::resultado(self::preautorizada(),self::preautorizada()?'politica_do_site':'decisao_ausente',$ref?'referencia_expirada_ou_perdida':'sem_decisao_individual');
    }
    public static function requisicao(): array {
        $raw=is_string($_COOKIE[F3Base_Modulo_Consentimento::COOKIE]??null)?wp_unslash($_COOKIE[F3Base_Modulo_Consentimento::COOKIE]):'';$c=json_decode($raw,true);
        if($raw==='denied'||(is_array($c)&&($c['publicidade']??null)===false)){return self::resultado(false,'negativa_explicita','cookie');}
        if($raw==='granted'&&!F3Base_Modulo_Consentimento::modo_granular()){return self::resultado(true,'decisao_explicita','cookie');}
        $d=array('consentimento_snapshot'=>F3Base_Modulo_Consentimento::referencia_confirmada());return self::resolver($d);
    }
    public static function capturar(): array {$r=self::requisicao();return $r+array('negativa'=>!$r['permitida']&&$r['fundamento']==='negativa_explicita','fonte'=>$r['evidencia'],'em'=>time(),'confirmada'=>$r['fundamento']==='decisao_explicita');}
    public static function rotulo(array $r): string {return !$r['permitida']?($r['fundamento']==='negativa_explicita'?'negativa explícita preservada':'não autorizada — '.$r['fundamento']):($r['fundamento']==='politica_do_site'?'pré-autorizada pela política do site; sem consentimento individual comprovado':'autorizada por decisão explícita');}
    /** A revogação e seu resumo no contato pertencem à mesma transação do recibo. */
    public static function preservar_revogacao(string $ref): bool {global $wpdb;return false!==$wpdb->query($wpdb->prepare("UPDATE %i SET dados=JSON_SET(dados,'$.consentimento_snapshot.revogada',true,'$.publicidade.negativa',true,'$.publicidade.fonte','revogacao_registrada'),revisao=revisao+1 WHERE decisao_ref=%s OR JSON_UNQUOTE(JSON_EXTRACT(dados,'$.consentimento_snapshot.decisao_ref'))=%s OR JSON_UNQUOTE(JSON_EXTRACT(dados,'$.consentimento_snapshot.ref'))=%s",F3Base_Leads_Repositorio::tabela(),$ref,$ref,$ref));}
    public static function nativa(array $fields,array $mapping): array {
        $key=$mapping['campo']??'';$negative=is_string($key)&&array_key_exists($key,$fields)&&is_array($mapping['negativas']??null)&&array_intersect((array)$fields[$key],$mapping['negativas']);
        return array('negativa'=>(bool)$negative,'fonte'=>$negative?'campo_nativo_mapeado':'politica_do_site','campo'=>$negative?$key:'','em'=>time());
    }
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('contato-publicidade-negar','Registrar negativa explícita do contato sem alterar medição ou apagar entregas históricas',array(__CLASS__,'negar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'revisao'=>array('type'=>'integer'),'motivo'=>array('type'=>'string','minLength'=>1,'maxLength'=>500),'simular'=>array('type'=>'boolean','default'=>true)),array('record_id','revisao','motivo'),false));
        add_action('admin_post_f3base_publicidade_negar',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão');}check_admin_referer('f3base-publicidade');$r=F3Base_Recuperacao::executar(array(__CLASS__,'negar'),array('record_id'=>sanitize_key($_POST['record_id']??''),'revisao'=>(int)($_POST['revisao']??0),'motivo'=>sanitize_textarea_field(wp_unslash($_POST['motivo']??'')),'simular'=>false));wp_die(esc_html($r['codigo']??'operacao_indisponivel'),'Publicidade',array('back_link'=>true));});
    }
    public static function negar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$l=F3Base_Leads_Repositorio::obter((string)($e['record_id']??''));if(!$l||!empty($l['eliminacao_pendente'])||$l['captura']==='eliminado'){return array('ok'=>false,'codigo'=>'contato_indisponivel');}if((int)$l['revisao']!==(int)($e['revisao']??0)){return array('ok'=>false,'codigo'=>'conflito');}$reason=trim(sanitize_textarea_field((string)($e['motivo']??'')));if($reason===''||strlen($reason)>2000){return array('ok'=>false,'codigo'=>'motivo_obrigatorio');}if(($e['simular']??true)!==false){return array('ok'=>true,'simular'=>true,'persisted'=>false,'codigo'=>'negativa_prevista','record_id'=>$l['record_id']);}
        global $wpdb;$d=$l['dados'];$d['publicidade']=array('negativa'=>true,'fonte'=>'operador','em'=>time(),'autor'=>get_current_user_id(),'motivo'=>$reason);$n=$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($d),'revisao'=>(int)$l['revisao']+1),array('record_id'=>$l['record_id'],'revisao'=>$l['revisao']));if($n!==1){return array('ok'=>false,'codigo'=>'conflito_ou_persistencia');}
        // Todo despacho relê a negativa; cancelar só pendências, sem apagar entregas anteriores.
        $wpdb->query($wpdb->prepare("UPDATE %i SET estado='cancelado',payload='',motivo='publicidade_negada',atualizado=%d WHERE record_id=%s AND estado IN ('pendente','reservado','suspenso')",$wpdb->prefix.F3Base_Capi_Fila::TABELA,time(),$l['record_id']));F3Base_Qualidade::cancelar($l['record_id'],false);
        return array('ok'=>true,'persisted'=>true,'codigo'=>'negativa_registrada','http_ja_iniciado'=>'Uma requisição iniciada antes da negativa não pode ser desfeita.','revisao'=>(int)$l['revisao']+1);
    }
    public static function ficha(array $l): void {
        echo '<details><summary>Publicidade e negativa do contato</summary><p>'.esc_html(self::rotulo(self::resolver($l['dados']))).'</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_publicidade_negar"><input type="hidden" name="record_id" value="'.esc_attr($l['record_id']).'"><input type="hidden" name="revisao" value="'.(int)$l['revisao'].'">';wp_nonce_field('f3base-publicidade');echo '<label>Motivo da negativa <input name="motivo" maxlength="500" required></label> ';submit_button('Registrar negativa de publicidade','secondary','submit',false);echo '</form><p>Não altera a medição, não desfaz entregas já iniciadas e não envia conversões antigas.</p></details>';
    }
}
