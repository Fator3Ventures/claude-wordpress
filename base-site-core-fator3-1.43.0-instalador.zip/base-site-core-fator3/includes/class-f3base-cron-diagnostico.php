<?php
/** Prova da agenda Core. Histórico de operação não substitui leitura atual. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Cron_Diagnostico {
    private static array $tentativas=array();
    private static bool $retomando=false;
    private static ?bool $gravacao=null;
    public static function proprio(string $hook): bool {return F3Base_Operacao::identificar_hook($hook)!==''||$hook==='f3base_operacao_retomar';}
    private static function chave(string $op,string $hook,array $args): string {return $op.'|'.$hook.'|'.hash('sha256',serialize($args));}
    public static function iniciar(): void {
        add_filter('pre_reschedule_event',static function($pre,$e){if(self::proprio($e->hook)){self::$tentativas[self::chave('reagendar',$e->hook,$e->args)]=array('original_em'=>(int)$e->timestamp,'timestamp'=>null,'schedule'=>$e->schedule,'interval'=>(int)($e->interval??0),'args'=>$e->args);}return $pre;},PHP_INT_MAX,2);
        add_filter('schedule_event',static function($e){if($e&&self::proprio($e->hook)){$key=self::chave('reagendar',$e->hook,$e->args);if(isset(self::$tentativas[$key])){self::$tentativas[$key]=array_merge(self::$tentativas[$key],array('timestamp'=>(int)$e->timestamp,'schedule'=>$e->schedule,'interval'=>(int)($e->interval??0),'args'=>$e->args));}}return $e;},PHP_INT_MAX);
        add_filter('pre_unschedule_event',static function($pre,$at,$hook,$args){if(self::proprio($hook)){self::$tentativas[self::chave('remover',$hook,$args)]=array('timestamp'=>(int)$at,'args'=>$args,'schedule'=>false,'interval'=>0);}return $pre;},PHP_INT_MAX,4);
        foreach(array('cron_reschedule_event_error'=>'reagendar','cron_unschedule_event_error'=>'remover') as $name=>$op){add_action($name,static fn($error,$hook,$data)=>self::observar($op,$error,$hook,$data),10,3);}
    }
    /** Somente opções pertinentes entram na revisão; nenhum segredo entra no diagnóstico. */
    public static function intencao(string $hook,array $args=array()): array {
        $id=F3Base_Operacao::identificar_hook($hook);if(!self::proprio($hook)||!has_action($hook)){return array('verificavel'=>false,'ativa'=>false,'revisao'=>'','codigo'=>'tarefa_nao_registrada');}
        $map=array('gsc'=>array('f3base_gsc','f3base_gsc_property'),'clarity'=>array('f3base_clarity','f3base_clarity_project_id','f3base_clarity_api_token'),'anuncios'=>array('f3base_anuncios_meta','f3base_anuncios_meta_token'),'pipedrive'=>array('f3base_pipedrive'),'capi'=>array('f3base_meta_capi'),'llms'=>array('f3base_llms'),'acessos'=>array('f3base_acessos'),'cadencia'=>array('f3base_cadencia'),'retencao'=>array('f3base_retencao'),'navegacao'=>array('f3base_navegacao'),'ofertas'=>array('f3base_ofertas'),'avisos_contatos'=>array('f3base_avisos'));
        $values=array();foreach($map[$id]??array() as $n){$f=F3Base_Options::fotografia_bruta($n);if($f['erro']){return array('verificavel'=>false,'ativa'=>false,'revisao'=>'','codigo'=>'configuracao_ilegivel');}$values[$n]=$f['revisao'];}
        $active=true;if($id==='gsc'){$active=!empty(F3Base_Options::ler('f3base_gsc')['ativo']);}elseif($id==='clarity'){$active=F3Base_Clarity::configurado()&&!empty(F3Base_Options::ler('f3base_clarity')['coleta_ativa']);}elseif($id==='anuncios'){$active=!empty(F3Base_Options::ler('f3base_anuncios_meta')['ativo']);}elseif($id==='pipedrive'){$active=!empty(F3Base_Options::ler('f3base_pipedrive')['ativo']);}
        $calendar=!empty($args)?'':(in_array($id,array('gsc','clarity','retencao','cadencia','redes_robos','gtm','navegacao','manutencao'),true)?wp_timezone_string():'');
        return array('verificavel'=>true,'ativa'=>$active,'tarefa'=>$id?:'despertador','revisao'=>hash('sha256',serialize(array(get_current_blog_id(),$hook,$args,$values,$calendar))),'codigo'=>$active?'intencao_vigente':'tarefa_desligada');
    }
    /** null: não foi possível provar; false: leitura confirmou ausência/divergência. */
    public static function conferir(string $op,string $hook,array $event): ?bool {
        if(!self::proprio($hook)||!isset($event['timestamp'])||!is_array($event['args']??null)){return null;}
        global $wpdb;wp_cache_delete('cron','options');wp_cache_delete('alloptions','options');
        $raw=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,'cron'));if($wpdb->last_error){return null;}
        $persistido=$raw===null?array():maybe_unserialize($raw);if(!is_array($persistido)){return null;}$efetivo=_get_cron_array();if(!is_array($efetivo)){return null;}
        $select=static function(array $cron)use($hook,$event){$out=array();$key=md5(serialize($event['args']));foreach($cron as $at=>$hooks){if(is_numeric($at)&&isset($hooks[$hook][$key])){$v=$hooks[$hook][$key];if(!is_array($v)){return null;}$out[(int)$at]=array('args'=>$v['args']??null,'schedule'=>$v['schedule']??false,'interval'=>(int)($v['interval']??0));}}ksort($out);return $out;};
        $a=$select($persistido);$b=$select($efetivo);if($a===null||$b===null||$a!==$b){return null;}$at=(int)$event['timestamp'];if($op==='remover'){return !isset($a[$at]);}
        foreach($a as $when=>$v){if($v['args']!==$event['args']){continue;}$schedule=$event['schedule']??false;if(!$schedule){if($when<=$at){return true;}continue;}$interval=(int)($event['interval']??0);if($interval>0&&$v['schedule']===$schedule&&$v['interval']===$interval&&$when>=$at&&($when-$at)%$interval===0){return true;}}
        return false;
    }
    public static function reagendar(int $at,string $schedule,string $hook,array $args): bool {
        $ok=wp_reschedule_event($at,$schedule,$hook,$args,true);$key=self::chave('reagendar',$hook,$args);$event=self::$tentativas[$key]??null;
        if($ok===true){unset(self::$tentativas[$key]);return $event&&self::conferir('reagendar',$hook,$event)===true;}
        $proof=$event?self::conferir('reagendar',$hook,$event):null;self::observar('reagendar',$ok,$hook,array('args'=>$args));return $proof===true;
    }
    public static function observar(string $op,$error,string $hook,array $data): void {
        if(!self::proprio($hook)||!in_array($op,array('reagendar','remover'),true)){return;}$key=self::chave($op,$hook,$data['args']??array());$event=self::$tentativas[$key]??null;unset(self::$tentativas[$key]);if(self::$retomando){return;}
        $proof=$event?self::conferir($op,$hook,$event):null;$intent=self::intencao($hook,$event['args']??array());$id=hash('sha256',serialize(array(get_current_blog_id(),$op,$hook,$event,$intent['revisao'])));$at=time();$code=$proof===true?'estado_desejado_confirmado':($proof===false?'agenda_nao_confirmada':'causa_indeterminada');
        $saved=F3Base_Options::atualizar_estado('f3base_agenda',static function($s)use($id,$at,$op,$hook,$event,$intent,$proof,$code,$error){
            $obs=array('id'=>$id,'revisao_intencao'=>$intent['revisao'],'em'=>$at,'primeira_em'=>$at,'ultima_em'=>$at,'hook'=>$hook,'operacao'=>$op,'origem'=>F3Base_Execucoes::origem(),'erro'=>is_wp_error($error)?sanitize_key($error->get_error_code()):'desconhecido','codigo'=>$code,'timestamp'=>$event['timestamp']??null,'agenda_confirmada'=>$proof,'concorrencia_comprovada'=>false,'diagnostico_persistido'=>true);
            $s['wp_observacoes']=array_values(array_filter($s['wp_observacoes']??array(),static fn($r)=>($r['em']??0)>time()-DAY_IN_SECONDS));$s['wp_observacoes'][]=$obs;if(count($s['wp_observacoes'])>100){$s['wp_detalhes_omitidos']=(int)($s['wp_detalhes_omitidos']??0)+count($s['wp_observacoes'])-100;}$s['wp_observacoes']=array_slice($s['wp_observacoes'],-100);
            $h=gmdate('YmdH');$s['wp_contadores'][$h][$hook][$code]=($s['wp_contadores'][$h][$hook][$code]??0)+1;foreach(array_keys($s['wp_contadores']) as $old){if((string)$old<gmdate('YmdH',time()-DAY_IN_SECONDS)){unset($s['wp_contadores'][$old]);}}
            if($proof!==true&&$event){if(isset($s['wp_retentativas'][$id])){$s['wp_retentativas'][$id]['ultima_em']=$at;}else{$s['wp_retentativas'][$id]=array('hook'=>$hook,'operacao'=>$op,'evento'=>F3Base_Contato_Comunicacao::cifrar($event),'intencao'=>$intent,'revisao_intencao'=>$intent['revisao'],'primeira_em'=>$at,'ultima_em'=>$at,'tentar_em'=>$at+60,'tentativas'=>0,'estado'=>'pendente','agenda_confirmada'=>$proof);}}return $s;
        });self::$gravacao=!empty($saved['persisted']);if(!self::$gravacao){error_log('F3BASE cron diagnostico_nao_persistido hook='.sanitize_key($hook));}
    }
    private static function estado(): ?array {
        global $wpdb;$raw=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,'f3base_agenda'));if($wpdb->last_error){return null;}$v=$raw===null?array():maybe_unserialize($raw);return is_array($v)?$v:null;
    }
    private static function concluir(string $key,array $job,string $state,?bool $proof,string $code): bool {
        $saved=F3Base_Options::atualizar_estado('f3base_agenda',static function($s)use($key,$job,$state,$proof,$code){if(($s['wp_retentativas'][$key]??null)!==$job){return null;}$j=$job;$j['estado']=$state;$j['agenda_confirmada']=$proof;$j['codigo']=$code;$j['resolvida_em']=time();$s['wp_resolucoes'][]=array_diff_key($j,array('evento'=>1,'intencao'=>1));$s['wp_resolucoes_omitidas']=(int)($s['wp_resolucoes_omitidas']??0)+max(0,count($s['wp_resolucoes'])-100);$s['wp_resolucoes']=array_slice($s['wp_resolucoes'],-100);unset($s['wp_retentativas'][$key]);return $s;});self::$gravacao=!empty($saved['persisted']);return self::$gravacao;
    }
    /** Mesmo orçamento é compartilhado com as pendências de evento único da Fila. */
    public static function retomar(int $limite=3): int {
        if(self::$retomando){return 0;}self::$retomando=true;$n=0;
        try{$state=self::estado();if($state===null){return 0;}foreach($state['wp_retentativas']??array() as $key=>$job){if($n>=$limite){break;}if(($job['tentar_em']??0)>time()||($job['tentativas']??0)>=5){continue;}++$n;$lock=F3Base_Trava::adquirir('agenda-'.substr(hash('sha256',$job['hook']),0,32),30);if(!$lock){continue;}
            try{$event=F3Base_Contato_Comunicacao::abrir($job['evento']);$now=self::intencao($job['hook'],$event['args']??array());$proof=$event?self::conferir($job['operacao'],$job['hook'],$event):null;
                if(!empty($now['verificavel'])&&empty($now['ativa'])){self::concluir($key,$job,'cancelada',$proof,'tarefa_desligada');continue;}
                if(!empty($job['revisao_intencao'])&&$job['revisao_intencao']!==$now['revisao']){self::concluir($key,$job,'substituida',$proof,'configuracao_alterada');continue;}
                if($proof===true){self::concluir($key,$job,'resolvida',true,'agenda_confirmada');continue;}
                $can=$event&&$proof===false&&!empty($now['verificavel'])&&!empty($now['ativa'])&&!empty($job['revisao_intencao']);
                $new=$job;$new['tentativas']=(int)($job['tentativas']??0)+1;$new['tentar_em']=time()+min(3600,60*2**$new['tentativas']);$new['estado']=$new['tentativas']>=5?'esgotada':($can?'pendente':'nao_verificavel');$new['codigo']=$can?'retomada_reservada':'intencao_nao_verificavel';
                $saved=F3Base_Options::atualizar_estado('f3base_agenda',static function($s)use($key,$job,$new){if(($s['wp_retentativas'][$key]??null)!==$job){return null;}$s['wp_retentativas'][$key]=$new;return $s;});self::$gravacao=!empty($saved['persisted']);if(!self::$gravacao||!$can){continue;}
                if(self::intencao($job['hook'],$event['args'])['revisao']!==$now['revisao']){self::concluir($key,$new,'substituida',null,'configuracao_alterada');continue;}
                if($job['operacao']==='remover'){wp_unschedule_event($event['timestamp'],$job['hook'],$event['args'],true);}
                else{$next=(object)array_merge($event,array('hook'=>$job['hook']));$interval=(int)($next->interval??0);if($interval>0&&$next->timestamp<time()){$next->timestamp+=(int)ceil((time()-$next->timestamp)/$interval)*$interval;}$next=F3Base_Operacao::alinhar_evento($next);$event['timestamp']=$next->timestamp;wp_schedule_event($next->timestamp,$next->schedule,$next->hook,$next->args,true);}
                if(self::intencao($job['hook'],$event['args'])['revisao']!==$now['revisao']){if($job['operacao']==='reagendar'){wp_unschedule_event($event['timestamp'],$job['hook'],$event['args'],true);}self::concluir($key,$new,'substituida',null,'configuracao_alterada_durante_retomada');continue;}
                $proof=self::conferir($job['operacao'],$job['hook'],$event);if($proof===true){self::concluir($key,$new,'resolvida',true,'agenda_confirmada_apos_retomada');}
            }finally{F3Base_Trava::liberar($lock);}}
        }finally{self::$retomando=false;}return $n;
    }
    public static function resumo(): array {
        $s=self::estado();if($s===null){return array('leitura_confirmada'=>false,'agenda_confirmada'=>null,'diagnostico_persistido'=>self::$gravacao,'pendencias'=>null,'codigo'=>'diagnostico_ilegivel');}$pending=array();foreach($s['wp_retentativas']??array() as $key=>$r){$event=F3Base_Contato_Comunicacao::abrir($r['evento']??'');$proof=$event?self::conferir($r['operacao'],$r['hook'],$event):null;$pending[]=array_diff_key($r,array('evento'=>1,'intencao'=>1))+array('chave'=>$key,'esgotado'=>($r['tentativas']??0)>=5,'confirmacao_atual'=>$proof);}
        $proofs=array_column($pending,'confirmacao_atual');$confirmation=in_array(null,$proofs,true)?null:!in_array(false,$proofs,true);
        return array('leitura_confirmada'=>true,'agenda_confirmada'=>$pending?$confirmation:null,'diagnostico_persistido'=>self::$gravacao,'escopo'=>'Somente intenções observadas; ausência de incidentes não comprova toda a agenda.','observacoes'=>$s['wp_observacoes']??array(),'contagens_por_hora'=>$s['wp_contadores']??array(),'pendencias'=>$pending,'resolucoes'=>$s['wp_resolucoes']??array(),'completude'=>array('pendencias_total'=>count($pending),'pendencias_completas'=>true,'limite_detalhes'=>100,'detalhes_omitidos'=>$s['wp_detalhes_omitidos']??0,'resolucoes_omitidas'=>$s['wp_resolucoes_omitidas']??0,'janela'=>'24 horas em baldes UTC, inclui hora limítrofe; pendências não expiram'),'documentacao'=>'docs/CRON-DIAGNOSTICO-1.31.md','explicacao'=>'Agenda, execução e gravação do diagnóstico são provas distintas. could_not_set sozinho não comprova concorrência; o log nativo é preservado.');
    }
}
