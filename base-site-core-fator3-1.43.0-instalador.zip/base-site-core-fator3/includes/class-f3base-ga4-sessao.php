<?php
/** Native Google tag session evidence. Browser data is validated, not trusted as provider proof. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Ga4_Sessao {
    public static function capturar(array $input,array $identity): array {
        $start=$input['ga4_session_started_at']??null;$observed=$input['ga4_observed_at']??null;
        if(($input['ga4_session_source']??'')!=='google_tag_native'||!is_scalar($start)||!is_scalar($observed)||!ctype_digit((string)$start)||!ctype_digit((string)$observed)){return $identity;}
        $identity['session_evidence']=array('source'=>'google_tag_native','started_at'=>(int)$start,'observed_at'=>(int)$observed,'received_at'=>time());return $identity;
    }
    public static function validar(array $g,int $occurred): string {
        $e=$g['session_evidence']??array();
        if(($e['source']??'')!=='google_tag_native'||!is_int($e['started_at']??null)||!is_int($e['observed_at']??null)||!is_int($e['received_at']??null)){return 'ga4_sessao_sem_evidencia';}
        $start=$e['started_at'];$observed=$e['observed_at'];$received=$e['received_at'];
        if((string)$start!==(string)($g['session_id']??'')||$start<1577836800||$start>$observed||abs($observed-$received)>30||abs($occurred-$received)>30||$occurred<$start){return 'ga4_sessao_tempo_invalido';}
        return time()>$start+DAY_IN_SECONDS?'ga4_sessao_expirada':'';
    }
}
