<?php
/** Editorial metadata only: no changes to defaults, validators or persisted values. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Descricoes {
    public static function texto(string $id): array {
        static $map=null;if($map===null){$map=json_decode((string)file_get_contents(F3BASE_PLUGIN_DIR.'dados/descricoes-configuracao.json'),true)?:array();}return $map[$id]??array();
    }
    public static function catalogo(array $all): array {
        foreach($all as $id=>&$c){$c=array_replace($c,self::texto($id));foreach($c['subcampos']??array() as $key=>$field){$c['subcampos'][$key]=array_replace($field,self::texto($id.'.'.$key));}}
        unset($c);return $all;
    }
    public static function ajuda(string $id,array $field,array $help): array {
        $override=self::texto($id);$description=$override['descricao']??$field['descricao']??'';
        if(isset($override['descricao'])){$help['funcionamento']=$description;}
        foreach($help as $key=>$value){if(!is_string($value)){continue;}
            if(preg_match('/Ajuste este campo conforme|Escolha conforme o fluxo descrito|Torna a decisão explícita|A escolha fica centralizada|A preferência não comprova|Permite controlar esta função sem|Ative quando quiser aplicar|Escolha uma das alternativas exibidas|Itens ausentes não são acrescentados|A lista explícita permite|Informe somente os itens|A configuração salva não comprova/u',$value)){$help[$key]='';}
            if($key==='exemplo'&&trim($value)===trim((string)$description)){$help[$key]='';}
        }
        $choices=$field['opcoes']??array();if($choices&&empty($help['escolha'])){$help['escolha']='Alternativas disponíveis: '.implode('; ',array_values($choices)).'.';}
        return $help;
    }
}
