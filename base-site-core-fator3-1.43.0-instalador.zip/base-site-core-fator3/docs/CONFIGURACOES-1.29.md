# Configurações por tarefa — 1.29

A entrada é **Site Core → Configurações → Visão geral**. Busque por tarefa ou use os cartões. Contatos permanece para atendimento e edição de formulários; Medição permanece para análise. Configuração de contas e canais fica em **Conexões e entregas**, com Pipedrive, origens de anúncios, qualidade e Meta, entregas e avisos. Links antigos de Integrações redirecionam para esta área.

Os grupos avançados ficam recolhidos. A configuração continua legível sem JavaScript; busca e adição de linhas são facilidades da tela. Salvar uma área compara o que foi realmente alterado, preserva outros campos e mantém o controle de revisão contra edição simultânea. Campo de segredo vazio mantém; apagar exige ação explícita. Use a indicação de estado, sem esperar que o token reapareça.

| Quero… | Onde | Como escolher |
|---|---|---|
| Colocar GTM/GA4/LinkedIn | Medição e anúncios → Tags e carregamento | Configure IDs e carga dos destinos. Cada destino tem sua autorização; não replique evento GA4 por servidor. |
| Receber contatos da Meta | Conexões e entregas → Origens de anúncios | Confira conta, páginas e formulários. Todos os autorizados facilita administrar novos formulários; Selecionados restringe a lista. Lista vazia em Selecionados é nenhum. |
| Encaminhar ao Pipedrive | Conexões e entregas → Pipedrive | Verifique a conta, depois escolha responsáveis/campos do catálogo. Mapas aumentam dados estruturados, mas precisam ser revistos ao mudar os formulários. |
| Devolver resultados à Meta | Conexões e entregas → Qualidade e Meta | Cadastre etapas e regras deste site; confira dataset e autorização antes de ligar. Não há mapa de cliente de fábrica. |
| Nomear campanhas por ID | Medição e anúncios → Coleta do site | Uma linha por plataforma + conta + campanha. O nome recebido no link prevalece; o mapa complementa a leitura quando só existe ID. Snapshots enviados não são reescritos. |
| Ajustar avisos | Conexões e entregas → Avisos | E-mail, Slack ou webhook têm estado próprio e contingência visível. Aceite de transporte não significa leitura da equipe. |
| Aumentar histórico | Coleta do site / Privacidade | O padrão de comportamento é 365 dias. Mais histórico aumenta armazenamento e dados pessoais conservados; reduzir elimina eventos vencidos. |
| Conferir falha de execução | Operação | Veja origem CLI/HTTP/manual, pendências, causa e horário. Abrir a tela não equivale a executar tarefa. |

No Pipedrive, **Contatos sem nome** permite manter para revisão ou enviar quando há e-mail/telefone válido. A alternativa de nome é sinalizada como gerada; não transforma uma identidade presumida em nome informado nem renomeia pessoa existente. LinkedIn significa o endereço de perfil profissional informado pela pessoa, não busca de perfil na rede.

As explicações dos campos descrevem funcionamento, exemplo, vantagens e limites. Os rótulos técnicos continuam disponíveis para agentes no catálogo; não são substitutos dos nomes para a equipe.
