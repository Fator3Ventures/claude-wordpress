# Material e contato — 1.35.0

O regime/método conteudo representa solicitação de material. A liberação ocorre após aceite persistido e elegibilidade da conversão, respeitando consentimento, contexto e teste. Não comprova leitura do PDF. Download não deve herdar a ação de contato.

## Configuração

Em Site Core → Medição e anúncios → Tags e carregamento, configure os identificadores e os quatro interruptores de Conversões de material. Cada interruptor inicia desligado. Pelo canal, ler config-core-ler, obter revisão atual, simular/gravar config-core-escrever e reler. Exige manage_options. schema administrativo 8.1.0 contém tipos e ajuda integral.

| Destino | Interruptor em f3base_conversoes_conteudo | Evento/ação | Requisito adicional |
|---|---|---|---|
| GA4/GTM | ga4 | download_material | GA4 ou GTM configurado; medição permitida |
| Meta | meta | MaterialDownload | Pixel/CAPI e transporte configurados; publicidade permitida |
| Google Ads | google_ads | conversion para ação Material | f3base_google_ads.conteudo_conversion_label + conversion_id AW |
| LinkedIn | linkedin | conversion com ID Material | f3base_linkedin_conteudo_conversion_id + Insight Tag |

Exemplo de interruptores: {"ga4":true,"meta":false,"google_ads":false,"linkedin":false}. O objeto exige os quatro booleanos. Google Ads e LinkedIn não enviam material quando falta seu identificador, mesmo que ligados. Nunca usam o rótulo/ID de contato como fallback. O dono cria/seleciona ações nas plataformas e decide se viram eventos-chave/ações primárias; o Core não muda otimização nem campanhas.

Contato continua generate_lead, Meta Lead, rótulo conversion_label e LinkedIn f3base_linkedin_conversion_id. Clarity conserva sua instrumentação existente com method; os quatro novos interruptores não controlam esse destino.

## Meta, testes e deduplicação

Pixel usa trackCustom MaterialDownload e CAPI usa event_name MaterialDownload, com a mesma identidade de correlação. Material segue o modo de transporte; seu interruptor é independente da lista histórica PageView/Lead. Ativar material invalida a prova anterior de modo servidor e exige nova homologação incluindo o evento; a proteção passa ao modo efetivo ambos até prova compatível. Desligado, conserva o contexto da homologação anterior.

O endpoint recusa Lead para correlação de material e MaterialDownload para contato. O consumidor suspende material quando seu destino está desligado e suspende Lead legado de material antes do despacho. Fila entregue não é recriada. Eventos já enviados com comportamento anterior não são corrigidos retroativamente.

A reserva de material usa sessão derivada da sessão original + formulário; não altera a sessão do contato/jornada. Material e contato da mesma pessoa/sessão podem gerar suas conversões independentes; repetir o mesmo material na mesma sessão conserva deduplicação. A regra por_acao continua disponível. Testes marcados seguem a política existente: no navegador, publicidade é suprimida e GA4 pode ser marcado como internal; CAPI exige a configuração própria de Test Events. Fixture não prova recebimento externo.

## Pipedrive e relatórios

mapa_pontos.conteudo prevalece para método conteudo; sem a chave usa site. whatsapp_formulario e nativo preservam seus pontos. mapa_respostas de Meta usa rótulos em campos textuais; opções enum/set exigem IDs reais do catálogo CRM.

relatorios-integrados-ler: visao comercial inclui intencao contato/material; visao intencoes apresenta envios por intenção. Nas visões do agregado comercial, totais.envios_contato e totais.envios_material preservam totais.envios como soma compatível. Resumo editorial e agregados históricos mantêm suas unidades de audiência; para custo/comercial, use intencoes/comercial ou filtre metodo. Dados retidos, testes e filtros limitam totais; intenção não comprova qualidade comercial.

## Fronteira SDK

O SDK site-measurement-context/1.0.0 tem enumeração fechada: continua com seis slots e nomes anteriores. Seu catálogo não inclui download_material nem seus novos identificadores/interruptores. A descrição de generate_lead exclui material. Não apresentar esse snapshot como configuração completa de material. Google 0.10.0 continua compatível; descoberta de material requer revisão explícita Core/Google. Enquanto isso, use a configuração administrativa 8.1.0 e este documento. Não acrescente campo a um schema fechado nem consulte options privadas de outro plugin.
