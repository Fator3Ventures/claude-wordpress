# Histórico, conversões e operação — 1.29

Padrão de comportamento: 365 dias. Perfil atual `piso-padrao-3.4`, P02/P03=365. O perfil 3.3 continua histórico, com seu significado original. Atualização preserva escolhas e procedência; não recupera eventos já apagados. Atribuição no navegador tem TTL próprio.

O histórico parte do índice por visitante/classe/início e lê até 10.001 eventos de origem para detectar excesso sobre o teto de 10.000. Até 500 sessões, cinco visitas com detalhes por página e paginação de resumos. Excesso é lacuna explícita; não resumo completo. Recebimento posterior ao corte não amplia snapshot antigo. Conflito de visitante não cruza identidades. Não há vínculo por IP.

Horário, caminho e tempo ativo por página entram no resumo comum de e-mail, Slack e Pipedrive. Zero observado é distinto de ausência. Origem distingue acesso direto comprovável de informação ausente. Click ID pode indicar família da plataforma, sem inventar campanha nem mídia paga por um fbclid. O último toque igual à sessão é resumido; repetições são omitidas sem remissões campo a campo. Snapshots já comunicados permanecem congelados; novas apresentações usam versão 4, envelope de comunicação 3.

Conversões: `f3base_conversoes.modo=contato_sessao` evita contar formulário e clique de continuidade duas vezes. Outra pessoa identificada na mesma sessão fica separada. Opção `por_acao` mantém contagem individual. A reserva anterior aos destinos usa sessão/classe e identidade HMAC; limpa após um dia. Ações continuam no histórico de comportamento. Sem sessão, há código explícito de cobertura insuficiente para vincular.

Contexto público: pendente, permitido, excluído e falha são distintos. Classificação válida tem janela de cinco minutos; falha na renovação não apaga imediatamente contexto ainda válido. Negativa de consentimento continua negativa. Captura aceita enquanto o contexto está pendente recebe prova HMAC curta; `POST /leads/contexto` finaliza apenas essa captura, da mesma origem, dentro de cinco minutos, reconferindo autorização. Não cria outro contato. Falha/exclusão/saída ficam distintas no diagnóstico de capturas. O diagnóstico do servidor conta o que recebeu; não consegue inventar PageViews perdidos antes de qualquer comunicação.

Rolagem usa gesto confiável, duração do toque, inércia curta e scrollend; salto por âncora permanece separado. Scripts Core recebem `data-no-optimize=1` sem perder defer/estratégia. Não há filtro global sobre scripts de terceiros.

Clarity: até oito tentativas automáticas + duas manuais/dia no contador local, uma chamada por passagem. 429 respeita a espera; falha não promete oito recortes completos. Token/projeto/vínculo estão visíveis sem segredo; GET da leitura não coleta. Janela do fornecedor e uso por outros consumidores podem reduzir a cota disponível.

Cron: o Core confirma a agenda após reler o estado. Uma disputa com evento já gravado pode ser idempotente; falha sem agenda segue falha, com pendência durável. Contagens por hora/origem/hook/código ficam no diagnóstico; retomada mexe somente em ganchos Core. Captação Meta esgotada pode ser superada uma vez por nova revisão/release, preservando a ocorrência antiga. Alerta de atraso/recuperação é operacional e não cria lead; reserva de alerta evita tempestade por resultado incerto.

Alertas JSON usam `schema=f3base.operacao.alerta.v1`, texto, site e horário. A assinatura `X-F3Base-Signature` desse alerta é HMAC SHA-256 dos bytes do corpo com a chave do canal. Este é outro schema, distinto do aviso comercial `f3base.aviso.v1`; consumidores devem distinguir os contratos.

Ofertas: alteração apenas de render abre revalidação transitória de até 15 minutos, sem prorrogar a cada edição. Mudança comercial, prova divergente ou vencimento impede emissão. Estado técnico informa causa. Eliminação concluída não mantém `eliminacao_pendente=1`; marcas mínimas nativas contra reimportação têm ciclo próprio e não voltam ao atendimento.
