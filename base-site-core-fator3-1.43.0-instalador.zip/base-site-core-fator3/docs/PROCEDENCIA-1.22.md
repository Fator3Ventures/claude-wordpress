# Procedência e complementações — contrato preservado na 1.32.0

Uma configuração explícita mantém origem, canal e data de autoria quando o padrão recebe novas subchaves. A complementação tem registro próprio, versão e lista de chaves acrescentadas; não troca a opção inteira para “padrão”. Listas vazias explícitas permanecem vazias. A revisão do valor muda se o conteúdo mudar, mesmo sem mudar autoria.

Leia `config-core-ler` e `config-complementacoes-ler`. O histórico pode conter prova de reparos anteriores, que permanece auditável. O executor da versão atual não refaz esses reparos, e a antiga ability de reparo foi retirada no contrato 7.0.0. Nenhum registro histórico deve ser apagado ou fabricado para aparentar procedência original.
