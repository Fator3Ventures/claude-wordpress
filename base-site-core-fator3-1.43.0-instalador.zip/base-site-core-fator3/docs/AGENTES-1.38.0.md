# Agentes — Core 1.38.0
Descubra f3base/como-usar; leia docs/DOCUMENTACAO.md por f3base/documentacao-ler. Parâmetros arquivo, linha, limite até 200; continuar proxima_linha até nulo e conferir versão/hash por página. Ajuda local não chama fornecedor.
Leia f3base/config-core-contrato-v1 e f3base/config-core-ler; rota de escrita f3base/config-core-escrever (simular antes, revisão atual). Perfil docs/perfis/piso-padrao-3.5.json. Contrato 8.3.0.
Tela, configuração e dados privados exigem manage_options; documentação tem gate explícito. Não ler arquivos arbitrários nem segredos.
Consulte WHATSAPP-1.38.md para campos e aceite, PIPEDRIVE-1.37.md para demais regras comerciais. Homologação Pipedrive nos sites autorizados CTOoffice/korvena.com.br; Site-Teste para demais provas.
Confirmar atualização pelos quatro campos de atualizacao em f3base/como-usar, conforme RELEASE-1.38.0.md, e registrar tempo observado.
