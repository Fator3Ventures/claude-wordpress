# Fator3 Site Core 1.36.0

Rodada de implementação: Pedidos core 212(a), 224 e resposta ao impacto Google 0.11.0/Core 222.
Base direta: 1.35.0 ou WordPress limpo. Mínimos preservados: WordPress 7.1.2, PHP 8.3.6 de 64 bits, instalação única; MySQL compatível com os requisitos já publicados.
Identidade: base-site-core-fator3/base-site-core-fator3.php. Contrato administrativo 8.1.0. Marcador de estrutura 1.35.0 preservado, pois não muda a estrutura. Ciclo de instalação identificado pela versão 1.36.0.

## Memória editorial — 212(a)

f3base/medicao-editorial percorre a análise em lotes de até 128 linhas; não retém o conjunto bruto completo. Dimensões da primeira observação permanecem por sessão; índices de navegação conservam somente as referências usadas no cálculo. Agregados e conjuntos de identidades continuam necessários para contagens distintas, pareamento e continuidade entre dias.
O limite segue 397 dias e 100 mil linhas por fonte. A projeção retornada e os filtros são preservados. O orçamento depende do memory_limit efetivo e da arena PHP, sem aumentar o limite. Lotes não tornam o custo de agregados constante: cardinalidade extrema pode provocar recusa explícita.
Na recusa de memória, fonte/linhas identificam a maior fonte com crescimento vivo observado; fonte_consulta_recusada/linhas_consulta_recusada preservam a consulta que não coube. fonte_maior_crescimento detalha a medida. Não se atribui memória exclusivamente a um plugin.

## Agenda de avisos — 224

Intenção nova agenda evento único f3base_avisos_processar para seu prazo; reenfileiramento idempotente também verifica a agenda. A sincronização de partes rearma trabalho pendente. O bootstrap de uma requisição WP-Cron recupera fila sem evento; leitura administrativa/ajuda não faz esse reparo.
O executor usa até 8 subpassagens em orçamento de 20 segundos, reservando tempo para HTTP e respeitando a cadência do canal. Uma parte possui seu resultado persistido antes da próxima. Recuo do fornecedor e espera pela principal determinam a próxima data; resposta incerta não é reenviada automaticamente.
A fila mostra a data real de wp_next_scheduled. Não há novo cron recorrente, reset de intenção, troca de destino ou reenvio de histórico entregue. O cron precisa ser acionado pela hospedagem/tráfego; fila, indisponibilidade ou recuo podem superar dois minutos.

## Descoberta opcional

Novo SDK site-conversion-purposes/1.0.0, separado do SDK site-measurement-context/1.0.0, que conserva seus seis slots e enumeração fechada. Leia CONVERSOES-SDK-1.36.md. A ability f3base/conversoes-contexto-ler exige manage_options. O consumidor Google 0.11.0 continua usando a interface anterior; adoção do contrato adicional exige atualização própria do Google.

## Dados e configuração

Nenhuma tabela, coluna, segredo ou opção nova. Atualização preserva os quatro interruptores de material, inclusive true com rótulo Ads/ID LinkedIn vazios. Sem ativação automática de destinos ou criação de recursos em fornecedores. Não reabre os pedidos 219–223 aceitos pela frota.
Backup e rollback: preservar banco, arquivos privados e guardas operacionais. Voltar arquivos não desfaz mensagens entregues e restaura as limitações anteriores. Não usar desinstalação para atualizar.

## Provas

O relatório externo da entrega registra o instalador final, hashes, instalação limpa, atualização direta, evidências e limitações. Na bancada: 5.872 análises, 24 conteúdos, 1.931 eventos, 28 dias, base viva aproximada de 65 MiB; resumo/aquisição passaram a pico de 82,5 MiB com limite de 128 MiB e resultados iguais à base. Essa fixture não equivale à aceitação no CTO.
