# Search Console — apresentação e operação 1.34.0

A mesma projeção aparece em Medição e Operação. Mostra SDK, configuração/estrutura local, resolução da autorização (ausente/ambígua/ilegível/resolvida), conexão efetiva, tentativa e código, próxima tentativa, último dia publicado e parcial em curso. Dias GSC seguem America/Los_Angeles; horários operacionais usam o fuso do site, com rótulos explícitos. Prontidão local não comprova concessão ou coleta remota.

A leitura de diagnóstico não consulta Google, publica snapshot nem avança cursor. Sem concessão correta não há fallback para default. Coleta usa o SDK público search-console-reader/1.0.0 com usuário zero, origem Core e revisões do universo. Falha SQL ou contexto alterado não publica página incompleta. Retomada preserva acervo confirmado. Desligar limpa agenda e continuação próprias; não altera cron do Google.

SDK de medição produtor do Core continua site-measurement-context/1.0.0, schema 1, seis slots. Google 0.10.0 consome esse contrato independentemente da revisão administrativa 8.0.0. Não adotar campo extra sob schema fechado. Leitura de catálogo/snapshot não cria recursos Google.
