> Histórico da base 1.33.0. Para operação atual, leia AGENTES-1.34.0.md e RELEASE-1.34.0.md. Dependências futuras citadas abaixo pertencem à data da base.

# Core 1.33.0 → MCP e MCP Google

Documento para encaminhamento pelo responsável; não enviado a terceiros.

A implantação será direta da 1.31.0 para a 1.33.0 ou WordPress novo. A 1.32.0 não foi instalada. Checkpoint corrigido no Core: o alvo abre um ciclo próprio e arquiva o anterior, preservando corte de coleta e configurações. Não pedir repetição de hooks ou edição de estado privado como procedimento normal.

## Google — CORE-01/02 entregues no produtor

Fachada `F3Base_Medicao_Contexto::{capabilities,snapshot,events}`, contrato `site-measurement-context/1.0.0`. Schemas fechados em docs/schemas/, fixtures completas em docs/fixtures/measurement/. Consulte MEDICAO-SDK-1.33.md antes de implementar o consumidor.

Ajuste de contrato a incorporar: slot Meta contém também `server_pixel_id`; o Core pode emitir para um dataset de servidor diferente. Mapas sem parâmetros serializam `{}`. Tipos completos de policy/emission/provenance/event parameters estão nos schemas. Declarações de 22 eventos são geradas da fonte do runtime. Transporte Meta browser/servidor aparece como caminhos do mesmo evento lógico.

Não manter fallback às options privadas. Classes/métodos ausentes ou contrato sem suporte afetam somente a capacidade dependente; nenhum binding deve ser apagado. Revisão é opaca, inclui visão efetiva e política, exclui horário; filtros podem mudá-la. Leia antes/depois da descoberta e antes do commit. Não prometer atomicidade entre writers dos dois plugins.

`search-console-reader/1.0.0` permanece independente: grant explícito, conexão efetiva não necessariamente padrão, cron sem usuário, sem grants automáticos. Contrato Core 7.1.0, perfil 3.5; Google configuração 4.0.0 é outro número. Não existe leitor Ads de leads novo nesta entrega.

I01/T07/C14 aguardam o binário Google 0.8.6; a matriz local usa Google 0.8.5 e MCP 0.21.1. Não confundir teste do produtor com teste do adaptador Google futuro.

## MCP

As abilities `f3base/medicao-contexto-ler` e `f3base/medicao-eventos-ler` são leituras com `manage_options`; o transporte soma suas permissões. A documentação instalada inclui schemas/fixtures no leitor paginado.

O plano MCP 0.22.0 revisão 4 incluiu MCP-03/P09. Está resolvida a divergência documental com G08/GOOGLE-04/C16; implementar e provar `executor-registration/1.0.0` continua sendo trabalho MCP/Google. A Core não absorve essa bridge.

Enquanto não houver prova do executor corrigido, instalação nova com MCP 0.21.1 usa upload inativo e ativação explícita, seguida de nova requisição. Nenhum bloqueio numérico no Core.

## Implantador

A ponte JSON existente ficou concentrada em `F3Base_Implantador_Adaptador`; abilities e permissões preservadas. O validador privado ainda é necessário. A transferência dessa responsabilidade ou descoberta pública definitiva depende do dono do implantador; não houve alteração nele ou no tema.

## Observações da bancada desta entrega

MCP 0.21.1/Google 0.8.5: ordens invertidas e concessão GSC não padrão com usuário zero aprovadas. Não foram alterados os binários desses plugins.

O transporte MCP acrescenta `success`, `request_id` e `result_contract` à resposta da ability; o Core publica schemas específicos de ability aceitando esses metadados. O envelope PHP do SDK permanece fechado e independente. O HTTP tools/call pode ainda envolvê-lo em `success/data`; consumidores PHP não devem copiar esse envelope de transporte.

Uma tentativa de substituir o Core ativo pelo MCP 0.21.1 trocou os arquivos, mas retornou `package_verification_pending` / `activation_unconfirmed`, com `active_after: false`. Provas prévias de home/REST haviam passado. O ensaio não demonstra a causa exata do estado pendente. Solicita-se repetir esse percurso no executor corrigido do MCP, incluindo a leitura seguinte. Não usar resposta de upload ou versão do cabeçalho como prova de ativação.

A atualização direta final foi ensaiada pelo `Plugin_Upgrader` nativo do WordPress, preservando ativação e captura antes da conclusão administrativa. O fluxo alternativo de upload inativo/ativação explícita permanece orientação do plano MCP; não foi homologado novamente pelo Core nesta rodada. Nenhum inicializador privado do acompanhante foi chamado para contornar o problema.
