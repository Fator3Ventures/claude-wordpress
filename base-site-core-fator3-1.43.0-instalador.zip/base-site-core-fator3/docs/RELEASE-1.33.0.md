# Release 1.33.0

## Implantação

WordPress novo ou atualização **direta da 1.31.0**. A 1.32.0 não foi instalada na frota e não é uma etapa intermediária. Este pacote inclui suas funcionalidades. Não há bloqueio por número de versão de outro plugin; contratos e capacidades governam somente a integração dependente.

## Entregue

- Ciclo de instalação próprio da versão alvo, histórico do checkpoint anterior, leitura física com falhas explícitas, gravação condicional e reserva renovável. Finalização de outra versão não comprova esta atualização. Etapas comprovadas são retomadas, sem repetir a instalação inteira.
- Preservação de escolhas, listas vazias, procedência, marco de coleta, contatos, arquivos, concessões e filas da base. O servidor não é reaplicado por simples troca de release.
- `F3Base_Medicao_Contexto`: contexto público com seis slots, configured/effective, procedência, política, revisão e catálogo paginado. Duas abilities autenticadas. Leitura PHP funciona sem pessoa autenticada e não concede permissões Google.
- Catálogo declarativo de 22 eventos, schemas fechados e fixtures completas. Observação de formulário não vira outra conversão. Native Lead Sync não fabrica sessão web.
- Ponte do JSON do implantador isolada em um adaptador; as abilities preservam seu escopo. O validador privado ainda é uma dependência explícita, até existir contrato do implantador.
- Fronteira interna do cliente LinkedIn centralizada e diagnóstico de responsabilidade visível. Nenhum segredo copiado, nenhuma troca automática de leitor.
- Exclusão de 404 preservada durante a atualização do contexto no navegador; diagnóstico do ciclo na tela com horários legíveis.
- Documentação vigente instalada e consultável, inclusive schemas e fixtures do SDK.

## Incorporado da entrega não instalada 1.32.0

LinkedIn Lead Sync por polling e webhook opcional; reconciliação de assinaturas e recibo durável; ajustes de leitura/exclusão Slack; cotas independentes e diagnósticos Pipedrive; atribuição comercial ligada à sessão de captura; relatórios editoriais com cobertura e limites explícitos. Consulte os guias temáticos do índice.

## Limites de conclusão

O SDK produtor Core está entregue. A prova conjunta com o adaptador Google 0.8.6 (I01) aguarda seu binário. MCP 0.22.0 e sua bridge também dependem do pacote final.

A **troca para provedor LinkedIn externo não está implementada nem liberada**. Faltam entrypoint, métodos, schemas e provas de LI-04. P08 entrega somente a fronteira do cliente interno e diagnóstico; A23–A26 de troca externa e I02 continuam abertos. Não existe fallback silencioso nem um seletor que prometa uma troca impossível.

I03/L07/L14 exigem homologação com aplicação, conta, formulário, callback HTTPS e destino autorizados. Simulação local não comprova recebimento pelo LinkedIn, Slack, e-mail ou CRM. Nenhuma implantação em site real integra esta entrega.
