> Versão vigente: Core **1.43.0**, contrato **8.8.0**. Leia [RELEASE-1.43.0.md](RELEASE-1.43.0.md) e [AGENTES-1.43.0.md](AGENTES-1.43.0.md). Conteúdo de versões anteriores abaixo é histórico.

# Documentação corrente — Core 1.42.0

Comece por RELEASE-1.42.0.md e AGENTES-1.42.0.md. As notas anteriores são histórico, com nomenclatura editorial atualizada; não use instruções antigas para configurar o e-mail automático.

# Documentação instalada — Core 1.41.0

Contrato administrativo 8.6.0. Comece por [RELEASE-1.41.0.md](RELEASE-1.41.0.md) e [AGENTES-1.41.0.md](AGENTES-1.41.0.md). A ajuda atual está em AJUDA-OPCOES.md e dados/configuracao-schema.json, gerados do runtime. Documentos de versões anteriores abaixo são históricos; em divergência prevalecem as instruções 1.41.0.

## Índice histórico

> Versão atual 1.39.0, contrato administrativo 8.4.0. Consulte [RELEASE-1.39.0.md](RELEASE-1.39.0.md) e [AGENTES-1.39.0.md](AGENTES-1.39.0.md) para alterações 230–235 e bloqueios de aceite. Seções anteriores permanecem referência histórica.

# Documentação instalada — Core 1.38.0

Índice vigente. Ajuda estática: f3base/documentacao-ler, manage_options, arquivo/linha/limite até 200, SHA-256 e proxima_linha. Continue até nulo. Histórico não substitui estes procedimentos.

| Arquivo | Conteúdo |
|---|---|
| RELEASE-1.38.0.md | Links WhatsApp e atualização 1.37 → 1.38 |
| WHATSAPP-1.38.md | Configuração, campos, mensagens e aceite |
| AGENTES-1.38.0.md | Receitas, autorização, leitura e evidência |
| CONVERSOES-CONTEUDO-1.35.md | Configuração, eventos, deduplicação, Pipedrive e limite do SDK |
| CONVERSOES-SDK-1.36.md | Contrato opcional por finalidade, permissões e receitas |
| schemas/conversion-*.json / fixtures/conversion/*.json | Schemas e exemplos do contrato novo |
| PIPEDRIVE-1.37.md | Título, empresa, respostas, serviço, primeira atividade do lead, oportunidade e thread |
| CONFIGURACAO.md / AJUDA-OPCOES.md | Configuração e ajuda extraída do código |
| CONTRACTS.md / dados/abilities-*.json | Contratos e schemas integrais |
| dados/configuracao-schema.json | Contrato administrativo 8.3.0 |
| DICIONARIO-DADOS.md / dados/contrato.json | Tabelas, unidades, retenção e vínculos |
| ../dados/estado-inventario.json | Propriedade e backup de estado |
| MEDICAO-SDK-1.33.md / MEDICAO-EVENTOS-1.33.md | SDK 1.0.0 fechado; não inclui material |
| schemas/measurement-*.json / fixtures/measurement/*.json | Exemplos e schemas do SDK mantido |
| LINKEDIN-LEAD-SYNC.md / GSC-1.34.md | Integrações mantidas |
| OPERACAO-E-RECUPERACAO.md / VALIDACAO.md | Recuperação e tipos de prova |

RELEASE/AGENTES/IMPACTO/CORRECOES de versões anteriores são históricos. As regras comerciais desta release prevalecem sobre textos históricos. A leitura não ativa integrações nem comprova acesso a fornecedor.
