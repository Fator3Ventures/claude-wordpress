# Links de WhatsApp — Core 1.38.0
Pedidos core 229. A elegibilidade é a mesma da primeira atividade do lead da 1.37: celular BR com DDD válido/nono dígito, móvel PT, demais E.164 válidos por sintaxe. Não verifica conta WhatsApp nem envia mensagem. Fixos BR/PT, inválidos e ausentes não recebem link.

## Configuração
Ferramentas → Fator3 Site Core → Integrações → Pipedrive. f3base_pipedrive.whatsapp_texto é string opcional, até 1000 caracteres, padrão vazio. Variáveis {nome}, {empresa}, {unidade}; unidade é rótulo do catálogo local da conta. Texto vazio gera https://wa.me/5511912345678 (número sintético); preenchido acrescenta ?text= com codificação RFC3986. Para preservar URLs completas nos limites de Slack/resumo, o texto interpolado é cortado por caracteres até no máximo 1700 bytes após codificação. HTML de valores é removido.
Essa opção também governa o link dos avisos mesmo com Pipedrive desativado. pais_telefone é reutilizado (BR por padrão). Não exige credencial para gerar link.

## Onde aparece
Principal Slack: telefone clicável, mantendo número legível no texto alternativo. Thread Contato: linha WhatsApp. Formato completo também apresenta link; compacto tem o telefone clicável.
Resumo único dados.comunicacao_envio: linha WhatsApp em Contato; e-mail HTML e nota do Pipedrive têm âncora clicável. Resumos já congelados e mensagens entregues não são reescritos na atualização.
WhatsApp e tarefa Reenvio de formulário: link na nota junto ao marcador próprio. Outras primeira atividade do lead não incluem link.
Complemento da etapa 2 com campo de papel telefone: nova parte da thread e nota complementar recebem a linha WhatsApp usando o telefone atualizado, preservando o resumo inicial.

## Campos opcionais Pipedrive
mapa_campos.whatsapp_link aponta para campo de lead textual; mapa_pessoa.whatsapp_link aponta para campo de pessoa textual. Use a chave de 40 caracteres do catálogo da conta, nunca o exemplo sintético. Tipos varchar, varchar_auto ou text; sem mapa não escreve campo. Seleção inválida é recusada contra catálogo. Dois papéis não podem disputar a mesma chave no mesmo mapa. Links que excedem o tamanho do campo são omitidos integralmente, nunca truncados; prefira texto longo para mensagem predefinida.
Pessoa existente: enriquece apenas campo vazio, com releitura e confirmação; preserva valor anterior. Mapear WhatsApp não altera os identificadores usados para encontrar pessoas. Editor de LinkedIn preserva o mapa WhatsApp.

## Operação e prova
Use f3base/config-core-contrato-v1 e f3base/config-core-ler; configure por f3base/config-core-escrever com simulação/revisão conforme schema instalado. Contrato administrativo 8.3.0, perfil piso-padrao-3.5, 65 options operáveis, 130 abilities, delta zero. SDKs inalterados.
f3base/pipedrive-previa retorna whatsapp_link, campos_pessoa, campos_lead, nota e atividade.note. É prévia local, não prova entrega.
No Site-Teste, criar contato marcado de teste com celular e outro fixo; verificar principal/thread por f3base/avisos-slack-verificar e limpar apenas mensagens da rodada por f3base/avisos-slack-testes-apagar. Respeitar revisão e simulação dessas operações.
Aceite CRM real: CTOoffice/korvena.com.br com projeto Pipedrive, chaves reais e homologacao=true somente durante teste. Verificar nota e primeira atividade do lead na conta e remover recursos próprios sintéticos. O relatório distingue execução de pendência.
Marcas, consentimento, supressões, destino, autoria e deduplicação permanecem. Clique de WhatsApp sem formulário não entra no Pipedrive. Nenhuma fila histórica é reaberta por esta atualização.
