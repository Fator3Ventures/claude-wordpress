# SDK opcional de conversões por finalidade

Contrato: site-conversion-purposes/1.0.0 · Produtor: base-site-core-fator3 · Schema: 1.
Oferta publicada pelo Core 1.36.0 em resposta ao impacto Google 0.11.0 revisão 2.

## Descoberta

A classe pública F3Base_Conversoes_Contexto expõe capabilities() e snapshot(array).
Descobrir a classe e o método antes de usar; não comparar somente versão do plugin.
capabilities() retorna envelope ok/code/contract/provider/data.
Exigir contract igual a site-conversion-purposes/1.0.0, contract_version igual a 1.0.0 e schema_revision igual a 1.
O descritor anuncia métodos, capability conversion.purposes.read e os caminhos dos schemas.
Não acrescenta campos ao descritor de F3Base_Medicao_Contexto.
Ausência, unsupported ou unreadable suspendem apenas esta descoberta adicional.

```php
if (class_exists('F3Base_Conversoes_Contexto') &&
    is_callable(array('F3Base_Conversoes_Contexto', 'capabilities'))) {
    $descriptor = F3Base_Conversoes_Contexto::capabilities();
    if (($descriptor['contract'] ?? '') === 'site-conversion-purposes/1.0.0') {
        $response = F3Base_Conversoes_Contexto::snapshot(array(
            'contract' => 'site-conversion-purposes/1.0.0',
        ));
    }
}
```

## Negociação e revisão

snapshot exige contract; a ausência é invalid_input.
Uma string de contrato não suportada retorna unsupported.
expected_revision é opcional e aceita SHA-256 hexadecimal minúsculo.
Se a revisão mudou, retorna revision_conflict e data:null.
A projeção é lida duas vezes; filtro/configuração instável também retorna revision_conflict.
Não há paginação: as duas finalidades retornam juntas.
Parâmetros offset/limit e chaves desconhecidas são recusados.
Revisão representa a projeção efetiva, não observado_em ou consentimento de um visitante.
observed_at registra UTC; não usar esse campo como revisão.
Não repetir uma escrita remota por receber conflito desta leitura.

## Envelope

ok é booleano; code é ok, invalid_input, unsupported, unreadable, revision_conflict ou not_authorized.
contract e provider permanecem presentes em sucesso e erro.
Em erro, data é null; não interpretar como configuração vazia ou desligada.
Em sucesso, scope é site_configuration.
measurement_revision vincula a projeção do SDK de medição atual.
runtime_verified e remote_access_verified são false: esta leitura não verifica emissão nem acesso ao fornecedor.

## Finalidades

purposes contém contact e material, nessa ordem; consumidores devem localizar pela chave purpose.
contact usa ga4_event generate_lead e meta_event Lead.
material usa ga4_event download_material e meta_event MaterialDownload.
Eventos efetivos do Core são informados; não são nomes de ações primárias nem garantia de evento-chave na conta.
Os destinos são ga4, google_ads, meta e linkedin.
Clarity/GTM permanecem no SDK de medição e não são novas finalidades.

## Estados e identificadores

Cada destino informa enabled, configured, identifiers e provenance.
enabled indica a política local do propósito e a disponibilidade dos módulos; material respeita seu próprio interruptor.
configured indica identificadores públicos necessários não vazios e válidos para o destino/modo descrito. Não confirma token, concessão, tag carregada ou recebimento.
IDs públicos vazios permanecem strings vazias; dados inválidos que não podem ser projetados com segurança ficam null.
GA4 fornece measurement_id.
Google Ads fornece conversion_id AW e conversion_label.
LinkedIn fornece partner_id e conversion_id.
Meta fornece pixel_id e server_pixel_id, preservando a herança publicada entre Pixel e CAPI; não retorna token.
O estado pode ser enabled:true e configured:false. Isso é esperado quando o dono ligou material antes de cadastrar sua ação.
Consentimento, classificação de teste, disponibilidade em execução, modo Meta e fornecedor continuam condicionando o envio.

## Separação obrigatória

Material Google Ads usa f3base_google_ads.conteudo_conversion_label.
Material LinkedIn usa f3base_linkedin_conteudo_conversion_id.
Esses valores vazios não herdam conversion_label ou conversion_id do contato.
GA4 measurement_id e Ads conversion_id AW identificam destinos compartilhados; o evento/rótulo diferencia a finalidade.
A presença da finalidade material não autoriza criar evento-chave, ação primária, tag, campanha ou assinatura.
Google 0.11.0 ainda não implementa o consumo deste contrato.
O SDK site-measurement-context/1.0.0 permanece integralmente compatível e sem download_material em seu catálogo fechado.

## Procedência

provenance é uma lista por destino.
field destination contém a procedência do slot base; enabled identifica o interruptor de material; conversion_label/conversion_id identificam a configuração própria de material.
recorded_origin, channel e recorded_at mostram somente metadados públicos permitidos.
record_status distingue confirmed, unconfirmed, unknown e default.
effective_source distingue configured, default, filtered e unknown.
changed_by_filter pode ser true, false ou null quando não há evidência suficiente.
Mistura de procedências não recebe autoria inventada; a informação adicional está nos campos específicos.
Nenhum ID de pessoa, token, payload de contato ou decisão individual de consentimento integra o contrato.

## MCP e autorização

Descobrir f3base/conversoes-contexto-ler pelo catálogo do MCP.
Entrada: {"contract":"site-conversion-purposes/1.0.0"}.
Para guarda: acrescentar expected_revision com a revisão recebida.
A ability e sua execução direta exigem manage_options, verificado no servidor.
A leitura PHP interna funciona sem usuário autenticado, pois só projeta identificadores/configuração públicos. O plugin consumidor precisa aplicar sua própria autorização administrativa antes de expor dados e antes de operar contas.
Nada concede autorização Google ou permite contornar grants de outro provedor.
A leitura não grava opções, renova tokens, agenda cron nem chama APIs.

## Schemas e exemplos

schemas/conversion-capabilities.json: envelope do descritor.
schemas/conversion-snapshot-input.json: entrada estrita, sem paginação.
schemas/conversion-snapshot.json: resposta PHP estrita.
schemas/conversion-ability-snapshot.json: resposta com decoração administrativa do transporte.
fixtures/conversion/capabilities.json: descritor.
fixtures/conversion/material-enabled-ids-empty.json: interruptores ligados, ações de material vazias.
fixtures/conversion/material-own-id.json: ID próprio de material distinto do contato.
fixtures/conversion/unsupported.json: versão não suportada.
fixtures/conversion/revision-conflict.json: revisão obsoleta.
Exemplos são sintéticos; não copiar identificadores para produção.

## Leitura documental completa

f3base/documentacao-ler sem parâmetros retorna índice e allowlist.
Usar arquivo docs/CONVERSOES-SDK-1.36.md, linha:1 e limite até 200.
Continuar em proxima_linha até null; conferir versao e sha256 iguais em todas as páginas.
A mesma leitura aceita os schemas e fixtures catalogados.
Travessia de diretórios, URLs e caminhos fora da lista são recusados.
Somente a documentação local é lida; não há verificação remota implícita.

## Adoção pelo consumidor

Validar descritor e versão exata antes do snapshot.
Validar resposta contra o schema publicado, inclusive falsos e nulls.
Testar ausência do Core, versão não suportada e revisão concorrente.
Testar material habilitado sem IDs próprios e nunca substituir pelo contato.
Preservar o leitor antigo durante a transição.
Declarar separadamente implementação do consumidor e homologação da conta.
