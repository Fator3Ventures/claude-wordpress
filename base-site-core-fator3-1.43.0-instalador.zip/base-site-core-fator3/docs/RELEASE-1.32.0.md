> Histórico da entrega preparada 1.32.0, não instalada na frota. Seus recursos estão incorporados na 1.33.0. Implantação vigente: RELEASE-1.33.0.md.

# Release 1.32.0

Contrato Core 7.0.0; perfil 3.5. Referência de implantação: WordPress novo ou Core 1.31.0. Não há veto por versão, presença ou ordem de carregamento dos acompanhantes. Contratos observados decidem apenas a disponibilidade das integrações correspondentes.

## Mudanças

| Pedido | Entrega |
|---|---|
| 194 | Resposta Slack é localizada dentro da thread pelo `ts` exato. Comparação normaliza somente equivalências seguras. Exclusão aceita permanece pendente até releitura comprovar ausência. |
| P2–P4 | Diagnóstico por capacidades; estrutura atual e complementações conservam escolhas, listas vazias, segredos, procedência e história. Conversores e reparos de releases antigas foram retirados. |
| 209 | Cotas independentes por consumidor, conta, site e dia UTC; qualidade com cadência adaptativa; alertas locais deduplicados de entregas reais. |
| 210 | `mensagens.baixar_conteudo`, padrão “Baixar conteúdo”; vazio restaura padrão. Texto é tratado como texto, sem HTML. A alteração não muda concessão, quota, validade ou cabeçalhos privados. |
| 211 | Na comunicação comercial, sessão paga da captura com evidência suficiente prevalece; primeiro/último toque analíticos permanecem preservados. |
| 212 | Relatório editorial lê fontes em lotes e recusa de forma estruturada quando ultrapassa os limites. Comparativo indisponível não vira zero. |
| 213 | Identificação de LinkedIn por `li_fat_id` ou UTM paga coerente; conflito é explícito. Conversão web ocorre após captura aceita. |
| 214 | Captura nativa LinkedIn, consulta horária, recibos duráveis, endpoint autenticado e cadastro de assinaturas próprias pelo Core. Webhook opcional nesta release. |

## Atualização

Instale o ZIP preservando o banco e a pasta privada. A primeira requisição carrega o código atual; estrutura, complementações e reconciliação do próprio servidor são concluídas pelo executor com checkpoints. Consulte `saude-ler` e `executar-pendentes`; gravação local, aplicação no servidor e comprovação HTTP são evidências distintas. Não use ausência de plugin acompanhante para impedir a instalação.

A instalação atual usa `f3base_instalacao`. O marcador 1.31 pode fornecer evidência anterior, sem reexecutar conversores históricos nem apagar registros. A retirada de `config-procedencia-reparar` é deliberada: leitura da procedência/complementações continua disponível. Valores novos adicionados a opções compostas preservam a autoria, canal e data da escolha anterior; a revisão do valor pode mudar porque seu conteúdo foi complementado.

Credenciais, filas, contatos, acervos, concessões e histórico válidos da 1.31 permanecem. Concessões de conteúdo continuam seguindo a versão vigente do arquivo, conforme o contrato preservado. Não há garantia de retorno para pacotes anteriores.

## Ativação LinkedIn

F3 Base → Configurações → Conexões e entregas → Origens de anúncios → LinkedIn. A consulta periódica e o recebimento imediato são controles distintos. Instalar não ativa nenhum deles. Leia LINKEDIN-LEAD-SYNC.md antes de cadastrar credenciais e assinaturas.

## Limites da comprovação

A bancada usa WordPress, MySQL, Chromium e endpoint HTTP locais, com transportes de fornecedores simulados. Não comprova aprovação de aplicativo, permissões da conta, recebimento em caixa de e-mail, leitura humana de Slack nem negócio real no CRM. L07 e L14 do plano permanecem homologações remotas: aplicativo aprovado, formulário do site, teste LinkedIn, assinatura e revalidação efetivas, depois entrega comercial autorizada. A versão não foi implantada em produção.
