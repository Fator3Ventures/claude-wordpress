# Fator3 Site Core 1.34.0

Base direta: 1.33.0. Slug e arquivo principal preservados. Contrato administrativo 8.0.0; SDK de medição site-measurement-context/1.0.0, schema 1, seis slots, sem expansão. Normas comuns: revisão 4; plano Core revisão 4 e especificação do consumidor LinkedIn revisão 3.

## Mudanças

- GSC: apresentação única no painel e na operação, separando estrutura, SDK, autorização, conexão efetiva, última tentativa, próximo horário, último dia publicado e coleta parcial. Diagnóstico não faz HTTP nem coleta. Dados e datas usam os fusos declarados.
- LinkedIn: configuração canônica por integração; a base vira `principal`, cliente `core`, uma vez. Preserva callback, referências cifradas, procedência, cursores e aquisição. Clientes explícitos Core e plugin LinkedIn, sem fallback; uma conta/formulário não pode estar ativa em dois fluxos. Cliente externo usa somente interfaces públicas.
- Troca LinkedIn: prévia, revisão, chave idempotente, diário durável, reservas por integração, pausa e commit recuperável. Sem histórico de assinaturas, troca nos dois sentidos preserva o marco confirmado. Com assinaturas anteriores, falta de prova sobre notificações em trânsito impede promoção; ver LINKEDIN-LEAD-SYNC.md.
- Slack: equivalência ignora `verbatim` em mrkdwn e `emoji` em plain_text nos dois lados; mantém texto, links, tipo e ordem.
- Pipedrive: catálogo e prova de conta usam identidade estável de conta/domínio/instalação/credencial. Orçamento/homologação não invalidam catálogo comprovado. Guardas completas dos lotes continuam vigentes.
- Qualidade CRM: distribuição por confirmação mais antiga; cobertura compatível com orçamento; três confirmações terminais iguais, separadas por pelo menos 24 horas, encerram consulta recorrente. 404, erro e won/lost não comprovam apagamento. Evento autenticado ou consulta individual autorizada reabre acompanhamento.
- Editorial: orçamento calcula limite efetivo, uso e reserva com unidades; diferencia inválido, ilimitado e zero. Lotes adaptativos mantêm agregação exata e o teto real de 100 mil registros.
- Alertas operacionais: destino exclusivo `admin_email`; não usam Slack, webhook comercial nem `email_leads`. Aceite do correio não prova recebimento.
- GTM: remover o contêiner encerra espera esgotada e agenda própria por reconciliação, sem reativar tarefa; ausência retorna `nada_a_verificar` sem HTTP. ID inválido é distinto de ausente.
- Ajuda da conversão LinkedIn: o gatilho é aceite do contato, inclusive formulário de conteúdo, com consentimento aplicável. Clique ou validação recusada não é aceite. Menu de recuperação: Site Core.

## Instalação e prontidão

Instalar em WordPress novo ou atualizar diretamente da 1.33.0. Não usar versão intermediária. A ativação abre ciclo próprio da 1.34.0; consultar prontidão em nova requisição e aguardar confirmação posterior. Não apagar estados para forçar sucesso. A instalação não depende de acompanhantes; seus contratos são conferidos apenas ao operar a integração.

Referências de bancada: MCP 0.23.0, Google 0.10.0, LinkedIn 0.2.0 e Meta 0.2.0. A matriz externa pode ter versões diferentes; o relatório identifica cada ambiente. Nenhum teste com transportes simulados comprova chegada de e-mail, lead remoto, Slack, CRM ou conversão publicitária.

## Banco e reversão

Novas colunas na fila Pipedrive: qualidade_confirmada, qualidade_encerrada, qualidade_terminal_em, qualidade_terminal_contagem e qualidade_contexto. Configuração/estado LinkedIn passam a coleção de integrações; não há cópia de cofre externo. Preservar banco, pasta privada e guarda operacional em backup. Retornar apenas os arquivos à 1.33.0 não desfaz a mudança de configuração: reversão exige backup compatível do banco e reconciliação dos efeitos externos. Nunca repetir POST incerto por ausência em uma listagem.

## Limites

Provas remotas I03, chegada de e-mail, exclusão Slack, Pipedrive nos ambientes do pedido e observações de 24/48 horas exigem recursos autorizados e evidência própria. Relógio de bancada acelerado não substitui observação real. Consulte o relatório externo para o estado final, hashes e matriz N01–N49.
