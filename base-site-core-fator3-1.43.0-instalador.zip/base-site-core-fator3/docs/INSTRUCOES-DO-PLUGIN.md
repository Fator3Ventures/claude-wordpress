> Versão vigente: Core **1.43.0**, contrato **8.8.0**. Leia [RELEASE-1.43.0.md](RELEASE-1.43.0.md) e [AGENTES-1.43.0.md](AGENTES-1.43.0.md). Conteúdo de versões anteriores abaixo é histórico.

> Versão atual 1.39.0, contrato administrativo 8.4.0. Consulte [RELEASE-1.39.0.md](RELEASE-1.39.0.md) e [AGENTES-1.39.0.md](AGENTES-1.39.0.md) para alterações 230–235 e bloqueios de aceite. Seções anteriores permanecem referência histórica.

> Atualização 1.37.0: consulte RELEASE-1.37.0.md e PIPEDRIVE-1.37.md; base direta 1.36.0, contrato administrativo 8.2.0. Evidências atuais no relatório externo; provas históricas abaixo mantêm seu escopo original.

# Instruções do plugin

Leia DOCUMENTACAO.md, AGENTES-1.36.0.md e CONVERSOES-SDK-1.36.md. Documentos anteriores são históricos quando houver divergência. Normas comuns revisão 4.
