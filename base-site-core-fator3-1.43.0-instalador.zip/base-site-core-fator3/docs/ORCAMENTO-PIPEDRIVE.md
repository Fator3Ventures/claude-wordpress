# Orçamento Pipedrive — Core 1.32.0

| Consumidor | Padrão por dia UTC | Uso |
|---|---:|---|
| Entregas | 3000 | Pessoa, organização, oportunidade, nota e demais efeitos da entrega |
| Qualidade | 600 | Consultar andamento comercial para retorno de qualidade |
| Verificação | 600 | Acesso, catálogos e operações explícitas de verificação |

São estimativas locais: GET/pesquisa 20 unidades, escrita 10. Não representam o saldo oficial da conta. Configuração explícita anterior, inclusive 10000, permanece. Contador misto da 1.31 fica identificado como anterior sem discriminação e continua comprometido até a próxima virada UTC; não é zerado ao atualizar.

Escopo: instalação/site + conta efetiva + consumidor + dia UTC. Reserva atômica antes da chamada evita ultrapassar o teto em concorrência. Falha comprovadamente anterior ao despacho devolve a reserva; timeout após despacho continua contado. Reserva cujo processo não confirmou término fica comprometida até a virada UTC. Diagnóstico separa consumido estimado, reservado, saldo e próxima janela. Em disputa de reserva, a fila pode aguardar a próxima passagem.

Qualidade lê no máximo uma vez por hora no primeiro dia após observação/mudança, seis horas quando estável e um dia em estado terminal. Erros aplicam recuo. A cota padrão de 600 permite aproximadamente trinta leituras por dia; uma carteira maior exige orçamento escolhido pelo dono. Qualidade esgotada não consome a reserva de novas entregas. `429` do fornecedor e pausa remota continuam compartilhados entre consumidores.

Falha de rede, autenticação ou permissão ao ler lead não é prova de conversão em negócio. A ponte só é procurada com evidência de remoção; uma vez confirmado o negócio, a consulta usa esse ID. Não recriar lead antigo nem repetir pesquisa de pessoa por erro de rede.

Alerta de orçamento exige integração ativa e contato real aceito ainda pendente da conta atual. Só testes não abrem alerta de produção. A ocorrência é deduplicada, inclui pendência mais antiga, consumidor, motivo e retomada prevista, e usa painel e destinos já habilitados (e-mail, Slack ou JSON). Aceite de transporte não equivale a recebimento humano; não há repetição cega em caso incerto.

O destino JSON recebe `schema: f3base.operacao.v1`, `tipo: pipedrive_orcamento`, `event_id`, `site`, `mensagem` e `pendentes`, assinado pelos mesmos headers HMAC do webhook de avisos. O receptor deve distinguir eventos operacionais de contatos; não criar um lead para esse schema.
