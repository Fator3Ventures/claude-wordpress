# Fator3 Site Core 1.35.0

Base direta: 1.34.0, sem versão intermediária. Mínimos declarados e ensaiados: WordPress 7.1.2, PHP 8.3.6, 64 bits. Instalação única. Identidades publicadas preservadas. Contrato administrativo 8.1.0; SDK de medição 1.0.0/schema 1 mantido com seis slots e enumeração de eventos fechada.

## Pedidos desta rodada

- 212(a): limite de memória efetivo conserva a base `memory_get_usage(true)`, a mesma arena fiscalizada pelo PHP. A reserva passa de 20 MiB fixos a 10% da folga, mínimo 256 KiB e máximo 20 MiB. Libera caches do alocador no início. Diagnóstico separa arena, memória viva, pico, consumo antes da consulta e crescimento por fonte retida. Não atribui bytes a plugins sem instrumentação. Mantém teto de 100 mil linhas por fonte, contagens exatas, lotes e recusa explícita. Não aumenta memory_limit.
- 219: cabeçalho passa a declarar os mínimos efetivamente validados em instalação nova e atualização da base.
- 220: blocos presentes nos dois lados são comparados pelo conteúdo canônico exibido, ignorando fallback de notificação reconstruído, block_id, emoji em plain_text e verbatim em mrkdwn. Preserva texto, URLs, tipos e ordem. Sem blocos comparáveis, normaliza escapes/autolinks HTTP e mailto; alterações relevantes continuam divergentes. Alteração exclusiva do fallback com blocos intactos não é divergência do conteúdo exibido.
- 221: campos varchar/text de leads originados na Meta recebem os rótulos do catálogo das alternativas; múltiplos separados por vírgula. Alternativa não catalogada usa sua chave; resposta livre é preservada. Enum/set mantêm os IDs do Pipedrive.
- 222: material e contato têm eventos, destinos e reservas distintos. Ver CONVERSOES-CONTEUDO-1.35.md. Pipedrive usa mapa_pontos.conteudo com fallback a site se ausente. Relatório comercial inclui intencao; integrado inclui envios_contato/envios_material e visão intencoes.
- 223: coleção associativa do LinkedIn vira lista antes do espalhamento de array_merge. Tela Conexões e entregas ensaiada até o botão de salvar com conexão principal pausada.

## Instalar, verificar e recuperar

Faça backup compatível do banco e arquivos privados. Instale o ZIP instalador, preservando pasta e basename. O ciclo passa a 15 etapas, incluindo conversoes_conteudo, com confirmação em requisição posterior. Não apague estado nem force prontidão. Confira saude-ler, versão, etapa concluída e finalizacao_em em requisição independente.

As novas opções não ativam destinos de material automaticamente. Configurações de contato permanecem. Na atualização, reservas antigas de material migram para domínio separado por formulário; pendências CAPI Lead associadas a material são suspensas como evento_material_legado. Não altera entregas já confirmadas, não reclassifica fatos históricos e não reenvia como outro evento. Filas incertas/em envio exigem reconciliação. Voltar só os arquivos pode retomar comportamento antigo: usar backup completo compatível e suspender/reconciliar efeitos externos.

Acompanhantes de referência: MCP 0.23.0, Google 0.10.0, LinkedIn 0.2.0, Meta 0.2.0. A presença não comprova integração remota. Core instala sem esses acompanhantes; a operação verifica contratos pertinentes. Provas e limites finais estão no relatório externo do instalador exato.
