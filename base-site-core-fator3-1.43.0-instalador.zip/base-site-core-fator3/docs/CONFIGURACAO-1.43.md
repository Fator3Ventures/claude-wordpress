# Configurações 1.43

Textos de confirmação e avisos: Configurações → Contato permite editar título, expiração, continuação, nome acessível do WhatsApp, títulos e link dos avisos e resumo da equipe, com prévia. Os resumos aceitam {quantidade}. Os textos são escapados na apresentação e não alteram destinos, permissões ou mensagens já enviadas.

Avisos: selecione o canal, os destinatários e o transporte. Para aplicativo Slack, salve o token, atualize os canais e escolha um nome. O teste cria mensagem somente ao acioná-lo explicitamente. Webhook e bot são alternativas de transporte.

Pipedrive: salve a conta e o token, atualize o catálogo e escolha os campos pelo nome. Os editores conservam os códigos no transporte interno. Não copie códigos de outra conta. Uma alteração de catálogo exige verificar as alternativas antes de ativar.

Origens: salve a conta/credencial; descubra ativos; selecione e salve; confira o mapeamento; depois habilite. Para Meta, salve as páginas antes de descobrir os formulários. Google usa o MCP Google habilitado com acesso de leitura Ads. A consulta de catálogo não importa respostas.

Retenção: Configurações → Privacidade e segurança. Testes: Configurações → Medição e anúncios → Testes e homologação. Estados e ações de entrega: Operação.

Catálogos temporários de descoberta usam transientes `f3cat_*`, expiram em uma hora e podem ser descartados; não são fonte de autorização. `f3base_email_teste_*` guarda autorização de uso único por quinze minutos, sem credencial. Fontes oficiais mantêm hash, obtenção e validade, não IP do visitante.
