# Guia para agentes — Core 1.36.0

Leia DOCUMENTACAO.md, RELEASE-1.36.0.md e CONVERSOES-SDK-1.36.md.
Base direta 1.35.0; instalação limpa em ambiente descartável. Requisitos WP 7.1.2/PHP 8.3.6 64 bits. Configuração administrativa 8.1.0 preservada.

1. Descobrir f3base/documentacao-ler, f3base/saude-ler, f3base/medicao-editorial e f3base/avisos-fila-ler.
2. Ler schemas e documentação com paginação e hash estável.
3. Consultar saúde sem efeitos e conferir versão/ciclo antes de operar.
4. Para relatório, usar período explícito e filtros de segmento/automação/anotações. Exemplo: de 2026-09-16, ate 2026-10-13, visao aquisicao, segmento sem_testes, automacao audiencia, anotacoes true, limite 5.
5. Em recusa, examinar memory_limit_bytes, fonte_maior_crescimento e fonte_consulta_recusada. Não elevar memory_limit automaticamente nem interpretar erro como tráfego zero.
6. Para avisos, consultar fila/partes/proxima_execucao. O reparo de evento ausente ocorre no executor WP-Cron, sem necessidade de cron/schedule manual. Confirmar passagem http_cron e estados entregues.
7. Se houver incerto, reconciliar no fornecedor antes de reenvio; respeitar suspensões, destino congelado e limites. Testes devem usar dados marcados e destino autorizado.
8. Para descoberta de material, negociar o SDK adicional e consultar conversoes-contexto-ler; não procurar download_material no catálogo antigo fechado.

Configuração: f3base/config-core-ler e f3base/config-core-escrever usam nome, valor, revisão e simulação conforme schema vivo. Tela Conexões e entregas mantém opções anteriores. Não ligar integração ou completar ID próprio por inferência.
A atualização não reseta interruptores, inclusive todos true com Ads/LinkedIn próprios vazios. Sem mudança de credenciais. Instalação não prova entrega no fornecedor.
Backup: banco, arquivos privados, guardas e pré-imagem. Voltar arquivos não desfaz mensagens, dados nem ações remotas. Não apagar estado de outro pacote. Normas comuns revisão 4 preservadas.
O relatório externo registra provas e limitações da entrega; produção CTO e adoção Google são aceites próprios.
