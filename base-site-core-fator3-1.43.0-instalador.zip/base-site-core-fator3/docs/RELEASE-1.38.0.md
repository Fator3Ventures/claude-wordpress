# Fator3 Site Core 1.38.0
Base direta 1.37.0; instalação limpa. WordPress 7.1.2 e PHP 8.3.6.
- 227: guias AGENTES-1.36.0.md e CONFIGURACAO.md corrigidos para config-core-escrever e piso-padrao-3.5; nenhum alias.
- 228: relatório identifica os quatro campos da confirmação e latência esperada/observada.
- 229: links WhatsApp em Slack, resumo, e-mail, notas/atividades e campos opcionais; veja WHATSAPP-1.38.md.
Contrato 8.3.0 aditivo, 65 options operáveis, 130 abilities sem entrada/saída; perfil e SDKs inalterados. Completa whatsapp_texto vazio, preserva escolhas, não ativa integrações nem modifica banco estrutural.
Atualização concluída exige f3base/como-usar: atualizacao.versao_alvo=1.38.0, estado=concluida, falhas=0 e confirmada_no_executor_em positivo. Planejar 2–6 minutos após upload (observação da frota na 1.37); cron e hospedagem podem aumentar esse tempo. Não confundir HTTP 200 com confirmação.
Restaurar ZIP 1.37 não desfaz campos/mensagens externos; backup de arquivos e banco é necessário. Publicação raw e implantação de frota pertencem ao responsável da frota.
