# Core 1.42.0 — histórico comercial e e-mail automático

Atualização direta da 1.41.0 ou instalação limpa. Pedidos core 238–242. Contrato administrativo 8.7.0; transporte Google inalterado, compatível com o método sendBound da versão 0.15.0.

## Configuração e uso

Em Configurações → Conexões e entregas → E-mail automático ao novo lead, configure `f3base_email_novo_lead`: marca, remetente, smtp_host, smtp_porta, smtp_seguranca (tls/ssl), smtp_usuario, nome_exibicao, assinatura e texto_unidade. Contato e whatsapp_url são opcionais. Nenhuma identidade comercial é preenchida em instalação nova. A ausência da configuração completa impede envio.

Prepare com ativo=false. Salve a senha no campo mascarado, que usa `f3base_email_novo_lead_smtp_senha`; vazio mantém e apagar remove. O formulário inclui revisão da configuração e da senha. Reabra se outra sessão tiver alterado os valores. Reserve a cota de destinatários por hora, confirme alocacao_confirmada e só então ative. A cota inclui o destinatário, a cópia ao remetente e o Smart Bcc, removendo endereços duplicados. Ela não aumenta a cota do provedor.

`textos_servicos` associa IDs às apresentações aprovadas; as alternativas são lidas do campo Serviços mapeado na conta Pipedrive verificada. A tela lista as alternativas e permite editar o mapa. Mudanças exigem alternativa existente; textos anteriores são preservados quando o catálogo estiver indisponível. Serviço selecionado sem texto bloqueia o envio. Sem serviço, usa texto_unidade.

O corpo confirma o recebimento e informa que vamos entrar em contato, sem prometer horário ou canal. Não depende do prazo da primeira atividade do lead. Assinatura e textos aprovados são configurações do site. Somente contatos elegíveis aceitos durante ativação, com novo lead confirmado no CRM, geram intenção. Reenvios, negócios, leads reutilizados e testes não autorizados permanecem excluídos.

Para testar, cadastre uma caixa controlada em homologacao_emails, crie um contato de teste com novo lead confirmado e invoque `f3base/email-novo-lead-homologar` com record_id e confirmar=true. Autoriza uma única intenção por uma hora. A consulta `f3base/email-novo-lead-ler` exige administração e retorna estados sem corpo ou credenciais. SMTP/Smart Bcc reais exigem homologação autorizada.

A mesma tela mostra ativo, cota usada na última hora, contagem de intenções por estado e último código de erro sanitizado. Em Credenciais complementares há campos cifrados, com apagar e revisão, para token Meta de qualidade, segredo do webhook Pipedrive, URL privada do webhook de avisos, token e Client Secret LinkedIn.

## Histórico no Pipedrive

Notas novas incluem contato, respostas, formulário/página, campanha/anúncio disponíveis, data/hora e link privado do registro WordPress. Dados técnicos e de medição permanecem no WordPress. O assunto da atividade de e-mail é configurável, com padrão “E-mail – primeiro contato”; sua nota contém somente data e hora do aceite SMTP. Não é uma confirmação de entrega na caixa de entrada.

IDs, provas de criação, hashes e operações incertas permanecem no diário local. Notas com resposta perdida são reconciliadas pelo conteúdo esperado, que contém o link do registro. Atividade WhatsApp existente no lead é reaproveitada sem sobrescrever as edições da equipe. Várias candidatas exigem revisão; ausência de confirmação de criação nunca autoriza um novo POST. Atividades de e-mail com resposta perdida ficam incertas, sem repetir o e-mail nem criar outra atividade automaticamente; confira a conta antes de qualquer recuperação administrativa. Notas antigas externas não são reescritas em massa.

## Migração e reversão

O coordenador de instalação migra nomes da configuração, cota, senha, tabela, agenda e referências das intenções. A senha é aberta com a chave antiga e recifrada com o nome novo. Dados comerciais que eram fixos são materializados somente para configuração legada existente, preservando seus valores. Não são defaults de sites novos. Estados incertos, IDs e cotas são preservados; corpos ainda pendentes são regenerados sem promessa de prazo. Os nomes antigos das duas abilities permanecem aliases por esta versão, documentados no relatório externo e no catálogo técnico. A compatibilidade está isolada em compat/email-legado.php.

Faça backup de arquivos, banco e salts antes da troca. As opções antigas ficam apenas como pré-imagens, sem uso pelo envio atual; a tabela é renomeada. Voltar somente os arquivos não restaura o estado anterior e pode perder deduplicação. Para reverter, suspenda executores e restaure backup coerente, reconciliando qualquer efeito externo posterior. Não apague filas nem reenvie resultados incertos.

## Consulta de conversões

`f3base/conversoes-contexto-ler` agora tem um só schema de entrada, com contract restrito a site-conversion-purposes/1.0.0 ou /1.1.0 e expected_revision opcional. Cada contrato conserva sua saída. A leitura é local, sem efeitos ou credenciais e exige manage_options.

## Limites

Teste local com WordPress e fornecedores simulados não comprova caixa postal, Smart Bcc ou histórico real no CRM. Instalação da frota, homologação em caixas controladas e conferência do histórico comercial são etapas distintas. Atribuição GA4, Ads real e navegador/WebView mantêm os limites anteriores.
