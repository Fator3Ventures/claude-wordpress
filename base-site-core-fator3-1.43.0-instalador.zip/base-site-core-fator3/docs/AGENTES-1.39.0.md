# Agentes — Core 1.39.0

Leia RELEASE-1.39.0.md e os schemas atuais antes de operar. Escopo exclusivo 230–235. Use documentacao-ler sem arquivo para índice, depois arquivo/linha/limite (até 200). A leitura retorna hash/versão e paginação. Não habilite conversão de produção sem aceite do adaptador Google e configuração coordenada Ads/Meta. Simulação de recuperação não envia. Respeite resultado incerto e nunca force reenvio sem reconciliação.
