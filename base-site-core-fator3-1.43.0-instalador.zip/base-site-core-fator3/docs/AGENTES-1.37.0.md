# Guia de agentes — Core 1.37.0

1. Leia DOCUMENTACAO.md, RELEASE-1.37.0.md, PIPEDRIVE-1.37.md e o contrato efetivo. Use f3base/documentacao-ler com arquivo, linha e limite até 200; continue proxima_linha até null e confira versao/sha256. A leitura exige manage_options e não chama fornecedor nem altera estado.
2. Preserve identidade do plugin e base direta 1.36.0. Descubra abilities e schemas pelo provider base-site-core-fator3. São 130 abilities, 65 opções operáveis, contrato administrativo 8.2.0. Não confundir 68 entradas catalogadas ou 67 opções do arquivo de referência com as operáveis. Perfil piso-padrao-3.5 inalterado.
3. Para Pipedrive, leia f3base_pipedrive e sua revisão, confira catálogo/estado, simule a alteração e grave pelo canal oficial com revisão esperada. Deltas e chaves reais são fornecidos pela conta, não pelo exemplo. O token não deve entrar em relatório, JSON público ou fonte.
4. Use f3base/pipedrive-previa com record_id e permissão administrativa: título, organização, serviço, campos, plano de atividade e qualidade são projeções locais. A prévia não confirma identidade, oportunidade ou atividade remota.
5. f3base/pipedrive-fila-ler informa a entrega; resultado incerto exige releitura/reconciliação. Nunca repetir POST para resolver timeout sem conferir o marcador e a referência remota. Preservar filas e provas de autoria; reutilizar oportunidade não autoriza sua exclusão.
6. Retorno comercial vai à thread do aplicativo Slack já confirmado. Não cadastrar outro destino ou usar envio direto para contornar pendências. Supressão de testes, 429, limpeza, troca de destino e timeout continuam válidos.
7. Homologação comercial real só em CTOoffice/korvena.com.br conforme a decisão do dono. Site-Teste é destinado à instalação/documentação. Requer coordenação com Pipedrive, IDs reais de campos e serviços, formulário/cookie de teste e limpeza dos dados sintéticos pelo responsável.
8. Relate instalação nativa, mocks e fornecedor real separadamente. Não declare causa dos casos Apex sem payloads/IDs históricos. Não altere Implantador, Google, Meta, LinkedIn, regra comum ou publicação da frota por inferência.

Os SDKs de medição/conversões da 1.36 permanecem íntegros. Informações técnicas/administração não ficam públicas apenas por estarem acessíveis via MCP; o conector aplica política adicional à capacidade WordPress.
