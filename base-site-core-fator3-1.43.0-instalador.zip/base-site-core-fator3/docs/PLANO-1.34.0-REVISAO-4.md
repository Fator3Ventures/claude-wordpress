# Fator3 Site Core 1.34.0 — plano da próxima versão

**Revisão 4 — 16/10/2026, America/Sao_Paulo.** Substitui a revisão 3 após receber `Fator3 Site Core.md`. Planejamento; versão-base 1.33.0 inalterada, alvo 1.34.0 ainda não implementado.

## O que mudou nesta revisão

| Mudança | Decisão atual |
|---|---|
| Base da frota | Documento recebido informa 1.33.0 nos 12 sites; leitura própria confirma o Site-Teste. Percurso exigido: instalação limpa ou 1.33→1.34. |
| Oito pedidos pendentes | 194, 209, 212, 213, 215, 216, 217 e 218 entram como P08–P15, preservando seus subitens e os 34 aceites anteriores. |
| Prioridade | Alertas para admin_email, catálogo Pipedrive, GTM sem contêiner e diagnóstico de memória precedem expansão funcional. |
| Precisão dos achados | Slack já normaliza parte de emoji; relatório já lê memory_limit. Confirmar a causa dos incidentes sem assumir que o relato comprova o mecanismo inteiro. |
| LinkedIn | Escopo P06/I02/I03, SDK recebido e bloqueios R3-LI-01/02 preservados; especificação revisão 3 continua vigente. |
| Entrega | Padrão e instruções de agentes revisão 3 aplicados; cinco impactos individuais e ZIPs da base inalterados nesta rodada. |

P01–P15 e N01–N49 formam o escopo. N35–N49 são novos critérios planejados; nenhum foi declarado aprovado nesta rodada.

## 1. Decisão de escopo e base

A 1.34.0 deve implementar a convivência dos clientes Lead Sync, melhorar o diagnóstico GSC e fechar as verificações afetadas com **MCP 0.22.0 e Google 0.9.0**. Não foi identificada mudança obrigatória de compatibilidade do Core para consumir os dois acompanhantes já entregues. A integração opcional ao plugin LinkedIn exige código novo no Core; o SDK LI-04 foi recebido na 0.1.0 e já pode ser usado no desenvolvimento.

Manter o cliente Lead Sync Core como opção suportada e padrão das integrações atuais. Cada integração comercial seleciona **Cliente do Core** ou **Cliente do plugin LinkedIn**. Um único leitor comercial atende cada conjunto remoto de conta, tipo e formulários; Core conserva agenda, callback, recebimento durável, contatos, deduplicação, CRM e avisos. Nenhuma credencial é copiada entre plugins.

As sete frentes anteriores, preservadas, são: P01 diagnóstico GSC; P02 contratos e trio; P03 retomada GSC; P04 instalação/cache/navegador; P05 documentação; P06 convivência Lead Sync; P07 homologação das fronteiras. A revisão 4 acrescenta as oito frentes P08–P15 da seção 9-A e prioriza os incidentes da base instalada. P06 permanece incluído e avança contra o produtor concreto enquanto o mantenedor trata as correções de assinaturas.

### Premissas

- **1.34.0 continua sendo a versão planejada**; a revisão documental não cria uma 1.35.0.
- O plano integrado atualizado adota WordPress novo ou o trio anexado. Os percursos principais passam a **instalação limpa e 1.33.0 → 1.34.0**. O caminho 1.31→1.33 já provado fica no histórico; não instalar a 1.32.0 intermediária.
- O documento da frota de 16/10 informa a 1.33.0 nos 12 sites, inclusive CTO Office/Korvena. A leitura própria desta rodada confirma as versões no Site-Teste, sem validar os outros 11 sites. Conferir versão/hash efetivos antes de qualquer troca; não acrescentar suporte histórico preventivo.
- Não bloquear instalação, ativação ou bootstrap por versão, presença ou ordem de acompanhantes. Capacidade ausente afeta somente a operação dependente.
- Preservar dados, filas, segredos cifrados, concessões, pausas, valores vazios e procedência. Não desinstalar para atualizar. Não reintroduzir reparos de versões anteriores nem suporte de downgrade como condição de entrega.
- A transformação única da configuração LinkedIn **da base 1.33 para o novo modelo** é evolução necessária do estado atual, não reparo histórico. Deve ser idempotente, auditada e recuperável pelo ciclo existente.
- Tema/implantador e os outros plugins mantêm seus donos. Este plano não modifica seus fontes, apps, tokens ou destinos. Não testar em korvena.net.br.

### Decisões pendentes

Não há nova decisão de produto necessária do dono. Convivência, escolha explícita, cliente Core preservado e retirada de Sheets social estão decididos. **Entrypoint, schemas de entrada, fixtures e binário LI-04 foram recebidos**; não manter essa dependência como ausente.

Restam o consumidor Core, as correções R3-LI-01/02 no produtor LinkedIn, a estratégia verificável de drenagem/reconciliação e os recursos autorizados para homologação externa. O binário corrigido MCP também continua pendente. São insumos técnicos/operacionais, não novas preferências de produto.

A leitura/polling pelo SDK pode ser implementada contra a 0.1.0. Gestão externa de assinaturas e troca que dependam dela exigem as correções e provas pertinentes antes de liberação. Não declarar P06/I02 integralmente concluído com apenas polling. Funções independentes e instalação Core permanecem disponíveis, com os impedimentos específicos visíveis.

## 2. Evidências, achados e consequências

### 2.1 Homologação recebida do Site-Teste

Ambiente informado: WordPress 7.1.3, PHP 8.3.30, Yoast 28.7 e WP Super Cache 3.1.4. Execução em 15/10/2026, aproximadamente 20h50–21h05, America/Sao_Paulo. Os três relatórios são **evidência recebida**; não foram reexecutados nesta revisão.

| Tema | Resultado recebido | Limite / ação |
|---|---|---|
| Instalação Core | 1.31→1.33, 12 etapas, zero falhas, confirmação posterior; home/REST 200; pacote de mesmo hash da entrega | Atualizar a base observada. Não repetir como instalação feita neste planejamento. |
| Preservação | 62 opções anteriores com valores existentes e procedência preservados; complementos previstos; nenhuma integração ativada | Não prova igualdade interna de segredos mascarados, contatos, arquivos e filas. Preservação ampla continua na bancada do candidato. |
| Arquivos | 356/455/147 esperados e instalados em Core/MCP/Google, sem diferença de caminhos/tamanho | Não houve segundo download para rehash completo independente. Distinguir essa prova do hash validado pelo executor e da checagem de bytes em bancada. |
| Medição Core | Seis slots; catálogo de 22 eventos, páginas 7/7/7/1; revisões e recusas coerentes | As nove verificações pontuais recebidas não equivalem à validação integral JSON Schema. Emissão no navegador não ensaiada. |
| Publicação/Yoast | Página publicada/alterada, noindex/nofollow e exclusão do llms; removida ao final com 404 | GETs usaram bypass comprovado. Cache servindo o conteúdo atualizado ainda precisa ser demonstrado. |
| Google → Core | Prévia com GA4 vazio devolveu `f3_google_core_measurement_missing`, sem gravação | Prova negativa; descoberta positiva de stream e gravação não testadas nesse site. |
| GSC | Consumidor Core registrado, `not_granted`; Google sem chave e vínculos | Configuração pendente; não é defeito do Core nem motivo para conceder acesso automaticamente. |
| MCP transporte | Redação incorreta de indicadores e inconsistência do envelope de conflito | Dono MCP; correção e comparação callback→MCP exigidas em P07. |
| Proteção HTTP | URLs documentais/privadas sondadas responderam 404 | A recusa é favorável para os endereços testados; não prova proteção de toda a árvore. Não exigir literalmente 403 quando 404 também recusa exposição. |
| Comercial/navegador | Não exercitados | Não houve formulário, contato, Slack/e-mail, Pipedrive, CAPI ou Lead Sync real. Não declarar esses aceites concluídos. |

Na homologação de 15/10 descrita nesta seção, nenhum defeito funcional próprio do Core foi confirmado nos casos executados. Essa conclusão é limitada àquela amostra e foi complementada pelos incidentes da frota de 16/10 incorporados em P08–P15. Isso não certifica todos os fluxos: a ausência de exercício do navegador e das integrações comerciais limita a conclusão.

### 2.2 Conferência própria e separação das provas

Na revisão 1, foram conferidos hashes e arquivos comuns dos instaladores/fontes e realizadas **21 verificações estáticas** do contrato Core/Google, sem falhas. Elas continuam identificadas como evidência daquela revisão; não foram recontadas.

Na revisão 2, foram examinados os 11 novos anexos nos trechos pertinentes e os pontos de código envolvidos. Um script local executou `SafeOutput::error()` e `Result::normalize()` do MCP entregue com dados sintéticos, confirmando seis observações: contagem/booleanos/diagnóstico público redigidos, token sintético oculto, conflito Core normalizado como erro comum e nulo preservado. **É reprodução de defeito, não teste de correção**, sem WordPress, HTTP ou consultas a sites.

Achados do Core que sustentam P06: `F3Base_Linkedin_Cliente::estado()` fixa interno selecionado; `F3Base_Linkedin` usa configuração, estado e trava globais; a callback abre o segredo Core diretamente; o pipeline de anúncios busca uma configuração por origem. Portanto, acrescentar um campo de escolha isolado não atende seleção por integração. É necessário propagar o contexto da integração pelo fluxo inteiro.

### 2.3 Tickets recebidos

| Ticket / fronteira | Estado e tratamento |
|---|---|
| CORE-01/02, I01 | Produtor Core e consumidor Google entregues; retirar “aguarda Google 0.8.6” dos documentos vigentes. Preservar contrato e regressão do candidato; vínculo positivo no Site-Teste segue pendente. |
| CORE-03 / GOOGLE-03/06 | Recuperação de leads Ads condicionada ao SDK e à homologação; métricas Ads no catálogo não entregam esse leitor. |
| CORE-04 | Adaptador do implantador preservado. Contrato/transferência definitiva pertencem ao implantador, fora deste trabalho. |
| CORE-05 / A22/A27 | Documentação, isolamento e provas públicas afetadas incluídos em P02/P04/P05/P07. |
| CORE-SOC-01 / I02 / S05 | **Incluído em P06**, com adaptação por integração, escolha reversível e manutenção dos dois clientes. LI-04 0.1.0 recebido; implementar o consumidor e fechar os casos de assinatura/transição desta revisão. |
| CORE-SOC-02 / I03 / L07/L14 | **Incluído em P07 como homologação externa**, com recursos de teste autorizados e prova separada por cliente. |
| MCP-SOC-01 / S01/S04/S06 | Infraestrutura existente. Ensaiar a fronteira Core com produtor social real quando entregue; não refazer registro genérico no Core. |
| GOOGLE-SOC-01 / S07 | Arquivados fora do escopo atual, inclusive preparativos. |

### 2.4 Entrega Meta/LinkedIn 0.1.0 recebida na revisão 3

Os quatro anexos novos contêm instaladores, fontes e relatório. O produtor **LI-04 existe**: `Fator3\LinkedIn\PublicApi`, hook `f3_linkedin_register_consumers`, fábrica `lead_reader()` e `LeadReader` com métodos de domínio. Há schemas de entrada executáveis, documentação PHP e fixtures. A pendência de fornecer um entrypoint/binário foi resolvida. I02 continua pendente: o consumidor Core ainda será implementado.

| Evidência | Resultado | Limite |
|---|---|---|
| Conferência própria dos ZIPs | Hashes iguais aos publicados; todos os 20 arquivos Meta e 21 LinkedIn iguais às árvores correspondentes dos fontes | Não é rehash dos arquivos do site instalado. |
| Manifestos | 19 entradas Meta e 20 LinkedIn válidas; só o próprio manifesto fica fora de sua lista | Prova dos bytes recebidos, não execução de comportamento. |
| QA recebido | 30 casos `ok` no WordPress real, persistência real e HTTP do fornecedor simulado | Não reexecutados nesta rodada; não são 30 testes próprios do Core. |
| Instalação/isolamento recebidos | Sociais instalados/ativos no Site-Teste; home/REST 200; bootstrap isolado por requisição | Sem teste de contas reais, navegador interativo ou alternância comercial Core. |
| SDK e concessão | Identidade de consumidor, grant por consumidor/conexão, conta/formulários, revisões e callback única | Exige adaptar o modelo por integração; registrar código não concede acesso. |
| Reprodução própria de assinatura | Quatro observações locais confirmam dois defeitos, com `LeadReader.php` real e colaboradores simulados | Não executa WordPress, banco ou HTTP; exigir regressão nativa do produtor e depois I02. |

Os dois achados próprios são **R3-LI-01**, segunda criação permitida com nova chave depois de resultado incerto, e **R3-LI-02**, mutação depois de revogação ocorrida na pré-consulta. A suíte recebida testa timeout com **a mesma chave** e revogação durante **leitura de formulário**; esses casos aprovados não cobrem os cenários novos. Não há evidência de duplicação ou envio indevido em conta real.

O relatório social declara tokens/ativos reais ausentes, validação visual pendente e matriz WP/PHP executada somente nas versões do Site-Teste. Manter os limites declarados; não inferir acesso Lead Sync a partir de Ads, do token configurado ou de 30 fixtures aprovadas.


## 3. P01 — Diagnóstico compreensível do Search Console

### Problema concreto

Em `includes/class-f3base-gsc.php`, `resumo()` já distingue `resolved`, `not_granted`, `ambiguous` e `unreadable`. A tela `render()` mostra propriedade, “SDK: registrado” e um aviso genérico apenas quando `configuracao.ready` é falso. Esse `ready` verifica configuração/estrutura/recuperação local; não significa concessão resolvida nem consulta remota bem-sucedida. A tela não apresenta a resolução contida em `servico`.

Assim, configuração local pronta com grant ausente ou ambíguo não recebe uma orientação específica no painel. É uma lacuna observada no código; não se afirma que houve incidente novo em produção.

### Comportamento a implementar

Na área Search Console da Medição, apresentar um resumo curto, usando os dados já disponíveis. Detalhes técnicos ficam recolhidos, com nomes legíveis e códigos copiáveis. Evitar novos menus, abas ou um segundo painel geral de integrações.

| Informação | Apresentação e ação esperadas |
|---|---|
| Provedor e contrato | “SDK disponível” ou motivo de indisponibilidade/incompatibilidade. Versão observada apenas informativa. |
| Configuração local | Propriedade, coleta ligada/desligada e pendência específica de validação, estrutura ou recuperação. Link para a seção existente de configuração. |
| Autorização local | Sem concessão: orientar autorização no MCP Google. Ambígua: orientar escolha de conexão/concessão explícita. Ilegível: informar impossibilidade de leitura, sem reclassificar como ausente. |
| Conexão efetiva | Identificador retornado pelo SDK somente quando a resolução for `resolved`. Não escolher a conexão padrão em lugar da concedida. Não expor credenciais. |
| Última tentativa | Data/hora no fuso do site, código traduzido e resultado. Diferenciar tentativa de coleta publicada. |
| Próxima tentativa | Exibir o horário quando houver recuo/quota; não sugerir repetição imediata nem alterar a agenda ao abrir a tela. |
| Última coleta e cobertura | Indicar se foi publicada, parcial/limitada, sem linhas, interrompida ou ainda não realizada. Manter o histórico existente acessível. |
| Escopo da prova | “Autorização local resolvida” não vira “acesso Google confirmado”. Prova remota vem do recibo da consulta correspondente; publicação exige confirmação da persistência local. |

Reutilizar a mesma interpretação na seção de configuração GSC e no resumo pertinente da Operação, por componente/projeção comum. Evitar três versões do significado do mesmo estado. `f3base/gsc-status` deve continuar com os estados estruturados existentes; texto de interface não deve substituir códigos de máquina.

A leitura do diagnóstico não deve executar consulta Google, alterar grant, escolher conta, disparar coleta ou reparar estrutura. A ação já existente de coleta continua explícita e sujeita a permissão, orçamento e recuo. Não criar botão que ignore quota. Uma integração indisponível não pode bloquear leitura do acervo já armazenado nem os outros módulos do site.

Horários operacionais usam data completa e fuso do site. A **data das métricas GSC continua no calendário America/Los_Angeles**, identificada como dia da origem; não converter esse dia em um instante local enganoso. Desconhecido deve aparecer como “Não informado” ou “Ainda não verificado”, nunca zero ou verde.

### Aceites P01

- Configuração pronta e grant ausente/ambíguo/ilegível geram mensagens diferentes, com a próxima ação e sem fatal.
- Conexão não padrão concedida aparece corretamente; ausência de resolução não mostra um identificador antigo como efetivo.
- Quota futura mostra quando retomar; abrir/recarregar o diagnóstico não consome uma consulta Google.
- Coleta parcial/limitada não aparece publicada/completa; acervo anterior continua disponível.
- Conteúdo escapa valores externos, funciona por teclado e em largura estreita; estado não depende apenas de cor. O relatório de validação inclui os estados ensaiados e o navegador usado.

## 4. P02 — Preservar os contratos e homologar o trio final

### Contratos a manter

| Dono | Contrato/referência | Regra desta versão |
|---|---|---|
| Core | Base: configuração 7.1.0; perfil 3.5 | P06 propõe configuração 8.0.0 para o modelo LinkedIn por integração, com schema/catálogo/revisão explícitos. Perfil só muda se houver alteração efetiva de permissões; texto/UI não muda contrato. |
| Core | `site-measurement-context/1.0.0`, `schema_revision: "1"` | Seis slots, contexto configurado/efetivo, procedência, escopo, revisões, catálogo paginado e estados explícitos. Sem tokens, dados de pessoas ou chamadas remotas. |
| Google | `search-console-reader/1.0.0` | Consumidor editorial por página/dia, concessão explícita, orçamento e contexto. Não se transforma em `google/query`. |
| MCP | `server-integration/1.0.0` e política pública vigente | Autorização de transporte e da ability continuam distintas. A presença do plugin não concede acesso. |
| MCP | `executor-registration/1.0.0` | Registro e admissão são do MCP; o Google declara apenas seus próprios alvos. Não adicionar bridge Core sem necessidade concreta. |
| MCP | `package-distribution/1.0.0` | Seleção, guarda e recibo pertencem ao produtor. Core não lê seu armazenamento privado nem interfere em filtros de distribuição. |

Os schemas compartilhados são fechados. Não adicionar um campo ou alterar seu significado sob o mesmo contrato supondo que o consumidor irá ignorá-lo: o Google rejeita campos/tipos não declarados. Uma expansão futura precisa de revisão/contrato negociado e consumidor correspondente. Nenhuma expansão do SDK de medição é necessária para P01 ou P06. A mudança administrativa 8.0.0 de P06 é um contrato distinto, não um campo extra no snapshot consumido pelo Google.

### Regressão conjunta mínima

1. Ler `capabilities`, `snapshot` e todas as páginas de `events` no Core candidato, pelo PHP público e pelas abilities autenticadas. Validar com o consumidor Google 0.9.0 real.
2. Comparar IDs configurados e efetivos, os seis slots, Meta navegador versus servidor, vazio explícito, desativado, ausente, ilegível e efeito de filtro. `runtime_verified` permanece falso para uma leitura de configuração.
3. Demonstrar revisão estável sem alteração; mudança por opção/filtro observável; revisão conflitante durante paginação/discovery/antes da gravação Google impede conclusão indevida. Não prometer transação atômica entre plugins.
4. Exercitar binding GA4 com zero, um e vários streams elegíveis; ausência/erro não apaga binding existente. GTM não é usado para inventar o ID GA4. Operações de configuração Google ficam no seu próprio pacote.
5. Catálogo completo sem repetição, orçamento e progresso respeitados, parâmetros validados, zero criação automática de tags/dimensões/conversões. Manter a ordem publicada pelo produtor e descobrir a contagem por revisão/paginação; os 22 eventos da base não viram limite fixo no consumidor.
6. Ler contexto/catálogo sem escrita de configuração ou HTTP externo pelo SDK; confirmar que a autorização do transporte não substitui as permissões Core. Negativas de bridge Google para alvos Core continuam no pacote Google/MCP.

**I01 atualizado:** a pendência de binário foi resolvida pela entrega Google 0.9.0. Os cenários conjuntos locais recebidos são evidência válida da 1.33.0; o relatório 1.34.0 deverá apontar a execução própria correspondente no novo candidato. Não retroeditar o relatório histórico da 1.33.0 nem reapresentar a implementação Google como trabalho novo do Core.

## 5. P03 — Completar a confiabilidade do consumidor GSC

Reutilizar a matriz recebida, priorizando os riscos que ainda exigem evidência própria no candidato:

| Cenário | Resultado exigido |
|---|---|
| Cron com usuário WordPress zero | Grant do consumidor e conexão explícita autorizam a coleta; não depender de login humano nem de conexão padrão. |
| Grant ausente, ambíguo e ilegível | Códigos distintos, sem fallback a outra conexão; diagnóstico consistente com P01. |
| Revogação antes da continuação | A próxima página é recusada; não publicar um dia incompleto nem aproveitar autorização antiga. |
| Troca de configuração/conexão/credencial entre páginas | O cursor anterior não é usado como se pertencesse ao novo contexto. Reinício/recusa explícitos segundo o SDK; métricas não misturam universos. |
| Alteração da configuração Core durante consulta | Validar novamente o contexto local antes de aceitar a resposta, preservando a guarda já existente. |
| Quota e `next_eligible_at` futuro | Não disparar antes do prazo; conservar o recuo e mostrar a data. |
| Página remota válida, persistência local falha | Não avançar cursor ou publicar resultado como sucesso; manter o último acervo confirmado e permitir retomada segura. Injetar falha SQL no ponto de gravação. |
| Resposta/cursor inválido, erro remoto ou orçamento encerrado | Motivo e possibilidade de retentativa explícitos. Não transformar erro em zero métricas ou em dia concluído. |
| Coleta desligada | Não reativar por atualização; remover os agendamentos próprios previstos sem afetar outros plugins. |
| Isolamento de origem | Consulta do SDK pelo Core não cria `ultima_cli`/`ultima_http` Google. A passagem da tarefa Core mantém sua própria origem e histórico. |

Usar WordPress, banco e plugins reais, com respostas Google controladas para quota, erro e paginação. A evidência deve marcar a fronteira simulada. O aceite é a política de consumo e persistência do Core; disponibilidade ou permissão de uma conta Google real é uma etapa operacional distinta.

Se um teste encontrar defeito, corrigir o ramo específico do Core e reproduzir a falha antes/depois. Não reimplementar controle de concessões, coletas completas, calendário ou credenciais do Google no Core.

## 6. P04 — Fechar A22 e reforçar a prova dos arquivos instalados

### 6.1 Efeito público de conteúdo, SEO e cache

A homologação recebida já demonstra publicação e noindex com Yoast 28.7, mas sondou o HTML com bypass. Aproveitar essa evidência sem declarar cache aprovado. Montar bancada do candidato com pacotes reais de Yoast e WP Super Cache, identificados por versão e hash. Tema de teste suficiente para renderização, sem transferir responsabilidades do implantador ao Core. Não executar em korvena.net.br.

- Aquecer o cache e registrar resposta pública anterior com HIT demonstrável. Fazer escrita autorizada pelo MCP; conferir HTML atualizado e Markdown/índice pertinentes. A leitura decisiva deve ser anônima e sem query/cookie/cabeçalho de bypass; registrar caminho, status, cabeçalhos e marcador de conteúdo para distinguir atualização e cache antigo.
- Aplicar noindex pelo fluxo público de SEO efetivamente exposto pelo MCP/Yoast. Conferir o efeito público e a exclusão do conteúdo dos recursos de descoberta/Markdown conforme a política Core vigente. Reverter a opção e conferir a atualização correspondente.
- Provar invalidação e resposta atualizada com cache real, inclusive arquivos `.php` do WP Super Cache; não usar apenas uma fixture de `.html`.
- Preservar a verificação HTTP de exposição do diretório de cache e suas distinções de estado; HIT em disco não substitui prova HTTP.
- Preservar as exclusões de 404, editor autenticado e modo de teste; a atualização de conteúdo não pode reaproveitar contexto de audiência indevido do cache.
- Yoast/cache ausente ou incompatível deve produzir diagnóstico delimitado, sem impedir funções independentes. Falha pertencente ao MCP, Yoast, tema ou infraestrutura é encaminhada ao dono, com reprodução; não é corrigida com acesso privado compensatório no Core.

A22 só será marcado concluído para o cenário real executado. Sem os pacotes reais, declarar a lacuna explicitamente; não substituir por metadado pré-gravado e anunciar equivalência. Não se propõe homologação de toda CDN, multisite ou cache persistente.

### 6.2 Instalação e atualização

Ensaiar instalação nova e atualização direta **1.33.0 → 1.34.0**, a base adotada nos anexos e confirmada no Site-Teste. A atualização anterior 1.31→1.33 é evidência histórica, não um caminho principal a repetir. Cobrir instalador nativo WordPress e fluxo MCP 0.22.0 de upload/substituição/ativação, com primeira leitura em requisição nova. Ativação concluída e prontidão do domínio Core são estados diferentes; a segunda depende do ciclo e das etapas do alvo atual.

Usar o ciclo de atualização já entregue: alvo próprio, reserva/renovação, retomada, falha explícita, idempotência e confirmação posterior. Checkpoint concluído na versão anterior não pode aprovar a nova. Nenhum conversor intermediário 1.32 é necessário. A conversão LinkedIn da base 1.33 prevista em P06 entra como etapa única do alvo, com retomada e prova de preservação.

Antes/depois, comparar fixtures representativas de contatos/sessões/atribuição, anexos/concessões, recibos e filas de entrega, segredos cifrados e procedência das opções. Repetição não reenvia avisos ou contatos. Preservar integração desligada, listas vazias e agenda pausada. Primeiro acesso público mantém coleta/recursos disponíveis conforme a estrutura suportada; falha estrutural tem diagnóstico explícito.

O pacote Google relata conflitos intermitentes de pós-imagem em ensaios preliminares e aprovação em diretórios temporários independentes. **A causa não foi identificada.** Adotar como critério de liberação:

1. Bancada isolada por execução, com banco, diretórios e processos identificados.
2. Verificar o inventário completo e SHA-256 de cada arquivo instalado contra o ZIP final, inclusive depois de encerrar os processos da bancada. Detectar extras antigos, ausentes e modificados.
3. Registrar prévia de recuperação/rollback quando o executor a fornecer, sem aplicar retorno nem alegar que arquivos restauram banco ou efeitos externos.
4. Se houver divergência, preservar inventários, staging/previous, journal e condições do filesystem. Não forçar rollback, não relaxar a guarda e não introduzir limpeza histórica no Core para esconder a causa.
5. Promover exatamente os bytes ensaiados. Alteração posterior invalida as verificações afetadas.

### 6.3 Acompanhantes e ausência de travas

A base desta rodada já contém MCP 0.22.0 e Google 0.9.0. A ordem Google-primeiro que evitou o intervalo 0.8.4 é histórico da homologação recebida, não requisito de compatibilidade da 1.34. Instalação limpa e funções locais Core não podem depender da presença dos acompanhantes. Exercitar indisponibilidade/retorno por capacidade, sem fatal ou reparo automático em outro plugin.

O binário LinkedIn 0.1.0 recebido já está identificado. As correções futuras LinkedIn/MCP serão identificadas por contrato/hash no ensaio. Não impor uma versão nominal como trava global para acomodar essas dependências opcionais.

## 7. P05 — Documentação instalada e receitas para os agentes

Atualizar a documentação vigente do Core, catálogo documental e ajuda contextual. Preservar os relatórios históricos com sua data e seus limites, apontando a situação atual em documento próprio.

Conteúdo obrigatório:

- Matriz efetiva Core candidato + MCP 0.22.0 + Google 0.9.0; números observados separados de compatibilidade por contrato/capacidade.
- I01 e bridges/distribuição já entregues; remover “aguarda Google 0.8.6” dos procedimentos correntes. A limitação MCP 0.21.1 permanece apenas no histórico.
- Instalação limpa/direta, ciclo do alvo, leitura de estado, indisponibilidade transitória e recuperação pelo dono correto. Não prometer instalação remota comprovada apenas por upload aceito.
- Diagnóstico GSC da seção 3, campos de máquina e textos humanos; diferença entre configuração, grant, acesso remoto, persistência e cobertura.
- Receitas de leitura: contexto/catálogo Core → descoberta/vínculo Google explícitos → relatório solicitado → conferência de período, cobertura e qualidade. Leitura não autoriza criar tags, propriedades, conversões ou exportações.
- Receitas para cruzar campanhas/anúncios/leads locais com relatórios Google, mantendo IDs de campanha/anúncio/UTMs, domínio/propriedade, fuso, período e universo. Agregados Google não permitem vincular uma linha GSC ou métrica GA4 a uma pessoa específica do Core por dedução.
- Core: audiência/contato/sessão/atribuição e recorte editorial GSC armazenado. Google: consultas remotas GA4/GSC/Ads, coleta completa/calendário e exportação autorizada. Meta/LinkedIn: ativos e métricas próprios. Registrar desconhecido/parcial e não somar visitantes/sessões entre universos ou períodos como se fossem aditivos.
- Concluir paginação GSC não garante todas as linhas da origem; dia sem linhas não prova ausência de visitas. Leituras de IA e referências vindas de IA continuam distintas de citação/recomendação, não demonstráveis pelo servidor.
- Dois clientes LinkedIn, modelo por integração, configuração administrativa 8.0.0 proposta, grants, escolha/troca/retomada e callback. Diferenciar SDK LI-04, integração I02 e homologação externa I03. Google 0.9.0 não entrega o SDK de recuperação de leads Google Ads. Sheets social permanece fora, inclusive preparativos.
- Exemplos sem segredos ou dados pessoais; permissões e vias autenticadas de leitura documental; schemas/fixtures completos, paginação e hashes preservados.

Arquivos principais a revisar: `README.md`, `docs/README.md`, `docs/VALIDACAO.md`, `docs/OPERACAO-E-RECUPERACAO.md`, guia vigente dos agentes, ajuda de opções, documentação GSC e de SDK. Criar nota de impacto da 1.34.0. Não importar automaticamente o modelo de empacotamento documental Google: preservar o acesso instalado/autenticado e as proteções Core existentes.

## 8. P06 — Dois clientes Lead Sync, escolha por integração

**CORE-SOC-01 / I02 / S05 / A23–A24–A26 incluídos.** Implementar o contrato de consumidor detalhado em [especificacao-consumidor-linkedin-core-1.34.0.md](especificacao-consumidor-linkedin-core-1.34.0.md). Ele é parte normativa do plano; os itens abaixo resumem seus efeitos.

### Modelo e atualização

Criar integrações LinkedIn identificadas e isoladas, com cliente, conexão, conta, formulários, mapeamento e estado próprios. A configuração administrativa passa do formato global da 1.33 para `integracoes`, com contrato Core **8.0.0 proposto**; publicar schema, catálogo e exemplos. Isso não muda o SDK de medição 1.0.0 usado pelo Google nem o perfil de permissões por conveniência.

Converter uma única vez a configuração atual em integração `principal`, cliente Core. Preservar valores vazios, ativação, credenciais por referência, procedência, marcos, cursores, recibos, assinaturas e filas. Não reimportar histórico ou reenviar entregas. A revisão estrutural muda de forma explícita e auditável, sem atribuir origem de fábrica a uma escolha do dono. Instalação nova não ativa Lead Sync.

Propagar o contexto de integração por cron, callbacks, diagnóstico e ingestão. O pipeline atual não pode continuar escolhendo uma configuração global por origem. Não duplicar o tratamento comercial: consentimentos, contatos, atribuição, CRM e avisos permanecem Core.

### Interface e seleção

Usar a área existente **Conexões e entregas → Origens de anúncios → LinkedIn**. Listar integrações e mostrar, em cada uma, cliente escolhido, disponibilidade, autorização conhecida, última leitura, próximo processamento e motivo de pausa. Explicar em linguagem simples a diferença entre usar as credenciais Core e usar uma conexão do plugin LinkedIn.

Trocar por operação explícita com prévia, revisão esperada e idempotência. O seletor não pode salvar a opção e deixar o trabalho antigo rodando. A escrita genérica deve passar pelo mesmo serviço ou indicar a operação correta. Campos não alterados de outro fluxo não impedem salvar uma mudança independente.

### Dois adaptadores, um executor comercial

Preservar o cliente Core e acrescentar adaptador ao SDK público **`linkedin-lead-reader/1.0.0`**, sem acesso a classes privadas ou cópia de token. A escolha é independente por integração, mas recursos remotos sobrepostos não podem ter dois leitores comerciais ativos no mesmo site. A confirmação de propriedade não é prova de exclusividade distribuída em toda a frota.

Ausência/incompatibilidade/revogação do cliente escolhido pausa somente seu fluxo, sem fallback. Cron usa concessão de consumidor com usuário WordPress zero. Uma permissão de relatório não autoriza ler respostas pessoais, criar assinatura ou enviar mensagens.

### Troca reversível e recebimento

Reservar os recursos, pausar novos lotes, cercar workers pela geração/revisão, drenar trabalho e reconciliar callbacks/assinaturas antes de promover a seleção. Guardar journal retomável. Resultado remoto incerto permanece pendente; não repetir criação/remoção cegamente. Depois do commit, voltar ao Core é outra troca explícita, não rollback de contatos ou pacote.

Preservar a identidade da submissão e deduplicação ao mudar de cliente. Marco confirmado não regride; cursor opaco só pode ser reaproveitado com equivalência provada. Caso contrário, retomar por marco com sobreposição controlada e deduplicação. Falha de banco não avança cursor nem confirma recibo. A callback mantém validação dos bytes originais pelo dono correto do segredo.

Documentar a drenagem de notificações antigas antes de liberar a troca. Um contexto anterior conhecido pode continuar verificando recebimentos durante a transição delimitada, sem segundo polling ou fallback comercial. Não prometer recuperar exclusões tardias apenas pelo polling. Sem estratégia verificável, a troca é recusada com motivo.

### Contrato recebido e dependências restantes

Consumir `Fator3\LinkedIn\PublicApi`, registrar no hook `f3_linkedin_register_consumers` e usar `lead_reader($consumer_id)` sob concessão. O contrato é `linkedin-lead-reader/1.0.0`; métodos retornam envelope `success`, com revisões e dados próprios. A especificação revisão 3 fixa a tradução de entradas/saídas, consumidor por integração, limites de 31 dias/50 respostas e recuperação de cursores.

Conservar o contexto/URL das assinaturas atuais na conversão 1.33→1.34. A revisão da opção muda com o novo modelo; recalcular o hash antigo sem registrar sua vinculação faria as callbacks existentes perderem o destino. Capturar e associar esse contexto antes da transformação, sem criar assinatura no upgrade.

R3-LI-01/02 impedem liberar gestão externa de assinaturas como aprovada. Implementar/testar o consumidor real, encaminhar os defeitos e repetir os casos com o produtor corrigido. Alternância comum conserva as conexões/revisões antigas enquanto forem necessárias à drenagem. Rotacionar a mesma conexão invalida grant/cursor e não conta como passagem automática de contexto. Não prometer transição sem perda até demonstrar o protocolo de recebimento e reconciliação.

## 9. P07 — Homologação conjunta e correções de transporte

### 9.1 Separar os níveis de prova

| Nível | Prova necessária | O que não prova |
|---|---|---|
| Domínio Core | Fixtures de integração, deduplicação, estado, concorrência, falhas SQL e troca | Contrato real do produtor ou acesso aprovado no LinkedIn. |
| I02 / S05 | Core candidato + binário LinkedIn real, SDK público, ambos os clientes e alternância; registrar respostas remotas simuladas | Entrega de lead real e aprovação de conta/app. |
| I03 / CORE-SOC-02 | App/conta/formulários e destino autorizados; ambos os clientes, challenge, notificação, polling, recibo, deduplicação e entrega reais | Exclusividade global em sites não observados ou disponibilidade futura do fornecedor. |
| Transporte MCP | Callback/ability e HTTP MCP do mesmo cenário com tipos, códigos e permissões comparados | Uma resposta correta do callback não valida serialização do transporte. |

I03 exige recursos previamente autorizados e identifica os contatos de teste e cada efeito externo. Não transformar o planejamento em envio de mensagens ou ativação de integrações. Na implementação, a execução externa deve respeitar a autorização concreta dos recursos usados. Sem ambiente, manter I03 pendente com motivo; não escrever “homologado” com base em mocks.

### 9.2 Defeitos MCP confirmados e encaminhamento

O relatório Site-Teste e a reprodução local identificam dois problemas do MCP 0.22.0:

- `SafeOutput::error()` redige campos públicos pelo nome: `passed`, `checks_passed`, `all_checks_passed` e o diagnóstico `credential`. Corrigir no **MCP**, preservando os tipos/indicadores públicos e ocultando as folhas secretas. Não desligar a proteção geral ou renomear contratos Core/Google para contorná-la.
- `Result::normalize()` preserva `code:revision_conflict`, mas acrescenta `error_code:operation_failed` e `conflict:false`. Corrigir no **MCP** a classificação comum; manter o código de domínio e `data:null`. O conflito deve ser identificável de forma consistente sem inferir pelo texto humano.

Acrescentar casos positivos e negativos: preflight sem credenciais mantém `passed:0`, booleanos falsos e `credential.configured:false`; token/senha/chave sintéticos seguem ocultos; revisão vencida mantém conflito; erro real de banco não vira concorrência; nulos e arrays vazios conservam o tipo. Comparar resposta nativa e transporte tanto no sucesso quanto na falha.

O binário corrigido MCP não foi recebido. Identificar seu hash/contrato quando chegar e repetir apenas os testes afetados. A falta dessa correção não bloqueia instalação Core nem justifica ler armazenamento privado; impede declarar a fronteira correspondente aprovada. O encaminhamento separado traz localização e reprodução para o mantenedor.

### 9.3 Matriz social compartilhada sob responsabilidade Core

| Caso | Execução e aceite Core |
|---|---|
| S01 — isolamento | Core sozinho; pares com cada acompanhante pertinente; ativação em ordens invertidas e desativação. Captura local/cliente Core continuam, e só o cliente externo selecionado fica indisponível. Usar binários reais nas fronteiras declaradas como integradas. |
| S04 — permissões | Grant analítico/GSC não permite respostas pessoais LinkedIn, mutação de assinatura, jobs ou exportação. Chamada MCP não substitui grant de consumidor local. Executor aninhado continua recusado quando houver bridge; não acrescentar bridge Core para o SDK. |
| S05 — alternância | Matriz P06/N15–N21 e I02; registrar ambos os sentidos, concorrência, sobreposição, replay e falha antes/depois do commit. |
| S06 — pausas | Pausar Lead Sync não pausa GSC, Meta ou capturas do site; Google/MCP ausentes não bloqueiam o fluxo Core local concedido. Retirar LinkedIn só pausa as integrações que o escolheram. A aprovação remota pendente de um canal não bloqueia outro. |

S02/S03 são principalmente provas dos produtores; o Core testa as consequências de revogação, parcialidade e erro em sua própria fronteira. Paginar diagnósticos e dados administrativos com orçamento de bytes abaixo do limite MCP de 2 MiB, considerando o envelope; não devolver histórico pessoal completo para contornar paginação nem inventar streaming no transporte. O SDK local não depende do MCP para operar.

### 9.4 Novos casos do produtor LinkedIn

**R3-LI-01 — incerteza além da chave:** provocar timeout depois do POST, repetir a mesma chave (um POST total) e depois outra chave equivalente com listagem remota ainda vazia. O comportamento atual faz segundo POST. O aceite exige bloqueá-lo enquanto existir intenção incerta sobre o recurso, preservar o diário e prover reconciliação explícita. Sem assumir que GET vazio prova que o primeiro POST não ocorreu.

**R3-LI-02 — concessão antes da mutação:** revogar ou alterar o grant durante a busca de assinaturas, antes do POST. O comportamento atual executa o POST e devolve conflito ao final. O aceite exige revalidar imediatamente antes do efeito e não despachar o POST/DELETE quando a mudança já for conhecida. Se o efeito estava em voo, registrar incerteza/efeito conhecido; não tratá-lo como erro sem efeito para retentar automaticamente.

As duas reproduções da revisão 3 executam o método real com colaboradores simulados. Exigir primeiro correção e regressão WordPress do produtor, depois Core candidato + binário corrigido. Não modificar os outros plugins neste projeto. A prova recebida de timeout com a mesma chave e de revogação em leitura continua válida dentro de seu escopo.

**Transição e rotação:** demonstrar mudança de cliente sem mudar as revisões usadas na drenagem; callbacks/assinaturas conservam dono e contexto. Se a mesma conexão for rotacionada, o SDK rejeita a antiga: pausar a operação e exigir reconciliação pública. Não copiar segredos, adotar assinatura por URL igual ou criar uma nova para contornar resultado incerto. A ausência de método público de reconciliação completa deve ficar como limitação concreta, com proposta ao mantenedor.

## 9-A. Pedidos da frota incorporados na revisão 4

Fonte: `Fator3 Site Core.md`, atualização de 16/10/2026, sem número de revisão declarado. Este plano conserva os IDs da frota; não cria o item 219 nem altera a lista central. A instalação da 1.33 nos 12 sites é informação recebida da frota. Nesta rodada, somente o inventário do Site-Teste foi consultado por MCP, em leitura, confirmando Core 1.33.0, MCP 0.22.0, Google 0.9.0 e sociais 0.1.0 ativos. Não houve instalação, mudança de configuração ou envio/exclusão de mensagem.

### P08 — Pedidos core 194(b)/(e): equivalência Slack e documentação da exclusão

**Evidência própria estática:** `class-f3base-slack-manutencao.php:89–98` já retira `emoji` de `plain_text` sem símbolos/aliases, mas só retira `verbatim` quando falso. Portanto, a ausência de tratamento de `emoji` não é total; `verbatim:true` ainda pode explicar divergência. Isso não reproduz a comparação de uma mensagem real.

Normalizar recursivamente, nos dois lados, os campos `emoji` dos objetos `plain_text` e `verbatim` dos objetos `mrkdwn`, conforme o pedido. Preservar texto, conteúdo dos emojis, tipo de bloco, links, menções, estilos relevantes e ordem das listas. Não modificar a mensagem remota para fazê-la coincidir. Manter controles que detectam alteração real de texto, link, bloco e ordenação.

Alinhar `docs/SLACK-1.32.md` e o guia vigente com a regra já implementada: a exclusão explícita da principal de teste pode prosseguir quando a consulta de thread falha, retornando `thread_nao_verificada`; isso não apaga respostas em cascata nem comprova limpeza integral. Quando houver respostas humanas, de produção ou remanescentes efetivamente observadas, preservar a principal conforme a guarda vigente. Uma resposta só recebe `apagada` após `chat.delete` aceito e ausência relida pela thread. Estado antigo contradito permanece visível; não converter registros em excluídos por atualização de versão.

**Aceite:** N35/N36. Exercitar raiz/resposta, paginação, flags presentes/ausentes/true/false, `&amp;`, texto com emoji e controles de divergência real. A prova externa usa somente mensagens de teste autorizadas no Site-Teste; verificar e limpar os recursos criados na execução. A exclusão real continua pendente enquanto não exercitada.

### P09 — Pedidos core 209(b): cobertura da qualidade compatível com o orçamento

**Evidência própria estática:** `trait-f3base-qualidade-remota.php:63–73` mantém consulta diária para estado terminal sem condição de encerramento. `class-f3base-pipedrive-api.php:35` atribui 20 unidades a cada GET. As reservas separadas já entregues permanecem.

Com o custo da base, 600 unidades permitem no máximo 30 GETs/dia. Para 17 registros com um GET cada, uma rodada completa custa 340 e a cobertura média não pode ser melhor que 13,6 horas por registro se o teto for integralmente usado por essas leituras. O cálculo de 8.160 unidades/dia é a demanda teórica da cadência de uma hora; a cadência de seis horas ainda demandaria 1.360. Fallbacks, erros e leituras adicionais ampliam o atraso. Esses números derivam do custo local do plugin; não são promessa de quota contratada no fornecedor.

Implementar seleção justa por última leitura confirmada, levando em conta saldo do consumidor, custo estimado, leituras auxiliares e prazo de execução. Conservar as reservas de entregas e a pausa remota comum. Não elevar automaticamente os limites já escolhidos pelo dono. Mostrar elegíveis, nunca lidos, vencidos, leitura mais antiga, próximo lote e estimativa de cobertura/atraso com suas premissas; não apresentar a cadência nominal como cobertura garantida.

Para apagado ou arquivado **com estado confirmado no contexto correto**, encerrar o polling recorrente após três observações consecutivas sem mudança, espaçadas por pelo menos 24 horas (política proposta da 1.34). Falha HTTP, autorização recusada, quota, timeout ou 404 isolado sem interpretação de domínio não contam como confirmação. Preservar último estado e horário; não apagar o registro nem inferir ganho/perda a partir da ausência. Reabrir somente por evento autenticado pertinente, mudança observada ou consulta explícita autorizada. Como arquivamento é reversível, a ajuda deve informar que, sem webhook operacional, mudanças após encerramento dependem de nova consulta explícita. Não encerrar automaticamente ganhos/perdas apenas por compartilhar o ramo `terminal`.

**Aceite:** N37/N38. Bancada com 17 ou mais registros, ativos/arquivados/apagados, erros e consultas auxiliares, relógio controlado por vários dias e concorrência. Demonstrar ausência de inanição, não consumo da reserva de entregas e retomada após evento. Aceite Pipedrive externo em `ctooffice.com.br` e `korvena.com.br`, conforme decisão recebida, com modo de teste e homologação temporária restaurada ao final. Em Korvena, confirmar primeiro a existência atual de formulário; não presumir que a ausência registrada em 06/10 ainda persiste. Não usar `korvena.net.br`. Observação real de 24 horas deve ter evidência própria, distinta do relógio acelerado.

### P10 — Pedidos core 212(a): explicar e corrigir a recusa por memória

**Evidência própria estática:** `class-f3base-editorial-relatorios.php:33–40` já lê `ini_get('memory_limit')`, converte por `wp_convert_hr_to_bytes`, subtrai `memory_get_usage(true)` e reserva 20 MiB; para `-1`, adota orçamento local de 384 MiB. A resposta não expõe limite lido/conversão/uso. A disponibilidade zero não prova, sozinha, erro na conversão nem que a margem é a causa única.

Instrumentar a decisão com valor bruto e bytes do limite efetivo da requisição, memória usada, reserva, orçamento operacional, estimativa, fonte, linhas e processamento. Valores inválidos/indisponíveis ficam explicitamente desconhecidos; não viram zero ou ilimitado. Distinguir limite PHP de orçamento local mesmo quando PHP está sem limite. Não substituir o valor efetivo por uma constante WordPress maior nem elevar limites globais para forçar aprovação.

Reproduzir no mesmo tipo de requisição MCP/REST o cenário de 24 linhas/120.000 bytes e identificar se o problema é conversão, consumo prévio, reserva ou planejamento excessivo. Ajustar a causa comprovada e o tamanho de lote, quando aplicável, com contabilização do conjunto já retido. Manter proteção contra esgotamento e resultados exatos: não trocar sessões distintas ou agregações por soma de lotes incorreta. Se a memória for de fato insuficiente, a recusa deve informar o cálculo completo e a ação cabível; não garantir 28 dias por omissão da guarda.

**Aceite:** N39/N40. Visões `aquisicao` e `resumo`, 28 dias no cenário de baixo volume, dias isolados, zero linhas, limite real restrito, `-1`, valores válidos em diferentes unidades e falha de leitura. Validar no alvo que originou o relato quando houver acesso autorizado; prova local não encerra o aceite do CTO Office. Esta alteração pertence ao relatório local do Core e não exige ampliar o SDK de medição ou o coletor Google.

### P11 — Pedidos core 213(b): conversão no aceite do contato

Corrigir `descricao` e `impacto` de `f3base_linkedin_conversion_id` em `trait-f3base-options-catalogo.php`, `docs/AJUDA-OPCOES.md`, ajuda e exemplos vigentes: o disparo ocorre no aceite do contato do formulário, inclusive regime `conteudo`, observadas as condições de configuração/consentimento do código. Não garantir otimização de campanhas por apenas preencher o ID.

Preservar classificação por `li_fat_id`/UTM paga já entregue. Não acrescentar conversão ao clique, não disparar novamente para leads nativos como consequência dessa correção textual e não alterar o contrato do SDK por mudar a descrição.

**Aceite:** N41. `config-core-ler`, ajuda e catálogo concordam com o fluxo do JavaScript; clique/validação recusada não gera o evento de aceite, e uma captura aceita gera o evento esperado uma vez, nas condições de emissão ensaiadas. Recebimento pelo LinkedIn é prova externa distinta.

### P12 — Pedidos core 215: identidade do catálogo Pipedrive

**Evidência própria estática:** `class-f3base-qualidade-catalogo.php:16` exige a revisão inteira de `f3base_pipedrive`. Além disso, `F3Base_Integracoes::pipedrive_verificado()` também usa essa revisão. Corrigir somente a primeira condição não basta quando a segunda continua inválida.

Separar a prova de identidade da conta/credencial da revisão operacional do lote. Vincular o catálogo ao domínio/conta e à revisão da credencial, mantendo a identidade de instalação existente quando relevante. Alterações de orçamento, homologação ou complemento de schema não invalidam um snapshot completo cuja identidade permaneça comprovadamente a mesma. Mudança de conta/domínio/token, revogação ou identidade ilegível continuam invalidando o vínculo.

Preservar as guardas de configuração integral durante um lote, antes de aceitar resposta/persistência e antes de efeitos comerciais; não relaxar globalmente `revisoes_atuais()` para resolver a validade do catálogo. Conferir o comportamento dos fluxos que preservam ou refazem a prova de conta ao gravar opções. Conversão da base reaproveita o catálogo somente quando há evidência suficiente de identidade equivalente. Snapshot já inválido e sem prova de identidade deve permanecer pendente, com recuperação explícita; não fabricar prova retroativa.

Selecionar a solução de vínculo estável. Não acrescentar recarga remota ao abrir `qualidade-ler` ou `como-usar`. Recarga necessária usa operação ou job autorizado, orçamento e troca atômica já existentes, preservando o último snapshot até o novo ficar completo.

**Aceite:** N42/N43. Gravar orçamento/homologação, atualizar 1.33→1.34 e acrescentar defaults sem perder catálogo válido. Trocar conta/token invalida; falha SQL/paginação não publica catálogo parcial; alteração em voo conserva guarda. Declarar dependências externas da prova real.

### P13 — Pedidos core 216: alertas operacionais para o administrador

Aplicar a decisão de 16/10: alertas de saúde, fila, captação, orçamento, falha/recuperação de integração vão por e-mail ao `admin_email` efetivo do WordPress. Avisos de contato conservam os destinos comerciais. Não criar seletor adicional: a regra já define o destino necessário.

Criar serviço interno comum para os alertas operacionais e inventariar seus chamadores. Incluir `F3Base_Captacao_Operacao`, `F3Base_Pipedrive_Orcamento`, `F3Base_Pipedrive_Alertas` e demais alertas dessa natureza encontrados na implementação. Não utilizar `email_leads`, destinatários do contato, Slack app/webhook ou webhook comercial como fallback. Mudança de destino do evento operacional `f3base.operacao.v1` deve ser anunciada no guia/impacto; não remover eventos comerciais independentes.

Preservar deduplicação, recuo, reserva, supressão de testes e distinção entre envio aceito, falha, resultado incerto e recebimento comprovado. `wp_mail` aceito não comprova chegada à caixa. Endereço administrativo inválido ou falha de envio gera estado operacional legível e recuperação limitada; não cria cascata de alertas nem envia ao canal de contatos. Na atualização, pendências operacionais ainda não enviadas adotam o destino novo, com registro da política; avisos comerciais e recibos já concluídos não são reescritos/reemitidos.

**Aceite:** N44/N45. Com avisos comerciais no Slack, induzir falha e recuperação Meta e orçamento/falha Pipedrive em bancada: destinatário `admin_email`, zero despacho aos transportes comerciais, repetição controlada e contrato de leitura claro. Em homologação autorizada, comprovar chegada do e-mail e ausência no canal; interceptação local do correio prova o roteamento, não o recebimento. `como-usar` distingue os destinos. Planejamento não envia mensagens.

### P14 — Pedidos core 217: encerrar GTM sem configuração

Tratar ID vazio como módulo sem tarefa: `coletar()` retorna sucesso com `nada_a_verificar`, sem HTTP; remover todos os agendamentos próprios pertinentes e invalidar evidência corrente do contêiner retirado. ID preenchido inválido continua sendo configuração inválida, sem se disfarçar de ausência.

O encerramento deve alcançar intenção durável, checkpoint de espera e despertador do executor; retirar apenas `f3base_gtm_verificar` não resolve a espera `esgotada`. Usar reconciliação autorizada ou ação explícita de encerramento, com revisão, motivo e registro de auditoria, sem `reativar_esgotada` nem execução do contêiner ausente. A leitura de `como-usar`/diagnóstico permanece sem reparos. Não apagar histórico operacional nem intenções de outros módulos.

Conferir novamente ausência/revisão sob a guarda: se o ID foi reposto ou há worker ativo, recusar/aguardar o conflito em vez de encerrar a nova tarefa. Worker iniciado com configuração antiga não publica evidência após a remoção. Ao configurar novamente, criar uma agenda e evidência nova; preservar a pausa explícita do operador quando aplicável.

**Aceite:** N46/N47. Reproduzir espera esgotada da base, remover ID, reconciliar sem reativação, consultar `como-usar`, passar duas janelas diárias no relógio controlado e repetir com concorrência/reinserção do ID. A observação de dois dias reais em CTO Office permanece separada até executada. O contorno já aplicado pela frota (`cron/unschedule`) deve ser reconhecido no upgrade, sem recriar o evento quando não há ID.

### P15 — Pedidos core 218: entrega e menu conforme padrão revisão 3

Na próxima entrega implementada, usar `base-site-core-fator3-1.34.0-instalador.zip`, `base-site-core-fator3-1.34.0-fonte.zip` e `base-site-core-fator3-1.34.0-relatorio.md`, além de cinco impactos individuais para os outros slugs. Fonte com raiz `base-site-core-fator3-1.34.0-fonte/`; instalador com raiz/basename publicados preservados. Relatório externo contém nomes, bytes e SHA-256 dos dois ZIPs; cópia interna do relatório é anterior ao fechamento do fonte para evitar circularidade. Nenhum ZIP da entrega contém outro ZIP.

Menu de recuperação passa de `F3 Base` para `Site Core`, coerente com o menu normal, preservando slug de menu, autorização e rotas. Conferir cabeçalho, título, documentação instalada completa/paginada, leitura MCP e recusa de conta/configuração a usuário sem autorização administrativa. Mínimos de runtime só são comprovados pela matriz executada.

**Aceite:** N48/N49 e checklist do padrão. Nesta rodada documental, disponibilizar os dois ZIPs originais 1.33 sem alteração e sem renomeação retroativa; relatório/impactos identificam base 1.33 e alvo apenas planejado 1.34. A estrutura antiga do fonte permanece registrada como legado; não reempacotar os mesmos bytes sob uma falsa certificação nova.

### Prioridade e coordenação desta revisão

Primeiro: P13 (destino dos alertas), P12 (catálogo), P14 (GTM) e P10 (memória), pois corrigem incidentes em operação. Depois P09 (qualidade/cobertura), P08 (Slack), P11/P15 (textos e entrega). P01–P07 permanecem completos no escopo; o desenvolvimento P06 pode avançar independentemente enquanto se aguardam os binários corrigidos do LinkedIn/MCP. Nenhuma dessas dependências impede corrigir os oito pedidos próprios do Core.

Os aceites Pipedrive usam os dois sites definidos na aba, com as autorizações e o modo de homologação existentes; os demais ensaios de pacote usam o Site-Teste e bancada descartável. Casos observados em CTO Office têm validação específica registrada para a frota. Não alterar sites durante este planejamento, não alterar pacote alheio nem remover pedidos da fonte central.

## 10. Fora do escopo Core e justificativa

| Item | Tratamento e motivo |
|---|---|
| Sheets social, inclusive GOOGLE-SOC-01/S07 | Retirado por decisão explícita: não implementar SDK, stubs, configuração, preparação ou testes dedicados. Sheets já existente no Google permanece. |
| Recuperação de leads Google Ads — CORE-03 / GOOGLE-03/06 | SDK e homologação ainda não entregues. Catálogo de métricas Ads não equivale a recuperação de leads. Retomar com contrato, binário e recursos autorizados. |
| Instagram Insights e LinkedIn Pages/Ads | Implementação dos novos plugins sociais. Core documenta o cruzamento permitido, sem copiar seus coletores/painéis. Instagram Insights não incorpora Meta Ads. |
| Meta Ads e operação comercial Meta | Meta Ads continua no MCP oficial; Meta Lead Ads, Pixel/CAPI e entregas permanecem Core. Não mover clientes/segredos como efeito da nova arquitetura social. |
| Correções de assinatura R3-LI-01/02 | Código LinkedIn. Core inclui testes de fronteira e guardas próprias; o mantenedor corrige o produtor. Gestão de webhook externo fica condicionada. |
| Correções de sanitização/conflito, CIMD B22 | Código do MCP. Incluir regressão da fronteira e encaminhar os defeitos; não alterar o outro pacote. CIMD novo não foi provado pela conexão de manutenção existente. |
| Compatibilidade transitória Google 0.8.4 | Histórico da atualização já executada no Site-Teste; não adicionar adaptador à nova base. Se outro ambiente ainda estiver nessa combinação, tratar seu percurso separadamente. |
| Causa dos antigos conflitos de pós-imagem | Não identificada. Manter inventário/hash como critério e encaminhar reprodução, sem limpeza especulativa ou relaxar a guarda do executor. |
| Armazém geral GA4/GSC, calendário, OAuth novo, BigQuery | Fora desta demanda. Reutilizar as capacidades existentes de cada dono, sem abrir nova frente por antecipação. |
| Tema/implantador e SDK definitivo | Responsabilidade expressamente excluída. Preservar o adaptador Core existente. |
| Redesenho geral do wp-admin, multisite, CDN/cache persistente | Não necessários para os pedidos recebidos. UX delimitada a GSC, Lead Sync e diagnósticos/correções dos pedidos P08–P15; cache na integração real ensaiada. |

P06/I02 e P07/I03 **não estão adiados por falta de intenção**: integram o plano, com dependências e aceites explícitos. Nenhuma delas deve ser escondida sob “todos os itens atendidos”. Mudança incompatível do contrato social recebido exige nova revisão documentada.

### Situação dos pedidos da base após a evidência de 16/10

| Pedido | Tratamento nesta revisão |
|---|---|
| 194 | (a)/(d) entregues segundo a frota; corrigir (b) e alinhar documentação de (e) em P08. Exclusão remota continua prova pendente. |
| 209 | (a)/(c)/(d) entregues; completar cadência/encerramento em P09. O destino dos alertas passa a obedecer 216/P13. |
| 210/211 | Retirados da lista pendente pela frota; preservar download e atribuição, com regressão se os respectivos caminhos forem alterados. |
| 212 | (b) entregue; investigar/completar (a) em P10, sem confundir orçamento local com cobertura Google. |
| 213 | (a) entregue; (b) ainda incorreto no catálogo da base, corrigir em P11. |
| 214 | Cliente Core/polling/webhook entregues; aceite externo é da frota. P06 acrescenta seleção por integração e cliente externo. |
| 215–218 | Novos problemas da base: P12–P15, com critérios e evidência próprios. |

## 11. Aceites da próxima entrega

| ID | Aceite verificável | Vínculo |
|---|---|---|
| N01 | Nova instalação e atualização direta 1.33→1.34, incluindo a transformação LinkedIn prevista em P06. Sem intermediária, trava por acompanhante ou reutilização do ciclo anterior. | P04; A01–A10 |
| N02 | Opções/valores vazios/procedência, dados e filas preservados; reexecução não duplica efeitos. | P04; A06/A09/A14 |
| N03 | Consumidor Google 0.9 real lê contexto e catálogo do candidato; schemas, slots, revisões, permissões e ausência de rede/escrita pelo SDK confirmados. | P02; A16–A19/I01 |
| N04 | Zero/um/vários streams e conflito de revisão mantêm comportamento explícito; erro não apaga binding. | P02; I01 |
| N05 | Estados GSC ausente/ambíguo/ilegível/resolvido, prontidão local e coleta aparecem separadamente e orientam a correção. | P01 |
| N06 | Diagnóstico não dispara consulta ou coleta; horários/fusos e próxima tentativa legíveis; navegação por teclado e largura estreita conferidas. | P01 |
| N07 | SDK real com usuário zero e conexão não padrão; quota/revogação/troca entre páginas sem mistura de universo ou avanço indevido. | P03; A11 |
| N08 | Falha SQL após resposta válida não publica/coleta nem avança cursor; retomada preserva o acervo confirmado. | P03; A11 |
| N09 | Consulta Core não marca cron Google; origem Core preservada, desligamento e isolamento sem efeitos no acompanhante. | P03; A12/A27 |
| N10 | Escrita autorizada reflete HTML, descoberta/Markdown e noindex com Yoast/cache reais. Aproveitar prova Yoast recebida; complementar no candidato com HIT/invalidação por HTTP anônimo sem bypass. | P04; A22 |
| N11 | 404, editor e teste preservam exclusões; emissão pertinente conferida com assets finais, sem confundir rede bloqueada com recebimento remoto. | P04; A20 |
| N12 | Caminhos nativo e MCP 0.22 observam ativação e prontidão separadas; leitura em requisição nova; inventário final coincide integralmente com ZIP após parar processos. | P04; A15 |
| N13 | Docs vigentes instaladas, catalogadas e legíveis por agente autorizado; schemas/fixtures completos, nenhum procedimento corrente depende do pacote não entregue 0.8.6. | P05; A13/A27 |
| N14 | Relatório separa provas próprias, recebidas, simuladas e externas pendentes; 21 verificações estáticas da revisão 1, seis observações MCP da revisão 2, quatro observações unitárias LinkedIn da revisão 3, 30 casos sociais recebidos e inspeções estáticas/inventário de leitura da revisão 4 conservam sua origem; não viram homologação do candidato. Hashes amarram testes e instalador. | Todos |
| N15 | Configuração 1.33 vira integração `principal`/Core uma única vez, conservando estado, credenciais por referência e procedência; falha não publica configuração vazia. Contrato administrativo 8.0.0 e revisão estrutural explícitos. | P06 |
| N16 | Duas integrações de recursos distintos operam com clientes diferentes, sem compartilhar cursor, lease, mapeamento ou callback indevidamente. Lista vazia autoriza zero recursos. | P06; CORE-SOC-01 |
| N17 | Sobreposição de conta/tipo/formulário é recusada mesmo com conexões locais diferentes; cliente indisponível não dispara fallback. Core sozinho continua operacional. | P06; A23/A26 |
| N18 | SDK LI-04 real, concessões distintas e cron usuário zero funcionam; ausente, incompatível, revogado e quota têm estados próprios, sem token exposto. | P06; I02/S05 |
| N19 | Prévia/troca Core→plugin→Core preserva marco e identidade, com revisão/idempotência. Concorrência e queda antes/depois do commit não criam dois executores ou duplicam contatos/intenção de entrega. | P06; A24 |
| N20 | Callback verifica corpo original pelo cliente/contexto correto; notificações repetidas/tardias, assinatura incerta e perda de credencial seguem política documentada, sem confirmação antes de persistir. | P06; LI-04 |
| N21 | CREATED/DELETED, submissão posterior, 404 transitório, paginação e falha SQL preservam tombstone/recibos/cursor. Troca não fabrica sessão, não reenvia histórico nem apaga CRM por inferência. | P06 |
| N22 | Seletor e lista de integrações mostram estado/ação no fuso do site, com teclado e largura estreita; cliente externo indisponível tem motivo; edição independente não valida campos intocados de outro fluxo. | P05/P06 |
| N23 | Ambos os clientes e a alternância são exercitados em recursos LinkedIn autorizados, com evidência de lead, callback/polling, deduplicação e entrega reais. Sem ambiente, registrar pendência externa, sem aprovação fictícia. | P07; I03/L07/L14 |
| N24 | Transporte do MCP preserva booleanos, contagens, diagnóstico público e nulos; token/senha/chave sintéticos continuam ocultos. Identificar binário corrigido e comparar com callback. | P07; dono MCP |
| N25 | Revisão conflitante conserva código de domínio/nulo e classificação comum de conflito; erro real não é reclassificado. Ensaio no callback e HTTP MCP. | P07; dono MCP |
| N26 | Docs instaladas publicam modelo por integração, permissões, seleção, troca, recuperação e limites de prova; SDK de medição continua aceito pelo Google real. Nenhuma dependência privada cruzada. | P02/P05/P06 |
| N27 | S01/S04/S06 executados na fronteira Core: isolamento, ordens, grants, bridge aninhada e pausas conforme §9.3. Sem código/stub/tela/ensaio novo para Sheets social; Sheets existente preservado. | P07; escopo social |
| N28 | Relatório final distingue I02 local e I03 remoto, prova própria e recebida, e lista impedimentos por dono. Produtor LI-04 recebido não prova consumidor; correções pendentes LinkedIn/MCP não viram aprovação nem trava global de instalação. | Todos |
| N29 | Registro por integração no hook real, descriptor idempotente, factory/erro/envelope tratados e dois grants na mesma conexão não substituem callbacks/seleções. Sem acesso privado ou usuário humano fabricado. | P06; SDK 0.1.0 |
| N30 | Limites reais de cinco metadados/50 respostas/31 dias, cursores e revisões preservados; orçamento total Core, `forms_remaining` e cobertura nula corretamente interpretados. Guest/test leads e IDs/ms sem perda. | P06 |
| N31 | Resultado incerto não permite novo POST equivalente com outra chave, inclusive após GET vazio. Diário/reconciliação preservados; prova nativa do produtor e regressão Core com binário corrigido. | P07; R3-LI-01 |
| N32 | Grant alterado durante pré-consulta impede mutação posterior; alteração com requisição em voo preserva efeito/incerteza e bloqueia retry cego. Cobrir POST e DELETE. | P07; R3-LI-02 |
| N33 | Callback 1.33 continua vinculada depois da transformação; ambas as direções de troca respeitam dono/ownership_key e contexto verificável. Rotação não reutiliza grant/cursor antigo, nem declara drenagem concluída por tempo arbitrário. | P06/P07 |
| N34 | Prévia confere, pelas interfaces públicas, conta/formulários, permissões, app/callback e revisões. Ausência em listagem limitada não vira prova de inexistência; sem prova suficiente, motivo e ação visíveis. | P06/P05 |

| N35 | Equivalência Slack ignora os dois metadados solicitados nos objetos corretos, nos dois lados; texto/link/tipo/ordem alterados continuam divergentes. | P08; 194(b) |
| N36 | Guia e resultado distinguem principal removida, cobertura de thread desconhecida e resposta removida com recibo+ausência; sem falsa limpeza ou alteração automática de registros antigos. | P08; 194(e) |
| N37 | Com 17+ registros e tetos 3000/600, qualidade respeita sua reserva, distribui leituras sem inanição e mostra atraso/cobertura coerentes; quota remota comum continua respeitada. | P09; 209(b) |
| N38 | Após três confirmações terminais sem mudança na cadência definida, polling de apagado/arquivado encerra; erro não conta, histórico permanece e evento/consulta autorizada reabre. | P09; 209(b) |
| N39 | Recusa editorial expõe limite bruto/efetivo, uso, reserva, estimativa, fonte e contagem; indisponível, ilimitado e zero não são confundidos. | P10; 212(a) |
| N40 | Aquisição/resumo 28 dias de baixo volume respondem quando o orçamento efetivo comporta; com insuficiência real, recusa completa e cálculo verificável. Sem elevar limite global ou perder exatidão de agregação. | P10; 212(a) |
| N41 | Descrição/impacto/ajuda e JavaScript concordam no aceite do contato; preservada atribuição LinkedIn e ausência de novo evento por clique. | P11; 213(b) |
| N42 | Catálogo conserva validade em gravação não identitária; mudança de conta/domínio/credencial invalida. Prova de conta e catálogo seguem identidade adequada sem relaxar guardas do lote. | P12; 215 |
| N43 | Atualização 1.33→1.34 preserva catálogo com identidade comprovada; prova insuficiente e falha SQL/paginação ficam pendentes, sem marcar completo indevidamente. | P12; 215 |
| N44 | Alertas operacionais Meta/Pipedrive e demais inventariados usam admin_email; nenhum Slack/webhook comercial/email_leads; avisos comerciais conservam destinos. | P13; 216 |
| N45 | Falha/resultado incerto de e-mail e destinatário inválido ficam legíveis sem fallback comercial; deduplicação/supressão/retomada preservadas; aceite de transporte separado de recebimento. | P13; 216 |
| N46 | ID GTM removido invalida evidência, retira agenda e faz coleta retornar nada_a_verificar sem HTTP; duas janelas diárias e upgrade não recriam evento. ID inválido não vira ausência. | P14; 217 |
| N47 | Espera GTM esgotada encerra por reconciliação/ação própria sem reativação, com revisão e auditoria; concorrência/reinserção do ID preservam tarefa válida e outros módulos. | P14; 217 |
| N48 | Instalador/fonte/relatório finais usam nomes e raízes exigidos; bytes/SHA-256 dos ZIPs no relatório; cópia interna anterior ao fechamento; cinco impactos; menu de recuperação Site Core. | P15; 218 |
| N49 | Normas r3 rastreáveis; documentação instalada completa/paginada e versão/hash coerentes; autorização administrativa e confinamento demonstrados no MCP; checklist publicado com pendências reais. | P05/P15; padrão comum |

Os aceites são obrigações de verificação do plano, não resultados desta revisão. N23 depende de recursos externos; N18–N21/N24–N25/N31–N33 também dependem das capacidades/correções pertinentes dos produtores. Cada pendência deve ficar visível na entrega. Manter o mesmo ID quando um caso for corrigido ou reexecutado, vinculando-o ao hash do candidato.

## 12. Sequência de implementação e entregáveis

1. Fixar normas revisão 3, hashes, oito pedidos e base 1.33; levantar os chamadores de alertas e a cadeia de provas Pipedrive. Preservar SDK LinkedIn recebido e encaminhar correções dos produtores.
2. Reproduzir e corrigir P13/P12/P14/P10, depois P09/P08/P11; manter regressões de configuração, dados, captura e destinos comerciais.
3. Executar P01–P03 e implementar P06 conforme a especificação revisão 3, com consumidor por integração, conversão da base e preservação de callbacks. Aguardar correções pertinentes para liberar mutações externas e alternância.
4. Ensaiar I02 com os binários reais; N24/N25 com MCP corrigido e N31/N32 com LinkedIn corrigido, identificados por hash. Falta do produtor deixa apenas o aceite dependente pendente.
5. Executar P04/cache/navegador, documentação e autorização. Testes Pipedrive reais seguem os ambientes autorizados no anexo; demais casos de pacote usam Site-Teste/bancada. Separar relógio controlado de observação real de 24/48 horas.
6. Fazer I03 somente com recursos externos autorizados. Registrar ausência de app/token/formulário/destino como pendência, sem equivaler mocks a fornecedor real.
7. Fechar documentação e instalador; instalação limpa e atualização direta da 1.33, inventário por hash e estado final. Atualização não ativa integrações nem reenvia histórico.
8. Entregar os três artefatos canônicos da 1.34.0 e cinco impactos individuais; relatório N01–N49 com evidências, pendências, nomes/bytes/hashes. Fonte contém a cópia anterior ao seu fechamento, sem hash circular. Publicação/implantação na frota continua decisão do dono.

**Entrega desta rodada:** plano revisão 4, relatório documental da base 1.33, cinco impactos, especificação LinkedIn r3 preservada e evidências de análise. Os ZIPs 1.33 são redisponibilizados inalterados sob seus nomes históricos. Não existe instalador 1.34 gerado nesta rodada. Acesso remoto limitado a descoberta/schema/inventário de plugins no Site-Teste, sem mutação.

## 13. Rastreabilidade dos insumos

| Artefato | SHA-256 conferido |
|---|---|
| Core 1.33.0 instalador | `de427cb219be769d9e44ae9aaf5e6f31055990b3d8f9b8664ac0faa596f61364` |
| Google 0.9.0 instalador | `333e3f177be1095ac9e568e66d4d8cab9b4dfbd4d6a86505e8b7a02583182b32` |
| Google 0.9.0 fonte | `a25b6202eabbc6d2d40de754d92f03c3a19ff5cae556315fa30497e7be6da814` |
| MCP 0.22.0 instalador | `622b75d20c3dc115bb8391d08f59c484ebbc6ac78547b8dac08b0f6b10e1fa7d` |
| MCP 0.22.0 fonte | `50ff0c8734a7c133561dc44d45256fa0923bc7735655a25b6792d469e69bfda8` |

A revisão 2 considerou os três relatórios HTML de homologação Core/MCP/Google, `analise-e-plano-integrado (1).md`, `plano-instagram-linkedin-lead-sync (1).md`, `contratos-integracao-social (1).md` e os cinco encaminhamentos anexos. O inventário de evidências registra os 11 nomes e hashes exatos, além dos insumos e verificações estáticas da revisão 1.

A revisão 3 acrescenta relatório social e três ZIPs. LinkedIn instalador: `6112381105bd60de42c61b47b7831aaefe94fbb88971eb79a4c7f6315a6c8999`; Meta instalador: `4ce0a3446a55f634bb109662c2aacd83759c7d0a9b467d6a8706b17b917fb378`; fontes conjuntos: `0521ccafafac94752a326ecded8c5c13c1cf967e66d8de49a985ec7ebac4333b`. Os quatro anexos, localizadores e reproduções estão no inventário da revisão 3, sem recontar testes anteriores.

Arquivos complementares: [especificação Lead Sync](especificacao-consumidor-linkedin-core-1.34.0.md), [encaminhamento MCP/Google](encaminhamento-core-1.34.0-mcp-google.md), [encaminhamento Meta/LinkedIn](pendencias-core-1.34.0-meta-linkedin.md), [evidências](evidencias-planejamento-core-1.34.0.zip) e [SHA-256](SHA256SUMS-planejamento-1.34.0.txt).

## 14. Normas, insumos e limites da revisão 4

- Lidos integralmente: `instrucoes-agentes-plugins-fator3.md`, revisão 3 de 16/10/2026, e `padrao-desenvolvimento-plugins-fator3.md`, revisão 3 da mesma data. Padrão completo prevalece. A regra comum foi incorporada nesses documentos; sua origem é declarada neles, sem alegar leitura de conteúdo remoto adicional.
- `Fator3 Site Core.md` lido integralmente; não possui revisão numérica. Referência vigente usada: acréscimos de 16/10 e hash registrado no inventário. Não foi alterado.
- Fonte-base e instalador 1.33 conferidos por SHA-256; inspeção estática dos métodos afetados. Não houve teste PHP/WordPress de correção nesta rodada.
- Inventário remoto `plugins/list`, request `6ff45233ca6ff542c786ffd8`: cinco pacotes Fator3 ativos, Yoast 28.7 e WP Super Cache 3.1.4. Inventário não comprova execução funcional, saúde integral ou igualdade de todos os arquivos remotos.
- Implantador: identidade `implantador-base/implantador-base.php`, versão 2.8.0, conferida no cabeçalho do pacote disponível e na aba própria; ausente no Site-Teste. O código de integração do Implantador não foi homologado nesta rodada.

Relatório e cinco impactos usam a versão emissora 1.33.0, cujos bytes estão disponíveis; 1.34.0 é o alvo planejado. Os encaminhamentos conjuntos antigos passam a índices para esses impactos individuais. Consultar o relatório documental para a matriz de destinatários e o checklist aplicado.
