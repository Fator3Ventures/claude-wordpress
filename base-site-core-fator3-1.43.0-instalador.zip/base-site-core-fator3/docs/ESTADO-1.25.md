# Inventário de estado — referência atual

O nome deste arquivo foi conservado para manter os links da documentação. O inventário vigente é [dados/estado-inventario.json](../dados/estado-inventario.json), distribuído com o plugin e disponível, sem valores, por `f3base/estado-inventario-ler`. O [dicionário SQL](DICIONARIO-DADOS.md) descreve as tabelas atuais. Não use um inventário de outra release para apagar estado.

## Backup e restauração

Preserve banco, opções e arquivos privados de negócio. Segredos e payloads são cifrados com material derivado dos salts do WordPress: a restauração precisa conservar esses salts. Não exporte conteúdo em texto aberto para compensar uma chave ausente.

Em recuperação coordenada, prepare Core → Google, drene o trabalho e reconcilie efeitos externos; retome Google → Core com a geração atual de cada componente. Não sobreponha sentinelas ativas com cópias antigas. Inclua o estado dos dois acompanhantes no backup conjunto. `f3-google-cache` pertence ao Google e não é alvo de limpeza pelo Core.

Histórico, contatos, filas comerciais, arquivos privados e concessões não são cache. Confira as ações de desinstalação no inventário vigente; desinstalação não substitui backup. O Core não remove dados por varredura de prefixo nem reivindica opções do implantador ou do tema.

## Instalação 1.32.0

A referência é uma instalação nova ou atualização da 1.31.0, sem bloqueio por versão dos acompanhantes. O marcador atual é `f3base_instalacao`. A estrutura e as complementações atuais preservam valores explícitos, listas vazias, procedência e registros válidos. Não há execução da antiga cadeia de consolidação/reparo de releases anteriores. Marcadores históricos não autorizam uma limpeza ampla.

Consulte também [RELEASE-1.32.0.md](RELEASE-1.32.0.md), [AGENTES-1.33.0.md](AGENTES-1.33.0.md) e [CONTRACTS.md](CONTRACTS.md).
