# Diagnóstico do WP-Cron — pedido 189

A linha `could_not_set` é emitida pelo **WordPress**, ao reagendar/remover um evento recorrente e receber falha na persistência da option `cron`. O código sozinho não prova perda de agenda nem disputa inofensiva. O Core não suprime o log e não promete eliminá-lo globalmente.

O Core observa `cron_reschedule_event_error` e `cron_unschedule_event_error`, guarda operação, hook, horário UTC, origem e releitura do estado. `estado_desejado_confirmado` significa que a agenda foi encontrada após a falha; não afirma concorrência comprovada. `agenda_nao_confirmada` mantém falha pendente. Sem os dados necessários ou com banco ilegível, `causa_indeterminada` permanece explícita.

`f3base/saude-ler`/fila operacional e `f3base/como-usar` expõem `cron_diagnostico`/`wordpress`; a fila inclui observações, contadores por hora e pendências. Dados ficam em `f3base_agenda`; argumentos de eventos pendentes são cifrados. Janela de contadores: 24 horas em baldes UTC, incluindo a hora limítrofe; até 100 observações detalhadas.

Releitura direta do banco evita usar como prova somente o cache de options. Retomada: até três pendências por passagem, trava por hook, até cinco tentativas, recuo até uma hora. Se a cadeia recorrente já avançou para horário equivalente posterior, não recriar uma execução antiga. Ganchos externos, MCP Google e WP Super Cache não são reparados pelo Core.

Aceite da frota: acompanhar sete dias e comparar a agenda efetiva com os avisos. O teste local cobre confirmação, ausência, causa desconhecida, retomada e isolamento; não comprova a frequência do erro em produção. A explicação acima atende a alternativa documental do pedido sem atribuir causalidade não medida.
