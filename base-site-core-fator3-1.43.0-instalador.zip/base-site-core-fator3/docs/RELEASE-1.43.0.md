# Fator3 Site Core 1.43.0

Base direta: 1.42.0. Contrato administrativo: 8.8.0. Escopo: pedidos 243–255, arquivo de pedidos recebido em 21/10/2026, e dependência MCP Google 0.16.0.

## Correções de execução

- O marcador textual da migração de e-mail mantém seu tipo. A cadência isola uma falha de leitura, informa a opção afetada e continua as demais verificações.
- Atividades do Pipedrive omitem `note` quando vazia. A reconciliação conserva pessoa, oportunidade e nota já confirmadas; reparar uma atividade não repete o núcleo da entrega.
- Campos da API v2 do Pipedrive preservam `field_name`. O catálogo em preparo ganha uma nova geração para não reaproveitar listas sem nomes.
- Google Ads: o executor do Core consulta `reconcileBound` para recibos incertos, sob a mesma trava. Exige contrato, extensão, referência de destino e recibo compatíveis; não chama novamente a ingestão. Uma negativa só é final com prova de não entrega. O Google 0.16.0 lê o ID GA4 do Core e renova suas verificações no próprio executor.
- Comparação editorial sem observações de audiência retidas devolve `totais: null`, código e motivo. A visão Search Console declara que não oferece comparação nesta rota.
- Relatórios integrados contam, com limite, linhas do período e da comparação antes de executar as consultas maiores. Acima de 8.000 linhas devolvem `reduza_periodo`; trata-se de limite conservador, não de promessa de duração em qualquer hospedagem.
- Redes oficiais: fontes vencidas ou ausentes têm prioridade; duas por execução, continuação por cron, tentativa falha com intervalo mínimo de uma hora. O relatório informa obtenção, validade e tentativa. Atualizar a lista não reclassifica fatos históricos.

## Configuração e conteúdo

- Um menu Site Core reúne Contatos, Formulários, Relatórios, Configurações e Operação. Cartões de busca incluem e-mail, credenciais e origens.
- Filas de avisos e Pipedrive em Operação: 20 registros por página, ações abertas por registro e diário nos detalhes técnicos. Configuração de Avisos não renderiza manutenção de mensagens.
- Destinatários de avisos, retenções e homologação do CRM/e-mail têm controles centrais. Os formulários mantêm substituições explícitas. Verificações de domínio ficam em SEO; redirects deixam Operação.
- E-mail automático: conta de envio, conteúdo e homologação; assunto, saudação, apresentação, recebimento, frases de origem e convite de resposta editáveis. Variáveis: `{nome}`, `{primeiro_nome}`, `{nome_exibicao}`, `{marca}`, `{origem}`. Texto de serviço usa o catálogo da conta. Número de WhatsApp vazio herda Contato. Link antigo é conservado para não trocar destinos já configurados silenciosamente.
- Prévia sintética e teste SMTP separado do envio. O envio de teste usa uma caixa autorizada, reserva um destinatário e não cria pessoa, lead, nota, atividade ou Bcc no CRM. A confirmação de autenticação não comprova entrega na caixa final.
- Segredos ficam na área responsável, com nome, estado e data. Credenciais complementares é um resumo de leitura. Campo vazio mantém o valor; apagar é explícito.
- Objetos antes exibidos como JSON usam controles de propriedades, linhas e seletores, com o mesmo transporte oculto e validação/revisão do servidor. Mapas existentes e valores ausentes do catálogo são conservados até edição explícita.
- Descoberta de páginas/formulários/campanhas Meta, formulários/campanhas Google via ability `ads/search`, formulários LinkedIn com cliente Core e canais Slack. Consultas paginadas são explícitas e não importam contatos. Selecionar não ativa a origem; é preciso salvar. Os catálogos dependem das permissões da conta.
- Qualidade: eventos Meta em lista; campos nomeados, funis, etapas e seletores de formulários/campanhas disponíveis localmente. Valores antigos não encontrados permanecem identificados para revisão.
- Textos do consentimento configuráveis e prévia; mensagens do formulário com rótulo e prévia; conjuntos de campos por caixas de seleção. Barra de salvamento e aviso de alterações pendentes. Blocos escolhidos aparecem primeiro e o intervalo é editado em minutos.

- Textos de confirmação e avisos: Configurações → Contato permite editar título, expiração, continuação, nome acessível do WhatsApp, títulos e link dos avisos e resumo da equipe, com prévia. Os resumos aceitam {quantidade}. Os textos são escapados na apresentação e não alteram destinos, permissões ou mensagens já enviadas.

## Compatibilidade e limites de aceite

Não copia credenciais entre plugins, não troca automaticamente o cliente LinkedIn, não transfere propriedade de entregas antigas, não reenvia conversões incertas e não altera listas vazias por padrão. Os aliases temporários `c0-ler`/`c0-homologar`, anunciados para um ciclo na 1.42, saem do registro; a migração dos dados legados permanece.

A descoberta completa de ativos no cliente externo Plugin LinkedIn não é afirmada: o contrato instalado no Core oferece leitura de formulários identificados, sem catálogo tipado de descoberta. Nesse cliente a tela informa a indisponibilidade; não muda para credenciais do Core. Nomes de campanhas usadas nas regras de qualidade dependem do catálogo local observado/configurado. Nem todo campo técnico do editor de formulários virou seletor (por exemplo, destino de material protegido e referência da conexão). O JSON editável foi retirado da configuração comum; a leitura técnica permanece pelos serviços/documentação.

A prova de entrega real ao CRM, SMTP, Meta, Slack e Google e o tempo de resposta na hospedagem devem ser conferidos no Site-Teste. Evidências locais não substituem esse aceite. Consulte o relatório externo para o que foi efetivamente executado.
