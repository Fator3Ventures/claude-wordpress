# Formulários — complemento 1.29

A primeira etapa persiste um contato. A segunda acrescenta dados ao mesmo registro com identidade/revisão próprias. O CTA guarda destino real e mensagem do link WhatsApp; o texto visível do botão não substitui a mensagem. Um CTA que aponta para outro telefone válido preserva esse destino no percurso.

Opções por formulário: `etapa2_apresentacao` (`inline` ou `dialogo`), `mostrar_pular` e mensagens `concluir`, `pular`, `complemento`, `complemento_pulado`, `complemento_nao_confirmado`. O diálogo nativo move o formulário existente, não duplica DOM/IDs, fecha com Escape e devolve o formulário à posição original. Adaptador do tema tem precedência.

Resposta HTML, JSON inválido e erro 5xx não são mostrados crus ao visitante. 413 informa limite de envio. Falha só no complemento informa que o contato inicial está salvo e permite continuar no WhatsApp confirmado, conservando possibilidade de tentar de novo. Abertura de nova aba continua configurável; o navegador pode bloquear popups.

Arquivo: `max_bytes` ausente ou zero não impõe teto do plugin; extensões vazias não restringem pelo pacote. Limites reais de PHP/proxy permanecem. `limites_exibicao`: automático (tamanho/quantidade em linguagem comum), oculto ou personalizado (`limites_texto`). Ocultar explicação não muda validação. Diagnóstico técnico permanece no admin.

A auditoria de formulários inclui campos por etapa, mensagens, apresentação e gatilhos observados. Os templates e adaptadores do tema não são alterados por esta release. O envio original e os complementos continuam consultáveis mesmo quando não há autorização de medição.
