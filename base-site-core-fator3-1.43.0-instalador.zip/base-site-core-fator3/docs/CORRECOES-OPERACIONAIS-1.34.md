# Correções operacionais — 1.34.0

## Slack

A equivalência descarta block_id e somente os metadados textuais `verbatim` de mrkdwn e `emoji` de plain_text. Vale para presente/ausente/true/false em qualquer lado. Não apaga emoji do texto nem normaliza mudanças reais de link, conteúdo, tipo ou ordem. Escapes Slack conhecidos são normalizados conforme contrato anterior.

Principal removida, resposta removida e cobertura da thread são fatos distintos. Uma principal apagada sem leitura completa da thread deixa cobertura desconhecida. Exclusão de resposta exige autoria/recibo local e ausência posterior. Não reclassificar limpeza antiga por inferência; não tocar conversa humana não registrada.

## Pipedrive e qualidade

Identidade estável: domínio, conta remota comprovada, instalação e revisão física da credencial. Migração só adota catálogo previamente completo e prova correspondente à configuração da base. Alteração não identitária (orçamento, homologação ou defaults) conserva catálogo; credencial/conta/domínio divergentes invalidam. Guardas de revisão dos lotes continuam estritas contra mudança em voo.

A fila ordena pela confirmação mais antiga, depois última tentativa e chave. Custo mínimo estimado 20 por leitura, ou 60 quando há ponte; estimativa de cobertura mostra pendentes, nunca consultados, encerrados, leitura mais antiga, próxima tentativa e quota. Não é garantia de cobertura: erros/consultas auxiliares ampliam o atraso. Reserva de qualidade e reserva de entrega continuam separadas.

Três respostas bem-sucedidas com mesmo estado terminal e contexto, em cadência mínima de 24 horas entre confirmações, encerram polling de arquivado/apagado. Mudança reinicia contagem. Erro, 404 e estado won/lost não encerram. Webhook autenticado e consulta individual administrativa reabrem acompanhamento sem apagar histórico.

## Alertas

Inventário: captação/recuperação Meta, monitor de orçamento Pipedrive, falha por job e incidente de conta Pipedrive usam F3Base_Alertas_Operacionais. Destino admin_email, política admin_email/1. Email comercial e resposta ao visitante conservam destinos próprios. Nunca fallback para email_leads, Slack ou webhook comercial. Sem destinatário válido: sem_destinatarios. Falha: falhou; exceção de transporte: incerto. `recebimento: nao_comprovado` mesmo quando wp_mail aceita. Reservas/deduplicação/supressão de testes pertencem ao chamador e são preservadas.

## Editorial e GTM

O diagnóstico de memória informa memory_limit bruto, estado/bytes efetivos, uso, reserva de 20 MiB, disponibilidade e estimativa de 5.000 bytes por linha, fonte PHP e contagem exata. `-1` usa orçamento interno conservador de 384 MiB menos uso/reserva. Valor inválido é indisponível, não ilimitado. Zero é zero. Lotes adaptativos de 1–500 mantêm totais exatos; o teto de 100 mil linhas é distinto da estimativa de 120 mil bytes para 24 linhas. Recusa não fabrica relatório parcial.

Remoção do ID GTM encerra intenções não suspensas, inclusive esgotadas, retira agenda própria e registra revisão/ator/evidência anterior. Checkpoint de recuperação deixa de estar pendente. Despertador compartilhado só é removido sem outra tarefa pendente. Reserva ativa impede encerramento; reinserção concorrente agenda a configuração válida. ID vazio não consulta fornecedor. Pausa deliberada permanece preservada.
