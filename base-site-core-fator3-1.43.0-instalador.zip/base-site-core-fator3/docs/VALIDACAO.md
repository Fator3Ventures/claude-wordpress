> Atualização 1.37.0: consulte RELEASE-1.37.0.md e PIPEDRIVE-1.37.md; base direta 1.36.0, contrato administrativo 8.2.0. Evidências atuais no relatório externo; provas históricas abaixo mantêm seu escopo original.

# Validação — Core 1.36.0

Evidências desta rodada ficam no fonte e no relatório externo canônico: equivalência de dez consultas com 1.35.0; volume sintético 5.872/24/1.931; limite real 128 MiB; diagnósticos; WP-Cron e thread de seis partes com fornecedor simulado; schemas/revisões/permissões; consumidor Google atual; instalação limpa e atualização direta.
Resultados e pendências remotos são especificados no relatório externo. Prova local não é homologação do CTO, Slack ou demais fornecedores. Nenhuma credencial sintética/fixture de execução acompanha o instalador. Sem alteração visual nesta rodada.
