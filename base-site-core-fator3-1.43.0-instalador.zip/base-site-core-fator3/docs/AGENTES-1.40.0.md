# Instruções Core 1.40.0

Leia RELEASE-1.40.0.md e CONTRACTS.md. Contrato administrativo 8.5.0. Não executar reenvio de e-mail automático ao novo lead incerto. Não mover conversões entre transportes. Configuração exige administração e revisão. Segredos somente pelo campo cifrado. Testes reais exigem caixa/ativos controlados. Nenhuma ativação automática na atualização.
