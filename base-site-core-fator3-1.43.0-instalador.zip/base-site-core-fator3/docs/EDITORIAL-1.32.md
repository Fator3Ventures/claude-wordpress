# Relatórios editoriais — Core 1.32.0

Janelas de sete e 28 dias incluem páginas e artigos, humanos/IA e as fontes preservadas do relatório. Consultas de eventos, contatos e acessos são percorridas em lotes de 500; as fontes não são carregadas todas em duplicidade. Totais de sessões respeitam identidade, inclusive ao atravessar meia-noite.

A leitura prévia limita cada fonte a 100000 linhas elegíveis e estima memória com margem de 20 MiB. Falhas de SQL, tempo, quantidade ou memória retornam erro estruturado com fonte, linhas, limite, tempo e memória observada/estimada. Não devolver zeros como se não houvesse visitas. Se somente o período comparativo falhar, o período principal continua disponível e o comparativo mostra motivo e totais nulos.

A causa do erro observado em ctooffice não foi reproduzida em produção nesta entrega. A bancada cobre janelas com totais conhecidos, falhas injetadas e limites controlados; o diagnóstico instalado permite identificar a condição real sem adivinhá-la.
