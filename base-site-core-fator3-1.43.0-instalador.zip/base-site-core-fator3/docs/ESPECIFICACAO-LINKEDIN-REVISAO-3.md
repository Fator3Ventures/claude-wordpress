# Core 1.34.0 — especificação do consumidor Lead Sync

15/10/2026, America/Sao_Paulo · Plano revisão 3 · **Contrato de implementação proposto, ainda não implementado.** Complementa CORE-SOC-01/02 e o contrato social revisão 3, agora contra o SDK público LinkedIn 0.1.0 recebido. O consumidor Core continua por implementar.

## 1. Resultado esperado e fronteira

Manter os clientes **Core** e **plugin LinkedIn**. O administrador escolhe um por integração comercial; integrações de recursos remotos distintos podem escolher clientes diferentes. Core mantém polling comercial, URL da callback, recibos, tombstones, contatos, consentimentos, atribuição, CRM e avisos. O cliente escolhido mantém suas próprias credenciais e executa as chamadas/validação criptográfica.

Não há fallback automático, cópia de credenciais, transferência do cliente Core ou segundo pipeline comercial. Sem LinkedIn instalado, o modo Core continua operacional. Se o cliente LinkedIn selecionado ficar indisponível, somente seu fluxo pausa, conservando a seleção e o progresso. MCP/Google/Meta não são necessários à execução local desse fluxo.

## 2. Modelo por integração

O código 1.33.0 tem configuração/estado globais e pressupõe um conjunto LinkedIn por site. O novo modelo deve expressar a seleção por integração e acompanhar esse contexto em toda leitura, captura, cursor, assinatura e mutação.

### Configuração administrativa

Evoluir `f3base_anuncios_linkedin` para um objeto canônico com `integracoes`, mapa por identificador estável. Publicar o **contrato de configuração Core 8.0.0**, schema, catálogo e exemplos. A forma 7.1.0 pertence à base; não manter duas representações graváveis ou reinterpretar uma escrita antiga silenciosamente. O SDK público de medição permanece 1.0.0, schema revision `"1"`.

| Campo lógico de cada integração | Regra |
|---|---|
| ID e rótulo | ID estável usado em rotas, estados e operações; rótulo apenas humano. Renomear não muda identidade comercial. |
| `ativo` | Preservar a preferência existente; instalação nova desativada. Disponibilidade do cliente não ativa integração. |
| `cliente` | Enum fechado `core` / `linkedin_plugin`. Mudança efetiva passa pela operação de troca; escrita genérica não contorna suas guardas. |
| Referência de conexão | No modo plugin, ID opaco do SDK. No modo Core, referência ao cofre Core, começando pela credencial atual. Nunca nome arbitrário de option, token ou URL. |
| Conta e tipo | Conta remota canônica e `SPONSORED` nesta entrega. Outros tipos exigem escopo próprio. |
| Formulários | Seleção explícita de IDs canônicos; vazio autoriza zero. Conservar versões recebidas e mapear aliases/URNs sem perda de identidade. |
| Propriedade confirmada | Preservar confirmação do responsável; não é prova de exclusividade em toda a frota. |
| Mapeamento e preferências | Campos, campanhas e webhook do fluxo atual, sem reset na alternância do cliente. |

**Credenciais Core:** a configuração atual permanece no cofre Core, referenciada como conexão inicial. Integrações podem referenciar a mesma credencial somente quando o acesso aos respectivos recursos estiver autorizado. Esta entrega não exige construir um gerenciador genérico novo de conexões Core. Se o usuário precisar de outro app/token Core simultâneo, isso terá escopo explícito; a conexão do plugin LinkedIn já usa o cadastro desse produtor. Não misturar credenciais de apps distintos para atender a alternância.

### Estado por integração

Separar: cliente selecionado, disponibilidade/capacidades, conexão efetiva, revisão da política/credencial, prova de acesso, marco inicial e confirmado, cursores por formulário/versão, recuo, leases, geração de execução, contexto de callback e journal de troca. Estado temporário de troca não substitui preferência persistida nem a apresenta como já aplicada.

Operações sobre uma integração devem nomeá-la. Em leituras agregadas, paginar e identificar cada fluxo; não escolher implicitamente o primeiro. Nas antigas abilities com alvo único, a falta do ID só pode ser resolvida sem ambiguidade quando houver exatamente uma integração; com várias, devolver erro indicando o parâmetro necessário. Documentar essa conveniência explícita no novo contrato, sem manter o armazenamento antigo.

Paginar respostas administrativas com orçamento de bytes compatível com o envelope MCP e seu limite de 2 MiB. Não retornar acervo pessoal completo, cursor secreto ou tokens no diagnóstico. O cron usa SDK local, independentemente do transporte MCP.

### Conversão única da base 1.33.0

Transformar a configuração existente em `integracoes.principal`, com `cliente:core`, durante o ciclo de atualização do alvo. Capturar antes da escrita o contexto/URL vigente 1.33 e associá-lo à integração, para manter callbacks de assinaturas existentes durante a reconciliação; o novo número de revisão não pode invalidá-lo silenciosamente. Conservar `ativo`, conta, formulários vazios, preferências, mapeamento, marcos, cursores, assinaturas e recibos. Referenciar as credenciais atuais sem copiá-las, recifrá-las por conveniência ou apagá-las.

Registrar a transformação estrutural à parte, com versão, origem/destino e revisão; preservar quem configurou, canal e data originais. Não atribuir origem `padrao` a valores escolhidos pelo usuário. O contrato e a revisão nova da estrutura devem ser explícitos: um cliente administrativo com revisão antiga recebe conflito e orientação de rediscovery.

Se leitura, gravação, associação de estado ou confirmação falhar, não publicar modelo vazio nem concluir a etapa. Retomar pelo journal/ciclo existente. A conversão é idempotente, não importa histórico, não muda cliente, não cria assinatura e não dispara avisos. Os estados atuais não vinculáveis a uma conta/formulário devem ser conservados para diagnóstico, sem atribuição inventada.

## 3. Adaptadores e SDK efetivamente recebido

Criar interface interna Core com operações de domínio; preservar seu cliente atual e implementar o adaptador do plugin usando somente o contrato público recebido.

### 3.1 Entrada pública recebida e adaptação Core

O instalador LinkedIn 0.1.0 publica `Fator3\LinkedIn\PublicApi`, sem necessidade de incluir arquivos privados. Registrar cada identidade Core no hook **`f3_linkedin_register_consumers`**, emitido em `plugins_loaded` prioridade 20. Instalar o listener durante o bootstrap Core, antes desse ponto; testar ambas as ordens de carregamento. O registro é idempotente para descritor idêntico.

| Chamada concreta | Tratamento Core |
|---|---|
| `PublicApi::capabilities()` | Retorno direto, sem envelope; verificar contrato/entrypoint, sem usar versão nominal como trava de instalação. |
| `PublicApi::register_consumer(['id'=>…, 'label'=>…, 'contract'=>'linkedin-lead-reader/1.0.0'])` | Envelope `success/code/provider/version/data`; campos fechados. Não passar callback ou permissões nesse descritor. |
| `PublicApi::lead_reader($consumer_id)` | Devolve objeto; consumidor desconhecido lança `Fault`. Capturar exceções na fronteira, sem fatal ou impersonação humana. Nunca passar string vazia no cron: ela seleciona acesso administrativo humano. |
| `LeadReader::descriptor()` | Retorno direto; `opaque_cursor_transferable:false`, `credential_secret_export:false`, tipos `SPONSORED`. |
| Métodos do leitor | Envelope `success/code/provider/version/data`; preservar `code`, `details`, `conflict`, `retryable`, nulo e avisos. Adaptar uma única vez ao resultado interno Core. Não confundir `success` do produtor com `ok` do Core ou sucesso do transporte. |

As entradas fechadas estão em `docs/input-schemas.json`, `Schemas::all()` e `linkedin/contracts`. Não passar `integracao_id`, ator, URL arbitrária, orçamento próprio ou nome de cliente para métodos que não declaram esses campos. O Core mantém esse contexto no adaptador. Validar o corpo de saída exigido por cada método antes de ingerir; a entrega possui schemas de entrada, não um conjunto completo de JSON Schemas fechados de saída equivalente ao SDK de medição Core.

### 3.2 Um consumidor por integração

**Decisão de implementação:** `consumer_id` estável por integração Core, por exemplo `f3base-li-` seguido dos primeiros 32 caracteres hexadecimais do SHA-256 do UUID persistente da integração, dentro dos 64 caracteres aceitos. Guardar o identificador; renomear o rótulo não cria outro consumidor. Não embutir token, conta pessoal ou endereço de e-mail nesse ID.

Motivo verificável: `PublicApi::grant()` armazena concessão pela chave **consumidor + conexão** e aceita uma única `callback_url`. Usar um consumidor global para duas integrações na mesma conexão faria uma concessão substituir a seleção/callback da outra. Consumidores distintos permitem configurações e revisões independentes. Manter a guarda Core de sobreposição remota: conceder dois consumidores não autoriza dois executores sobre o mesmo formulário.

Registrar também os consumidores de integrações pausadas e de contextos ainda em drenagem. O registro não executa consulta, cria assinatura, ativa fluxo ou concede permissões. Configuração ilegível é diagnosticada; não substituir por consumidor genérico ou integração vazia.

O administrador concede acesso no **plugin LinkedIn**, por painel ou `linkedin/save-grant`, com `expected_revision`, `enabled`, mapa de formulários por conta e permissões separadas `metadata`, `responses`, `verify`, `subscriptions`. A callback é HTTPS, do host do site e exatamente igual à URL persistida no Core. O Core exibe o ID e a URL copiáveis e o vínculo ao cadastro responsável; não pede token do outro plugin nem grava grant automaticamente.

Para a prévia administrativa, usar as projeções públicas `Api::dispatch('list-connections')` e `Api::dispatch('list-grants')` sob usuário autorizado quando forem necessárias para conferir app, permissões e callback. Não chamar `Connections`, `Store`, `Http` ou `PublicApi::grants()` não documentada como contrato de consumidor. Não simular administrador no cron. As listagens 0.1.0 limitam-se aos primeiros 100 registros sem continuação: ausência nessa resposta não prova inexistência; informar “não localizado na projeção disponível” e bloquear a prévia até obter prova, encaminhando eventual necessidade de consulta direta ao produtor.

Guardar apenas projeção não secreta/revisões necessárias à operação. No worker, `effective_status` e os métodos executados usam revisões fixadas, fazendo a autorização vigente prevalecer. `effective_status` não devolve permissões, callback nem app; não inventar esses campos nem converter presença de token em autorização integral. Uma projeção administrativa anterior só continua válida se as revisões coincidirem.

### 3.3 Limites efetivos e tradução de dados

| Método / regra 0.1.0 | Implementação/aceite Core |
|---|---|
| `effective_status` | Conexão/conta e revisões opcionais; devolve forms, revisões, token/secret configurados, expiração declarada e `remote_access_verified:false`. Pode gravar auditoria do produtor; não consulta o fornecedor nem repara configuração. |
| `check_access` | Confere conta e até cinco formulários. Se `forms_remaining>0`, completar metadados dos selecionados com paginação/consultas; não marcar todos verificados. Não importa respostas. |
| `list_forms`, `get_form` | Somente formulários concedidos. Cinco por página; cursor de metadados expira em uma hora. Descoberta administrativa de formulários é outra operação, não ampliar seleção automaticamente. |
| `read_responses` | `form_id`, `form_version`, `from_ms`, `to_ms`; até 50 respostas, janela máxima de 31 dias e cursor de um dia. Fixar conexão/conta/revisões e todos os parâmetros ao continuar. |
| Dados de resposta | `responses[]` ou `response` contêm `identity`, `form_version` e `raw`. Preservar o `raw` no acervo permitido e converter perguntas/consentimentos pelo catálogo, conferindo identidade e versão. Guest lead não exige submitter; `testLead` é explícito. |
| Challenge/notificação | `verify_challenge` recebe `challenge_code` e, quando fixado, `application_id`; devolve `challengeCode`, `challengeResponse` e revisão da credencial. `verify_notification` recebe `raw_body` e assinatura hexadecimal minúscula, sem recodificar JSON; devolve identidade validada e `receipt_persisted:false`. Fixar as revisões de entrada e não exigir campo de saída que aquele método não publica. |
| Tempo/continuação | Milissegundos como strings de 13 dígitos. Não enviar segundos, float ou janela maior. Dividir backlog permitido desde o marco confirmado em janelas fixas ≤31 dias, com fronteiras/replay deduplicados; não abrir importação histórica. |
| Cobertura | `complete` só indica esgotamento da consulta; `all_rows_guaranteed:null` não vira cobertura integral garantida. Falha, página vazia, completo e lacuna de origem ficam distintos. |
| Orçamento | O SDK redefine orçamento interno de 12 chamadas/25 s por método, até 8 s por HTTP e 700.000 bytes por corpo de domínio. Core também limita tempo/itens do lote inteiro e renova sua trava; chamar vários métodos não reinicia o orçamento total do worker. |
| Erros | `rate_limited` respeita `details.retry_after`; `resource_not_found` não equivale a DELETED; `operation_uncertain` pausa mutação. `revision_conflict` em uma mutação não comprova ausência de efeito remoto. |

Não reutilizar cursor de metadados em respostas ou cursor Core no plugin. Persistir janela, versão, parâmetro de teste, revisões e marco ao iniciar a leitura. Se cursor expirar, retomar a janela confirmada por replay deduplicado, sem avançar cobertura fictícia.

### 3.4 Assinaturas: diferenças concretas e liberação

`create_subscription` retorna `subscription_id`, `ownership_key` e estado; `delete_subscription` exige **ownership_key**, não ID remoto. Guardar ambos por contexto e identificar qual cliente é dono. Assinatura criada pelo Core aparece ao SDK como equivalente sem autoria e é recusada com `subscription_exists_unowned`; não copiá-la para o diário privado do LinkedIn nem inventar ownership_key.

`list_subscriptions` usa offset, lotes de até 50 e não infere autoria. A pré-criação do produtor consulta até 400 assinaturas; `coverage_incomplete` interrompe a operação. Não ignorar o limite ou tratar a listagem incompleta como zero.

Dois defeitos foram reproduzidos no fluxo entregue e devem ser corrigidos no **produtor LinkedIn** antes de liberar gestão externa de assinaturas:

1. **R3-LI-01:** depois de POST incerto, repetir a mesma chave é bloqueado, mas outra chave para a mesma intenção pode fazer novo POST se a busca remota ainda vier vazia. Exigir guarda por recurso/intenção incerta, inclusive com nova chave. Core também conserva sua chave e pausa, sem presumir que isso corrige o produtor.
2. **R3-LI-02:** se o grant for revogado durante a listagem preparatória, o POST ainda é executado; só o resultado final vira `revision_conflict`. Exigir revalidação de grant/revisões junto à mutação, após a pré-consulta, e resultado explícito de efeito incerto quando a alteração ocorrer com a requisição já em voo. A proteção de leitura recebida não cobre esse cenário.

O ensaio desta revisão usa `LeadReader.php` real com colaboradores em memória; não é homologação WordPress/API. O mantenedor deve produzir regressão nativa/correção e o Core repetir N31/N32 com o binário corrigido. Leitura/polling podem ser desenvolvidos contra 0.1.0; webhook externo e troca que dependam dessas mutações não recebem aceite integral antes dessas provas.


## 4. Identidade, progresso e ingestão

A identidade comercial preservada é **origem LinkedIn + conta + formulário + ID remoto da resposta + `submittedAt` em milissegundos**. Cliente escolhido, ID da conexão local e ID da integração não entram na chave de deduplicação comercial. Guardá-los como proveniência operacional permite auditoria sem criar contatos novos após a troca.

Não usar e-mail/telefone como identidade de submissão. IDs e milissegundos passam sem conversão para ponto flutuante ou arredondamento. Manter perguntas por ID, versão do formulário, consentimentos da origem, marca `testLead` e campanha/criativo comprovados. Lead nativo não recebe sessão web ou consentimento de navegador fabricados.

Preservar a distinção entre `CREATED`, `DELETED`, uma submissão posterior e um tombstone anterior. Um delete atrasado não cancela submissão mais nova. Conservar a política atual: cancelar pendências locais pertinentes, manter registro auditável e não apagar CRM/avisos já entregues por inferência.

O pipeline deve receber configuração/contexto explícitos da integração. Não continuar lendo a opção global dentro de `F3Base_Anuncios::ingerir`/normalização para decidir outra conta ou mapeamento. Meta e Google mantêm seus percursos e identidades existentes; testar a fronteira compartilhada afetada.

Cursor avança somente após a persistência das submissões e do checkpoint. Falha após persistir contatos, mas antes do cursor, permite replay deduplicado. Marco confirmado não regride nem é redefinido para agora em uma simples troca de cliente. Cursores opacos só atravessam clientes quando o contrato comprovar equivalência; por padrão, reabrir a leitura desde o marco confirmado, com sobreposição limitada pela política existente e deduplicação. Se a janela já não existir na origem, registrar lacuna; não declarar cobertura completa.

Notificações não avançam o cursor do polling. Um 404 transitório na leitura individual é tratado separadamente de uma notificação `DELETED` válida. Recibos com falha de gravação não recebem confirmação de sucesso.

## 5. Troca explícita e retomável

### Operação administrativa proposta

Publicar a operação `f3base/anuncios-linkedin-cliente-alterar`, com `integracao_id`, cliente/conexão de destino, revisão esperada, `simular` e chave de idempotência. O nome e o schema fazem parte da entrega Core 8.0.0. Simulação permanece classificada como escrita; não inicia polling nem cria/remove assinaturas. Se uma conferência remota for necessária, declará-la explicitamente no resultado e respeitar orçamento.

Escrita genérica de configuração que tente mudar o cliente de um fluxo existente deve ser recusada com orientação para essa operação, ou executar o mesmo serviço de domínio com todas as guardas. Não oferecer uma via que troque a opção e deixe assinaturas/cursores inconsistentes.

Leituras de diagnóstico publicam selecionado, disponível, acesso conhecido, estado da operação e motivo da pausa separadamente. Antes do commit, a interface informa “troca pendente”; salvar uma intenção não significa que o cliente de destino está executando.

### Sequência e critérios

1. **Preparar:** validar configuração, capacidade SDK, concessão, acesso ao mesmo recurso remoto e revisões. A prévia descreve conta/tipo/formulários, cliente atual/destino, cursores, assinaturas e impedimentos, sem respostas pessoais ou segredos.
2. **Reservar:** obter exclusão sobre a integração e seus recursos remotos normalizados. Comparar sobreposição entre integrações, clientes e conexões locais diferentes; bloquear o mesmo formulário/conta/tipo em dois fluxos comerciais ativos. Listas vazias não criam autorização ampla.
3. **Pausar/drenar:** suspender novos lotes, renovar lease e esperar/encerrar com segurança o trabalho já iniciado. Cercar workers por geração/revisão e revalidar antes de persistir. Um lease vencido não autoriza um worker antigo a confirmar estado.
4. **Reconciliar recebimento:** conferir app, segredo pelo seu dono, callback, assinaturas próprias e notificações duráveis/em trânsito. Não supor compatibilidade de cursores ou assinatura entre apps. Resultado remoto incerto mantém a operação pausada e requer reconciliação; não repetir criação/remoção cegamente.
5. **Confirmar localmente:** só promover a seleção e sua nova geração após os pré-requisitos. Registrar evidências e progresso para retomar se o processo cair. Não alegar transação atômica envolvendo banco WordPress e API LinkedIn.
6. **Retomar:** executar apenas o cliente escolhido, a partir do progresso confirmado; validar recebimento e repetir com segurança a página incompleta. A operação idempotente relê seu resultado confirmado.

Antes do commit, falha mantém a seleção anterior registrada e a operação diagnosticável; não voltar a despachar automaticamente se as assinaturas ficaram em estado incerto. Depois do commit, retorno ao cliente Core é **uma nova troca explícita**, com as mesmas guardas. Não é rollback do pacote ou de dados comerciais já entregues.

Uma limitação de observabilidade remota não pode ser mascarada como troca segura. Se não for possível estabelecer uma estratégia verificável para notificações em trânsito ou autoria das assinaturas, recusar a ativação do destino com motivo e manter o progresso.

## 6. Callback e assinaturas

Manter a rota pública Core existente quando compatível. Adicionar resolução não ambígua de integração/contexto; o parâmetro público identifica uma configuração já autorizada e não escolhe livremente cliente, conta ou segredo. A callback não exige autenticação MCP.

No estado estável, challenge/assinatura usam o cliente selecionado: segredo Core no modo Core; validação via SDK no modo plugin. Não decodificar/reformatar o corpo antes de verificar a assinatura. Preservar limites de entrada, allowlists, comparação segura e vínculo de app/conta/tipo/formulários/marco.

**Drenagem de notificações:** o SDK 0.1.0 só aceita a revisão corrente da conexão/grant. Ele não verifica uma revisão antiga após rotação. A troca de cliente deve conservar conexões/revisões necessárias ao recebimento anterior; não rotacionar a mesma conexão como parte implícita da troca. Se isso não for possível, pausar e reconciliar antes da promoção. O protocolo verificável deve ser documentado/testado com o produtor antes da liberação. Contextos antigos só podem ser aceitos de forma delimitada e vinculados a assinaturas anteriores conhecidas, com a verificação do app correto e política de transição persistida. Isso pode exigir verificação de recebimento pelo contexto anterior durante a drenagem; não autoriza um segundo polling, importação por cliente alternativo ou fallback comercial. Não encaminhar um payload antigo ao segredo do cliente novo por tentativa.

Recibos já confirmados continuam processáveis ou ficam em pendência explícita após a troca. Repetição de notificação gera o mesmo recibo/efeito; perda da credencial necessária para verificar um contexto antigo é uma pendência real. Não prometer recuperação integral de exclusões tardias apenas pelo polling de novas respostas.

Assinaturas Core não são adotadas pelo diário LinkedIn. Para trocar, a assinatura anterior deve ser mantida sob seu dono durante a drenagem ou removida por ele com confirmação, antes da nova criação autorizada; preservar a prova dos dois lados. O `ownership_key` do plugin nunca é inferido do ID remoto.

Listar/reconciliar assinaturas antes de criar equivalente. Remover somente assinaturas cuja autoria e relação com o fluxo estejam comprovadas. Separar intenção gravada, operação remota aceita e estado verificado. Manter a recuperação por polling e as lacunas observadas. Não mudar a URL em massa durante instalação sem reconciliar as assinaturas.

## 7. Interface e documentação

Na área existente **Conexões e entregas → Origens de anúncios → LinkedIn**, listar integrações com nome, conta/formulários, cliente escolhido, próximo processamento e estado. A edição mostra opções em radio/select com explicações curtas:

- **Cliente do Core:** utiliza as credenciais cadastradas no Core e funciona sem o plugin LinkedIn. Mantém a implementação atual e sua manutenção.
- **Cliente do plugin LinkedIn:** utiliza conexão/concessão do plugin LinkedIn; sua disponibilidade depende desse provedor e do contrato público. Não transfere credenciais.

Diferenciar “disponível”, “selecionado”, “autorizado”, “última leitura confirmada” e “homologação registrada”. A presença do plugin não produz selo de homologação. A opção externa aparece desabilitada com motivo enquanto faltar contrato/cliente; campos preenchidos para outra integração não devem impedir salvar uma alteração independente.

A troca exibe prévia concreta e confirmação final; revisão vencida pede nova leitura sem perder o formulário digitado. Detalhes de assinatura/cursor ficam recolhidos; estado e ação recomendada ficam visíveis, com horários no fuso do site. Segredos permanecem em seus painéis, sem valor reapresentado.

Documentação instalada deve publicar configuração 8.0.0, exemplos de leitura/troca/retomada, schemas e permissões, distribuição de responsabilidades, limites de homologação e matriz de testes. Não chamar a classe privada da 1.33.0 de SDK substituível.

## 8. Provas mínimas e dependências

- L0/LI-04: entrypoint, schemas de entrada, métodos e fixtures recebidos na 0.1.0. Falta o consumidor Core e a prova conjunta; não manter o produtor como indisponível.
- R3-LI-01/02: correções de mutação de assinaturas e regressão nativa pelo mantenedor, seguidas de N31/N32 no consumidor. Conservar as quatro observações locais como reprodução unitária, não prova WordPress.
- Concessão por integração: duas integrações na mesma conexão têm consumidores/callbacks próprios; grant e identidade Core não são escolhidos por parâmetro livre da callback.
- Transição: URL 1.33 preservada no upgrade; ownership separado; mudança de cliente distinta de rotação, sem aceitar contexto já invalidado ou fabricar prazo de drenagem.
- Bancada: Core sozinho; ambos presentes com Core selecionado; externo selecionado; ausência/incompatibilidade do escolhido; usuário zero; grant revogado; duas contas/conexões; recursos sobrepostos; lista vazia; duas integrações independentes; dois workers.
- Transição: Core → plugin → Core; falha antes/depois do commit; atualização concorrente; quota; token trocado; assinatura incerta; notificação tardia/repetida; `CREATED`/`DELETED`; 404 transitório; falha SQL e replay após persistência.
- Preservação: cliente escolhido não muda a identidade comercial, não duplica contato/intenção de entrega, não reenvia histórico e não fabrica sessão. Configuração e credenciais preservadas na atualização 1.33→1.34.
- I02/S05 exige **binário LinkedIn real**, hashes e consumidor Core real; respostas remotas simuladas podem provar os casos locais de falha, identificadas como tal.
- I03/L07/L14 exige app/conta/formulário e destino autorizados, challenge/notificação reais, lead de teste, recibo, deduplicação, entrega e alternância nos dois modos. Fixtures não comprovam aprovação do app.

Pages/Ads/Instagram Insights podem ser liberados pelos seus donos sem esperar a integração comercial. Sheets social, BigQuery, OAuth interativo novo e ampliação para outros tipos Lead Sync não fazem parte deste contrato Core.
