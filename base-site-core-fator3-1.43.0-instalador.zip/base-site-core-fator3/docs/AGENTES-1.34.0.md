# Guia de agentes — Core 1.34.0

Leia DOCUMENTACAO.md e o schema instalado da ability antes de operar. Contrato administrativo 8.0.0; provider base-site-core-fator3. SDK de medição 1.0.0/schema 1 permanece separado da configuração administrativa. Referências ensaiadas localmente: MCP 0.23.0, Google 0.10.0, LinkedIn 0.2.0, Meta 0.2.0; não inferir suporte apenas pelo número da versão.

## Leitura documental

`f3base/documentacao-ler` sem parâmetros lista a allowlist. Com `arquivo`, `linha` e `limite` (1–200), retorna versão, SHA-256, total e proxima_linha. Continue até nulo. Caminhos arbitrários, traversal e usuário sem manage_options são recusados. Ajuda estática não lê fornecedor nem muda preferências. `dados/abilities-*.json` contém schemas integrais e `dados/configuracao-schema.json` descreve as opções sem segredos efetivos.

## Configuração e operação

Ler → obter revisão → prévia → gravar pelo canal autorizado → reler. Conflito de revisão exige nova leitura, nunca sobrescrever às cegas. Segredos são inseridos nos campos protegidos do wp-admin e não vão a relatórios. Diagnóstico de credencial mantém booleanos e estado, nunca seu valor. Aprovação de instalação não autoriza mensagens, gastos ou assinaturas reais.

LinkedIn: leia LINKEDIN-LEAD-SYNC.md. Escolha por integração; Core sozinho funciona. No cliente externo, criar concessão para o consumidor estável no produtor. Troca é ability dedicada com integracao_id, cliente, connection_id, revisão e chave. Não alterar cliente por edição bruta de option. Incerteza de assinatura bloqueia novo POST mesmo após GET vazio. Notificações em trânsito sem prova bloqueiam promoção.

Google/GSC: separar SDK presente, estrutura pronta, concessão resolvida e coleta publicada. `f3base_gsc` não é credencial. Conexão efetiva pode não ser default. Diagnóstico não dispara coleta e consulta Core não comprova passagem do cron Google. Measurement SDK conserva seis slots, revisões, null e fronteira de leitura; nenhum novo campo fechado foi acrescentado.

Pipedrive: identidade de conta/catálogo não depende do orçamento. Alterar token/conta invalida prova; não marcar catálogo incompleto como válido. Qualidade usa reserva própria, sem consumir reserva de entregas. Encerramento terminal exige três confirmações espaçadas. Alertas operacionais vão ao admin_email e o aceite SMTP/wp_mail não prova chegada.

GTM: sem ID, reconciliar encerramento; não reativar espera esgotada para limpá-la. `tracking-encerrar-gtm` exige revisão e simula por padrão. ID inválido não é ausência. Slack: principal removida não comprova thread inteira limpa; resposta exige recibo e ausência. Não mudar registros antigos automaticamente.

## Testes, dados e recuperação

Navegação de teste: /f3base-teste/ ou X-F3Base-Teste: 1 em todas as requisições internas. Não enviar essa marca a fornecedores. Teste não autoriza contato a cliente. Lead nativo mantém testLead remoto; não atribuir IP/sessão do executor. Consentimento e evento de aceite são independentes de clique.

Nova instalação ou atualização direta 1.33→1.34. Consultar ciclo/prontidão em nova requisição depois da ativação. Reservas/etapas/finalização pertencem ao alvo 1.34. Backup inclui banco, arquivos privados e guardas independentes Core/companheiros. Não restaurar sentinela antiga sobre execução ativa. Reversão de arquivos não reverte o modelo administrativo 8.0.0; exige backup compatível e reconciliação.

Medição configurada, permitida, enviada e recebida são evidências diferentes. Eventos de fornecedores simulados e relógio acelerado não encerram homologação remota. Não inferir sucesso de ausência de erro ou silêncio.
