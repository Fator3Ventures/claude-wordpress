# Encaminhamento — Site Core 1.32.0 implementado

15/10/2026. Destinatários: responsáveis por MCP, MCP Google e pelos receptores JSON existentes. Este relatório acompanha a entrega; não foi enviado a terceiros. Nenhum desses componentes foi modificado.

## MCP

Contrato Core passou de 6.7.0 para **7.0.0**. Provider `base-site-core-fator3`, perfil 3.5 e política de autorização preservados. Descobrir o catálogo efetivo; não manter contagem fixa nem conceder automaticamente permissões de um nome retirado a outro.

- Retirada definitiva: `f3base/config-procedencia-reparar`, reparo específico de versão antiga. Leitura de complementações/procedência permanece.
- Novas abilities: `f3base/anuncios-linkedin-acesso-verificar`, `f3base/anuncios-linkedin-consultar`, `f3base/anuncios-linkedin-webhook-configurar`.
- Verificação não lê leads. Consulta pode importar contatos quando `simular: false`. Cadastro de webhook exige ação administrativa, revisão e chave de operação; segredos não são argumentos dessas abilities.
- `integracoes-ler` e Saúde incluem estado LinkedIn e três orçamentos Pipedrive. Diagnósticos dos companheiros agora usam `regra: contrato_e_capacidades`; versão observada é informativa.
- Relatórios e filtros admitem métodos nativos Meta, Google e LinkedIn; Lead Sync usa `anuncio_linkedin`.
- Configuração nova: `f3base_anuncios_linkedin` e segredos privados próprios; `mensagens.baixar_conteudo`; orçamento da qualidade Pipedrive. Schemas completos em `docs/dados/`.

O registro usa `f3_mcp_register_providers` e `ExtensionContract::register`. Verifica contrato `server-integration/1.0.0`, política 1, provider `wp-mcp-fator3`, server `wp-mcp-ultimate-server` e métodos efetivos. Ausência, ordem de carregamento ou número de versão não impedem instalar/ativar o Core. Contrato incompatível degrada apenas a integração.

## MCP Google

Preservado SDK `search-console-reader/1.0.0`, consumidor `base-site-core-fator3`, concessão explícita e conexão efetiva. Exige capacidades declaradas e métodos chamáveis `query`/`effective_status`; não há fallback para conexão corrente por ausência de diagnóstico. Resposta malformada fica `unreadable` localmente, sem produzir autorização.

O Core não chama `google/complete-transition`, `google/migrate-storage` nem `google/maintenance`. A retirada de rotas antigas no Google não requer alias no Core. Credenciais, cron, cotas, jobs e guardas continuam separados. O LinkedIn é integração própria do Core, sem participação do Google.

## Callback LinkedIn e receptor JSON

GET/POST `/wp-json/f3base/v1/anuncios/linkedin/notificacoes` é REST público autenticado por HMAC do LinkedIn. Não adicionar autenticação MCP, login WordPress ou cookie de agente. O endpoint exige HTTPS, não gera audiência e grava recibo antes do aceite. Proxy/cache/WAF precisam permitir o protocolo descrito em `LINKEDIN-LEAD-SYNC.md`; o Core não altera infraestrutura externa.

O alerta Pipedrive também usa o destino JSON já habilitado. Novo schema `f3base.operacao.v1`, tipo `pipedrive_orcamento`; assinatura pelos mesmos headers HMAC de avisos. Receptores devem distinguir ocorrência operacional de lead e ignorar de forma segura schemas que não tratam. Não requer configuração adicional de URL/chave no Core.

## Matriz exercitada e limites

Companheiros reais disponíveis: **MCP 0.21.0 e MCP Google 0.8.4**. Ensaios locais cobrem duas ordens de carregamento, registro frio, conexão Google não padrão, usuário cron zero, pausa/retomada independente e upload do ZIP por ability MCP. A chamada do SDK não fabrica usuário humano nem passagem cron.

MCP 0.21.1 / Google 0.8.5 foram considerados pelos planos recebidos, mas seus executáveis finais não estavam disponíveis nesta bancada. Não há alegação de teste desses binários nem trava esperando sua entrega. Ao disponibilizá-los, repetir a matriz de capacidades e recuperação com seus hashes reais.

Instalação nova e referência 1.31.0: estruturas atuais e complementações preservam dados comerciais, segredos cifrados, filas, concessões e procedência. Conversores antigos não são reexecutados. Tema e implantador não pertencem ao Core. Backup/restore continua exigindo coordenação das guardas de cada plugin, sem retomada automática de outros participantes.

Nenhuma mudança funcional adicional foi identificada como obrigatória nos companheiros para esta release. A homologação remota LinkedIn exige aplicativo aprovado, credenciais e ativos do dono, endpoint público e observação da notificação/revalidação; está separada da prova local.
