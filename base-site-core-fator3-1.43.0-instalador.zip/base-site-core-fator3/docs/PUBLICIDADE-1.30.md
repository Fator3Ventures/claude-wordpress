# Publicidade, medição e negativas — 1.30

`f3base_consentimento.publicidade_politica` tem padrão `pre_autorizada` em instalação nova e é complementada na atualização. A complementação preserva a procedência da opção. Também existe `exigir_decisao`, visível em Privacidade/Consentimento. **Não há reenvio automático de conversões anteriores** pela mudança.

A política do site permite publicidade quando não há negativa explícita. Isso não é prova de consentimento individual. A resposta efetiva contém `permitida`, `fundamento` (`politica_do_site`, `decisao_explicita`, `negativa_explicita`, ou causa de indisponibilidade), `evidencia` e `politica`.

- Medição e histórico de navegação continuam sujeitos à autorização de medição. Sem ela, não registrar sessão/visitante/jornada; a atribuição fica no toque atual, podendo manter identificadores de anúncios se publicidade estiver permitida.
- Tags publicitárias, aquisição CAPI e retorno de qualidade usam a mesma política. Credenciais, transporte, dataset, janela, idempotência, exclusão de editor/404 e classe de teste continuam obrigatórios.
- Negativa explícita do navegador, da referência, do snapshot com negativa conhecida ou do contato prevalece sobre o padrão. Referência expirada/revogada não apaga a negativa. Ao revogar, o Core grava um resumo restritivo no contato na mesma transação do recibo. Perder a referência positiva não inventa consentimento: a autorização passa a ser identificada como política do site, quando aplicável.
- No modo legado o controle permite/recusa as duas categorias em conjunto. No modo granular elas são independentes. GTM sem separação conferida continua exigindo ambas; o Core não controla snippets instalados por terceiros.

## Contatos nativos e negativa manual

No padrão pré-autorizado, não é necessário preencher evidência para cada formulário Meta. As evidências anteriores continuam preservadas como complemento, não como requisito nem prova fabricada pelo Core. No modo exigir decisão, ausência de decisão individual permanece restritiva.

Quando houver campo nativo de negativa, configure explicitamente:

```json
{"mapeamento":{"formularios":{"123":{"publicidade":{"campo":"autorizacao_publicidade","negativas":["Não autorizo","nao"]}}}}}
```

Somente respostas exatas do campo mapeado são negativas. Uma resposta “não” a outra pergunta não deve ser interpretada como recusa. O resumo em `dados.publicidade` guarda a fonte, campo e instante da negativa; não muda o contato comercial nem cancela seus avisos internos.

Na ficha do contato há **Publicidade e negativa do contato**. Informe motivo para registrar a negativa. MCP: `f3base/contato-publicidade-negar`, com `record_id`, revisão inteira do contato, `motivo` e `simular` (true por padrão). O despacho reconfere a decisão; uma requisição externa já iniciada não pode ser desfeita. A negativa acompanha o contato até sua eliminação, mesmo após a retenção dos eventos brutos.

## Relatórios e mensagens

`dados.publicidade` guarda o fundamento na captura; `dados.consentimento_snapshot` conserva evidência histórica. A apresentação canônica de e-mail, Slack e Pipedrive distingue política do site de decisão explícita. Histórico de comportamento não é liberado pela política publicitária. Consultar situação atual não modifica mensagens já entregues nem notas antigas.
