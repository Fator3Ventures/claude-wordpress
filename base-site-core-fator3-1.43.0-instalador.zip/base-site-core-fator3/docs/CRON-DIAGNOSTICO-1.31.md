# Cron e confirmação da agenda — Core 1.31.0

Uma passagem registrada prova execução; uma entrada de agenda prova intenção futura; persistir o diagnóstico é uma terceira confirmação. `could_not_set` sozinho não prova concorrência e não transforma falha de banco em sucesso.

O Core observa somente hooks do seu registro de tarefas e o próprio despertador. Não usa o prefixo como autorização para alterar hooks de MCP, Google, WordPress, tema ou terceiros. A leitura de Saúde/Operação não agenda nem executa tarefa.

Para recorrentes, a prova compara hook, argumentos completos, recorrência, intervalo e timestamp final capturado depois do alinhamento de calendário. Uma ocorrência posterior só equivale à intenção se estiver na grade exata daquele intervalo. Remoção confirma ausência da ocorrência exata, sem confundir ausência de uma ocorrência com ausência de todo o hook. Persistência SQL e leitura efetiva precisam concordar; erro ou divergência resultam em confirmação desconhecida, nunca sucesso presumido.

Cada pendência preserva revisão de configuração pertinente, primeira/última observação, tentativas e próximo horário. Observação repetida não zera recuo nem reabre orçamento. Retomada compartilha orçamento de três intenções por passagem e até cinco tentativas por intenção. Confere configuração e callback antes de escrever e novamente depois; tarefa desligada cancela, configuração substituída encerra a intenção anterior. Metadados insuficientes não autorizam mutação. O registro do WordPress permanece visível.

`cron_diagnostico` expõe agenda confirmada (true/false/null), gravação do diagnóstico, pendências, resoluções e completude. Há até 100 detalhes de observação, contagens por hora UTC na janela de 24 horas incluindo a hora limítrofe e contador de detalhes omitidos. Resoluções mantêm os últimos 100 registros, com contador de omissões. Pendências não são descartadas para caber nessa amostra. Ausência de incidente não confirma a agenda inteira.

Na tela Operação, a confirmação aparece separada das execuções e com horários no fuso do site; o JSON técnico fica recolhido. Rotas de leitura não corrigem agenda silenciosamente. A própria tarefa pode ser retomada pela operação autorizada já existente.

MCP 0.21.0 corrige o marcador próprio; Google 0.8.4 usa `cron.scheduling/2.0.0`. Esses diagnósticos têm proprietários independentes. Nenhum resultado antigo de MCP/Google substitui a prova atual da agenda do Core.
