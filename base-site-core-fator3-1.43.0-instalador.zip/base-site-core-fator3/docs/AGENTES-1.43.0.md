# Agentes — Core 1.43.0

Leia RELEASE-1.43.0.md e o catálogo executável 8.8.0. A versão não autoriza envio de testes, publicação ou instalação na frota por si só.

1. Use fotografia e revisão atual antes de gravar; simule quando o serviço oferecer. Uma revisão divergente exige nova leitura.
2. E-mail automático: nome canônico `email-novo-lead`; aliases temporários `c0-*` removidos. Preserve migração, cota, intenções incertas e atividade independente.
3. MCP Google 0.16.0: `site-conversion-delivery/1.0.0` com extensão `site-conversion-reconcile/1.0.0` e `reconcileBound`. `incerto` é pendência de confirmação, nunca autorização de reingestão. Não remonte destino nem forneça referência nova para recibo antigo.
4. `comparacao.totais: null` significa audiência não retida, não zero. Search Console declara comparação indisponível. Em `reduza_periodo`, reduza a janela e não apresente taxas parciais.
5. Relatórios de redes distinguem estado atual da fonte e evidência histórica. Não executar DNS reverso nem reclassificar o histórico.
6. Segredos são de escrita, nunca ecoar valores. A página Credenciais complementares somente encaminha ao campo responsável.
7. Catálogos de descoberta são metadados temporários. Permissões e responsabilidade pela importação continuam sendo validadas no fluxo original. Cliente externo LinkedIn não oferece descoberta tipada no contrato consumido; não trocar cliente para contornar isso.

Sem novo impacto a repassar ao MCP Google além do consumo da dependência 0.16.0 já recebida. O Core incorpora a confirmação assíncrona e o painel consulta o estado público do destino.
