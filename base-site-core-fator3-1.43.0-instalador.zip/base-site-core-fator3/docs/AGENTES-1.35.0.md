# Guia de agentes — Core 1.35.0

Leia DOCUMENTACAO.md, RELEASE-1.35.0.md e CONVERSOES-CONTEUDO-1.35.md antes de operar. Normas comuns revisão 4. Identidades publicadas preservadas. Cabeçalho mínimo: WP 7.1.2/PHP 8.3.6 64 bits. Base direta 1.34.0. Configuração administrativa 8.1.0; SDK público 1.0.0/schema 1 fechado.

## Receitas

1. Leia f3base/documentacao-ler sem parâmetros; depois arquivo/linha/limite (até 200) até proxima_linha nula. Compare SHA-256. A leitura exige manage_options, allowlist e não consulta fornecedor. dados/abilities-*.json e dados/configuracao-schema.json são extraídos do registro instalado.
2. Para material: ler opções com revisões; configurar os quatro booleanos e identificadores próprios com autorização do dono; simular, gravar, reler. Não ligar destinos durante atualização. Verificar aceite de formulário e chamadas locais; recebimento só com evidência da plataforma. Não enviar teste comercial por inferência.
3. Para editorial: consultar 28 dias e conferir fonte/contagem/limite em eventual recusa. memory_limit e arena são a mesma base; memória viva e pico são diagnósticos separados. Crescimento observado não é medição exclusiva por plugin. Não aumentar o limite automaticamente nem fabricar relatório parcial.
4. Para Slack: verificar raiz e respostas próprias; conformidade compara blocos canônicos. Editar exige revisão local/remota e operação autorizada. Conversas humanas e mensagens sem autoria comprovada não são modificadas. Envio/deleção exige autorização e destino de teste específico.
5. Para Pipedrive: prévia do contato nativo deve mostrar rótulos de catálogo em texto; enum/set continuam IDs. Material usa ponto conteudo, contato WhatsApp mantém seu ponto. Prévia não cria lead remoto.

## Troca e evidência

Backup de banco, privados e guardas operacionais. Instalação nova ou atualização 1.34→1.35; 15 etapas e confirmação em requisição posterior. Preservar histórico de entregas e pendências incertas. Lead legado de material ainda não enviado é suspenso, sem converter silenciosamente em outro evento. Rollback exige backup compatível e reconciliação; arquivo antigo sozinho não desfaz migração.

A leitura do Google 0.10.0 permanece no SDK 1.0.0 e não descobre material. Impacto coordenado acompanha a entrega. Não modificar plugins Google, Meta, LinkedIn, MCP ou Implantador nesta tarefa. Fluxos sociais mantidos: LINKEDIN-LEAD-SYNC.md e GSC-1.34.md.

Teste local usa dados sintéticos, correio/rede bloqueados; relógio acelerado é identificado. Instalação no Site-Teste não prova Tag Assistant em CTO, prévia Korvena, Slack editado à mão ou recebimento publicitário. O relatório externo lista provas próprias e aceites pendentes por responsável.
