# Catálogo de medição — Core 1.33.0
Gerado de `dados/eventos-comportamento-fonte.json`. A fachada devolve o catálogo completo e sua revisão. Não são dimensões criadas nas contas remotas.
Os parâmetros abaixo são lógicos. Os roteadores acrescentam metadados de transporte:
- `send_to`: ID de destino Google; acrescentado pelo roteador.
- `timestamp_micros`: Instante do envio Google; não muda o nome lógico.
- `event`: Nome lógico inserido no objeto dataLayer.
- `traffic_type`: internal quando teste marcado.
- `debug_mode`: true quando teste marcado.
- `f3base_contexto_teste`: Marca booleana do dataLayer em teste.
- `eventID/event_id`: Correlação Meta; propriedade do envelope do transporte.
- `transaction_id`: Correlação da conversão Google Ads.
- `conversion_id`: Configuração pública da conversão LinkedIn; não é resposta de formulário.

Tags externas também podem emitir seus próprios sinais automáticos. Este catálogo descreve o que o Core declara ou inicializa; não inspeciona tags de terceiros no GTM.

## f3base_rolagem
Quanto da pagina as pessoas leem antes de parar.
Gatilho: rolagem. Papel: `none`.
Parâmetros: `f3base_marco`.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 6 emissões por carregamento; limites da visita e do lote também se aplicam. Quanto da pagina as pessoas leem antes de parar. Limiares efetivos: marcos=25,50,75,90;travessias_por_sessao=30;histerese_pp=5;salto_ms=1000;salto_ancora_ms=2000. Até 30 travessias por sessão; banda de 5 pontos evita oscilação. Saltos são registrados separadamente.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_rolagem` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_rolagem` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_rolagem` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_secao_vista
Quais blocos da pagina chegam a ser vistos, e quais ficam abaixo do ponto em que a leitura acaba.
Gatilho: interseccao. Papel: `none`.
Parâmetros: `f3base_secao`.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 18 emissões por carregamento; limites da visita e do lote também se aplicam. Quais blocos da pagina chegam a ser vistos, e quais ficam abaixo do ponto em que a leitura acaba. Limiares efetivos: visivel=0.5;saida=0.2;travessias_por_sessao=30;ocupa_janela=0.5. Até 30 travessias por sessão. Entra em 0,5 e rearma abaixo de 0,2 para evitar leituras fabricadas pela oscilação.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_secao_vista` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_secao_vista` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_secao_vista` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_link_externo
Para onde o visitante sai quando sai do site.
Gatilho: clique-externo. Papel: `none`.
Parâmetros: `f3base_dominio`.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 15 emissões por carregamento; limites da visita e do lote também se aplicam. Para onde o visitante sai quando sai do site. Limiares efetivos: —.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_link_externo` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_link_externo` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_link_externo` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_friccao
Onde a pessoa clica repetido esperando algo acontecer — em geral, onde ela achou que havia um botao e nao havia.
Gatilho: clique-repetido. Papel: `none`.
Parâmetros: `f3base_cliques`.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 5 emissões por carregamento; limites da visita e do lote também se aplicam. Onde a pessoa clica repetido esperando algo acontecer — em geral, onde ela achou que havia um botao e nao havia. Limiares efetivos: cliques=4;janela_ms=1200;raio_px=24;alvo=interativo.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_friccao` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_friccao` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_friccao` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_erro_js
Quais paginas quebram no navegador do visitante, com o arquivo e a linha do defeito.
Gatilho: erro. Papel: `none`.
Parâmetros: `f3base_arquivo`, `f3base_linha`.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 5 emissões por carregamento; limites da visita e do lote também se aplicam. Quais paginas quebram no navegador do visitante, com o arquivo e a linha do defeito. Limiares efetivos: origem=site.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_erro_js` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_erro_js` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_erro_js` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_web_vital
Quanto tempo a pagina leva para ficar utilizavel no aparelho de quem visita, medido nas visitas reais.
Gatilho: desempenho. Papel: `none`.
Parâmetros: `f3base_vital`, `f3base_valor`.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 6 emissões por carregamento; limites da visita e do lote também se aplicam. Quanto tempo a pagina leva para ficar utilizavel no aparelho de quem visita, medido nas visitas reais. Limiares efetivos: vitais=LCP,CLS,INP,TTFB;duracao_minima_ms=16.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_web_vital` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_web_vital` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_web_vital` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_pagina_vista
Quantas vezes esta pagina foi carregada — o denominador que torna todo o resto legivel.
Gatilho: pagina. Papel: `none`.
Parâmetros: nenhum parâmetro lógico.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 2 emissões por carregamento; limites da visita e do lote também se aplicam. Quantas vezes esta pagina foi carregada — o denominador que torna todo o resto legivel. Limiares efetivos: inatividade_min=30.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_pagina_vista` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_pagina_vista` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_pagina_vista` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_tempo_ativo
Tempo ativo estimado em cada bloco, com página visível e interação recente.
Gatilho: tempo-ativo. Papel: `none`.
Parâmetros: `f3base_secao`, `f3base_milissegundos`.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 18 emissões por carregamento; limites da visita e do lote também se aplicam. Tempo ativo estimado em cada bloco, com página visível e interação recente. Limiares efetivos: inatividade_ms=30000;maximo_ms=30000. Ligado por padrão; uma seção predominante por instante, tempo monotônico com página visível e atividade recente.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_tempo_ativo` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_tempo_ativo` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_tempo_ativo` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_saida
Quanto tempo a pagina fica aberta e visivel, e ate onde a pessoa desce antes de sair.
Gatilho: saida. Papel: `none`.
Parâmetros: `f3base_profundidade`, `f3base_visivel_ms`.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 6 emissões por carregamento; limites da visita e do lote também se aplicam. Quanto tempo a pagina fica aberta e visivel, e ate onde a pessoa desce antes de sair. Limiares efetivos: valor_max=86400000. Tempo cumulativo por navegação; o leitor escolhe a última marca, sem somar snapshots.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_saida` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_saida` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_saida` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_rolagem_salto
Ate onde a pagina foi levada por ancora ou por salto, sem leitura no caminho.
Gatilho: rolagem-salto. Papel: `none`.
Parâmetros: `f3base_marco`.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 6 emissões por carregamento; limites da visita e do lote também se aplicam. Ate onde a pagina foi levada por ancora ou por salto, sem leitura no caminho. Limiares efetivos: —.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_rolagem_salto` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_rolagem_salto` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_rolagem_salto` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_clique_interno
Quais botoes e links internos sao acionados, pelo nome declarado ou pela secao de destino.
Gatilho: clique-interno. Papel: `none`.
Parâmetros: `f3base_clique`, `f3base_clique_origem`.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 20 emissões por carregamento; limites da visita e do lote também se aplicam. Quais botoes e links internos sao acionados, pelo nome declarado ou pela secao de destino. Limiares efetivos: origens=1,2,3.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_clique_interno` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_clique_interno` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_clique_interno` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_clique_inerte
Onde a pessoa toca esperando resposta em algo que nao e botao nem link.
Gatilho: clique-inerte. Papel: `none`.
Parâmetros: `f3base_secao`.
Teto por carregamento; não é deduplicação entre fornecedores.
Teto atual: 5 emissões por carregamento; limites da visita e do lote também se aplicam. Onde a pessoa toca esperando resposta em algo que nao e botao nem link. Limiares efetivos: espera_ms=400.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_clique_inerte` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_clique_inerte` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_clique_inerte` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_form_aberto
Quais formulários foram vistos ou abertos?
Gatilho: formulario-aberto. Papel: `form_observation`.
Parâmetros: `form_id`, `codigo`.
Teto por carregamento; não é deduplicação entre fornecedores.
ID do formulário; recusa/fechamento acrescenta código fechado depois de dois-pontos. Sem conteúdo preenchido. Aceite continua distinto da conversão generate_lead.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_form_aberto` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_form_aberto` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_form_aberto` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_form_iniciado
Quais tiveram o primeiro campo preenchido?
Gatilho: formulario-iniciado. Papel: `form_observation`.
Parâmetros: `form_id`, `codigo`.
Teto por carregamento; não é deduplicação entre fornecedores.
ID do formulário; recusa/fechamento acrescenta código fechado depois de dois-pontos. Sem conteúdo preenchido. Aceite continua distinto da conversão generate_lead.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_form_iniciado` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_form_iniciado` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_form_iniciado` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_form_recusado
Quais envios foram recusados e por qual código?
Gatilho: formulario-recusado. Papel: `form_observation`.
Parâmetros: `form_id`, `codigo`.
Teto por carregamento; não é deduplicação entre fornecedores.
ID do formulário; recusa/fechamento acrescenta código fechado depois de dois-pontos. Sem conteúdo preenchido. Aceite continua distinto da conversão generate_lead.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_form_recusado` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_form_recusado` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_form_recusado` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_form_enviado
Quais envios foram aceitos?
Gatilho: formulario-enviado. Papel: `form_observation`.
Parâmetros: `form_id`, `codigo`.
Teto por carregamento; não é deduplicação entre fornecedores.
ID do formulário; recusa/fechamento acrescenta código fechado depois de dois-pontos. Sem conteúdo preenchido. Aceite continua distinto da conversão generate_lead.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_form_enviado` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_form_enviado` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_form_enviado` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## f3base_form_fechado
Quais foram fechados sem aceite observado?
Gatilho: formulario-fechado. Papel: `form_observation`.
Parâmetros: `form_id`, `codigo`.
Teto por carregamento; não é deduplicação entre fornecedores.
ID do formulário; recusa/fechamento acrescenta código fechado depois de dois-pontos. Sem conteúdo preenchido. Aceite continua distinto da conversão generate_lead.

| Destino | Nome | Regra |
|---|---|---|
| local | `f3base_form_fechado` | medicao: Coleta local habilitada, consentimento e contexto elegíveis. |
| ga4 | `f3base_form_fechado` | medicao: GA4 configurado, medição permitida e seleção deste evento habilitada quando existente. |
| gtm | `f3base_form_fechado` | medicao: GTM configurado, separação de categorias conferida e seleção data_layer habilitada quando existente; tags do contêiner não são inspecionadas. |

## oferta_exibida
Observação de exposição ou interação com oferta; não representa contato recebido.
Gatilho: oferta_exibida. Papel: `none`.
Parâmetros: `form_id`, `oferta_id`, `oferta_tipo`, `oferta_instancia`, `navegacao`.
Uma emissão de cada tipo por instância de oferta na navegação.
Limites de visita, lote e orçamento local se aplicam.

| Destino | Nome | Regra |
|---|---|---|
| local | `oferta_exibida` | medicao: Slot configurado, contexto de audiência elegível e política do destino permitida. |
| ga4 | `oferta_exibida` | medicao: Slot configurado, contexto de audiência elegível e política do destino permitida. |
| gtm | `oferta_exibida` | medicao: Slot configurado, contexto de audiência elegível e política do destino permitida. |

## oferta_aberta
Observação de exposição ou interação com oferta; não representa contato recebido.
Gatilho: oferta_aberta. Papel: `none`.
Parâmetros: `form_id`, `oferta_id`, `oferta_tipo`, `oferta_instancia`, `navegacao`, `gatilho`.
Uma emissão de cada tipo por instância de oferta na navegação.
Limites de visita, lote e orçamento local se aplicam.

| Destino | Nome | Regra |
|---|---|---|
| local | `oferta_aberta` | medicao: Slot configurado, contexto de audiência elegível e política do destino permitida. |
| ga4 | `oferta_aberta` | medicao: Slot configurado, contexto de audiência elegível e política do destino permitida. |
| gtm | `oferta_aberta` | medicao: Slot configurado, contexto de audiência elegível e política do destino permitida. |

## oferta_fechada
Observação de exposição ou interação com oferta; não representa contato recebido.
Gatilho: oferta_fechada. Papel: `none`.
Parâmetros: `form_id`, `oferta_id`, `oferta_tipo`, `oferta_instancia`, `navegacao`, `motivo`.
Uma emissão de cada tipo por instância de oferta na navegação.
Limites de visita, lote e orçamento local se aplicam.

| Destino | Nome | Regra |
|---|---|---|
| local | `oferta_fechada` | medicao: Slot configurado, contexto de audiência elegível e política do destino permitida. |
| ga4 | `oferta_fechada` | medicao: Slot configurado, contexto de audiência elegível e política do destino permitida. |
| gtm | `oferta_fechada` | medicao: Slot configurado, contexto de audiência elegível e política do destino permitida. |

## generate_lead
Contato de navegador confirmado pelo Core; formulário e CTA seguem a mesma regra comercial.
Gatilho: Confirmação positiva do endpoint de contato, com identidade de correlação.. Papel: `lead_conversion`.
Parâmetros: `form_id`, `correlation_id`, `event_id`, `superficie`, `method`.
Uma liberação por correlation_id na página após confirmação; importação nativa não chama este emissor.
Limites de visita, lote e orçamento local se aplicam.

| Destino | Nome | Regra |
|---|---|---|
| ga4 | `generate_lead` | medicao: Slot configurado, contexto de audiência elegível e política do destino permitida. |
| gtm | `generate_lead` | medicao: Slot configurado, contexto de audiência elegível e política do destino permitida. |
| google_ads | `conversion` | publicidade: ID e label válidos; consentimento de publicidade; transaction_id usa a correlação. Enhanced Conversions é transporte comercial separado. |
| meta | `Lead` | publicidade: Pixel e/ou CAPI conforme transporte efetivo; eventID/event_id compartilham a correlação; somente Meta pode deduplicar ambos. |
| linkedin | `conversion` | publicidade: Insight Tag e conversion_id configurados; somente visitante elegível. |
| clarity | `generate_lead` | medicao: Clarity carregado com medição permitida; somente form_id e method em set. |
| meta | `Lead` | publicidade: CAPI habilitada no transporte efetivo, credencial e consentimento pertinentes; event_id compartilha a correlação do Pixel. Recebimento remoto não comprovado pelo catálogo. |

## page_view
Visualização automática da tag GA4 e PageView do Pixel/CAPI; distinta da observação local f3base_pagina_vista.
Gatilho: Inicialização permitida da tag na página pública elegível.. Papel: `none`.
Parâmetros: nenhum parâmetro lógico.
Inicialização por página e guarda de carregamento das tags; sem deduplicação GA4 tag/servidor.
Limites de visita, lote e orçamento local se aplicam.

| Destino | Nome | Regra |
|---|---|---|
| ga4 | `page_view` | medicao: Emissão automática do gtag config; depende da política de medição. |
| meta | `PageView` | publicidade: Pixel/CAPI conforme transporte e política; identidade compartilhada para deduplicação Meta. |
| meta | `PageView` | publicidade: CAPI habilitada no transporte efetivo, credencial e consentimento pertinentes; event_id compartilha a correlação do Pixel. Recebimento remoto não comprovado pelo catálogo. |

