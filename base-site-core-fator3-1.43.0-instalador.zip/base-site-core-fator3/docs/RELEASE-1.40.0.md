# Core 1.40.0 — transporte de conversão e e-mail automático ao novo lead

Pedidos 236 e 237. Atualização direta da 1.39 ou 1.38; navegador é o padrão para novos contatos em ambos os destinos. Meta e materiais conservam seu comportamento.

## Conversões de contato

`f3base_conversoes_transporte` é objeto fechado: `{"ga4":"navegador","google_ads":"navegador"}`. Cada valor aceita navegador/servidor. Escreva pelo painel ou `f3base/config-core-escrever`, com revisão/CAS. Servidor exige adaptador pronto, contrato `site-conversion-delivery/1.0.0` e identidade de destino. Nenhum HTTP ocorre ao validar a configuração. Ausência posterior pausa a fila, sem fallback.

A decisão é persistida junto ao registro e devolvida no POST. O script usa essa resposta, inclusive em páginas antigas em cache. Recuperação não transfere registros de transporte. Registros marcados pela 1.39 continuam servidor; históricos sem prova não são automaticamente recuperados. IDs de clique ambíguos bloqueiam Ads.

`f3base/conversoes-contexto-ler` aceita `contract: site-conversion-purposes/1.1.0` para incluir `transport` por destino de contato, com selected/effective/ready/reason. A resposta 1.0.0 mantém seu schema. `f3base/conversoes-entregas-ler` mostra a escolha do registro. Ambas exigem administração. A leitura não consulta Google.

GA4 entregue significa recepção HTTP, não inclusão nos relatórios. O adaptador Google valida o payload antes do envio e limita associação à sessão original a 24h desde session_id. Não fabrica client_id/session_id. HTTP incerto não é reenviado. Ads exige um único clique e resultado individual. Não foi introduzido Data Manager nem contrato assíncrono.

## E-mail automático ao novo lead — histórico

A função foi introduzida nesta versão com configuração restrita à operação original. As instruções antigas foram substituídas na 1.42.0: consulte RELEASE-1.42.0.md para configuração por site, migração e recuperação. Esta seção não orienta a ativação da versão atual.

## Instalação e reversão

Instalar o ZIP Core pelo fluxo nativo WordPress; nenhuma conexão é ativada pela atualização. Google 0.13 permite usar navegador. Para servidor, aplicar a alteração Google entregue separadamente, configurar/verificar os ativos e então mudar o Core. A dependência não inclui o pedido Google 29.

Voltar arquivos para 1.39 é perigoso: aquela versão envia contatos pelo servidor incondicionalmente. Pausar execução antes de reversão e conservar banco/diários. Restaurar arquivos não desfaz conversões, e-mails ou atividades externos. Não apagar filas para reprocessar incertos.

## Limites da prova

Fixtures não comprovam entrega SMTP, Smart Bcc, atribuição GA4, conversão Ads ou WebView Android/Instagram. Essas provas exigem credenciais e ativos autorizados. e-mail automático ao novo lead permanece desativado por padrão. Dados pessoais, senhas e fixtures não fazem parte do instalador.
