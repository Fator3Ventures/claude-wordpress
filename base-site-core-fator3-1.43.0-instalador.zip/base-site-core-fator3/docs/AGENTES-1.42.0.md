# Guia para agentes — Core 1.42.0

Leia RELEASE-1.42.0.md e descubra os schemas atuais por `f3base/documentacao-ler` e pelo catálogo MCP. O índice lista IDs permitidos; use arquivo, linha e limite e siga proxima_linha até null. Confira versão e SHA-256 durante paginação.

Use os nomes descritivos `f3base_email_novo_lead`, `f3base_email_novo_lead_smtp_senha`, `f3base/email-novo-lead-ler` e `f3base/email-novo-lead-homologar`. O contrato administrativo é 8.7.0. A senha entra somente pelo dono no painel; não solicitar nem registrar seu valor em conversa. Demais valores usam config-core-escrever com revisão e simulação antes de persistir.

A ausência de configuração ou de texto de serviço é impedimento real: não inventar remetente, conteúdo, IDs ou autorizações. Status ativo não prova entrega. Confira diário e resposta SMTP; resultados incertos nunca autorizam reenvio. O histórico do CRM deve conter somente informação útil ao atendimento, enquanto diagnóstico fica no WordPress.

A atualização conserva as escolhas existentes e não ativa integrações. Teste Pipedrive somente nos sites e contas autorizados pelo dono, com caixa controlada, autorização de homologação e limpeza dos recursos criados. Leitura de ajuda não chama fornecedor.
