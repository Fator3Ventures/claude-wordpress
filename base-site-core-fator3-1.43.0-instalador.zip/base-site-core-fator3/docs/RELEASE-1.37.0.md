# Fator3 Site Core 1.37.0

Pedidos core 225 e 226(a–h). Base direta 1.36.0 ou WordPress novo. WordPress mínimo comprovado 7.1.2; PHP 8.3.6 de 64 bits. Identidade base-site-core-fator3/base-site-core-fator3.php preservada. Contrato administrativo 8.2.0; perfil piso-padrao-3.5, revisão 2026-10-12-core-1.31.0. São 65 opções operáveis e 130 abilities do provider Core, sem adição ou remoção de option/ability nesta rodada. O catálogo possui 68 entradas, das quais 3 não operáveis; o arquivo de referência publica 67 opções (65 mais 2 de governança).

## Mudanças

Título explícito sem host, {unidade}, validação de empresa, respostas completas em campo longo, serviço por formulário/campanha, ID nativo universal e diagnóstico de anúncio ausente. primeira atividade do lead por canal e expediente; negócio aberto recebe nota/tarefa de reenvio e lead existente de outra origem recebe nota. Retorno com link/prazo usa a thread Slack existente. Regras, defaults, exemplos, permissões e recuperação: PIPEDRIVE-1.37.md.

Nova configuração adiciona cinco propriedades ao grupo f3base_pipedrive e dois papéis em mapa_campos. O token e as escolhas existentes permanecem. Não há ativação automática, limpeza de mapas legados, retitulação de oportunidades, recalculo de atividades ou reenvio do histórico. A limpeza do mapa legado korvena exige aceite do novo campo e cabe à frota.

## Convivência e dados

SDKs site-measurement-context/1.0.0 e site-conversion-purposes/1.0.0 permanecem com schema_revision textual "1". A demanda Google 0.12.0 r2 já é atendida pelo contrato da 1.36.0; não depende desta release. Implantador deve descobrir schema 8.2.0 e preservar propriedades ao editar o grupo. O Core funciona autonomamente; MCP transporta operações remotas.

Nenhuma tabela ou coluna nova; marcador estrutural 1.35.0 mantido, ciclo de instalação 1.37.0. Journal comercial passa a registrar plano de atividade, classificação da oportunidade e retorno Slack; usa as tabelas existentes. Backup/restore conserva banco, arquivos privados e guardas. Rollback dos arquivos não desfaz efeitos nos fornecedores.

## Evidência e limites

O relatório externo identifica os bytes finais, instalação limpa, upgrade direto, provas nativas com fornecedores simulados e verificação do Site-Teste. Testes reais Pipedrive/Slack em CTOoffice ou korvena.com.br dependem da implantação e coordenação autorizadas do projeto Pipedrive/frota. Casos históricos Apex não têm causa diagnosticável sem os IDs/payloads completos. A versão implementa as regras, não declara aceites de outros responsáveis.
