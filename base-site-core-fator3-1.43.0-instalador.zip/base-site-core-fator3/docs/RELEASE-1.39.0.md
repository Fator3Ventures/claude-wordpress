# Fator3 Site Core 1.39.0 — pedidos 230–235

Base direta: 1.38.0. Contrato administrativo: 8.4.0 (aditivo). Identidade e SDKs de medição/conversão existentes preservados. Piso instalado permanece piso-padrao-3.5: nenhum novo valor específico de cliente é imposto.

## 230 — histórico no CRM

Visitas anteriores aparecem antes da sessão atual. Cada sessão detalhada contém data, origem/canal, entrada, páginas, tempo visível, cliques e formulários abertos. A leitura usa o mesmo navegador/site/classe e decisões de consentimento, dentro da retenção. Histórico tem 20 sessões por página, até 500 sessões e 10.000 eventos de origem por leitura; o texto tem orçamento de 6.500 caracteres e declara cortes. Nenhuma contagem é identidade de pessoa. A jornada considera saídas recebidas depois do último pageview, até a captura do contato.

Notas de novos envios e complementos consultam sessões já presentes nas notas da mesma oportunidade/conta. A projeção do CRM muda; snapshots originais de avisos são preservados. Notas incertas exigem reconciliação. Históricos acima do orçamento permanecem paginados no WordPress. A homologação real CTO/Korvena continua pendente.

## 231–232 — configuração Pipedrive

Em `f3base_pipedrive`, `parceiros_plataforma` mapeia plataformas para IDs positivos de alternativas do campo parceiro; padrão vazio. Exemplo: `{"google_ads":"49","linkedin_ads":"49"}` apenas na conta cujo catálogo confirme 49. `campos_fixos` mapeia chaves CRM de 40 caracteres hexadecimais para alternativa válida ou texto. Padrão vazio. Não contém ICP/152 hardcoded. Exige catálogo sincronizado do mesmo domínio; chaves conflitantes com mapeamentos são recusadas. É aplicado somente ao POST de lead novo, nunca para sobrescrever oportunidade existente.

`mapeamento.campanhas` das integrações de anúncios aceita o legado string ou objeto `{"nome":"Campanha livre","parceiro":"49","objetivo":"Contato"}` por ID. Vale também na atribuição web com plataforma/conta compatíveis. Precedência: campanha por ID, parceiro da plataforma, interpretação legada do nome. `mapa_campos.objetivo` aponta para campo textual. O nome recebido é preservado no campo campanha. Não inventar ID de campanha/conta ou alternativa.

## 233–234 — coleta e relatórios

O plano Clarity publica oito recortes diários. Recortes sem tentativa têm motivo: janela, cota local, cota remota ou orçamento de tempo. Novos recortes precedem retentativas; orçamento por projeto inclui reservas automáticas e manuais. Reservas não são prova de resposta HTTP. Planos diários anteriores ficam no histórico, limitado a 90 planos. A observação por três dias em 12 sites ainda precisa ocorrer.

Relatórios normalizam caminhos na associação navegação/saída e no filtro SQL. `/pagina` e `/pagina/` referem-se ao mesmo caminho. Isso corrige exclusões indevidas sem afirmar igualdade entre pageviews e saídas.

## 235 — contrato e operação

O contato aceito agenda processamento no servidor. A requisição pública não chama Google/Meta. O formulário reaproveita o POST e lê client_id e session_id dos cookies GA4 somente sob consentimento de medição. Não cria script nem chamada no carregamento. Eventos de materiais existentes permanecem separados. Contatos deixam de emitir generate_lead/Ads no navegador: **não implantar em produção até o adaptador Google e a meta de importação estarem prontos**.

Tabela `f3base_conversoes_servidor`: uma linha por record_id/destino (ga4 ou google_ads); sem payload pessoal, guarda estado, destino, timestamps e tentativas. Novo registro marcado é reconciliado se o hook falhar. O worker valida consentimento atual e snapshot, tráfego, prazo e identificadores. Supressão de tráfego de teste é padrão desta fila. GA4 exige IDs reais e janela de 72h. Ads exige gclid/gbraid/wbraid, order_id=record_id, data ISO com fuso, valor 0 BRL no contrato atual. Meta usa fila existente, Lead e event_id compartilhado com Pixel; configuração deve permitir ambos. Revogação impede novos envios.

### Adaptador de propriedade do Google

Filtro PHP `f3base_conversoes_adaptador($adapter, $destino, $contrato)`; contrato `site-conversion-delivery/1.0.0`. O objeto fornece `capabilities()` (somente leitura local) e `send(array $payload)` (somente worker). Capabilities: contract exato, ready booleano, destination_ref não vazia até 191 caracteres. Mudança de destino bloqueia a fila. O Core não armazena segredo Measurement Protocol nem credenciais Ads.

Payload comum: record_id, event_id, occurred_at. GA4: measurement_id, client_id, session_id, timestamp_micros, event_name=generate_lead. Ads: click_ids, order_id, ad_user_data=GRANTED, value, currency. O Google deve conferir propriedade/destino, consentimento, formato, validade dos cliques e resultado individual antes de confirmar entrega. Resposta: `{"status":"entregue"}`, `{"status":"recusado","non_delivery_proven":true,"retry_after":3600}` ou `{"status":"incerto"}`. Não confirmar entrega por mera aceitação HTTP de lote. Timeout/exceção/resposta ambígua ficam incertos e nunca repetem automaticamente. Até dez tentativas apenas com prova de não entrega; sem adaptador fica bloqueado. Este contrato é implementado no Core, **ainda não implementado pelo Google 0.12.0**.

### Consulta e recuperação administrativa

`f3base/conversoes-entregas-ler {"record_id":"<32 hex>"}` consulta somente o diário local. `f3base/conversoes-recuperar {"record_id":"<32 hex>","confirmar":false}` simula. Para registros históricos sem diário, informe `nao_entregues_confirmados` com destinos cuja ausência foi comprovada externamente. `confirmar:true` apenas agenda. Nunca repete entregue/incerto; Meta até 7 dias, GA4 até 72h, Ads até 90 dias (também clique, quando conhecido). Prazos menores do fornecedor prevalecem. A fila Meta mantém suas restrições preexistentes de deduplicação e elegibilidade; a simulação não garante aceitação externa.

As duas abilities exigem manage_options. Leitura de ajuda não chama fornecedor. Instalação cria tabela idempotente; dados da base são preservados. Backup inclui banco, diário e guarda operacional. Restaurar banco antigo pode apagar provas de entrega: suspender execução e reconciliar fornecedores antes de retomar. Reversão de arquivos não desfaz envio externo. Eliminação do contato cancela entradas; uninstall preserva este diário de deduplicação.

## Limites de aceite

Provas locais usam WordPress real com transportes sintéticos. Não equivalem a aceitação Pipedrive/Meta/GA4/Ads, Android WebView, Instagram, três dias de Clarity nem reconciliação CTO de 14–19/10. O dono/Datta precisa configurar importação Ads como única principal de Contatos e coordenar o desligamento das antigas ações. Nenhum acompanhante foi modificado nesta entrega.
