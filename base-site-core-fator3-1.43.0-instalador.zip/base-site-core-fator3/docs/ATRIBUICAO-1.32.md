# Origem comercial e analítica — Core 1.32.0

O histórico mantém primeiro toque, último toque e origem da sessão. A apresentação comercial comum usa a sessão paga da captura quando há evidência coerente de campanha ou anúncio e publicidade permitida. Guarda `atribuicao_analitica` e `atribuicao_comercial_procedencia` no snapshot da apresentação; não reescreve primeiro toque, sessão nem relatórios históricos. Confira os nomes exatos no snapshot retornado.

Retorno orgânico, origem parcial, conflito de plataformas ou falta de permissão preservam o modelo configurado, com motivo. Não combinar campanha da primeira visita com anúncio de outra sessão. Campanha traduzida por mapa preserva ID e valor original; e-mail, Slack e Pipedrive usam a mesma projeção congelada, com redução quando houver negativa posterior.

`li_fat_id` válido ou UTM paga coerente do LinkedIn identifica a plataforma; não fornece por si só campanha, anúncio ou conta. UTMs orgânicas do LinkedIn permanecem orgânicas. Macros não substituídas têm cobertura explícita. Identificadores simultâneos incompatíveis geram conflito, sem inventar prioridade. IDs devem ser tratados como strings.

Conversão web LinkedIn é enviada após captura aceita; o clique que abre o formulário não é uma conversão de formulário. Lead Sync nativo é outro método de captura e não fabrica jornada web.
