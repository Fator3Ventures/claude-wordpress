> Versão atual 1.39.0, contrato administrativo 8.4.0. Consulte [RELEASE-1.39.0.md](RELEASE-1.39.0.md) e [AGENTES-1.39.0.md](AGENTES-1.39.0.md) para alterações 230–235 e bloqueios de aceite. Seções anteriores permanecem referência histórica.

> Atualização 1.37.0: consulte RELEASE-1.37.0.md e PIPEDRIVE-1.37.md; base direta 1.36.0, contrato administrativo 8.2.0. Evidências atuais no relatório externo; provas históricas abaixo mantêm seu escopo original.

> Atualização vigente: Core 1.36.0. Leia RELEASE-1.36.0.md e CONVERSOES-SDK-1.36.md. Configuração administrativa 8.1.0 e estrutura 1.35.0 preservadas.

# Operação e recuperação — Core 1.35.0

## Instalação e atualização

Instale o ZIP diretamente sobre a 1.33.0 ou em WordPress novo. Não instalar a 1.32.0 antes. Não há bloqueio numérico por versões dos acompanhantes, nem obrigação de retorno a versões anteriores. Tema e implantador têm responsáveis próprios.

Em WordPress novo são criados o esquema atual, os padrões, a gestão pelo canal e a pasta privada. Na atualização são preservadas escolhas, listas vazias, revisões/autoria das configurações existentes, filas, recibos, contatos e concessões. Subchaves ausentes são complementadas com registro separado; a origem de quem configurou não é substituída por padrão.

`f3base_instalacao` registra a versão alvo, ciclo, origem, início, etapas, falha, próxima tentativa e conclusão. `f3base_instalacao_historico` conserva o checkpoint anterior por hash. A base 1.33.0 usa `f3base_release_1310`: o atualizador lê essa evidência sem executar o instalador antigo e preserva o corte de coleta. Nenhum conversor anterior à base é exigido.

O agendamento reconhece a versão alvo mesmo quando a base estava concluída. Duas execuções competem pela mesma reserva; cada gravação exige a posse e o checkpoint esperado. Falha de SQL, estado malformado e persistência recusada não são tratados como site novo. Corrija a causa; não apague marcadores nem chame inicializadores privados.

A conclusão das etapas aguarda uma passagem posterior, após pelo menos 60 segundos, para confirmação do executor. A prontidão das estruturas de captura é independente dessa confirmação administrativa; não bloquear contato válido apenas pela espera. Uma estrutura realmente ausente recusa a captura com diagnóstico específico. Upgrade não reaplica regras do servidor somente porque a versão mudou.

Leia Saúde/Operação e `f3base/executar-pendentes` para as tarefas elegíveis. Backoff e trava continuam obrigatórios. O GET público agenda quando necessário, sem executar DDL. Leitura de diagnóstico não roda a migração.

No MCP 0.23.0, instalação nova usa upload inativo e ativação explícita; confira em outra requisição. Repetir `plugins/activate` em plugin já ativo não prova que inicialização faltante foi reparada. Não prepare estado privado para contornar falha do instalador MCP.

## Cron e evidência

`cli`, `http_cron` e `manual` têm últimas passagens e contagens independentes. `cron_servidor_ativo` indica CLI observado nas últimas duas horas, inclusive CLI manual; não comprova o crontab. O diário preserva horários UTC, cobertura e resultados. Consulte CRON-DIAGNOSTICO-1.31.md. A tarefa de atualização só executa trabalho Core.

## Pasta privada e servidor

A raiz deve ficar fora das raízes públicas conhecidas. Instalação prepara e prova escrita/leitura; diagnóstico distingue pasta pronta, criável ou indisponível. Aliases da hospedagem exigem conferência externa. Não exponha anexos ou documentação por uma regra de servidor inadequada. A proteção HTTP dos documentos depende da configuração Apache/Nginx; o canal documental autenticado continua disponível.

Cache HIT e proteção do diretório são provas diferentes. A sonda de artefato considera HTML e PHP compatíveis do WP Super Cache, sem executar PHP de disco. Leia a evidência vigente de `cache.tokens` e `artefato_cache`; consulta de saúde não produz uma nova prova HTTP. Aplicar/remover regras de servidor é operação explícita com revisão e verificação própria.

## Recuperação coordenada

A barreira Core vive fora do banco e do plugin em `wp-content/f3-core-state/`. Todos os executores precisam compartilhar os arquivos de coordenação. Preserve essa pasta durante restauração; não substitua a guarda atual por uma cópia antiga.

1. Leia `f3base/operacao-recuperacao-ler` e a geração vigente.
2. Use `f3base/operacao-recuperacao` com `acao:preparar` e `geracao_esperada`. Aguarde a drenagem confirmada.
3. Prepare os demais escritores, incluindo MCP e Google, pelos contratos próprios. Pausar Core não pausa acompanhantes.
4. Restaure somente um conjunto coerente de banco, arquivos privados e chaves, preservando a guarda atual. Reconcilie efeitos externos; restauração local não desfaz mensagens ou negócios remotos.
5. Retome explicitamente com a geração esperada e `reconciliacao_confirmada:true`. Estados incertos e filas suspensas exigem conciliação, sem repetir criação externa no escuro.

Sentinela ausente ou inválida exige a operação de recuperação apropriada e suas precondições, sem simular arquivo vazio. Desinstalação preserva o acervo. Segredo indecifrável exige recadastro no painel; não há fallback para texto aberto. Não restaurar banco antigo sobre novos contatos para reverter a versão.


## Complementos vigentes

Configuração LinkedIn por integração e troca dedicada: LINKEDIN-LEAD-SYNC.md. Correções de operação e retenção: CORRECOES-OPERACIONAIS-1.34.md. Matriz de bancada atual: MCP 0.23.0 / Google 0.10.0 / LinkedIn 0.2.0 / Meta 0.2.0. Leia RELEASE-1.35.0.md antes de atualizar ou reverter.


## Alterações 1.35.0

Leia CONVERSOES-CONTEUDO-1.35.md. Instalação nova ou base 1.34.0; mínimos WP 7.1.2/PHP 8.3.6 64 bits. Contrato administrativo 8.1.0; SDK 1.0.0 fechado sem material. Reserva editorial adaptativa, equivalência Slack por blocos exibidos, rótulos Meta em texto CRM e tela de conexões corrigida. Migração de reservas e suspensão de Lead legado de material; sem reenvio ou correção retroativa.
