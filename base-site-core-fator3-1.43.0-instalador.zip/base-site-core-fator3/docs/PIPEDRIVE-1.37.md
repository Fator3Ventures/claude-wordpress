> Core 1.38.0: links e texto opcional WhatsApp em WHATSAPP-1.38.md complementam este guia.

# Pipedrive — regras comerciais da 1.37.0

Este guia rege os Pedidos core 226(a–h) e prevalece sobre os exemplos históricos de PIPEDRIVE.md. Contrato administrativo 8.2.0; configurações em f3base_pipedrive. Não há novo token, option, ability, tabela ou coluna. Os catálogos da conta continuam obrigatórios. A integração e a criação de atividades permanecem desligadas por padrão; a atualização preserva escolhas anteriores.

## Configurar e conferir

Use Contatos → Integrações → Pipedrive como administrador. Consulte a prévia privada f3base/pipedrive-previa com record_id sintético antes da entrega. Ela é local, não consulta o fornecedor e não cria atividade. Configuração por ability exige manage_options, leitura da revisão atual, simulação e escrita com a mesma revisão; não reutilize revisão vencida. Consulte dados/configuracao-schema.json e dados/abilities-*.json para os argumentos completos.

Os exemplos abaixo são deltas de configuração, não credenciais ou catálogo real. Use mescla tipada ou preserve as demais propriedades ao salvar. Não grave os exemplos literalmente na conta.

```json
{
  "modelo_titulo": "{empresa} – {unidade}",
  "mapa_servicos_formularios": {"meta:123": "89"},
  "mapa_servicos_campanhas": {"google:456": "90"},
  "atividade_canais": {
    "whatsapp": {"tipo": "whatsapp", "assunto": "WhatsApp"},
    "email": {"tipo": "email", "assunto": "E-mail – primeiro contato"},
    "task": {"tipo": "task", "assunto": "Conferir contato"}
  },
  "atividade_janela": {
    "fuso": "America/Sao_Paulo", "dias": [1,2,3,4,5],
    "inicio": "08:00", "fim": "19:00", "minutos": 60, "retomada": "09:30"
  }
}
```

## Título e empresa — 226(a–b)

Modelo explícito sem {site} não acrescenta host. Variáveis: {empresa}, {nome}, {servicos}, {formulario}, {site}, {unidade}. {unidade} é o rótulo da alternativa selecionada no catálogo confirmado da mesma conta. Modelo vazio mantém o padrão com host, inclusive ao reduzir títulos longos. A marca de teste e o teto de 255 caracteres permanecem. Oportunidades existentes não são retituladas.

{empresa} usa o nome da pessoa quando a empresa é inválida. Não buscar, criar ou vincular nova organização com vazio, menos de três letras, e-mail, URL, telefone, nome igual ao da pessoa ou resposta da lista empresas_invalidas. Comparação ignora caixa, acentos e espaços repetidos. Padrão: não tem, nenhuma, autônomo, sim, não, x, -, particular, pessoa física, pf, mei e ainda não. A lista é configurável. Empresa e organização já existentes não são apagadas; a resposta original permanece no contato/nota.

## Respostas, serviço e identificadores — 226(c–d, g)

mapa_campos.respostas_formulario recebe a chave real de um campo comercial de texto longo (field_type=text). Produz todas as respostas escalares disponíveis em linhas “Pergunta: resposta”, incluindo nome e demais papéis, booleanos e respostas vazias. Usa o rótulo e as alternativas do snapshot; sem rótulo histórico, informa a indisponibilidade. Arquivos privados ficam fora desse campo. Limite do catálogo é respeitado, com diagnóstico de truncamento. A nota completa continua existindo.

Formulário do site usa campos_snapshot; Meta e LinkedIn usam o catálogo nativo preservado; Google guarda column_name do payload e nomes legíveis para campos padrão. Complemento tardio de lead atualiza esse campo com as respostas iniciais e adicionais e acrescenta a nota. Complemento de negócio existente acrescenta nota, preservando seus campos e atividades anteriores.

mapa_campos.servico continua exigindo seleção múltipla (set). Precedência: serviço respondido/fixo e mapa_servicos existente; depois mapa_servicos_formularios; por fim mapa_servicos_campanhas. As novas chaves usam origem:ID, com origem meta, google ou linkedin, e valores são IDs textuais de alternativas existentes na conta. Não há IDs reais embutidos no plugin. Sem correspondência em captura nativa/campanha, o campo fica vazio e Qualidade informa “serviço não mapeado” com formulário/campanha, também no retorno ao Slack. Mapa inexistente não é licença para deduzir serviço pelo anúncio.

mapa_campos.lead_nativo_id é a chave real de um campo textual para o ID do lead Meta, Google ou LinkedIn. O campo legado campo_meta_id continua como fallback exclusivo de Meta quando o novo papel não está mapeado. Não escreva dois papéis no mesmo campo. Os tipos e alternativas são validados contra o catálogo; a chave do novo campo deve ser fornecida pelo responsável Pipedrive.

Na 1.36.0, anúncio e ID nativo não eram garantidos em toda entrega: dependiam do payload, consentimento/política, mapeamento e destino disponível; o mapa dedicado legado de ID era Meta. A 1.37 registra anúncio informado, ausência no payload, lead orgânico ou omissão pela política; não inventa o anúncio. Sem IDs completos e payloads históricos, não é possível determinar a causa dos dois casos Apex de 10/10. A inclusão de diagnóstico novo não reprocessa esses contatos.

## primeira atividade do lead e expediente — 226(e)

Com atividade habilitada, nova oportunidade recebe WhatsApp para celular elegível, E-mail quando só há e-mail válido e tarefa Conferir contato sem ambos. BR exige DDD válido e nono dígito; PT usa faixa móvel. Outros E.164 são elegíveis pela sintaxe; isso não prova WhatsApp ativo ou alcançabilidade. Tipos e assuntos são configuráveis e os tipos precisam existir na conta. atividade_tipo legado permanece armazenado; novas primeira atividade do lead usam atividade_canais.

O prazo parte do instante de entrada do contato no Core, não do despacho nem da data declarada pelo fornecedor. Soma 60 minutos dentro do expediente padrão de segunda a sexta, 08:00–19:00, America/Sao_Paulo. Se não couber, usa 09:30 do próximo dia útil. Antes da abertura em dia útil, usa 09:30 desse dia. Não há calendário de feriados. Segundos são arredondados para o minuto seguinte, sem antecipar o prazo; envio à API usa data e HH:MM UTC. Exemplo: sexta 18:00 → sexta 19:00; sexta 18:01 → segunda 09:30. Fuso, dias, janela, minutos e retomada são configuráveis e validados.

O plano é persistido antes do POST e reaproveitado na retomada; atividades antigas não são recalculadas. A confirmação por releitura confere vínculo, tipo, assunto e prazo. Listagem para reconciliação inclui atividades concluídas, evitando criar outra após uma resposta perdida.

## Oportunidade existente — 226(f)

Após identificar e reler a pessoa por identificadores, consulta negócios abertos e leads não arquivados, com paginação completa. Um negócio aberto tem precedência: recebe nota e, com atividades habilitadas, task “Reenvio de formulário”, sem novo lead. Sem negócio, um lead aberto de qualquer origem recebe nota, preservando título, campos anteriores e atividades. Mais de um negócio ou mais de um lead elegível exige revisão; não escolhe arbitrariamente. O lead próprio de uma criação incerta é reconciliado pelo marcador antes de qualquer nova criação.

Isso não funde pessoas, não apaga oportunidades alheias e não amplia provas de autoria para exclusão. Instalações independentes não compartilham trava; concorrência entre sites continua requerendo reconciliação quando a conta ainda não reflete a outra gravação.

## Retorno à thread — 226(h)

Entregas iniciadas sob a 1.37.0 geram uma parte durável na fila Slack do aviso original: link da oportunidade e prazo local com fuso, confirmado somente após releitura da atividade. Se a atividade não foi confirmada, o texto identifica o prazo como previsto; se foi dispensada, explica o motivo. Não anuncia confirmação comercial a partir de mera tentativa HTTP.

Exige aplicativo Slack, principal confirmada e mesmo destino. Incoming Webhook não oferece a confirmação da thread e resulta em thread_exige_aplicativo_slack. Sem aviso inicial, aguarda; espera pendente é limitada a 144 observações. Respeita marca/supressão de teste, limpeza, destino alterado, eliminação do contato, cadência, 429 e resultados incertos. Repetir o worker conserva a mesma chave. Não reenvia histórico entregue antes da nova versão. O retorno não faz chamada direta fora da fila existente.

## Recuperação e aceite

Use as operações privadas de fila/reconciliação já publicadas; consulte o journal e releia a referência remota antes de repetir efeito incerto. Restaurar arquivos não desfaz leads, notas, atividades ou mensagens. Backup deve incluir banco e guarda operacional; preservar filas e segredos, nunca reinstalar apagando dados. Nenhuma migração de tabela nesta versão.

Homologação comercial real: exclusivamente CTOoffice/korvena.com.br, conforme autorização do dono. Deve ser coordenada pelo projeto Pipedrive com cookie/formulário de teste e homologacao=true temporário, conferência dos IDs/tipos/prazo na conta e remoção dos dados sintéticos pelo responsável. Site-Teste comprova instalação/documentação, não essa homologação. Conferir a hora exibida no fuso real do usuário Pipedrive, o catálogo e a thread antes da adoção na frota.

Referências oficiais: https://developers.pipedrive.com/docs/api/v1/Activities ; https://developers.pipedrive.com/docs/api/v1/Leads ; https://github.com/pipedrive/client-php/blob/master/docs/versions/v1/Model/ActivityPostObject.md . A documentação v2 expõe due_date/due_time; o contrato temporal UTC é documentado pelo SDK e deve ser conferido também no aceite real.
