# Catálogo Pipedrive pelo canal — pedido 193

Use `f3base/qualidade-catalogo-carregar`. `simular:true` verifica condições localmente, sem HTTP, consumo de cota ou escrita. Para carregar, envie `simular:false`. Exige conta Pipedrive verificada e usa a mesma credencial e orçamento da integração existente. Não cria pessoas, leads, negócios nem etapas.

O serviço comum à tela e ao MCP consulta `GET v2/pipelines` e `GET v2/stages`, com páginas de 100 itens e até seis páginas por lista em uma passagem, além dos limites de tempo/orçamento do adaptador. Cursores/geração intermediária ficam em `f3base_qualidade_estado.catalogo_preparo`. Quando incompleto, repita a execução; configuração/credencial/conta diferentes reiniciam a geração. Após uma geração completa, a próxima execução inicia atualização nova.

Somente um catálogo completo e consistente substitui `f3base_qualidade_catalogo`. Erro, 429, cursor repetido ou troca de conta preservam o snapshot anterior. Resposta: conta, instante, contagens, revisão, código, `completo`, `persistido`/`persisted` e `changed`. IDs permanecem strings. Ausência de indicador de atividade vira `active:null`; falso informado continua falso. Regras não podem usar funil/etapa comprovadamente inativos.

`f3base/qualidade-ler` com `incluir_catalogo:true` lê o snapshot sem rede, com prova de vinculação e última tentativa. `catalogo_disponivel:false` após trocar credencial/conta indica necessidade de verificar e recarregar; o conteúdo anterior não é apresentado como pertencente à nova conta.

A fixture 14725895/funil 1/etapas 3,23,24,25 integra somente os testes. Não há preset de cliente no plugin. Veja também QUALIDADE-META-1.29.md; a política vigente de autorização está em PUBLICIDADE-1.30.md.
