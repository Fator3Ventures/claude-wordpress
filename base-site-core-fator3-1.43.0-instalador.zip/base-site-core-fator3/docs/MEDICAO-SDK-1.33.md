# SDK público de medição — Core 1.33.0

Contrato entregue `site-measurement-context/1.0.0`, schema revision `1`. Produtor PHP implementado nesta versão; consumidor Google 0.8.6 ainda aguarda homologação conjunta. Os schemas instalados são normativos; as fixtures completas são respostas sintéticas, sem credenciais ou dados reais.

## Ajustes registrados entre o plano e o código

- O slot Meta contém `pixel_id` **e `server_pixel_id`**, pois o Core permite dataset CAPI diferente do Pixel do navegador. Vazio no segundo herda o Pixel no valor efetivo. O schema fechado deve aceitar ambos; não descartar o ID do servidor nem supor que são iguais.
- `policy` possui objetos fechados para consentimento, carregamento, testes, exclusões de audiência, coleta local e seleção de eventos. `destination_loading.enabled` controla estratégia de carregamento, não desativa o destino. A ausência do módulo tracking/consentimento desativa os slots; não há switch inventado para cada ID.
- `configured.fields` é a projeção física normalizada. Para slots com várias options, `persisted:true` significa ao menos uma presente; campos ausentes são `null`. Procedências diferentes produzem `mixed_provenance_<slot>`, com origem agregada desconhecida; não atribuir autoria única.
- `parameters` é um objeto de descritores (`type`, `required`, `minimum`, `maximum`, `max_length`, `enum`, `sanitization`). Limite nulo significa que este catálogo não declara um teto adicional. Mapas sem parâmetros saem como `{}`. Metadados de transporte estão documentados separadamente no catálogo; não são respostas livres de formulário.
- `destinations` é lista de objetos fechados; Meta pode ter registros `core_browser` e `core_server` para o mesmo evento lógico. Isso não cria duas conversões Core. `eligibility` declara exclusões, teto, limites, repetição e tratamento de importação.
- `capabilities()` devolve o mesmo envelope dos outros métodos. Erros mantêm `data:null`; `not_authorized` é reservado ao acesso por ability, que exige `manage_options`.

## Arquivos executáveis

| Arquivo em docs/ | Uso |
|---|---|
| schemas/measurement-capabilities.json | Descritor e erros |
| schemas/measurement-snapshot.json | Snapshot completo e erros |
| schemas/measurement-events-input.json | Entrada do catálogo; offset maior que zero também exige revisão no método |
| schemas/measurement-events.json | Catálogo paginado, parâmetros fechados e erros |
| fixtures/measurement/*.json | Respostas completas positivas e negativas |
| MEDICAO-EVENTOS-1.33.md | Catálogo legível e metadados de transporte |

Todos são acessíveis por `f3base/documentacao-ler`, com hash e paginação. Os JSONs de catálogo são gerados de `dados/eventos-comportamento-fonte.json`; TSV e instrumentação usam os mesmos nomes e parâmetros. Geradores estão no pacote de fontes/testes.

## Consumo PHP

Depois de `plugins_loaded`, confira classe, métodos, contrato, provider e capacidades. Não carregar arquivo privado nem comparar versão. Chame `snapshot()`, valide o envelope e schema; só então use o ID efetivo de um slot `configured`. Reler a revisão antes/depois da operação remota autorizada e antes de gravar vínculo. Se houver conflito, preserve o vínculo anterior.

Para obter o catálogo, passe `expected_revision` do snapshot desde a primeira página. Prossiga com `next_offset`, mantendo a revisão, até `complete:true`. Erro, ausência de progresso ou interrupção não autorizam usar um catálogo parcial como completo. A leitura não cria tags ou dimensões remotas.

```php
$context = F3Base_Medicao_Contexto::snapshot();
// Validar o envelope/schema antes de projetar os campos.
if ($context['ok']) {
    $page = F3Base_Medicao_Contexto::events(array(
        'limit' => 100, 'offset' => 0,
        'expected_revision' => $context['data']['events_revision'],
    ));
}
```

A comparação de revisões é otimista; não bloqueia writers ou filtros arbitrários. `scope:site_request` não garante o mesmo ID para todos os visitantes. `runtime_verified:false` e `remote_access_verified:false` nunca são convertidos em prova de entrega.

## Especificação de base com os ajustes acima

# Core 1.33.0 — contrato público de medição

Implementação 1 · 15/10/2026 · Proposta para implementação de CORE-01/02. As assinaturas e os exemplos abaixo não existem por consequência deste documento. A conclusão exige schemas exportados, fixtures e provas do produtor real.

## 1. Fronteira e descoberta

Contrato: **`site-measurement-context/1.0.0`**. Produtor: **`base-site-core-fator3`**. Capacidades: `measurement.context.read` e `measurement.events.read`. A configuração Core 7.1.0 entregue e o SDK GSC `search-console-reader/1.0.0` são contratos diferentes.

Ponto público PHP entregue, carregado pelo Core antes de concluir `plugins_loaded`:

```php
final class F3Base_Medicao_Contexto {
    public static function capabilities(): array;
    public static function snapshot(): array;
    public static function events(array $input = []): array;
}
```

São assinaturas de interface, não código copiável de implementação. O consumidor verifica `class_exists`, `is_callable` e descritor após `plugins_loaded`; não inclui arquivos do Core nem usa sua versão numérica para habilitar a integração. Dentro do próprio hook, adiar a descoberta até todos os callbacks de registro terem sido executados. Se o produtor não estiver disponível, o adaptador consumidor devolve `unavailable`; classe incompleta/contrato diferente gera `unsupported`.

`capabilities()` é leitura local do descritor implementado. `snapshot()` é uma fotografia sanitizada da configuração efetiva. `events()` pagina a declaração de eventos. Não consultam rede, criam estado, executam reparos, agendam tarefas ou concedem acesso remoto. Uma exceção de leitura torna o diagnóstico ilegível, sem acionar correção implícita.

A chamada PHP coopera entre plugins instalados e confiáveis; funciona em cron sem pessoa autenticada e não recebe ator livre. Isso não autoriza leitura de contatos ou uso de APIs. Leituras administrativas entregues `f3base/medicao-contexto-ler` e `f3base/medicao-eventos-ler` exigem `manage_options` e a autorização de transporte aplicável, usando os mesmos resultados e schemas. Não criar REST anônima para esse diagnóstico.

## 2. Envelope e estados

Todas as respostas do produtor usam `ok`, `code`, `contract`, `provider` e `data`. `contract` é a string completa acima. `data` é objeto quando `ok:true`, e `null` em falha. `message` é uma explicação sanitizada; consumidores decidem por `code`, nunca pelo texto. Nenhum erro devolve SQL, stack trace, cabeçalho de autorização ou conteúdo bruto de option.

| Código | Significado |
|---|---|
| `ok` | Leitura coerente concluída; ainda pode conter slots vazios/desativados |
| `unavailable` | Produtor ausente/não carregado; devolvido pelo adaptador do consumidor |
| `unsupported` | Contrato/capacidade/método/schema não suportado |
| `unreadable` | Não foi possível ler configuração/procedência indispensável; não significa slot vazio |
| `revision_conflict` | Entradas mudaram durante a fotografia ou continuação usa revisão antiga |
| `invalid_input` | Paginação/filtro/parâmetro fora do schema |
| `not_authorized` | Gate administrativo/transportador recusado; não fabricado pela leitura PHP de configuração pública |

`capabilities().data` contém `methods` (lista fechada dos três nomes), `capabilities` (as duas capacidades), `schema_revision` (string), `max_page_size:200` e referências documentais dos schemas. Disponibilidade não significa configuração pronta, credencial presente ou acesso remoto.

## 3. Schema do snapshot

`snapshot().data` contém os campos abaixo. Schemas de saída fecham objetos conhecidos para impedir exposição acidental; futuras extensões publicadas precisam ser aceitas explicitamente pelo adaptador. Alteração incompatível muda a versão principal do contrato.

| Campo | Tipo/regra |
|---|---|
| `revision` | String opaca não vazia, até 128 caracteres; igualdade exata, sem ordenação |
| `events_revision` | Revisão opaca do catálogo, até 128 caracteres |
| `observed_at` | UTC em RFC 3339; não participa da revisão |
| `scope` | `site_request`; fotografia deste site na requisição corrente, sem promessa de igualdade entre contextos com filtros dinâmicos |
| `emission_mode` | `nenhum`, `direto`, `gtm` ou `misto`, com a mesma semântica do tracking Core |
| `runtime_verified` | Sempre `false` nesta leitura; não houve observação do navegador |
| `remote_access_verified` | Sempre `false`; não houve consulta ao fornecedor |
| `policy` | Projeção declarativa sanitizada: carregamento, finalidades/regras de consentimento e exclusões de teste/404/editor pertinentes; não contém consentimento individual |
| `slots` | Objeto com `ga4`, `gtm`, `google_ads`, `meta`, `linkedin`, `clarity`; todos presentes |
| `warnings` | Lista de `{code,message}` sanitizados, sem alegar dupla entrega a partir de configuração estática |

Cada slot contém:

| Campo | Tipo/regra |
|---|---|
| `state` | `configured`, `empty`, `disabled` ou `invalid`; falha SQL impede o snapshot (`unreadable`), em vez de produzir um slot vazio |
| `configured` | `{persisted:boolean, fields:object}`; projeção segura do valor físico normalizado; `fields:null` quando a option não existe |
| `effective` | `{fields:object}`; projeção dos mesmos valores realmente usados pelo tracking na requisição |
| `provenance` | `{recorded_origin:string|null, channel:string|null, recorded_at:string|null, record_status:string, effective_source:string, changed_by_filter:boolean|null}`; sem identidade da pessoa ou histórico integral |
| `emission` | `{routes:array, transport:string|null, configuration_ready:boolean, reasons:array}`; descreve possibilidade por configuração, sem afirmar entrega |

`recorded_origin`/`channel` preservam rótulos públicos conhecidos; ausência de registro é `null`, sem inventar origem de fábrica. `recorded_at` usa RFC 3339 quando conhecido. `record_status` distingue `confirmed`, `unconfirmed`, `unknown` e `default`: uma origem registrada, mas não vinculada à revisão atual, não é autoria comprovada do valor atual. `effective_source` é `configured`, `default`, `filtered` ou `unknown`. A comparação entre valor físico e efetivo, sozinha, não identifica um filtro: normalização e padrão também podem explicar a diferença. Só marcar `changed_by_filter:true` com evidência no caminho de resolução; não inventar autor do filtro.

Estados não substituem causas: um destino explicitamente desativado é `disabled` mesmo com ID preenchido, preservando o ID e o motivo. Sem desativação explícita, ID obrigatório vazio é `empty`; forma inválida é `invalid`; configuração utilizável é `configured`. Se não há switch próprio do destino, não inventar um. Falha na leitura indispensável não é `disabled`.

### Campos públicos dos slots

| Slot | `fields` permitido |
|---|---|
| `ga4` | `measurement_id` |
| `gtm` | `container_id` |
| `google_ads` | `conversion_id`, `conversion_label` |
| `meta` | `pixel_id`, `server_pixel_id` |
| `linkedin` | `partner_id`, `conversion_id` |
| `clarity` | `project_id` |

IDs e rótulos são strings; vazio continua `""`, diferente de ausência física. Aplicar limites, forma e sanitização da fonte Core, sem criar formatos de fornecedor não documentados. Valor inválido potencialmente sensível não é ecoado: `null` no campo exposto, `state:invalid` e motivo de validação. Não devolver o objeto Google Ads/Meta/LinkedIn/Clarity completo. O token Clarity, token CAPI, segredo de webhook, resposta de lead e identificador de visitante nunca pertencem ao contrato.

`routes` admite `core_browser`, `gtm_container`, `core_server`. Sua presença significa configuração de caminho. `gtm_container` para um slot de destino exige mapeamento conhecido; só existir um contêiner não prova que contenha GA4, Meta ou LinkedIn. A leitura local não inspeciona o contêiner remoto. `transport` preserva o modo público do destino quando aplicável, inclusive Meta; não infere que GA4 suporte deduplicação de envio browser/servidor.

### Revisão e concorrência

Calcular a revisão a partir de uma serialização canônica dos valores permitidos configurados/efetivos, procedência relevante, políticas/caminhos e revisão do catálogo. Excluir horário de consulta, logs e dados individuais. Alteração somente por filtro precisa mudar a revisão. Não usar revisão da option física como substituto de toda a fotografia.

Ler/verificar as entradas ao redor da projeção. Se as duas leituras divergirem, devolver `revision_conflict` sem dados utilizáveis. Isso é verificação otimista: não promete bloquear writers nem resolver filtros não determinísticos. O consumidor relê antes/depois da descoberta remota e antes de persistir seu próprio binding; alteração recusa a confirmação sem apagar o vínculo anterior. Registrar a revisão usada permite identificar qual configuração fundamentou o vínculo.

Não persistir snapshot por efeito de leitura. Cache local opcional só pode ser limitado à requisição e não pode ocultar a releitura exigida. Configurações filtradas por contexto são identificadas pelo escopo; não anunciar “o ID de todos os visitantes” quando só se observou uma requisição administrativa.

## 4. Catálogo de eventos

Entrada de `events()`:

| Campo | Regra |
|---|---|
| `limit` | Inteiro 1–200; padrão 100 |
| `offset` | Inteiro ≥0; padrão 0 |
| `expected_revision` | String opaca; obrigatória quando `offset>0` |

Recusar propriedades não previstas. Ordenação estável pelo nome lógico. `data` contém `revision`, `total`, `items`, `next_offset` (inteiro ou `null`) e `complete` (booleano; fim deste catálogo, não de uma coleta remota). Revisão diferente recusa a página inteira. O snapshot aponta para a mesma `events_revision`.

Cada item declara `name`, `meaning`, `trigger`, `purpose`, `emitter`, `parameters`, `destinations`, `conversion_role` e `eligibility`. `conversion_role` distingue `none`, `form_observation` e `lead_conversion`; não confunde a observação do formulário com a regra de criação de lead. `parameters` é um mapa fechado: tipo, obrigatório, tamanho/faixa/enum e sanitização documentados. `destinations` contém o destino, nome mapeado, caminho de emissão e regra de consentimento. `eligibility` declara exclusões e limites, inclusive testes, repetição e 404/editor. Tudo deve corresponder ao código efetivamente entregue, não a uma lista ideal de futuras capacidades.

Reutilizar `dados/eventos-comportamento-fonte.json` como fonte, completando as declarações que hoje estão nos emissores de leads/formulários/Web Vitals. Gerar JSON, TSV e ajuda coerentes. O catálogo não recebe dados reais nem exemplifica respostas preenchidas. Identificadores técnicos e códigos fechados de formulário são permitidos; e-mail, telefone, nome, campo preenchido e texto livre não são parâmetros analíticos de formulário.

Uma importação Lead Ads/Lead Sync não se torna evento de navegador, não recebe sessão fabricada e não presume consentimento. A regra comercial existente pode criar a intenção de entrega adequada; não fabricar uma segunda conversão analítica para uniformizar nomes. Publicar o catálogo não cria tags, dimensões ou eventos-chave nas contas remotas.

## 5. Exemplo parcial e falhas

Este exemplo mostra somente o slot GA4 e os campos relevantes. Não é uma resposta completa para validação do schema; as fixtures da implementação incluirão os seis slots e todos os campos obrigatórios. IDs são sintéticos.

```json
{
  "ok": true,
  "code": "ok",
  "contract": "site-measurement-context/1.0.0",
  "provider": "base-site-core-fator3",
  "data": {
    "revision": "fixture-r2",
    "scope": "site_request",
    "runtime_verified": false,
    "remote_access_verified": false,
    "slots": {
      "ga4": {
        "state": "configured",
        "configured": {"persisted": true, "fields": {"measurement_id": "G-TEST0001"}},
        "effective": {"fields": {"measurement_id": "G-TEST0002"}},
        "provenance": {
          "recorded_origin": "ability",
          "channel": "mcp",
          "recorded_at": null,
          "record_status": "confirmed",
          "effective_source": "filtered",
          "changed_by_filter": true
        },
        "emission": {"routes": ["core_browser"], "transport": null, "configuration_ready": true, "reasons": []}
      }
    }
  }
}
```

`recorded_origin` preserva o vocabulário público de procedência; o exemplo usa origem `ability` e canal `mcp`, com valores sintéticos e sem identidade do autor.

Falha de leitura completa:

```json
{"ok":false,"code":"unreadable","contract":"site-measurement-context/1.0.0","provider":"base-site-core-fator3","data":null,"message":"Não foi possível ler a configuração de medição."}
```

Slot vazio é resposta `ok:true` com `state:empty`; slot desativado é `ok:true` com `state:disabled`. Não convertê-los em ausência do Core. Revisão concorrente usa `ok:false`, `code:revision_conflict`, `data:null`, preservando o binding consumidor existente.

## 6. Entrega e prova

No pacote: contrato/guia de consumo, schemas JSON completos para descritor, snapshot, entrada/saída de catálogo e erros; fixtures sintéticas compatíveis com esses schemas; catálogo gerado e sua revisão. Schemas serão artefatos versionados, não exemplos de texto sem validação.

| Fixture/prova | Resultado exigido |
|---|---|
| Ausente / classe incompleta / contrato diferente | `unavailable` ou `unsupported`; consumidor continua com configuração explícita |
| Padrão / valor físico / vazio / desligado / inválido | Estados e procedência próprios, sem campos privados |
| Filtro e normalização | Mesmo valor efetivo do tracking; distinguir causas quando comprováveis |
| SQL falha / erro de projeção | `unreadable`; nenhuma gravação/reparação e nenhum valor presumido |
| Duas revisões / filtro instável / paginação velha | `revision_conflict`; sem persistir vínculo obsoleto |
| Leitura repetida sem mudança | Revisão idêntica apesar do horário diferente |
| Catálogo versus PHP/JS/minificado | Eventos e parâmetros reais declarados; consentimento e exclusões testados no navegador |
| Core + Google reais | I01: dois caminhos antigos substituídos pelo mesmo adaptador; sem fallback privado, sem concessão implícita |

A16–A20 do plano comprovam o produtor. I01 comprova a integração. Nenhum dos dois comprova, por si, recebimento dos eventos pela conta remota. A leitura GSC existente, os grants Google e a escolha comercial LinkedIn permanecem independentes deste SDK.

## Envelope administrativo

As abilities aceitam os campos externos de transporte `success`, `request_id`, `result_contract`, `error_code`, `retryable` e `conflict` adicionados pelo contrato MCP vigente. Seus schemas próprios são `schemas/measurement-ability-snapshot.json` e `schemas/measurement-ability-events.json`. Os objetos `data`, slots, policy e parâmetros continuam fechados. Os métodos PHP e os quatro schemas base não contêm essa decoração. Não entregar a resposta decorada de uma ability ao consumidor PHP como se fosse o envelope bruto.

O leitor documental aceita arquivos instalados de até 2 MiB, com até 200 linhas por página, incluindo os schemas completos de configuração e abilities. Não autoriza caminhos fora do catálogo.
