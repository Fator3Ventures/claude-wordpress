# Fator3 Site Core 1.36.0

Instalação nova ou atualização direta 1.35.0. WordPress 7.1.2/PHP 8.3.6 de 64 bits. Leia docs/DOCUMENTACAO.md. SDK de medição 1.0.0 preservado; SDK opcional site-conversion-purposes/1.0.0 para finalidades. Contrato administrativo 8.1.0.
