<?php
/** Compatibility from the immediately preceding release. Remove ability aliases after 1.42. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Legado {
    public static function iniciar(): void {
        if(($_GET['integracao']??'')==='f3base_c0'){$_GET['integracao']='f3base_email_novo_lead';}
    }
    public static function configuracao(array $v): array {
        $brand=$v['marca']??'';$legacy=array('remetente'=>'korvena@korvena.net.br','smtp_host'=>'smtp.dreamhost.com','smtp_porta'=>587,'smtp_seguranca'=>'tls','smtp_usuario'=>'korvena@korvena.net.br','nome_exibicao'=>'Anderson','contato'=>'Se preferir adiantar, é só me chamar no WhatsApp, no (11) 93620-3481.','whatsapp_url'=>'https://wa.me/5511936203481?text='.rawurlencode('Olá, Anderson. Recebi seu e-mail da '.$brand.'.'),'assinatura'=>"Anderson Valtriani\n".($brand==='Korvena'?'Korvena Desenvolvimento de Sistemas':$brand),'texto_unidade'=>$brand==='Korvena'?'A Korvena desenvolve e moderniza sistemas com times seniores, por projeto fechado ou com profissionais alocados no time do cliente.':($brand==='CTO Office'?'A CTO Office organiza a área de tecnologia junto com a empresa: define prioridades, arquitetura, processos e quem executa, sem a necessidade de contratar um CTO em tempo integral.':'') );
        return array_replace(F3Base_Email_Novo_Lead::definicao()['padrao'],$legacy,$v);
    }
    public static function migrar(): bool {
        global $wpdb;
        if(get_option('f3base_email_migracao_142')==='concluida'){return true;}
        // Installation coordinator holds recovery/upgrade locks. No worker may run during this step.
        foreach(array('f3base_c0'=>'f3base_email_novo_lead','f3base_c0_cota'=>'f3base_email_novo_lead_cota') as $old=>$new){$v=get_option($old,null);if($v!==null&&get_option($new,null)===null){$v=$old==='f3base_c0'?self::configuracao((array)$v):$v;if(!F3Base_Options::migrar_email_opcao($new,$v)){return false;}}}
        $old='f3base_c0_smtp_senha';$new='f3base_email_novo_lead_smtp_senha';$cipher=get_option($old,'');
        if($cipher!==''&&get_option($new,'')===''){
            $bytes=base64_decode(substr($cipher,strlen(F3Base_Segredos::PREFIXO)),true);if(!str_starts_with($cipher,F3Base_Segredos::PREFIXO)||!$bytes||strlen($bytes)<40){return false;}
            try{$clear=sodium_crypto_secretbox_open(substr($bytes,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),substr($bytes,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),F3Base_Segredos::chave($old));}catch(Throwable $e){return false;}
            if(!is_string($clear)){return false;}$encoded=F3Base_Segredos::cifrar($new,$clear);if(!F3Base_Options::migrar_email_opcao($new,$encoded)||F3Base_Segredos::abrir($new)!==$clear){return false;}
        }
        $oldTable=$wpdb->prefix.'f3base_c0';$newTable=F3Base_Email_Novo_Lead::tabela();$exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($oldTable)));
        if($exists){if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($newTable)))){return false;}if($wpdb->query($wpdb->prepare('RENAME TABLE %i TO %i',$oldTable,$newTable))===false){return false;}}
        $leads=F3Base_Leads_Repositorio::tabela();$queue=F3Base_Pipedrive_Fila::tabela();
        foreach(array($leads=>array('dados','c0_intencao','email_novo_lead_intencao'),$queue=>array('journal','c0_checkpoint','email_novo_lead_checkpoint')) as $table=>$fields){
            if(!$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))){continue;}
            list($column,$from,$to)=$fields;$sql=$wpdb->prepare("UPDATE %i SET %i=JSON_REMOVE(JSON_SET(%i,%s,JSON_EXTRACT(%i,%s)),%s) WHERE JSON_VALID(%i) AND JSON_CONTAINS_PATH(%i,'one',%s) AND NOT JSON_CONTAINS_PATH(%i,'one',%s)",$table,$column,$column,'$.'.$to,$column,'$.'.$from,'$.'.$from,$column,$column,'$.'.$from,$column,'$.'.$to);if($wpdb->query($sql)===false){return false;}
        }
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($newTable)))){
            $rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i',$newTable),ARRAY_A);
            foreach($rows as $row){$key=hash('sha256',get_current_blog_id().'|'.$row['conta'].'|'.$row['lead_id'].'|email_novo_lead');if($key===$row['chave']){continue;}
                $payload=$row['payload'];if($payload!==''){$v=F3Base_Contato_Comunicacao::abrir($payload);if(!$v){return false;}$v['config']=self::configuracao($v['config']??array());if(isset($v['ctx']['c0_service_ids'])){$v['ctx']['email_novo_lead_service_ids']=$v['ctx']['c0_service_ids'];unset($v['ctx']['c0_service_ids']);}if($row['estado']==='pendente'){unset($v['message']);}$payload=F3Base_Contato_Comunicacao::cifrar($v);}
                if($wpdb->update($newTable,array('chave'=>$key,'payload'=>$payload),array('chave'=>$row['chave']))===false){return false;}
            }
        }
        wp_clear_scheduled_hook('f3base_c0_processar');
        // Old values are retained only as rollback pre-images, never read by current dispatch.
        if(!F3Base_Options::migrar_email_metadados(array('f3base_c0'=>'f3base_email_novo_lead','f3base_c0_cota'=>'f3base_email_novo_lead_cota','f3base_c0_smtp_senha'=>'f3base_email_novo_lead_smtp_senha'))){return false;}
        return F3Base_Options::migrar_email_opcao('f3base_email_migracao_142','concluida');
    }
}
