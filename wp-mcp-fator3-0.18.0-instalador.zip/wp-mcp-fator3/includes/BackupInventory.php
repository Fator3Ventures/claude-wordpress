<?php
/** Bounded import of all known backup sources. Deleted identities never re-enter. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class BackupInventory {
    public static function advance(int $limit=200): array {
        $key='backup-inventory-018';$s=StateStore::get('migration',$key);
        if(!$s||!empty($s['complete']))$s=['stage'=>0,'after'=>'','complete'=>false,'examined'=>0,'imported'=>0,'blocked'=>[]];
        $dirs=[StateStore::directory('backup-index'),StateStore::directory('backups'),LegacyStorage::root(),LegacyStorage::root().'/nomeados'];
        $left=$limit;$deadline=microtime(true)+3;
        while($s['stage']<4 && $left>0 && microtime(true)<$deadline){
            $stage=$s['stage'];$dir=$dirs[$stage];
            if(is_link($dir)){$s['blocked'][]=['source'=>$stage,'reason'=>'linked_directory'];$s['stage']++;$s['after']='';continue;}
            $files=[];
            if(is_dir($dir))foreach(new \FilesystemIterator($dir,\FilesystemIterator::SKIP_DOTS) as $f){
                $n=$f->getFilename();$pattern=$stage<2?'/^[a-f0-9]{64}\.php$/D':'/^(?:db)?[a-f0-9]{16,64}\.json$/iD';
                if($n<=$s['after'])continue;
                if($stage<2&&!preg_match($pattern,$n))continue;
                if($stage>=2){if(in_array($n,['.htaccess','index.php'],true)||$stage===2&&$n==='nomeados'&&$f->isDir()&&!$f->isLink())continue;if(str_ends_with($n,'.bak')&&is_file($dir.'/'.substr($n,0,-4).'.json'))continue;}
                $files[$n]=$f->getPathname();
                if(count($files)>$left+1){ksort($files,SORT_STRING);array_pop($files);}
            }
            ksort($files,SORT_STRING);$more=count($files)>$left;$batch=array_slice($files,0,$left,true);$done=true;
            foreach($batch as $n=>$path){
                if(microtime(true)>=$deadline){$done=false;break;}
                $s['after']=$n;$s['examined']++;$left--;
                try {
                    if(is_link($path)||!is_file($path)||filesize($path)>100*1024*1024)throw new \RuntimeException('unsafe_component');
                    if($stage>=2&&!preg_match('/^(?:db)?[a-f0-9]{16,64}\.json$/iD',$n))throw new \RuntimeException('unrecognized_or_unpaired');
                    $raw=file_get_contents($path);if($raw===false)throw new \RuntimeException('read_failed');
                    if($stage<2){if(!str_starts_with($raw,StateStore::HEADER))throw new \RuntimeException('invalid_envelope');$raw=substr($raw,strlen(StateStore::HEADER));}
                    $v=json_decode($raw,true,512,JSON_THROW_ON_ERROR);$id=$v['id']??'';
                    if(!is_array($v)||!preg_match('/^(?:db)?[a-f0-9]{16,64}$/iD',(string)$id))throw new \RuntimeException('invalid_identity');
                    if(isset($v['site_id'])&&(int)$v['site_id']!==get_current_blog_id())continue;
                    if($stage>=2 && is_multisite() && !isset($v['site_id']))throw new \RuntimeException('legacy_site_unknown');
                    if($stage<2 && basename(StateStore::path($stage===0?'backup-index':'backups',$id))!==$n)throw new \RuntimeException('identity_mismatch');
                    $existing=Persistence::get('backup-index',$id);
                    if(($existing['_storage']['status']??'')==='deleted')continue;
                    if($stage>=2){
                        if($n!==$id.'.json')throw new \RuntimeException('identity_mismatch');
                        $v['legacy']=true;$v['legacy_relative']=($stage===3?'nomeados/':'').$id;$v['kind']=isset($v['rows'])?'database':'file';
                        if($existing && (empty($existing['legacy'])||($existing['legacy_relative']??$id)!==$v['legacy_relative']))throw new \RuntimeException('duplicate_identity');
                        $bak=$dir.'/'.$id.'.bak';$v['stored_bytes']=filesize($path)+(is_file($bak)?filesize($bak):0);
                    } else {
                        $payload=StateStore::path('backups',$id);
                        if($stage===0 && !is_file($payload))throw new \RuntimeException('payload_missing');
                        $v['stored_bytes']=filesize($payload);
                    }
                    if($existing)continue;
                    unset($v['rows'],$v['sql'],$v['content_base64'],$v['snapshot']);$v['target']=$v['path']??$v['table']??'';$v['inventory_source']=['envelope_index','private_payload','legacy_root','legacy_named'][$stage];
                    if(Persistence::put('backup-index',$id,$v,true))$s['imported']++;
                }catch(\Throwable $e){$s['blocked'][]=['source'=>$stage,'file'=>$n,'reason'=>in_array($e->getMessage(),['unsafe_component','invalid_envelope','invalid_identity','identity_mismatch','legacy_site_unknown','duplicate_identity','payload_missing','read_failed','unrecognized_or_unpaired'],true)?$e->getMessage():'invalid_metadata'];}
            }
            if($done&&!$more){$s['stage']++;$s['after']='';}
        }
        $s['complete']=$s['stage']===4;$s['time']=time();StateStore::put('migration',$key,$s);
        return ['complete'=>$s['complete'],'examined'=>$s['examined'],'imported'=>$s['imported'],'blocked'=>$s['blocked'],'sources'=>['envelope_index','private_payload','legacy_root','legacy_named']];
    }
}
