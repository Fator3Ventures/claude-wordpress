<?php
/** Environment diagnostics and compact capability discovery. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SystemTools {
	public static function register(): void {
		Registry::add('system/capabilities', 'Report the loaded MCP distribution, user capabilities, channel gates, optional components and configured limits.', [], [], [self::class, 'capabilities'], 'edit_posts');
		Registry::add('system/health', 'Read local diagnostics for MCP, PHP, WordPress, private storage and database. Does not claim an external HTTP or OAuth connectivity test.', [], [], [self::class, 'health'], 'manage_options');
		$page = ['offset' => Registry::integer(), 'per_page' => Registry::integer(1, 200)];
		Registry::add('audit/list', 'List operation metadata without request payloads or credentials. Filtros exatos por habilidade, usuário, conexão, alvo, operação, resultado e período. before é alias de cursor; path é alias de target; aliases divergentes são recusados.', ['ability' => Registry::string(), 'user' => Registry::integer(1), 'success' => Registry::boolean(), 'before' => Registry::string(), 'cursor'=>Registry::string(), 'path'=>Registry::string(),'target'=>Registry::string(),'connection_id'=>Registry::string(),'operation_id'=>Registry::string(),'since'=>Registry::string(),'until'=>Registry::string(), 'per_page' => Registry::integer(1, 200)], [], [Audit::class, 'listing']);
		Registry::add('audit/prune', 'Evaluate or remove audit records older than the chosen age. dry_run defaults to true.', ['older_than_days' => Registry::integer(1, 3650), 'dry_run' => Registry::boolean(true),'max_total_bytes'=>Registry::integer(1),'before_id'=>Registry::integer(1),'expected_selection_sha256'=>Registry::string()], [], [Audit::class, 'prune'], 'manage_options', false);
		Registry::add('backups/list', 'List protected file/database backup metadata, including compatible legacy backups.', $page + ['category'=>['type'=>'string','enum'=>['backups','sql_mutation','sql_artifacts']],'path' => Registry::string(),'label'=>Registry::string(),'rotulo'=>Registry::string(),'since'=>Registry::string(),'until'=>Registry::string()], [], [Backups::class, 'listing'], [FileTools::class, 'permission']);
		Registry::add('backups/export', 'Export one backup as base64 JSON with SHA-256. Binary database cells use explicit base64 encoding.', ['backup_id' => Registry::string()], ['backup_id'], [Backups::class, 'export'], [FileTools::class, 'permission']);
		Registry::add('backups/prune', 'Evaluate retention by age and optional total stored bytes. dry_run defaults to true. Apply requires the preview expected_selection_sha256. include_legacy adds recognized legacy pairs; resume reuses the frozen selection. Active references are preserved.', ['category'=>['type'=>'string','enum'=>['backups','sql_mutation','sql_artifacts']],'artifact_ids'=>['type'=>'array','items'=>['type'=>'string','pattern'=>'^[a-f0-9]{32}$'],'minItems'=>1,'maxItems'=>200,'uniqueItems'=>true],'max_count'=>Registry::integer(1,10000),'min_keep'=>Registry::integer(0,10000),'older_than_days' => Registry::integer(1, 3650), 'max_total_bytes' => Registry::integer(), 'dry_run' => Registry::boolean(true),'include_legacy'=>Registry::boolean(),'expected_selection_sha256'=>Registry::string(),'selection_sha256'=>Registry::string(),'offset'=>Registry::integer(),'legacy_after'=>Registry::string(),'cursor'=>Registry::string()], [], [Backups::class, 'prune'], [FileTools::class, 'permission'], false);
	}
	public static function capabilities(array $input = []): array {
		global $wp_version;
		$caps = []; foreach (['edit_posts','edit_pages','publish_posts','manage_options','edit_theme_options','switch_themes','install_themes','install_plugins','update_plugins','delete_plugins','edit_files','unfiltered_html'] as $cap) $caps[$cap] = current_user_can($cap);
		$loaded = defined('WP_MCP_ULTIMATE_DIR') ? wp_normalize_path(WP_MCP_ULTIMATE_DIR) : '';
		$integrated = '' !== $loaded && str_starts_with($loaded, wp_normalize_path(F3_MCP_FILES_DIR));
        $context=ConnectionContext::get()??[];
        $metatools=['Discover Abilities','Get Ability Info','Execute Ability'];if(!empty($context['readonly_executor']))$metatools[]='Execute Readonly Ability';
        $channel_allowed=static fn($name,$read)=>!is_wp_error(AuthorizationPolicy::check($name,[],$read,true));
		return Result::ok(['plugin_version' => F3_MCP_FILES_VERSION, 'wordpress' => $wp_version, 'php' => PHP_VERSION, 'site_id' => get_current_blog_id(), 'user_id' => get_current_user_id(), 'connection_context'=>array_intersect_key(ConnectionContext::get()??[],array_flip(['connection_id','profile','policy_version','expires','transport','readonly_executor'])), 'endpoint' => ConnectionEndpoints::url(), 'legacy_endpoint' => ConnectionEndpoints::url(ConnectionEndpoints::LEGACY), 'endpoints' => ConnectionEndpoints::entries(), 'metatools' => $metatools, 'integrated_core_loaded' => $integrated, 'upstream_version' => F3_MCP_UPSTREAM_VERSION, 'abilities_api' => version_compare($wp_version, '6.9', '>=') ? 'wordpress-native' : 'bundled-polyfill', 'capabilities' => $caps, 'channels' => ['files' => PathGuard::is_enabled() && PathGuard::can_edit() && $channel_allowed('files/read',true) && (in_array($context['profile']??'',['legacy','maintenance'],true)||!empty($context['roots'])), 'database_read' => PathGuard::is_enabled() && current_user_can('manage_options') && $channel_allowed('db/query',true), 'database_write' => PathGuard::is_enabled() && current_user_can('manage_options') && Database::writes_enabled() && $channel_allowed('db/execute',false) && (in_array($context['profile']??'',['legacy','maintenance'],true)||!empty($context['database_write']))], 'limits' => ['file_bytes' => PathGuard::max_bytes(), 'sql_rows' => SqlGuard::MAX_ROWS, 'sql_bytes' => ConnectionContext::maintenance()?1048576:65536, 'query_response_bytes'=>16777216,'transfer_part_bytes'=>262144, 'db_confirmation_seconds' => 600, 'plan_steps' => 50, 'lock_wait_seconds' => max(0, min(10, (float)apply_filters('f3_mcp_lock_timeout', 2.0)))], 'file_scope' => in_array($context['profile']??'',['legacy','maintenance'],true) ? (PathGuard::is_confined() ? 'configured_roots' : 'php_reachable_paths') : 'connection_roots', 'file_roots'=>$context['roots']??[], 'concurrency_scope' => 'Cooperating operations in this plugin and shared lock storage. External writers must use the same lock API.']);
	}
	public static function health(array $input = []): array {
		global $wpdb;
		$checks = ['abilities_api' => function_exists('wp_get_abilities'), 'mcp_adapter' => class_exists('WpMcpUltimate\\Server\\McpAdapter'), 'json' => function_exists('json_encode'), 'random_bytes' => function_exists('random_bytes'), 'flock' => function_exists('flock'), 'rest_configured' => (bool)ConnectionEndpoints::url(), 'persistence_schema'=>(int)get_option('f3_mcp_schema_version',0)===2];
        $connection = ConnectionStatus::snapshot();
        $checks['mcp_registration'] = $connection['registry_checked'] && !$connection['errors'];
        $recovery = method_exists(\Fator3\RecoveryV1\Engine::class, 'sweep_status') ? \Fator3\RecoveryV1\Engine::sweep_status() : ['status'=>'unavailable','reason'=>'sentinel_update_pending'];
        $recovery['runtime_refresh'] = Recovery::runtime_refresh_status();
        $checks['recovery_sweep'] = match ($recovery['status']??'') { 'checked' => true, 'degraded' => false, default => null };
        if($recovery['runtime_refresh']==='failed')$checks['recovery_sweep']=false;
		$storage = [];
		try { $legacy_protection=LegacyStorage::ensure(); $dir = StateStore::directory(); $storage = ['path' => $dir, 'writable' => is_writable($dir), 'free_bytes' => @disk_free_space($dir), 'php_envelopes' => true, 'outside_document_root' => !str_starts_with(wp_normalize_path($dir) . '/', wp_normalize_path(realpath(ABSPATH) ?: ABSPATH)), 'legacy_protection'=>$legacy_protection, 'legacy_directory_present' => is_dir(WP_CONTENT_DIR . '/f3-mcp-backups'), 'http_protection_tested' => false]; $checks['private_storage'] = $storage['writable']; }
		catch (\Throwable $e) { $checks['private_storage'] = false; $storage['error'] = 'Armazenamento privado indisponível.'; }
		$storage['sql_artifacts']=SqlArtifacts::health();
        $probe=StateStore::get('diagnostics','private-http');
        $fingerprint=isset($storage['path'])?hash('sha256',wp_normalize_path($storage['path']).'|'.home_url('/')):'';
        if($probe && ($probe['fingerprint']??'')===$fingerprint && strtotime($probe['time']??'')>time()-DAY_IN_SECONDS) { $storage['http_protection_tested']=!empty($probe['tested']);$storage['http_protection_passed']=!empty($probe['passed']);$storage['http_protection_evidence']=$probe; }
        $suppress = $wpdb->suppress_errors(true); $one = $wpdb->get_var('SELECT 1'); $checks['database'] = '1' === (string)$one && !$wpdb->last_error; $wpdb->suppress_errors($suppress);
		return Result::ok(['healthy' => !in_array(false, $checks, true), 'checks' => $checks, 'storage' => $storage, 'recovery' => $recovery, 'database_class' => get_class($wpdb), 'environment' => self::capabilities(), 'external_connectivity_tested' => false, 'connection' => $connection,'cron'=>Probe::cron(),'audit'=>Audit::status(),'providers'=>Providers::all(),'maintenance'=>StateMaintenance::storage()]);
	}
}
final class Discovery {
	public static function schema(): array { return ['type' => 'object', 'properties' => ['query' => Registry::string('Search name, label and description.'), 'prefix' => Registry::string(), 'category' => Registry::string(), 'readonly' => Registry::boolean(), 'per_page' => Registry::integer(1, 200), 'cursor' => Registry::string(), 'compact' => Registry::boolean(), 'if_catalog_sha256'=>['type'=>'string','pattern'=>'^[a-fA-F0-9]{64}$']], 'additionalProperties' => false]; }
    /** Shared visibility contract; target-dependent permissions remain requires_input. */
    public static function eligibility(\WP_Ability $ability): array {
        $meta=$ability->get_meta();$name=$ability->get_name();
        if(empty($meta['mcp']['public']))return ['visible'=>false,'availability'=>'private'];
        if(!str_starts_with($name,'wp-mcp-ultimate/')&&is_wp_error(AuthorizationPolicy::check($name,[],!empty($meta['annotations']['readonly']),true)))return ['visible'=>false,'availability'=>'profile_denied'];
        if($ability->get_input_schema()['required']??[])return ['visible'=>true,'availability'=>'requires_input'];
        try{$permission=$ability->check_permissions([]);$allowed=!is_wp_error($permission)&&(bool)$permission;}catch(\Throwable $error){return ['visible'=>true,'availability'=>'requires_input'];}
        return ['visible'=>$allowed,'availability'=>$allowed?'available':'permission_denied'];
    }
	public static function listing(array $abilities, array $input): array {
		$list = [];
		foreach ($abilities as $ability) {
			$meta = $ability->get_meta(); $name = $ability->get_name();
			$eligibility=self::eligibility($ability);if (!$eligibility['visible'] || ($meta['mcp']['type'] ?? 'tool') !== 'tool') continue;
			$readonly = (bool)($meta['annotations']['readonly'] ?? false);
            if(!str_starts_with($name,'wp-mcp-ultimate/') && is_wp_error(AuthorizationPolicy::check($name,[],$readonly,true)))continue;
			$category = method_exists($ability, 'get_category') ? $ability->get_category() : '';
			if (isset($input['prefix']) && !str_starts_with($name, $input['prefix']) || isset($input['category']) && $category !== $input['category'] || isset($input['readonly']) && $readonly !== $input['readonly']) continue;
			if (!empty($input['query']) && false === stripos($name . ' ' . $ability->get_label() . ' ' . $ability->get_description(), $input['query'])) continue;
            $available=$eligibility['availability'];
			$list[] = ['name' => $name, 'label' => $ability->get_label(), 'description' => !empty($input['compact']) ? '' : $ability->get_description(), 'category' => $category, 'readonly' => $readonly, 'availability' => $available, 'version' => $meta['fator3']['version'] ?? Providers::metadata($name)['version'], 'provider'=>$meta['fator3']['provider']??Providers::metadata($name)['provider'], 'version_reason'=>$meta['fator3']['version_reason']??(Providers::metadata($name)['version_reason']??null), 'schema_sha256' => hash('sha256', serialize([$ability->get_input_schema(), $ability->get_output_schema()]))];
		}
		usort($list, static fn($a, $b) => strcmp($a['name'], $b['name']));
		$hash = hash('sha256', serialize([ConnectionContext::key(),ConnectionContext::get()['policy_version']??null,$list])); $offset = 0;
        if(isset($input['if_catalog_sha256'])&&hash_equals($hash,strtolower($input['if_catalog_sha256'])))return Result::ok(['unchanged'=>true,'catalog_sha256'=>$hash,'abilities'=>[],'total'=>count($list),'has_more'=>false,'next_cursor'=>null]);
		$filter = $input; unset($filter['cursor'],$filter['if_catalog_sha256']); ksort($filter); $filter_hash = hash('sha256', serialize($filter));
		if (!empty($input['cursor'])) {
			$state = Cursor::decode($input['cursor']); if (is_wp_error($state)) return Result::error($state) + ['abilities' => []];
			if (($state['kind'] ?? '') !== 'abilities' || ($state['connection_id']??'')!==ConnectionContext::key() || $state['user'] !== get_current_user_id() || $state['blog'] !== get_current_blog_id() || $state['filter'] !== $filter_hash) return Result::fail('cursor_invalid', 'Discovery cursor belongs to different filters or user.', ['abilities' => []]);
			if ($state['catalog'] !== $hash) return Result::fail('catalog_changed', 'Ability catalog changed. Restart discovery.', ['conflict' => true, 'abilities' => []]);
			$offset = $state['offset'];
		}
		// Empty input preserves the historical complete list for existing clients.
		$limit = isset($input['per_page']) || isset($input['cursor']) ? max(1, min(200, (int)($input['per_page'] ?? 50))) : max(1, count($list));
		$page = array_slice($list, $offset, $limit); $next = $offset + count($page);
		return Result::ok(['abilities' => $page, 'unchanged'=>false, 'total' => count($list), 'catalog_sha256' => $hash, 'plugin_version' => F3_MCP_FILES_VERSION, 'has_more' => $next < count($list), 'next_cursor' => $next < count($list) ? Cursor::encode(['kind' => 'abilities', 'connection_id'=>ConnectionContext::key(), 'user' => get_current_user_id(), 'blog' => get_current_blog_id(), 'filter' => $filter_hash, 'catalog' => $hash, 'offset' => $next]) : null]);
	}
}
