<?php
/** Protected backup envelopes; existing .json/.bak backups remain readable. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Backups {
    private static ?string $label=null;
    public static function labelled(array $input,callable $callback) { $old=self::$label;self::$label=$input['label']??$old;try{return $callback();}finally{self::$label=$old;} }
    public static function reference(string $id,string $plan): void {
        Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static function()use($id,$plan){$meta=self::metadata($id,false);if(is_wp_error($meta))return;$meta['protected_by_operations']=array_values(array_unique(array_merge($meta['protected_by_operations']??[],[$plan])));StateStore::put('backup-index',$id,$meta);});
    }
    public static function create_snapshot(string $ability,array $snapshot) {
        $id=bin2hex(random_bytes(12));
        try { self::persist($id,['id'=>$id,'kind'=>'snapshot','ability'=>$ability,'snapshot'=>$snapshot,'time'=>gmdate('c'),'user'=>get_current_user_id(),'backup_contains_sensitive_values'=>'unknown']); }
        catch(\Throwable $e){return new \WP_Error('backup_write_failed','Não foi possível preservar a pré-imagem.');}return $id;
    }

	public static function metadata(string $id, bool $with_content = true) {
		if (!preg_match('/^(?:db)?[a-f0-9]{16,64}$/iD', $id)) return new \WP_Error('invalid_backup_id', 'Invalid backup identifier.');
		$stored = StateStore::get($with_content ? 'backups' : 'backup-index', $id);
		if (!$stored && $with_content) { $index=StateStore::get('backup-index',$id);if(!empty($index['legacy']))$stored=$index; }
		if (!$stored && !$with_content) $stored = StateStore::get('backups', $id);
		if (!$stored) {
			$path = WP_CONTENT_DIR . '/f3-mcp-backups/' . $id . '.json';
			if (!is_file($path)) return new \WP_Error('backup_not_found', 'Backup not found.');
			$stored = json_decode((string)file_get_contents($path), true);
			if (!is_array($stored)) return new \WP_Error('backup_corrupt', 'Invalid backup metadata.');
			$stored['legacy'] = true;
			$stored['kind'] = isset($stored['rows']) ? 'database' : 'file';
		}
		if ($with_content && !empty($stored['legacy'])) { $path=LegacyStorage::base($stored).'.json';$raw=is_file($path)&&!is_link($path)?json_decode((string)file_get_contents($path),true):null;if(!is_array($raw))return new \WP_Error('backup_corrupt','Metadados legados indisponíveis.');$stored=array_merge($raw,array_intersect_key($stored,array_flip(['legacy','legacy_relative','kind']))); }
		if (($stored['id'] ?? '') !== $id) return new \WP_Error('backup_corrupt', 'Backup identity mismatch.');
		return $stored;
	}
	private static function persist(string $id, array $payload): void {
		$payload['label']=self::$label; $payload['connection_id']=ConnectionContext::key();
		$result = Locks::run(['backups:' . get_current_blog_id() => LOCK_EX], static function () use($id, $payload) {
			StateStore::put('backups', $id, $payload);
			unset($payload['rows'], $payload['sql'], $payload['content_base64'], $payload['snapshot']);
			$payload['stored_bytes'] = filesize(StateStore::path('backups', $id)); $payload['target']=$payload['path']??$payload['table']??'';
			StateStore::put('backup-index', $id, $payload);
			return Result::ok();
		});
		if (!$result['success']) throw new \RuntimeException($result['message']);
	}
	public static function create_file(string $path) {
		$size = filesize($path);
		$max = (int)apply_filters('f3_mcp_backup_max_bytes', 64 * 1024 * 1024);
		if (false === $size || $size > $max) return new \WP_Error('backup_size_limit', 'File exceeds the configured backup size limit; no change made.');
		$memory_limit = wp_convert_hr_to_bytes(ini_get('memory_limit'));
		if ($memory_limit > 0 && $size * 6 + memory_get_usage(true) > $memory_limit) return new \WP_Error('backup_memory_limit', 'Backup cannot fit in the PHP memory limit. No file change was made.');
		$content = @file_get_contents($path);
		if (false === $content || strlen($content) !== $size) return new \WP_Error('backup_read_failed', 'Incomplete backup read.');
		$id = bin2hex(random_bytes(12));
		try {
			self::persist($id, ['id' => $id, 'kind' => 'file', 'path' => PathGuard::to_relative($path), 'time' => gmdate('c'), 'user' => get_current_user_id(), 'bytes' => strlen($content), 'sha256' => hash('sha256', $content), 'content_base64' => base64_encode($content)]);
		} catch (\Throwable $e) { return new \WP_Error('backup_write_failed', $e->getMessage()); }
		return $id;
	}
	public static function create_rows(string $table, string $sql, array $rows) {
		$id = 'db' . bin2hex(random_bytes(11));
		try {
			self::persist($id, ['id' => $id, 'kind' => 'database', 'table' => $table, 'sql' => $sql, 'rows' => DatabaseWriter::transport_rows($rows), 'binary_encoding' => 'Cells with encoding=base64 contain original binary bytes', 'time' => gmdate('c'), 'user' => get_current_user_id(), 'count' => count($rows)]);
		} catch (\Throwable $e) { return new \WP_Error('backup_write_failed', $e->getMessage()); }
		return $id;
	}
	public static function restore(array $input): array {
		$meta = self::metadata((string)($input['backup_id'] ?? ''));
		if (is_wp_error($meta)) return Result::error($meta);
		if ('file' !== $meta['kind']) return Result::fail('backup_type_mismatch', 'Use a file backup with files/restore.');
		$path = PathGuard::resolve((string)$meta['path'], true);
		if (is_wp_error($path)) return Result::error($path);
		$valid = PathGuard::check_extension($path);
		if (is_wp_error($valid)) return Result::error($valid);
		$content = !empty($meta['legacy']) ? @file_get_contents(LegacyStorage::base($meta) . '.bak') : base64_decode($meta['content_base64'] ?? '', true);
		if (false === $content || !hash_equals($meta['sha256'] ?? '', hash('sha256', $content))) return Result::fail('backup_corrupt', 'Backup content hash mismatch.');
		if ('php' === strtolower(pathinfo($path, PATHINFO_EXTENSION))) {
			$check = PathGuard::check_php_syntax($content);
			if (is_wp_error($check)) return Result::error($check);
		}
		$before = is_file($path) ? self::create_file($path) : '';
		if (is_wp_error($before)) return Result::error($before);
		$result = Files::atomic_write($path, $content);
		if (is_wp_error($result)) return Result::error($result);
		PathGuard::audit('restore', PathGuard::to_relative($path), ['backup_id' => $meta['id']]);
		return Result::ok(['path' => PathGuard::to_relative($path), 'bytes' => strlen($content), 'backup_id' => $before, 'sha256' => hash('sha256', $content)], 'File restored.');
	}
	public static function listing(array $input): array {
        if(($input['category']??'backups')!=='backups')return SqlArtifacts::listing($input);
        $migration=Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static fn()=>BackupInventory::advance());
        if(!isset($migration['complete']))return $migration;
        $filters=[];
        if(isset($input['label']))$filters['label']=$input['label'];
        if(!empty($input['path'])) { $wanted=PathGuard::lock_path($input['path']);if(is_wp_error($wanted))return Result::error($wanted);$filters['target']=PathGuard::to_relative($wanted); }
        foreach(['since','until'] as $key)if(isset($input[$key])) { $t=strtotime($input[$key]);if(false===$t)return Result::fail('invalid_date','Use data ISO 8601.');$filters[$key]=$t; }
        $limit=max(1,min(200,(int)($input['per_page']??30)));$offset=max(0,(int)($input['offset']??0));
        $rows=Persistence::listing('backup-index',$filters,$limit+1,PHP_INT_MAX,$offset);$more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);
        foreach($rows as &$row)unset($row['_row_id']);unset($row);
        return Result::ok(['backups'=>$rows,'has_more'=>$more,'next_offset'=>$more?$offset+count($rows):null,'history_complete'=>$migration['complete'],'legacy_directory_present'=>is_dir(WP_CONTENT_DIR.'/f3-mcp-backups')]);
    }

	public static function export(array $input): array {
        return Locks::run(['backups:'.get_current_blog_id()=>LOCK_SH],static function()use($input){
            $source=BackupExport::source($input['backup_id']);if(is_wp_error($source))return Result::error($source);
            $size=filesize($source['path'])-$source['skip'];
            if(4*(int)ceil($size/3)>PathGuard::max_bytes())return Result::fail('export_size_limit','Use backups/export-part para este backup.');
            $bytes=file_get_contents($source['path'],false,null,$source['skip']);if($bytes===false||strlen($bytes)!==$size)return Result::fail('backup_export_failed','Leitura incompleta.');
            return Result::ok(['filename'=>$input['backup_id'].'.json','content_base64'=>base64_encode($bytes),'sha256'=>hash('sha256',$bytes),'backup_contains_sensitive_values'=>$source['meta']['backup_contains_sensitive_values']??'unknown'],'Exportação com valores originais; base64 não é criptografia.');
        });
    }
    public static function prune(array $input): array {return ($input['category']??'backups')==='backups'?Retention::prune($input):SqlArtifacts::prune($input);}
}
