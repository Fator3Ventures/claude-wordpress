<?php
/** Expiry cleanup and finite tombstones; live refresh families retain replay guards. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class TokenRetention {
    public const DAYS=30;
    private static function scope(): string {return is_admin()&&current_user_can('manage_options')?'admin:'.get_current_user_id():ConnectionContext::key();}
    private static function action(array $r,bool $lock=false): ?string {
        $expires=(int)$r['expires_at'];if($expires<=0)return null;
        $status=$r['status'];$v=json_decode($r['payload'],true);if(!is_array($v))return null;
        if($status!=='deleted'&&!($status==='consumed'&&!empty($v['compacted_at'])))return $expires<=time()?'compact':null;
        $cutoff=time()-self::DAYS*DAY_IN_SECONDS;
        if($expires>=$cutoff||(int)$r['updated_at']>=$cutoff)return null;
        if(($r['kind']??'')==='rt'&&!empty($r['grant_id'])){
            $g=Persistence::get('oauth-grants',$r['grant_id'],$lock);
            if($g&&(($g['_storage']['status']??'')==='active'||(int)($g['_storage']['updated_at']??time())>=$cutoff))return null;
        }
        return 'purge';
    }
    public static function run(array $i): array {
        if(!current_user_can('manage_options'))return Result::fail('permission_denied','Exige manage_options.');
        if(isset($i['older_than_days'])&&(int)$i['older_than_days']!==self::DAYS)return Result::fail('token_retention_fixed','Tokens usam expiração real e 30 dias para comprovantes; older_than_days aceita somente 30.');
        if(isset($i['max_total_bytes']))return Result::fail('token_volume_unsupported','Volume não autoriza remover tokens válidos ou controles de reutilização.');
        return Locks::run(['state-maintenance:oauth-tokens'=>LOCK_EX],static function()use($i){
            global $wpdb;$table=Persistence::table('oauth-tokens');
            if(($i['dry_run']??true)!==false){
                $before=(int)($i['before_id']??PHP_INT_MAX);$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM `$table` WHERE bucket='oauth-tokens' AND expires_at>0 AND expires_at<=%d AND id<%d ORDER BY id DESC LIMIT 101",time(),$before),ARRAY_A);
                if($wpdb->last_error)return Result::fail('maintenance_read_failed','Leitura de tokens falhou.');
                $more=count($rows)>100;$rows=array_slice($rows,0,100);$selected=[];
                foreach($rows as $r){$action=self::action($r);if($action)$selected[]=['record_key'=>$r['record_key'],'id'=>(int)$r['id'],'revision'=>(int)$r['revision'],'action'=>$action,'bytes'=>strlen($r['payload'])];}
                $plan=['category'=>'oauth-tokens','scope'=>self::scope(),'expires'=>time()+3600,'status'=>'pending','rows'=>$selected,'completed'=>[],'has_more'=>$more,'next_before_id'=>$more?(int)end($rows)['id']:null];
                $sha=hash_hmac('sha256',serialize($plan),wp_salt('auth'));StateStore::put('token-retention',$sha,$plan);
                return Result::ok(['dry_run'=>true,'selected'=>count($selected),'selected_bytes'=>array_sum(array_column($selected,'bytes')),'selection_sha256'=>$sha,'has_more'=>$more,'next_before_id'=>$plan['next_before_id'],'items'=>array_map(static fn($r)=>array_intersect_key($r,array_flip(['id','action','bytes'])),$selected)],'Tokens vencidos são compactados; comprovantes elegíveis após 30 dias são excluídos.');
            }
            $sha=(string)($i['expected_selection_sha256']??'');$plan=StateStore::get('token-retention',$sha);
            if(!$plan||$plan['scope']!==self::scope()||($plan['expires']<time()&&!$plan['completed']))return Result::fail('maintenance_selection_invalid','Prévia ausente, expirada ou de outra conexão.');
            if($plan['status']==='complete')return Result::ok(['changed'=>false,'replayed'=>true,'completed'=>count($plan['completed']),'has_more'=>$plan['has_more'],'next_before_id'=>$plan['next_before_id']]);
            foreach($plan['rows'] as $row){
                if(in_array($row['record_key'],$plan['completed'],true))continue;
                try{$result=Persistence::transaction(static function()use($row,$table,$wpdb,$sha,&$plan){
                    $r=Persistence::rows($wpdb->prepare("SELECT * FROM `$table` WHERE record_key=%s FOR UPDATE",$row['record_key']))[0]??null;
                    // A durable receipt shares the transaction with physical deletion.
                    if(in_array($row['record_key'],$plan['completed'],true))return Result::ok(['replayed'=>true]);
                    if(!$r||(int)$r['revision']!==$row['revision']||self::action($r,true)!==$row['action'])return new \WP_Error('maintenance_selection_conflict','Token ou concessão mudou desde a prévia.');
                    if(!empty($r['grant_id']))Persistence::get('oauth-grants',$r['grant_id'],true);
                    if(self::action($r,true)!==$row['action'])return new \WP_Error('maintenance_selection_conflict','Concessão mudou durante a manutenção.');
                    if($row['action']==='purge')$n=Persistence::query($wpdb->prepare("DELETE FROM `$table` WHERE record_key=%s AND revision=%d",$row['record_key'],$row['revision']));
                    else{
                        $v=json_decode($r['payload'],true);$guard=$r['kind']==='rt'&&$r['status']==='consumed'&&!empty($v['grant_id']);$status=$guard?'consumed':'deleted';
                        $compact=['status'=>$status,'compacted_at'=>time(),'maintenance_selection'=>$sha];if($guard)$compact+=['retention_kind'=>'replay_guard']+array_intersect_key($v,array_flip(['kind','client_id','grant_id','expires','issuer','site_id']));
                        $n=Persistence::query($wpdb->prepare("UPDATE `$table` SET payload=%s,status=%s,updated_at=%d,revision=revision+1 WHERE record_key=%s AND revision=%d",wp_json_encode($compact),$status,time(),$row['record_key'],$row['revision']));
                    }
                    if($n!==1)throw new \RuntimeException();$plan['completed'][]=$row['record_key'];StateStore::put('token-retention',$sha,$plan);return Result::ok();
                });}catch(\Throwable $e){return Result::fail('maintenance_write_failed','Manutenção não confirmada; transação revertida.',['completed'=>count($plan['completed'])]);}
                if(is_wp_error($result))return Result::error($result)+['completed'=>count($plan['completed'])];
            }
            $plan['status']='complete';StateStore::put('token-retention',$sha,$plan);StateStore::put('maintenance-status','oauth-tokens',['time'=>time(),'category'=>'oauth-tokens','completed'=>count($plan['completed'])]);
            return Result::ok(['changed'=>(bool)$plan['completed'],'completed'=>count($plan['completed']),'selection_sha256'=>$sha,'dry_run'=>false,'has_more'=>$plan['has_more'],'next_before_id'=>$plan['next_before_id']]);
        });
    }
    public static function diagnostics(): array {
        global $wpdb;$t=Persistence::table('oauth-tokens');$now=time();
        $r=$wpdb->get_results("SELECT kind,status,COUNT(*) records,SUM(expires_at>0 AND expires_at<=$now) expired,SUM(expires_at=0) unknown_expiry FROM `$t` WHERE bucket='oauth-tokens' GROUP BY kind,status",ARRAY_A);
        return ['access_ttl_seconds'=>3600,'refresh_ttl_seconds'=>2592000,'receipt_retention_days'=>self::DAYS,'automatic_deletion_enabled'=>false,'expired_cleanup'=>'system/maintenance category:oauth-tokens','replay_guard_retention'=>'While grant is active; otherwise until token expiry and compaction and grant change are each older than 30 days.','groups'=>$wpdb->last_error?null:$r,'counts_are_authorization_proof'=>false];
    }
}
