<?php
/** Frozen, resumable retention selections. New backups never enter an existing confirmation. */
declare(strict_types=1);
namespace Fator3\McpFiles;
use Fator3\RecoveryV1\Engine;
final class Retention {
    private static function component(string $path): array {
        if(is_link($path))throw new \RuntimeException('Linked component.');
        $manifest=Engine::manifest($path);if(!$manifest)throw new \RuntimeException('Missing component.');
        $bytes=0;foreach($manifest['files'] as $entry)$bytes+=(int)($entry['bytes']??0);
        return ['path'=>$path,'sha256'=>Engine::digest($manifest),'bytes'=>$bytes,'removed'=>false];
    }
    private static function item(array $row): array {
        $id=$row['id'];$legacy=!empty($row['legacy']);$parts=[];
        foreach($row['protected_by_backups']??[] as $parent)if(is_file(StateStore::path('backups',$parent)))throw new \RuntimeException('backup_reference');
        if(!empty($row['protected_by_operations']))throw new \RuntimeException('operation_reference');
        if($legacy){
            $base=LegacyStorage::base($row);$meta=$base.'.json';
            if(($row['kind']??'file')==='file'){
                $bak=$base.'.bak';
                if(!is_file($bak)||is_link($bak)||!hash_equals((string)($row['sha256']??''),hash_file('sha256',$bak)))throw new \RuntimeException('legacy_pair_invalid');
                $parts[]=self::component($bak);
            }
            $parts[]=self::component($meta);
        }else{
            $payload=Backups::metadata($id);if(is_wp_error($payload))throw new \RuntimeException('backup_corrupt');
            if(($payload['ability']??'')==='recovery'){
                $journal=Recovery::directory().'/'.($payload['snapshot']['journal_id']??'').'.journal.php';$state=Engine::read($journal);
                if(!$state||!in_array($state['status'],['complete','rolled_back','unchanged'],true))throw new \RuntimeException('recovery_reference');
                if(file_exists($state['preimage']))$parts[]=self::component($state['preimage']);
                // The signed journal is retained as a consumed-operation receipt, never reused as a new effect.
            }
            $parts[]=self::component(StateStore::path('backups',$id));
            $old_index=StateStore::path('backup-index',$id);if(is_file($old_index))$parts[]=self::component($old_index);
        }
        foreach(glob(StateStore::directory('backup-exports').'/'.$id.'-*.php')?:[] as $export)$parts[]=self::component($export);
        return ['id'=>$id,'kind'=>$row['kind']??'unknown','legacy'=>$legacy,'time'=>$row['time']??null,'parts'=>$parts,'bytes'=>array_sum(array_column($parts,'bytes')),'status'=>'pending'];
    }
    private static function candidates(array $input): array {
        global $wpdb;$table=Persistence::table('backup-index');
        $where="bucket='backup-index' AND status<>'deleted'";
        if(empty($input['include_legacy']))$where.=" AND COALESCE(JSON_EXTRACT(payload,'$.legacy'),false)=false";
        $cutoff=time()-max(1,(int)($input['older_than_days']??30))*DAY_IN_SECONDS;
        $criteria=['created_at<'.$cutoff];
        if(isset($input['max_total_bytes']))$criteria[]='cumulative_bytes>'.max(0,(int)$input['max_total_bytes']);
        if(isset($input['max_count']))$criteria[]='keep_rank>'.max(1,(int)$input['max_count']);
        $base="SELECT *,ROW_NUMBER() OVER (ORDER BY created_at DESC,id DESC) keep_rank,SUM(stored_bytes) OVER (ORDER BY created_at DESC,id DESC) cumulative_bytes FROM `$table` WHERE $where";
        $eligible="SELECT * FROM ($base) inventory WHERE keep_rank>".max(0,(int)($input['min_keep']??0))." AND (".implode(' OR ',$criteria).")";
        $total=(int)$wpdb->get_var("SELECT COUNT(*) FROM ($eligible) eligible");
        if($wpdb->last_error)throw new \RuntimeException('Inventory unavailable.');
        $after=0;
        if(!empty($input['cursor'])){$c=Cursor::decode($input['cursor']);if(is_wp_error($c)||($c['kind']??'')!=='backup-retention-018'||($c['connection']??'')!==ConnectionContext::key()||($c['site']??0)!==get_current_blog_id()||($c['criteria']??'')!==self::criteria($input))throw new \RuntimeException('Invalid retention cursor.');$after=(int)$c['after'];}
        $rows=$wpdb->get_results("SELECT id,payload FROM ($eligible) eligible WHERE id>".$after." ORDER BY id LIMIT 201",ARRAY_A);
        if($wpdb->last_error)throw new \RuntimeException('Inventory unavailable.');
        return ['total'=>$total,'rows'=>$rows];
    }
    private static function criteria(array $i): string {
        return hash('sha256',serialize(['age'=>(int)($i['older_than_days']??30),'bytes'=>$i['max_total_bytes']??null,'count'=>$i['max_count']??null,'keep'=>(int)($i['min_keep']??0),'legacy'=>!empty($i['include_legacy'])]));
    }
    private static function plan(array $input): array {
        if(!empty($input['offset'])||!empty($input['legacy_after']))throw new \RuntimeException('Use cursor instead of mutable offsets.');
        $inventory=BackupInventory::advance();$selected=[];$blocked=$inventory['blocked'];$total=null;$more=!$inventory['complete'];$next=null;$all_bytes=0;
        if($inventory['complete']){
            $scan=self::candidates($input);$total=$scan['total'];$rows=$scan['rows'];$more=count($rows)>200;$rows=array_slice($rows,0,200);
            foreach($rows as $record){$row=json_decode($record['payload'],true,512,JSON_THROW_ON_ERROR);
                try{$item=self::item($row);$selected[]=$item;}catch(\Throwable $e){$blocked[]=['id'=>$row['id'],'reason'=>$e->getMessage()];}
            }
            if($more)$next=Cursor::encode(['kind'=>'backup-retention-018','connection'=>ConnectionContext::key(),'site'=>get_current_blog_id(),'criteria'=>self::criteria($input),'after'=>(int)end($rows)['id']]);
            global $wpdb;$table=Persistence::table('backup-index');$all_bytes=(int)$wpdb->get_var("SELECT COALESCE(SUM(stored_bytes),0) FROM `$table` WHERE bucket='backup-index' AND status<>'deleted'");
            if($wpdb->last_error)throw new \RuntimeException('Inventory unavailable.');
        }
        $state=['status'=>'pending','connection_id'=>ConnectionContext::key(),'time'=>time(),'expires'=>time()+3600,'items'=>$selected,'blocked'=>$blocked,'indexed_bytes'=>$all_bytes,'projected_indexed_bytes'=>max(0,$all_bytes-array_sum(array_column($selected,'bytes'))),'has_more'=>$more,'next_offset'=>null,'legacy_after'=>null,'next_cursor'=>$next,'inventory'=>$inventory,'remaining_eligible'=>$total,'criteria_input'=>array_intersect_key($input,array_flip(['older_than_days','max_total_bytes','max_count','min_keep','include_legacy']))];
        $hash=hash_hmac('sha256',serialize($state),wp_salt('auth'));StateStore::put('retention-plans',ConnectionContext::key().'|'.$hash,$state);$state['selection_sha256']=$hash;return $state;
    }
    private static function public(array $state,bool $dry): array {
        $selection=[];foreach($state['items'] as $item)$selection[]=array_intersect_key($item,array_flip(['id','kind','legacy','time','bytes','status']));
        return ['inventory_complete'=>$state['inventory']['complete']??false,'inventory'=>$state['inventory']??null,'remaining_eligible'=>$state['remaining_eligible']??null,'next_cursor'=>$state['next_cursor']??null,'selected_scope'=>'frozen_batch','dry_run'=>$dry,'selected'=>count($selection),'selection'=>$selection,'blocked'=>$state['blocked'],'indexed_bytes'=>$state['indexed_bytes'],'projected_indexed_bytes'=>$state['projected_indexed_bytes'],'has_more'=>$state['has_more'],'next_offset'=>$state['next_offset'],'legacy_after'=>$state['legacy_after'],'expected_selection_sha256'=>$state['selection_sha256'],'removed'=>count(array_filter($selection,static fn($r)=>$r['status']==='complete'))];
    }
    public static function prune(array $input): array {
        return Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static function()use($input){
            if($input['dry_run']??true){try{return Result::ok(self::public(self::plan($input),true));}catch(\Throwable $e){return Result::fail('backup_inventory_failed','Inventário ou cursor inválido; nenhuma exclusão executada.');}}
            $hash=$input['expected_selection_sha256']??'';
            if(!preg_match('/^[a-f0-9]{64}$/D',$hash))return Result::fail('backup_selection_required','Use o expected_selection_sha256 da simulação.');
            $key=ConnectionContext::key().'|'.$hash;$state=StateStore::get('retention-plans',$key);
            if(!$state||($state['connection_id']??'')!==ConnectionContext::key())return Result::fail('backup_selection_invalid','Seleção não pertence a esta conexão.');
            $state['selection_sha256']=$hash;
            if($state['status']==='complete')return Result::ok(self::public($state,false)+['replayed'=>true]);
            if($state['status']==='pending'&&$state['expires']<time())return Result::fail('backup_selection_expired','Simulação expirou.');
            foreach($state['items'] as $item){
                if($item['status']==='complete')continue;
                $index=Persistence::get('backup-index',$item['id']);foreach($index['protected_by_backups']??[] as $parent)if(is_file(StateStore::path('backups',$parent)))return Result::fail('backup_selection_conflict','Backup ganhou referência de pré-imagem.',['conflict'=>true]);if(!empty($index['protected_by_operations']))return Result::fail('backup_selection_conflict','Backup ganhou referência de operação.',['conflict'=>true]);
                foreach($item['parts'] as $part){if($part['removed']||($part['phase']??'')==='removing')continue;
                    $observed=isset($part['quarantine'])&&file_exists($part['quarantine'])?$part['quarantine']:$part['path'];$actual=Engine::digest(Engine::manifest($observed));
                    if($actual===null&&$state['status']==='running')continue;
                    if($actual!==$part['sha256'])return Result::fail('backup_selection_conflict','Componente selecionado mudou; nada novo foi incluído.',['conflict'=>true,'backup_id'=>$item['id']]);
                }
            }
            $state['status']='running';StateStore::put('retention-plans',$key,$state);$failed=[];
            foreach($state['items'] as &$item){
                if($item['status']==='complete')continue;
                foreach($item['parts'] as &$part){if($part['removed'])continue;
                    try{
                        if(!isset($part['quarantine'])){$part['quarantine']=dirname($part['path']).'/.f3-prune-'.bin2hex(random_bytes(16));$part['phase']='quarantining';StateStore::put('retention-plans',$key,$state);}
                        if(file_exists($part['path'])){if(file_exists($part['quarantine'])||!rename($part['path'],$part['quarantine']))throw new \RuntimeException('Cannot quarantine component.');}
                        $part['phase']='removing';StateStore::put('retention-plans',$key,$state);
                        if(file_exists($part['quarantine']))Engine::remove($part['quarantine']);
                        $part['removed']=true;StateStore::put('retention-plans',$key,$state);
                    }
                    catch(\Throwable $e){$failed[]=['id'=>$item['id'],'remaining_component'=>basename($part['path'])];break;}
                }unset($part);
                if(!array_filter($item['parts'],static fn($p)=>!$p['removed'])){$item['status']='complete';StateStore::delete('backup-index',$item['id']);StateStore::put('retention-plans',$key,$state);}
            }unset($item);
            if(!$failed)$state['status']='complete';
            if(isset($state['criteria_input'])){try{$state['remaining_eligible']=self::candidates($state['criteria_input'])['total'];$state['has_more']=$state['remaining_eligible']>0;$state['next_cursor']=null;}catch(\Throwable $e){$state['remaining_eligible']=null;$state['has_more']=true;}}
            StateStore::put('retention-plans',$key,$state);
            return $failed?Result::fail('backup_prune_partial','Repita a mesma seleção para reconciliar componentes restantes.',self::public($state,false)+['failed'=>$failed,'pending'=>true]):Result::ok(self::public($state,false));
        });
    }
}
