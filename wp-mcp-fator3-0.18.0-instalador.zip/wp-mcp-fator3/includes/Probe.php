<?php
/** Anonymous same-origin evidence. A cache header alone never proves PHP execution. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Probe {
    public static function init(): void {
        add_action('init',[self::class,'instrument'],0);
        add_action('f3_mcp_cron_observed',static function(){ update_option('f3_mcp_last_cron_observed',time(),false); });
        add_action('init',static function(){ if(!wp_next_scheduled('f3_mcp_cron_observed'))wp_schedule_event(time()+300,'hourly','f3_mcp_cron_observed'); });
    }
    private static function secret(): string { return wp_salt('auth'); }
    public static function instrument(): void {
        $nonce=$_SERVER['HTTP_X_F3_PROBE_NONCE']??'';$sig=$_SERVER['HTTP_X_F3_PROBE_SIGNATURE']??'';$stamp=$_SERVER['HTTP_X_F3_PROBE_TIME']??'';
        if(!preg_match('/^[a-f0-9]{32}$/D',$nonce)||!ctype_digit((string)$stamp)||abs(time()-(int)$stamp)>60||!hash_equals(hash_hmac('sha256',$nonce.'|'.$stamp,self::secret()),(string)$sig))return;
        if(!defined('DONOTCACHEPAGE'))define('DONOTCACHEPAGE',true);
        nocache_headers();
        $mark=static function()use($nonce){
            if(!headers_sent()) { header('X-F3-Probe-Executed: '.$nonce);header('X-F3-Probe-Generation-Ms: '.round((microtime(true)-(float)($_SERVER['REQUEST_TIME_FLOAT']??microtime(true)))*1000,3)); }
        };
        add_filter('rest_post_dispatch',static function($response)use($mark){$mark();return $response;},PHP_INT_MAX);
        ob_start(static function($body)use($mark){$mark();return $body;});
    }
    public static function register(): void {
        $assert=['type'=>'object','properties'=>['status'=>Registry::integer(100,599),'contains'=>Registry::string(),'not_contains'=>Registry::string(),'headers'=>['type'=>'object','additionalProperties'=>Registry::string()]],'additionalProperties'=>false];
        Registry::add('system/probe','Faz GET/HEAD anônimo à origem de home_url, sem cookies/Authorization. Asserções de status, corpo e cabeçalhos; hash do corpo e tempos com procedência. contexto_teste ou X-F3Base-Teste (0/1) marca somente a requisição enviada; omissão é nao_marcado, sem herdar cookies. Informa classe_trafego enviada, não comprova gravação pelo Core. Marca PHP novo para comprovar bypass; não prova acesso externo à hospedagem.', ['paths'=>['type'=>'array','items'=>['type'=>'object','properties'=>['path'=>Registry::string(),'method'=>['type'=>'string','enum'=>['GET','HEAD']],'assert'=>$assert],'required'=>['path'],'additionalProperties'=>false],'minItems'=>1,'maxItems'=>5],'headers'=>['type'=>'object','additionalProperties'=>Registry::string()],'contexto_teste'=>['type'=>'boolean','description'=>'Marca declarativa de teste; não concede permissão. Deve concordar com X-F3Base-Teste se ambos forem enviados. Omitido e sem cabeçalho: false.'],'samples'=>Registry::integer(1,3),'timeout_seconds'=>Registry::integer(1,10),'test_private_storage'=>Registry::boolean()],[],[self::class,'run'],'manage_options');
    }
    public static function defaults(): array {
        return [['path'=>(wp_parse_url(home_url('/'),PHP_URL_PATH)?:'/'),'assert'=>['status'=>200]],['path'=>self::relative(rest_url()),'assert'=>['status'=>200,'contains'=>'"namespaces"']]];
    }
    private static function relative(string $url): string { return (wp_parse_url($url,PHP_URL_PATH)?:'/').(($q=wp_parse_url($url,PHP_URL_QUERY))?'?'.$q:''); }
    private static function origin(string $url): string { $p=wp_parse_url($url);return strtolower(($p['scheme']??'').'://'.($p['host']??'')).':'.($p['port']??(($p['scheme']??'')==='https'?443:80)); }
    public static function run(array $input=[]): array {
        $paths=$input['paths']??self::defaults();$samples=(int)($input['samples']??1);$timeout=(int)($input['timeout_seconds']??5);
        if(!$paths||count($paths)>5||$samples<1||$samples>3||$timeout<1||$timeout>10)return Result::fail('probe_limits','Sonda excede limites de caminhos/amostras/tempo.');
        if(array_key_exists('contexto_teste',$input) && !is_bool($input['contexto_teste']))return Result::fail('probe_test_context_invalid','contexto_teste deve ser booleano.');
        $headers=[];$header_test=null;
        foreach($input['headers']??[] as $name=>$value) {
            $name=strtolower((string)$name);
            if(!in_array($name,['accept','accept-language','cache-control','pragma','x-f3base-teste'],true)||!is_string($value)||strlen($value)>1024||preg_match('/[\r\n\x00]/',$value))return Result::fail('probe_header_forbidden','Cabeçalho fora da allowlist ou inválido.');
            if(isset($headers[$name]) && $headers[$name]!==$value)return Result::fail('probe_header_conflict','Cabeçalho repetido com valores conflitantes.');
            if($name==='x-f3base-teste') {
                if(!in_array($value,['0','1'],true))return Result::fail('probe_test_context_invalid','X-F3Base-Teste aceita somente 0 ou 1.');
                $header_test=$value==='1';
            }
            $headers[$name]=$value;
        }
        if(array_key_exists('contexto_teste',$input)&&$header_test!==null&&$input['contexto_teste']!==$header_test)return Result::fail('probe_test_context_conflict','contexto_teste e X-F3Base-Teste devem concordar.');
        $test=$input['contexto_teste']??$header_test??false;
        $headers['x-f3base-teste']=$test?'1':'0';
        $traffic=['contexto_teste'=>$test,'classe_trafego'=>$test?'teste':'nao_marcado','traffic_class_scope'=>'outgoing_request'];
        foreach($paths as $spec) {
            $path=$spec['path']??'';$method=$spec['method']??'GET';
            if(!is_string($path)||!str_starts_with($path,'/')||str_starts_with($path,'//')||str_contains($path,'\\')||preg_match('/[\x00-\x20#]/',$path)||!in_array($method,['GET','HEAD'],true))return Result::fail('probe_path_invalid','Use caminho relativo à origem, sem fragmento, e GET/HEAD.');
            if($method==='HEAD'&&(isset($spec['assert']['contains'])||isset($spec['assert']['not_contains'])))return Result::fail('probe_assertion_invalid','HEAD não oferece corpo para asserção de conteúdo.');
        }
        $rows=[];$deadline=microtime(true)+25;
        foreach($paths as $spec)for($sample=0;$sample<$samples;$sample++) {
            if(microtime(true)>$deadline)return Result::fail('probe_budget_exceeded','Sonda atingiu o orçamento total.', $traffic+['samples'=>$rows,'status'=>'inconclusive']);
            $rows[]=$traffic+self::request($spec,$headers,$timeout,$deadline);
        }
        $passed=!array_filter($rows,static fn($r)=>!$r['passed']);$verified=!array_filter($rows,static fn($r)=>empty($r['cache_bypass_verified']));
        $result=Result::ok($traffic+['passed'=>$passed,'status'=>$passed?'passed':'failed','samples'=>$rows,'sample_count'=>count($rows),'cache_bypass_verified'=>$verified,'origin_scope'=>'internal_same_origin','external_access_proven'=>false]);
        if(!empty($input['test_private_storage']))$result['private_storage']=self::storage_test($test);
        return $result;
    }
    private static function request(array $spec,array $headers,int $timeout,?float $deadline=null): array {
        $home=wp_parse_url(home_url('/'));$base=$home['scheme'].'://'.$home['host'].(isset($home['port'])?':'.$home['port']:'');
        $nonce=bin2hex(random_bytes(16));$stamp=(string)time();$url=add_query_arg('_f3_probe',$nonce,$base.$spec['path']);$method=$spec['method']??'GET';
        $headers+=['cache-control'=>'no-cache','pragma'=>'no-cache'];$headers['X-F3-Probe-Nonce']=$nonce;$headers['X-F3-Probe-Time']=$stamp;$headers['X-F3-Probe-Signature']=hash_hmac('sha256',$nonce.'|'.$stamp,self::secret());
        $deadline=$deadline??microtime(true)+$timeout;$start=microtime(true);$response=null;$redirects=[];
        for($i=0;$i<4;$i++) {
            if(microtime(true)>=$deadline){$response=new \WP_Error('probe_budget_exceeded','Orçamento de sonda esgotado.');break;}
            // Deliberately no cookies, Authorization or caller session. Origin is fixed.
            $response=wp_remote_request($url,['method'=>$method,'headers'=>$headers,'cookies'=>[],'timeout'=>min($timeout,max(0.01,$deadline-microtime(true))),'redirection'=>0,'limit_response_size'=>1048577,'sslverify'=>true]);
            if(is_wp_error($response))break;
            $status=(int)wp_remote_retrieve_response_code($response);
            if(!in_array($status,[301,302,303,307,308],true))break;
            $location=(string)wp_remote_retrieve_header($response,'location');
            $next=\WP_Http::make_absolute_url($location,$url);
            if(self::origin($next)!==self::origin(home_url('/'))||wp_parse_url($next,PHP_URL_USER)||wp_parse_url($next,PHP_URL_PASS)) { $response=new \WP_Error('probe_redirect_forbidden','Redirecionamento saiu da origem.');break; }
            $redirects[]=$status;$url=$next;
        }
        $total=round((microtime(true)-$start)*1000,3);
        if(is_wp_error($response))return ['path'=>$spec['path'],'method'=>$method,'passed'=>false,'status'=>'inconclusive','error_code'=>$response->get_error_code(),'total_ms'=>$total,'ttfb_ms'=>null,'ttfb_reason'=>'Transporte WordPress não fornece TTFB separado.','generation_ms'=>null,'cache_status'=>'unknown','cache_bypass_verified'=>false,'assertions'=>[]];
        $status=(int)wp_remote_retrieve_response_code($response);$body=(string)wp_remote_retrieve_body($response);$truncated=strlen($body)>1048576;
        $assert=$spec['assert']??['status'=>200];$checks=[];
        if(isset($assert['status']))$checks[]=['type'=>'status','passed'=>$status===(int)$assert['status'],'expected'=>(int)$assert['status'],'actual'=>$status];
        if(isset($assert['contains']))$checks[]=['type'=>'contains','passed'=>!$truncated&&str_contains($body,$assert['contains'])];
        if(isset($assert['not_contains']))$checks[]=['type'=>'not_contains','passed'=>!$truncated&&!str_contains($body,$assert['not_contains'])];
        foreach($assert['headers']??[] as $name=>$value)$checks[]=['type'=>'header','name'=>$name,'passed'=>hash_equals((string)$value,(string)wp_remote_retrieve_header($response,$name))];
        $executed=hash_equals($nonce,(string)wp_remote_retrieve_header($response,'x-f3-probe-executed'));$ms=wp_remote_retrieve_header($response,'x-f3-probe-generation-ms');
        return ['path'=>$spec['path'],'method'=>$method,'passed'=>!$truncated&&!array_filter($checks,static fn($v)=>!$v['passed']),'status_code'=>$status,'assertions'=>$checks,'body_sha256'=>hash('sha256',$body),'body_bytes'=>strlen($body),'body_complete'=>!$truncated,'redirects'=>$redirects,'total_ms'=>$total,'ttfb_ms'=>null,'ttfb_reason'=>'Transporte WordPress não fornece TTFB separado.','generation_ms'=>$executed&&is_numeric($ms)?(float)$ms:null,'generation_scope'=>'bootstrap_and_response_preparation','cache_status'=>$executed?'bypass':'unknown','cache_bypass_verified'=>$executed,'cache_evidence'=>$executed?'fresh_signed_php_nonce':'no_execution_marker'];
    }
    public static function storage_test(bool $test=false): array {
        $dir=StateStore::directory();$content=wp_normalize_path(WP_CONTENT_DIR);$normalized=wp_normalize_path($dir);
        if(!str_starts_with($normalized,$content.'/'))return ['tested'=>false,'reason'=>'Armazenamento sem URL pública mapeável com segurança.'];
        $marker='f3-probe-'.bin2hex(random_bytes(16));$name=$marker.'.txt';$file=$dir.'/'.$name;
        if(file_put_contents($file,$marker)!==strlen($marker))return ['tested'=>false,'reason'=>'Marcador não pôde ser criado.'];
        try {
            $url=content_url(substr($normalized,strlen($content)).'/'.$name);
            if(self::origin($url)!==self::origin(home_url('/')))return ['tested'=>false,'reason'=>'Origem de conteúdo difere da origem da home.'];
            $r=self::request(['path'=>self::relative($url),'assert'=>['not_contains'=>$marker]],['x-f3base-teste'=>$test?'1':'0'],5);
            $passed=in_array($r['status_code']??0,[403,404],true)&&!empty($r['body_complete'])&&!empty($r['passed']);
            $evidence=['contexto_teste'=>$test,'classe_trafego'=>$test?'teste':'nao_marcado','traffic_class_scope'=>'outgoing_request','tested'=>true,'passed'=>$passed,'time'=>gmdate('c'),'scope'=>'private_storage_marker','fingerprint'=>hash('sha256',$normalized.'|'.home_url('/')),'status_code'=>$r['status_code']??null];
            StateStore::put('diagnostics','private-http',$evidence);return $evidence;
        } finally { if(is_file($file))unlink($file); }
    }
    public static function cron(): array {
        $due=0;$oldest=null;$now=time();foreach(_get_cron_array()?:[] as $time=>$hooks)if($time<$now) { foreach($hooks as $jobs)$due+=count($jobs);$oldest=$oldest===null?(int)$time:min($oldest,(int)$time); }
        $last=get_option('f3_mcp_last_cron_observed',null);
        return ['wp_cron_desabilitado'=>defined('DISABLE_WP_CRON')&&(bool)DISABLE_WP_CRON,'eventos_vencidos'=>$due,'atraso_maximo_seconds'=>$oldest===null?0:$now-$oldest,'ultimo_disparo'=>$last?gmdate('c',(int)$last):null,'escopo_ultimo_disparo'=>'Execução observada do marcador f3_mcp_cron_observed; não comprova todos os jobs.'];
    }
}
