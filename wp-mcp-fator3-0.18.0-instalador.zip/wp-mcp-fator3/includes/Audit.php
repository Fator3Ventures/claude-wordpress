<?php
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Audit {
    private static bool $write_failed=false;
    private static ?\WeakMap $denied_requests=null;
    /** WordPress can check permissions repeatedly to compute Allow/links. One row per request. */
    public static function transport_denied(\WP_REST_Request $request, string $code): bool {
        self::$denied_requests ??= new \WeakMap();
        if (isset(self::$denied_requests[$request])) return false;
        self::$denied_requests[$request] = true;
        // Never persist Authorization, cookies, query strings, IPs or request bodies here.
        self::record('mcp/access-denied', ['path'=>$request->get_route()], Result::fail($code, 'Acesso MCP recusado.'), 0);
        return true;
    }
    public static function record(string $name,array $input,array $result,int $duration): void {
        if(str_starts_with($name,'audit/')) return;
        try {
            $id=gmdate('YmdHis').'-'.bin2hex(random_bytes(8));
            $target=$input['path']??$input['destination']??$input['source']??$input['id']??$input['name']??$input['slug']??'';
            Persistence::put('audit',$id,['id'=>$id,'time'=>gmdate('c'),'user'=>get_current_user_id(),'connection_id'=>ConnectionContext::key(),'ability'=>$name,'target'=>is_scalar($target)?(string)$target:'','duration_ms'=>$duration,'success'=>$result['success']??true,'error_code'=>$result['error_code']??'','operation_id'=>$result['operation_id']??'','backup_id'=>$result['backup_id']??'','replayed'=>$result['replayed']??false],true);
        } catch(\Throwable $error) { self::$write_failed=true;try{StateStore::write(StateStore::directory('diagnostics').'/audit-failure.php',StateStore::HEADER.json_encode(['time'=>time(),'code'=>'audit_persistence_failed']));}catch(\Throwable $ignored){} }
    }
    public static function migrate(int $batch=200): array {
        $result=Locks::run(['audit-migration'=>LOCK_EX],static function() use($batch) {
            $state=StateStore::get('migration','audit')??['offset'=>0,'imported'=>0,'complete'=>false];
            if($state['complete']) return $state;
            $it=new \FilesystemIterator(StateStore::directory('audit'),\FilesystemIterator::SKIP_DOTS); $i=0;$read=0;
            foreach($it as $file) {
                if($i++<(int)$state['offset']) continue;
                if($read++>=$batch) break;
                $state['offset']=$i;
                if($file->isLink()||!$file->isFile()||$file->getSize()>65536||$file->getExtension()!=='php') continue;
                $raw=file_get_contents($file->getPathname());
                if(!str_starts_with($raw,StateStore::HEADER)) continue;
                $row=json_decode(substr($raw,strlen(StateStore::HEADER)),true);
                if(!is_array($row)||empty($row['id'])||(int)($row['site_id']??1)!==get_current_blog_id()) continue;
                if(Persistence::put('audit',(string)$row['id'],$row,true)) $state['imported']++;
            }
            if($read<=$batch) $state['complete']=true;
            StateStore::put('migration','audit',$state);return $state;
        });
        return is_array($result)?$result:['complete'=>false];
    }
    public static function status(): array {
        $path=StateStore::directory('diagnostics').'/audit-failure.php';$last=null;
        if(is_file($path)){$raw=file_get_contents($path);if(str_starts_with($raw,StateStore::HEADER))$last=json_decode(substr($raw,strlen(StateStore::HEADER)),true);}
        return ['current_request_write_failed'=>self::$write_failed,'last_failure'=>$last];
    }
    private static function migrate_option(): array {
        return Locks::run(['audit-option-migration'=>LOCK_EX],static function(){
            $state=StateStore::get('migration','audit-option')??['offset'=>0,'imported'=>0,'complete'=>false];if($state['complete'])return $state;
            $old=get_option('f3_mcp_files_audit',[]);if(!is_array($old))$old=[];$batch=array_slice($old,$state['offset'],100);
            foreach($batch as $row){$state['offset']++;if(!is_array($row))continue;$id='legacy-option-'.hash('sha256',serialize($row));
                $safe=['id'=>$id,'time'=>$row['time']??gmdate('c'),'user'=>(int)($row['user']??0),'ability'=>'legacy/'.(string)($row['action']??'unknown'),'target'=>(string)($row['path']??''),'backup_id'=>(string)($row['backup_id']??''),'success'=>true,'origin'=>'legacy-option','connection_id'=>'unknown'];
                if(Persistence::put('audit',$id,$safe,true))$state['imported']++;
            }
            $state['complete']=$state['offset']>=count($old);StateStore::put('migration','audit-option',$state);return $state;
        });
    }
    public static function listing(array $input): array {
        $migration=self::migrate();$migration['option']=self::migrate_option();$migration['complete']=!empty($migration['complete'])&&!empty($migration['option']['complete']);$filters=[];
        foreach(['user','connection_id','ability','target','operation_id','success'] as $key) if(isset($input[$key])) $filters[$key==='user'?'user_id':$key]=$input[$key];
        foreach(['since','until'] as $key) if(isset($input[$key])) { $t=strtotime($input[$key]);if(false===$t) return Result::fail('invalid_date','Use data ISO 8601.');$filters[$key]=$t; }
        $before=PHP_INT_MAX;
        if(!empty($input['cursor'])) { $cursor=Cursor::decode($input['cursor']); if(is_wp_error($cursor)) return Result::error($cursor); if(($cursor['kind']??'')!=='audit'||($cursor['connection']??'')!==ConnectionContext::key()||($cursor['filters']??'')!==hash('sha256',serialize($filters))) return Result::fail('cursor_invalid','Cursor não corresponde à conexão e filtros.');$before=(int)$cursor['before']; }
        $limit=max(1,min(200,(int)($input['per_page']??50)));$rows=Persistence::listing('audit',$filters,$limit+1,$before);$more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);
        $cursor=$more?Cursor::encode(['kind'=>'audit','connection'=>ConnectionContext::key(),'filters'=>hash('sha256',serialize($filters)),'before'=>end($rows)['_row_id']]):null;
        foreach($rows as &$row) unset($row['_row_id']);unset($row);
        return Result::ok(['entries'=>$rows,'has_more'=>$more,'next_cursor'=>$cursor,'history_complete'=>!empty($migration['complete']),'migration'=>$migration]);
    }
    public static function prune(array $input): array {
        return StateMaintenance::run(array_replace($input,['category'=>'audit']));
    }
}
