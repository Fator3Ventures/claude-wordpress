<?php
/** Explicit term identity, bounded preimage, two phases and database readback. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class TaxonomyTerms {
    public static function register(): void {
        Registry::add('content/delete-term','Exclui um termo e somente suas relações, inclusive relações com posts inexistentes. Duas fases com confirm_token, backup e releitura. Informe taxonomy e exatamente um de term_id/term_taxonomy_id. Taxonomia ausente exige allow_unregistered:true e object_type:post; Relações com posts existentes impedem exclusão. Termos padrão, compartilhados ou com filhos são protegidos.',[
            'taxonomy'=>Registry::string(),'term_id'=>Registry::integer(1),'term_taxonomy_id'=>Registry::integer(1),'confirm_token'=>Registry::string(),'allow_unregistered'=>Registry::boolean(),'object_type'=>['type'=>'string','enum'=>['post']],
        ],['taxonomy'],[self::class,'delete'],[ConnectionTools::class,'permission'],false);
    }
    private static function rows(string $sql): array {global $wpdb;return Persistence::rows($sql);}
    private static function snapshot(array $i,bool $lock=false) {
        global $wpdb;$tax=(string)($i['taxonomy']??'');
        if($tax===''||strlen($tax)>32||sanitize_key($tax)!==$tax||isset($i['term_id'])===isset($i['term_taxonomy_id']))return new \WP_Error('term_identity_invalid','Informe taxonomy e exatamente um de term_id ou term_taxonomy_id.');
        $registered=taxonomy_exists($tax);$t=$registered?get_taxonomy($tax):null;
        if($registered&&!current_user_can($t->cap->delete_terms))return new \WP_Error('permission_denied','Capacidade nativa de exclusão da taxonomia necessária.');
        if(!$registered&&(empty($i['allow_unregistered'])||($i['object_type']??'')!=='post'))return new \WP_Error('taxonomy_unregistered','Taxonomia ausente exige allow_unregistered:true e object_type:post explícitos.');
        if($registered)foreach($t->object_type as $ot)if(!post_type_exists($ot))return new \WP_Error('term_object_type_unsupported','Esta rota trata relações com posts; tipo de objeto desconhecido.');
        $field=isset($i['term_id'])?'term_id':'term_taxonomy_id';$suffix=$lock?' FOR UPDATE':'';
        $rows=self::rows($wpdb->prepare("SELECT * FROM `$wpdb->term_taxonomy` WHERE taxonomy=%s AND `$field`=%d".$suffix,$tax,(int)$i[$field]));
        if(count($rows)!==1)return new \WP_Error('term_not_found','Identidade não corresponde a um termo da taxonomia informada.');
        $tt=$rows[0];$id=(int)$tt['term_id'];$tid=(int)$tt['term_taxonomy_id'];
        $term=self::rows($wpdb->prepare("SELECT * FROM `$wpdb->terms` WHERE term_id=%d".$suffix,$id));
        if(count($term)!==1)return new \WP_Error('term_corrupt','Linha do termo ausente; exige reconciliação específica.');
        if(($tax==='category'&&(int)get_option('default_category')===$id)||(int)get_option('default_term_'.$tax,0)===$id)return new \WP_Error('term_protected','Termo padrão não pode ser excluído.');
        $shared=self::rows($wpdb->prepare("SELECT term_taxonomy_id FROM `$wpdb->term_taxonomy` WHERE term_id=%d ORDER BY term_taxonomy_id".$suffix,$id));
        if(count($shared)>1)return new \WP_Error('term_shared','Termo compartilhado entre taxonomias; separe sua identidade antes de excluir.');
        $children=self::rows($wpdb->prepare("SELECT term_taxonomy_id FROM `$wpdb->term_taxonomy` WHERE taxonomy=%s AND parent=%d LIMIT 1".$suffix,$tax,$id));
        if($children)return new \WP_Error('term_has_children','Realoque ou exclua os filhos explicitamente antes deste termo.');
        $rel=self::rows($wpdb->prepare("SELECT * FROM `$wpdb->term_relationships` WHERE term_taxonomy_id=%d ORDER BY object_id LIMIT 1001".$suffix,$tid));
        $meta=self::rows($wpdb->prepare("SELECT * FROM `$wpdb->termmeta` WHERE term_id=%d ORDER BY meta_id LIMIT 1001".$suffix,$id));
        if(count($rel)>1000||count($meta)>1000)return new \WP_Error('term_preimage_limit','Seleção excede 1000 relações ou metadados.');
        $existing=[];foreach($rel as $v){$posts=self::rows($wpdb->prepare("SELECT ID,post_type FROM `$wpdb->posts` WHERE ID=%d".$suffix,(int)$v['object_id']));if($posts)$existing[]=$posts[0];}
        if($existing)return new \WP_Error('term_in_use','Existem posts associados; realoque suas relações pelo provedor antes de excluir.',['objects'=>count($existing)]);
        $s=['contract'=>'term-deletion/1','site_id'=>get_current_blog_id(),'registered'=>$registered,'term'=>$term[0],'term_taxonomy'=>$tt,'termmeta'=>$meta,'relationships'=>$rel,'existing_posts'=>$existing];
        if(strlen(serialize($s))>4*1024*1024)return new \WP_Error('term_preimage_limit','Pré-imagem excede 4 MiB.');return $s;
    }
    private static function summary(array $s): array {
        return ['taxonomy'=>$s['term_taxonomy']['taxonomy'],'term_id'=>(int)$s['term']['term_id'],'term_taxonomy_id'=>(int)$s['term_taxonomy']['term_taxonomy_id'],'registered'=>$s['registered'],'relationships'=>count($s['relationships']),'orphan_post_relationships'=>count($s['relationships'])-count($s['existing_posts']),'existing_posts'=>count($s['existing_posts']),'preimage_sha256'=>hash_hmac('sha256',serialize($s),wp_salt('auth'))];
    }
    public static function delete(array $i): array {
        if(!ConnectionTools::permission())return Result::fail('permission_denied','Exige Manutenção e manage_options.');
        return Locks::run(['taxonomy-terms:'.get_current_blog_id()=>LOCK_EX],static function()use($i){
            return Phase::run('content/delete-term',$i,static function()use($i){$s=self::snapshot($i);return is_wp_error($s)?$s:self::summary($s);},static function($before)use($i){
                global $wpdb;$s=self::snapshot($i);if(is_wp_error($s))return Result::error($s);
                if(self::summary($s)!==$before)return Result::fail('preimage_conflict','Termo mudou antes do backup.',['conflict'=>true]);
                foreach([$wpdb->terms,$wpdb->term_taxonomy,$wpdb->term_relationships,$wpdb->termmeta] as $table){$engine=$wpdb->get_var($wpdb->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s',$table));if($engine!=='InnoDB')return Result::fail('term_transaction_unavailable','As quatro tabelas de taxonomia precisam ser InnoDB.');}
                $backup=Backups::create_snapshot('content/delete-term',$s);if(is_wp_error($backup))return Result::error($backup);
                $id=$before['term_id'];$tid=$before['term_taxonomy_id'];$tax=$before['taxonomy'];
                try{$r=Persistence::transaction(static function()use($i,$before,$id,$tid,$tax,$wpdb){
                    $fresh=self::snapshot($i,true);if(is_wp_error($fresh))return $fresh;
                    if(self::summary($fresh)!==$before)return new \WP_Error('preimage_conflict','Termo ou relações mudaram desde o backup.');
                    // Only empty terms or relations to missing posts are eligible. No content reassignments.
                    foreach([[$wpdb->term_relationships,'term_taxonomy_id',$tid],[$wpdb->termmeta,'term_id',$id],[$wpdb->term_taxonomy,'term_taxonomy_id',$tid],[$wpdb->terms,'term_id',$id]] as [$table,$field,$value])Persistence::query($wpdb->prepare("DELETE FROM `$table` WHERE `$field`=%d",$value));
                    $remaining=[];foreach([[$wpdb->terms,'term_id',$id],[$wpdb->term_taxonomy,'term_taxonomy_id',$tid],[$wpdb->term_relationships,'term_taxonomy_id',$tid],[$wpdb->termmeta,'term_id',$id]] as [$t,$k,$v]){$remaining[$k.'@'.$t]=(int)Persistence::rows($wpdb->prepare("SELECT COUNT(*) n FROM `$t` WHERE `$k`=%d",$v))[0]['n'];}
                    if(array_sum($remaining)!==0)throw new \RuntimeException('readback_conflict');return Result::ok(['changed'=>true,'persisted'=>true,'readback'=>['term_absent'=>true,'term_taxonomy_absent'=>true,'relationships_absent'=>true,'termmeta_absent'=>true]]);
                });}catch(\Throwable $e){$r=Result::fail('term_deletion_failed','Exclusão não confirmada; transação revertida.',['applied'=>false]);}
                if(is_array($r)&&!empty($r['success'])){foreach([[$wpdb->terms,'term_id',$id],[$wpdb->term_taxonomy,'term_taxonomy_id',$tid],[$wpdb->term_relationships,'term_taxonomy_id',$tid],[$wpdb->termmeta,'term_id',$id]] as [$table,$field,$value]){ $count=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `$table` WHERE `$field`=%d",$value));if($wpdb->last_error||(int)$count!==0){$r=Result::fail('term_readback_conflict','Releitura após commit divergiu; confira o alvo antes de repetir.',['applied'=>null]);break;}}}
                wp_cache_delete($id,'terms');wp_cache_delete($id,'term_meta');if(taxonomy_exists($tax))clean_term_cache($id,$tax);wp_cache_set_terms_last_changed();
                return (is_wp_error($r)?Result::error($r):$r)+['backup_id'=>$backup,'term_id'=>$id,'term_taxonomy_id'=>$tid,'taxonomy'=>$tax,'deletion_hooks_invoked'=>false];
            });
        });
    }
}
