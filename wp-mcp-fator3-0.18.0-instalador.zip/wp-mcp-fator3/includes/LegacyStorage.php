<?php
/** Retirement concerns backup storage only; transport aliases remain active. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class LegacyStorage {
    public static function root(): string {return rtrim(wp_normalize_path(WP_CONTENT_DIR),'/').'/f3-mcp-backups';}
    private const INDEX="<?php http_response_code(404); header('Cache-Control: no-store'); exit;\n";
    private const HT="# Fator3 MCP legacy storage protection 1\n<IfModule mod_rewrite.c>\nRewriteEngine On\nRewriteRule ^ - [R=404,L]\n</IfModule>\n<IfModule !mod_rewrite.c>\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n</IfModule>\n";
    public static function register(): void {
        Registry::add('backups/legacy-status','Inventário do diretório legado, proteção local e impedimentos à retirada. Alias MCP não depende desta pasta. test_http verifica 404 em sondas marcadas.', ['test_http'=>Registry::boolean()],[],[self::class,'status'],'manage_options');
        Registry::add('backups/legacy-retire','Retira somente diretórios legados vazios e seus arquivos de proteção gerenciados, em duas fases. Conteúdo desconhecido ou backups impedem retirada. Não remove aliases ou sessões.', ['confirm_token'=>Registry::string()],[],[self::class,'retire'],[ConnectionTools::class,'permission'],false);
    }
    public static function base(array $meta): string {
        $id=(string)($meta['id']??'');$rel=(string)($meta['legacy_relative']??$id);
        if(!preg_match('/^(?:db)?[a-f0-9]{16,64}$/iD',$id)||!in_array($rel,[$id,'nomeados/'.$id],true))throw new \RuntimeException('legacy_identity_invalid');
        if(is_link(self::root())||is_link(dirname(self::root().'/'.$rel)))throw new \RuntimeException('legacy_linked_directory');
        return self::root().'/'.$rel;
    }
    public static function ensure(): array {
        $r=Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static fn()=>self::protect());
        return isset($r['protected'])?$r:['present'=>is_dir(self::root()),'changed'=>false,'protected'=>false,'errors'=>['protection_busy']];
    }
    private static function protect(): array {
        $out=['present'=>is_dir(self::root()),'changed'=>false,'protected'=>true,'errors'=>[]];
        foreach([self::root(),self::root().'/nomeados'] as $dir){
            if(is_link(self::root())||is_link($dir)){$out['errors'][]='linked_directory';continue;}
            if(!is_dir($dir))continue;
            foreach(['.htaccess'=>self::HT,'index.php'=>self::INDEX] as $name=>$bytes){
                $path=$dir.'/'.$name;
                if(is_link($path)){$out['errors'][]='linked_protection_file';continue;}
                $old=is_file($path)?file_get_contents($path):null;if($old===$bytes){if(!chmod($path,0644))$out['errors'][]='protection_permissions_failed';continue;}
                // Only replace recognized package rules. Unknown configuration remains intact and visible.
                $known=$old===null||($name==='index.php'&&preg_match('/^<\?php\s*(?:(?:\/\/[^\n]*\n)|\s)*(?:exit;\s*\?>\s*)?$/D',(string)$old))||($name==='.htaccess'&&in_array(trim((string)$old),['Require all denied',"Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>","<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>"],true));
                if(!$known){$out['errors'][]='unmanaged_protection_file:'.basename($dir).'/'.$name;continue;}
                try{StateStore::write($path,$bytes);if(!chmod($path,0644))throw new \RuntimeException();if(file_get_contents($path)!==$bytes)throw new \RuntimeException();$out['changed']=true;}catch(\Throwable $e){$out['errors'][]='protection_write_failed';}
            }
        }
        $out['protected']=!$out['errors'];return $out;
    }
    private static function snapshot(): array {
        $out=['present'=>is_dir(self::root()),'directories'=>[],'entries'=>[],'blocked'=>[]];
        if(is_multisite())$out['blocked'][]='shared_multisite_storage';
        foreach([self::root(),self::root().'/nomeados'] as $dir){
            if(is_link(self::root())||is_link($dir)){$out['blocked'][]='linked_directory';continue;}
            if(!is_dir($dir))continue;$out['directories'][]=basename($dir);
            foreach(new \FilesystemIterator($dir,\FilesystemIterator::SKIP_DOTS) as $f){
                if($dir===self::root()&&$f->getFilename()==='nomeados'&&$f->isDir()&&!$f->isLink())continue;
                $rel=($dir===self::root()?'':'nomeados/').$f->getFilename();
                if(count($out['entries'])>=1000){$out['blocked'][]='inventory_limit';break;}
                $managed=isset(['.htaccess'=>true,'index.php'=>true][$f->getFilename()])&&!$f->isLink()&&$f->isFile()&&$f->getSize()<4096;
                $hash=$managed?hash_file('sha256',$f->getPathname()):null;
                $managed=$managed&&$hash===hash('sha256',$f->getFilename()==='index.php'?self::INDEX:self::HT);
                $out['entries'][$rel]=['managed_protection'=>$managed,'sha256'=>$hash];
                if(!$managed)$out['blocked'][]=$rel;
            }
        }
        ksort($out['entries']);sort($out['blocked']);$out['retirable']=$out['present']&&!$out['blocked'];return $out;
    }
    public static function status(array $i=[]): array {
        return Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static function()use($i){
            $p=self::ensure();$s=self::snapshot();$out=Result::ok(['legacy_storage'=>$s,'protection'=>$p,'transport_alias_preserved'=>true]);
            if(!empty($i['test_http'])&&$s['present']){
                $paths=[];foreach($s['directories'] as $dir)$paths[]=['path'=>(string)wp_parse_url(content_url('/f3-mcp-backups/'.($dir==='nomeados'?'nomeados/':'')),PHP_URL_PATH),'assert'=>['status'=>404]];
                $out['http']=Probe::run(['contexto_teste'=>true,'paths'=>$paths]);
            }
            return $out;
        });
    }
    public static function retire(array $i): array {
        if(!ConnectionTools::permission())return Result::fail('permission_denied','Exige Manutenção e manage_options.');
        return Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static function()use($i){
            return Phase::run('backups/legacy-retire',$i,static function(){
                $s=self::snapshot();if($s['blocked'])return new \WP_Error('legacy_storage_not_empty','Há conteúdo, configuração não gerenciada ou armazenamento compartilhado; nada removido.',['blocked'=>$s['blocked']]);return $s;
            },static function($s){
                if(!$s['present'])return Result::ok(['changed'=>false,'present'=>false,'transport_alias_preserved'=>true]);
                // Record metadata only; no user backup is deleted by retirement.
                $backup=Backups::create_snapshot('backups/legacy-retire',$s);if(is_wp_error($backup))return Result::error($backup);
                try{
                    foreach(array_reverse($s['directories']) as $d){$dir=self::root().($d==='nomeados'?'/nomeados':'');
                        foreach(['.htaccess','index.php'] as $f)if(is_file($dir.'/'.$f)&&!unlink($dir.'/'.$f))throw new \RuntimeException();
                        if(!rmdir($dir))throw new \RuntimeException();
                    }
                }catch(\Throwable $e){self::ensure();return Result::fail('legacy_retirement_incomplete','Retirada incompleta; proteção reaplicada aos diretórios restantes.',['backup_id'=>$backup,'applied'=>null]);}
                clearstatcache();return Result::ok(['changed'=>true,'persisted'=>!is_dir(self::root()),'present'=>is_dir(self::root()),'backup_id'=>$backup,'transport_alias_preserved'=>true]);
            });
        });
    }
}
