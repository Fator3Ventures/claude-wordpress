<?php
declare(strict_types=1);
namespace Fator3\McpFiles;
use Fator3\RecoveryV1\Engine;
final class ArchiveTools {
    public static function register(): void {
        $p=['source'=>Registry::string(),'destination'=>Registry::string(),'overwrite'=>Registry::boolean(),'expected_sha256'=>Registry::string(),'expected_destination_sha256'=>Registry::string(),'label'=>Registry::string(),'rotulo'=>Registry::string()];
        Registry::add('files/archive','Compacta arquivo/diretório em ZIP, com locks de origem/destino, backup e hash. Links/special files são recusados. O ZIP contém a pasta/nome de origem.',$p,['source','destination'],[self::class,'archive'],[FileTools::class,'permission'],false);
        Registry::add('files/extract','Extrai ZIP em staging, valida caminhos/CRC/expansão, preserva pré-imagem e substitui destino com recuperação. overwrite:true substitui a árvore inteira; não mescla silenciosamente.',$p,['source','destination'],[self::class,'extract'],[FileTools::class,'permission'],false);
        Registry::add('files/rollback-tree','Restaura pré-imagem de extração/compactação por backup, recusando destino alterado.',['backup_id'=>Registry::string()],['backup_id'],[self::class,'rollback'],[FileTools::class,'permission'],false);
    }
    public static function install(string $source,string $target,array $extra=[]): array {
        $manifest=Engine::manifest($source);$runtime=false;foreach($manifest['files']??[] as $name=>$entry)if(empty($entry['directory'])&&Recovery::runtime_path($manifest['kind']==='file'?$target:$name))$runtime=true;
        $before=$runtime?Probe::run(['contexto_teste'=>true]):null;if($runtime&&!Recovery::verified($before))return Result::fail('tree_baseline_failed','Sonda inicial não aprovou a árvore PHP; destino preservado.');
        $expected=Engine::digest($manifest);$op=Recovery::begin($target,$expected,$extra+['tree_operation'=>true]);
        try{Engine::prepare_install($op['file'],$source);Engine::commit_install($op['file']);Recovery::close($op,'applied');
            $probe=$runtime?Probe::run(['contexto_teste'=>true]):null;if($runtime&&!Recovery::verified($probe)){$recovery=Engine::restore($op['file'],true);return Result::fail('tree_probe_failed','Sonda não aprovou a árvore PHP.',['backup_id'=>$op['state']['backup_id'],'recovery'=>$recovery,'applied'=>$recovery['status']==='rolled_back'?false:null]);}
            Recovery::close($op,'complete');return Result::ok(['changed'=>true,'backup_id'=>$op['state']['backup_id'],'journal_id'=>$op['state']['id'],'tree_sha256'=>$expected,'path'=>$target,'probe_tested'=>$runtime,'probe_after'=>$probe]);}
        catch(\Throwable $e){$recovery=Engine::restore($op['file'],true);return Result::fail('tree_install_failed','Troca da árvore não concluída.',['backup_id'=>$op['state']['backup_id'],'recovery'=>$recovery,'applied'=>$recovery['status']==='rolled_back'?false:null]);}
        finally{Recovery::release($op);}
    }
    private static function paths(array $i,callable $run): array {
        foreach(['source','destination'] as $key){$p=PathGuard::resolve($i[$key],$key==='destination');if(is_wp_error($p))return Result::error($p);$i[$key]=$p;}
        if($i['source']===$i['destination']||str_starts_with($i['destination'].'/',$i['source'].'/'))return Result::fail('archive_path_conflict','Destino não pode estar dentro da origem.');
        return Locks::files([$i['source'],$i['destination']],static function()use($i,$run){
            if(file_exists($i['destination'])&&empty($i['overwrite']))return Result::fail('destination_exists','overwrite:true necessário.');
            foreach(['source'=>'expected_sha256','destination'=>'expected_destination_sha256'] as $path=>$field)if(isset($i[$field])){$actual=is_file($i[$path])?hash_file('sha256',$i[$path]):Engine::digest(Engine::manifest($i[$path]));if($actual!==$i[$field])return Result::fail('file_conflict','Hash diverge.',['conflict'=>true]);}
            return $run($i);
        });
    }
    public static function archive(array $i): array {return self::paths($i,static function($i){
        Engine::manifest($i['source']);if(!is_dir(dirname($i['destination'])))return Result::fail('destination_parent_missing','Crie o diretório de destino.');
        require_once ABSPATH.'wp-admin/includes/class-pclzip.php';$temp=StateStore::directory('archive-staging').'/'.bin2hex(random_bytes(16)).'.zip';
        try{$zip=new \PclZip($temp);$r=$zip->create($i['source'],PCLZIP_OPT_REMOVE_PATH,dirname($i['source']));if(!$r)return Result::fail('archive_create_failed','Falha ao gerar ZIP.');if(filesize($temp)>PathGuard::max_bytes())return Result::fail('file_size_limit','ZIP supera limite configurado.');$hash=hash_file('sha256',$temp);return Backups::labelled($i,static fn()=>self::install($temp,$i['destination']))+['sha256'=>$hash,'bytes'=>filesize($temp)];}
        finally{if(is_file($temp))unlink($temp);}
    });}
    public static function extract(array $i): array {return self::paths($i,static function($i){
        $temp=StateStore::directory('archive-staging').'/'.bin2hex(random_bytes(16));mkdir($temp,0700);
        try{$entries=ZipPackage::extract($i['source'],$temp);return Backups::labelled($i,static fn()=>self::install($temp,$i['destination']))+['entry_count'=>count($entries)];}
        catch(\Throwable $e){return Result::fail('archive_invalid','ZIP inválido: caminho, CRC, tipo ou expansão.');}finally{Engine::remove($temp);}
    });}
    public static function rollback(array $i): array {
        $meta=Backups::metadata($i['backup_id']);if(is_wp_error($meta))return Result::error($meta);$id=$meta['snapshot']['journal_id']??'';if(!preg_match('/^[a-f0-9]{32}$/D',$id))return Result::fail('backup_type_mismatch','Backup não contém árvore recuperável.');
        $file=Recovery::directory().'/'.$id.'.journal.php';$s=Engine::read($file);if(!$s||empty($s['tree_operation']))return Result::fail('backup_type_mismatch','Use a rota de rollback de pacote.');
        return Locks::files([$s['target']],static function()use($file,$s){if(Engine::digest(Engine::manifest($s['target']))!==$s['after_sha256'])return Result::fail('rollback_conflict','Árvore alterada.',['conflict'=>true]);$s['status']='applied';Engine::write($file,$s);$r=Engine::restore($file,true);return $r['status']==='rolled_back'?Result::ok(['changed'=>true,'recovery'=>$r]):Result::fail('rollback_failed','Restauração não concluída.',['recovery'=>$r]);});
    }
}
