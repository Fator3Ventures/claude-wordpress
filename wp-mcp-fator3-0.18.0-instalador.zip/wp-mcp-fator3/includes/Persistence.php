<?php
/** Durable state. SQL transactions are never held across HTTP or file effects. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Persistence {
	private static ?\mysqli $transaction_connection = null;
	private const TABLES = ['clients','grants','authorization_codes','tokens','legacy_sessions','idempotency','audit','operations','operation_steps','migration_checkpoints','state'];
	private const BUCKETS = ['oauth-clients'=>'clients','oauth-grants'=>'grants','oauth-codes'=>'authorization_codes','oauth-tokens'=>'tokens','sessions'=>'legacy_sessions','idempotency'=>'idempotency','audit'=>'audit','plans'=>'operations','steps'=>'operation_steps','migration'=>'migration_checkpoints'];
	public static function client_index(string $client): string { return strlen($client)>191 ? 'sha256:'.hash('sha256',$client) : $client; }
    public static function table(string $bucket): string {
		global $wpdb;
		return $wpdb->prefix . 'f3_mcp_' . (self::BUCKETS[$bucket] ?? 'state');
	}
	public static function install(): void {
		global $wpdb;
		if (2 === (int)get_option('f3_mcp_schema_version', 0)) return;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		foreach (self::TABLES as $suffix) {
			$table = $wpdb->prefix . 'f3_mcp_' . $suffix;
			dbDelta("CREATE TABLE {$table} (
				id bigint unsigned NOT NULL AUTO_INCREMENT,
				record_key char(64) NOT NULL,
				bucket varchar(64) NOT NULL,
				user_id bigint unsigned NOT NULL DEFAULT 0,
				client_id varchar(191) NOT NULL DEFAULT '',
				grant_id varchar(64) NOT NULL DEFAULT '',
				connection_id varchar(191) NOT NULL DEFAULT '',
				status varchar(32) NOT NULL DEFAULT 'active',
				ability varchar(191) NOT NULL DEFAULT '',
				target varchar(191) NOT NULL DEFAULT '',
				label varchar(128) NOT NULL DEFAULT '',
				kind varchar(32) NOT NULL DEFAULT '',
				stored_bytes bigint unsigned NOT NULL DEFAULT 0,
				operation_id varchar(64) NOT NULL DEFAULT '',
				success tinyint NOT NULL DEFAULT 1,
				created_at bigint unsigned NOT NULL,
				updated_at bigint unsigned NOT NULL,
				expires_at bigint unsigned NOT NULL DEFAULT 0,
				consumed_at bigint unsigned DEFAULT NULL,
				revision bigint unsigned NOT NULL DEFAULT 1,
				payload longtext NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY record_key (record_key),
				KEY bucket_user (bucket,user_id,id),
				KEY client_status (client_id,status),
				KEY grant_status (grant_id,status),
				KEY connection_status (connection_id,status),
				KEY expiration (expires_at),
				KEY time_id (created_at,id),
				KEY ability_id (ability,id),
				KEY operation_id (operation_id),
				KEY target_id (target,id),
				KEY label_time (label,created_at,id)
			) ENGINE=InnoDB {$wpdb->get_charset_collate()};");
			$engine = $wpdb->get_var($wpdb->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s', $table));
			if ('innodb' !== strtolower((string)$engine)) throw new \RuntimeException('MCP persistence requires verified InnoDB tables.');
            $indexes=$wpdb->get_results("SHOW INDEX FROM `$table`",ARRAY_A);
            $actual=[];foreach($indexes as $index)$actual[$index['Key_name']][(int)$index['Seq_in_index']]=$index['Column_name'];
            foreach(['PRIMARY'=>['id'],'record_key'=>['record_key'],'bucket_user'=>['bucket','user_id','id'],'client_status'=>['client_id','status'],'grant_status'=>['grant_id','status'],'connection_status'=>['connection_id','status'],'expiration'=>['expires_at'],'time_id'=>['created_at','id']] as $name=>$columns){if(!isset($actual[$name])||array_values($actual[$name])!==$columns)throw new \RuntimeException('MCP persistence index verification failed.');}
		}
		add_option('f3_mcp_policy_installed_at', time(), '', false);
		update_option('f3_mcp_schema_version', 2, false);
	}
	public static function hash(string $bucket, string $key): string { return hash('sha256', get_current_blog_id() . '|' . $bucket . '|' . $key); }
	public static function get(string $bucket, string $key, bool $for_update = false): ?array {
		global $wpdb;
		$table = self::table($bucket);
		$row = self::rows($wpdb->prepare("SELECT * FROM {$table} WHERE record_key=%s" . ($for_update ? ' FOR UPDATE' : ''), self::hash($bucket, $key)))[0]??null;
		if ($wpdb->last_error) throw new \RuntimeException('MCP state read failed.');
		if (!$row) return null;
		$value = json_decode($row['payload'], true, 512, JSON_THROW_ON_ERROR);
		$value['_storage'] = array_diff_key($row, ['payload'=>true]);
		return $value;
	}
	public static function put(string $bucket, string $key, array $value, bool $insert_only = false): bool {
		global $wpdb;
		unset($value['_storage']);
		$now = time(); $time = $value['time'] ?? $now;
		$time = is_numeric($time) ? (int)$time : (strtotime((string)$time) ?: $now);
		$data = ['record_key'=>self::hash($bucket, $key), 'bucket'=>$bucket, 'user_id'=>(int)($value['user_id'] ?? $value['user'] ?? $value['owner'] ?? get_current_user_id()), 'client_id'=>self::client_index((string)($value['client_id'] ?? '')), 'grant_id'=>(string)($value['grant_id'] ?? ''), 'connection_id'=>(string)($value['connection_id'] ?? ''), 'status'=>(string)($value['status'] ?? 'active'), 'ability'=>(string)($value['ability'] ?? ''), 'target'=>substr((string)($value['target'] ?? ''), 0, 191), 'label'=>(string)($value['label']??''), 'kind'=>(string)($value['kind']??''), 'stored_bytes'=>(int)($value['stored_bytes']??0), 'operation_id'=>(string)($value['operation_id'] ?? ''), 'success'=>(int)($value['success'] ?? true), 'created_at'=>$time, 'updated_at'=>$now, 'expires_at'=>(int)($value['expires'] ?? 0), 'payload'=>json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE)];
		$table = self::table($bucket);
        if ($insert_only) {
            $sql="INSERT INTO {$table} (".implode(',',array_keys($data)).") VALUES (".implode(',',array_fill(0,count($data),'%s')).")";
            $old=$wpdb->suppress_errors(true);
            try {
                if(self::$transaction_connection) {
                    try { $ok=self::query($wpdb->prepare($sql,array_values($data))); }
                    catch(\Throwable $e) {
                        if(mysqli_errno(self::$transaction_connection)!==1062)throw $e;
                        return false;
                    }
                } else $ok=self::query($wpdb->prepare($sql,array_values($data)));
                if(false===$ok) { if(self::get($bucket,$key))return false;throw new \RuntimeException('MCP state insert failed.'); }
                return true;
            } finally { $wpdb->suppress_errors($old); }
        }
		$columns = array_keys($data); $values = array_values($data);
		$update = []; foreach ($columns as $column) if (!in_array($column, ['record_key','created_at'], true)) $update[] = "{$column}=VALUES({$column})";
		$sql = "INSERT INTO {$table} (" . implode(',', $columns) . ') VALUES (' . implode(',', array_fill(0, count($values), '%s')) . ') ON DUPLICATE KEY UPDATE ' . implode(',', $update) . ',revision=revision+1';
		if (false === self::query($wpdb->prepare($sql, $values))) throw new \RuntimeException('MCP state write failed.');
		return true;
	}
	/** A tombstone prevents legacy files/cache from resurrecting consumed state. */
	public static function delete(string $bucket, string $key): bool {
		return self::put($bucket, $key, ['status'=>'deleted', 'time'=>time()]);
	}
	public static function consume(string $bucket, string $key): bool {
		global $wpdb; $table = self::table($bucket);
		$n = self::query($wpdb->prepare("UPDATE {$table} SET consumed_at=%d,status='consumed',revision=revision+1 WHERE record_key=%s AND consumed_at IS NULL AND status='active' AND (expires_at=0 OR expires_at>%d)", time(), self::hash($bucket,$key), time()));
		if (false === $n) throw new \RuntimeException('MCP state consumption failed.');
		return 1 === $n;
	}
    /** Transaction queries use the pinned native connection. wpdb may reconnect/replay
     * failed statements, which would silently turn a lost transaction into autocommit. */
    public static function query(string $sql) {
        global $wpdb;
        if (!self::$transaction_connection) return $wpdb->query($sql);
        if ($wpdb->dbh !== self::$transaction_connection) throw new \RuntimeException('State transaction connection changed.');
        $wpdb->last_error='';
        try { $result=mysqli_query(self::$transaction_connection,$sql); }
        catch(\Throwable $e) { throw new \RuntimeException('State transaction statement failed.'); }
        if (false===$result) throw new \RuntimeException('State transaction statement failed.');
        return $result instanceof \mysqli_result ? $result : mysqli_affected_rows(self::$transaction_connection);
    }
    public static function rows(string $sql): array {
        global $wpdb;
        if (!self::$transaction_connection) {
            $rows=$wpdb->get_results($sql,ARRAY_A);
            if($wpdb->last_error)throw new \RuntimeException('MCP state query failed.');
            return $rows?:[];
        }
        $result=self::query($sql);
        if(!$result instanceof \mysqli_result)throw new \RuntimeException('MCP state result unavailable.');
        try { return mysqli_fetch_all($result,MYSQLI_ASSOC); } finally { mysqli_free_result($result); }
    }
    /** Database-only callback: no filesystem or HTTP side effects while holding this transaction. */
    public static function transaction(callable $callback) {
        global $wpdb;
        if (self::$transaction_connection) throw new \RuntimeException('Nested state transaction refused.');
        if (!($wpdb->dbh instanceof \mysqli))throw new \RuntimeException('State transactions require mysqli.');
        $connection=$wpdb->dbh;
        self::$transaction_connection=$connection;
        try {
            self::query('START TRANSACTION');
            $result=$callback();
            if (is_wp_error($result)) { self::query('ROLLBACK'); return $result; }
            self::query('COMMIT');
            return $result;
        } catch (\Throwable $error) {
            // Only the original connection may roll back. Never reconnect a lost transaction.
            try { mysqli_query($connection,'ROLLBACK'); } catch(\Throwable $ignored) {}
            throw $error;
        } finally { self::$transaction_connection=null; }
    }
    public static function revoke_sessions(string $connection): int {
        global $wpdb;$table=self::table('sessions');
        $n=self::query($wpdb->prepare("UPDATE `$table` SET status='revoked',payload=JSON_SET(payload,'$.status','revoked'),revision=revision+1,updated_at=%d WHERE connection_id=%s AND status='active'",time(),$connection));
        if($n===false)throw new \RuntimeException('Session revocation was not confirmed.');
        return (int)$n;
    }
    public static function touch_connection(string $key): void {
        global $wpdb;$table=self::table('connections');
        $wpdb->query($wpdb->prepare("UPDATE `$table` SET payload=JSON_SET(payload,'$.last_seen',%d) WHERE record_key=%s AND status='active' AND COALESCE(JSON_EXTRACT(payload,'$.last_seen'),0)<%d",time(),self::hash('connections',$key),time()-60));
    }
	public static function listing(string $bucket, array $filters = [], int $limit = 100, int $before_id = PHP_INT_MAX, int $offset = 0): array {
		global $wpdb; $table = self::table($bucket); $where = ['bucket=%s','id<%d',"status<>'deleted'"]; $params = [$bucket,$before_id];
		foreach (['user_id','client_id','grant_id','connection_id','status','ability','target','operation_id','success','label','kind'] as $field) if (isset($filters[$field])) { $where[] = "$field=%s"; $params[] = $field==='client_id'?self::client_index((string)$filters[$field]):$filters[$field]; }
		if (isset($filters['since'])) { $where[] = 'created_at>=%d'; $params[] = (int)$filters['since']; }
		if (isset($filters['until'])) { $where[] = 'created_at<%d'; $params[] = (int)$filters['until']; }
		$params[] = max(1,min(1000,$limit)); $params[]=max(0,$offset);
		$rows = self::rows($wpdb->prepare("SELECT id,payload FROM {$table} WHERE " . implode(' AND ', $where) . ' ORDER BY id DESC LIMIT %d OFFSET %d', $params));
		if ($wpdb->last_error) throw new \RuntimeException('MCP indexed query failed.');
		return array_map(static function($row) { $v=json_decode($row['payload'],true,512,JSON_THROW_ON_ERROR); $v['_row_id']=(int)$row['id']; return $v; },$rows);
	}
}
