# Fator3 Site Core 1.38.0 — fonte

Código canônico em work/plugin/base-site-core-fator3/. Consulte build/README.md para empacotamento e reprodução das provas. Relatório e impacto estão nesta raiz. Este arquivo ZIP não é instalável no WordPress. Não contém runtimes, banco, ZIPs-base ou credenciais de hospedagem.
