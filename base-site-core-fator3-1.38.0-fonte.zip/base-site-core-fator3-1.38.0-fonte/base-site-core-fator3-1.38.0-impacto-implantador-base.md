> Revisão 2 · 19/10/2026 · Etapa entrega · Situação: implementação Core concluída; aceite Implantador pendente.
>
> Contrato8.3.0 implementado, 65 options/130 abilities, delta zero. Instalador base-site-core-fator3-1.38.0-instalador.zip, 1993463 bytes, SHA-256 1b0de25e1dd4276fe7f7d8e428dfc0eb01a249d4108f680aa65bd3a4de3e59ee. Schema nativo e MCP conferidos; instalação limpa/upgrade direto1.37 passaram. Slack real com celular/fixo confirmado e limpo. Pipedrive real e runtime Implantador não homologados nesta rodada.
>
> Responsável Implantador deve validar o editor/contrato e preservação dos mapas, conforme proposta abaixo. Não foi alterado pacote externo nem enviado encaminhamento. Histórico r1 mantido; esta revisão prevalece.

# Impacto de base-site-core-fator3 1.38.0 em implantador-base
Revisão 1 · 2026-10-19 · Etapa planejamento · Situação aberto.
Base Core 1.37.0 (a7cd1c225bb9de76a5d1c3ad4b2184df47a6270856da902b8a268a4105ad20ad); alvo 1.38.0 previsto, instalador ainda não gerado. Implantador 2.9.0 citado no pedido 227; runtime não fornecido.
Classificação: validacao-coordenada. Natureza: contrato administrativo/configuração.
## Mudança e consequência
Contrato 8.2.0 → 8.3.0: f3base_pipedrive.whatsapp_texto string opcional vazia; variáveis nome, empresa, unidade. mapa_campos e mapa_pessoa aceitam whatsapp_link textual, opcional. Editor com lista fechada de propriedades/papéis precisa descobrir o contrato novo e preservar valores não editados. Nenhuma dependência nova ou ativação automática; 65 options e 130 abilities previstos, SDKs/perfil preservados.
## Ação e compatibilidade
Responsável Implantador: validar leitura/edição pelo contrato e preservar mapas existentes; não preencher IDs de exemplo. Core independente, sem conflito que condicione implementação. Nenhuma alteração em outro plugin nesta rodada.
## Validação prevista
Schemas nativos, recusas de tipo/catálogo, preservação em upgrade e leitura MCP. Compatibilidade com runtime Implantador não avaliada sem pacote; aceite do responsável pendente.
## Evolução
r1: proposta antes da implementação. Referências Pedidos core 227–229; não encerra pendências de outro responsável.
