# Plano — Fator3 Site Core 1.38.0
Revisão 1 · 2026-10-19 · implementação autorizada.
Base 1.37.0, SHA-256 a7cd1c225bb9de76a5d1c3ad4b2184df47a6270856da902b8a268a4105ad20ad. Identidades preservadas.
Pedidos 227: corrigir rota config-core-escrever e perfil piso-padrao-3.5 nos dois guias.
228: relatório com versao_alvo, estado, falhas, confirmada_no_executor_em e tempo esperado/observado.
229: regra única de elegibilidade C1/wa.me, links Slack/resumo/e-mail/CRM/atividades/complemento; f3base_pipedrive.whatsapp_texto opcional vazio e papéis whatsapp_link nos mapas de lead/pessoa. Contrato aditivo 8.3.0; nenhuma nova option/ability. Perfil/SDKs preservados.
Impacto relevante: base-site-core-fator3-1.38.0-impacto-implantador-base.md. MCP/Google/Meta/LinkedIn não mudam interfaces.
Provas previstas: WordPress 7.1.2/PHP 8.3.6, instalação limpa e upgrade direto, fixtures de conteúdo/escape/mapeamentos/supressão, Site-Teste instalação/documentação e Slack marcado de teste. Homologação Pipedrive somente CTOoffice/korvena.com.br conforme acesso e configuração disponíveis; registrar limites reais.

Revisão 2 — entrega: 234 checks, ciclos limpo/upgrade, Slack real e limpeza aprovados. Hash final 1b0de25e1dd4276fe7f7d8e428dfc0eb01a249d4108f680aa65bd3a4de3e59ee. Pendências de Pipedrive/Implantador/navegador no relatório; impacto atualizado r2.
