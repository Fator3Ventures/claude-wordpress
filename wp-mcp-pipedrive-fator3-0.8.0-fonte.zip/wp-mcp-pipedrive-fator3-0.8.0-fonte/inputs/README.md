# Fontes examinadas

Documentos do projeto: `01-padrao-desenvolvimento-plugins-fator3.md` e `02-instrucoes-agentes-plugins-fator3.md`, revisão 5 de 02/11/2026, lidos integralmente na abertura. Prevalece o padrão completo. Os nomes recebidos preservam o prefixo de origem.

- Padrão SHA-256: `6dd73913cf41f0157a8e68cf922cbc2b97757537488fcf441ef67a9dee5e3166`.
- Instruções SHA-256: `f0c48263597444bf304be515e3a61d268751c47cd5eaf7dfcfa9db7ea47773fc`.
- `pedidos-pipedrive-11.md`: documento anexado pelo dono, situação em 06/11/2026; item 11 aberto. A lista atual registra a instalação da 0.7.0 em korvena.com.br pela frota; esta rodada não repete essa instalação nem declara o aceite 11.
- Base 0.7.0 recuperada dos três artefatos próprios entregues anteriormente. Instalador SHA-256 `8f58b26c8408c02604c16bcfd30fcb92e3bbae308ebc107defad21555e5b5779`; fonte SHA-256 `2b1d0c1f5dad13a31beb348fe9c249acde678a29dbb7081c05b7597cef07677d`. ZIPs de entrada não são incluídos neste fonte.
- `pacotes.json`: identidade dos cinco instaladores anexados, usados para comparar os arquivos congelados do Site-Teste. Relatórios recebidos estão em `relatorios-acompanhantes/`.
- `core1730-observado.json` e `core1730-release.md`: Core 1.73.0 observado durante o encerramento. O instalador foi localizado no trabalho do mantenedor em `core1730/release`, copiado apenas para análise privada; 939 arquivos conferidos contra a cópia instalada/congelada. Nenhum arquivo com implementação Pipedrive mudou desde a 1.72.1. A análise do release local e os testes de fronteira não identificaram adaptação exigida neste plugin. Não se editou ou publicou a entrega do Core.

Fontes primárias para o Pedido 11, conferidas em 06/11/2026: https://developers.pipedrive.com/docs/api/v1/Activities e https://pipedrive.readme.io/docs/pipedrive-api-v2-migration-guide . POST/PATCH v2 recebem `participants[].primary`; o objeto retornado pode usar `primary_flag`. A implementação usa o cliente público existente do Core.
