# Plano e decisões — 0.8.0

Base 0.7.0; alvo 0.8.0; Pedido MCP Pipedrive 11 recebido em 06/11/2026. Normas integrais: instruções e padrão revisão 5, 02/11/2026.

1. Identificar pacotes atuais, pedidos e impactos; preservar contratos do Core/MCP.
2. Guardar progresso cifrado junto ao recibo na transação local existente; manter a leitura dos marcadores já gravados.
3. Criar atividade com pessoa do lead como participante principal via API v2; recusar criação sem pessoa e conferir o resultado.
4. Cobrir idempotência, próximo toque, retenção, migração, reinício, divergência remota e falha de banco. Atualizar guias e explicações do painel.
5. Congelar instalador; testar instalação limpa, atualização direta da 0.7.0 e convivência da matriz atual. Instalar e verificar no Site-Teste autorizado.
6. Conferir checklist, publicar fonte/instalador/relatório e registrar o aceite em korvena.com.br como pendência externa à prova sintética.

Decisão: usar uma linha interna `progress` por conta/lead na tabela de operações, por chave primária HMAC, sem mensagem. Evita nova tabela e migração automática; recibo, diário e progresso são confirmados juntos. Uma alteração textual ou troca da atividade bloqueia avanço até reconciliação. O registro não expira com o diário e não é executável como prévia.

API v2 recebe `primary:true`; `primary_flag` é aceito na releitura do objeto retornado. Atividades existentes conservam participantes. Não alterar prefixo `[IA]` nem executar uma limpeza em massa dos marcadores antigos.

Nenhum impacto que exija implementação nos acompanhantes foi identificado: contrato Core 1.0.0 e as 19 operações permanecem; validar o transporte original e o encoder do Core. Não emitir relatório sem providência técnica.

## Encerramento

Implementação, documentação, 550 asserções e instalação no Site-Teste concluídas. O Core mudou de 1.72.1 para 1.73.0 durante a rodada: os 26 arquivos alterados foram identificados e a fronteira Core/MCP foi revalidada em nova bancada isolada, com paridade dos instaladores. Nenhuma mudança no instalador Pipedrive congelado. Evidências iniciais em `matrix1721-*`; evidências finais em `current-*`. Pendência: aceite comercial do Pedido 11 em korvena.com.br, pelo responsável autorizado pela conta.
