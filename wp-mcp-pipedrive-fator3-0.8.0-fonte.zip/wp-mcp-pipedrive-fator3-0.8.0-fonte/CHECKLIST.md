# Checklist de encerramento — revisão 5 do padrão

| Requisito pertinente | Situação e prova |
|---|---|
| Dois documentos centrais, revisão e precedência | Lidos integralmente; revisão 5 de 02/11/2026; identificados na abertura e em inputs |
| Base, alvo e incremento | 0.7.0 → 0.8.0; Pedido 11; schema e rotas preservados |
| Mínimos de runtime | WP 7.1.4/PHP 8.3.36 executados; lint PHP 8.3.6 |
| Versões atuais dos acompanhantes | Matriz inicial 1.72.1; Core 1.73.0 observado e fronteira revalidada com paridade dos arquivos |
| Correção por nova versão | Nenhum byte do instalador mudou após instalação nativa; sem downgrade |
| Três artefatos e fechamento | Fonte, instalador e relatório; hash do fonte somente no relatório externo após fechar o ZIP |
| Impactos e prontidão do emissor | Contrato Core 1.0.0 preservado; nenhuma providência técnica em outro pacote identificada; nenhum relatório artificial |
| Identidade, permissões e painel | Slug/nome/domínio estáveis, manage_options e nonces; testes desktop e 360 px |
| Código e documentação no instalador | 36 arquivos; 12 documentos; 19 operações; comparação exata dos bytes |
| Descoberta e leitura integral via MCP | 19 abilities 0.8.0; 12 documentos reconstruídos com hashes iguais |
| Instalação limpa e atualização | Banco isolado; atualização da base com regras, prazos, estados e recibo preservados |
| Testes próprios e fronteiras | 550 asserções; cliente e encoder originais do Core; MCP original; limites explicitados |
| Dados, credenciais, autorização e pausas | Snapshot do estado próprio e autorização preservados; sem segredo em artefatos |
| Integridade e reprodução | 109 checks; 46 lints; instalador reproduzido byte a byte; ZIPs sem ZIP interno |
| Temporários e estado final | Bancadas, controladores e ZIP de QA removidos; Site-Teste 0.8.0 ativo e saudável |
| Publicação raw/frota | Não aplicável nesta instalação direta por zip_path+SHA/slug; nenhuma publicação GitHub solicitada/executada |
| Experimentos nos destinatários | Somente cópias isoladas dos acompanhantes; nenhuma edição em pacote oficial alheio |
| Aceite comercial em korvena.com.br | **Pendente**: teste real com lead criado/excluído, participante, nota e replay; responsável autorizado da conta |

Status final `com-pendencias` devido ao aceite comercial do Pedido 11. Provas sintéticas e autorização real não são intercambiáveis. A cópia interna do relatório explicita a etapa de fechamento do fonte.
