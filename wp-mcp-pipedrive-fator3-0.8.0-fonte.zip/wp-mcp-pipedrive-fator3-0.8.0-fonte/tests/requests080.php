<?php
/** Pedido 11: real WordPress/MySQL, synthetic CRM, including transactional fault injection. */
use Fator3\Pipedrive\{Api,CoreClient,Configuration,Store,Support,Cadence,Progress,Rules};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0800'))throw new RuntimeException('Disposable only');
require_once __DIR__.'/fixture050.php';wp_set_current_user(1);$checks=[];$ok=static function($n,$v)use(&$checks){$checks[]=['name'=>$n,'passed'=>(bool)$v];};
$f=new ReleaseFixture();$http=0;$block=static function()use(&$http){++$http;return new WP_Error('qa','External request forbidden');};add_filter('pre_http_request',$block,PHP_INT_MAX);
$transport=new class($f){
 public array $account=[];public string $fault='';public function __construct(public $f){}
 public function status(){$s=$this->f->status();if($this->account)$s['data']['conta']=$this->account;return $s;}
 public function request($m,$p,$q,$b,$ctx){$r=$this->f->request($m,$p,$q,$b,$ctx);if($m==='GET'&&preg_match('~/activities/[0-9]+$~',$p)){
  $d=&$r['data']['body']['data'];foreach($d['participants']??[] as $j=>$part){$d['participants'][$j]['primary_flag']=$part['primary']??false;unset($d['participants'][$j]['primary']);}
  if($this->fault==='participant'){$d['participants']=[];$d['person_id']=null;}
  if($this->fault==='note')$d['note']='Não corresponde ao enviado';
  if($this->fault==='link')$d['lead_id']='80000000-0000-4000-8000-000000000999';
 }return $r;}
};
$property=new ReflectionProperty(CoreClient::class,'client');$oldClient=$property->getValue();$property->setValue(null,$transport);$oldConfig=get_option(Configuration::OPTION,null);$oldRetention=get_option('f3_pipedrive_retention',null);
$c=Configuration::defaults();$c['habilitada']=true;$c['tipo_whatsapp']='whatsapp';$c['fuso']='UTC';$c['dias']=[1,2,3,4,5,6,7];$c['periodos']=[['codigo'=>'manha','hora'=>'09:30']];$c['textos']=[['codigo'=>'m','texto'=>'Sintético']];$c['nota']=['prefixo'=>'','formato'=>'d/m H\\hi','autor'=>'nós'];
$c['toques']=[['codigo'=>'t1','base'=>'entrada','atraso_minutos'=>0,'texto_id'=>'m','etiqueta_id'=>''],['codigo'=>'t2','base'=>'ultimo_registro','atraso_minutos'=>60,'texto_id'=>'m','etiqueta_id'=>''],['codigo'=>'t3','base'=>'ultimo_registro','atraso_minutos'=>60,'texto_id'=>'m','etiqueta_id'=>'']];
$account=$f->status()['data']['conta'];$uuid=static fn($n)=>sprintf('80000000-0000-4000-8000-%012d',$n);
$seed=static function($n,$person=88)use($f,$uuid){$lead=['id'=>$uuid($n),'person_id'=>$person,'add_time'=>'2026-11-01T12:00:00Z','is_archived'=>false,'label_ids'=>[]];$f->data['/v1/leads/'.$lead['id']]=$lead;return $lead;};
$input=static fn($n,$touch='t1')=>['lead_id'=>$uuid($n),'mensagem'=>'Mensagem sintética <b>literal</b>','toque'=>$touch,'chave_idempotencia'=>'pedido11-'.$n.'-'.$touch];
$ops=Store::table('ops');$progressRow=static fn($lead)=>$wpdb->get_row($wpdb->prepare("SELECT * FROM $ops WHERE previa_id=%s",substr(Progress::identity($account,$lead['id']),0,32)),ARRAY_A);
try{
 update_option(Configuration::OPTION,Support::json($c),false);
 $lead=$seed(1);$r=Api::dispatch('whatsapp-registrar',$input(1));$ok('create_success',$r['success']);if(!$r['success'])throw new RuntimeException(Support::json($r));$activity=$f->data['/api/v2/activities/'.$r['data']['atividade_id']];
 $sent=array_values(array_filter($f->requests,fn($x)=>$x[0]==='POST'))[0][3];
 $ok('new_note_has_no_marker',!str_contains($activity['note'],'F3PD1:')&&!str_contains($activity['note'],$lead['id']));
 $ok('configured_empty_prefix_preserved',!str_contains($activity['note'],'[IA]')&&str_contains($activity['note'],'&lt;b&gt;literal&lt;/b&gt;'));
 $ok('v2_primary_payload_exact',$sent['participants']===[['person_id'=>88,'primary'=>true]]&&!isset($sent['person_id'],$sent['attendees']));
 $ok('readback_primary_flag_accepted',$r['success']&&end($f->requests)[0]==='GET');
 $n=count($f->requests);$writes=$f->writes;$ok('same_key_replays_without_any_request',Api::dispatch('whatsapp-registrar',array_reverse($input(1),true))===$r&&count($f->requests)===$n);
 $changed=$input(1);$changed['mensagem']='Outra';$ok('same_key_changed_message_refused',Api::dispatch('whatsapp-registrar',$changed)['code']==='idempotencia_conflitante'&&$f->writes===$writes);
 $row=$progressRow($lead);$p=Progress::read($account,$lead['id'],$activity);$ok('progress_private_and_permanent',$row['state']==='progress'&&(int)$row['retain_until']===PHP_INT_MAX&&!str_contains(wp_json_encode($row),'Mensagem')&&$p['touch']==='t1');
 $ok('progress_case_and_account_order_stable',Progress::identity(array_reverse($account,true),strtoupper($lead['id']))===Progress::identity($account,$lead['id']));
 wp_set_current_user(2);$ok('progress_available_to_other_admin',Progress::read($account,$lead['id'],$activity)===$p);wp_set_current_user(1);
 $progress=Cadence::progress($lead,$activity,$c,null,$account);$ok('cadence_uses_private_cursor',$progress['indice']===1&&$progress['ultimo']===$p['time']&&$progress['origem']==='registro_local');
 $f->data['/v1/leads']=[$lead];$q=Api::dispatch('cadencia-fila');$item=$q['data']['itens'][0];$ok('queue_next_touch_and_date',$item['toque']==='t2'&&$item['devido_em_utc']===gmdate('Y-m-d\TH:i:s\Z',Rules::deadline($p['time'],$c['toques'][1],$c)['instante']));
 $other=$input(1);$other['chave_idempotencia']='pedido11-new-key';$ok('same_touch_other_key_no_write',Api::dispatch('whatsapp-registrar',$other)['code']==='toque_incompativel'&&$f->writes===$writes);
 $old=$c;$old['toques']=[$c['toques'][1]];try{Cadence::progress($lead,$activity,$old,null,$account);$rejected=false;}catch(Throwable $e){$rejected=$e->reason==='progresso_incompativel';}$ok('removed_touch_cannot_restart',$rejected);
 $different=$account;$different['conta_id']=999;$ok('other_account_has_no_cursor',Progress::read($different,$lead['id'],$activity)===null);
 foreach(['missing'=>null,'replaced'=>array_replace($activity,['id'=>99999]),'edited'=>array_replace($activity,['note'=>'Editado'])] as $why=>$altered){try{Progress::read($account,$lead['id'],$altered);$rejected=false;}catch(Throwable $e){$rejected=$e->reason==='progresso_divergente';}$ok($why.'_activity_refuses_progress',$rejected);}
 $normalized=array_replace($activity,['note'=>str_replace('<p>','<p class="provider">',$activity['note'])]);$ok('html_normalization_preserves_cursor',Progress::read($account,$lead['id'],$normalized)===$p);
 $ok('paragraph_normalization_preserves_text',Progress::noteDigest('<p>Primeira</p><p>Segunda</p>')===Progress::noteDigest("<div>Primeira<br>Segunda</div>")&&Progress::noteDigest('<p>Primeira</p><p>Segunda</p>')!==Progress::noteDigest('<p>PrimeiraSegunda</p>'));
 $policy=Fator3\Pipedrive\Retention::read();Fator3\Pipedrive\Retention::configure(['diario_dias'=>1,'revisao_esperada'=>$policy['revisao'],'confirmar_expurgo'=>true]);$wpdb->update(Store::table('journal'),['created'=>time()-3*DAY_IN_SECONDS],['previa_id'=>$r['previa_id']]);Store::cleanup();
 $ok('journal_expiry_preserves_cadence',!$wpdb->get_var($wpdb->prepare('SELECT id FROM '.Store::table('journal').' WHERE previa_id=%s',$r['previa_id']))&&Progress::read($account,$lead['id'],$activity)===$p);
 $n=count($f->requests);$ok('journal_expiry_preserves_replay',Api::dispatch('whatsapp-registrar',$input(1))===$r&&count($f->requests)===$n);
 // Save before next touch: the separate restart action reuses this lead's final state.
 $r2=Api::dispatch('whatsapp-registrar',$input(1,'t2'));$activity=$f->data['/api/v2/activities/'.$activity['id']];$p2=Progress::read($account,$lead['id'],$activity);
 $ok('second_touch_appends_without_marker',$r2['success']&&!str_contains($activity['note'],'F3PD1:')&&substr_count($activity['note'],'Mensagem')===2&&$p2['touch']==='t2');
 $ok('one_cursor_per_lead',(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $ops WHERE binding=%s AND state='progress'",Progress::identity($account,$lead['id'])))===1);
 file_put_contents(dirname(__DIR__).'/restart080.json',Support::json(['lead'=>$lead,'activity'=>$activity,'config'=>$c,'receipt'=>$r2,'input'=>$input(1,'t2'),'progress'=>$p2]));
 $missing=$seed(2,null);$writes=$f->writes;$bad=Api::dispatch('whatsapp-registrar',$input(2));$ok('missing_person_before_any_write',$bad['code']==='lead_sem_pessoa'&&$f->writes===$writes&&$progressRow($missing)===null);
 $existing=$seed(3,null);$a=['id'=>803,'type'=>'whatsapp','lead_id'=>$existing['id'],'done'=>false,'note'=>'','participants'=>[['person_id'=>99,'primary'=>true]],'person_id'=>99];$f->data['/api/v2/activities'][]=$a;$f->data['/api/v2/activities/803']=$a;
 $r3=Api::dispatch('whatsapp-registrar',$input(3));$patch=array_values(array_filter($f->requests,fn($x)=>$x[0]==='PATCH'&&$x[1]==='/api/v2/activities/803'))[0][3];$ok('existing_participants_preserved',$r3['success']&&!isset($patch['participants'])&&$f->data['/api/v2/activities/803']['participants']===$a['participants']);
 $legacy=$seed(4);$marker=Cadence::marker($legacy['id'],'t1',time()-120,'old-message');$a=['id'=>804,'type'=>'whatsapp','lead_id'=>$legacy['id'],'done'=>false,'note'=>'<p>Antiga '.$marker.'</p>'];$f->data['/api/v2/activities'][]=$a;$f->data['/api/v2/activities/804']=$a;
 $ok('old_marker_read_before_new_write',Cadence::progress($legacy,$a,$c,null,$account)['origem']==='marcador');$legacyResult=Api::dispatch('whatsapp-registrar',$input(4,'t2'));$a=$f->data['/api/v2/activities/804'];$ok('old_marker_preserved_no_new_marker',$legacyResult['success']&&substr_count($a['note'],'[F3PD1:')===1&&str_contains($a['note'],$marker)&&Progress::read($account,$legacy['id'],$a)['touch']==='t2');
 foreach(['participant'=>5,'note'=>6,'link'=>7] as $fault=>$num){$l=$seed($num);$transport->fault=$fault;$res=Api::dispatch('whatsapp-registrar',$input($num));$transport->fault='';$writes=$f->writes;$ok($fault.'_readback_keeps_pending',!$res['success']&&$res['data']['reconciliacao_necessaria']&&$progressRow($l)===null);$i=$input($num);$i['chave_idempotencia'].='-retry';$ok($fault.'_readback_no_retry',Api::dispatch('whatsapp-registrar',$i)['code']==='reconciliacao_necessaria'&&$f->writes===$writes);}
 // Break the local cursor write after the provider succeeded: receipt and cursor must roll back together.
 $l=$seed(8);$identity=substr(Progress::identity($account,$l['id']),0,32);$injection=static function($sql)use($ops,$identity){return str_contains($sql,$ops)&&str_contains($sql,$identity)&&str_starts_with($sql,'INSERT')?'INSERT INTO qa_nonexistent_progress080 VALUES (1)':$sql;};
 $beforeErrors=$wpdb->suppress_errors(true);add_filter('query',$injection);try{$failed=Api::dispatch('whatsapp-registrar',$input(8));}finally{remove_filter('query',$injection);$wpdb->suppress_errors($beforeErrors);}
 $ok('cursor_failure_rolls_back_receipt',$failed['code']==='resultado_incerto'&&$progressRow($l)===null);$writes=$f->writes;$ok('cursor_failure_prevents_retry',Api::dispatch('whatsapp-registrar',$input(8))['code']==='resultado_incerto'&&$f->writes===$writes);
 $ok('no_supplier_http',$http===0);
}finally{
 $property->setValue(null,$oldClient);remove_filter('pre_http_request',$block,PHP_INT_MAX);if($oldConfig===null)delete_option(Configuration::OPTION);else update_option(Configuration::OPTION,$oldConfig,false);if($oldRetention===null)delete_option('f3_pipedrive_retention');else update_option('f3_pipedrive_retention',$oldRetention,false);wp_set_current_user(1);
}
return ['checks'=>$checks,'passed'=>count(array_filter($checks,fn($x)=>$x['passed'])),'failed'=>count(array_filter($checks,fn($x)=>!$x['passed'])),'supplier_http'=>$http];
