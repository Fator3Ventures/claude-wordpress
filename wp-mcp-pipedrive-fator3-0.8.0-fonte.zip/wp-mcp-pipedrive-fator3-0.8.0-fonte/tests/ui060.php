<?php
/** Browser harness: fixed admin settings surface in a dedicated, synthetic WordPress installation. */
use Fator3\Pipedrive\{Admin,CoreClient,Configuration,Retention,Store};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||$wpdb->prefix!=='f3pipqa_0800v_')throw new RuntimeException('UI sandbox only');
$req=json_decode(stream_get_contents(STDIN),true)?:[];require_once __DIR__.'/fixture050.php';
$f=new ReleaseFixture();$f->pagination=($req['fixture']??'ok')!=='partial';
if(($req['fixture']??'ok')!=='absent')(new ReflectionProperty(CoreClient::class,'client'))->setValue(null,$f);
$_GET=wp_slash(array_intersect_key($req['get']??[],array_flip(['page','aba','modo','documento','antes_id','offset','revisao'])));
$_POST=wp_slash(array_intersect_key($req['post']??[],array_flip(['f3_pipedrive_action','_wpnonce','_wp_http_referer','revisao_esperada','modo','form_completo','regras_json','habilitada','dias','inicio','fim','fuso','periodos','feriados','tipo_whatsapp','archive_reasons','lost_reasons','ordem','previa_id','confirmacao','diario_dias','confirmar_expurgo'])));
$_SERVER['REQUEST_METHOD']=$_POST?'POST':'GET';$_REQUEST=$_POST+$_GET;$_SERVER['REQUEST_URI']='/wp-admin/tools.php?page=wp-mcp-pipedrive-fator3';
wp_set_current_user(1);$stop=static fn()=>static function(){throw new RuntimeException('admin_refused');};add_filter('wp_die_handler',$stop);
if(($req['profile']??'admin')==='anonymous')wp_set_current_user(0);
ob_start();try{Admin::page();$status=200;}catch(RuntimeException $e){echo '<p role="alert">Requisição recusada.</p>';$status=403;}finally{$html=ob_get_clean();remove_filter('wp_die_handler',$stop);}
wp_set_current_user(1);$rules=Configuration::read();$ops=Store::table('ops');
return ['status'=>$status,'html'=>$html,'fixture_reads'=>count($f->requests),'supplier_writes'=>$f->writes,'rules_revision'=>$rules['revisao'],'zone'=>$rules['regras']['fuso'],'retention'=>Retention::read()['diario_dias'],'drafts'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM $ops"),'supplier_http'=>0];
