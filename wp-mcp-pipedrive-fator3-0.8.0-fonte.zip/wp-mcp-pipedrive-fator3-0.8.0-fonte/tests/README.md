# Qualidade e reprodução • Pipedrive 0.8.0

A bancada instala o mesmo ZIP distribuído, em WordPress descartável. Dados, saldos, mensagens e escritas do CRM são fixtures. O relógio, processos PHP, banco MySQL, executor do MCP, ciclo de instalação nativo e navegador são reais. O Site-Teste compartilhado recebe somente a atualização do plugin e verificações de leitura.

## Preparar os artefatos

Use o instalador 0.7.0 publicado (SHA-256 `8f58b26c8408c02604c16bcfd30fcb92e3bbae308ebc107defad21555e5b5779`) e o ZIP 0.8.0 congelado. A ferramenta recusa outro instalador-base, versões incorretas, testes novos ausentes e saída dentro da árvore de fonte.

```sh
python3 build/verify.py --phase package --installer /artefatos/wp-mcp-pipedrive-fator3-0.8.0-instalador.zip
python3 build/lab.py --base /artefatos/wp-mcp-pipedrive-fator3-0.7.0-instalador.zip --candidate /artefatos/wp-mcp-pipedrive-fator3-0.8.0-instalador.zip --out /temporario/f3-pipedrive-qa-0800.zip
```

O ZIP de bancada não integra a distribuição. No Site-Teste autorizado, carregar esse ZIP em `wp-content/f3-pipedrive-qa-0800.zip` e conferir o hash informado por `build/lab.py`. Instalar temporariamente o MU de testes `lab-controller.php`, com guarda e backup. Ele expõe `qa-pipedrive080/run`, exige administrador e limita o host, cenário e ações. `setup` recusa diretório alheio ou preexistente e prefixo ocupado; gera sais privados, bloqueia HTTP, cron e e-mail. `freeze` copia os acompanhantes para o cenário atual. Nenhum trabalhador usa o prefixo da instalação compartilhada.

| Cenário | Prefixo de banco | Ações, em ordem |
| --- | --- | --- |
| Instalação e integração | `f3pipqa_0800c_` | setup → freeze → install → bootstrap080 → native → report → retention → release → requests050 → quality060 → writes070 → insights070 → requests080 → restart080 → integrate → integrated → core → core-report → core-workflows → diagnostics |
| Migração | `f3pipqa_0800u_` | setup → install-base → bootstrap080 → seed-upgrade → upgrade → verify-upgrade → upgrade-restart |
| Configuração no navegador | `f3pipqa_0800v_` | setup → install → ui060 (GETs e POSTs do navegador) → documents050 |

Cada ação abre um processo separado. `install-base`, `install` e `upgrade` devolvem o hash do ZIP efetivamente utilizado. A migração semeia política finita, regras ativas, recibo permanente, operações prontas/em execução, diário e marcador pendente. Após a atualização, compara o estado, reassocia o recibo original sem nova chamada e testa o conflito de conta. `upgrade-restart` confirma a escolha após novo carregamento. Para repetir uma sequência com fixtures de IDs fixos, executar `cleanup` e recomeçar. A ação `develop` cria somente um protótipo nos cenários UI ou atual. Recriar as bancadas antes da instalação final; não contar os ensaios de protótipo como certificação do ZIP.

A matriz de integração exige Core 1.73.0, MCP 0.41.0, Google 0.30.0, Meta 0.21.0 e LinkedIn 0.19.0, ativos. `current-freeze.json` registra as cópias congeladas do Site-Teste e `current-integrated.json` atesta a versão e a ativação encontradas pelo WordPress. O conjunto foi conferido no início desta rodada.

## Cobertura da rodada

| Suíte | Verifica |
| --- | --- |
| `requests080` (37) + `restart080` (4) | Pedido 11, progresso local, participante, releitura, retenção, falha transacional e novo processo PHP. |
| `writes070` (34) | Recibos aplicados em rota incompatível, idempotência com chaves em ordem diferente, histórico ambíguo, compensação recusada quando falta checkpoint, exclusões bloqueadas pelo estado pendente e expiração dos recibos protegidos. |
| `insights070` (25) | Ausência só com cobertura comprovada, limites de coleta, duplicação de entidades, dados de data/etapa e contagem de opções apenas no campo/ID corretos. |
| `browser060.py` (38) | Nonce, teclado, consentimento, recuperação de prévia após erro, conflitos entre revisões, navegação das seções do guia, HTML literal e leitura em 360 px. |
| Integração | Descoberta, permissões e documentos por meio do MCP; fixture do contrato do Core e convivência com os acompanhantes na matriz desta rodada. |
| Regressão e migração | Operações nativas, retenção, bloqueios entre conexões, relatórios, regras/editoração, configuração, documentação e atualização direta 0.7.0→0.8.0. |

O adaptador Playwright intercepta `https://pipedrive-qa.test` e usa `ui060.php` para obter o HTML real de `Admin::page`. Chromium digita, envia dados e verifica os efeitos no mesmo WordPress. Esse percurso não autentica um navegador no painel compartilhado. As imagens de inspeção e os formulários contendo nonce ficam fora da fonte.

```sh
python3 tests/browser060.py --bridge /temporario/ponte --chromium /caminho/chromium --wp /temporario/wordpress --out /temporario/browser.json --screens /temporario/inspecao
```

Para cada `req-N.json`, o operador da ponte chama `qa-pipedrive080/run` com `cenario=ui`, `acao=ui060` e `formulario` igual à requisição. Entregar `data.result` completo por rename atômico para `resp-N.json`; esperar `finished`, código de saída zero e todas as asserções. Em instalação local equivalente, com WP_HOME `https://pipedrive-qa.test`, prefixo e marcador exclusivos, substituir `--bridge` por `--local-runner /temporario/lab/runner.php --php /caminho/php`.

## Verificar e encerrar

Salve cada resposta sanitizada como `evidence/{cenario}-{acao}.json` (resposta do executor completa). Salve `evidence/browser.json` e execute `build/verify.py --phase isolated --installer ...`. Esse estágio compara o manifesto de arquivos instalados, cada documento reconstruído, a matriz de acompanhantes, a execução das asserções e ausência de chamadas reais ao fornecedor. A fase `final` exige também atualização direta do Site-Teste, snapshot antes/depois do mesmo estado, documentação real, descoberta sem controladores e limpeza das três bancadas.

`cleanup` remove somente tabelas e diretório de cenário com marcador próprio; verificar `tables_remaining=0` e `directory_removed=true`. Remover os dois controladores e o ZIP de bancada por hash. Manter os backups e registros do MCP. Não há downgrade.

## Mudança de acompanhante no encerramento

A primeira matriz usou Core 1.72.1, antes de sua troca por outro mantenedor. A repetição pertinente congelou Core 1.73.0 e verificou integração MCP, documentos, retenção/recibo via Core, relatório e registro/encerramento via encoder original. Os cinco acompanhantes foram comparados por inventário e SHA-256 de cada arquivo com seus instaladores. O instalador Pipedrive foi idêntico em todas as bancadas. `matrix1721-*` preserva a primeira prova; `current-integrated/core/core-report/core-workflows` contém a prova final. Os demais testes funcionais do Pipedrive não foram repetidos sem mudança de código. O verificador final reúne as provas do mesmo instalador e informa a matriz final.

Um diagnóstico inicial da bancada de integração ainda esperava a versão 0.7.0; corrigiu-se somente a asserção para 0.8.0 e repetiu-se a prova. O instalador nunca foi modificado após a primeira instalação nativa.
