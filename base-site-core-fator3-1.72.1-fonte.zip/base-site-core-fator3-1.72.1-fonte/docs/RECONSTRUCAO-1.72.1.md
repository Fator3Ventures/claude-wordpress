# Reconstrução do fonte 1.72.1

Data: 06/11/2026. Escopo: recuperar o trabalho existente e regenerar o fonte da versão solicitada, mantendo o instalador original.

## 1. Origem e integridade

| Material | Origem comprovada | Uso nesta entrega |
|---|---|---|
| Runtime 1.72.1 | Instalador preservado no Site-Teste, 4.323.938 bytes, SHA-256 `3d13dfc96c6dec31221dbe989bdbee27beedbcf98719be0a0447bba7078242f6` | 935 arquivos preservados; instalador reproduzido byte a byte |
| Runtime 1.72.0 | Arquivamento somente da pasta do plugin instalado, 933 arquivos | Base de código para atualização local e comparação do painel |
| Fonte 1.71.0 | Pacote de 5.828.164 bytes, SHA-256 `a532a725dabe76af9ec36811e4e4611826b397716188f5c99d938eeb3bd43278` | Build, testes, lockfiles, evidências, insumos e documentos conservados |
| Primeira recuperação da 1.72.1 | Fonte de 5.728.046 bytes, SHA-256 `ccdf8917b868b3da789982c31292791a9a46ad4d84f95f9543c6de38236731b0` | Base desta ampliação; relatório revisão 1 arquivado |
| Build e testes atuais | Reconstrução de 06/11/2026 | Scripts em `build/` e `tests/`, resultados em `evidence/1721-reconstrucao/` |

O arquivo obtido da pasta instalada da 1.72.0 tinha 4.336.773 bytes e SHA-256 `b840f90f5c1d2de820b4ce2d060dbd0613b2403c5f6f03f7d475fd7856bb9658`. É um arquivo de recuperação, não o instalador original daquela release. A árvore foi preservada expandida, com manifesto; o ZIP temporário remoto criado nesta rodada foi removido após a recuperação. O candidato original da 1.72.1 permaneceu intacto.

O fonte original completo da rodada interrompida e seus scripts específicos não foram localizados. Esta reconstrução reproduz os assets e o instalador e reexecuta cenários documentados, sem alegar identidade com os scripts perdidos. Não há commit Git recuperado a declarar.

## 2. Cobertura executada

| Grupo | Verificações | Evidência em `evidence/1721-reconstrucao/` |
|---|---:|---|
| Cliente JS e perfis | 395 | `cliente-1720.json` |
| Sonda HTTP e contexto | 68 | `sonda-1720-http.json` |
| WordPress limpo: instalação | 2 | `fresh--instalacao-limpa-1721.json` |
| Vitais, schema, filtros e concorrência | 52 | `fresh--vitais-1720.json` |
| Regressão de medição reaproveitada | 27 | `fresh--medicao-1710-relatorio.json` |
| Painel em instalação limpa | 8 | `fresh--painel-1721.json` |
| Perfis e leitura documental | 37 | `fresh--ativos-documentacao-1721.json` |
| Base 1.72.0: instalação e semente | 4 | `upgrade--instalacao-limpa-1720.json`, `upgrade--upgrade-1720-semente.json` |
| Defeito do painel na 1.72.0 | 8 | `upgrade--painel-1720.json` |
| Atualização direta e preservação | 3 | `upgrade--upgrade-1720-1721.json` |
| Painel depois da atualização | 8 | `upgrade--painel-1721.json` |
| Reativação após desinstalação | 5 | `upgrade--reativacao-1721.json` |
| **Total funcional** | **617** | `resumo.json`; 617 aprovadas, zero falhas |

Separadamente: 596 arquivos PHP passaram no lint; 935 arquivos do runtime foram conferidos por hash; 84 arquivos JS e um PHP de assets foram recompilados idênticos. A retirada das 33 tabelas na desinstalação aparece em `native-run.json`; não foi somada como asserção adicional. O total inclui variações parametrizadas, não representa 617 cenários independentes.

### Cliente e sonda

O cliente executa scripts integrais em jsdom 27.4.0: fonte e minificado de tracking, 64 variantes de tracking/público, origem válida/conflitante/ausente/inválida, maior sequência e consentimento negado. A continuidade de fila usa armazenamento produzido pelo runtime 1.72.0 recuperado e consumido pela 1.72.1.

O cliente de contatos abrange fonte, minificado e quatro perfis, sob condições normal, consentimento negado, teste, contexto pendente e supressão. Confere chamadas esperadas/proibidas, identificação do evento e deduplicação. Transporte, callbacks de métricas e SDKs externos são controlados pela fixture.

A sonda usa HTTP do PHP e o dispatcher de hooks do WordPress. Os 17 contextos têm quatro verificações cada: ativação, SQL, wrapper e retorno do callback. Cobre POSTs públicos de comportamento/análise, query string, subdiretório, prefixo personalizado, administração, cron, autenticação, opt-in e outras rotas. Não carrega o WordPress completo nem um banco nesse grupo.

### WordPress nativo e banco

O orquestrador executa WordPress 7.1.4, PHP 8.4.27 e MariaDB 11.8.6 em duas instalações separadas: limpa na 1.72.1 e base 1.72.0 para atualização direta. Dados pessoais e opções privadas do site real não são usados.

A migração de vitais parte de 993 linhas sintéticas em schema anterior à coluna `versao_origem`. Confere alteração aditiva, coluna e índice em um ALTER, ausência de escrita de amostras, preservação de linhas vencidas na migração, idempotência com poda suspensa, falha DDL e retomada. Coluna, índice ou chave primária incompatíveis são recusados. Dois processos WordPress enviam 30 revisões concorrentes da mesma amostra: preservam a maior sequência e mantêm o conflito de origem como desconhecido.

As consultas verificam filtros de versão, dispositivo, automação e teste; denominador e p75 coerentes; origem desconhecida permanente quando há conflito; recusa sem autorização. A regressão reaproveitada cobre fases, denominadores, p75, zero, erros e página além do limite.

O teste do painel dispara `admin_menu` e executa o callback registrado. A 1.72.0 produz dois painéis e dois formulários; a 1.72.1 produz um painel e um formulário, nas visões qualidade e vitais. Confere filtros, escape e recusa sem `manage_options`. É prova do HTML gerado pelo WordPress nativo; não inclui inspeção visual.

Na atualização direta, as 993 amostras e a configuração sintéticas mantêm seus hashes. Desinstalação/reativação é teste separado: remove vitais operacionais conforme a política do plugin, conserva configuração e recria 33 tabelas auxiliares, sem consultas prematuras às tabelas removidas. A tabela de vitais retorna vazia.

A documentação é lida de forma paginada pela implementação do plugin, conferindo revisão e hash de `RELEASE-1.72.1.md`, `VITAIS-VERSAO.md` e `AGENTES-1.72.1.md`, com recusa a travessia de diretórios e a usuário anônimo. Não certifica o transporte MCP remoto.

## 3. Build e desempenho

O gerador foi reconstruído a partir do script 1.71.0, dos marcadores do código e dos assets distribuídos. Terser 5.44.1 e rcssmin 1.2.2 reproduziram 85 arquivos byte a byte. O vendor web-vitals conserva os bytes publicados; seu upstream não foi recompilado.

O manifesto do runtime mantém rótulos legados do gerador. A ferramenta usada e os hashes atuais estão em `assets-reproduzidos.json`; a preservação do runtime inclui a documentação original.

`tamanhos-assets.json` compara arquivos: contatos completo passa de 17.382 bytes na 1.71.0 para 16.087; os perfis atuais têm 14.149, 15.540, 14.696 e 16.087 bytes. Tracking cresce de 40.385 para 40.666 bytes. São tamanhos de arquivos, sem inferência sobre latência, vitais reais ou bytes da página completa. A medição histórica de economia em página não foi repetida.

## 4. Limites e continuidade

- PHP 8.3 permanece requisito sem execução nesta rodada. O WordPress mínimo 7.1.4 foi executado; o banco foi MariaDB 11.8.6, sem prova em MySQL 8.4.
- Não houve navegador real, inspeção de layout, CDN, cache de produção nem SDKs/contas reais de anúncios.
- A 1.72.1 não foi instalada no Site-Teste nesta reconstrução. Acompanhantes não integraram o laboratório; o relatório registra o inventário remoto observado.
- `SCRIPT_DEBUG` ligado não foi exercitado pela suíte atual. Resultados históricos não ampliam essa cobertura.
- A exportação integral de opções privadas foi recusada na primeira recuperação. A rodada atual usa dados sintéticos locais e não depende desse backup.

O fonte está reconstruído e utilizável para continuidade do desenvolvimento. Homologação visual, ambiente compartilhado, acompanhantes e runtimes não executados conservam suas pendências.
