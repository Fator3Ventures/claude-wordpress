# Sonda PHP do Core 1.71.0

## O que mudou

A 1.71.0 deixa os GET/HEAD públicos anônimos comuns, incluindo artigo e login, fora do perfil detalhado. `medir()` executa o trabalho diretamente e `callback()` devolve o callable original. Essas visitas dispensam reflexão, cronômetros de módulos, observador SQL e backtrace de catálogo. A coleta de eventos de navegação obedece aos seus próprios controles. Se um consumidor PHP solicitar o resumo naquele contexto, o resultado será `ok=false` com `requisicao_sem_perfil`.

O perfil completo é habilitado para CLI, administração, cron, REST, requisições com indicador de sessão WordPress ou autenticação HTTP e métodos diferentes de GET/HEAD. A sonda da página ou do login usa um cabeçalho assinado. Se o WordPress ainda não instalou `wp_salt`, o Core mede provisoriamente o início apenas para um cabeçalho com formato e horário válidos, confere a assinatura em `plugins_loaded` e desativa o perfil caso seja recusada. A resposta pública nunca inclui o diagnóstico sem conferir a assinatura e o caminho. A bancada que precisa consultar o perfil no footer pode definir `F3BASE_PERFIL_PHP=true` em código PHP confiável antes do bootstrap do Core. Esse opt-in não disponibiliza o diagnóstico ao visitante.

Na medição habilitada, a 1.70.0 registrava um callback em `all`, que o WordPress invocava até para hooks de terceiros fora dos 18 observados. A 1.71.0 instala um observador apenas nos 18 hooks que acompanha. Os callbacks dos módulos registrados explicitamente e as cargas de classe continuam cronometrados. O observador devolve o primeiro argumento do filtro, preserva prioridades e permite remover o callback por sua identidade original.

A soma agora usa os valores com sua precisão original. Cada módulo e o total só são arredondados na apresentação. Uma fixture com três intervalos de 0,0004 ms resulta em total de 0,001 ms, apesar de cada linha exibir zero a três casas decimais. O início da montagem do relatório é o instante de corte para as duas janelas. Classificação, contagem de classes e consulta ao estado de OPcache e realpath ocorrem depois desse corte.

A resposta interna de página ou login contém uma prova específica da solicitação. Uma resposta anterior do cache perde a validade para uma nova sondagem. O leitor confere a prova, o contexto e a versão. O comentário só é emitido para uma solicitação assinada para aquele caminho. As opções públicas da operação e a estrutura do relatório lido pelo administrador continuam vigentes.

## Como ler os dados

| Dado | Interpretação |
|---|---|
| `modulos[].total_ms` | Tempo decorrido nos intervalos concluídos daquele módulo e fase, incluindo filhos. Valores são cumulativos quando o callback se repete. |
| `total_proprio_ms` | Soma dos intervalos concluídos após descontar os filhos também cronometrados. Inclui espera, banco e efeitos dos serviços chamados dentro de cada intervalo. Mede parte do trabalho associado ao Core. CPU exclusiva e diferença de latência ao ativar o plugin exigem outras medições. |
| `nao_instrumentado_ms` | Tempo desde a entrada no arquivo principal até o corte, menos a soma instrumentada. Inclui trechos do Core, WordPress, tema, acompanhantes e parte do custo da instrumentação. |
| `geracao_ate_agora_ms` | Tempo desde `REQUEST_TIME_FLOAT` até o corte. Em sondagem de página/login, o corte ocorre no footer. O envio HTTP e o processamento do navegador ficam fora dessa janela. |
| `consultas_total` | Quantidade de SQL que atravessou o filtro `query` durante um intervalo instrumentado, atribuída ao contexto aberto mais interno. Outros plugins podem fazer consultas dentro desse contexto. |
| `consultas` | No máximo 200 formas por requisição. A inspeção examina até os primeiros 2.048 bytes por instrução. Operação reconhecível, tabela quando reconhecida, callback e marca de estrutura. O nome de option só aparece na lista fixa de nomes públicos do Core e opções nativas selecionadas. Valores, SQL íntegro e identificadores dinâmicos de transient ficam fora da resposta. |
| `amostras` | De uma a três solicitações sintéticas por operação, da mesma origem e sem cookies. Falha, ausência de marcador da solicitação ou incoerência de contexto/versão impede aceitar aquela amostra. Não descrever esse conjunto como distribuição de tráfego real. |

O profiler mantém os registros na memória da requisição. A leitura de ambiente acompanha a configuração efetiva do processo. Os contadores de OPcache e do cache de caminhos pertencem ao ambiente e podem refletir outros pedidos. Uma página entregue inteiramente por cache antes da execução do WordPress está fora dessa medição. Renderização final do navegador, long tasks e TTFB exigem dados coletados nas respectivas etapas.

## Evidência

O teste `tests/sonda-php-1710.php` passou nas 44 verificações de `sonda-php-testes.json`, em PHP 8.3.6 com o despachante de hooks de WordPress 7.1.4. A prova usa WP_Hook real e simula o transporte HTTP para reproduzir marcadores vencidos, página trocada e falta de assinatura. Outros 23 cenários passaram no teste HTTP com PHP e o mesmo despachante, incluindo HEAD, cookies, pacote autenticado, REST com prefixo personalizado, rotas MCP, falta/falsificação de assinatura, sondas por caminho e opt-in. O roteador isola o perfil em um processo de servidor real e simula a identificação de rotas e contexto. Ver `sonda-php-http.json`. Os mesmos callbacks de teste produziram a mesma resposta funcional com o perfil ligado e desligado.

Comandos a partir da raiz do fonte, apontando a uma instalação WordPress 7.1.4 e a um PHP 8.3 disponível:

```sh
build/php tests/sonda-php-1710.php /caminho/wordpress
python3 tests/sonda-php-1710-http.py /caminho/wordpress
build/php tests/sonda-php-1710-dispatch.php /caminho/wordpress /caminho/do/plugin
```

No microbenchmark de despacho com perfil habilitado, cada amostra executou 42.000 filtros com um callback externo. Em cada grupo de 21 filtros, 20 estavam fora do conjunto observado. Foram 12 pares em ordem alternada, com aquecimento em cada processo. As medianas de tempo decorrido foram **52,739 ms na 1.70.0 e 28,813 ms na 1.71.0** para esse lote. Os valores individuais estão em `sonda-php-dispatch.json`. Essa carga sintética isola o despacho de hooks. A diferença marginal em páginas completas depende do teste HTTP com o Core ativo e inativo.
