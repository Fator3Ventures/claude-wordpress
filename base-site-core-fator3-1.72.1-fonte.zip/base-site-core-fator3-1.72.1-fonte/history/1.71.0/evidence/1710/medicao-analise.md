# Medição do Core 1.71.0

## Dados de campo disponíveis

Consulta agregada ao Site-Teste por `f3base/vitais-ler`. Período de 9 de outubro a 5 de novembro de 2026, inclusive, no fuso America/Sao_Paulo. A consulta precedeu a implantação da versão 1.71.0. O JSON `medicao-1710-campo.json` conserva apenas contagens e percentis. O legado corresponde a linhas antigas sem classificação de automação.

| Métrica | N elegível, sem testes | p75, sem testes | Legado excluído | N de testes marcados, todas as classes | p75 dos testes |
|---|---:|---:|---:|---:|---:|
| TTFB | 2 | 862 ms | 2 | 81 | 649 ms |
| LCP | 2 | 1.184 ms | 2 | 70 | 952 ms |
| CLS | 2 | 0 | 2 | 38 | 0 |
| INP | 0 | Sem amostra | 2 | 4 | 96 ms |

Nenhuma observação adicional foi excluída por automação provável/declarada no primeiro recorte. “Sem testes” indica ausência da marca de teste e a classificação de audiência depende dos sinais disponíveis. As duas medidas elegíveis de LCP contêm atribuição. O seletor estrutural indica texto, e a média da fase TTFB foi 827,75 ms. A origem da espera permanece indeterminada. Com N=2, a posição ceil(0,75 × 2) é 2 e o p75 coincide com o maior valor. A diferença de volume entre carregamentos de teste e audiência impede usar o conjunto de testes como substituto de observações de campo.

## O que cada camada conta

| Fonte | Unidade e dados úteis | Condições de inclusão e limitações |
|---|---|---|
| Acessos do servidor | Requisições presentes nos arquivos de log aceitos pelo importador; data, caminho e classificação técnica agregados. | Cobertura depende dos arquivos disponíveis e do ponto que atende a requisição. Redirecionamentos, robôs e camadas de cache podem alterar a população. Uma requisição não identifica um visitante nem comprova execução de JS. |
| Resumo e registro de comportamento | Ocorrências de gatilhos declarados, como página, rolagem, seção, interação e saída. O registro detalhado pode ligar eventos à visita/ao visitante por pseudônimos. | Exige configuração e consentimento de medição no cliente. Orçamentos, armazenamento bloqueado, limites de envio e saída precoce geram perda. O resumo e o registro detalhado têm retenção e cobertura próprias. |
| Amostras locais de vitais | Maior sequência recebida por ID de carregamento, métrica e caminho. TTFB/LCP/INP em ms e CLS sem unidade. Agrupa por caminho, largura (móvel até 767 px), segmento, data e automação. | A tabela de vitais não grava pseudônimo pessoal. Percentil por métrica usa apenas linhas elegíveis daquela métrica. INP depende de interação mensurável. TTFB inclui rede, conexão, redirecionamentos e aplicação. Reenvio não aumenta N. |
| Análise de sessões, ofertas e formulários | Evento de análise, instante, chaves técnicas pseudônimas de sessão/visita/navegação, contexto permitido e sequência. Permite relacionar eventos e etapas efetivamente observadas. | O emissor exige contexto e pseudônimo de visitante. A fila de análise conserva até 100 eventos, expira após 24 horas e registra contadores de limite, expiração, rejeição e confirmações. O número de sessões com um evento não corresponde ao número total de visitantes nem a todas as requisições. |
| Sonda sintética HTTP / perfil PHP | Tempo da resposta nas condições medidas, consultas e custo instrumental da requisição observada. | Sondas marcadas, agentes, cache, rede, ordem e carga alteram os resultados. Estimar impacto causal exige comparar a mesma página e condições com a versão ou o Core alternados. O tempo no servidor isolado não é LCP/INP do navegador. |

Os caminhos públicos têm query e fragmento removidos no cliente. Atribuição INP usa seletor por tags e posições, classe de interação, fases disponíveis e, quando há LoAF, origem de script coincidente. O recurso LCP pode incluir origem e caminho sem query ou fragmento. Caminhos livres ainda podem carregar identificadores de negócio. O código limita formatos e tamanhos, e a tabela de vitais guarda o hash técnico da chave de amostra. As tabelas de sessões e análise têm pseudônimos e finalidades diferentes. A auditoria salvou somente agregados e fixtures.

## Como o número chega ao painel

1. O navegador passa pelo consentimento de medição e verifica os recursos disponíveis. A biblioteca web-vitals local, com as adaptações já existentes, produz callbacks de métricas. O filtro de consentimento da 1.71.0 atua antes do cálculo de atribuição ou da emissão de revisões.
2. O coletor arredonda milissegundos e CLS, emite o primeiro evento e atualiza localmente a mesma amostra em revisões seguintes. A tabela retém a maior sequência aceita (até 60) por chave. Tentativas repetidas e revisões antigas mantêm uma só linha. O registro detalhado do comportamento guarda só a primeira emissão. A trilha de análise vinculada tem armazenamento e confirmação independentes.
3. A rota aplica limites de carga, escopo do evento, formato e intervalo dos valores. A 1.71.0 também rejeita tipo, recurso, origem, sinal LoAF e fase incompatíveis com a métrica. CLS e TTFB não aceitam atribuição de INP/LCP. A rejeição ocorre antes da persistência da linha.
4. A consulta padrão considera audiência sem marca de teste e exclui automação detectada e legado. Ordena os valores válidos por métrica, escolhe a posição ceil(0,75 × N) e expõe separadamente os descartes por classe. N=0 produz p75 ausente. Zero continua sendo um valor válido. A tela diferencia indisponibilidade de consulta, ausência de amostras e zero medido.
5. O relatório informa quantas amostras sustentam cada média de fase (`fases_amostras`). `amostras_fases_completas` identifica o subconjunto comum usado para comparar todas as fases e escolher a maior média; empate ou ausência de casos completos resulta em fase dominante nula. Amostras incompletas permanecem no p75 da métrica. A leitura de atribuição usa paginação por chave em lotes de 500, apenas para métricas com atribuição. Na tabela administrativa, ou com a opção aditiva `somente_resumo=true` na ability, o Core devolve apenas contagens e p75, informa o modo usado e não consulta a coluna de atribuição. O modo padrão da ability continua detalhado.

## Correções comprováveis

- **LCP em documento pré-renderizado.** O código 1.70.0 descontava a ativação no TTFB, mas comparava os tempos absolutos do recurso com o valor relativo de LCP. No fixture com ativação em 1.000 ms, início da requisição em 1.060 ms, fim em 1.180 ms e LCP de 300 ms, a 1.71.0 produz fases de 0, 60, 120 e 120 ms. Ausência de relógio de resposta mantém a fase ausente. Restauração pelo cache de navegação e navegação suave não herdam a cronologia da navegação anterior.
- **Percentil ausente.** A tela anterior enviava p75 nulo ao formatador numérico e a leitura de percentil convertia ausência/erro SQL em zero. O novo painel mostra exclusões e uma mensagem para cada situação.
- **Fases com populações diferentes.** Uma única fase TTFB presente num carregamento atípico inflava a comparação com fases calculadas em outro conjunto. O teste separa as médias descritivas da comparação em casos completos. Uma associação temporal entre um script e a interação continua insuficiente para atribuir causa.
- **Privacidade e custo.** Ao receber callback depois da retirada da permissão, o coletor interrompe o processamento antes de percorrer recursos/estruturas do DOM ou atualizar sequências. A atribuição inválida de uma métrica não é armazenada nem resumida. O informe de TTFB deixou de atribuir toda a demora à hospedagem.

## Limites observados

A permissão é verificada na emissão. Observadores de desempenho já iniciados permanecem na página e o navegador mantém sua própria cronologia de navegação. Um novo aceite no mesmo documento não redefine a origem temporal das métricas. A verificação do teste cobre a ausência de emissão/atribuição enquanto a permissão está negada.

O teto de 75.000 linhas consulta o total antes de admitir uma nova chave; a verificação e a inserção são operações distintas. O teto protege orçamento, mas o caminho pode ter custo maior sob alta cardinalidade e permite corrida entre inserções novas próximas ao limite. A amostra de campo disponível não mede essa carga. A rota devolve 503 a lotes recusados por orçamento/armazenamento, e a recuperação depende da fila e de sua validade. O resumo misto pode confirmar uma gravação parcial e indica quantos itens gravou. Os contadores do navegador dependem de armazenamento e de consentimento, portanto não há denominador universal para computar a fração de carregamentos perdidos. Nenhum dado atual sustenta uma conclusão sobre desempenho de toda a audiência ou impacto causal em conversões.

## Reprodução

Resultado final registrado: 27/27 verificações PHP/WordPress/MySQL e 54/54 verificações JS distribuídas entre fonte, minificado, perfis públicos 0 e 31 e perfis de tracking 0 e 31.

- `tests/medicao-1710-cliente.cjs` carrega o cliente integral em jsdom com entradas e consentimento controlados e inspeciona as amostras que o cliente efetivamente persiste. Também cobre revisão, repetição, ausência de fases, sanitização do recurso e revogação. Executar após gerar os perfis e instalar as dependências de testes.
- `tests/medicao-1710-relatorio.php` usa WordPress e MySQL da bancada, com tabela temporária exclusiva da conexão. Exercita os validadores de entrada, persistência e idempotência, percentil, separação de públicos, ausência vs. zero no HTML, falha SQL e paginação acima de 500 registros.
- As entradas controladas verificam cálculos e limites do código. Os dados de campo vêm da consulta de leitura anterior à implantação, não dos testes.

Referências de semântica: [decomposição de LCP](https://web.dev/articles/optimize-lcp), [origem de tempo na implementação de referência](https://github.com/GoogleChrome/web-vitals/blob/main/src/attribution/onLCP.ts), [componentes de TTFB](https://web.dev/articles/ttfb).
