# Fator3 Site Core 1.71.0

A base desta rodada é a 1.70.0. O diretório `work/plugin/base-site-core-fator3` reproduz o instalador. O plano está em `PLANO-1.71.0.md` e as provas em `evidence/1710`. Consulte `build/README.md` para reproduzir a validação e `docs/MEDICAO-DESEMPENHO.md` no plugin para interpretar as métricas.
