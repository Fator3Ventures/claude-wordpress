"""Compara GET/HEAD reais, com e sem perfil, sem gravar dados no WordPress."""
from base64 import b64decode
from hashlib import sha256
import hmac
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from urllib.request import Request, urlopen

root = Path(__file__).resolve().parents[1]
wp = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / 'lab/wordpress'
with socket.socket() as socket_livre:
    socket_livre.bind(('127.0.0.1', 0))
    porta = socket_livre.getsockname()[1]
base = f'http://127.0.0.1:{porta}'
server = subprocess.Popen(
    [str(root / 'build/php'), '-S', f'127.0.0.1:{porta}', str(root / 'tests/sonda-php-1710-http.php')],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=dict(os.environ, F3_SONDA_WP=str(wp)))
try:
    for _ in range(80):
        try:
            with socket.create_connection(('127.0.0.1', porta), timeout=.2):
                break
        except OSError:
            time.sleep(.02)
    now = int(time.time())
    def assinada(path, instante=now):
        inicio = f'{instante}.'+'2'*32
        autentica = hmac.new(b'chave-local-descartavel-da-fixture',f'{inicio}|{path}'.encode(),sha256).hexdigest()
        return {'X-F3base-Desempenho':inicio+'.'+autentica}
    casos = [
        ('pagina', '/', 'GET', {}, False, False),
        ('artigo', '/artigo/', 'GET', {}, False, False),
        ('login', '/wp-login.php', 'GET', {}, False, False),
        ('head', '/artigo/', 'HEAD', {}, False, False),
        ('cookie_comum', '/', 'GET', {'Cookie':'visitante=123'}, False, False),
        ('assinatura_malformada', '/', 'GET', {'X-F3base-Desempenho':'x'}, False, False),
        ('assinatura_incorreta', '/', 'GET', {'X-F3base-Desempenho':f'{now}.'+'2'*32+'.'+'0'*64}, False, False),
        ('assinatura_expirada', '/', 'GET', assinada('/',now-120), False, False),
        ('assinatura_outro_caminho', '/artigo/', 'GET', assinada('/'), False, False),
        ('sonda_pagina', '/', 'GET', assinada('/'), True, True),
        ('sonda_login', '/wp-login.php', 'GET', assinada('/wp-login.php'), True, True),
        ('sonda_artigo', '/artigo/', 'GET', assinada('/artigo/'), True, True),
        ('administracao', '/wp-admin/index.php', 'GET', {}, True, False),
        ('cron', '/wp-cron.php', 'GET', {}, True, False),
        ('usuario_com_sessao', '/', 'GET', {'Cookie':'sessao_teste=fixture'}, True, False),
        ('autorizacao_http', '/mcp/', 'GET', {'Authorization':'Bearer teste-local'}, True, False),
        ('rest', '/wp-json/f3base/v1/desempenho', 'GET', {}, True, False),
        ('rest_indice', '/subsite/wp-json', 'GET', {}, True, False),
        ('rest_personalizada', '/subsite/api/f3base/v1/desempenho', 'GET', {'X-Prefixo-Teste':'api'}, True, False),
        ('rest_query', '/?rest_route=/f3base/v1/desempenho', 'GET', {}, True, False),
        ('rest_constante', '/outra-rota', 'GET', {'X-Rest-Teste':'1'}, True, False),
        ('post_mcp', '/mcp/', 'POST', {}, True, False),
        ('perfil_explicito', '/artigo/', 'GET', {'X-Optin-Teste':'1'}, True, False),
    ]
    aprovados = []
    for nome, path, method, headers, ativo, marca in casos:
        request = Request(base+path,method=method,headers=headers)
        with urlopen(request,timeout=5) as response:
            facts = json.loads(b64decode(response.headers['X-Dados-Sonda']))
        assert facts == {
            'ativo':ativo, 'codigo':None if ativo else 'requisicao_sem_perfil',
            'sql':ativo,'wrapper':ativo,'valor':'valor-ok','consultas':2 if ativo else None,
            'marca':marca,'carga_medida':ativo
        }, (nome, facts)
        aprovados.append(nome)
    print(json.dumps({'cenarios':len(aprovados),'provas':aprovados},ensure_ascii=False,indent=2))
finally:
    server.terminate()
    server.wait(timeout=10)
