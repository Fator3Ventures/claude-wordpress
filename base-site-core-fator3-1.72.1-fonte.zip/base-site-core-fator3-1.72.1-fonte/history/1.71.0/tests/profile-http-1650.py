from pathlib import Path
import os,subprocess,urllib.request,json,time,re,base64,socket
root=Path(__file__).resolve().parents[1];site=Path(os.environ['F3BASE_LAB_DIR'])/'wordpress';out=Path(os.environ.get('F3BASE_PROFILE_OUTPUT',str(root/'evidence/1650')));out.mkdir(parents=True,exist_ok=True)
mu=site/'wp-content/mu-plugins/profile1650.php'
mu.write_text("<?php\ndefine('F3BASE_PERFIL_PHP',true);\nadd_action('f3base_perfil_catalogo',static function(){file_put_contents(getenv('F3BASE_ROOT').'/evidence/1650/catalog-trace.json',json_encode(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,30),JSON_PRETTY_PRINT));});$qa1640_report=static function(){if(class_exists('F3Base_Desempenho',false)){file_put_contents(getenv('F3BASE_ROOT').'/evidence/1650/http-last.json',json_encode(F3Base_Desempenho::resumo(),JSON_PRETTY_PRINT));}};add_action('wp_footer',$qa1640_report,PHP_INT_MAX);add_action('login_footer',$qa1640_report,PHP_INT_MAX);\n")
allow=json.loads((root/'tests/public-classes-1640.json').read_text())
summary=[]
log=open(out/'http-server.log','w');server=subprocess.Popen([str(root/'build/php'),'-d','zend_extension='+str(Path(os.environ['F3BASE_RUNTIME'])/'usr/lib/php/20230831/opcache.so'),'-d','opcache.enable_cli=1','-d','opcache.revalidate_freq=0','-S','127.0.0.1:8136','-t',str(site)],env=os.environ,stdout=log,stderr=log)
try:
 for i in range(30):
  try:
   with socket.create_connection(('127.0.0.1',8136),.1):break
  except OSError:time.sleep(.1)
 # Settle derived state after installing/configuring the disposable fixture.
 # Stable-request budgets apply to every subsequent request, including warmup.
 for label,path in [('prepare','/'),('warmup','/'),('page1','/'),('page2','/'),('page3','/'),('login1','/wp-login.php'),('login2','/wp-login.php'),('login3','/wp-login.php')]:
  (out/'http-last.json').unlink(missing_ok=True)
  try:
   with urllib.request.urlopen('http://127.0.0.1:8136'+path,timeout=30) as response:body=response.read();status=response.status
  except urllib.error.HTTPError as e:body=e.read();status=e.code
  assert status==200 and len(body)>1000,(label,status,len(body))
  assert b'loginform' in body if label.startswith('login') else b'qa360-footer' in body and b'qa360-page' in body,label
  (out/(label+'-html.html')).write_bytes(body)
  profile=json.loads((root/'evidence/1650/http-last.json').read_text());(out/(label+'-profile.json')).write_text(json.dumps(profile,indent=2))
  if label=='prepare':continue
  unexpected=set(profile['classes_carregadas'])-set(allow['login' if label.startswith('login') else 'pagina'])
  assert profile.get('catalogo_completo',{}).get('aberturas',0)==0,(label,profile.get('catalogo_completo'))
  assert not any(q['estrutura'] or q['operacao']=='UPDATE' for q in profile['consultas']),(label,profile['consultas'])
  assert profile['consultas_total']<=5,(label,profile['consultas_total'])
  assert len(profile['classes_carregadas'])<=60,(label,len(profile['classes_carregadas']))
  if label!='warmup':assert profile['total_proprio_ms']<=(50 if label.startswith('login') else 100),(label,profile['total_proprio_ms'])
  discovery=sum(m['total_ms'] for m in profile['modulos'] if '::descoberta' in m['modulo'])
  assert discovery<=5,(label,discovery)
  summary.append({'amostra':label,'status':status,'bytes_html':len(body),'footer':True,'classes':len(profile['classes_carregadas']),'consultas':profile['consultas_total'],'core_ms':profile['total_proprio_ms'],'nao_instrumentado_ms':profile['nao_instrumentado_ms'],'descoberta_ms':discovery})
  print(label,status,'classes',len(profile['classes_carregadas']),'queries',profile['consultas_total'],'own_ms',profile['total_proprio_ms'],flush=True)
 (out/'performance-1650.json').write_text(json.dumps({'escopo':'PHP 8.3.6 + WP 7.1.4, tema nativo de teste, 50 itens; MCP/Google/Meta/LinkedIn ativos. Sem Yoast/PD na bancada local. Medição até footer.','amostras':summary},indent=2))
finally:server.terminate();server.wait();log.close();mu.unlink()
