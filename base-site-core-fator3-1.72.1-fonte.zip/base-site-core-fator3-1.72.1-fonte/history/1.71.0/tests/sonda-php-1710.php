<?php
/** Teste do profiler com WP_Hook real. Não carrega dados nem conecta ao banco. */
declare(strict_types=1);
$root=dirname(__DIR__);
$wp=$argv[1]??(getenv('F3BASE_LAB_DIR')?:$root.'/lab').'/wordpress';
define('ABSPATH',rtrim($wp,'/').'/');
define('F3BASE_PLUGIN_DIR',$root.'/work/plugin/base-site-core-fator3/');
define('F3BASE_PLUGIN_VERSAO','teste');
define('F3BASE_INICIO',microtime(true));
$_SERVER['REQUEST_TIME_FLOAT']=F3BASE_INICIO;
require ABSPATH.'wp-includes/plugin.php';
require F3BASE_PLUGIN_DIR.'includes/class-f3base-desempenho.php';

function wp_doing_cron(): bool{return false;}
function is_admin(): bool {if(!empty($GLOBALS['atrasar_relatorio'])){usleep(60_000);}return false;}
function current_user_can(string $cap): bool{return $cap==='manage_options'&&!empty($GLOBALS['admin_teste']);}
function teste(bool $ok,string $nome): void {
    if(!$ok){throw new RuntimeException($nome);}
    $GLOBALS['aprovados'][]=$nome;
}
function linha(array $resumo,string $fase,string $modulo): ?array {
    foreach($resumo['modulos'] as $linha){
        if($linha['fase']===$fase&&$linha['modulo']===$modulo){return $linha;}
    }
    return null;
}
final class F3Base_Teste_Sonda {
    public static function texto(string $valor,string $extra): string {
        apply_filters('query',"SELECT option_value FROM wp_options WHERE option_name = 'home'");
        return $valor.$extra;
    }
    public static function zero(): void {
        ++$GLOBALS['sem_argumentos'];
    }
}
$GLOBALS['sem_argumentos']=0;
F3Base_Desempenho::iniciar();
teste(!has_filter('all'),'sem_despacho_global');
teste(!has_filter('evento_sem_relacao'),'sem_observador_em_hook_externo');
teste(apply_filters('wpseo_schema_graph',['x'=>1])===['x'=>1],'observador_preserva_tipo_e_valor');
teste(apply_filters('render_block',null)===null,'observador_preserva_nulo');
add_action('wp_loaded',[F3Base_Teste_Sonda::class,'zero'],20,0);
do_action('wp_loaded');
teste($GLOBALS['sem_argumentos']===1,'acao_sem_argumentos_chamada_uma_vez');

$cb=[F3Base_Teste_Sonda::class,'texto'];
add_filter('the_content',static fn($v)=>strtoupper($v),5);
add_filter('the_content',$cb,10,2);
teste(apply_filters('the_content','a','!')==='A!','ordem_argumentos_e_retorno');
teste(apply_filters('the_content','b','?')==='B?','repeticao_sem_duplicar_callback');
teste(remove_filter('the_content',$cb,10),'remocao_por_identidade_original');
teste(apply_filters('the_content','c','?')==='C','remocao_efetiva');
add_filter('the_content',$cb,25,2);
teste(apply_filters('the_content','d','*')==='D*','registro_tardio_observado');
$r=F3Base_Desempenho::resumo();
$row=linha($r,'the_content','F3Base_Teste_Sonda::texto');
teste(($row['chamadas']??0)===3,'medicao_uma_vez_por_callback');
teste($r['consultas_total']===3&&$r['consultas'][0]['callback']==='F3Base_Teste_Sonda::texto:the_content','sql_atribuido_ao_intervalo');
teste($r['consultas'][0]['tabela']==='wp_options'&&$r['consultas'][0]['option']==='home','forma_sql_conhecida');

apply_filters('query','SELECT * FROM tabela_externa');
teste(F3Base_Desempenho::resumo()['consultas_total']===3,'sql_fora_de_intervalo_omitido');
$sql=[
    "SELECT option_value FROM wp_options WHERE option_name = '_transient_sessao_privada_364'",
    "SELECT 'FROM dado_privado' AS teste FROM wp_options",
    "SELECT option_value FROM wp_options WHERE option_name = 'f3base_consentimento'",
    "TRUNCATE TABLE `wp_teste`",
    "CREATE TABLE IF NOT EXISTS `wp_teste` (id INT)",
    "INSERT INTO wp_teste (id) VALUES (42)",
];
try {
    F3Base_Desempenho::medir('externo','pai',static function()use($sql){
        return F3Base_Desempenho::medir('interno','filho',static function()use($sql){
            foreach($sql as $consulta){teste(apply_filters('query',$consulta)===$consulta,'sql_intacto_'.strtok($consulta,' '));}
            usleep(2_000);
            throw new RuntimeException('esperada');
        });
    });
    throw new RuntimeException('excecao_nao_propagada');
} catch(RuntimeException $e) {
    teste($e->getMessage()==='esperada','excecao_propagada');
}
$r=F3Base_Desempenho::resumo();
$q=array_slice($r['consultas'],3);
teste($q[0]['option']===null&&!str_contains(json_encode($r['consultas']),'privada'),'identificador_dinamico_omitido');
teste($q[1]['tabela']===''&&!str_contains(json_encode($r['consultas']),'dado_privado'),'literal_sql_nao_inventa_tabela');
teste($q[2]['option']==='f3base_consentimento','nome_publico_permitido');
teste($q[3]['estrutura']&&$q[3]['tabela']==='wp_teste'&&$q[4]['tabela']==='wp_teste','ddl_identificado');
teste($q[5]['operacao']==='INSERT'&&$q[5]['tabela']==='wp_teste','insert_identificado');
teste($q[0]['callback']==='interno:filho','sql_pelo_filho_mais_interno');
$pai=linha($r,'pai','externo');
$filho=linha($r,'filho','interno');
teste($filho['proprio_ms']>=1.5&&abs(($pai['total_ms']-$pai['proprio_ms'])-$filho['total_ms'])<0.003,'desconto_do_filho_mesmo_em_excecao');
apply_filters('query','SELECT * FROM tabela_externa');
teste(F3Base_Desempenho::resumo()['consultas_total']===9,'pilha_limpa_apos_excecao');
F3Base_Desempenho::medir('rajada','banco',static function(){
    for($i=0;$i<210;$i++){apply_filters('query','SELECT * FROM wp_posts');}
});
$r=F3Base_Desempenho::resumo();
teste(count($r['consultas'])===200&&$r['consultas_total']===219,'limite_de_detalhe_com_total_completo');
teste(F3Base_Desempenho::ler()['codigo']==='sem_permissao','leitura_requer_administrador');

$prop=new ReflectionProperty(F3Base_Desempenho::class,'rows');
$rows=[];
foreach(['a','b','c'] as $nome){$rows[$nome]=['modulo'=>$nome,'fase'=>'fixture','chamadas'=>1,'total_ms'=>0.0004,'proprio_ms'=>0.0004];}
$prop->setValue(null,$rows);
$GLOBALS['atrasar_relatorio']=true;
$r=F3Base_Desempenho::resumo();
$ate_saida=(microtime(true)-F3BASE_INICIO)*1000;
teste($r['total_proprio_ms']===0.001&&array_sum(array_column($r['modulos'],'proprio_ms'))===0.0,'soma_antes_do_arredondamento');
teste($ate_saida-$r['geracao_ate_agora_ms']>=50,'preparacao_do_relatorio_fora_da_janela');
teste(abs($r['nao_instrumentado_ms']+$r['total_proprio_ms']-$r['geracao_ate_agora_ms'])<0.002,'mesmo_instante_para_as_janelas');
/** Transporte simulado; o marcador e a leitura são executados pelo código real da sonda. */
function site_url($path): string{return 'https://teste.invalid/'.$path;}
function home_url($path): string{return 'https://teste.invalid'.$path;}
function wp_parse_url($url,$component){return parse_url($url,$component);}
function wp_salt($scheme): string{return 'chave-local-descartavel-da-fixture';}
function add_query_arg($key,$value,$url): string{return $url.'?'.$key.'='.$value;}
function wp_json_encode($value){return json_encode($value);}
function wp_remote_retrieve_response_code($response){return $response['status'];}
function wp_remote_retrieve_body($response){return $response['body'];}
function is_wp_error($r): bool{return false;}
function wp_safe_remote_get($url,$args): array {
    $path=parse_url($url,PHP_URL_PATH);
    $GLOBALS['pagenow']=$path==='/wp-login.php'?'wp-login.php':'index.php';
    $_SERVER['REQUEST_URI']=$path;
    $_SERVER['HTTP_X_F3BASE_DESEMPENHO']=$args['headers']['X-F3Base-Desempenho'];
    $GLOBALS['isolamento']=$args['cookies']===[]&&$args['redirection']===0;
    $cenario=$GLOBALS['resposta_da_sonda'];
    if($cenario==='anterior'){return ['status'=>200,'body'=>$GLOBALS['ultima_pagina']];}
    if($cenario==='outro_caminho'){$_SERVER['REQUEST_URI']='/outra-pagina';}
    if($cenario==='sem_assinatura'){unset($_SERVER['HTTP_X_F3BASE_DESEMPENHO']);}
    (new ReflectionProperty(F3Base_Desempenho::class,'printed'))->setValue(null,false);
    ob_start();
    F3Base_Desempenho::imprimir();
    $body=ob_get_clean();
    if($cenario==='contexto_incorreto'||$cenario==='versao_incorreta'){
        $body=preg_replace_callback('~(<!--f3base-desempenho:)([A-Za-z0-9+/=]+)(-->)~',static function($m)use($cenario){
            $json=json_decode(base64_decode($m[2]),true);
            if($cenario==='contexto_incorreto'){$json['contexto']='cron';}else{$json['versao']='0.0.0';}
            return $m[1].base64_encode(json_encode($json)).$m[3];
        },$body);
    }
    $GLOBALS['ultima_pagina']=$body;
    return ['status'=>200,'body'=>$body];
}
$GLOBALS['atrasar_relatorio']=false;
$GLOBALS['admin_teste']=true;
foreach(['pagina','login'] as $contexto){
    $GLOBALS['resposta_da_sonda']='atual';
    $saida=F3Base_Desempenho::ler(['contexto'=>$contexto,'amostras'=>2]);
    teste($saida['ok']&&count($saida['amostras'])===2&&$saida['amostras'][0]['contexto']===$contexto,'duas_amostras_comprovadas_'.$contexto);
    teste($GLOBALS['isolamento'],'transporte_sem_cookies_nem_redirecao_'.$contexto);
    $GLOBALS['resposta_da_sonda']='anterior';
    $saida=F3Base_Desempenho::ler(['contexto'=>$contexto]);
    teste(!$saida['ok']&&$saida['amostras'][0]['codigo']==='sonda_sem_relatorio','cache_anterior_recusado_'.$contexto);
}
foreach(['outro_caminho','sem_assinatura','contexto_incorreto','versao_incorreta'] as $cenario){
    $GLOBALS['resposta_da_sonda']=$cenario;
    $saida=F3Base_Desempenho::ler(['contexto'=>'login']);
    teste(!$saida['ok']&&!$saida['amostras'][0]['ok'],'sonda_recusa_'.$cenario);
}
echo json_encode(['aprovados'=>count($GLOBALS['aprovados']),'php'=>PHP_VERSION,'provas'=>$GLOBALS['aprovados']],JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n";
