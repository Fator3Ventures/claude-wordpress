"""Exercita as entradas reais de página, login, REST, painel e cron em WP local já instalado."""
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
SITE = Path(os.environ.get('F3BASE_SITE', ROOT / 'lab/wordpress/wp-load.php')).parent
PORTA = int(os.environ.get('F3BASE_TEST_HTTP_PORT', '8136'))
HOST = f'127.0.0.1:{PORTA}'
ROTAS = {
    'pagina': '/',
    'login': '/wp-login.php',
    'contexto': '/?rest_route=/f3base/v1/contexto-publico',
    'rest': '/?rest_route=/wp/v2/types',
    'admin': '/wp-admin/index.php',
    'cron': '/wp-cron.php?doing_wp_cron=1',
}


class RedirecionamentoLocal(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args):
        return None


def observar(cliente, rota, evidencia):
    evidencia.unlink(missing_ok=True)
    try:
        resposta = cliente.open(f'http://{HOST}{rota}', timeout=30)
    except urllib.error.HTTPError as erro:
        resposta = erro
    with resposta:
        corpo = resposta.read()
    for _ in range(100):
        if evidencia.is_file() and evidencia.stat().st_size:
            break
        time.sleep(.02)
    valor = json.loads(evidencia.read_text())
    assert valor['local'] and valor['filtro_sessao'] == 10000, rota
    valor.update(status=resposta.status, bytes_resposta=len(corpo))
    return valor


def executar(tmp):
    host_sql = os.environ.get('F3BASE_DB_HOST', '127.0.0.1:33436')
    banco = os.environ.get('F3BASE_LAB_DB', 'core_lab')
    if not re.fullmatch(r'127\.0\.0\.1(:[0-9]+)?', host_sql) or not re.fullmatch(r'core_[a-z0-9_]+', banco):
        raise ValueError('O teste HTTP requer uma base descartável local core_*')
    evidencia = tmp / 'resumo.json'
    probe = tmp / 'registro.php'
    probe.write_text("""<?php
register_shutdown_function(static function () {
    if (!function_exists('wp_get_environment_type')) { return; }
    $arquivos = [];
    foreach (get_included_files() as $file) {
        if (str_starts_with(basename($file), 'bootstrap-hooks')) { $arquivos[] = basename($file); }
    }
    file_put_contents(getenv('F3BASE_TEST_REGISTRO'), json_encode([
        'arquivos' => $arquivos,
        'perfil_publico' => F3Base_Perfil_Publico::ativo(),
        'cron' => wp_doing_cron(),
        'admin' => is_admin(),
        'rest' => did_action('rest_api_init'),
        'filtro_sessao' => has_filter('auth_cookie_expiration', ['F3Base_Sessao_Admin', 'expiracao']),
        'local' => wp_get_environment_type() === 'local',
    ]));
});""")
    env = dict(os.environ, F3BASE_TEST_REGISTRO=str(evidencia))
    cmd = [ROOT / 'build/php', '-d', 'auto_prepend_file=' + str(probe), '-S', HOST, '-t', SITE]
    with (tmp / 'servidor.log').open('w') as log:
        servidor = subprocess.Popen(cmd, env=env, stdout=log, stderr=log)
        try:
            for _ in range(100):
                if servidor.poll() is not None:
                    raise RuntimeError('Servidor PHP falhou ao iniciar')
                try:
                    with socket.create_connection(('127.0.0.1', PORTA), timeout=.1):
                        break
                except OSError:
                    time.sleep(.05)
            cliente = urllib.request.build_opener(RedirecionamentoLocal)
            resultado = {nome: observar(cliente, rota, evidencia) for nome, rota in ROTAS.items()}
        finally:
            servidor.terminate()
            servidor.wait(timeout=10)
    for nome, valor in resultado.items():
        assert valor['status'] == (302 if nome == 'admin' else 200), (nome, valor)
        assert 'bootstrap-hooks-publicos.php' in valor['arquivos'], (nome, valor)
        assert ('bootstrap-hooks.php' in valor['arquivos']) != valor['perfil_publico'], (nome, valor)
    assert all(resultado[n]['perfil_publico'] for n in ('pagina', 'login'))
    assert all(not resultado[n]['perfil_publico'] for n in ('rest', 'admin', 'cron'))
    assert resultado['contexto']['rest'] and resultado['rest']['rest']
    assert resultado['cron']['cron'] and resultado['admin']['admin']
    return resultado


if __name__ == '__main__':
    with tempfile.TemporaryDirectory() as pasta:
        print(json.dumps(executar(Path(pasta)), ensure_ascii=False, indent=2))
