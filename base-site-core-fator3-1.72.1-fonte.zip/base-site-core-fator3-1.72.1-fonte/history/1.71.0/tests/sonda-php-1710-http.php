<?php
/** Router de bancada; carrega o despachante real e simula somente o contexto/marcação do WordPress. */
declare(strict_types=1);
define('ABSPATH',rtrim(getenv('F3_SONDA_WP'),'/').'/');
define('F3BASE_PLUGIN_DIR',dirname(__DIR__).'/work/plugin/base-site-core-fator3/');
define('F3BASE_PLUGIN_VERSAO','teste');
define('F3BASE_INICIO',microtime(true));
define('LOGGED_IN_COOKIE','sessao_teste');
require ABSPATH.'wp-includes/plugin.php';
require F3BASE_PLUGIN_DIR.'includes/class-f3base-desempenho.php';
function is_admin(): bool{return str_starts_with($_SERVER['REQUEST_URI'],'/wp-admin/');}
function wp_doing_cron(): bool{return str_starts_with($_SERVER['REQUEST_URI'],'/wp-cron.php');}
function rest_get_url_prefix(): string{return $_SERVER['HTTP_X_PREFIXO_TESTE']??'wp-json';}
function wp_parse_url($url,$component){return parse_url($url,$component);}
function wp_json_encode($v){return json_encode($v);}
if(isset($_SERVER['HTTP_X_OPTIN_TESTE'])){define('F3BASE_PERFIL_PHP',true);}
if(isset($_SERVER['HTTP_X_REST_TESTE'])){define('REST_REQUEST',true);}
F3Base_Desempenho::iniciar();
F3Base_Desempenho::medir('bootstrap','carga',static fn()=>apply_filters('query','SELECT * FROM wp_posts'));
// A mesma ordem do wp-settings.php para plugins normais: wp_salt entra depois do bootstrap.
if(!function_exists('wp_salt')){function wp_salt($scheme){return 'chave-local-descartavel-da-fixture';}}
do_action('plugins_loaded');
$sql_antes=has_filter('query',[F3Base_Desempenho::class,'consulta'])!==false;
$fn=static fn($v)=>$v.'-ok';
$cb=F3Base_Desempenho::callback('the_content',$fn);
add_filter('the_content',$cb);
$valor=F3Base_Desempenho::medir('modulo','teste',static function(){
    apply_filters('query','SELECT * FROM wp_posts');
    return apply_filters('the_content','valor');
});
ob_start();
F3Base_Desempenho::imprimir();
$marca=ob_get_clean();
$sonda=F3Base_Desempenho::resumo();
$escopo=[
    'ativo'=>$sonda['ok'],'codigo'=>$sonda['codigo']??null,
    'sql'=>$sql_antes,'wrapper'=>$cb!==$fn,'valor'=>$valor,
    'consultas'=>$sonda['consultas_total']??null,'marca'=>$marca!=='',
    'carga_medida'=>in_array('bootstrap',array_column($sonda['modulos']??[],'modulo'),true),
];
header('X-Dados-Sonda: '.base64_encode(json_encode($escopo)));
header('Content-Type: application/json');
echo json_encode($escopo);
