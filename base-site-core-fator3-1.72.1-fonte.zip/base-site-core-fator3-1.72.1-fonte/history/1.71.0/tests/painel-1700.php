<?php
require __DIR__.'/bootstrap.php';
function envio_central(string $area): array {
    $r=['area'=>$area,'valores'=>[],'revisoes'=>[]];$grupos=F3Base_Config_UI::centrais($area);$fotos=F3Base_Options::fotografias(array_keys($grupos));
    foreach($grupos as $nome=>$campos){$f=$fotos[$nome];$r['revisoes'][$nome]=$f['revisao'];foreach($campos as $key=>$label){$v=$key==='_valor'?$f['valor']:($f['valor'][$key]??'');$r['valores'][$nome][$key]=is_array($v)?implode("\n",$v):(is_bool($v)?($v?'1':'0'):(string)$v);}}return $r;
}
foreach (['avisos','medicao-testes','privacidade'] as $area) {
    $e=envio_central($area);$before=F3Base_Options::fotografias_brutas(array_keys($e['valores']));$v=F3Base_Config_Central::processar($e);
    check($v['ok']&&$v['salvas']===[]&&F3Base_Options::fotografias_brutas(array_keys($e['valores']))===$before,'mantem_valor_e_revisao_'.$area);
}
$e=envio_central('avisos');$e['valores']['f3base_contato']['email_leads']='qa@example.test';$r=F3Base_Config_Central::processar($e);check($r['ok']&&$r['salvas']===['f3base_contato'],'grava_apenas_opcao_alterada');
$ok=envio_central('avisos');$old=F3Base_Options::fotografia_bruta('f3base_contato');
foreach (['ausente','array','campo_alheio','grupo_alheio','revisao','tipo_revisao'] as $falha) {
    $e=$ok;
    switch($falha){case 'ausente':unset($e['valores']['f3base_contato']['email_leads']);break;case 'array':$e['valores']['f3base_contato']['email_leads']=[];break;case 'campo_alheio':$e['valores']['f3base_contato']['ativo']='1';break;case 'grupo_alheio':$e['valores']['f3base_pipedrive']=[];break;case 'revisao':$e['revisoes']['f3base_contato']='velha';break;default:$e['revisoes']['f3base_contato']=[];}
    $r=F3Base_Config_Central::processar($e);check(!$r['ok']&&F3Base_Options::fotografia_bruta('f3base_contato')===$old,'recusa_sem_escrita_'.$falha);
}
$e=envio_central('medicao-testes');$e['valores']['f3base_pipedrive']['homologacao']='sim';check(F3Base_Config_Central::processar($e)['http']===400,'bool_estrito');$e['valores']['f3base_pipedrive']['homologacao']='1';$e['valores']['f3base_email_novo_lead']['homologacao_emails']='incorreto';$r=F3Base_Config_Central::processar($e);check(!$r['ok']&&empty(F3Base_Options::ler('f3base_pipedrive')['homologacao']),'erro_no_segundo_grupo_preserva_primeiro');
$ok['valores']['f3base_contato']['email_leads']='';$r=F3Base_Config_Central::processar($ok);check($r['ok']&&F3Base_Options::ler('f3base_contato')['email_leads']===[],'vazio_explicito_limpa');
wp_set_current_user(0);check(F3Base_Config_Central::processar($ok)['http']===403,'anonimo_recusado');wp_set_current_user(1);
$_GET=['secao'=>'inicio'];$s=F3Base_Config_UI::html('<textarea name="assinatura">["texto"]</textarea><pre>Informação da edição</pre>');check(str_contains($s,'<textarea')&&str_contains($s,'Informação da edição')&&!str_contains($s,'f3base-editor-catalogo'),'texto_literal_e_diagnostico_preservados');
$s=F3Base_Config_UI::html('<textarea name="mapeamento" id="qa-mapa">{"campos":{}}</textarea>');check(str_contains($s,'f3base-structured')&&str_contains($s,'f3base-editor-catalogo'),'mapa_continua_com_editor');
$_GET=['secao'=>'conexoes','integracao'=>['x']];check(F3Base_Integracoes::aba_atual($_GET['integracao'])==='f3base_pipedrive'&&is_string(F3Base_Config_UI::status()),'parametro_complexo_seguro');
$e=['arquivo'=>[]];check(F3Base_Configuracao_Atual::documentacao($e)['codigo']==='documento_nao_catalogado','tipo_documento_invalido');
$r=F3Base_Configuracao_Atual::documentacao(['arquivo'=>'docs/GUIA-PAINEL.md','limite'=>3]);$s=F3Base_Configuracao_Atual::documentacao(['arquivo'=>'docs/GUIA-PAINEL.md','linha'=>$r['proxima_linha'],'limite'=>3]);check($r['sha256']===$s['sha256']&&$r['sha256']===hash_file('sha256',F3BASE_PLUGIN_DIR.'docs/GUIA-PAINEL.md'),'paginas_e_hash_mesma_fonte');
evidence('painel-1700');
