<?php
/** Fixture exclusiva da bancada local: nenhuma gravação no runtime ou HTTP externo. */
if (!defined('ABSPATH') || wp_get_environment_type() !== 'local' || !getenv('F3_BENCH_LOG')) {
    return;
}
add_filter('pre_http_request', static fn() => new WP_Error('bench_offline', 'Bancada isolada.'));
add_filter('pre_wp_mail', '__return_true');

$id = $_SERVER['HTTP_X_F3_BENCH_ID'] ?? '';
if (PHP_SAPI !== 'cli-server' || !preg_match('/^[0-9]+$/D', $id)) {
    return;
}
$mode = $_SERVER['HTTP_X_F3_BENCH_MODE'] ?? '';
if ($mode === 'off') {
    add_filter('option_active_plugins', static function ($plugins) {
        return array_values(array_diff($plugins, ['base-site-core-fator3/base-site-core-fator3.php']));
    });
}
add_action('shutdown', static function () use ($id) {
    global $wpdb;
    $active = defined('F3BASE_PLUGIN_VERSAO');
    $status = function_exists('opcache_get_status') ? opcache_get_status(false) : [];
    $sample = [
        'id' => $id, 'core' => $active ? F3BASE_PLUGIN_VERSAO : null, 'queries' => $wpdb->num_queries,
        'php_ms' => round((microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']) * 1000, 4),
        'opcache' => !empty($status['opcache_enabled']), 'wp' => get_bloginfo('version'), 'php' => PHP_VERSION,
    ];
    file_put_contents(getenv('F3_BENCH_LOG'), wp_json_encode($sample)."\n", FILE_APPEND);
}, PHP_INT_MAX);
