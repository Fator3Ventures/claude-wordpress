<?php
/** Custo sintético da distribuição dos hooks; não mede uma página ou o tempo de CPU. */
declare(strict_types=1);
if($argc!==3){fwrite(STDERR,"Uso: php sonda-php-1710-dispatch.php <wordpress> <plugin>\n");exit(2);}
define('ABSPATH',rtrim($argv[1],'/').'/');
define('F3BASE_PLUGIN_DIR',rtrim($argv[2],'/').'/');
require ABSPATH.'wp-includes/plugin.php';
require F3BASE_PLUGIN_DIR.'includes/class-f3base-desempenho.php';
F3Base_Desempenho::iniciar();
$externos=array_map(static fn($n)=>'externo_'.$n,range(1,20));
foreach($externos as $hook){add_filter($hook,static fn($v)=>$v);}
add_filter('the_content',static fn($v)=>$v);
$rodada=static function(int $ciclos)use($externos): void {
    for($i=0;$i<$ciclos;$i++){
        foreach($externos as $hook){apply_filters($hook,'x');}
        apply_filters('the_content','x');
    }
};
$rodada(200);
$inicio=hrtime(true);
$rodada(2000);
echo json_encode(['despachos'=>42_000,'ms'=>(hrtime(true)-$inicio)/1e6])."\n";
