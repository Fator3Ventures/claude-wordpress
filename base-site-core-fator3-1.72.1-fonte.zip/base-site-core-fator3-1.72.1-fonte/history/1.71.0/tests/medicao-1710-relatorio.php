<?php
/** Teste WordPress/MySQL. A tabela temporária existe apenas nesta conexão. */
require __DIR__ . '/bootstrap.php';
global $wpdb;
$table = F3Base_Vitais::tabela();
$ddl = $wpdb->get_row($wpdb->prepare('SHOW CREATE TABLE %i', $table), ARRAY_N);
if (!$ddl || $wpdb->query(preg_replace('/^CREATE TABLE /', 'CREATE TEMPORARY TABLE ', $ddl[1], 1)) === false) {
    throw new RuntimeException('Falha ao criar tabela temporária de vitais.');
}
$day = wp_date('Y-m-d');
$path = '/teste-vitais-1710/';
$complete = array('ttfb'=>10, 'atraso_carga'=>30, 'duracao_carga'=>85, 'atraso_renderizacao'=>25);
function sample1710(string $metric, string $id, int $sequence, float $value, array $phases = array(), string $automation = 'nao_identificada', string $traffic = 'nao_marcado'): bool {
    global $day, $path;
    $sample = array('id'=>$id,'dispositivo'=>'movel','sequencia'=>$sequence);
    if ($phases) {
        $sample['atribuicao'] = array('fases'=>$phases);
    }
    return F3Base_Vitais::gravar($day, $path, array('detalhe'=>$metric,'soma'=>$value,'amostra'=>$sample), $traffic, array('automacao'=>$automation));
}
function read1710(string $metric, array $extra = array()): array {
    global $path;
    $result = F3Base_Vitais::consultar($extra + array('metrica'=>$metric, 'caminho'=>$path));
    if (!$result['ok']) { throw new RuntimeException($result['codigo']); }
    return $result['linhas'][0];
}
check(sample1710('LCP','valid001',1,250) && sample1710('LCP','valid001',3,150,$complete)
    && sample1710('LCP','valid001',2,9999,array('ttfb'=>9999)) && sample1710('LCP','valid001',3,150,$complete),
    'aceita_repeticao_e_revisao_fora_de_ordem');
check(sample1710('LCP','valid002',1,5000,array('ttfb'=>4000)) && sample1710('LCP','valid003',1,245)
    && sample1710('LCP','valid004',1,320), 'aceita_amostras_parciais_e_sem_fases');
check(sample1710('LCP','robot001',1,6000,array(),'declarada') && sample1710('LCP','test0001',1,7000,array(),'nao_identificada','teste'),
    'grava_segmentos_distintos');
check(!sample1710('CLS','invalid1',1,0,array('entrada'=>0.1))
    && !sample1710('LCP','invalid2',1,200,array('processamento'=>3))
    && !F3Base_Vitais::atribuicao_valida(array('recurso'=>'https://fixture.test/privado'),'INP')
    && !F3Base_Vitais::atribuicao_valida(array('origem_script'=>'https://fixture.test'),'LCP'), 'atribuição_recusa_campos_e_fases_de_outra_metrica');
$entry = array('gatilho'=>'desempenho','detalhe'=>'INP','contagem'=>1,'soma'=>25,
    'amostra'=>array('id'=>'route001','sequencia'=>1,'dispositivo'=>'movel','atribuicao'=>array('fases'=>array('entrada'=>5))));
check(!isset(F3Base_Modulo_Comportamento::validar_metricas(array($entry))['erro']), 'rota_aceita_fase_compativel');
$entry['amostra']['atribuicao']['fases'] = array('ttfb'=>5);
check(F3Base_Modulo_Comportamento::validar_metricas(array($entry))['erro']['codigo'] === 'f3base_amostra_invalida', 'rota_recusa_fase_de_outra_metrica');
$row = read1710('LCP');
check($row['amostras'] === 4 && $row['p75'] === 320.0 && $row['excluidas_automacao'] === 1, 'p75_quatro_carregamentos_e_posicao_tres');
check($row['amostras_atribuidas'] === 2 && $row['fases_amostras'] === array('ttfb'=>2,'atraso_carga'=>1,'duracao_carga'=>1,'atraso_renderizacao'=>1),
    'denominador_independente_por_fase');
check($row['fases_media_ms']['ttfb'] === 2005.0 && $row['fases_media_ms']['duracao_carga'] === 85.0
    && $row['amostras_fases_completas'] === 1 && $row['fase_dominante'] === 'duracao_carga', 'dominante_compara_mesmos_carregamentos');
$reads = 0;
$observe = static function(string $sql) use (&$reads): string {
    if (stripos($sql, 'SELECT') !== false && stripos($sql, 'atribuicao') !== false) { ++$reads; }
    return $sql;
};
add_filter('query',$observe);
$compact = F3Base_Vitais::consultar(array('metrica'=>'LCP','caminho'=>$path,'dispositivo'=>'movel','somente_resumo'=>true));
check($reads===0 && $compact['ok'] && $compact['somente_resumo']===true, 'somente_resumo_sem_consulta_de_atribuicoes');
$fields = array_flip(array('metrica','amostras','p75','excluidas_automacao','excluidas_legado'));
check($compact['linhas'][0] === array_intersect_key($row,$fields), 'mesmo_p75_e_contagens_sem_expor_atribuicoes');
$filtered = F3Base_Vitais::consultar(array('metrica'=>'LCP','caminho'=>$path,'dispositivo'=>'desktop','somente_resumo'=>true));
check($filtered['linhas']===array() && $reads===0,'somente_resumo_respeita_filtro_de_dispositivo');
ob_start(); F3Base_Vitais::render(28); ob_end_clean();
check($reads===0,'painel_nao_consulta_atribuicoes');
$full = F3Base_Vitais::consultar(array('metrica'=>'LCP','caminho'=>$path));
check($reads>0 && $full['somente_resumo']===false && $full['linhas'][0]['alvos']===array(),'padrao_detalhado_preservado');
remove_filter('query',$observe);
check(read1710('LCP',array('segmento'=>'somente_testes'))['p75'] === 7000.0, 'teste_separado');
check(read1710('LCP',array('automacao'=>'todas'))['amostras'] === 5, 'automacao_todas_preserva_filtro_de_teste');
check(sample1710('INP','inptest1',1,28,array('entrada'=>10,'processamento'=>10,'apresentacao'=>8)), 'aceita_inp_completo');
check(read1710('INP')['fase_dominante'] === null, 'empate_sem_vencedor_arbitrario');
check(sample1710('TTFB','ttfbot01',1,180,array(),'provavel') && sample1710('TTFB','ttfold01',1,190), 'ttfb_automacao_e_legado');
$wpdb->query($wpdb->prepare("UPDATE %i SET automacao='legado_desconhecido' WHERE metrica='TTFB' AND automacao='nao_identificada'", $table));
$empty = read1710('TTFB');
check($empty['p75'] === null && $empty['amostras'] === 0 && $empty['excluidas_automacao'] === 1 && $empty['excluidas_legado'] === 1, 'excluidas_sem_p75');
check(sample1710('CLS','cls-zero1',1,0) && read1710('CLS')['p75'] === 0.0, 'zero_real_preservado');
ob_start();
F3Base_Vitais::render(28);
$html = ob_get_clean();
check(str_contains($html, '<td>TTFB</td><td>Sem amostras elegíveis</td><td>0</td><td>1</td><td>1</td>'), 'painel_sem_zero_falso');
check(str_contains($html, '<td>CLS</td><td>' . number_format_i18n(0,3) . '</td><td>1</td>'), 'painel_zero_cls_formatado');
$wpdb->suppress_errors(true);
$fail = static function(string $sql) use ($table): string {
    return str_contains($sql, 'SELECT valor FROM '.$table) ? 'SELECT unknown_field_1710 FROM '.$table : $sql;
};
add_filter('query',$fail);
$failed = F3Base_Vitais::consultar(array('metrica'=>'LCP','caminho'=>$path));
ob_start();
F3Base_Vitais::render(28);
$unavailable = ob_get_clean();
remove_filter('query',$fail);
$wpdb->suppress_errors(false);
check(!$failed['ok'] && $failed['codigo'] === 'consulta_indisponivel', 'erro_percentil_nao_produz_zero');
check(str_contains($unavailable, 'Não foi possível consultar') && !str_contains($unavailable, 'Sem amostras neste filtro'), 'painel_erro_diferente_de_amostra_vazia');
$batchPath = '/teste-paginacao-vitais-1710/';
$rows = array();
for ($i=1; $i<=501; ++$i) {
    $attr = wp_json_encode(array('fases'=>array('entrada'=>$i)));
    $rows[] = $wpdb->prepare('(%s,%s,%s,%s,%s,1,%d,%s,%s)', hash('sha256',"batch-$i"), $day, $batchPath, 'INP', 'movel', $i, 'nao_identificada', $attr);
}
$write = $wpdb->query("INSERT INTO {$table} (amostra,dia,caminho,metrica,dispositivo,sequencia,valor,automacao,atribuicao) VALUES ".implode(',', $rows));
check($write===501,'lote_de_duas_paginas');
$bulk = F3Base_Vitais::consultar(array('metrica'=>'INP','caminho'=>$batchPath))['linhas'][0];
check($bulk['amostras']===501 && $bulk['p75']===376.0 && $bulk['fases_amostras']['entrada']===501
    && $bulk['fases_media_ms']['entrada']===251.0 && $bulk['fase_dominante']===null, 'cursor_500_soma_cada_linha_uma_vez');
$wpdb->query($wpdb->prepare('DROP TEMPORARY TABLE %i',$table));
evidence('medicao-1710-relatorio');
