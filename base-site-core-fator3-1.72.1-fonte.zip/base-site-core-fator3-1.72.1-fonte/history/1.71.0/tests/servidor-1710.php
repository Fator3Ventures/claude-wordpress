<?php
/** Harness do registro de hooks com WP_Hook real. Cada invocação representa uma requisição. */
declare(strict_types=1);

[$script, $perfil, $estrategia] = $argv;
$site = getenv('F3BASE_SITE') ?: __DIR__ . '/../lab/wordpress/wp-load.php';
define('ABSPATH', dirname($site) . '/');
require ABSPATH . 'wp-includes/plugin.php';

$plugin = getenv('F3BASE_BOOTSTRAP_PLUGIN') ?: __DIR__ . '/../work/plugin/base-site-core-fator3';
define('F3BASE_PLUGIN_DIR', realpath($plugin) . '/');
$mapa = require F3BASE_PLUGIN_DIR . 'includes/autoload-map.php';
spl_autoload_register(static function (string $nome) use ($mapa): void {
    if (isset($mapa[$nome])) {
        require_once F3BASE_PLUGIN_DIR . $mapa[$nome];
    }
});
if ($estrategia === 'nativo') {
    define('F3BASE_BUILD_BOOTSTRAP', true);
}

if ($perfil === 'sonda') {
    $_GET['f3base_nav_sonda'] = 'sonda';
}
$memoria = memory_get_usage();
$inicio = hrtime(true);
F3Base_Bootstrap::iniciar(F3Base_Email_Wordpress::class);
F3Base_Perfil_Publico::iniciar($perfil === 'login', $perfil === 'contexto');
if ($perfil === 'promocao') {
    F3Base_Perfil_Publico::completo();
    F3Base_Bootstrap::iniciar(F3Base_Admin_Saude::class);
    F3Base_Bootstrap::iniciar(F3Base_Admin_Saude::class);
}
// Uma segunda iniciação não deve registrar callbacks repetidos na promoção.
F3Base_Bootstrap::iniciar(F3Base_Sessao_Admin::class);
$duracao = (hrtime(true) - $inicio) / 1e6;
$alocados = memory_get_usage() - $memoria;

$inventario = [];
foreach ($GLOBALS['wp_filter'] as $nome => $hook) {
    foreach ($hook->callbacks as $prioridade => $callbacks) {
        foreach ($callbacks as $entry) {
            $fn = $entry['function'];
            $identidade = $fn instanceof Closure ? '(closure)' : $fn;
            $inventario[$nome][] = [$prioridade, $entry['accepted_args'], $identidade];
        }
    }
}
ksort($inventario);
$registros = [];
foreach (get_included_files() as $arquivo) {
    if (str_starts_with(basename($arquivo), 'bootstrap-hooks')) {
        $registros[basename($arquivo)] = filesize($arquivo);
    }
}
echo json_encode([
    'inventario' => $inventario,
    'registros'  => $registros,
    'registro_ms' => $duracao,
    'alocados_bytes' => $alocados,
    'opcache_ativo' => function_exists('opcache_get_status') && (bool)opcache_get_status(false),
    'perfil_publico_ativo' => F3Base_Perfil_Publico::ativo(),
], JSON_THROW_ON_ERROR), "\n";
