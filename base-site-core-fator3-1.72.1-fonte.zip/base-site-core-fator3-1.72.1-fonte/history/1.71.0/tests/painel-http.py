"""Fluxos HTTP reais, autenticação WordPress e POST normal. Exporta apenas o HTML sintético para QA local."""
from pathlib import Path
import subprocess, os, socket, time, json, html, http.cookiejar, urllib.request, urllib.parse, urllib.error
from lxml import html as dom
r=Path(__file__).resolve().parents[1];lab=Path(os.environ['F3BASE_LAB_DIR']);base='http://127.0.0.1:8136';version=os.environ.get('F3_UI_VERSION','1.70.0');old=version=='1.69.0';root=base+'/wp-admin/admin.php?page=base-site-core-fator3';results={}
def check(name,condition):
 results[name]=bool(condition)
 if not condition:raise AssertionError(name)
def client():return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def get(op,url,form=None):
 try:
  with op.open(url,urllib.parse.urlencode(form,doseq=True).encode() if form is not None else None,timeout=45) as response:return response.status,response.read().decode()
 except urllib.error.HTTPError as exc:return exc.code,exc.read().decode()
def login(user,pw):
 op=client();get(op,base+'/wp-login.php');s,body=get(op,base+'/wp-login.php',{'log':user,'pwd':pw,'testcookie':'1','wp-submit':'Log In','redirect_to':base+'/wp-admin/profile.php'});check('login_'+user,s==200 and 'wpadminbar' in body);return op
def filled(form):
 values={}
 for el in form.xpath('.//input[@name]|.//textarea[@name]|.//select[@name]'):
  if el.get('type')=='submit' or (el.get('type')=='checkbox' and el.get('checked') is None):continue
  if el.get('disabled') is not None: continue
  if el.tag=='select':
   opted=el.xpath('.//option[@selected]') or el.xpath('.//option[1]');value=opted[0].get('value',opted[0].text or '') if opted else ''
  elif el.tag=='textarea':value=el.text or ''
  else:value=el.get('value','')
  values[el.get('name')]=value
 return values
def export(body,area):
 tree=dom.fromstring(body);parts=tree.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," f3base-tela ")]');assert parts,area
 part=parts[0]
 for el in part.xpath('.//input[@type="hidden"]'):
  if el.get('name','').startswith(('_wp','f3base_contexto','f3base_fim','revisao','f3base_revisao','f3base_renovar_nonce','previa','confirmacao','chave_operacao')):el.set('value','')
 for el in part.xpath('.//*[@data-nonce]'):el.set('data-nonce','')
 for el in part.xpath('.//form'):el.set('onsubmit','return false')
 bundle=lab/'wordpress/wp-content/plugins/base-site-core-fator3'; css='\n'.join((bundle/'admin/assets'/n).read_text() for n in ['f3base-admin.css','f3base-interface.css','f3base-config143.css']);js='\n'.join((bundle/'admin/assets'/n).read_text() for n in ['f3base-config143.js','f3base-admin1120.js','f3base-config-ui.js'])
 css=(lab/'wordpress/wp-admin/css/common.min.css').read_text()+'\n'+(lab/'wordpress/wp-admin/css/forms.min.css').read_text()+'\n'+css
 out=lab/'ui'/version;out.mkdir(parents=True,exist_ok=True)
 (out/(area+'.html')).write_text('<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>QA local · '+area+'</title><style>'+css+'</style><body class="wp-admin wp-core-ui" style="margin:0;padding:16px">'+dom.tostring(part,encoding='unicode')+'<script>'+js+'</script></body></html>')
with open(lab/'ui-server.log','a') as log:
 server=subprocess.Popen([str(r/'build/php'),'-S','127.0.0.1:8136','-t',str(lab/'wordpress')],stdout=log,stderr=log)
 try:
  for _ in range(80):
   try:
    with socket.create_connection(('127.0.0.1',8136),.15):break
   except OSError:time.sleep(.1)
  admin=login('admin','synthetic-only-1360'); addresses=root+'&secao=conexoes&integracao=avisos';screens={'inicio':root,'conteudo':root+'&secao=conteudo','privacidade':root+'&secao=privacidade','linkedin':root+'&secao=conexoes&integracao=f3base_anuncios_linkedin','qualidade':root+'&secao=conexoes&integracao=qualidade','avisos':addresses}
  for area,url in screens.items():
   status,body=get(admin,url);check('tela_'+area,status==200 and 'wpadminbar' in body);export(body,area)
  status,body=get(admin,addresses);tree=dom.fromstring(body);form=tree.xpath('//form[input[@name="action" and @value="f3base_config_central"]]')[0];fields=filled(form);field='valores[f3base_contato][email_leads]';fields[field]='equipe-qa@example.test';endpoint=form.get('action');s,body=get(admin,endpoint,fields);check('post_valido_releitura',s==200 and 'equipe-qa@example.test' in body)
  form=dom.fromstring(body).xpath('//form[input[@name="action" and @value="f3base_config_central"]]')[0];fields=filled(form);assert field in fields;del fields[field];s,_=get(admin,endpoint,fields);s2,body=get(admin,addresses);found='equipe-qa@example.test' in (dom.fromstring(body).xpath('//textarea[@name=$name]',name=field)[0].text or '')
  check('faltante_'+('apaga_na_base' if old else 'recusado_e_preservado'),(s==200 and not found) if old else (s==400 and found))
  if not old:
   s,_=get(admin,endpoint,dict(fields,**{'_wpnonce':'invalido',field:'fora@example.test'}));check('nonce_negado',s==403)
   s,_=get(admin,endpoint,dict(fields,**{field:'fora@example.test','revisoes[f3base_contato]':'alterada'}));check('revisao_antiga_negada',s==409)
   s,body=get(admin,root+'&secao=conexoes&integracao%5B%5D=qualquer');check('parametro_invalido_navegavel',s==200 and 'wpadminbar' in body)
   s,body=get(admin,root+'&secao=inicio&guia=configuracoes');check('guia_no_painel',s==200 and 'Como configurar o Site Core' in body)
   for name in ['f3base_email_site','f3base_email_novo_lead','f3base_anuncios_meta','f3base_anuncios_google','f3base_pipedrive']:
    s,body=get(admin,root+'&secao=conexoes&integracao='+name);check('abre_'+name,s==200)
    tree=dom.fromstring(body);form=tree.xpath('//form[input[@name="action" and @value="f3base_integracoes_salvar"]]')[0];e=filled(form);original=dict(e);s,body=get(admin,form.get('action'),e);check('post_completo_'+name,s==200 and 'wpadminbar' in body and 'Os valores já estavam salvos' in body)
    del e['integracao_completa'];s,_=get(admin,form.get('action'),e);check('post_cortado_'+name,s==400)
    if name=='f3base_email_site':
     e=dict(original);del e['config[ativo]'];s,_=get(admin,form.get('action'),e);check('checkbox_ausente_recusado',s==400)
     e=dict(original);e['config[nome_exibicao]']='Equipe de teste';s,body=get(admin,form.get('action'),e);check('email_alteracao_real',s==200 and 'Equipe de teste' in body and 'Alterações salvas e conferidas' in body)
    if name=='f3base_pipedrive':
     e=dict(original);e['config[homologacao]']='1';s,_=get(admin,form.get('action'),e);check('campo_de_homologacao_fora_do_formulario',s==400)
   subscriber=login('leitorqa','somente-bancada-ui');s,_=get(subscriber,root);check('assinante_painel_recusado',s==403);s,_=get(subscriber,endpoint,fields);check('assinante_gravacao_recusada',s==403)
 finally:server.terminate();server.wait(timeout=6)
(r/'evidence/1700'/('http-'+version+'.json')).write_text(json.dumps({'versao':version,'checks':results},indent=2));print(version,len(results),'verificações HTTP')
