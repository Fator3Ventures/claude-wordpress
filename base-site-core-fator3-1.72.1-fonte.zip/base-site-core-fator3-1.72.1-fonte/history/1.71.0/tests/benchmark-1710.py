"""Benchmark isolado. Ex.: python tests/benchmark-1710.py instalador.zip 1.71.0
Requer F3_BENCH_WP (WordPress limpo com wp-config.php do lab), F3_BENCH_CLI (wp-cli.phar)
e F3BASE_RUNTIME (árvore Linux PHP 8.3 / MySQL). Portas dedicadas 33771 e 8171.
A evidência inclui somente agregados, configurações sintéticas e caminhos públicos de ativos.
"""
import argparse
import base64
import hashlib
import hmac
import http.client
import json
import math
import os
import pwd
import re
import shutil
import socket
import statistics
import subprocess
import tempfile
import time
import zipfile
from contextlib import ExitStack
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
HTTP = 8171
DB = 33771
HOST = '127.0.0.1'
URL = f'http://{HOST}:{HTTP}'
SLUG = 'base-site-core-fator3'
ROUTES = {'home': '/', 'artigo': '/?p=1', 'login': '/wp-login.php'}


def start_process(stack, cmd, env, lab, name, port):
    # Refuse occupied ports even if another server would answer the readiness check.
    with socket.socket() as check:
        check.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        check.bind((HOST, port))
    log = stack.enter_context((lab / f'{name}.log').open('w+'))
    proc = subprocess.Popen(cmd, env=env, stdout=log, stderr=log)

    def stop():
        proc.terminate()
        try:
            proc.wait(timeout=30)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
    stack.callback(stop)
    for _ in range(200):
        if proc.poll() is not None:
            log.seek(0)
            raise RuntimeError(log.read()[-1500:])
        try:
            with socket.create_connection((HOST, port), .2):
                return
        except OSError:
            time.sleep(.05)
    raise TimeoutError(f'{name} startup')


def run(cmd, env):
    result = subprocess.run(cmd, env=env, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr[-1500:] + result.stdout[-500:])
    return result.stdout.strip()


def request(path, extra=None):
    headers = {'Host': f'{HOST}:{HTTP}', 'Connection': 'close', 'Accept-Encoding': 'identity'}
    headers.update(extra or {})
    message = f'GET {path} HTTP/1.1\r\n' + ''.join(f'{k}: {v}\r\n' for k, v in headers.items()) + '\r\n'
    start = time.perf_counter_ns()
    with socket.create_connection((HOST, HTTP), 15) as conn:
        conn.sendall(message.encode('ascii'))
        # Timestamp actual first HTTP response octet (before parsing headers or reading body).
        if not conn.recv(1, socket.MSG_PEEK):
            raise EOFError(path)
        first = (time.perf_counter_ns() - start) / 1e6
        response = http.client.HTTPResponse(conn)
        response.begin()
        if response.status != 200:
            raise RuntimeError(f'{path}: HTTP {response.status} {response.getheader("Location")}')
        body = response.read()
    return first, body


class Assets(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.paths = set()

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == 'script' and a.get('src'):
            self.paths.add(a['src'])
        if tag == 'link' and 'stylesheet' in (a.get('rel') or '').lower().split() and a.get('href'):
            self.paths.add(a['href'])


def inventory(body):
    parser = Assets()
    parser.feed(body.decode())
    result = []
    for url in sorted(parser.paths):
        parsed = urlsplit(url)
        if parsed.netloc and parsed.netloc != f'{HOST}:{HTTP}':
            result.append({'path': parsed.path, 'origin': 'external', 'bytes': None})
            continue
        target = parsed.path + ('?' + parsed.query if parsed.query else '')
        _, data = request(target)
        owned = '/f3base-publico/' in parsed.path or ('/plugins/' + SLUG + '/') in parsed.path
        result.append({'path': parsed.path, 'bytes': len(data), 'origin': 'core' if owned else 'wordpress/theme'})
    return {'css_js_declarados': result,
            'bytes_core': sum(a['bytes'] for a in result if a['origin'] == 'core'),
            'bytes_wp_tema': sum(a['bytes'] for a in result if a['origin'] == 'wordpress/theme')}


def summary(values):
    seq = sorted(values)
    return {'p50': round(statistics.median(seq), 3), 'p95': round(seq[math.ceil(.95 * len(seq)) - 1], 3),
            'min': round(seq[0], 3), 'max': round(seq[-1], 3)}


def median_interval(values):
    """Conservative two-sided sign interval; ties can increase coverage."""
    seq = sorted(values)
    n = len(seq)
    tail = 0
    for k in range(1, n // 2 + 1):
        tail += math.comb(n, k - 1) / 2**n
        if 1 - 2 * tail < .95:
            break
        bounds = [round(seq[k - 1], 3), round(seq[n - k], 3)]
    return bounds if n >= 6 else None


def signed_header(path, salt):
    prefix = f'{int(time.time())}.{os.urandom(16).hex()}'
    msg = (prefix + '|' + urlsplit(path).path).encode()
    return prefix + '.' + hmac.new(salt.encode(), msg, hashlib.sha256).hexdigest()


def measure(cli, env, args, lab):
    salt = run(cli + ['eval', "echo wp_salt('auth');"], env)
    trace = lab / 'requests.jsonl'
    trace.touch()
    profiles = {}
    serial = 0
    with trace.open() as reader:
        for route, path in ROUTES.items():
            cases = {'on': [], 'off': []}
            inventories = {}
            probes = []
            for pair in range(-4, args.pairs + 5):
                # Alternate which member of a pair runs first, on the same routes/database.
                for mode in (['on', 'off'] if pair % 2 else ['off', 'on']):
                    if pair >= args.pairs and mode == 'off':
                        continue
                    serial += 1
                    headers = {'X-F3-Bench-Id': str(serial), 'X-F3-Bench-Mode': mode}
                    if pair >= args.pairs:
                        headers['X-F3base-Desempenho'] = signed_header(path, salt)
                    ttfb, body = request(path, headers)
                    marker = b'id="loginform"' if route == 'login' else b'f3-benchmark-artigo'
                    if marker not in body or (route != 'login' and (b'f3-benchmark-segundo' in body) != (route == 'home')):
                        raise RuntimeError(f'Conteúdo inesperado {route} {mode}')
                    line = reader.readline()
                    if not line:  # php can finish sending body just before shutdown log is visible
                        for _ in range(100):
                            time.sleep(.001)
                            line = reader.readline()
                            if line:
                                break
                    meta = json.loads(line)
                    if meta['id'] != str(serial) or meta['core'] != (args.version if mode == 'on' else None) or not meta['opcache']:
                        raise AssertionError((serial, mode, meta))
                    if pair < 0:
                        continue
                    if pair >= args.pairs:
                        found = re.search(rb'<!--f3base-desempenho:([A-Za-z0-9+/=]+)-->', body)
                        if not found:
                            raise AssertionError('Relatório assinado ausente')
                        perf = json.loads(base64.b64decode(found[1]))
                        if not perf.get('ok') or perf.get('versao') != args.version or not perf.get('modulos'):
                            raise AssertionError('Relatório de perfil inválido')
                        probes.append((perf['total_proprio_ms'], perf['consultas_total']))
                        continue
                    cases[mode].append({'ttfb_ms': ttfb, 'wp_ate_shutdown_ms': meta['php_ms'],
                                        'consultas_wp': meta['queries'], 'html_bytes': len(body)})
                    if pair == args.pairs - 1:
                        inventories[mode] = inventory(body)
            aggregated = {m: {k: summary([s[k] for s in cases[m]]) for k in cases[m][0]} for m in ('off', 'on')}
            paired = {}
            for k in cases['on'][0]:
                differences = [a[k] - b[k] for a, b in zip(cases['on'], cases['off'])]
                paired[k] = summary(differences)
                paired[k]['faixa_mediana_95'] = median_interval(differences)
            aggregated['delta_pareado_on_menos_off'] = paired
            profiles[route] = {'normal': aggregated, 'ativos': inventories,
                               'sondas_assinadas': {'n': len(probes), 'proprio_ms': summary([p[0] for p in probes]),
                                                   'consultas_no_escopo': summary([p[1] for p in probes])}}
    return profiles, meta['wp'], meta['php']


def benchmark(args):
    runtime = Path(os.environ['F3BASE_RUNTIME']).resolve()
    wp_source = Path(os.environ['F3_BENCH_WP']).resolve()
    php = runtime / 'usr/bin/php8.3'
    seed = Path(os.environ['F3_BENCH_CLI']).resolve()
    with tempfile.TemporaryDirectory(prefix='f3-benchmark1710-') as directory, ExitStack() as stack:
        lab = Path(directory)
        site = lab / 'wordpress'
        shutil.copytree(wp_source, site, ignore=shutil.ignore_patterns('wp-content', '.maintenance'), symlinks=False)
        content = site / 'wp-content'
        for dirname in ['themes', 'mu-plugins', 'plugins']:
            (content / dirname).mkdir(parents=True)
        shutil.copytree(wp_source / 'wp-content/themes/f3-fixture', content / 'themes/f3-fixture')
        shutil.copyfile(HERE / 'benchmark-1710-observer.php', content / 'mu-plugins/benchmark.php')
        with zipfile.ZipFile(args.zip) as plugin:
            for f in plugin.namelist():
                if not f.startswith(SLUG + '/') or '..' in Path(f).parts:
                    raise ValueError('Instalador fora da raiz prevista.')
            plugin.extractall(content / 'plugins')
        env = dict(os.environ, LD_LIBRARY_PATH=str(runtime / 'usr/lib/x86_64-linux-gnu'),
                   PHP_INI_SCAN_DIR='', F3_BENCH_LOG=str(lab / 'requests.jsonl'),
                   F3BASE_LAB_DB='f3_bench1710', F3BASE_DB_HOST=f'{HOST}:{DB}', F3BASE_CRON='0',
                   F3BASE_DB_USER='root', F3BASE_DB_PASSWORD='', F3BASE_LAB_CONTENT=str(content))
        modules = ['mysqlnd', 'mysqli', 'pdo', 'pdo_mysql', 'mbstring', 'curl', 'zip', 'dom', 'xml',
                   'simplexml', 'xmlreader', 'xmlwriter', 'fileinfo', 'ctype', 'tokenizer', 'iconv', 'gd', 'phar']
        ini = lab / 'php.ini'
        ini.write_text('date.timezone=UTC\nmemory_limit=512M\nlog_errors=1\ndisplay_errors=0\n' +
                       f'error_log={lab}/php-errors.log\nextension_dir={runtime}/usr/lib/php/20230831\n' +
                       ''.join(f'extension={m}\n' for m in modules) +
                       'zend_extension=opcache\nopcache.enable_cli=1\nopcache.validate_timestamps=0\nopcache.file_update_protection=0\n')
        phpcmd = [str(php), '-c', str(ini)]
        cli = phpcmd + [str(seed), f'--path={site}', '--allow-root']
        data = lab / 'mysql'
        data.mkdir()
        mysqld = [str(runtime / 'usr/sbin/mysqld'), '--no-defaults', '--user=' + pwd.getpwuid(os.geteuid()).pw_name,
                  '--basedir=' + str(runtime / 'usr'), '--datadir=' + str(data), '--innodb-file-per-table=OFF']
        run(mysqld + ['--initialize-insecure'], env)
        start_process(stack, mysqld + [f'--port={DB}', f'--bind-address={HOST}', '--socket=', '--mysqlx=0',
                                      '--innodb-fast-shutdown=0', f'--pid-file={lab}/mysqld.pid',
                                      f'--secure-file-priv={lab}'], env, lab, 'mysql', DB)
        run(phpcmd + ['-r', f"(new mysqli('127.0.0.1','root','',null,{DB}))->query('CREATE DATABASE f3_bench1710');"], env)
        run(cli + ['core', 'install', f'--url={URL}', '--title=Benchmark Fator3', '--admin_user=benchmark',
                   '--admin_password=' + os.urandom(24).hex(), '--admin_email=fixture@example.invalid', '--skip-email'], env)
        run(cli + ['theme', 'activate', 'f3-fixture'], env)
        run(cli + ['post', 'update', '1', '--post_content=f3-benchmark-artigo'], env)
        run(cli + ['post', 'create', '--post_title=Segundo', '--post_status=publish',
                   '--post_type=post', '--post_content=f3-benchmark-segundo'], env)
        run(cli + ['plugin', 'activate', SLUG], env)
        start_process(stack, phpcmd + ['-S', f'{HOST}:{HTTP}', '-t', str(site)], env, lab, 'http', HTTP)
        routes, wp_version, php_version = measure(cli, env, args, lab)
        mysql_version = run(phpcmd + ['-r', f"echo (new mysqli('127.0.0.1','root','',null,{DB}))->server_info;"], env)
    return {
        'versao': args.version, 'instalador_sha256': hashlib.sha256(args.zip.read_bytes()).hexdigest(),
        'inicio_utc': args.start, 'fim_utc': datetime.now(timezone.utc).isoformat(),
        'ambiente': {'wp': wp_version, 'php': php_version, 'mysql': mysql_version,
                     'servidor': 'PHP CLI-server, HTTP/1.1 loopback, sem TLS, conexão nova',
                     'cache': 'OPcache ativo aquecido, cache de página/CDN e cache persistente de objetos ausentes',
                     'conteudo': 'WordPress novo, tema f3-fixture, dois posts públicos, apenas Core nas opções padrão',
                     'cron': 'desativado', 'fornecedores': 'rede externa e email bloqueados na fixture'},
        'metodo': {'pares_por_rota': args.pairs, 'aquecimentos_por_modo_rota': 4, 'ordem': 'on/off e off/on alternadas',
                   'ttfb_ms': 'relógio monotônico desde antes da conexão TCP até o primeiro octeto HTTP local',
                   'wp_ate_shutdown_ms': 'REQUEST_TIME_FLOAT até observador no final de shutdown do WordPress',
                   'consultas_wp': 'wpdb->num_queries no mesmo ponto, sem SAVEQUERIES',
                   'delta_pareado': 'resposta com Core menos resposta sem Core no mesmo par. p50 é mediana; p95 nearest-rank',
                   'faixa_mediana_95': 'Intervalo bilateral pelo teste de sinais, cobertura nominal >=95% se os pares forem independentes. Há autocorrelação possível; descreve incerteza nesta bancada, não em produção.',
                   'sondas': 'cinco requisições extras com assinatura, tempo próprio e consultas dos trechos monitorados, não entram no TTFB normal',
                   'ativos': 'scripts src e folhas de estilo link do último HTML; GET local separado e sem compressão. Bytes de HTML incluem inline; não executar JavaScript nem somar ao TTFB.',
                   'alcance': 'Sem navegação visual, cache HIT de página, métricas RUM ou atribuição causal em produção. Carga do host compartilhada; comparar deltas pareados.'},
        'rotas': routes,
    }


def compare(base, candidate):
    rows = {}
    for route in ROUTES:
        pair = [version['rotas'][route] for version in (base, candidate)]
        metrics = {}
        for metric in ('ttfb_ms', 'wp_ate_shutdown_ms', 'consultas_wp', 'html_bytes'):
            series = [r['normal']['delta_pareado_on_menos_off'][metric] for r in pair]
            values = [s['p50'] for s in series]
            metrics[metric] = {'base': values[0], 'candidato': values[1],
                               'diferenca': round(values[1] - values[0], 3),
                               'base_p95': series[0]['p95'], 'candidato_p95': series[1]['p95'],
                               'faixa_mediana_95_base': series[0].get('faixa_mediana_95'),
                               'faixa_mediana_95_candidato': series[1].get('faixa_mediana_95')}
        for metric, fn in [('bytes_js_css_core', lambda r: r['ativos']['on']['bytes_core']),
                           ('proprio_ms_sonda', lambda r: r['sondas_assinadas']['proprio_ms']['p50'])]:
            values = [fn(r) for r in pair]
            metrics[metric] = {'base': values[0], 'candidato': values[1],
                               'diferenca': round(values[1] - values[0], 3)}
        rows[route] = metrics
    return {
        'base_sha256': base['instalador_sha256'], 'candidato_sha256': candidate['instalador_sha256'],
        'comparacao': 'TTFB, geração, SQL e HTML comparam medianas do acréscimo pareado Core ligado menos desligado por versão. Sonda e ativos são valores com Core ativo.',
        'limites': 'Execuções separadas no mesmo tipo de laboratório em horários diferentes. Carga do host pode variar. Cada rota tem contagem e distribuição no JSON da sua versão. Tamanho declarado não mede execução de JS.',
        'rotas': rows,
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('zip', type=Path)
    parser.add_argument('version', choices=['1.70.0', '1.71.0'])
    parser.add_argument('--pairs', type=int, default=24)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.pairs < 5:
        parser.error('mínimo de cinco pares')
    args.start = datetime.now(timezone.utc).isoformat()
    result = benchmark(args)
    output = args.output or ROOT / 'evidence/1710' / f'benchmark-core-{args.version}.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(output)
    base = output.parent / 'benchmark-core-1.70.0.json'
    if args.version == '1.71.0' and base.exists():
        comparison = compare(json.loads(base.read_text()), result)
        target = output.parent / 'benchmark-comparativo-1710.json'
        target.write_text(json.dumps(comparison, ensure_ascii=False, indent=2) + '\n')
        print(target)
