/* npm ci --prefix tests/dom; NODE_PATH=tests/dom/node_modules node tests/frontend-1710-dom.cjs
   Comparação opcional: F3BASE_BASELINE_PLUGIN=<pasta instalada da 1.70.0>.
   F3BASE_VARIANTE=min usa JS minificado; perfil usa o composto público de fornecedores desligados. F3BASE_FIXTURE_HTML gera ensaio autônomo para navegador (servir via HTTP no localhost, em perfil descartável). */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const {JSDOM, VirtualConsole} = require('jsdom');
const cena = fs.readFileSync(path.join(__dirname, 'frontend-1710-scene.js'), 'utf8');
const testar = vm.runInThisContext(cena + '\nexercitarFrontend');
const raiz = path.resolve(__dirname, '..');
const candidato = fs.existsSync(path.join(raiz, 'work/plugin')) ? 'work/plugin' : 'plugin';
const plugins = {'1.71.0': process.env.F3BASE_CANDIDATE_PLUGIN || path.join(raiz, candidato, 'base-site-core-fator3')};
if (process.env.F3BASE_BASELINE_PLUGIN) { plugins['1.70.0'] = path.resolve(process.env.F3BASE_BASELINE_PLUGIN); }
const variantes = {};
const composto = process.env.F3BASE_VARIANTE === 'perfil';
const sufixo = composto || process.env.F3BASE_VARIANTE === 'min' ? '.min.js' : '.js';
for (const [versao, plugin] of Object.entries(plugins)) {
    const asset = arquivo => fs.readFileSync(path.join(plugin, 'assets', arquivo), 'utf8');
    variantes[versao] = {
        composto,
        consentimento: asset(composto ? 'perfis/publico-0.min.js' : 'f3base-consentimento' + sufixo),
        formularios: asset('f3base-formularios' + sufixo)
    };
}
const perfis = ['padrao','negado','granular','sem_observador','api'];
async function executarDOM() {
    const resultados = {};
    for (const [versao, fontes] of Object.entries(variantes)) {
        resultados[versao] = {};
        for (const perfil of perfis) {
            const erros = [];
            const consoleDOM = new VirtualConsole();
            consoleDOM.on('jsdomError', erro => erros.push(erro.message));
            const dom = new JSDOM('<!doctype html><html><body></body></html>', {
                url: 'https://fixture.invalid/', runScripts: 'outside-only', pretendToBeVisual: true,
                virtualConsole: consoleDOM
            });
            try {
                // JSDOM envia DOMContentLoaded no próximo ciclo, como no primeiro defer.
                resultados[versao][perfil] = await testar(dom.window, fontes, perfil, versao === '1.71.0');
                if (erros.length) { throw new Error(erros.join('\n')); }
            } catch (erro) { throw new Error(versao + ' / ' + perfil + ': ' + erro.message); }
            finally { dom.window.close(); }
        }
    }
    console.log(JSON.stringify({ambiente: 'JSDOM ' + require('jsdom/package.json').version + ', Node ' + process.version, variante: composto ? 'perfis/publico-0.min.js + formulario minificado' : sufixo, resultados}, null, 2));
}
if (process.env.F3BASE_FIXTURE_HTML) {
    const run = `const variantes = ${JSON.stringify(variantes)}; const perfis = ${JSON.stringify(perfis)};
    (async () => {
        const resultados = {};
        for (const [versao, fontes] of Object.entries(variantes)) {
            resultados[versao] = {};
            for (const perfil of perfis) {
                const frame = document.createElement('iframe');
                document.body.appendChild(frame);
                try { resultados[versao][perfil] = await exercitarFrontend(frame.contentWindow, fontes, perfil, versao === '1.71.0'); }
                catch (erro) { throw new Error(versao + ' / ' + perfil + ': ' + erro.message); }
                finally { frame.remove(); }
            }
        }
        document.getElementById('saida').textContent = JSON.stringify({ambiente:navigator.userAgent, resultados}, null, 2);
        document.title = 'PASSOU';
    })().catch(erro => { document.title='FALHOU'; document.getElementById('saida').textContent=erro.stack; });`;
    const script = (cena + '\n' + run).replace(/<\/script/gi, '<\\/script');
    fs.writeFileSync(process.env.F3BASE_FIXTURE_HTML, '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Em execução</title><pre id="saida">Em execução</pre><script>' + script + '</script></html>');
} else {
    executarDOM().catch(erro => { console.error(erro.message); process.exitCode = 1; });
}
