/* Ensaio isolado. Recebe uma janela nova, as fontes exatas e o perfil a testar. */
async function exercitarFrontend(win, fontes, perfil, candidato) {
    const doc = win.document;
    let verificacoes = 0;
    const verificar = (ok, nome) => { if (!ok) { throw new Error(nome); } verificacoes++; };
    const esperar = () => new Promise(resolve => win.setTimeout(resolve, 0));
    const resultados = {};
    const contagens = { leiturasCookie: 0, parsesSentinela: 0, contextosCanvas: 0, leiturasEstilo: 0, buscasGlobaisForms: 0 };
    const rodape = perfil !== 'api';
    const granular = perfil === 'granular';
    const nomeCookie = 'f3base_fixture_' + (candidato ? '1710_' : '1700_') + perfil;
    doc.cookie = nomeCookie + '=; Max-Age=0; Path=/';
    const seletor = '[data-f3base-formulario]';
    const htmlForm = '<input name="submissao"><input name="token"><section data-etapa="1"><input></section><section data-etapa="2"><input></section>';
    doc.body.innerHTML = '<main></main>' + (rodape ? '<footer class="f3base-consentimento-rodape"><button data-f3base-consentimento aria-controls="f3base-consentimento-banner">Preferências</button></footer>' : '');
    const rodapeEl = doc.querySelector('footer');
    const controle = doc.querySelector('button');
    const cookies = Object.getOwnPropertyDescriptor(win.Document.prototype, 'cookie');
    Object.defineProperty(doc, 'cookie', {
        configurable: true,
        get() { contagens.leiturasCookie++; return cookies.get.call(this); },
        set(v) { cookies.set.call(this, v); }
    });
    const parse = win.JSON.parse.bind(win.JSON);
    win.JSON.parse = (texto, ...args) => {
        if (texto === '' || texto === 'granted' || texto === 'denied') { contagens.parsesSentinela++; }
        return parse(texto, ...args);
    };
    const estilos = win.getComputedStyle.bind(win);
    win.getComputedStyle = (...args) => { contagens.leiturasEstilo++; return estilos(...args); };
    const buscar = doc.querySelectorAll.bind(doc);
    doc.querySelectorAll = sel => {
        if (sel === seletor) { contagens.buscasGlobaisForms++; }
        return buscar(sel);
    };
    const renderizarCanvas = win.HTMLCanvasElement.prototype.getContext;
    win.HTMLCanvasElement.prototype.getContext = function (...args) {
        contagens.contextosCanvas++;
        return win.navigator.userAgent.includes('jsdom') ? null : renderizarCanvas.apply(this, args);
    };
    // O ensaio controla o instante de aproximação do rodapé. A API real de
    // IntersectionObserver e frames do navegador ficam fora desse contador.
    let observador;
    if (perfil === 'sem_observador') {
        win.IntersectionObserver = undefined;
    } else {
        win.IntersectionObserver = class {
            constructor(callback) { this.callback = callback; this.elements = new Set(); observador = this; }
            observe(el) { this.elements.add(el); }
            unobserve(el) { this.elements.delete(el); }
        };
    }
    win.f3baseConsentimentoDados = {
        cookie: nomeCookie, modo: granular ? 'granular' : 'legado',
        padrao: perfil === 'negado' ? 'negado' : 'pre-aprovado',
        controleRodape: rodape, avisoPrimeiraVisita: false, politicaVersao: '1',
        endpoint: '/decisao-sintetica', publicidadePreAutorizada: false,
        textos: { titulo: 'Preferências de uso', estadoNegado: 'Medição desligada.', estadoAtivo: 'Medição ligada.' }
    };
    const posts = [];
    let classificacoes = 0;
    if (fontes.composto) {
        win.f3baseTrackingDados = {caminho: 'nenhum', resumo: {ativo: false}};
        win.f3baseContextoDados = {contextoUrl: '/contexto-sintetico'};
    }
    win.fetch = async (url, options) => {
        if (url === '/contexto-sintetico' && fontes.composto) {
            classificacoes++;
            return { ok: true, json: async () => ({ok: true, excluida: false}) };
        }
        verificar(url === '/decisao-sintetica' && options.method === 'POST', 'URL inesperada');
        posts.push(JSON.parse(options.body));
        return { ok: true, json: async () => ({persisted: true, comprovante: 'fixture'}) };
    };
    win.eval(fontes.consentimento);
    win.eval(fontes.formularios);
    await esperar();
    if (fontes.composto) {
        verificar(classificacoes === 1 && win.f3baseContexto.pronto() && typeof win.f3baseTracking.permiteTags === 'function', 'composto carregado e classificação consultada uma vez');
    }
    const mapa = Array.from(win.dataLayer[0]);
    verificar(mapa[0] === 'consent' && mapa[1] === 'default', 'política inicial imediata');
    verificar(mapa[2].analytics_storage === (granular || perfil === 'negado' ? 'denied' : 'granted'), 'categoria de medição inicial');
    verificar(mapa[2].ad_storage === 'denied' && mapa[2].security_storage === 'granted', 'publicidade e funções essenciais');
    let caixa = doc.getElementById('f3base-consentimento-banner');
    resultados.chegada = {...contagens, elementosDialogo: caixa ? caixa.querySelectorAll('*').length : 0};
    verificar(rodape ? caixa && caixa.hidden : !caixa, 'alvo de aria-controls ao iniciar');
    if (candidato && perfil !== 'sem_observador') {
        verificar(!contagens.leiturasEstilo && !contagens.contextosCanvas, 'entrada sem leitura de estilo nem alocação de canvas');
    }
    if (candidato) {
        verificar(resultados.chegada.elementosDialogo === 0, 'conteúdo oculto foi adiado');
        verificar(!resultados.chegada.parsesSentinela, 'sem parse JSON de cookie vazio');
    }
    const consultas = contagens.buscasGlobaisForms;
    const main = doc.querySelector('main');
    for (let n = 0; n < 40; n++) {
        main.appendChild(doc.createElement('span'));
        await Promise.resolve();
    }
    resultados.buscasPor40MutacoesAlheias = contagens.buscasGlobaisForms - consultas;
    if (candidato) { verificar(resultados.buscasPor40MutacoesAlheias === 0, 'sem buscas globais para DOM alheio'); }
    const wrapper = doc.createElement('div');
    wrapper.innerHTML = '<form data-f3base-formulario="contato">' + htmlForm + '</form>';
    main.appendChild(wrapper);
    await esperar();
    const form = wrapper.querySelector('form');
    const instancia = form.elements.submissao.value;
    verificar(/^[a-f0-9]{32}$/.test(instancia) && form.querySelector('[data-etapa="2"]').hidden, 'formulário dinâmico pronto');
    main.appendChild(wrapper);
    await esperar();
    verificar(form.elements.submissao.value === instancia, 'movimento preserva instância');
    if (candidato) {
        const parcial = doc.createElement('form');
        parcial.setAttribute('data-f3base-formulario', 'parcial');
        main.appendChild(parcial);
        await esperar();
        parcial.innerHTML = htmlForm;
        await esperar();
        verificar(parcial.elements.submissao.value.length === 32, 'inserção parcial');
        const marcado = doc.createElement('form');
        marcado.innerHTML = htmlForm;
        main.appendChild(marcado);
        await esperar();
        marcado.setAttribute('data-f3base-formulario', 'posterior');
        await esperar();
        verificar(marcado.elements.submissao.value.length === 32, 'marcação posterior');
    }
    if (rodape && observador) {
        verificar(observador.elements.has(rodapeEl), 'rodapé observado');
        observador.callback([{isIntersecting: false, target: rodapeEl}]);
        verificar(!rodapeEl.hasAttribute('data-f3base-contraste'), 'rodapé distante em espera');
        observador.callback([{isIntersecting: true, target: rodapeEl}]);
        verificar(rodapeEl.hasAttribute('data-f3base-contraste'), 'paleta aplicada ao rodapé próximo');
    }
    if (perfil === 'sem_observador') {
        verificar(rodapeEl.hasAttribute('data-f3base-contraste'), 'paleta aplicada sem observador');
    }
    if (controle) { controle.click(); } else { win.f3baseConsentimento.abrir(); }
    caixa = doc.getElementById('f3base-consentimento-banner');
    verificar(caixa && !caixa.hidden && doc.activeElement === caixa, 'abrir e focar');
    verificar(caixa.querySelector('h2').textContent === 'Preferências de uso' && caixa.hasAttribute('data-f3base-contraste'), 'texto e paleta do painel');
    const children = caixa.querySelectorAll('*').length;
    if (rodape) {
        verificar(controle.getAttribute('aria-expanded') === 'true', 'controle indica abertura');
        doc.dispatchEvent(new win.KeyboardEvent('keydown', {key: 'Escape'}));
        verificar(caixa.hidden && doc.activeElement === controle && controle.getAttribute('aria-expanded') === 'false', 'fechar e devolver foco');
        controle.click();
    }
    verificar(caixa.querySelectorAll('*').length === children, 'reabertura não repete conteúdo');
    caixa.removeAttribute('data-f3base-contraste');
    doc.dispatchEvent(new win.Event('f3base-tema-alterado'));
    verificar(caixa.hasAttribute('data-f3base-contraste'), 'tema alterado com painel aberto');
    if (granular) {
        const escolhas = caixa.querySelectorAll('input[type=checkbox]');
        escolhas[0].checked = true;
        escolhas[1].checked = false;
        caixa.querySelector('.f3base-consentimento-salvar').click();
        verificar(win.f3baseConsentimento.permiteCategoria('medicao') && !win.f3baseConsentimento.permiteCategoria('publicidade'), 'escolha granular local imediata');
        await esperar();
        verificar(posts.length === 1 && posts[0].medicao && !posts[0].publicidade && !win.f3baseConsentimento.servidorPendente(), 'uma confirmação sintética');
    } else {
        caixa.querySelector('.f3base-consentimento-recusar').click();
        verificar(!win.f3baseConsentimento.permiteTags() && caixa.hidden && posts.length === 0, 'negativa legada persiste');
    }
    // O mesmo portão lê escolhas antigas, categorias atuais e cookies adulterados.
    const definirCookie = valor => { doc.cookie = nomeCookie + '=' + encodeURIComponent(valor) + '; Path=/'; };
    const permite = categoria => win.f3baseConsentimento.permiteCategoria(categoria);
    definirCookie('JSON inválido');
    verificar(permite('medicao') === (!granular && perfil !== 'negado') && !permite('publicidade'), 'cookie ilegível segue política');
    if (granular) {
        definirCookie(JSON.stringify({v:'obsoleta', medicao:true, publicidade:true}));
        verificar(!permite('medicao') && !permite('publicidade'), 'escolha granular vencida');
        definirCookie(JSON.stringify({v:'1', medicao:false, publicidade:true}));
        verificar(!permite('medicao') && permite('publicidade'), 'escolha vigente com categorias distintas');
    } else {
        definirCookie('granted');
        verificar(permite('medicao') && permite('publicidade'), 'aceite explícito legado');
        definirCookie('denied');
        verificar(!permite('medicao') && !permite('publicidade'), 'negativa explícita legada');
    }
    resultados.elementosDialogoAoAbrir = children;
    resultados.verificacoes = verificacoes;
    return resultados;
}
