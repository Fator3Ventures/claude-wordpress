"""Compara hooks compilados e nativos e confere carga tardia por tipo de requisição."""
import argparse
import json
import math
import os
from pathlib import Path
from statistics import median
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def executar(perfil, estrategia, plugin=None):
    comando = [ROOT / 'build/php', ROOT / 'tests/servidor-1710.php', perfil, estrategia]
    env = os.environ.copy()
    if plugin is not None:
        env['F3BASE_BOOTSTRAP_PLUGIN'] = str(plugin)
    saida = subprocess.run(comando, env=env, capture_output=True, text=True, check=False)
    if saida.returncode:
        raise RuntimeError(saida.stdout + saida.stderr)
    return json.loads(saida.stdout)


def conferir(perfil):
    atual = executar(perfil, 'compilado')
    nativo = executar(perfil, 'nativo')
    assert atual['inventario'] == nativo['inventario'], perfil
    hooks = atual['inventario']
    assert len(hooks['auth_cookie_expiration']) == 1, perfil
    assert ('wp_footer' in hooks) == (perfil not in ('contexto', 'login')), perfil
    assert ('wp_ajax_f3base_navegacao_verificar' in hooks) == (perfil == 'sonda'), perfil
    assert ('admin_post_f3base_operar' in hooks) == (perfil == 'promocao'), perfil
    assert atual['perfil_publico_ativo'] == (perfil != 'promocao'), perfil
    arquivos = atual['registros']
    assert 'bootstrap-hooks-publicos.php' in arquivos, perfil
    assert ('bootstrap-hooks.php' in arquivos) == (perfil == 'promocao'), perfil
    if perfil == 'promocao':
        assert len(hooks['admin_post_f3base_operar']) == 1
    return {'ganchos': len(hooks), 'arquivos_registro_bytes': arquivos, 'equivalente_ao_nativo': True}


def comparar(anterior, pares):
    # Dois processos novos por par. Alternar a ordem reduz viés de aquecimento.
    amostras = {'anterior': [], 'atual': []}
    for indice in range(pares):
        ordem = ('anterior', 'atual') if indice % 2 == 0 else ('atual', 'anterior')
        for versao in ordem:
            plugin = anterior if versao == 'anterior' else None
            amostras[versao].append(executar('pagina', 'compilado', plugin))
        assert amostras['anterior'][-1]['inventario'] == amostras['atual'][-1]['inventario']
    resumo = {}
    for versao, itens in amostras.items():
        tempos = sorted(item['registro_ms'] for item in itens)
        resumo[versao] = {
            'pares': pares,
            'p50_ms': median(tempos),
            'p95_ms': tempos[math.ceil(.95 * pares) - 1],
            'mediana_alocados_bytes': median(item['alocados_bytes'] for item in itens),
            'arquivos_registro_bytes': itens[-1]['registros'],
            'opcache_ativo': itens[-1]['opcache_ativo'],
        }
    return resumo


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--anterior', type=Path, help='diretório de outra versão do plugin para comparação pareada')
    parser.add_argument('--pares', type=int, default=30)
    args = parser.parse_args()
    if args.pares < 2:
        parser.error('--pares deve ser maior ou igual a dois')
    perfis = ('pagina', 'login', 'contexto', 'sonda', 'promocao')
    resultados = {'perfis': {perfil: conferir(perfil) for perfil in perfis}}
    if args.anterior:
        resultados['registro_pagina_php_cli'] = comparar(args.anterior.resolve(), args.pares)
    print(json.dumps(resultados, ensure_ascii=False, indent=2))
