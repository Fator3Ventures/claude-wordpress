"""Recria somente a base local protegida por cycle-1370.php e prepara o wp-admin para QA."""
from pathlib import Path
import os, subprocess
root=Path(__file__).resolve().parents[1]
lab=Path(os.environ['F3BASE_LAB_DIR']); cli=[str(root/'build/php'),str(root/'dependencies/wp-cli.phar'),'--allow-root','--path='+str(lab/'wordpress')]
def run(args):
 result=subprocess.run(args,text=True,capture_output=True)
 if result.returncode:raise RuntimeError(result.stdout[-1200:]+result.stderr[-1200:])
 return result.stdout.strip()
print(run([str(root/'build/php'),str(root/'tests/cycle-1370.php'),'install'])[:200],flush=True)
print(run(cli+['plugin','activate','wp-mcp-fator3','wp-mcp-linkedin-fator3','wp-mcp-google-fator3','wp-mcp-meta-fator3'])[-320:],flush=True)
for k in ['home','siteurl']:run(cli+['option','update',k,'http://127.0.0.1:8136'])
print(run(cli+['cron','event','run','--due-now'])[-240:],flush=True)
