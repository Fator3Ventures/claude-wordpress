<?php
require __DIR__.'/bootstrap.php';
require_once ABSPATH.'wp-admin/includes/nav-menu.php';
wp_set_password('synthetic-only-1360',1);
foreach (['Menu salvo QA','Alternativa QA'] as $label) { if (!wp_get_nav_menu_object($label)) { wp_create_nav_menu($label); } }
$menu=wp_get_nav_menu_object('Menu salvo QA');
raw('f3base_navegacao',array_replace(F3Base_Options::ler('f3base_navegacao'),['tipo'=>'menu_classico','id'=>(int)$menu->term_id]));
if (!get_user_by('login','leitorqa')) { wp_insert_user(['user_login'=>'leitorqa','user_pass'=>'somente-bancada-ui','role'=>'subscriber','user_email'=>'leitor@example.test']); }
$hub=F3Base_Config_UI::html('<p>Texto simples</p>');
$literal=F3Base_Config_UI::html('<textarea name="assinatura">["texto"]</textarea>');
$malformed=false;$_GET['secao']='conexoes';$_GET['integracao']=[];try { F3Base_Config_UI::status(); } catch (Throwable $e) { $malformed=true; }
file_put_contents(getenv('F3BASE_ROOT').'/evidence/1700/observacao-'.F3BASE_PLUGIN_VERSAO.'.json', wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'catalogo_em_html_sem_editor'=>str_contains($hub,'f3base-editor-catalogo'),'texto_literal_convertido'=>!str_contains($literal,'<textarea'),'parametro_invalido_lanca_excecao'=>$malformed]));
