"""Aceite autenticado no wp-admin descartável. Salva evidências técnicas sem cookies/segredos."""
from pathlib import Path
from contextlib import contextmanager
import os, subprocess, socket, time, json
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright
r=Path(__file__).resolve().parents[1];lab=Path(os.environ['F3BASE_LAB_DIR']);base='http://127.0.0.1:8136';entry=base+'/wp-admin/admin.php?page=base-site-core-fator3';version=os.environ.get('F3_UI_VERSION','1.70.0');before=version=='1.69.0';checks={}
@contextmanager
def server():
 with open(lab/'ui-server.log','a') as log:
  p=subprocess.Popen([str(r/'build/php'),'-S','127.0.0.1:8136','-t',str(lab/'wordpress')],stdout=log,stderr=log)
  try:
   for _ in range(80):
    try:
     with socket.create_connection(('127.0.0.1',8136),.15):break
    except OSError:time.sleep(.1)
   yield
  finally:p.terminate();p.wait(timeout=5)
def check(name, value):
 checks[name]=bool(value)
 if not value:raise AssertionError(name)
def login(page,user='admin',password='synthetic-only-1360'):
 page.goto(base+'/wp-login.php');page.locator('#user_login').fill(user);page.locator('#user_pass').fill(password);page.locator('#wp-submit').click();page.wait_for_url('**/wp-admin/**')
with server(),sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);ctx=browser.new_context(viewport={'width':1280,'height':900});ctx.route('**/*',lambda route: route.continue_() if urlsplit(route.request.url).hostname=='127.0.0.1' else route.abort());page=ctx.new_page();page.set_default_timeout(12000);login(page);page.goto(entry);page.locator('#f3base-busca-config').wait_for();check('inicio_autenticado',page.locator('#wpadminbar').count()==1);checks['atalhos']=page.locator('[data-f3base-busca]').count();checks['catalogo_crm_na_inicio']=bool(page.locator('#f3base-editor-catalogo').count());page.screenshot(path=lab/('inicio-'+version+'.png'))
 page.goto(entry+'&secao=conteudo');select=page.locator('#f3base-nav-id');old=select.input_value();check('referencia_salva_existe',old!='0');page.locator('#f3base-nav-busca').fill('Alternativa');page.locator('#f3base-nav-pesquisar').click();page.wait_for_function("document.querySelector('#f3base-nav-status').textContent.includes('referência')");checks['busca_preserva_selecao']=select.input_value()==old
 if not before:check('busca_preserva_selecao',checks['busca_preserva_selecao'])
 (r/'evidence/1700'/('navegador-'+version+'.json')).write_text(json.dumps({'versao':version,'chromium':browser.version,'observacoes':checks},ensure_ascii=False,indent=2));print(json.dumps(checks));browser.close()
