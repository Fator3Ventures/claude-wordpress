/** Exercita o callback registrado pelo cliente completo, com o relógio de navegação controlado. */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {JSDOM} = require(process.env.F3BASE_JSDOM || './dom/node_modules/jsdom');
const root = path.resolve(__dirname, '..');
const assets = path.join(root, 'work/plugin/base-site-core-fator3/assets');
const results = {};
function check(name, value) {
  assert(value, name);
  results[name] = true;
}

async function scene(asset) {
  const dom = new JSDOM('<html><head></head><body><main><img></main></body></html>',
    {url:'https://fixture.test/pagina/',runScripts:'outside-only',pretendToBeVisual:true});
  const w = dom.window;
  let consent = true;
  const navigation = {responseStart:800,activationStart:1000};
  let resources = [], lookups = 0;
  w.performance.getEntriesByType = type => type === 'navigation' ? [navigation] : [];
  w.performance.getEntriesByName = () => { lookups++; return resources; };
  w.matchMedia = () => ({matches:false});
  w.f3baseConsentimento = {permiteCategoria:()=>consent,permiteGtm:()=>false};
  const contexto = {pronto:()=>true,teste:()=>false,politica:()=> 'normal',audiencia:()=>({}),
    navegacao:()=>null,sinais:()=>({}),atribuicao:()=>({}),audienciaExcluida:false};
  // O perfil público agrega o módulo de contexto; o fixture controla este limite do coletor.
  Object.defineProperty(w,'f3baseContexto',{get:()=>contexto,set:()=>{}});
  w.f3baseTrackingDados = {caminho:'nenhum', vitaisUrl:'/vendor.js',vitaisMaxAtualizacoes:60,
    comportamento:{eventos:{teste_vital:{gatilho:'desempenho',teto:50,parametros:['metrica','valor'],
      limiar:{vitais:['LCP'],duracao_minima_ms:[16]}}}},
    resumo:{ativo:true,maximo:50,maximoLog:180,maximoVisita:1000}};
  let callback;
  w.webVitals = {onLCP: cb=>{callback=cb;}};
  const detailed = [];
  w.f3baseAnalise = {vital:(...args)=>detailed.push(args)};
  w.eval(fs.readFileSync(path.join(assets, asset), 'utf8'));
  await new Promise(resolve=>setTimeout(resolve,35));
  check(asset+'_registrou_coletor', typeof callback === 'function');
  function emit(id, value, options={}) {
    const url = options.url === undefined ? 'https://static.test/hero.png?segredo=1#frag' : options.url;
    callback({id,name:'LCP',value,navigationType:options.navigationType||'navigate',navigationStartTime:options.start||0,
      entries:[{element:w.document.querySelector('img'),url}]});
  }
  function sample(id) {
    const visit = JSON.parse(w.localStorage.getItem('f3base_sessao'));
    return visit.acumulado.metricas.find(m=>m.amostra && m.amostra.id === id);
  }
  try {
    resources = [{entryType:'resource',requestStart:1060,startTime:1050,responseEnd:1180}];
    emit('vital0001',300);
    const first = sample('vital0001');
    assert.deepEqual(first.amostra.atribuicao.fases,
      {ttfb:0,atraso_carga:60,duracao_carga:120,atraso_renderizacao:120});
    check(asset+'_prerender_fases_somam_ao_lcp', Object.values(first.amostra.atribuicao.fases).reduce((a,b)=>a+b,0)===300);
    check(asset+'_sem_query_fragmento_ou_id_dom', first.amostra.atribuicao.recurso==='https://static.test/hero.png' &&
      first.amostra.atribuicao.alvo==='html:nth-of-type(1)>body:nth-of-type(1)>main:nth-of-type(1)>img:nth-of-type(1)');
    emit('vital0001',320);
    emit('vital0001',320);
    check(asset+'_revisao_sem_duplicar', sample('vital0001').amostra.sequencia===2 && detailed.length===2);
    resources=[];
    emit('vital0002',330);
    assert.deepEqual(sample('vital0002').amostra.atribuicao.fases,{ttfb:0});
    check(asset+'_recurso_sem_timing_preserva_ausencia',true);
    emit('vital0003',335,{url:''});
    assert.deepEqual(sample('vital0003').amostra.atribuicao.fases,
      {ttfb:0,atraso_carga:0,duracao_carga:0,atraso_renderizacao:335});
    check(asset+'_lcp_texto_sem_download',true);
    navigation.responseStart=0;
    emit('vital0004',340);
    check(asset+'_ttfb_indisponivel_nao_vira_zero',!('fases' in sample('vital0004').amostra.atribuicao));
    navigation.responseStart=1200;
    emit('vital0005',345,{navigationType:'soft-navigation'});
    emit('vital0006',345,{navigationType:'back-forward-cache'});
    check(asset+'_nao_atribui_fases_da_navegacao_anterior',!('fases' in sample('vital0005').amostra.atribuicao) &&
      !('fases' in sample('vital0006').amostra.atribuicao));
    const beforeLookups=lookups, beforeDetailed=detailed.length;
    consent=false;
    emit('vital0001',400);
    check(asset+'_revisao_negada_sem_atribuicao_ou_evento',lookups===beforeLookups && detailed.length===beforeDetailed);
  } finally { dom.window.close(); }
}
(async()=>{
  for (const asset of process.argv.slice(2).length ? process.argv.slice(2) :
    ['f3base-tracking.js','f3base-tracking.min.js','perfis/publico-0.min.js','perfis/publico-31.min.js',
      'perfis/tracking-0.min.js','perfis/tracking-31.min.js']) {
    await scene(asset);
  }
  const evidence = {ambiente:'Cliente integral em jsdom, entradas de desempenho e consentimento controlados, sem rede',checks:results};
  fs.writeFileSync(path.join(root,'evidence/1710/medicao-1710-cliente.json'),JSON.stringify(evidence,null,2));
  console.log(Object.keys(results).length+' checks OK');
})().catch(error=>{console.error(error);process.exitCode=1;});
