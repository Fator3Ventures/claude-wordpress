# Plano da rodada 1.71.0

Base do Core 1.70.0, fonte ba59795f3d49e29d966c469f5776cbc789fc413728fae6d2a7d7270c68b401df e instalador a98245e9e0a41035e9f0439add1e41cd52ded7d43761a4112dd1d380848b9089. Normas da revisão 5 de 02/11/2026.

1. Isolar o custo no servidor e identificar o trabalho que realmente precisa ocorrer antes da renderização do conteúdo público.
2. Reduzir o trabalho de inicialização do navegador sem perder consentimento, navegação breve, interação comercial ou carregamento tardio de capacidade opcional.
3. Rastrear métricas de campo do observador até o relatório, verificar denominadores, ausências e exclusões. Separar duração do WordPress, intervalos instrumentados do Core e tempo observado pelo visitante.
4. Comparar, no mesmo WordPress, Core desligado, 1.70.0 e candidato. Medir sondas de site separadamente. Distinguir a amostra de diagnóstico e a coleta básica.
5. Ampliar testes de regressão PHP e JavaScript. Verificar cinco pacotes companheiros e a documentação MCP, instalação limpa, atualização direta, persistência e reinstalação.
6. Instalar o ZIP validado exclusivamente no Site-Teste, repetir sondas, verificar saúde e fechar fonte, instalador e relatório com identidades conferidas.

Escopo de impacto: bootstrap público, ativos próprios e medição no Core. Preservar integrações compartilhadas de MCP, Google, Meta, LinkedIn e Pipedrive, permissões, configurações antigas e fluxo do ecossistema. Nenhuma campanha ou envio a fornecedor integra o experimento.
