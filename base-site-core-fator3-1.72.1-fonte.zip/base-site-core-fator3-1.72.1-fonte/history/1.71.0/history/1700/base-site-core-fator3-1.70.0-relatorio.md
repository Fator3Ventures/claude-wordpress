# Entrega — Fator3 Site Core 1.70.0

Revisão 1 · 2026-11-05T08:57:41-03:00 · Implementação e revisão de interface

Slug `base-site-core-fator3`. Status `com-pendencias` pelas provas delimitadas na seção 6. O Core 1.70.0 está instalado e ativo no Site-Teste. O ciclo interno terminou com zero avisos.

## 1. De onde esta versão entra

A origem da atualização direta é a entrega canônica 1.69.0. Seu instalador tem 4256023 bytes e SHA-256 `8659ce0e526d378cf8424d0ff42deed660fee9f957be08f2bf26a74ce7f52996`. O fonte base tem 5728084 bytes e SHA-256 `2c4e19805fb78bfdef16f434559e9908004d1b7260613e82925f813aa826e4ee`. A bancada também exercitou instalação limpa. A identidade publicada continua sendo `base-site-core-fator3/base-site-core-fator3.php`.

As duas normas do projeto foram lidas integralmente na revisão 5 de 02/11/2026. O padrão completo orientou o checklist de encerramento. Requisitos declarados e verificados no cabeçalho: WordPress 7.1.4 e PHP 8.3. A bancada executou WordPress 7.1.4, PHP 8.3.6 de 64 bits, MySQL 8.0.46 e WP-CLI 2.12.0. O Site-Teste informou WordPress 7.1.4, PHP 8.3.36 e banco 8.4.11-0ubuntu0.26.04.1.

## 2. Convivência e encaminhamentos

| Pacote | Primeiro inventário em 05/11 | No instante da instalação e no encerramento | Evidência |
| --- | --- | --- | --- |
| wp-mcp-fator3 | 0.38.0 | 0.39.0 | Bancada com a versão final e Site-Teste |
| wp-mcp-google-fator3 | 0.26.0 | 0.27.0 | Bancada com a versão final e Site-Teste |
| wp-mcp-linkedin-fator3 | 0.17.1 | 0.18.0 | Bancada com a versão final e Site-Teste |
| wp-mcp-meta-fator3 | 0.19.0 | 0.20.0 | Bancada com a versão final e Site-Teste |
| wp-mcp-pipedrive-fator3 | 0.5.0 | 0.6.0 | Estado local do contrato no Site-Teste |

Os cinco acompanhantes foram atualizados em operações separadas entre o primeiro inventário e a instalação do Core. A versão de cada um já era a final ao iniciar a troca do Core. O inventário imediatamente anterior e o posterior coincidem para os outros oito plugins, inclusive WP Super Cache 3.1.5, Yoast 28.8 e DreamHost Panel Login 1.0.0. O fechamento considera o conjunto final. A bancada repetiu os testes com os quatro instaladores finais disponíveis. Os hashes constam em `evidence/1700/pacotes-vigentes.json`. A ausência de ZIP local do Pipedrive 0.6.0 foi compensada no alcance da convivência pela consulta `pipedrive/status` do Site-Teste: cliente registrado, contrato `pipedrive-api-client/1.0.0`, chamada_externa=false.

A fronteira revista compreende telas e gravações do Core, a leitura administrativa via MCP e o uso do contrato atual LinkedIn na prévia de conexão. O contrato administrativo é 8.32.0. Os schemas públicos, o leitor `linkedin-lead-reader/1.2.0`, a extensão de campanha 1.0.0 e o cliente Pipedrive publicado atendem à versão nova. A análise e os testes não identificaram solicitação técnica a encaminhar a outro mantenedor. A confirmação de conexão do painel guarda as revisões da prova e entrega os parâmetros à transição existente. As condições para aceite comercial da frota seguem na seção 6.

## 3. Mudanças e evidência

O pedido de 05/11/2026, sem número novo atribuído, abrange revisão e melhoria do código, mais testes, melhor organização das configurações e documentação. A análise acompanhou a navegação de entrada, as formas de gravação, as conexões, o leitor documental e os controles de edição em JavaScript.

| Pedido / fluxo | Problema observado na base | Entrega e prova |
| --- | --- | --- |
| Gravação de avisos, retenção e homologação | POST autenticado sem a lista de destinatários apagava o endereço já salvo. O processamento interpretava um campo ausente como valor vazio e percorria a gravação de todos os grupos. | Campos e revisões validados antes da primeira escrita. Somente grupos alterados são gravados. Um vazio explícito continua podendo limpar a lista. O POST truncado retorna 400 e a releitura conserva o destinatário. Provas PHP e HTTP. |
| Formulários de conexão | Campos opcionais e ocultos antes compartilhavam o tratamento de dados não enviados. Uma resposta genérica escondia a diferença entre salvar preferências e atualizar a credencial. | A lista do que cada tela pode editar alimenta renderização e validação. Pipedrive, os dois e-mails, Google e Meta foram exercitados pelo POST real. Cobertura de reenvio intacto, envio truncado, booleano ausente, campo de outra área e alteração real de remetente. Falha na credencial após gravar preferências tem mensagem específica. |
| Diretório e ajuda | A entrada apresentava uma lista única de atalhos, repetia destinos e carregava dados do editor do CRM até em HTML sem editor. Um parâmetro `integracao[]` provocava exceção. | Quatro grupos por tarefa, busca por palavras sem distinção de acento/caixa, estado vazio e limpeza com retorno de foco. Inclui acervo GA4, guia dentro do painel, resolução segura da aba e carregamento condicional do catálogo. A reprodução confirmou a presença do catálogo na base e sua ausência no diretório novo. |
| Campos e diagnóstico | O texto literal `["texto"]` em uma caixa comum era substituído por um editor estruturado. Um bloco de diagnóstico textual podia ser ocultado pela transformação de HTML. | O schema determina quando criar o editor. Campos de texto e diagnóstico textual são preservados. Os mapas continuam com controles estruturados. Teste específico cobre os dois formatos. |
| Navegação e listas editáveis | Buscar outra página de menus substituía o menu escolhido. Respostas antigas podiam repovoar outro tipo de referência. Clonar ou limpar uma linha de autorização apagava o valor enviado pelo checkbox. | Busca e paginação preservam a seleção. Mudança de termo ou tipo invalida a requisição anterior. Linhas são numeradas por tabela, preservam o valor 1 do checkbox e mantêm foco após remoção. Comparações DOM executaram o JS original e o final com a marcação real do WordPress. |
| Conexões e apresentação | Seções ficavam abertas em série, e estados técnicos disputavam espaço com a edição. E-mail e LinkedIn podiam mostrar um estado genérico inadequado ao modo ativo. | Abas sinalizam a área atual. A primeira seção da conexão abre para preenchimento, e o operador expande campos avançados pelo título. Descrições orientam o efeito de cada grupo. O diagnóstico detalhado vem ao final. E-mail distingue importação/envio e o LinkedIn usa o estado da integração selecionada. |
| Prévia do LinkedIn | Ao redirecionar, a interface podia confirmar o modo já salvo ou reconstruir a troca a partir dos campos do formulário em vez da seleção conferida. | Conexão, conta e formulários têm uma prévia guardada por usuário/integração por 10 minutos. Confirmar usa somente esse destino, revisão local e revisões conferidas do produtor. Nova prévia invalida a antiga. A seleção automática tem confirmação independente ligada ao modo escolhido. Dez verificações da interface com produtor real/HTTP sintético, além das 60 regressões do 369. |
| Documentação e leitor | O operador precisava cruzar notas de várias versões para saber onde editar e salvar. O leitor reabria o arquivo para calcular o hash. | Um único `docs/GUIA-PAINEL.md` alimenta a tela Guia de configuração e a leitura MCP. O leitor limita o arquivo, confere o caminho real e calcula texto/hash a partir da mesma leitura. Índice, agentes, configuração, contratos e notas atualizados. |

Estado dos itens: `implementado`, `validado-localmente` e `validado-wordpress` no escopo das provas descritas. A avaliação visual e as contas de fornecedores têm limites próprios. `runtime-diff.json` registra quatro arquivos acrescentados, 33 alterados e zero removidos. O trabalho inclui uma nova classe do painel central, guia e notas para agentes/release.

## 4. Instalação e prova da troca

Os testes funcionais do conjunto final somam **150 verificações**. São 19 no processamento das configurações, 10 na prévia LinkedIn, 34 via HTTP autenticado, 27 no DOM comparando os dois runtimes e 60 de regressão da aquisição LinkedIn. A base 1.69.0 teve ainda nove verificações HTTP próprias para reprodução. O erro de perda do destinatário foi visto na resposta do admin-post e confirmado por nova leitura. Credenciais de QA são sintéticas. A bancada bloqueia HTTP e e-mail externos. O produtor LinkedIn é o pacote PHP original com respostas HTTP controladas.

O leitor documental foi exercitado com a autenticação administrativa de laboratório e a Abilities API. Resultado: 182 documentos completos em 798 páginas, 2089 asserções aprovadas e duas contagens de cobertura. Conferiu conteúdo, hash, paginação, autorização e bloqueio de acesso arbitrário. O catálogo gerado refere 192 abilities e 102 opções operáveis. Os testes cobriram a leitura administrativa e a recusa ao assinante e ao anônimo. O guia servido no wp-admin também foi acessado por HTTP autenticado.

O lint aprovou 595 arquivos PHP. Instalação limpa e atualização direta 1.69.0 → 1.70.0 usaram o instalador da seção 8 em WordPress nativo. A execução por WP-CLI confirmou o ciclo em processo separado. Testes conferiram callback, progressos, escolhas, credencial sintética e dados populados com fotografia antes/depois, repetição idempotente e reativação da versão atual. O runtime de fonte e o instalador têm 922 arquivos correspondentes byte a byte.

**Site-Teste autorizado.** Foi usada transferência autenticada do ZIP final pelo WP MCP fator3-teste. `files/upload-create`, 17 partes e `files/upload-finalize` confirmaram 4266812 bytes e o SHA-256 da seção 8 no servidor. A instalação usou `plugins/upload-base64` com o caminho recebido, expected_slug do Core, expected_sha256, activate=true, overwrite=true, timeouts de 20 segundos e chave de idempotência. Operação `186950f5c77c9db4f18dea767f90ec50`. Pré-imagem `193ce7e84803c47a2667b4a9`. A leitura `plugins/operation-status` confirmou complete, verified, candidate e Core 1.70.0 ativo. As sondas internas de `/` e `/wp-json/` retornaram 200 antes e depois da troca.

`f3base/saude-ler` confirmou, separadamente, conclusão em **2026-11-05T08:48:11-03:00**, contrato 8.32.0, recuperação `core_operacional`, zero avisos e verificações posteriores de cabeçalhos, navegação e conta Pipedrive. `system/health` retornou healthy=true e nenhuma recuperação pendente. A janela de 24 h registrava duas ocorrências de agenda (`could_not_set`) anteriores à instalação. A verificação não atribuiu essas ocorrências ao Core novo.

A operação documental foi descoberta no catálogo do Site-Teste, seu schema foi consultado e o índice retornou 182 documentos da 1.70.0. Cinco documentos completos foram comparados com o instalador: índice, guia do painel, release, agentes e configuração. Foram 8 páginas e 186 linhas, com conteúdo e hash idênticos. O guia foi lido em quatro páginas para exercitar a continuação. Removido apenas o ZIP temporário da transferência, com guarda pelo SHA-256 (operação `fcd8965cfb658ec2fcec6583`).

## 5. Banco, migração e correção por nova versão

O inventário segue com 70 tabelas. A atualização usa o ciclo existente e preserva as opções, credenciais e filas. A novidade persistente da interface são prévias transitórias por usuário e integração com expiração. Campos fora do formulário ficam sob a responsabilidade de suas telas. Erros de revisão impedem aplicar uma preferência antiga. Uma gravação parcial informa os grupos confirmados para permitir a releitura antes da retomada.

A pré-imagem da operação cobre arquivos do plugin. A recuperação de dados segue o inventário próprio de backup do site. A instalação não exigiu alteração manual da configuração real nem restauração de banco. O instalador testado e instalado é imutável. Qualquer correção de código após este fechamento requer nova versão.

## 6. O que permanece pendente

- **Interface visual.** A bancada autenticada e os testes DOM cobriram navegação, escolhas e gravações. O Chromium local encerrou antes de abrir a página porque o processo não conseguiu criar seu soquete. O navegador remoto não alcançou o servidor local. A inspeção visual autenticada de larguras desktop e celular continua pendente com a manutenção. O roteiro Playwright está no fonte para um ambiente com navegador disponível. A cobertura DOM usa JSDOM 27 e não mede o layout renderizado.
- **Piso PHP.** PHP 8.3.0 exato ainda requer execução pela manutenção. Foram testados 8.3.6 local e 8.3.36 no Site-Teste. WordPress 7.1.4 foi verificado diretamente.
- **Fornecedores e frota.** A convivência Pipedrive 0.6.0 foi observada no Site-Teste, por leitura local e verificação do ciclo do Core. O ZIP desse pacote não foi usado na bancada. O aceite da frota para campanhas/assinaturas reais do pedido 369 e os indicadores anteriores de desempenho seguem separados. Novas entregas reais de CRM, assinaturas, e-mails ou anúncios não fazem parte destas provas. Não houve implantação em sites de produção da frota.

## 7. Credenciais e configuração do dono

Para usar o guia e editar preferências é necessário perfil de administrador com `manage_options`. Em Site Core → Configurações → Conexões e entregas, escolha o serviço e o campo de credencial correspondente. O campo em branco conserva o segredo salvo. A remoção usa a escolha explícita do próprio formulário. No LinkedIn, o cliente Plugin LinkedIn usa conexão e concessão do produtor. O cliente Core usa o cofre do site. A prévia confere metadados. Importar contatos e ativar recebimento imediato são operações distintas com efeitos indicados na tela. Valores de produção, cookies e respostas de contatos ficam fora dos artefatos.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| Instalador | [base-site-core-fator3-1.70.0-instalador.zip](sandbox:/workspace/scratch/e0ec4f78aa38/core1700/release/base-site-core-fator3-1.70.0-instalador.zip) | 4266812 | `a98245e9e0a41035e9f0439add1e41cd52ded7d43761a4112dd1d380848b9089` |
| Fonte | [base-site-core-fator3-1.70.0-fonte.zip](sandbox:/workspace/scratch/e0ec4f78aa38/core1700/release/base-site-core-fator3-1.70.0-fonte.zip) | 5753985 | `ba59795f3d49e29d966c469f5776cbc789fc413728fae6d2a7d7270c68b401df` |

O relatório externo é canônico. A cópia no fonte é anterior ao fechamento e indica o nome do relatório externo. O hash do próprio fonte é preenchido somente após gerar o ZIP. Evidências próprias estão em `evidence/1700`, incluindo os recibos de instalação, a leitura documental e a repetição com os acompanhantes finais em `atuais/`. A publicação raw e a distribuição às demais instalações permanecem com a frota. Os artefatos entregues ao dono contêm somente o próprio pacote, seus testes e documentação.
