# Convivência da versão 1.71.0

A bancada iniciou em WordPress 7.1.4 com cinco acompanhantes ativos. O inventário inicial do Site-Teste fica em `evidence/1710/site-base-plugins.json`. Os hashes SHA-256 dos instaladores, suas versões de entrada e a data da conferência remota ficam em `evidence/1710/pacotes-vigentes.json`.

| Acompanhante | Bancada inicial | Bancada após atualização | Site-Teste às 14:07 UTC de 05/11/2026 |
| --- | --- | --- | --- |
| MCP | 0.39.0 | 0.40.0 | 0.40.0 ativo |
| Google | 0.27.0 | 0.27.0 | 0.27.0 ativo |
| LinkedIn | 0.18.0 | 0.18.0 | 0.18.0 ativo |
| Meta | 0.20.0 | 0.20.0 | 0.20.0 ativo |
| Pipedrive | 0.6.0 | 0.6.0 | 0.6.0 ativo |

O relatório final do MCP 0.40.0, revisão 1, fechou às 13:53 UTC. O instalador conferido tem 932.250 bytes e SHA-256 `2434f99df49c56b6f0200d0ddca18c6dffe1b7c6058c2c88f04859f1e046bd81`. A bancada passou a usar esse pacote às 13:57 UTC. A entrega do MCP mudou as telas administrativas, o controle de perfis e os guias, e confirmou os mesmos schemas de entrada e saída para as 167 habilidades comparadas. Seu mantenedor testou a descoberta de habilidades e uma estrutura clonada de leads com Core 1.70.0.

A composição homologada do Core 1.71.0 corresponde à coluna “Bancada após atualização”. A medição do impacto ao comparar versões do Core requer os mesmos acompanhantes nos dois lados da comparação. O relatório do Core distingue as verificações locais, as realizadas no Site-Teste e os limites de cobertura de fornecedores.

A conferência de 13:58 UTC registrou a combinação intermediária sob Core 1.70.0 (recibo de plugins/list `be382b014678a3e28db760fb`). No corte de homologação das 14:07 UTC, o Site-Teste já operava com Core 1.71.0 e os cinco acompanhantes da tabela (recibo `f9b9cabe4c9280ed1cee69e3`). Google 0.27.0 estava ativo. O relatório final e o instalador de Google 0.28.0 permaneciam pendentes de publicação confirmada nesse corte.
