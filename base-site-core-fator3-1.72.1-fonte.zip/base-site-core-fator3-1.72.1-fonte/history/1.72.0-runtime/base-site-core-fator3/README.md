# Fator3 Site Core 1.72.0

Instale pelo painel de plugins em WordPress 7.1.4 ou superior, com PHP 8.3 ou superior. A atualização direta parte da versão 1.71.0. O índice está em docs/DOCUMENTACAO.md. O guia docs/MEDICAO-DESEMPENHO.md descreve a leitura de velocidade e a composição das amostras.
