# Como medir o impacto do Core

Use este guia para responder a duas perguntas diferentes. Quanto custa executar o Core nesta rota? Que experiência tiveram as visitas das quais o site recebeu métricas? Cada pergunta tem sua própria unidade de análise.

## Escolher a medição

| Pergunta | Medição | Interpretação |
| --- | --- | --- |
| Quanto o Core acrescenta ao tempo até o primeiro byte? | Na bancada, alterne pares com Core ativo e inativo. Use a mesma URL, conteúdo, tema e estado de cache. Compare os deltas por par em milissegundos. | O delta inclui efeitos indiretos, como trabalho do WordPress acionado pelo plugin. |
| Onde o código do Core gasta tempo? | Consulte `f3base/desempenho-ler` em uma requisição separada, com `contexto` igual a `pagina` ou `login` e até três amostras. | O total próprio soma intervalos instrumentados concluídos, descontando filhos também instrumentados. Inclui esperas por serviços dentro desses intervalos. |
| O cache evitou gerar o HTML? | Registre o estado de cache de cada resposta e separe as séries com acerto, desvio e estado desconhecido. | Uma resposta entregue do cache e uma requisição que executou WordPress medem trabalhos diferentes. |
| O que o navegador precisou baixar? | Inspecione a transferência da navegação com estado de cache e compressão conhecidos. Separe HTML, scripts próprios e terceiros. | A soma dos tamanhos dos arquivos declarados no HTML é um inventário. A transferência efetiva depende da resposta, compressão, cache e lógica do navegador. |
| Que experiência o site observou? | Consulte `f3base/vitais-ler` com período, caminho, faixa de tela e segmento. | Compare cada p75 junto ao seu número de amostras. O conjunto pode variar entre métricas ou períodos. |

A página pública e o login anônimos pelo caminho normal dispensam a instrumentação detalhada de callbacks e SQL. Na 1.72.0 essa regra também vale para os POSTs anônimos de comportamento e análise. Sessões autenticadas, diagnósticos assinados e diagnóstico explícito continuam com o perfil. A escolha afeta somente a sonda do servidor. O diagnóstico assinado ativa a sonda desde o início da requisição. Uma requisição sem perfil produz um estado explícito.

A janela de geração PHP começa com a requisição e termina na coleta da sonda. O intervalo não instrumentado abrange trechos do Core, do WordPress, do tema e de outros plugins. Os totais HTTP do transporte remoto incluem espera pelo corpo da resposta. Uma sonda autenticada que mede o Core tem sua própria sobrecarga. Use requisições normais na série de velocidade.

## Dados da medição de campo

| Registro | Dados e granularidade | Consequência para a leitura |
| --- | --- | --- |
| Valor principal | A tabela `f3base_vitais` conserva uma chave derivada, dia, caminho, métrica, faixa de largura da tela, sequência e último valor recebido. A mesma métrica do mesmo carregamento admite até 60 atualizações de sequência. | Uma revisão mais recente da mesma chave substitui seu valor. Conte amostras por métrica. Uma pessoa pode gerar vários carregamentos. |
| Elegibilidade | O registro distingue tráfego de teste, sinais de automação e legado sem classificação. A consulta padrão usa `segmento=sem_testes` e `automacao=audiencia`. | Automação declarada ou provável e legado desconhecido têm contadores de exclusão separados. A classe sem sinal de automação também pode conter robôs. |
| Atribuição de LCP | Elemento estrutural, tipo, recurso HTTP(S) sanitizado e fases disponíveis em ms. Texto do elemento, campos digitados, IDs e classes ficam fora da atribuição. | Imagens sem tempos de recurso suficientes podem ter atribuição parcial. A navegação pré-renderizada exige alinhar os tempos à ativação. |
| Atribuição de INP | Tipo de interação, alvo estrutural, atraso de entrada, processamento, apresentação e origem de script quando o navegador disponibiliza informação temporal. | INP requer interação observável. A ocorrência de um script no mesmo intervalo não estabelece a causa da lentidão. |
| Retenção e acesso | A limpeza dos vitais usa o prazo dos eventos de comportamento, definido em `f3base_comportamento.retencao_eventos_meses`. A consulta agregada administrativa exige `manage_options`. | Confira o prazo efetivo no site. O fluxo de consentimento, a retenção de sessões/contatos e os controles do fornecedor de replay têm registros próprios. |

TTFB mede a chegada do primeiro byte. LCP mede o instante de apresentação do maior conteúdo visível. INP mede a latência das interações observadas. CLS é uma pontuação de instabilidade visual. Use milissegundos para TTFB, LCP e INP. CLS é adimensional. Consulte as definições de referência. [Web Vitals](https://web.dev/articles/vitals) · [TTFB](https://web.dev/articles/optimize-ttfb) · [Fases de LCP](https://web.dev/articles/optimize-lcp)

## Ler o relatório

1. Em Site Core → Medição → Técnico, abra a visão de Web Vitals ou execute `f3base/vitais-ler` com `{"dias":28,"segmento":"sem_testes","automacao":"audiencia","somente_resumo":true}`. O período deve ter de 1 a 90 dias. Registre os limites de data e o fuso retornados.
2. Leia `amostras`, `excluidas_automacao` e `excluidas_legado` para cada linha. Com quatro valores ordenados de 110, 240, 360 e 810 ms, o p75 é o terceiro valor, 360 ms. Uma linha só com exclusões tem p75 nulo. Um CLS observado igual a zero é um valor válido.
3. Para investigar fases, repita com `somente_resumo:false`. O painel e o modo de resumo leem apenas contagens e percentis e dispensam a consulta às atribuições. Para cada média em `fases_media_ms`, consulte seu denominador em `fases_amostras`. A comparação para `fase_dominante` usa somente `amostras_fases_completas`. Ausência de conjunto completo ou empate deixa a fase dominante vazia.
4. Para comparar releases, use janelas que separem as versões e mantenham rota, cache, dispositivo, estado de consentimento e composição da audiência comparáveis. A partir da 1.72.0, aplique o filtro opcional `versao_origem` para separar o código observado pelo navegador. Linhas históricas ou com origem incerta formam o grupo `sem_versao`. Períodos anteriores não ganham versão por inferência da data da visita. Consulte VITAIS-VERSAO.md.

## Cobertura

O diagnóstico detalhado e o replay configurados continuam disponíveis a todas as visitas elegíveis, conforme a política e o consentimento. A coleta de vitais requer suporte do navegador e entrega do lote. Uma saída precoce, uma interação ausente, um bloqueador ou uma falha de entrega podem alterar o denominador. A inicialização do consentimento e os eventos de início de visita são separados da montagem do diálogo. As origens de anúncios e o serviço de replay têm políticas e horários de carregamento próprios. Consulte GUIA-PAINEL.md ao ajustar essas opções.

Preserve esses filtros e a configuração original em comparações. Uma amostra sintética em WordPress demonstra comportamento da implementação. Uma série de campo com população comparável mede experiência dos visitantes.
