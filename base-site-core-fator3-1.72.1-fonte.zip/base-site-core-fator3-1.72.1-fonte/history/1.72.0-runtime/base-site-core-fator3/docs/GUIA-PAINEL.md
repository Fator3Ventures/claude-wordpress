# Como configurar o Site Core

No WordPress, abra Site Core → Configurações. Use a busca para localizar uma tarefa, por exemplo “formulários LinkedIn”, “retenção” ou “GA4”. Limpar busca volta a exibir todas as áreas.

## Atender contatos e enviar avisos

Em Contato, ajuste os botões e as confirmações exibidas aos visitantes. Para mudar quem recebe os avisos, abra Conexões e entregas → Avisos → Destinatários dos avisos. Informe um e-mail por linha e escolha Salvar destinatários. Uma lista específica do formulário tem prioridade sobre a lista geral.

Use E-mail do site para a caixa de entrada e o servidor de envio. E-mail ao novo contato configura a resposta automática. O painel distingue a ativação da importação e a ativação do envio. A verificação de acesso e uma entrega confirmada têm registros próprios.

## Escolher os formulários de anúncios

Abra Conexões e entregas → Origens de anúncios e selecione a plataforma. No LinkedIn, escolha a integração e abra Alterar conexão, conta ou lista de formulários. Informe o cliente, a conexão, a conta e os IDs. Atualizar lista consulta os formulários da conta atualmente salva. Ao trocar de conta, informe os IDs da conta de destino.

Confira a prévia da conexão. O quadro Conexão conferida mostra o destino e a lista que serão aplicados. Aplicar conexão conferida usa a seleção dessa prévia. Caso a concessão ou a configuração tenha mudado, confira outra prévia. Para uma troca em curso, a área de retomada reapresenta o destino registrado.

Para incluir formulários novos automaticamente, habilite o recebimento imediato e configure a concessão no Plugin LinkedIn. Em Seleção de formulários, escolha Todos os formulários autorizados da conta, use Conferir seleção e depois Aplicar seleção conferida. A lista salva continua na operação junto com os formulários descobertos.

Em Coleta e mapeamento, ajuste a responsabilidade, a coleta periódica e os campos dos contatos. As credenciais do cliente Core ficam neste site. As do cliente Plugin LinkedIn ficam na conexão do produtor. Preencher o nome de campanha recebido posteriormente atualiza o registro local. Consulte o estado da coleta para conferir tentativas e revisões.

Recebimento imediato gerencia as assinaturas no fornecedor. Em Verificação e operação, Conferir acesso lê metadados. Consultar novos contatos agora inicia a importação e pode acionar os avisos e o CRM configurados.

## Medição, privacidade e testes

Em Medição e anúncios, escolha a tarefa: identificadores e carregamento de tags, Pixel da Meta, coleta e atribuição, acervo GA4, Search Console, Clarity ou testes. A área Testes e homologação tem um formulário próprio para os destinos de teste do CRM e do e-mail automático.

Em Privacidade e retenção, revise o prazo de cada histórico e use Salvar retenção. A rotina de limpeza aplica os novos prazos em sua próxima execução. Confira a descrição de cada campo antes de reduzir o período de guarda.

## Comparar desempenho entre versões

Em Site Core → Medição → Técnico, abra a visão de Web Vitals. Escolha o caminho, a faixa de tela e a versão de origem. Comece por todas as versões para conferir a cobertura e repita com a versão desejada. Use a seleção sem versão para conhecer o tamanho do histórico sem identificação. Cada linha usa o número de amostras da própria métrica. Consulte VITAIS-VERSAO.md antes de comparar períodos que incluam uma atualização.

## Escolher a navegação

Em Conteúdo e navegação, selecione Menu clássico ou Bloco e pesquise por nome. Pesquisar e avançar a página conservam a referência selecionada. Escolha o resultado desejado e use Salvar alterações. Verificar cabeçalho público executa a verificação de uso na página inicial.

## Conferir a gravação

Nas conexões, a primeira seção abre para edição. Abra os títulos das demais seções para revisar campos, cotas e mapeamentos. Estado e últimas verificações reúne o diagnóstico ao final. Cada formulário tem seu próprio botão de salvar. Uma edição pendente na área comum aparece junto ao botão. Nos formulários de retenção, avisos e homologação, enviar os mesmos valores conserva a configuração já gravada. Uma lista vazia enviada explicitamente expressa a decisão de limpar essa lista.

Se a revisão estiver desatualizada, releia os valores da área antes de repetir. Um formulário incompleto é recusado. Se uma gravação concorrente interromper um envio com vários grupos, a mensagem informa quantos grupos foram confirmados. Reabra a área e confira o resultado antes de aplicar o restante.

Para diagnosticar tarefas e filas, abra Site Core → Operação. O método f3base/documentacao-ler também fornece este guia. Consulte o índice, selecione docs/GUIA-PAINEL.md e use linha, limite e proxima_linha para ler as páginas. Compare versão e SHA-256 entre as respostas.


Core 1.72.0. MEDICAO-DESEMPENHO.md explica o custo de carregamento. VITAIS-VERSAO.md explica como separar medições de versões diferentes. Consulte RELEASE-1.72.0.md para a mudança do contrato 8.34.0.
