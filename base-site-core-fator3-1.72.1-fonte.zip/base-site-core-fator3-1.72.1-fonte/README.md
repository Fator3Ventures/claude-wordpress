# Fator3 Site Core 1.72.1 — fonte reconstruído

Reconstrução ampliada em 06/11/2026, por solicitação do dono. Contém o runtime integral da 1.72.1, build reproduzível, testes reconstruídos e executados, evidências e material histórico recuperado. Os **935 arquivos do runtime** continuam idênticos aos do instalador original. O número da versão permanece **1.72.1**.

Instalador: `base-site-core-fator3-1.72.1-instalador.zip`, 4.323.938 bytes, SHA-256 `3d13dfc96c6dec31221dbe989bdbee27beedbcf98719be0a0447bba7078242f6`.

## Organização e procedência

| Caminho | Conteúdo |
|---|---|
| `work/plugin/base-site-core-fator3/` | Runtime e documentação originais da 1.72.1; árvore usada no instalador |
| `build/` | Geradores reconstruídos, dependências e lockfile do build atual |
| `tests/` | Suíte reconstruída, regressão histórica adaptada e lockfile DOM |
| `evidence/1721-reconstrucao/` | Resultados atuais: 617 verificações funcionais aprovadas |
| `evidence/1721/` | Evidências da primeira recuperação; leituras remotas e integridade |
| `history/1.72.0-runtime/` | 933 arquivos da versão instalada recuperada, base do teste de atualização |
| `history/1.71.0/` | Build, testes, evidências, documentação e insumos do fonte anterior |
| `history/recuperacao-inicial/` | README, relatório e busca parcial de testes anteriores |
| `docs/RECONSTRUCAO-1.72.1.md` | Cobertura, origem, limitações e mapa das provas |
| `source-manifest.json` | Tamanho e SHA-256 dos arquivos, exceto o próprio manifesto |

Os scripts específicos originais da rodada 1.72.0/1.72.1 não foram encontrados. Os testes atuais foram reconstruídos a partir do código, das notas originais e das ferramentas da 1.71.0. `tests/medicao-1710-relatorio.php` reaproveita a regressão anterior com adaptação do harness. Evidências históricas não entram no total atual.

O histórico da 1.71.0 conserva o material de desenvolvimento recuperado; sua árvore de runtime não foi duplicada. Seu manifesto original descreve aquela entrega histórica. Scripts históricos podem depender de caminhos antigos; os comandos reproduzíveis desta rodada estão em `build/` e `tests/` na raiz.

## Dependências

Requisitos do plugin: **WordPress >= 7.1.4, PHP >= 8.3, 64 bits**. Ambiente efetivamente usado: WordPress **7.1.4**, PHP **8.4.27**, MariaDB **11.8.6**, Python **3.12.14**, Node **24.22.1** e npm **11.9.0**. PHP 8.3 e MySQL 8.4 não foram executados nesta rodada.

Para as ferramentas: Python 3.12+, Node 24, PHP com `mysqli`, `mbstring`, `curl` e extensões XML, MariaDB e seu inicializador, além do arquivo oficial `wordpress-7.1.4.tar.gz`. Use um ambiente local descartável.

```sh
python3 -m venv /tmp/core1721-tools
. /tmp/core1721-tools/bin/activate
python3 -m pip install -r build/requirements-1721.txt
npm ci --prefix build/node
npm ci --prefix tests/dom
```

Os lockfiles fixam Terser **5.44.1** e jsdom **27.4.0**; o requisito Python fixa rcssmin **1.2.2**. Dependências instaladas, WordPress, PHP/MariaDB e bancos do laboratório ficam fora do pacote.

## Reproduzir build e instalador

Execute na raiz do fonte:

```sh
F3BASE_PHP=/caminho/para/php python3 tests/verificar-entrega.py
python3 build/assets-1721.py
python3 build/reproduzir-instalador.py /tmp/base-site-core-fator3-1.72.1-instalador.zip
```

O primeiro comando confere os 935 arquivos e a sintaxe de 596 arquivos PHP. O segundo compila em diretório temporário e compara **84 arquivos JavaScript e `includes/ativos-build.php`**, incluindo o CSS minificado incorporado: **85 arquivos idênticos**, sem modificar o runtime. `--output /tmp/core1721-assets` conserva o resultado compilado. `web-vitals.js` é dependência vendorizada, verificada por hash; seu upstream não foi recompilado.

O terceiro comando reproduz o ZIP instalável com os metadados originais e exige o SHA-256 conhecido. O manifesto original de assets contém rótulos legados de gerador; a cadeia reproduzida nesta rodada consta em `assets-reproduzidos.json`.

## Executar os testes

```sh
node tests/cliente-1720.cjs
python3 tests/sonda-1720-http.py \
  --php /caminho/para/php \
  --wordpress /caminho/para/wordpress-7.1.4-extraido
python3 tests/run-native.py \
  --wordpress-archive /caminho/para/wordpress-7.1.4.tar.gz \
  --lab /tmp/core1721-laboratorio-novo \
  --php /caminho/para/php \
  --mysqld /usr/sbin/mariadbd \
  --db-install /usr/bin/mariadb-install-db \
  --db-basedir /usr
python3 build/resumir-evidencias.py
```

`--wordpress` aponta para a pasta que contém `wp-includes/`. O laboratório nativo exige `--lab` novo ou vazio, cria duas instalações isoladas, inicia MariaDB em loopback e encerra o processo no final. Em uma distribuição portátil, acrescente `--db-library-dir /caminho/das/bibliotecas`. Execute com usuário local apto a iniciar MariaDB; não use o banco de um site existente.

O harness exige WordPress `local` e banco `core_*` em `127.0.0.1`; o orquestrador fornece essas condições. Há operações de criação, alteração e remoção de tabelas sintéticas. HTTP e e-mail do WordPress são bloqueados pela fixture. Senhas e salts gerados permanecem no laboratório, fora do fonte.

Resultados: **395** verificações de cliente em jsdom, **68** de sonda HTTP e **154** em WordPress nativo, total **617**. As 596 verificações de sintaxe e os 85 arquivos reproduzidos são contagens separadas. A suíte cobre instalação limpa, atualização direta 1.72.0 → 1.72.1, preservação de 993 amostras sintéticas e de configuração, painel, migração aditiva, concorrência, documentação e reativação.

Desinstalação remove a tabela operacional de vitais conforme a política do plugin; a reativação a recria vazia. A preservação das 993 amostras refere-se à atualização direta.

## Empacotar o fonte e consultar a documentação

```sh
python3 build/empacotar-fonte.py /tmp/base-site-core-fator3-1.72.1-fonte.zip
```

O empacotador exclui dependências instaladas e caches, recusa links simbólicos e ZIPs internos, gera o manifesto e confere os runtimes. A cópia do relatório no fonte é anterior ao fechamento desse ZIP; o hash final consta no relatório externo canônico.

Índice operacional: `work/plugin/base-site-core-fator3/docs/DOCUMENTACAO.md`. A implantação no Site-Teste, a prova visual em navegador e a homologação com fornecedores continuam fora da validação desta reconstrução. Não houve instalação remota da 1.72.1 nesta rodada.
