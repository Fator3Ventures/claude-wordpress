<?php
/** Native forms for collection and independent reader grants. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\{Admin,Ads\PlannerAccess,Ads\Archive,Ads\ArchiveQuery,Integration\AdsServiceApi,Integration\QueryServiceApi,Settings,Response};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class ArchiveScreen {
    public static function init(): void { add_action('admin_post_f3_google_archive',[self::class,'handle']); }
    private static function form(string $op): void {
        Screen::form('f3_google_archive');
        echo '<input type="hidden" name="archive_operation" value="'.esc_attr($op).'">';
    }
    private static function account_field(string $account): void {
        echo '<input type="hidden" name="archive_target" value="'.esc_attr($account!==''?$account:'new').'">';
        echo '<label class="f3-field">Conta anunciante (10 dígitos) <input name="archive_account" value="'.esc_attr($account).'" inputmode="numeric" pattern="[0-9]{10}" maxlength="10" required'.($account!==''?' readonly':'').'></label>';
    }
    private static function datasets(array $selected): void {
        $labels=['clicks'=>'Cliques e GCLID','customer'=>'Totais da conta','campaign'=>'Campanhas','ad_group'=>'Grupos de anúncios','ad'=>'Anúncios','search_terms'=>'Termos de pesquisa','changes'=>'Histórico de alterações'];
        echo '<fieldset class="f3-datasets"><legend>Dados autorizados</legend>';
        foreach($labels as $id=>$label) {
            echo '<label><input type="checkbox" name="archive_datasets[]" value="'.esc_attr($id).'" '.checked(in_array($id,$selected,true),true,false).'> '.esc_html($label).'</label>';
        }
        echo '</fieldset>';
    }
    private static function enabled(string $label,bool $value=false): void {
        echo '<p><label><input type="checkbox" name="archive_enabled" value="1" '.checked($value,true,false).'> '.esc_html($label).'</label></p>';
    }
    private static function submit(string $label): void {
        echo '<p><button class="button button-primary">'.esc_html($label).'</button></p></form>';
    }
    private static function days(string $field,string $label,int $value,int $max,string $help): void {
        echo '<div class="f3-field"><label for="'.esc_attr($field).'">'.esc_html($label).'</label><input id="'.esc_attr($field).'" name="'.esc_attr($field).'" type="number" min="1" max="'.esc_attr((string)$max).'" value="'.esc_attr((string)$value).'" aria-describedby="'.esc_attr($field).'-help" required><p class="description" id="'.esc_attr($field).'-help">'.esc_html($help).'</p></div>';
    }
    private static function selector(array $accounts,string $selected): void {
        echo '<form class="f3-selector" method="get" action="'.esc_url(admin_url('tools.php')).'"><input type="hidden" name="page" value="'.esc_attr(Admin::SLUG).'"><input type="hidden" name="section" value="archive"><input type="hidden" name="connection_id" value="'.esc_attr(\Fator3\McpGoogle\Connections::id()).'"><label for="f3-archive-account">Conta para editar</label> <select id="f3-archive-account" name="archive_account"><option value="new" '.selected($selected,'new',false).'>Nova conta</option>';
        foreach($accounts as $id=>$account) {
            echo '<option value="'.esc_attr((string)$id).'" '.selected($selected,(string)$id,false).'>'.esc_html($id.(!empty($account['enabled'])?' · Coleta habilitada':' · Coleta pausada')).'</option>';
        }
        echo '</select> <button class="button">Abrir conta</button></form>';
    }
    public static function render(): void {
        $status=Archive::status();
        $readers=AdsServiceApi::status();
        $accounts=array_column($status['accounts']??[],null,'account_id');
        // Reader grants may outlive a collector or be configured before collection.
        foreach($readers['consumers'] as $consumer) {
            foreach($consumer['grants'] as $grant) { $accounts[$grant['account_id']] ??= ['account_id'=>$grant['account_id']]; }
        }
        $raw=$_GET['archive_account']??null;
        $selected=$raw===null?(string)(array_key_first($accounts)??'new'):(is_string($raw)?wp_unslash($raw):'');
        $is_new=$selected==='new';
        echo '<section class="f3-card"><h2>Acervo Google Ads</h2><p>Escolha a conta para consultar ou editar a coleta diária e os leitores autorizados. Os dados coletados ficam cifrados neste WordPress.</p>';
        if (empty($status['success']) || !empty($readers['grants_error'])) {
            echo '<div class="notice notice-error inline" role="alert"><p>Falha ao ler a configuração do acervo. Confira o armazenamento em Diagnóstico antes de editar.</p></div></section>';
            return;
        }
        self::selector($accounts,$selected);
        if (!$is_new && !isset($accounts[$selected])) {
            echo '<p role="alert">Esta conta não está cadastrada nesta conexão. Selecione uma das opções acima.</p></section>';
            return;
        }
        $account=$is_new?'':$selected;
        $cfg=$accounts[$selected]??[];
        echo '</section><section class="f3-card" id="f3-ads-archive"><h2>Coleta diária</h2><p>Marque os conjuntos de dados e defina a janela de recuperação. Desmarcar a autorização pausa a coleta e conserva o histórico.</p>';
        if (!empty($cfg['reason_code'])) { echo '<p>Estado da coleta: <code>'.esc_html($cfg['reason_code']).'</code></p>'; }
        self::form('collection');
        self::account_field($account);
        self::datasets($cfg['datasets']??ArchiveQuery::DATASETS);
        echo '<div class="f3-pair">';
        self::days('archive_backfill','Histórico a recuperar (dias)',(int)($cfg['backfill_days']??90),1125,'De 1 a 1125 dias, sujeito ao histórico disponível no Google.');
        self::days('archive_revisit','Dias recentes a revisitar',(int)($cfg['revisit_days']??7),30,'De 1 a 30 dias. Uma nova coleta atualiza os dias selecionados.');
        echo '</div>';
        self::enabled('Autorizar coleta diária desta conta',!empty($cfg['enabled']));
        self::submit('Salvar coleta');
        echo '</section><section class="f3-card"><h2>Leitores do acervo</h2><p>Escolha quais dados cada plugin pode consultar para esta conta. Cada permissão é salva separadamente.</p>';
        if (!$readers['consumers']) { echo '<p>Nenhum consumidor de acervo Ads registrado nesta instalação.</p>'; }
        foreach($readers['consumers'] as $consumer) {
            $grants=array_column($consumer['grants'],null,'account_id');
            $grant=$grants[$account]??[];
            echo '<h3>'.esc_html($consumer['id']).'</h3>';
            self::form('reader');
            echo '<input type="hidden" name="archive_consumer" value="'.esc_attr($consumer['id']).'">';
            self::account_field($account);
            self::datasets($grant['datasets']??[]);
            self::enabled('Permitir leitura local',!empty($grant['enabled']));
            self::submit('Salvar permissão do leitor');
        }
        echo '</section>';
        $planning=PlannerAccess::status();
        $labels=['unknown'=>'Não informado','test'=>'Test','explorer'=>'Explorer','basic'=>'Basic','standard'=>'Standard'];
        echo '<section class="f3-card"><h2>Planejador de palavras-chave</h2><p>O planejador usa a identidade e o nível de acesso desta conexão. Seu histórico é separado da coleta diária.</p><dl class="f3-definition"><dt>Nível declarado</dt><dd>'.esc_html($labels[$planning['level']]).'</dd><dt>Operações Ads observadas neste site nas últimas 24 horas</dt><dd>'.esc_html((string)($planning['operations_last_24h']??'Indisponível')).'</dd></dl><p><a href="'.esc_url(Admin::url('','services')).'">Abrir configurações de acesso ao Google Ads</a></p></section>';
    }
    public static function gsc(): void {
        echo '<section class="f3-card" id="f3-gsc-query-reader"><h2>Leitura de consultas, páginas e dias</h2><p>Autorize separadamente os consumidores que precisam das consultas de busca. Consultas anonimizadas são omitidas pelo Google; diferenças nos totais também podem decorrer dos limites da API.</p>';
        $consumers=QueryServiceApi::status()['consumers'];if(!$consumers)echo '<p>Nenhum consumidor compatível registrado.</p>';
        foreach($consumers as $c){echo '<p><strong>'.esc_html($c['id']).'</strong> · '.esc_html($c['configuration']['property']??'Propriedade pendente').'</p>';self::form('gsc');echo '<input type="hidden" name="archive_consumer" value="'.esc_attr($c['id']).'">';self::enabled('Permitir consultas por página e dia',!empty($c['grant']['enabled']));self::submit('Salvar permissão de consultas');}
        echo '</section>';
    }
    private static function check_target(string $account,string $target): ?\WP_Error {
        if (!preg_match('/^[0-9]{10}$/D',$account)) {
            return new \WP_Error('f3_google_archive_form_account','Informe o ID de dez dígitos da conta anunciante.');
        }
        if ($target===$account) { return null; }
        if ($target!=='new') {
            return new \WP_Error('f3_google_archive_form_target','A conta do formulário mudou. Abra a conta correta antes de salvar.');
        }
        $config=Archive::config();$grants=AdsServiceApi::grants();
        if (is_wp_error($config)) { return $config; }
        if (is_wp_error($grants)) { return $grants; }
        if (isset($config[$account]) || in_array($account,array_column($grants,'account_id'),true)) {
            return new \WP_Error('f3_google_archive_form_exists','Esta conta já tem configuração. Abra a conta existente para editar os valores salvos.');
        }
        return null;
    }
    public static function handle(): void {
        Admin::guard('f3_google_archive');$op=Admin::posted('archive_operation');$i=['account_id'=>Admin::posted('archive_account'),'enabled'=>Admin::posted('archive_enabled')==='1','expected_revision'=>Admin::posted_revision()];
        if (in_array($op,['collection','reader'],true) && ($error=self::check_target($i['account_id'],Admin::posted('archive_target')))) {
            Admin::require_saved(Response::fail($error));
            return;
        }
        // Structured allowlist is validated again by the same service used by MCP.
        $i['datasets']=isset($_POST['archive_datasets'])&&is_array($_POST['archive_datasets'])?array_values(wp_unslash($_POST['archive_datasets'])):[];
        if($op==='collection'){$i['backfill_days']=(int)Admin::posted('archive_backfill');$i['revisit_days']=(int)Admin::posted('archive_revisit');$r=Archive::configure($i);}
        elseif($op==='reader'){$i['consumer_id']=Admin::posted('archive_consumer');$r=AdsServiceApi::configure($i);}
        elseif($op==='gsc')$r=QueryServiceApi::configure(['contract'=>QueryServiceApi::CONTRACT,'consumer_id'=>Admin::posted('archive_consumer'),'enabled'=>$i['enabled'],'expected_revision'=>$i['expected_revision']]);
        else $r=Response::fail(new \WP_Error('f3_google_archive_operation','Operação inválida.'));
        Admin::require_saved($r);$url=Admin::url('saved',$op==='gsc'?'gsc':'archive');
        if ($op!=='gsc') { $url=add_query_arg('archive_account',$i['account_id'],$url); }
        wp_safe_redirect($url);exit;
    }
}
