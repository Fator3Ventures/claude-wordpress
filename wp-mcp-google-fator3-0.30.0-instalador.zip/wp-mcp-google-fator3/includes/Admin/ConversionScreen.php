<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\{ConversionDelivery as Delivery,StageConversionDelivery as Stage,Connections,Options,Admin,Response,Automation\Execution,RenewalNotifications as Notices};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class ConversionScreen {
    public static function render(): void {
        if (!Options::authorized()) wp_die('Permissão insuficiente.');
        OperationsScreen::render(true);
        $s=Delivery::status();$c=$s['config']??Delivery::defaults();$property=explode('/',$c['stream'])[1]??'';$result=null;
        if (($_SERVER['REQUEST_METHOD']??'GET')==='POST') {
            check_admin_referer('f3-google-conversions');
            $kind=Admin::posted('action_kind');
            if (Admin::posted('connection_id') !== Connections::id()) {
                $result=Response::fail(new \WP_Error('f3_google_form_connection','A conexão do formulário mudou. Reabra a aba Conversões.'));
            } else {
                $result=self::submit($kind,$c,$property);
            }
            $s=Delivery::status();if (!in_array($kind,['resources','resources-ga','resources-ads'],true)) $c=$s['config']??$c;
        }
        if ($result) echo '<div class="notice '.(!empty($result['success'])?'notice-success':'notice-warning').'"><p>'.esc_html(!empty($result['success'])?(!empty($result['dry_run'])?'Simulação pronta; confira o prazo antes de aplicar.':(($result['message']??'')?:'Operação concluída.')):($result['message']??'Operação não concluída. Confira o acesso e as seleções.')).'</p>'.self::diagnostic($result['provider_error']??null).'</div>';
        self::readiness_card();
        echo '<section class="f3-card"><h2>Entrega de conversões</h2><p>Autorize os destinos, verifique o acesso e selecione o transporte pelo servidor no Site Core.</p><div class="f3-table-wrap" tabindex="0" role="region" aria-label="Estado dos destinos de conversão"><table class="widefat striped"><thead><tr><th>Destino</th><th>Prontidão</th><th>Última verificação</th><th>Próxima renovação</th></tr></thead><tbody>';
        $reasons=['ok'=>'Pronto','integration_disabled'=>'Integração desabilitada','channel_disabled'=>'Ative o canal na aba Conexão','destination_missing'=>'Selecione um destino; configure a medição no Site Core','verification_required'=>'Verifique o destino','core_async_unsupported'=>'Instale a atualização do Core com consulta de confirmação Ads','grant_revoked'=>'Renove a autorização administrativa','mp_secret_missing'=>'Informe o segredo do fluxo de dados','service_disabled'=>'Habilite o serviço na aba Conexão','service_read_only'=>'Autorize escrita na aba Conexão','ads_developer_token_missing'=>'Informe o token de desenvolvedor na aba Conexão','resource_not_permitted'=>'Revise as permissões por recurso','ambiguous_connection'=>'Mantenha uma única conexão habilitada por destino'];
        foreach(['ga4'=>'Google Analytics','google_ads'=>'Google Ads'] as $target=>$label) {
            $v=$s[$target]??[];$renew=$v['renewal']??[];
            echo '<tr><td>'.esc_html($label).'</td><td>'.esc_html(!empty($v['verification_pending'])?(!empty($v['ready'])?'Pronto; nova validação agendada':'Aguardando nova validação automática'):($reasons[$v['reason']??'']??'Confira a conexão e as credenciais')).'</td><td>'.esc_html(!empty($v['verified_at'])?wp_date('d/m/Y H:i',$v['verified_at']):'Ainda não verificado').'</td><td>'.esc_html(!empty($renew['next_attempt'])?wp_date('d/m/Y H:i',$renew['next_attempt']):'Após a primeira verificação').'</td></tr>';
        }
        echo '</tbody></table></div><p>O cron renova a verificação antes de vencer. Falhas ficam na aba Incidentes. O aviso por e-mail aguarda as retentativas ou o prazo de vencimento configurado abaixo.</p></section><section class="f3-card"><h2>Destinos</h2><p><strong>ID de medição GA4:</strong> '.esc_html(Delivery::measurement_id()?:'Configure no Site Core').'. Lido do Site Core.</p><form method="post" class="f3-form">';
        self::hidden($s['revision']??'');
        echo '<p><label><input type="checkbox" name="enabled" '.checked(!empty($c['enabled']),true,false).'> Autorizar entregas pelo Core nesta conexão</label></p>';
        echo '<div class="f3-pair f3-destinations"><fieldset><legend>Google Analytics 4</legend>';
        ResourceChoices::select('property_id','Propriedade GA4',$property,ResourceChoices::items('ga'),'Escolha a propriedade para listar seus fluxos de dados.');
        ResourceChoices::select('stream','Fluxo de dados',$c['stream'],ResourceChoices::items('stream','properties/'.$property),'O fluxo recebe os eventos de conversão do Site Core.');
        echo '<button class="button" name="action_kind" value="resources-ga">Consultar propriedades e fluxos</button>';
        echo '<div class="f3-field"><label for="mp_secret">Segredo da API do fluxo</label><input id="mp_secret" name="mp_secret" type="password" autocomplete="new-password" aria-describedby="mp-secret-help"><p class="description" id="mp-secret-help">Estado: '.(!empty($s['mp_secret_present'])?'presente':'ausente').'. Deixe vazio para manter o segredo salvo. Digite um novo segredo somente ao salvar os destinos.</p></div>';
        echo '<label><input type="checkbox" name="clear_mp_secret"> Remover o segredo salvo</label></fieldset><fieldset><legend>Google Ads</legend>';
        ResourceChoices::select('customer_id','Conta anunciante',$c['customer_id'],ResourceChoices::items('ads'),'Escolha a conta antes de consultar as ações disponíveis.');
        ResourceChoices::select('conversion_action','Ação de conversão importada',$c['conversion_action'],ResourceChoices::items('action',$c['customer_id']),'Selecione uma ação ativa de importação de cliques. O valor e a moeda vêm da ação.');
        echo '<button class="button" name="action_kind" value="resources-ads">Consultar contas e ações</button></fieldset></div>';
        echo '<p class="description">Consultar listas atualiza as opções disponíveis. Use Salvar destinos e autorização para gravar a seleção dos dois destinos.</p><p><button class="button button-primary" name="action_kind" value="configure">Salvar destinos e autorização</button></p></form></section><section class="f3-card"><h2>Verificar acesso</h2><p>Selecione o destino para validar a configuração usando um evento de teste. Repita a verificação após alterar o destino, a credencial, o segredo ou a autorização.</p><form method="post" class="f3-form">';
        self::hidden($s['revision']??'');
        echo '<input type="hidden" name="action_kind" value="verify"><label for="f3-verify-target">Destino</label> <select id="f3-verify-target" name="target"><option value="ga4">Google Analytics</option><option value="google_ads">Google Ads</option></select> <button class="button">Verificar destino</button></form></section>';
        self::renewal_settings($result);
        self::stages();
        OperationsScreen::profiles();
    }
    private static function submit(string $kind,array &$config,string &$property): array {
        switch ($kind) {
            case 'renewal-preview':
            case 'renewal-apply':
                $raw=Admin::posted('expiry_warning_hours');
                $input=['configuration'=>['expiry_warning_hours'=>ctype_digit($raw)?(int)$raw:-1]];
                return $kind==='renewal-preview' ? Notices::plan($input) : Notices::configure($input+['expected_revision'=>Admin::posted('revision'),'expected_plan_hash'=>Admin::posted('plan_hash')]);
            case 'stage-grant':
                return Stage::configure(['expected_revision'=>Admin::posted('revision'),'action'=>Admin::posted('stage_action'),'enabled'=>isset($_POST['stage_enabled']),'renew_grant'=>isset($_POST['stage_renew_grant'])]);
            case 'stage-verify':
                return Stage::verify(['expected_revision'=>Admin::posted('revision'),'action'=>Admin::posted('stage_action')]);
            case 'verify':
                return Delivery::verify(['expected_revision'=>Admin::posted('revision'),'target'=>Admin::posted('target')]);
            case 'resources':
            case 'resources-ga':
            case 'resources-ads':
                foreach (['stream','customer_id','conversion_action'] as $field) { $config[$field]=Admin::posted($field); }
                $config['enabled']=isset($_POST['enabled']);
                $property=Admin::posted('property_id');
                return self::lists($kind,$config,$property);
            case 'configure':
                $values=['enabled'=>isset($_POST['enabled'])];
                foreach (['stream','customer_id','conversion_action'] as $field) { $values[$field]=Admin::posted($field); }
                return Delivery::configure(['expected_revision'=>Admin::posted('revision'),'config'=>$values,'mp_secret'=>wp_unslash($_POST['mp_secret']??''),'clear_mp_secret'=>isset($_POST['clear_mp_secret'])]);
            default:
                return Response::fail(new \WP_Error('f3_google_form_action','Ação de conversão desconhecida. Reabra a tela e escolha uma ação.'));
        }
    }

    private static function lists(string $kind,array $config,string $property): array {
        $sources=[];
        if ($kind!=='resources-ads') {
            $sources['ga']='';
            if ($property!=='') { $sources['stream']='properties/'.$property; }
        }
        if ($kind!=='resources-ga') {
            $sources['ads']='';
            if ($config['customer_id']!=='') { $sources['action']=$config['customer_id']; }
        }
        return Execution::run(static function() use($sources) {
            $errors=[];
            foreach ($sources as $source=>$parent) {
                $result=ResourceChoices::load($source,$parent);
                if (empty($result['success']) || empty($result['complete'])) {
                    $errors[]=$result['message']??'Lista incompleta. Consulte novamente.';
                }
            }
            return $errors ? Response::fail(new \WP_Error('f3_google_resource_list',implode(' ',array_unique($errors)))) : Response::ok([],'Lista atualizada. Confira a seleção antes de salvar.');
        });
    }
    private static function renewal_settings(?array $result): void {
        $config=Notices::config();
        if (is_wp_error($config)) { echo '<p>'.esc_html($config->get_error_message()).'</p>'; return; }
        echo '<section class="f3-card" id="f3-renewal-notices"><h2>Avisos da renovação</h2><p>O incidente aparece na primeira falha. O e-mail administrativo sai após cinco retentativas sem sucesso ou quando a prova chega ao prazo abaixo. As tentativas horárias continuam. A recuperação só avisa se o e-mail de atenção foi aceito pelo serviço de e-mail.</p><form method="post" class="f3-form">';
        self::hidden('');
        echo '<label for="f3-renewal-hours">Avisar quantas horas antes do vencimento?</label><input id="f3-renewal-hours" name="expiry_warning_hours" type="number" min="0" max="24" step="1" value="'.esc_attr((string)$config['expiry_warning_hours']).'" required><p>De 0 a 24 horas; zero avisa no vencimento. Padrão: 6 horas. A simulação e a aplicação não enviam e-mail.</p><button class="button" name="action_kind" value="renewal-preview">Simular alteração</button></form>';
        if (!empty($result['success']) && !empty($result['dry_run']) && isset($result['plan_hash'],$result['configuration']['expiry_warning_hours'])) {
            $hours=$result['configuration']['expiry_warning_hours'];
            echo '<p>Prazo atual: '.esc_html((string)$result['before']['expiry_warning_hours']).' h. Prazo proposto: '.esc_html((string)$hours).' h. Provas e destinos permanecem iguais.</p><form method="post">';
            self::hidden($result['configuration_revision']);
            echo '<input type="hidden" name="expiry_warning_hours" value="'.esc_attr((string)$hours).'"><input type="hidden" name="plan_hash" value="'.esc_attr($result['plan_hash']).'"><button class="button button-primary" name="action_kind" value="renewal-apply">Aplicar prazo simulado</button></form>';
        }
        echo '</section>';
    }
    private static function stages(): void {
        $status=Stage::status();
        echo '<section class="f3-card" id="f3-commercial-actions"><h2>Ações comerciais por etapa</h2><p>Autorize cada ação do Site Core separadamente. Use uma ação exclusiva por etapa; a ação de aquisição não pode ser reutilizada. O envio comercial usa valor zero em BRL.</p><div class="f3-table-wrap" tabindex="0" role="region" aria-label="Estado das ações comerciais por etapa"><table class="widefat striped"><thead><tr><th>Ação</th><th>Prontidão</th><th>Motivo</th></tr></thead><tbody>';
        foreach((array)($status['actions']??[]) as $action=>$cap){$entry=$cap['actions'][$action]??[];echo '<tr><td>'.esc_html($action).'</td><td>'.esc_html(!empty($entry['ready'])?'Pronta':'Bloqueada').'</td><td>'.esc_html($entry['reason']??'indisponível').'</td></tr>';}
        echo '</tbody></table></div><form method="post" class="f3-form">';self::hidden($status['revision']??'');
        echo '<p><label for="f3-stage-action">Recurso completo da ação Google Ads</label><input id="f3-stage-action" name="stage_action" type="text" maxlength="120" placeholder="customers/1234567890/conversionActions/222" required></p><p><label><input name="stage_enabled" type="checkbox"> Autorizar esta ação para etapas comerciais do Site Core</label></p><p><label><input name="stage_renew_grant" type="checkbox"> Renovar a concessão e invalidar referências anteriores</label></p><button class="button" name="action_kind" value="stage-grant">Salvar concessão</button> <button class="button" name="action_kind" value="stage-verify">Verificar ação</button></form><p>Salvar sem autorização marcada revoga a ação. Verificar consulta a conta e valida o destino sem coletar conversões. As provas são renovadas pelo executor; resultados de envio incertos exigem consulta do recibo, sem reenvio. Consulte o guia desta versão para configuração e reconciliação.</p></section>';
    }
    public static function diagnostic($diagnostic): string {
        if (!is_array($diagnostic)) return '';
        $items=[];
        foreach (['http_status'=>'HTTP','status'=>'Estado Google','reason'=>'Motivo','message'=>'Mensagem Google'] as $key=>$label)
            if (!empty($diagnostic[$key])) $items[]=$label.': '.$diagnostic[$key];
        foreach ($diagnostic['field_violations']??[] as $v) $items[]='Campo: '.($v['field']??'').' · '.($v['reason']??'').' · '.($v['message']??'');
        return '<ul class="f3-provider-diagnostic"><li>'.implode('</li><li>',array_map('esc_html',$items)).'</li></ul>';
    }
    private static function hidden(string $revision): void {
        echo '<input type="hidden" name="_wpnonce" value="'.esc_attr(wp_create_nonce('f3-google-conversions')).'">';
        echo '<input type="hidden" name="connection_id" value="'.esc_attr(Connections::id()).'"><input type="hidden" name="revision" value="'.esc_attr($revision).'">';
    }
    /** Local verdict of google/readiness-status at the top of the screen (0.18.0). */
    private static function readiness_card(): void {
        $r=\Fator3\McpGoogle\Readiness::read([]);
        if (empty($r['success'])) return;
        $names=['ready'=>'Pronta','attention'=>'Requer atenção','blocked'=>'Bloqueada'];
        echo '<section class="f3-card" id="f3-readiness" data-state="'.esc_attr($r['state']).'"><h2>Prontidão operacional</h2><p><strong>'.esc_html($names[$r['state']]??$r['state']).'</strong>. Leitura local da conexão, sem consulta ao Google.</p>';
        if (!empty($r['actions'])) {
            echo '<ol>';
            foreach ($r['actions'] as $action) echo '<li>'.esc_html($action).'</li>';
            echo '</ol>';
        }
        echo '<p class="description">A mesma leitura está em google/readiness-status.</p></section>';
    }
}
