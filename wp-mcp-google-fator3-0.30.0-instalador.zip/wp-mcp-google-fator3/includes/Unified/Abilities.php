<?php
/**
 * As cinco rotas `google/*`.
 *
 * Elas registram com o conector `'any'` porque a escolha entre Analytics e Ads
 * só acontece em tempo de execução, pelo parâmetro `connector`: uma rota que se
 * amarrasse a um conector no registro sumiria da lista quando o outro estivesse
 * ligado. O portão específico (`Gate::check( 'ga' )` ou `Gate::check( 'ads' )`)
 * é aplicado dentro da implementação, depois de saber qual conector foi pedido.
 *
 * As descrições seguem uma regra: a da habilidade é curta (é ela que aparece na
 * lista de ferramentas de todo cliente MCP, e vinte rotas com um parágrafo cada
 * consomem a janela de contexto antes da primeira pergunta); as listas longas —
 * presets de data, operadores, catálogo de campos — ficam nas descrições das
 * propriedades do `input_schema`, que o cliente só lê quando vai chamar a rota.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Unified;
use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Crypto;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Plugin;
use Fator3\McpGoogle\Response;
use Fator3\McpGoogle\SelfTest;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Abilities {
    public static function register(): void {
        self::register_status();
        self::register_selftest();
        self::register_list_accounts();
        self::register_list_fields();
        self::register_query();
    }
    // =========================================================================
    // google/status
    // =========================================================================
    private static function register_status(): void {
        Ability::register(
            'google/status',
            'any',
            array(
                'label' => __( 'Google: estado da configuração', 'wp-mcp-google-fator3' ),
                'description' => __( 'Diagnóstico da integração Google: canal aberto, conectores ligados, modo de autenticação e identidade da credencial, versão da Ads API, limites e rotas registradas. Nunca devolve segredo. Substitui whoami e list_connectors.', 'wp-mcp-google-fator3' ),
                'input_schema' => array(
                    'properties' => array(
                        'compact'=>['type'=>'boolean','default'=>false,'description'=>'Resumo de configuração e prontidão; não consulta Google salvo live:true.'],
                        'scope' => array(
                            'type' => 'string',
                            'enum' => array( 'selected', 'all_connections' ),
                            'default' => 'selected',
                            'description' => 'all_connections retorna resumo local das conexões, sem consultas externas.',
                        ),
                        'live' => array(
                            'type' => 'boolean',
                            'description' => __( 'Quando true, também pede um access token de verdade a cada conector ligado e informa se ele veio (token_ok). O token em si nunca é devolvido. Padrão: false.', 'wp-mcp-google-fator3' ),
                        ),
                    ),
                ),
                'output_schema' => StatusSchema::schema(),
                'callback' => static function ( array $input ): array {
            return self::status( $input );
                },
            )
        );
    }
    /**
	 * @param array $input 'live' => bool.
	 */
    public static function status( array $input ): array {
        if ( 'all_connections' === ( $input['scope'] ?? 'selected' ) ) {
            if ( ! empty( $input['live'] ) ) {
                return Response::fail( new \WP_Error( 'f3_google_status_scope', 'O resumo de todas as conexões aceita somente observações locais. Use live na conexão selecionada.' ) );
            }
            $connections = array();
            foreach ( \Fator3\McpGoogle\Connections::registry() as $id => $meta ) {
                $connections[] = \Fator3\McpGoogle\Connections::run(
                    $id,
                    static function () use ( $meta,$input ): array {
                    $status = self::status( array('compact'=>!empty($input['compact'])) );
                    return array_intersect_key( $status, array_flip( array( 'conversion_delivery', 'connection_id', 'ads_planning_access', 'auth', 'api_status', 'cron', 'integration', 'recovery', 'telemetry', 'quota_observations', 'inspection_budget', 'last_http', 'incidents' ) ) ) + array(
                        'label' => $meta['label'],
                        'services' => Options::get( \Fator3\McpGoogle\Connections::SERVICES, null ),
                        'bindings' => Options::get( \Fator3\McpGoogle\Connections::BINDINGS, array() ),
                    );
                    }
                );
            }
            return Response::ok(
                array(
                    'scope' => 'all_connections',
                    'site' => array(
                        'url' => home_url(),
                        'plugin_version' => F3_MCP_GOOGLE_VERSION,
                    ),
                    'connections' => $connections,
                    'google_checks_performed' => false,
                )
            );
        }
        $credentials = Credentials::current();
        if (!empty($input['compact'])) {
            $data=['ads_planning_access'=>\Fator3\McpGoogle\Ads\PlannerAccess::status(),'compact'=>true,'scope'=>'selected','plugin_version'=>F3_MCP_GOOGLE_VERSION,
                'connection_id'=>\Fator3\McpGoogle\Connections::id(),'enabled'=>Options::is_enabled(),
                'ga_enabled'=>Options::ga_enabled(),'ads_enabled'=>Options::ads_enabled(),
                'auth'=>is_wp_error($credentials)?['mode'=>Options::auth_mode(),'configured'=>false,'error_code'=>$credentials->get_error_code()]:$credentials->describe(),
                'conversion_delivery'=>\Fator3\McpGoogle\ConversionDelivery::status_compact(),
                'google_checks_performed'=>!empty($input['live'])];
            if(!empty($input['live']))$data['token_ok']=self::token_probe($credentials);
            return Response::ok($data);
        }
        $data = array(
            'scope'=>'selected',
            'conversion_delivery'=>\Fator3\McpGoogle\ConversionDelivery::status(),
            'enabled' => Options::is_enabled(),
            'ga_enabled' => Options::ga_enabled(),
            'ads_enabled' => Options::ads_enabled(),
            'auth' => is_wp_error( $credentials )
            ? array(
                'mode' => Options::auth_mode(),
                'configured' => false,
                'reason' => $credentials->get_error_message(),
                'error_code' => $credentials->get_error_code(),
            )
            : $credentials->describe(),
            'crypto_backend' => Crypto::backend(),
            'ads_planning_access' => \Fator3\McpGoogle\Ads\PlannerAccess::status(),
            'ads_api_version' => Options::ads_api_version(),
            'ads_developer_token_configured' => Options::has_secret( Options::ADS_DEVELOPER_TOKEN ),
            'ads_login_customer_id' => self::mask_customer_id( Options::ads_login_customer_id() ),
            'api_status' => \Fator3\McpGoogle\Http\GoogleClient::api_status(),
            'scopes_requested' => Credentials::scopes_for( 'any' ),
            'scopes_granted' => 'oauth' === Options::auth_mode() ? Options::get( Options::OAUTH_SCOPES, array() ) : null,
            'scopes_note' => 'OAuth: escopos registrados na última autorização, sujeitos a revogação. Service account: escopos solicitados por método; acesso efetivo depende dos papéis. APIs sem chamada observada aparecem com enabled=null.',
            'ga_default_property' => (string) Options::get( Options::GA_DEFAULT_PROPERTY, '' ),
            'max_rows' => Options::max_rows(),
            'abilities_registered' => self::count_abilities(),
            'mcp_server_detected' => Plugin::mcp_server_detected(),
            'wordpress_version' => (string) get_bloginfo( 'version' ),
            'site_url' => home_url(),
            'integration' => \Fator3\McpGoogle\Integration\ServiceApi::status(),
            'recovery' => \Fator3\McpGoogle\Recovery::status(),
            'mcp_server' => Plugin::mcp_status(),
            'cron' => \Fator3\McpGoogle\Automation\Executor::status(),
            'telemetry' => \Fator3\McpGoogle\Telemetry::state(),
            'quota_observations' => \Fator3\McpGoogle\Telemetry::quotas(),
            'inspection_budget' => \Fator3\McpGoogle\SearchConsole\Quota::state(),
            'incidents' => \Fator3\McpGoogle\Automation\Alerts::state()['incidents'],
            'audit_health' => \Fator3\McpGoogle\Audit::health(),
            'storage' => \Fator3\McpGoogle\Storage\State::status(),
            'maintenance' => \Fator3\McpGoogle\Storage\Maintenance::status(),
            'cache' => \Fator3\McpGoogle\Cache::status(),
            'connection_id' => \Fator3\McpGoogle\Connections::id(),
            'last_http' => self::last_http(),
            'plugin_version' => defined( 'F3_MCP_GOOGLE_VERSION' ) ? F3_MCP_GOOGLE_VERSION : '',
        );
        if ( ! empty( $input['live'] ) ) {
            $data['token_ok'] = self::token_probe( $credentials );
        }
        return Response::ok( $data, __( 'Estado da integração Google.', 'wp-mcp-google-fator3' ) );
    }
    private static function last_http() {
        $value = \Fator3\McpGoogle\Cache::get( 'f3_mcp_google_http_' . \Fator3\McpGoogle\Connections::id() );
        return $value ? $value : null;
    }
    /**
	 * Pede um token por conector ligado, sem nunca devolvê-lo.
	 *
	 * @param mixed $credentials CredentialsInterface ou WP_Error.
	 * @return array<string,mixed>
	 */
    private static function token_probe( $credentials ): array {
        $out = array();
        foreach ( array(
                'ga' => Options::ga_enabled(),
                'ads' => Options::ads_enabled(),
                'gsc' => true,
                'siteverification' => true,
                'sheets' => true,
                'drive' => true,
            ) as $connector => $on ) {
            if ( ! $on ) {
                continue;
            }
            if ( is_wp_error( $credentials ) ) {
                $out[ $connector ] = false;
                continue;
            }
            $token = $credentials->get_access_token( Credentials::scopes_for( $connector ) );
            // Só o veredito: o comprimento do token já seria informação a mais
            // sobre a credencial num transcript de conversa.
            $out[ $connector ] = ! is_wp_error( $token ) && is_string( $token ) && '' !== $token;
        }
        return $out;
    }
    /**
	 * `1234567890` vira `123-***-7890`.
	 *
	 * O ID da gerenciadora não é segredo, mas também não precisa sair inteiro
	 * de um site para uma conversa; o suficiente para conferir se é o certo.
	 */
    private static function mask_customer_id( string $id ): string {
        if ( 10 !== strlen( $id ) ) {
            return '' === $id ? '' : '***';
        }
        return substr( $id, 0, 3 ) . '-***-' . substr( $id, -4 );
    }
    /**
	 * Quantas rotas deste plugin estão registradas, por família.
	 *
	 * @return array<string,int>
	 */
    private static function count_abilities(): array {
        return \Fator3\McpGoogle\Catalog::counts();
    }
    // =========================================================================
    // google/selftest
    // =========================================================================
    private static function register_selftest(): void {
        Ability::register(
            'google/selftest',
            'any',
            array(
                'label' => __( 'Google: autoteste', 'wp-mcp-google-fator3' ),
                'description' => __( 'Verifica cifra, JWT, configuração e consultas localmente. live:true acrescenta leituras Google. Distingue passed, incomplete, failed e execution_error; conta e nomeia pendências. success:true sem reprovação não garante aprovação integral: confira complete e all_checks_passed.', 'wp-mcp-google-fator3' ),
                'output_schema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'success' => array( 'type' => 'boolean', 'description' => 'Diagnóstico executado sem reprovação. Configuração incompleta pode retornar true; não autoriza acesso.' ),
                        'message' => array( 'type' => 'string' ),
                        'execution_success' => array( 'type' => 'boolean', 'description' => 'A execução do diagnóstico terminou; não significa aprovação.' ),
                        'result_status' => array( 'type' => 'string', 'enum' => array( 'passed', 'incomplete', 'failed', 'execution_error' ) ),
                        'error_code' => array( 'type' => 'string', 'description' => 'Presente somente em reprovação ou erro. Ausente no diagnóstico incompleto sem falhas.' ),
                        'scope' => array( 'type' => 'string', 'enum' => array( 'local', 'local_and_google' ) ),
                        'checks_passed' => array( 'type' => 'boolean', 'description' => 'Zero reprovadas e zero não configuradas; não exige zero puladas.' ),
                        'all_checks_passed' => array( 'type' => 'boolean', 'description' => 'Todas aprovadas, sem puladas ou não configuradas.' ),
                        'complete' => array( 'type' => 'boolean', 'description' => 'Cobertura completa das checagens; pode ser true com reprovação.' ),
                        'passed' => array( 'type' => 'integer', 'minimum' => 0 ),
                        'failed' => array( 'type' => 'integer', 'minimum' => 0 ),
                        'skipped' => array( 'type' => 'integer', 'minimum' => 0 ),
                        'not_configured' => array( 'type' => 'integer', 'minimum' => 0 ),
                        'checks' => array(
                            'type' => 'array',
                            'items' => array( 'type' => 'object', 'properties' => array(
                                    'name' => array( 'type' => 'string' ),
                                    'status' => array( 'type' => 'string', 'enum' => array( 'passed', 'failed', 'skipped', 'not_configured' ) ),
                                    'ok' => array( 'type' => 'boolean' ),
                                    'detail' => array( 'type' => 'string' ),
                                ) ),
                        ),
                    ),
                ),
                'input_schema' => array(
                    'properties' => array(
                        'live' => array(
                            'type' => 'boolean',
                            'description' => __( 'Quando true, acrescenta as checagens que saem para a rede: leituras reais dos serviços habilitados e dos recursos configurados. Padrão: false.', 'wp-mcp-google-fator3' ),
                        ),
                    ),
                ),
                'callback' => static fn ( array $input ): array => SelfTest::run( array( 'live' => ! empty( $input['live'] ) ) ),
            )
        );
    }
    // =========================================================================
    // google/list-accounts
    // =========================================================================
    private static function register_list_accounts(): void {
        Ability::register(
            'google/list-accounts',
            'any',
            array(
                'label' => __( 'Google: listar contas', 'wp-mcp-google-fator3' ),
                'description' => __( 'Lista, num formato só, as propriedades do GA4 e as contas do Google Ads que a credencial alcança. Use os account_id devolvidos em google/query. Cache de 10 minutos. Substitui o list_accounts do Porter.', 'wp-mcp-google-fator3' ),
                'input_schema' => array(
                    'properties' => array(
                        'connector' => array(
                            'type' => 'string',
                            'enum' => array( 'ga4', 'google-ads', 'search-console', 'ga', 'ads', 'gsc', 'all' ),
                            'description' => __( 'Qual conector listar. Padrão: all (os dois). Um conector desligado ou sem credencial não derruba a chamada: os outros vêm e o motivo entra em warnings.', 'wp-mcp-google-fator3' ),
                        ),
                        'query' => array(
                            'type' => 'string',
                            'description' => __( 'Filtra por trecho do nome, do id ou da conta-pai. Sem diferenciar maiúsculas nem acentos.', 'wp-mcp-google-fator3' ),
                        ),
                        'expand_managers' => array(
                            'type' => 'boolean',
                            'description' => __( 'Só Google Ads: também lista as contas administradas por cada gerenciadora (MCC) acessível. Custa uma chamada por gerenciadora. Padrão: false.', 'wp-mcp-google-fator3' ),
                        ),
                        'refresh' => array(
                            'type' => 'boolean',
                            'description' => __( 'Ignora o cache de 10 minutos e consulta a Google de novo. Use depois de criar ou receber acesso a uma conta. Padrão: false.', 'wp-mcp-google-fator3' ),
                        ),
                    ),
                ),
                'callback' => static function ( array $input ): array {
            return Query::accounts( $input );
                },
            )
        );
    }
    // =========================================================================
    // google/list-fields
    // =========================================================================
    private static function register_list_fields(): void {
        Ability::register(
            'google/list-fields',
            'any',
            array(
                'label' => __( 'Google: listar campos', 'wp-mcp-google-fator3' ),
                'description' => __( 'Descobre as métricas e dimensões que google/query aceita num conector. No GA4 vem do catálogo da própria API (com as personalizadas da propriedade, se informada); no Google Ads vem do catálogo curado do plugin. Substitui o list_fields do Porter.', 'wp-mcp-google-fator3' ),
                'input_schema' => array(
                    'properties' => array(
                        'connector' => array(
                            'type' => 'string',
                            'enum' => array( 'ga4', 'google-ads', 'search-console', 'ga', 'ads', 'gsc' ),
                            'description' => __( 'Obrigatório: ga4, google-ads ou search-console. Os dois catálogos são diferentes e não se misturam.', 'wp-mcp-google-fator3' ),
                        ),
                        'field_type' => array(
                            'type' => 'string',
                            'enum' => array( 'metric', 'dimension' ),
                            'description' => __( 'Filtra por tipo. Sem ele vêm os dois.', 'wp-mcp-google-fator3' ),
                        ),
                        'query' => array(
                            'type' => 'string',
                            'description' => __( 'Filtra por trecho do id, do nome nativo ou do rótulo (ex.: "conver", "cost", "campanha"). Quando um campo casa exatamente, ele também volta em exact_match.', 'wp-mcp-google-fator3' ),
                        ),
                        'account_id' => array(
                            'type' => 'string',
                            'description' => __( 'Só GA4: a propriedade (ex.: "properties/123456") cujas dimensões e métricas personalizadas devem entrar na lista. Sem ela vem o catálogo universal. Ignorado no Google Ads.', 'wp-mcp-google-fator3' ),
                        ),
                        'resource' => array(
                            'type' => 'string',
                            'description' => __( 'Só Google Ads: nome do recurso GAQL (ex.: campaign, ad_group, search_term_view) cujos campos selecionáveis vivos devem ser acrescentados ao catálogo curado. Cache de 24 h.', 'wp-mcp-google-fator3' ),
                        ),
                    ),
                    'required' => array( 'connector' ),
                ),
                'callback' => static function ( array $input ): array {
            return Query::fields( $input );
                },
            )
        );
    }
    // =========================================================================
    // google/query
    // =========================================================================
    private static function register_query(): void {
        Ability::register(
            'google/query',
            'any',
            array(
                'label' => __( 'Google: consultar dados', 'wp-mcp-google-fator3' ),
                'description' => __( 'Relatório unificado de GA4, Google Ads ou Search Console: métricas por dimensão, num período, com filtros, ordenação e comparação com o período anterior. Devolve colunas e linhas posicionais. Substitui o query_data do Porter.', 'wp-mcp-google-fator3' ),
                'input_schema' => array(
                    'properties' => array(
                        'collection'=>Collection::schema(),
                        'calendar'=>Calendar::schema(),
                        'search_type' => array(
                            'type' => 'string',
                            'description' => 'Search Console: sinônimo de type.',
                        ),
                        'aggregation_type' => array(
                            'type' => 'string',
                            'description' => 'Search Console: auto, byPage ou byProperty.',
                        ),
                        'offset' => array(
                            'type' => 'integer',
                            'minimum' => 0,
                            'description' => 'Search Console: sinônimo de start_row.',
                        ),
                        'dimension_filter_groups' => array(
                            'type' => 'array',
                            'items' => array( 'type' => 'object' ),
                            'description' => 'Search Console: grupos de filtros dimensionais no formato da API.',
                        ),
                        'type' => array(
                            'type' => 'string',
                            'description' => 'Search Console: web, image, video, news, discover ou googleNews.',
                        ),
                        'data_state' => array(
                            'type' => 'string',
                            'description' => 'Search Console: final ou all.',
                        ),
                        'start_row' => array(
                            'type' => 'integer',
                            'minimum' => 0,
                            'description' => 'Search Console: índice inicial da página, a partir de zero.',
                        ),
                        'connector' => array(
                            'type' => 'string',
                            'enum' => array( 'ga4', 'google-ads', 'search-console', 'ga', 'ads', 'gsc' ),
                            'description' => __( 'Obrigatório, um por chamada: ga4, google-ads ou search-console. Use google/blend para combinar conectores.', 'wp-mcp-google-fator3' ),
                        ),
                        'accounts' => array(
                            'type' => array( 'array', 'string' ),
                            'items' => array( 'type' => 'string' ),
                            'description' => __( 'Contas a consultar, como vêm de google/list-accounts: "properties/123456" no GA4, "1234567890" ou "123-456-7890" no Google Ads. Com duas ou mais, as linhas ganham as colunas account_id e account_name, o limite vale por conta e uma conta que falhar vira aviso em warnings sem derrubar as outras. IDs ou nomes únicos. O seletor * expande todas as contas do catálogo acessível; seleção explícita mantém teto de 25 com aviso.', 'wp-mcp-google-fator3' ),
                        ),
                        // Sinônimo declarado de propósito: `Ability::register()` fecha o
                        // esquema com additionalProperties=false, e o WordPress 6.9+ recusa
                        // a chamada inteira quando chega uma chave não declarada. Um
                        // sinônimo que o código aceita e o esquema proíbe é código morto.
                        'account_id' => array(
                            'type' => array( 'array', 'string' ),
                            'items' => array( 'type' => 'string' ),
                            'description' => __( 'Sinônimo de accounts, para quem vem do vocabulário do Porter. Use um ou outro, não os dois.', 'wp-mcp-google-fator3' ),
                        ),
                        'metrics' => array(
                            'type' => 'array',
                            'items' => array( 'type' => 'string' ),
                            'description' => __( 'Ao menos uma. GA4: nomes da API (sessions, activeUsers, screenPageViews, totalRevenue…) e os apelidos users, pageviews, revenue, bounce_rate, engagement_rate, avg_session_duration, cost. Google Ads: impressions, clicks, cost, ctr, average_cpc, average_cpm, conversions, conversions_value, cost_per_conversion, conversion_rate, all_conversions, all_conversions_value, search_impression_share, search_top_impression_share, absolute_top_impression_percentage, interactions, interaction_rate, video_views, view_through_conversions, roas — ou o nome nativo (metrics.*). Custo e afins já voltam na moeda da conta, não em micros.', 'wp-mcp-google-fator3' ),
                        ),
                        'dimensions' => array(
                            'type' => 'array',
                            'items' => array( 'type' => 'string' ),
                            'description' => __( 'Opcional. GA4: nomes da API (date, sessionDefaultChannelGroup, country…) e os apelidos channel, source_medium, landing_page, page, device. Google Ads: date, week, month, quarter, year, day_of_week, device, ad_network_type, campaign_id, campaign_name, campaign_status, campaign_type, campaign_bidding_strategy_type, campaign_budget, ad_group_id, ad_group_name, ad_group_status, ad_id, ad_name, ad_type, ad_status, keyword, keyword_match_type, search_term, geo_country, account_id, account_name, currency, conversion_action_name — ou o nome nativo qualificado.', 'wp-mcp-google-fator3' ),
                        ),
                        'date_range' => array(
                            'type' => array( 'object', 'string' ),
                            'description' => __( 'Obrigatório. Preset (string ou {"preset":"..."}): today, yesterday, last_7_days, last_14_days, last_28_days, last_30_days, last_90_days, this_week, last_week, this_month, last_month, this_quarter, last_quarter, this_year, last_year. Ou {"from":"2026-08-01","to":"2026-08-31"}. Os last_N_days terminam ONTEM; os this_* incluem hoje. Resolvido no fuso do site.', 'wp-mcp-google-fator3' ),
                        ),
                        'compare_date_range' => array(
                            'type' => array( 'object', 'string' ),
                            'description' => __( 'Opcional. "previous_period" (mesmo número de dias imediatamente antes), "previous_year" (as mesmas datas um ano antes), um preset, ou {"from","to"}. Com comparação a tabela ganha a primeira coluna date_range_name, com os valores current e previous.', 'wp-mcp-google-fator3' ),
                        ),
                        'filters' => array(
                            'type' => 'array',
                            'items' => array( 'type' => 'object' ),
                            'description' => __( 'Lista de {"field","operator","value"}, combinados com E. Operadores: eq, neq, gt, gte, lt, lte, contains, ncontains, begins_with, ends_with, in (value é lista), regex, null, notnull. O campo usa os mesmos nomes de metrics/dimensions. No Google Ads, filtrar um campo em moeda usa a moeda (cost > 100 são cem reais, não cem micros).', 'wp-mcp-google-fator3' ),
                        ),
                        'order_by' => array(
                            'type' => array( 'array', 'object', 'string' ),
                            'items' => array( 'type' => array( 'object', 'string' ) ),
                            'description' => __( 'Lista de {"field","direction"} com direction asc ou desc (padrão desc). O campo precisa estar em metrics ou dimensions.', 'wp-mcp-google-fator3' ),
                        ),
                        'order_bys' => array(
                            'type' => array( 'array', 'object', 'string' ),
                            'items' => array( 'type' => array( 'object', 'string' ) ),
                            'description' => __( 'Sinônimo de order_by (é assim que a Data API do GA4 chama o campo). Use um ou outro.', 'wp-mcp-google-fator3' ),
                        ),
                        'limit' => array(
                            'type' => 'integer',
                            'description' => __( 'Máximo de linhas POR CONTA. Padrão e teto: o limite configurado no site (1000 de fábrica).', 'wp-mcp-google-fator3' ),
                        ),
                        'resource' => array(
                            'type' => 'string',
                            'description' => __( 'Só Google Ads, opcional: força o recurso da cláusula FROM (campaign, ad_group, ad_group_ad, keyword_view, search_term_view, geographic_view, customer). Sem ele o recurso é deduzido das dimensões pedidas.', 'wp-mcp-google-fator3' ),
                        ),
                    ),
                    // `accounts` fica fora de `required` porque `account_id` é um
                    // sinônimo válido e o núcleo não sabe disso; quem recusa a
                    // ausência dos dois é `Query::plan()`, com uma mensagem que diz
                    // qual formato usar em cada conector.
                    'required' => array( 'connector', 'metrics', 'date_range' ),
                ),
                'output_schema' => Quality::schema(),
                'callback' => static function ( array $input ): array {
            return Query::run( $input );
                },
            )
        );
    }
}
