# Fator3 MCP 0.44.0

## Atualização e ambiente

A base imediata é o Fator3 MCP 0.43.0. A atualização direta preserva políticas, sessões elegíveis, concessões, opções e backups no schema de dados 2. As senhas de aplicação conservam o alcance nativo do WordPress. Ao atualizar, confira a versão em nova requisição com saúde compacta, revise os clientes e teste o acesso com uma credencial real. O pacote requer WordPress 7.1.4 e PHP 8.3.

A matriz de integração desta edição inclui Core 1.78.0, Google 0.31.0, LinkedIn 0.20.0, Meta 0.21.0 e Pipedrive 0.9.0. As versões descrevem as entradas da bancada. O relatório externo registra quais cenários foram executados com cada entrada e seus limites.

## Clientes e sessões

As senhas novas e antigas se autenticam no REST nativo e no XML-RPC com as capacidades da conta. O perfil restringe as chamadas realizadas pelo MCP. Uma conexão que atinge seu teto de sessões libera a sessão menos recente da própria conexão para iniciar outra. Um cliente que voltar com uma sessão encerrada deve inicializar uma nova.

## Descoberta e documentação

A listagem sem argumentos continua entregando o catálogo visível completo. Para paginar, informe `per_page`, por exemplo 50. Use `summary:true` para ver provedores, `fields` para projetar campos e `next_cursor` para avançar. A leitura com schemas tem teto de 25 por página. O guia instalado informa o tipo, a descrição e o próximo passo de cada documento. O manual integral também é paginado. Clientes que optarem por paginar devem percorrer o cursor.

## Diagnóstico e contratos

A saúde do servidor resume os incidentes de cron nas últimas 24 horas, com indicação da cobertura da contagem. Para investigar o histórico retido, peça `system/health` com `fields:["cron"]`, sem o modo compacto. A inicialização da edição reconcilia o marcador com a agenda observada e registra o resultado.

O catálogo distingue parâmetros booleanos omitidos de um valor falso explícito. As metatools de execução e descoberta ficam fora da lista de alvos executáveis; as habilidades do próprio WordPress identificam o provedor `wordpress-core`. O texto JSON das respostas conserva acentos e barras, com as mesmas estruturas de dados disponíveis para clientes que usam o conteúdo estruturado.

Os documentos e os catálogos de linguagem são entregues em PHP protegido. A Ajuda do painel e a habilidade autenticada `system/guide` são as entradas para ler notas e guias. O build confere o catálogo compilado, os exemplos contra os contratos exportados, a base, a matriz e o conteúdo do instalador antes de substituir o ZIP.

## Painel, dados e limites

O painel reúne Visão geral, Conexão, Clientes, Arquivos e banco, Atividade, Diagnóstico e Ajuda. A documentação abre pelo índice, renderiza tabelas e código e avança por seções inteiras. Consulte [Administração](administracao) para os fluxos e [Atualização](atualizacao) para os efeitos da desinstalação.

A exclusão preserva os dados por padrão. A opção de limpeza se aplica à exclusão em site individual. As senhas de aplicação são nativas do WordPress e permanecem após a exclusão. Revogue-as separadamente quando a finalidade for encerrar seu uso geral no site.

A distribuição identifica o pacote por slug e SHA-256. Antes de implantar na frota, confira o relatório externo e o resultado de `system/health` em uma nova requisição.
