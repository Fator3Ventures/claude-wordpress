# Fator3 MCP 0.43.0 — Notas da versão instalada

## Pedidos MCP 79

Em **Ferramentas → Fator3 MCP → Ajuda**, o atalho **Notas desta versão** abre as notas da versão em execução. Na 0.42.0 o atalho apontava para a 0.40.0. O endereço agora é montado com a constante de versão do plugin, a mesma que `system/health` informa.

Para conferir pelo MCP:

```json
{"ability_name":"system/health","parameters":{"compact":true}}
```

Resposta: chaves `plugin_version`, `healthy`.

```json
{"ability_name":"system/guide","parameters":{"document":"release-0430"}}
```

Resposta: chaves `content`, `document_sha256`.

A tela e o MCP leem o mesmo documento do pacote. **Abrir documento** segue listando as releases anteriores. Em **Arquivos e banco**, o exemplo sobre pré-imagens continua nas notas da 0.42.0.

## Base de migração e requisitos

- Instalação limpa ou atualização direta da 0.42.0.
- WordPress 7.1.4 e PHP 8.3.
- Schema de dados 2, sem migração nesta versão.
- Correções posteriores seguem em nova versão.

## Conjunto validado na entrega

Core 1.77.0, Google 0.31.0, Meta 0.21.0, LinkedIn 0.19.0 e Pipedrive 0.8.0. Outras combinações precisam de validação própria.

## Contratos

167 habilidades próprias, com 0 acrescentadas, 0 removidas e 0 schemas alterados em relação à 0.42.0. Contratos vigentes: `server-integration/1.0.0`, `selection-guard/2`, `executor-registration/1.0.0`, `package-distribution/1.0.0`, `mutation-audit/1.0.0`.

Arquivos de runtime alterados: `includes/guide-content.php`, `includes/guide-documents.php`, `includes/views/help.php`, `wp-mcp-fator3.php`. Arquivo acrescentado: `docs/RELEASE-0430.md`.

## Limites conhecidos desta versão

1. O perfil de uma senha de aplicação vale para as chamadas MCP. No REST nativo e no XML-RPC, a senha conserva as permissões da conta. Veja «Alcance de uma senha de aplicação» em `administracao`.
2. As notas de versão em `wp-content/plugins/wp-mcp-fator3/docs/` respondem sem autenticação e informam a versão instalada.
3. `wp-mcp-ultimate-discover-abilities` sem parâmetros devolve o catálogo inteiro. Use `query`, `prefix`, `provider` ou `per_page`. O parâmetro `readonly` omitido lista leituras e escritas, embora o schema declare padrão `false`.
4. `system/guide` com `topic` devolve a seção inteira, sem paginação. Para leitura paginada use `document`.
5. `system/health` sem `compact` inclui o histórico de incidentes do cron, limitado a 100 itens; atingido o limite, os novos incidentes contam em `untracked_errors` e ficam fora da lista.
6. No **Registro**, eventos do painel e recusas do transporte aparecem como «Habilidade histórica».
7. A **Ajuda** mostra o Markdown sem formatação, em páginas de 8.192 bytes.
8. Excluir o plugin preserva tabelas, opções, armazenamento privado e senhas de aplicação. Veja «Desativar e excluir o plugin» em `administracao`.
9. 375 dos 770 parâmetros de entrada das habilidades próprias estão sem descrição no schema.
10. O servidor aceita 32 sessões ativas por conta WordPress. No limite, `initialize` devolve HTTP 500 com «Internal error: Failed to create session» até uma sessão expirar ou ser encerrada pelo cliente com HTTP DELETE.

Revisão documental de 10/11/2026: acrescentadas as seções de base, conjunto validado, contratos e limites conhecidos. O texto instalado na 0.43.0 tem 783 bytes e SHA-256 `1af50ffb7edc520aa93b8769391b362c573f7110cb939c5e8b7d9adec9bae481`.
