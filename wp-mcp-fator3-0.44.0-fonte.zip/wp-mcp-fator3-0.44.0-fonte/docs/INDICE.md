# Índice da documentação do Fator3 MCP

Versão documentada: 0.44.0.

Abra o documento indicado para a tarefa no painel ou envie seu identificador a `system/guide` no campo `document`. Use o cursor retornado para continuar a leitura. A pesquisa encontra seções por palavras do texto.

## Guias por tarefa

| Tarefa | Documento | Próximo passo |
|---|---|---|
| Conectar um cliente e escolher perfil | [Administração](administracao) | Faça uma leitura com a credencial emitida e confira a atividade. |
| Iniciar a operação de um agente | [Guia para agentes](guia-agentes) | Consulte saúde compacta e resumo dos provedores. |
| Usar arquivos, conteúdo, mídia ou banco | [Operação](operacao) | Consulte a habilidade e verifique o alvo antes de confirmar. |
| Instalar, atualizar ou excluir | [Atualização](atualizacao) | Confira a preferência de exclusão e a identidade do pacote. |
| Investigar uma instalação pendente | [Pacotes](pacotes) | Consulte o recibo pelo identificador. |
| Conferir cópias e retenção | [Retenção](retencao) | Conclua o inventário e examine a prévia. |
| Recuperar uma troca com vários provedores | [Recuperação conjunta](recuperacao-conjunta) | Confira o estado de cada provedor. |
| Excluir um termo de taxonomia | [Termos](termos) | Confira objetos relacionados e identidade do termo. |

## Contratos por assunto

| Assunto | Documento |
|---|---|
| Registro de extensões, servidor e executores | [Extensões](contrato-extensoes), [Integração do servidor](server-integration), [Registro de executores](executor-registration) |
| Distribuição de pacotes e escolha do instalador | [Distribuição](package-distribution) |
| Autorização OAuth, papéis e capacidades | [OAuth e CIMD](oauth-cimd), [Papéis](roles) |
| Proteção da escrita SQL e limites de retenção | [Guarda SQL](sql-guard), [Retenção SQL](sql-retention) |
| Sondas, auditoria e metadados que podem ser exibidos | [Sondas](probe-audit), [Auditoria de mutações](mutation-audit), [Auditoria de serviços](mutation-service-audit), [Redação](redacao) |

## Notas de versão e histórico

As [notas da edição instalada](release-0440) identificam a base, os acompanhantes, os contratos e os limites da atualização. As notas anteriores ficam no grupo Notas de versão. O [histórico de operação](historico) reúne as instruções acumuladas até a reorganização do manual. Consulte [Operação](operacao) para os procedimentos atuais.
