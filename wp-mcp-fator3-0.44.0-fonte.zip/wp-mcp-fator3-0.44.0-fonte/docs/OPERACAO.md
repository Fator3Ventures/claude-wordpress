# Manual de operação do Fator3 MCP

Versão documentada: 0.44.0.

## Por onde começar

| Tarefa | Documento | Conferência |
|---|---|---|
| Localizar um procedimento | [Índice](indice) | Abra o documento da tarefa pelo ID publicado. |
| Conectar um cliente | [Administração](administracao) | Faça uma leitura com o cliente e localize o evento em Atividade. |
| Verificar a instalação | [Atualização](atualizacao) e [Notas desta versão](release-0440) | Em uma nova requisição, confira a versão em saúde compacta. |
| Iniciar uma sessão de agente | [Guia para agentes](guia-agentes) | Leia o resumo dos provedores e procure a habilidade. |
| Revisar pré-imagens de plugins | [Retenção](retencao) | Percorra o inventário e examine a seleção antes de confirmar. |
| Recuperar linhas de um UPDATE | [Guarda de seleção SQL](sql-guard) | Confira a pré-imagem por chave antes de restaurar. |
| Investigar uma ação | [Auditoria de mutações](mutation-audit) | Filtre a atividade pela operação, cliente ou alvo. |

O cabeçalho do pacote declara `Update URI: https://fator3.com.br/plugins/wp-mcp-fator3`. O atualizador usa o ZIP identificado pelo slug e pelo hash do relatório. Os requisitos são WordPress 7.1.4 e PHP 8.3. A atualização é sem trava por versão de origem. As entradas efetivamente exercitadas constam das notas e do relatório da edição.

## Conectar e descobrir o catálogo

Copie o endereço na Visão geral. Abra o cliente com OAuth ou senha de aplicação, inicialize a sessão e leia o resumo dos provedores com `summary:true`. Para pesquisar uma tarefa, envie termos em `query`; para restringir a seleção, combine com `prefix`, `provider` e `readonly`. A descoberta sem parâmetros devolve o catálogo visível completo. Para páginas menores, informe explicitamente `per_page`, por exemplo 50. Percorra `next_cursor` enquanto `has_more` for verdadeiro. Com schemas, o limite por página é 25. Uma permissão marcada `requires_input` só se resolve ao conhecer o alvo da operação.

Antes de uma chamada, consulte Get Ability Info com o nome completo. A resposta descreve tipos, campos obrigatórios e disponibilidade para a conexão. Parâmetros de uma habilidade ficam em `parameters` de Execute Ability. O executor de leitura depende da configuração do cliente. Para o roteiro com exemplos, consulte o [guia para agentes](guia-agentes).

## Sessões, contas e autorização

O perfil de uma conexão e as capacidades da conta WordPress determinam o alcance das chamadas. Senhas de aplicação novas e antigas autenticam no REST nativo e no XML-RPC com as capacidades da conta. O perfil de acesso ao MCP se aplica às chamadas feitas por esse servidor. Ao emitir uma senha, considere as permissões da conta em todos esses caminhos.

As sessões têm identidade própria. Use o cabeçalho negociado na inicialização e termine com DELETE. Se o servidor devolver 404 para uma sessão encerrada, inicialize outra com a credencial válida. A criação de uma sessão quando o limite da conexão foi atingido encerra a menos recente daquela conexão. Ao revogar o cliente, confira a remoção do acesso e das sessões antes de emitir outra credencial.

## Confirmação, conflitos e resultados

Resultados incluem `success`, código estável de erro, identificação da operação quando pertinente e estado observado do efeito. No MCP, falha de tool usa `isError:true` e conteúdo estruturado. `data` de WP_Error é preservada com redação por chave. `applied:null` significa efeito incerto, não autorização para repetir. Uma falha com `retryable:true` sem efeito (`applied`, `persisted` e `changed` diferentes de true, código diferente de `operation_uncertain`) não consome a `idempotency_key`: repetir com a mesma chave executa de novo. Resultados concluídos, definitivos ou incertos continuam reproduzidos com `replayed:true`.

Operações em duas fases fornecem uma identidade `phase:…` consultável por `operations/status`, inclusive se a resposta de confirmação se perder. Para operações em duas fases, faça a chamada sem `confirm_token`, examine a prévia e repita os mesmos parâmetros com o token. Ele se vincula à intenção, conexão e pré-imagem, e expira em 600 segundos. SQL, lotes, restauração, mudanças de endereço e autorrestrição continuam em duas fases. `confirm:true` dispensa a segunda chamada apenas em exclusões tipadas admitidas para Manutenção; não dispensa uma revisão/hash fornecida.

`expected_sha256`, `expected_revision` e revisões de política impedem sobrescrever uma pré-imagem diferente. Os locks de arquivo cobrem leitura, comparação, backup e substituição entre operações cooperantes. O tempo padrão `lock_wait_seconds` é 2 segundos; dois agentes no mesmo site devem tratar conflitos e reler antes de decidir. Editores externos que não usam o mesmo lock continuam podendo alterar arquivos.

## Arquivos, busca e transferências

`files/read` conserva bytes binários em base64 também na leitura integral. Use `offset_bytes` para iniciar em um byte arbitrário; o cursor opaco continua disponível. Cursor e offset incompatíveis são recusados. `tail_lines`, `offset`, `grep` e busca por `grep_regex` atendem logs/textos; `files/search` aceita arquivo único ou diretório. Erros de PCRE são identificáveis.

`files/write` recusa conteúdo textual para extensões binárias; use `content_base64`. Arquivos PHP têm validação sintática, pré-imagem, escrita atômica e sondas. Em Manutenção, `probe:false` é uma escolha explícita que pula apenas as sondas de execução; a resposta registra isso, e a operação concluída não é revertida como se estivesse abandonada.

`files/move`, `files/copy`, `files/delete`, `files/rmdir`, patch e restauração preservam seus contratos. Rótulos `label`/`rotulo` identificam backups; aliases conflitantes são recusados. O armazenamento `f3-mcp-private` não é uma pasta comum disponível por files/*: consulte `system/health` e os serviços de backup/exportação.

O limite padrão por arquivo é 16 MiB. `system/settings-update` ajusta `file_bytes` entre 1 MiB e 1 GiB, sujeito aos recursos físicos; a conexão pode ter limite próprio. Isso não aumenta o tamanho máximo de uma resposta nem elimina limites PHP. Para 20 MiB, configure pelo menos 20 MiB e use `files/upload-create`, partes de 256 KiB, `files/upload-part` e `files/upload-finalize`. SHA-256 e tamanho total são conferidos; partes repetidas idênticas são aceitas. Cancelar remove as partes da transferência, sem desfazer um arquivo já concluído.

`files/archive` compacta a origem incluindo seu nome. `files/extract` valida o ZIP e prepara o destino antes de substituir. `overwrite:true` substitui a árvore inteira, sem mesclar. Links, traversal, colisões, CRC inválido e expansão excessiva são recusados. `files/rollback-tree` usa o backup e recusa pós-imagem alterada. Limites adicionais do inventário de recuperação: 20.000 entradas e 256 MiB por árvore.

## Backups e recuperação

Backups e artefatos são privados, com envelope PHP e metadados assinados. A exportação contém valores originais quando destinada a recuperação, inclusive segredos. Base64 não é criptografia. `backups/list` permite rótulo/data. Retenção é explícita, com prévia e seleção congelada; instalar a versão não limpa pendências automaticamente.

A sentinela em mu-plugins preserva a recuperação fora da pasta substituível. Não a remova enquanto houver operação pendente. Rollback de arquivos/plugins/temas verifica a pós-imagem para não apagar mudança posterior. Restauração de arquivos não desfaz migrações arbitrárias realizadas por código de um plugin/tema.

`system/health` apresenta estado e localização do armazenamento, recuperação, cron e sondas. Consulte o código e o estado de erro antes de repetir. Uma operação interrompida pode precisar de recuperação explicitamente confirmada.

## Plugins, temas e atualização do canal

`plugins/upload` e base64 aceitam hash do ZIP, slug esperado, overwrite e ativação explícita. Omissão de `activate` equivale a false. A substituição cria pré-imagem e devolve versões/ativação antes e depois. Plugins que já estavam ativos permanecem ativos ao atualizar, com verificação em requisição nova e sondas anônimas. `plugins/rollback` recupera a árvore anterior. A exclusão verifica ausência e limpa somente a entrada correspondente em auto-update; limpeza de registro de uninstall não executa o callback.

`plugins/list` permite projeção `fields`/`campos` e filtro `prefixes`/`prefixo`. `themes/upload`, `themes/activate`, `themes/update`, `themes/delete` e `themes/rollback` acrescentam pré-imagem, identidade, requisitos, pai/filho e recuperação. O tema em uso ou seu pai não pode ser excluído; tema com dependentes também é recusado.

O canal aceita fontes HTTPS de manifesto em `system/settings-update.update_channels`. Configurá-las não liga atualização automática. `Update URI: https://fator3.com.br/plugins/wp-mcp-fator3` identifica o pacote no mecanismo de atualização próprio; não é um feed publicado. O manifesto precisa apontar para bytes reais verificáveis por SHA-256.

## Leitura SQL e exportação de resultados

Em Manutenção, `db/query` aceita SELECT, WITH terminado em SELECT, JOIN, UNION, views do banco do site, subconsultas, agregações, CASE, janelas, funções JSON/data e leitura pertinente de information_schema. Há uma única instrução, sem escrita nem construções com efeito colateral. O SQL original é preservado; somente o LIMIT externo é limitado para a resposta interativa.

A resposta interativa tem até 2.000 linhas e 16 MiB. `timeout_seconds` é limitado pelo tempo efetivo do processo. Para o resultado completo, use `db/query-export` com `format:jsonl` ou `csv`, `gzip` opcional e `async:true` por padrão. A operação materializa um snapshot de leitura, informa contagem/bytes/SHA-256 e só publica artefato completo. `operations/status` recebe `operation_id`; `db/export-part` lê blocos base64 de até 256 KiB com offset/hash. `db/query-page` pagina JSONL sem gzip por uma chave sequencial criada no snapshot, sem OFFSET sobre tabelas vivas.

Jobs dependem do loopback ou WP-Cron, sem daemon novo. `db/export-cancel` solicita cancelamento cooperativo. Snapshot de worker encerrado não é retomado como se ainda existisse: o estado aponta interrupção e exige nova exportação. Artefatos de consulta expiram em sete dias. Espaço/tempo insuficientes geram falha sem disponibilizar arquivo parcial como concluído.

A redação usa origem da coluna, chave projetada e predicado exato comprovado. Aliases de colunas secretas continuam redigidos. `option_value`/`meta_value` com chave ambígua são redigidos conservadoramente; `redacted` informa célula, razão e origem. Transformações arbitrárias em SQL administrativo não têm garantia de impedir inferência. Respostas binárias preservam encoding explícito.

## Escrita SQL, dump e troca serializada

`db/execute`, `db/batch` e `db/search-replace` usam `selection-guard/2`, descrito no [contrato da guarda SQL](sql-guard). A seleção e suas dependências são verificadas sob locks MySQL, com token de dez minutos, dump privado (integral por padrão) e recibo persistido. A guarda não é uma impressão do banco inteiro. `database_conflict` exige revisão de nova prévia; `sql_guard_unavailable` recusa formas sem prova completa antes de escrever.

DML aplica uma transação InnoDB; DDL é operação separada, com snapshot para recuperação e sem promessa de rollback transacional global. `operations/plan` não inclui SQL.

`db/export` produz SQL gzip privado de tabelas selecionadas ou do banco. Inclui schema, dados, índices, views em ordem de dependência, triggers e manifesto. Bytes binários, NULL e Unicode são preservados. Banco com rotinas/eventos SQL não suportados é recusado como dump completo; nenhum artefato parcial recebe esse rótulo. Dumps de recuperação não expiram automaticamente.

`db/restore` exige artefato íntegro, prévia do destino e confirmação; cria backup anterior e diário fora do banco afetado. O estado MCP corrente é preservado por inventário explícito (`preserved-state/1`), inclusive revogações, senhas de aplicação e sessões WordPress. Options `f3_mcp_google_*` e a tabela Google pertencem à fotografia restaurada. Suspenda e reconcilie executores pelos controles dos seus donos: restauração não desfaz efeitos já enviados a APIs externas.

`db/search-replace` faz troca literal em strings, JSON e arrays serializados, com filtros `tables`/`columns`, amostras redigidas e lotes por chave primária dentro de uma transação. Não instancia objetos PHP. Objetos serializados e alterações em chave primária são apontados e preservados; tabela selecionada sem chave primária causa recusa antes da confirmação. Alterações de chave usam SQL explícito. Contagens por tabela/coluna e backup acompanham o resultado. Confira `skipped`, mesmo quando a operação conclui.

`db/schema` com `contar:true` acrescenta `rows_exact`, mantendo distinta a estimativa.

## Conteúdo e mídia

Patch de post/página exige seleção única por padrão, aceita limite também no modo regex e suporta `expected_revision`. Readback inclui SHA-256 e CHAR_LENGTH; transformação observada é indicada por `content_filtered`. As descrições usam `parent`; `parent_id` é alias compatível, com recusa quando diverge.

`content/edit-block` não descarta filhos silenciosamente quando recebe `inner_html`; use `children` para substituir a árvore. `featured_media` e revisão final consideram as gravações pertinentes. Revisões e getters permitem projeção sem trazer conteúdo desnecessário.

`content/delete-post` explicita o comportamento real de lixeira para tipos de post e exclusão permanente. `media/regenerate` e `media/set-site-icon` usam as APIs nativas e verificam metadados/recortes. Não exigem mu-plugin descartável.

## Configuração, cron e cache

Em Manutenção, `options/update` administra options fora do estado interno do canal, com backup e readback. `stylesheet` usa `themes/activate`; `template`/`current_theme` orientam para essa seleção nativa. `active_plugins` orienta para as habilidades de ativação/desativação para preservar hooks. Nomes internos f3_mcp_* orientam para `system/settings-update`. Segredos podem ser gravados, mas não são repetidos em resultado/log. `auto_update_plugins` é administrável; instalar o canal não a habilita automaticamente.

`site/set-admin-email` grava o e-mail autorizado e limpa confirmação pendente; não comprova entrega de e-mail. `site/set-language` instala pacote oficial compatível antes de mudar WPLANG. `roles/list`/`roles/update` usam APIs nativas e confirmação. `site/set-address` faz prévia, exige destino alcançável e permite troca serializada de URLs, com verificação e reversão. Não cria DNS/TLS.

Permalink, category_base e tag_base são regenerados pelo serviço nativo; `rewrite/flush` executa flush soft e devolve comparação de regras. Não é necessário editar rewrite_rules por SQL.

`cron/list` mostra hook/timestamp/argumentos/recorrência e revisão. `cron/run` executa somente evento existente conferido, sob lock cooperativo e contexto cron sem usuário logado; conclusão do callback informa `business_result:unknown`. O resultado inclui `operation_id`; `operations/status` conserva conclusão ou efeito incerto após interrupção. Não é um executor de nomes de funções PHP. `cron/schedule` e `cron/unschedule` verificam a agenda nativa. Dois disparos cooperantes são serializados; callbacks com efeito externo precisam de verificação própria.

`system/delete-transient` remove chave exata e identifica backend. `system/cache-flush` limpa cache de objeto, não cache de página. `system/health.cron` informa wp_cron_desabilitado, eventos_vencidos e ultimo_disparo. Site sem disparo WP-Cron pode acumular agenda vencida.

## Verificar sondas e recusas

Consulte o [contrato de sondas e auditoria](probe-audit). Ao enviar `contexto_teste:true`, o servidor marca o tráfego HTTP que origina. O campo `traffic_class_scope` tem valor `outgoing_request` e identifica esse escopo. Confira `passed`, os resultados por caminho e `cache_bypass_verified`. O campo `success` indica que a habilidade executou. Uma requisição anônima à rota MCP recebe `mcp_authentication_required`; uma conta autenticada sem a capacidade exigida recebe `mcp_permission_denied`. A atividade registra a recusa com os metadados permitidos.

Para testar o armazenamento privado, use a ação em Diagnóstico ou `system/probe` com `test_private_storage:true`. A sonda cria um marcador temporário e verifica a resposta por HTTP sem credencial. Consulte seu resultado e a validade na saúde do servidor. Uma resposta HTTP local e uma leitura autenticada feita pelo cliente verificam caminhos distintos; registre ambas ao investigar uma falha de conexão.

## Investigar operações de pacote

Guarde o `package_operation_id` retornado por uma instalação pendente. Consulte `plugins/operation-status` antes de uma nova tentativa. Se a verificação ficou inconclusiva, faça a reconciliação explícita pelo ID. A consulta de situação é de leitura. A reconciliação examina o estado atual e pode aplicar a recuperação. O diário de pacotes identifica a troca dos arquivos; o identificador do executor permite conferir a requisição que a iniciou. Veja os estados e procedimentos em [Verificação de pacotes](pacotes).

## Desativar e excluir

Desativar remove o evento de cron do MCP e interrompe o atendimento por esse plugin. A exclusão preserva os dados por padrão. Em Diagnóstico, a preferência de remover dados ao excluir exige uma escolha explícita antes da exclusão pelo WordPress. Consulte os efeitos sobre tabelas, opções, armazenamento, backups e credenciais em [Instalação e atualização](atualizacao).
