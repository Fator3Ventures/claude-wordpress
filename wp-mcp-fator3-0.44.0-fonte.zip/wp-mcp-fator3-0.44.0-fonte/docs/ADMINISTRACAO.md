# Guia de administração do Fator3 MCP

Versão documentada: 0.44.0.

Abra **Ferramentas → Fator3 MCP** com uma conta que tenha `manage_options`. A navegação reúne Visão geral, Conexão, Clientes, Arquivos e banco, Atividade, Diagnóstico e Ajuda. Os horários são apresentados no fuso configurado no site.

## Visão geral

Confira o servidor, o canal de arquivos e banco, a escrita SQL e os clientes ativos. As pendências encaminham à ação de teste ou configuração. Copie o endereço que será usado pelo cliente. Nos resumos de atividade, clientes e armazenamento, abra a aba correspondente para ver os detalhes ou alterar configurações.

## Conectar um cliente

1. Na aba **Conexão**, copie a URL e abra o modelo de configuração do cliente.
2. Para OAuth, informe a URL no cliente e autorize com a sua conta WordPress. A concessão associa o perfil à identidade do cliente.
3. Para senha de aplicação, prefira uma conta com as capacidades necessárias à tarefa. Escolha o perfil e emita a senha. Copie o segredo no momento da emissão e guarde-o no cliente.
4. Faça uma leitura com o cliente real e confira o evento na aba **Atividade**. O teste HTTP do painel parte do servidor e informa o resultado da conexão local.

## Alcance da senha de aplicação

As senhas de aplicação novas e antigas são credenciais nativas do WordPress. O perfil escolhido restringe as chamadas ao MCP. No REST nativo e no XML-RPC, a senha autentica com as capacidades da respectiva conta WordPress.

| Caminho | Permissão aplicada |
|---|---|
| MCP | Perfil da conexão e capacidades da conta. |
| REST nativo e XML-RPC | Capacidades da conta WordPress. Uma senha de administrador pode realizar operações administrativas. |

Emita a senha para uma conta com capacidades adequadas também fora do MCP. OAuth restringe o token ao recurso MCP autorizado. Revogue as senhas na conta WordPress quando precisar encerrar o acesso por todos esses caminhos.

## Clientes, perfis e validade

| Perfil | Acesso pelo MCP |
|---|---|
| Leitura | Consultas autorizadas pelo perfil e pela conta. |
| Conteúdo | Leitura e edição de conteúdo conforme as capacidades da conta. |
| Personalizado | Habilidades selecionadas para o cliente. |
| Manutenção | Administração conforme a conta, o canal e as restrições do servidor. |

Em **Clientes**, localize o cliente pela identificação e confira conta, perfil, último acesso e validade. Use a emissão para uma senha nova e a associação para uma identidade existente. Edite perfil, prazo, escopo de conteúdo, diretórios e permissões adicionais no formulário da identidade. Uma gravação concorrente exige reabrir o perfil antes de aplicar nova alteração.

O servidor limita sessões por conexão. Ao atingir o teto, ele encerra a sessão ativa menos recente daquela conexão para abrir a próxima. Conexões da mesma conta têm limites independentes. Ao revogar o cliente, confirme a identidade: o plugin bloqueia a política, encerra as sessões e, para senha de aplicação, remove a senha vinculada.

Um administrador em perfil Manutenção também pode consultar a relação pelo MCP.

```json
{"ability_name":"connections/list","parameters":{"per_page":20}}
```

Resposta: chaves `connections`, `has_more`.

Para renomear um cliente, envie `connection_id`, `expected_policy_version` e `label` a `connections/update`. Examine a prévia e repita os parâmetros com `confirm_token`. Se receber `connection_policy_conflict`, releia o perfil antes de preparar nova prévia.

## Arquivos e banco

No cartão de acesso, ajuste o canal, a escrita SQL e o limite por arquivo de 1 a 1.024 MiB. Salve os três ajustes juntos. Um MiB equivale a 1.048.576 bytes. Quando o canal está fechado, as chamadas de arquivos, temas, plugins e banco sujeitas ao canal são recusadas. Conteúdo e mídia seguem as permissões de cada cliente. A escrita SQL exige também perfil autorizado e confirmação da prévia. Abra a descrição das restrições do servidor para verificar outras condições.

No cartão de retenção, defina a idade mínima em dias, o máximo desejado e o mínimo protegido para backups SQL. Salvar os critérios não apaga cópias. O fluxo de limpeza mostra uma prévia da seleção para conferência. O [guia de retenção](retencao) descreve também a revisão das pré-imagens de plugins e o inventário com cursor.

## Atividade

Filtre por cliente, resultado, período ou habilidade/alvo. Abra os filtros adicionais para investigar um identificador de operação. A linha apresenta o momento, cliente, ação, alvo e resultado; abra os planos para conferir as etapas em execução. Os filtros ajudam a relacionar uma falha do cliente com a requisição recebida no servidor.

## Diagnóstico

Confira a saúde, as rotas, as falhas recentes de autorização, o cron e o armazenamento privado. O teste de proteção usa um marcador temporário e tenta lê-lo por HTTP sem credencial. Também é possível chamar a sonda pelo MCP.

```json
{"ability_name":"system/probe","parameters":{"test_private_storage":true}}
```

Resposta: chaves `private_storage`, `passed`.

O resultado da sonda vale por 24 horas. Use o relatório técnico para comunicar o estado observado. Na fonte de atualização, configure um manifesto apenas quando utilizar esse canal. A frota também aceita o ZIP versionado conferido pelo hash.

## Ajuda

Pesquise por termos presentes na mesma seção ou abra um documento pelo seletor agrupado. Os resultados abrem a página que contém a seção encontrada. A navegação entre páginas termina em uma seção completa. O [índice](indice) indica a primeira leitura para cada tarefa.

## Desativar, excluir e reinstalar

Desativar interrompe o MCP e remove o evento de cron próprio. A exclusão preserva os dados por padrão. Para exclusão definitiva em um site individual, marque antes a preferência de remoção em Diagnóstico. Consulte quais dados são removidos e quais credenciais precisam ser revogadas no [procedimento de exclusão](atualizacao).
