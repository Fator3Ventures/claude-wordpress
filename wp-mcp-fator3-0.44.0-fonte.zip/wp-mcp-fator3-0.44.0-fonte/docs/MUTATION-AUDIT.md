# Auditoria de mutações

Versão documentada: 0.44.0.

Identificador do contrato: Auditoria de mutações — mutation-audit/1.0.0.

> Contrato humano preservado. Serviço possui contrato separado implementado no MCP 0.28.0: veja MUTATION-SERVICE-AUDIT. Menções à proposta pendente abaixo são históricas.

Vigente na Fator3 MCP 0.26.1. Atende o impacto LinkedIn 0.5.0, Pedido LinkedIn 6(c). O MCP armazena somente referências e metadados. Os snapshots antes/depois permanecem no diário do provedor e são consultados no momento da leitura. Não há acesso a tabelas ou classes privadas de outro plugin, importação retroativa, restauração ou nova escrita remota.

## Registro público para provedores PHP

A classe pública `Fator3\McpFiles\MutationAudit` oferece `capabilities(): array`, `register(array $descriptor): true|WP_Error`, `record(array $event): array|WP_Error` e `status(): array`. `capabilities` não inicializa o catálogo. `status`, a primeira referência e a primeira leitura inicializam os provedores após a API de habilidades. O hook `f3_mcp_register_mutation_audit` recebe a string do contrato. Não existe ferramenta remota para registrar descritores ou callbacks.

```php
add_action('f3_mcp_register_mutation_audit', static function ($contract) {
    \Fator3\McpFiles\MutationAudit::register([
        'contract' => $contract,
        'provider' => 'wp-mcp-linkedin-fator3',
        'reader' => 'linkedin/get-write-operation',
        'event_contract' => 'linkedin-mutation/1.0.0',
    ]);
});
```

Descritores têm somente esses quatro campos; os dois contratos precisam ser strings versionadas. O leitor precisa estar registrado, ser público, somente leitura, aderente à política comum e decorado pelo MCP, pertencer ao provedor e aceitar `operation_id` string sem outros campos obrigatórios. Executores indiretos e habilidades `audit/*` são recusados. Descritores divergentes para o mesmo provedor invalidam sua integração naquela requisição. A permissão do leitor nunca é substituída.

A compatibilidade automática é delimitada ao metadado de versão **LinkedIn 0.5.0**, evento `f3_linkedin_mutation_recorded` e contrato `linkedin-mutation/1.0.0`. Versões futuras podem registrar explicitamente o contrato público; o MCP não presume compatibilidade de eventos futuros. Desativação do provedor deixa metadados históricos visíveis e retorna indisponibilidade na consulta.

## Referência emitida após escrita

```json
{"contract":"linkedin-mutation/1.0.0","provider":"wp-mcp-linkedin-fator3","operation_id":"<64 hex minúsculos>","operation":"create-campaign-group","state":"confirmed","before_sha256":"<64 hex minúsculos>","after_sha256":"<64 hex minúsculos ou null>","reader":"linkedin/get-write-operation"}
```

`record` recebe esse evento. Provedor/contrato/leitor devem coincidir com o descritor admitido; operation/state são identificadores ASCII limitados a 80 caracteres; hashes são SHA-256 hex ou null. Campos extras são descartados, nunca armazenados. Não enviar segredos nem snapshots. Um administrador autenticado é obrigatório. Usuário, site e conexão são capturados do runtime, não do evento.

A chave é `mutation:` + SHA-256 de `provider + NUL + operation_id`. Uma referência por provedor/operação é mantida no bucket `audit`; atualizações do mesmo principal atualizam estado/hashes preservando a data de criação. Tentativas de outro principal não alteram a referência. As tentativas MCP continuam registradas separadamente e incluem `mutation_reference`, derivada da identidade do provedor e do operation_id. Isso permite ver replay sem confundi-lo com outra escrita remota. O produtor continua responsável por idempotência, locks e reconciliação. `request_key` do LinkedIn permanece a chave do domínio; `idempotency_key` de transporte é opcional e não deve ser reutilizada entre prévia/aplicação/reconciliação.

Os hashes são declarações do evento, não prova recalculada sobre snapshots redigidos. O leitor é a autoridade atual. `reference_current` compara somente estado observado com estado da referência, não certifica igualdade dos snapshots. Falha de registro não repete nem desfaz efeito remoto; consultar o diário do produtor. Falha de persistência é sinalizada no diagnóstico de auditoria. Não há backfill automático de operações anteriores à instalação ou de eventos perdidos.

## Consulta por MCP

`audit/get-operation` recebe `provider` (slug, até 100 caracteres) e `operation_id` (64 hex minúsculos), ambos obrigatórios. Não aceita caminho, callback, usuário, concessão, campos de escrita ou bypass. Exige manage_options, autorização da própria ferramenta e do leitor do provedor, mesmo usuário/conexão da referência e todas as verificações do diário (principal, revogação, revisão de política e ativo ainda selecionado). Perfil custom precisa permitir as duas habilidades.

O leitor retorna `success:true`, com `operation_id`, `state`, `before` e `after`, em `data` ou na raiz. ID divergente, resposta inválida, erro ou exceção fecham a consulta. O MCP retorna contrato, audit_id, provider, operation_id, estado atual, reference_state, reference_current, snapshot_source:provider_public_reader, redacted:true e antes/depois. Snapshot acima de 1 MiB é recusado. Redação recursiva oculta chaves sensíveis (inclusive tokens/segredos dentro de objetos com forma de schema), valores Bearer/Basic e tipos não serializáveis. O produtor deve emitir projeções públicas próprias; a redação por nomes não identifica um segredo arbitrário escondido em um campo comum.

Erros locais: mutation_reference_invalid, mutation_not_found, mutation_access_denied, mutation_provider_unavailable, mutation_read_denied, mutation_result_invalid, mutation_snapshot_too_large e mutation_read_failed. Mensagens do erro remoto não são reproduzidas. after:null mantém a incerteza do produtor; nunca presumir confirmação. Ler um diário não renova credencial nem exige novo efeito remoto.

## Painel e retenção

Ferramentas → Fator3 MCP → Registro mostra operation_id, estado e botão Consultar antes e depois. A operação de painel é lida somente pelo mesmo administrador em identidade nativa. Um escopo interno temporário autoriza exclusivamente a habilidade de leitura admitida durante essa consulta; não cria ou reativa perfil MCP (inclusive mapeamento nativo revogado), não assume identidade e mantém o callback de permissão original e os gates do provedor. O escopo é fechado em finally. Uma operação de OAuth/Application Passwords continua exigindo a conexão original; o painel informa a restrição sem exibir snapshots.

O detalhe é somente leitura, com no-cache e JSON escapado no HTML. Não há exportação restaurável. Referências seguem a retenção explícita do bucket audit; apagar a referência não apaga o diário do provedor. O schema SQL permanece 2 e não há migração nem limpeza automática. Retornar arquivos à 0.25.0 preserva os metadados, mas remove a consulta de snapshots da interface.
