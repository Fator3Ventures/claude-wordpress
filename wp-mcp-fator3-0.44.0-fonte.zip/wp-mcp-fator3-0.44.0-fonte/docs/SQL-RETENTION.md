# Retenção e escopo SQL

Versão documentada: 0.44.0.

**0.39.0 · Pedido 77.** db/execute com backup_scope selected_rows simula e salva somente a seleção de um UPDATE elegível; restaura pelo backup_id passado como artifact_id a db/restore. O modo exige correspondência da pós-imagem e não copia a tabela na restauração. Para o contrato, limites e exemplos completos consulte RELEASE-0390. As regras de materialização integral abaixo referem-se aos demais escopos.


## Retenção dos dumps SQL

`backups/list` e `backups/prune` aceitam category: `backups` (padrão anterior), `sql_mutation` (dumps automáticos comprovados) e `sql_artifacts` (todos os artefatos SQL inventariados). Não use backups/export para ler SQL: use `db/export-part` e `db/restore`. A listagem mostra metadados, nunca as linhas originais. Exige manage_options e perfil Manutenção, além do canal habilitado.

A reconciliação de artefatos privados atuais avança em lotes de até 200 artefatos. Repita backups/list até inventory_complete:true. Origem não comprovada vira unknown; pares incompletos não são restauráveis. Saúde não faz dump, poda ou reconciliação. storage.sql_artifacts mostra contagens e bytes indexados, política e elegibilidade observada; eligibility.complete:false e inventory_complete:false indicam cobertura parcial. A observação de elegibilidade examina no máximo 1000 registros e protege o acervo se o diário de recuperação exceder 1000 registros ou for inválido.

Política inicial: idade maior que 30 dias OU exceder 20 dumps automáticos, preservando ao menos os três mais recentes e todas as referências ativas. Ajuste em Configurações → Retenção dos backups SQL ou system/settings-update.sql_retention (duas fases): older_than_days de 1 a 3650, max_count de 1 a 10000, min_keep de 0 a max_count. A política não executa exclusão automática.

```json
{"ability_name":"backups/prune","parameters":{"category":"sql_mutation","dry_run":true}}
```

Confira selection, blocked, selected_bytes e expected_selection_sha256. Aplique repetindo a categoria e enviando dry_run:false e o hash. Seletores repetidos precisam ser idênticos aos da prévia. Alternativamente, use artifact_ids com IDs completos de 32 caracteres; não misture IDs e política. ID explícito permite selecionar manual_export, restore_preimage e unknown completos, mas não ignora referências ou integridade.

Seleções são privadas, vinculadas ao usuário/conexão/site e válidas por 600 segundos antes do início. Novos arquivos não entram numa seleção existente. Criação, leitura e restore compartilham lock; poda é exclusiva. A espera padrão é 2 segundos. artifact_in_use e backup_selection_conflict não autorizam forçar a remoção. Operações em curso/incertas, diários pendentes e prévias válidas de restore protegem o dump. Recibos concluídos não impedem retenção para sempre.

Quarentena e remoção persistem por componente. backup_prune_partial retorna removed_bytes efetivamente retirados e remaining_count; retome com a mesma categoria/hash. O recibo concluído é reapresentado sem nova seleção. Tombstones preservam o histórico; operations/status.backup informa disponibilidade ou removed sem reaplicar SQL. Bytes retirados não equivalem à variação de espaço livre do volume.

## Backup SQL da tabela alvo

Somente db/execute admite backup_scope:selected_tables: uma instrução DML, uma tabela base InnoDB com identidade estável, sem outras fontes, joins, views, triggers ou chaves estrangeiras não modeladas. A tabela vem da análise SQL. DDL, db/batch e db/search-replace mantêm backup integral. Escopo reduzido inelegível recebe backup_scope_unsupported na prévia, sem escrita. Omitir o campo conserva database, inclusive em confirmações preparadas pela 0.21.0.

```json
{"ability_name":"db/execute","parameters":{"sql":"UPDATE wp_exemplo SET valor='novo' WHERE id=1","backup_scope":"selected_tables"}}
```

Substitua wp_exemplo pelo alvo real permitido; o exemplo não deve ser aplicado literalmente. A prévia informa backup_scope e backup_tables, vinculados à confirmação. O dump inclui a tabela inteira, contém valores originais e é produzido/verificado na mesma conexão protegida antes da escrita. Falha de backup impede mutação. A resposta inclui backup_id/artifact_id, backup_bytes e backup_contains_sensitive_values.

O restore escreve apenas as tabelas do manifesto e preserva o estado MCP corrente conforme preserved-state/1. A prévia declara restore_tables e restores_entire_tables:true: alterações posteriores da tabela podem ser perdidas. Atividade fora do manifesto não altera a guarda do destino. O restore cria pré-imagem integral de segurança, classificada restore_preimage; considere esse custo ao estimar economia.

