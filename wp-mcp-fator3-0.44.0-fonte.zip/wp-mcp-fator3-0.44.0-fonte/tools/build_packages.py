#!/usr/bin/env python3
"""Build and verify the versioned installer before replacing any previous artifact."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

import build


def runtime_digest(members):
    digest = hashlib.sha256()
    for path, content in sorted(members.items()):
        digest.update(path.encode() + b'\0' + hashlib.sha256(content).digest())
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--review', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    tools = build.ROOT/'tools'
    subprocess.run([sys.executable, str(tools/'check_documentation.py')], check=True)
    members = build.inventory()
    destination = args.out or build.ROOT
    destination.mkdir(parents=True, exist_ok=True)
    filename = f'wp-mcp-fator3-{build.version()}-instalador.zip'
    with TemporaryDirectory(dir=destination) as staging:
        candidate = Path(staging)/filename
        build.write_zip(candidate, members)
        result = build.audit(candidate, members)
        subprocess.run([sys.executable, str(tools/'check_package.py'), str(candidate)], check=True)
        candidate.replace(destination/filename)
    report = {'version':build.version(), 'runtime_sha256':runtime_digest(members),
              'installer':{k:v for k,v in result.items() if k != 'members_sha256'}, 'published':False}
    (build.ROOT/'evidencias/package.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
