#!/usr/bin/env python3
"""Validate the shipped guide against canonical Markdown, release data and installed schemas."""
import argparse
import json
from pathlib import Path
import re

from sync_docs import ROOT, catalogue, render

EXAMPLE_DOCS = ("administracao", "guia-agentes", "operacao", "atualizacao")
EXAMPLE = re.compile(r"```json\n(.*?)\n```(?:\s*Resposta: ([^\n]+))?", re.S)
VERSION = r"\b\d+\.\d+\.\d+\b"


def examples(documents):
    for identifier in EXAMPLE_DOCS:
        for m in EXAMPLE.finditer(documents[identifier]["content"]):
            yield identifier, json.loads(m[1]), m[2] or ""


def schema_accepts(schema, values):
    props = schema.get("properties") or {}
    if not isinstance(values, dict) or not set(values) <= set(props) or not set(schema.get("required", [])) <= set(values):
        return False
    types = {"boolean": bool, "integer": int, "number": (int, float), "string": str, "array": list, "object": dict}
    for key, value in values.items():
        field = props[key]
        permitted = field.get("type")
        permitted = permitted if isinstance(permitted, list) else [permitted]
        if not any(t not in types or isinstance(value, types[t]) and not (t in ("integer", "number") and isinstance(value, bool)) for t in permitted):
            return False
        if "enum" in field and value not in field["enum"]:
            return False
        if type(value) in (float, int) and not field.get("minimum", value) <= value <= field.get("maximum", value):
            return False
    return True


def verify(root):
    checks = []
    def check(name, passed):
        checks.append({"name": name, "passed": bool(passed)})
    def load(file):
        return json.loads((root / "docs" / file).read_text())
    docs = catalogue(root)
    spec = load("RELEASE-SPEC.json")
    contract = load("CONTRATOS-INSTALADOS.json")
    version = (root / "VERSION").read_text().strip()
    abilities = contract["abilities"]
    plugin = root / "fontes/wp-mcp-fator3"
    def props(name, which="input_schema"):
        return abilities.get(name, {}).get(which, {}).get("properties") or {}
    manual = docs["operacao"]["content"]
    update = docs["atualizacao"]["content"]
    release = docs.get("release-" + version.replace(".", ""), {}).get("content", "")
    check("Current package contract", version == spec["version"] == contract["package_header_version"] == contract["implementation_target"])
    check("Single release scope", bool(spec.get("local_plan_ids") or spec["ids"]) and spec["canonical"]["release"] == "RELEASE-" + version.replace(".", "") + ".md")
    check("Supported inputs", "clean" in spec["inputs"] and any(re.fullmatch(VERSION, v) for v in spec["inputs"]) and
          all(v in update and v in release for v in spec["inputs"] if v != "clean"))
    providers = {p["id"]: p["version"] for p in contract["providers"]}
    check("Local companion matrix", bool(spec["companions"]) and all(providers.get(slug) == v for slug, v in spec["companions"].items()))
    check("Versioned release notes", len(release.encode()) >= 1400 and all(v in release for v in spec["companions"].values()))
    for identifier, doc in docs.items():
        body = doc["content"]
        check("Index metadata: " + identifier, doc["kind"] in {"guia", "historico", "release", "contrato"} and all(doc[k].strip() for k in ("title", "description", "next_step")))
        if doc["kind"] in ("guia", "contrato"):
            check("Title and version: " + identifier, bool(re.match(r"^# [^\n]+\n", body)) and not re.search(VERSION, doc["title"])
                  and re.findall(r"^Versão documentada: (\d+\.\d+\.\d+)\.", body, re.M) == [version])
        if identifier in EXAMPLE_DOCS or identifier == "indice":
            for link in re.findall(r"\[[^]\n]+\]\(([^)\s]+)\)", body):
                check("Internal link: " + identifier + "/" + link, link in docs)
    declared = set(re.findall(VERSION, manual)) - {version, spec["requires"]["wordpress"], spec["requires"]["php"]}
    check("Current operating manual", not declared and not re.search(r"^#{1,6} .*?"+VERSION, manual, re.M) and "release-"+version.replace(".", "") in manual)
    check("Historical manual retained", docs["historico"]["kind"] == "historico" and "(historico)" in docs["indice"]["content"])
    check("Canonical guide equals compiled PHP", (plugin/"includes/guide-documents.php").read_text() == render(docs))
    check("Single compiled manual", not (plugin/"includes/guide-content.php").exists())
    for label, ex, _ in examples(docs):
        if "ability_name" in ex:
            name = ex["ability_name"]
            check("Documented example: " + label + "/" + name, name in abilities and schema_accepts(abilities[name]["input_schema"], ex.get("parameters")))
        else:
            # The live verifier also checks the installed metatool schema and executes its examples.
            check("Metatool example: " + label, ex.get("tool") in ("wp-mcp-ultimate-discover-abilities", "wp-mcp-ultimate-get-ability-info") and isinstance(ex.get("arguments"), dict))
    for name in ("plugins/upload", "plugins/upload-base64"):
        check(name+" defaults remain false", all(props(name)[f].get("default") is False for f in ("activate","overwrite")))
    for name, pairs in {"content/update-page":[("parent","parent_id")],"plugins/list":[("fields","campos"),("prefixes","prefixo")],
                        "files/write":[("label","rotulo")],"db/schema":[("exact","contar")]}.items():
        for first, second in pairs:
            p = props(name)
            check(name+" alias "+second, first in p and second in p and p[first]["type"] == p[second]["type"])
    required = {"files/read":["offset_bytes","cursor","compression","grep","tail_lines"], "content/patch-page":["expected_revision","limit","all"],
                "system/maintenance":["max_total_bytes","expected_selection_sha256"],"system/guide":["topic","ability"],
                "db/restore":["allow_changed_destination"], "db/search-replace":["columns"], "system/settings-update":["sql_retention"]}
    for name, fields in required.items():
        check(name+" documented contract", set(fields) <= set(props(name)))
    check("Plan excludes SQL mutation", "db/execute" not in props("operations/plan")["steps"]["items"]["properties"]["ability"]["enum"])
    for name in ("db/query-export","db/export","db/restore","db/search-replace","db/batch","connections/list","connections/update","connections/revoke",
                 "system/settings","system/settings-update","cron/list","cron/run","themes/upload","themes/activate","themes/update","themes/delete",
                 "themes/rollback","files/archive","files/extract","roles/delete","roles/restore"):
        check("Contract present: "+name, name in abilities)
    for name in ("db/execute","db/batch","db/search-replace"):
        check(name+" guard output", {"guard_contract","conflict_reason"} <= set(props(name,"output_schema")))
    for key, doc in (("sql_guard","sql-guard"), ("server_contract","server-integration")):
        check("Canonical contract: "+key, spec[key] in docs[doc]["content"])
    check("SQL categories", props("backups/list")["category"]["enum"] == ["backups","sql_mutation","sql_artifacts"])
    check("Optional scope preserves old tokens", "default" not in props("db/execute")["backup_scope"])
    header = (plugin/"wp-mcp-fator3.php").read_text()
    uri = re.search(r"^ \* Update URI:\s+(\S+)", header, re.M)
    check("Update URI matches both guides", uri and all("Update URI: "+uri[1] in text for text in (manual, update)))
    check("Probe contract documented", props("system/probe")["contexto_teste"]["type"] == "boolean" and "(probe-audit)" in manual and
          all(k in manual and k in docs["probe-audit"]["content"] for k in ("traffic_class_scope","outgoing_request","passed","cache_bypass_verified")))
    check("No runtime baseline gate", spec["inputs_are_test_baselines_not_runtime_gate"] is True and "sem trava por versão de origem" in manual)
    check("Removed migration runtime absent", all(not (plugin/"includes"/p).exists() for p in ("Upgrade015.php","Upgrade016.php")))
    for ref in spec["canonical"].values():
        check("Canonical specification: "+ref, (root/"docs"/ref).is_file())
    transport = (plugin/"core/includes/Server/Transport/HttpTransport.php").read_text()
    check("Transport diagnostics", all(k in manual and k in transport for k in ("mcp_authentication_required","mcp_permission_denied")))
    for name in ("plugins/upload","plugins/upload-base64","plugins/update","plugins/reconcile"):
        timeout = props(name)["probe_timeout_seconds"]
        check(name+" probe timeout", (timeout["minimum"], timeout["maximum"]) == (1,30))
    check("Uncertain package result", "null" in props("plugins/upload","output_schema")["applied"]["type"])
    for name, readonly in (("plugins/operation-status",True),("plugins/reconcile",False)):
        check("Package status and reconcile: "+name, abilities[name]["meta"]["annotations"]["readonly"] is readonly)
    check("Separate package journal", "package_operation_id" in props("plugins/upload","output_schema") and "package_operation_id" in manual)
    check("Uninstall preference documented", all(s in update for s in ("Por padrão","site individual","senhas de aplicação nativas","multisite")))
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args()
    version = (args.root/"VERSION").read_text().strip()
    try:
        checks = verify(args.root)
    except (OSError, ValueError, KeyError, TypeError) as err:
        checks = [{"name": str(err), "passed": False}]
    failures = [c["name"] for c in checks if not c["passed"]]
    target = args.root / "evidencias" / version.replace(".", "") / "documentation.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps({"version":version, "tests":len(checks),"failures":len(failures),"checks":checks}, ensure_ascii=False, indent=2)+"\n")
    print(f"{len(checks)} verificações documentais, {len(failures)} falhas.")
    for failure in failures:
        print("FAIL", failure)
    return bool(failures)


if __name__ == "__main__":
    raise SystemExit(main())
