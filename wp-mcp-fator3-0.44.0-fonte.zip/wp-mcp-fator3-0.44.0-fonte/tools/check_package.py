#!/usr/bin/env python3
"""Verify a built installer against the release contract and an independent distribution policy."""
import argparse
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import tempfile
import zipfile

import build


def _runtime_paths(names):
    for name in names:
        path = PurePosixPath(name)
        parts = path.parts[1:] if path.parts[:1] == ('wp-mcp-fator3',) else path.parts
        if any(part.lower() in {'docs', 'tests'} for part in parts) or parts[:1] == ('tools',):
            raise ValueError('Development directory in installer: ' + name)
        if path.name.lower().endswith('-pt_br.json'):
            raise ValueError('Public translation catalog in installer: ' + name)


def verify_runtime(zip_path, *, baseline=None, php=None, php_ini=None):
    spec = json.loads((build.ROOT / 'docs/RELEASE-SPEC.json').read_text())
    version = build.version()
    if spec['version'] != version:
        raise ValueError('RELEASE-SPEC version differs from VERSION')
    previous = [value for value in spec['inputs'] if value != 'clean']
    if len(previous) != 1 or not re.fullmatch(r'\d+\.\d+\.\d+', previous[0]):
        raise ValueError('RELEASE-SPEC must identify the upgrade baseline')

    # Inspect the declared paths independently: an accidental addition to the
    # allowlist must still fail (including generated docs/index.php).
    manifest = json.loads((build.ROOT / 'tools/runtime-manifest.json').read_text())
    _runtime_paths(manifest['files'])
    with zipfile.ZipFile(zip_path) as installer:
        _runtime_paths(installer.namelist())
    expected = build.inventory()
    audit = build.audit(zip_path, expected)
    with tempfile.TemporaryDirectory(prefix='f3-package-') as directory:
        again = Path(directory) / 'installer.zip'
        build.write_zip(again, expected)
        if again.read_bytes() != Path(zip_path).read_bytes():
            raise ValueError('Installer is not byte-identical to a clean rebuild')

    if baseline is not None:
        main = manifest['root'] + '/wp-mcp-fator3.php'
        with zipfile.ZipFile(baseline) as archive:
            header = re.search(r'^ \* Version:\s+(\S+)', archive.read(main).decode(), re.M)
        if not header or header[1] != previous[0]:
            raise ValueError('Baseline installer differs from RELEASE-SPEC')
    if php:
        command = [str(php)] + (['-c', str(php_ini)] if php_ini else []) + ['-l']
        for name, data in expected.items():
            if name.endswith('.php'):
                lint = subprocess.run(command, input=data, capture_output=True)
                if lint.returncode:
                    raise ValueError('PHP syntax error in ' + name + ': ' + lint.stderr.decode(errors='replace'))
    return {'version': version, 'baseline_version': previous[0], 'sha256': audit['sha256'],
            'files': audit['files'], 'reproducible': True, 'php_lint': bool(php),
            'baseline_installer_checked': baseline is not None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('installer', type=Path, nargs='?')
    parser.add_argument('--zip', type=Path)
    parser.add_argument('--baseline', type=Path)
    parser.add_argument('--php')
    parser.add_argument('--php-ini')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if bool(args.installer) == bool(args.zip):
        parser.error('Supply one installer path')
    result = verify_runtime(args.installer or args.zip, baseline=args.baseline, php=args.php, php_ini=args.php_ini)
    report = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(report + '\n')
    print(report)


if __name__ == '__main__':
    main()
