<?php
/** Pedido 66: included by media.php in an isolated native WordPress lab. */
use Fator3\McpFiles\ContentTools;
use Fator3\McpFiles\DeletionSnapshot;
$schema=wp_get_ability('media/convert')->get_input_schema();
check('66 required revision and typed WebP contract',in_array('expected_revision',$schema['required'],true)&&$schema['properties']['formato']['enum']===['webp']);
$upload=wp_upload_dir();$created=[];$origins=[];
foreach(['jpeg','png','large'] as $kind){
    $png=$kind==='png';$width=$kind==='large'?3100:640;$height=$kind==='large'?300:480;
    $path=$upload['path'].'/f3-convert-'.bin2hex(random_bytes(5)).($png?'.png':'.jpg');$image=imagecreatetruecolor($width,$height);
    if($png){imagealphablending($image,false);imagesavealpha($image,true);imagefill($image,0,0,imagecolorallocatealpha($image,0,0,0,127));}
    imagefilledrectangle($image,20,20,$width-20,$height-20,imagecolorallocate($image,30,90,180));
    if($png)imagepng($image,$path);else imagejpeg($image,$path,90);imagedestroy($image);
    $source=wp_insert_attachment(wp_slash(['post_title'=>"Título 'teste' \\ $kind",'post_excerpt'=>"Legenda 'teste' \\ $kind",'post_mime_type'=>$png?'image/png':'image/jpeg','post_status'=>'inherit']),$path);
    update_post_meta($source,'_wp_attachment_image_alt',wp_slash("Alt 'teste' \\ $kind"));wp_update_attachment_metadata($source,wp_generate_attachment_metadata($source,$path));$origins[]=$source;
    $snapshot=DeletionSnapshot::post($source);$read=call('media/get',['id'=>$source]);$revision=$read['revision']??'';check('66 public media/get supplies exact revision', $revision===ContentTools::revision($source),$read);$key='convert66-'.$source.'-'.bin2hex(random_bytes(4));
    $args=['id'=>$source,'formato'=>'webp','expected_revision'=>$revision,'idempotency_key'=>$key];if($png)$args['qualidade']=75;
    $r=call('media/convert',$args);$new=(int)($r['id']??0);if($new)$created[]=$new;
    check('66 '.$kind.' converted new WebP',!empty($r['success'])&&$new!==$source&&$new>0&&get_post_mime_type($new)==='image/webp',$r);
    if(!$new)continue;
    check('66 '.$kind.' title alt caption exact',get_the_title($new)===get_the_title($source)&&get_post($new)->post_excerpt===get_post($source)->post_excerpt&&get_post_meta($new,'_wp_attachment_image_alt',true)===get_post_meta($source,'_wp_attachment_image_alt',true),$r);
    $valid=count($r['files']??[])>2;foreach($r['files']??[] as $entry){$f=dirname(get_attached_file($new)).'/'.$entry['file'];$valid=$valid&&str_ends_with($f,'.webp')&&is_file($f)&&wp_getimagesize($f)['mime']==='image/webp'&&filesize($f)===$entry['bytes']&&hash_file('sha256',$f)===$entry['sha256'];}
    check('66 '.$kind.' every derivative real MIME bytes hash',$valid,$r);
    check('66 '.$kind.' source post metadata and all files unchanged',$snapshot===DeletionSnapshot::post($source)&&$revision===ContentTools::revision($source)&&!empty($r['original_preserved']),$r);
    check('66 '.$kind.' savings against original, revisions not confused',($r['savings_bytes']??null)===filesize($path)-($r['files']['converted_original']['bytes']??0)&&($r['revision']??'')===ContentTools::revision($new)&&($r['source_revision']??'')===$revision,$r);
    $repeat=call('media/convert',$args);check('66 '.$kind.' same intent replays without duplicate',($repeat['id']??0)===$new&&!empty($repeat['replayed']),$repeat);
    if($png){$out=imagecreatefromwebp(get_attached_file($new));check('66 PNG transparency retained',(imagecolorat($out,0,0)>>24&0x7f)>120);imagedestroy($out);}
    if($kind==='large')check('66 large uses unscaled original and keeps both WebP files',($r['files']['converted_original']['width']??0)===$width&&($r['files']['full']['width']??0)<$width,$r);
}
$source=$origins[0];$revision=ContentTools::revision($source);
$count=static fn()=>(int)$GLOBALS['wpdb']->get_var("SELECT COUNT(*) FROM {$GLOBALS['wpdb']->posts} WHERE post_type='attachment'");
$baseline=$count();$before=glob($upload['path'].'/*');
$r=call('media/convert',['id'=>$source,'formato'=>'webp','expected_revision'=>'stale']);check('66 stale revision no attachment',($r['error_code']??'')==='content_conflict'&&$count()===$baseline,$r);
foreach([['formato'=>'gif','expected_revision'=>$revision],['formato'=>'webp'],['formato'=>'webp','expected_revision'=>$revision,'qualidade'=>101]] as $invalid){$r=call('media/convert',['id'=>$source]+$invalid);check('66 invalid contract no attachment',empty($r['success'])&&$count()===$baseline,$r);}
$disable=static fn()=>[];add_filter('wp_image_editors',$disable,PHP_INT_MAX);
$r=call('media/convert',['id'=>$source,'formato'=>'webp','expected_revision'=>$revision]);remove_filter('wp_image_editors',$disable,PHP_INT_MAX);
check('66 no WebP explicit refusal before any media effect',($r['error_code']??'')==='media_webp_unsupported'&&($r['applied']??null)===false&&$count()===$baseline&&$before===glob($upload['path'].'/*'),$r);
// Hold the same sidecar from an independent descriptor: conversion must not pass either lock.
foreach(['post:'.get_current_blog_id().':'.$source,'file:'.$upload['basedir']] as $key){
    $lock=fopen(\Fator3\McpFiles\StateStore::directory('locks').'/'.hash('sha256',$key).'.php','c+b');flock($lock,LOCK_EX);
    $r=call('media/convert',['id'=>$source,'formato'=>'webp','expected_revision'=>$revision]);flock($lock,LOCK_UN);fclose($lock);
    check('66 source and upload locks serialize mutation',($r['error_code']??'')==='resource_busy'&&$count()===$baseline,$r);
}
$policy=\Fator3\McpFiles\Persistence::get('connections','integration:user:1');
foreach(['read','custom'] as $profile){\Fator3\McpFiles\Persistence::put('connections','integration:user:1',array_replace($policy,['profile'=>$profile,'abilities'=>[]]));$r=call('media/convert',['id'=>$source,'formato'=>'webp','expected_revision'=>$revision]);check('66 profile '.$profile.' refuses without grant',($r['error_code']??'')==='profile_denied'&&$count()===$baseline,$r);}
\Fator3\McpFiles\Persistence::put('connections','integration:user:1',$policy);
wp_set_current_user(0);$r=call('media/convert',['id'=>$source,'formato'=>'webp','expected_revision'=>$revision]);check('66 unauthenticated refused',empty($r['success'])&&$count()===$baseline,$r);wp_set_current_user(1);
class F3_Convert_Save_Failure extends WP_Image_Editor_GD { public function save($destfilename=null,$mime_type=null){return new WP_Error('synthetic_save_failure','Synthetic failure');} }
$bad_editor=static fn()=>['F3_Convert_Save_Failure'];add_filter('wp_image_editors',$bad_editor,PHP_INT_MAX);
$r=call('media/convert',['id'=>$source,'formato'=>'webp','expected_revision'=>$revision]);remove_filter('wp_image_editors',$bad_editor,PHP_INT_MAX);
check('66 editor save failure creates no attachment or file',($r['error_code']??'')==='media_conversion_save_failed'&&($r['applied']??null)===false&&$count()===$baseline&&$before===glob($upload['path'].'/*'),$r);
class F3_Convert_Wrong_Format extends WP_Image_Editor_GD { public function save($destfilename=null,$mime_type=null){return parent::save(substr($destfilename,0,-5).'.jpg','image/jpeg');} }
$wrong_editor=static fn()=>['F3_Convert_Wrong_Format'];add_filter('wp_image_editors',$wrong_editor,PHP_INT_MAX);
$r=call('media/convert',['id'=>$source,'formato'=>'webp','expected_revision'=>$revision]);remove_filter('wp_image_editors',$wrong_editor,PHP_INT_MAX);
check('66 unexpected editor output cleaned without touching source',($r['error_code']??'')==='media_conversion_save_failed'&&($r['applied']??null)===false&&$count()===$baseline&&$before===glob($upload['path'].'/*')&&!empty($r['original_preserved']),$r);
$mapping=static fn($map)=>array_merge($map,['image/webp'=>'image/jpeg']);add_filter('image_editor_output_format',$mapping,10);
$r=call('media/convert',['id'=>$source,'formato'=>'webp','expected_revision'=>$revision]);remove_filter('image_editor_output_format',$mapping,10);if(!empty($r['id']))$created[]=$r['id'];
check('66 explicit WebP survives site output mapping',!empty($r['success'])&&count(array_filter($r['files']??[],static fn($f)=>$f['mime_type']!=='image/webp'))===0,$r);
$drop=static fn($meta)=>[];add_filter('wp_generate_attachment_metadata',$drop,PHP_INT_MAX);
$r=call('media/convert',['id'=>$source,'formato'=>'webp','expected_revision'=>$revision]);remove_filter('wp_generate_attachment_metadata',$drop,PHP_INT_MAX);if(!empty($r['id']))$created[]=$r['id'];
check('66 generation failure reports new ID and applied partial',($r['error_code']??'')==='media_conversion_partial'&&!empty($r['id'])&&($r['applied']??null)===true&&!empty($r['partial'])&&!empty($r['original_preserved']),$r);
// A third-party save hook can throw after the row exists but before insertion returns its ID.
$prior_ids=$GLOBALS['wpdb']->get_col("SELECT ID FROM {$GLOBALS['wpdb']->posts} WHERE post_type='attachment'");
$throw=static function($new){if(get_post_mime_type($new)==='image/webp')throw new RuntimeException('synthetic insertion interruption');};add_action('add_attachment',$throw,PHP_INT_MAX);
$uncertain=['id'=>$source,'formato'=>'webp','expected_revision'=>$revision,'idempotency_key'=>'66-uncertain-'.$source];$r=call('media/convert',$uncertain);remove_action('add_attachment',$throw,PHP_INT_MAX);
$extra=array_diff($GLOBALS['wpdb']->get_col("SELECT ID FROM {$GLOBALS['wpdb']->posts} WHERE post_type='attachment'"),$prior_ids);$created=array_merge($created,$extra);
check('66 insert hook interruption preserves unknown effect and reconciliation',($r['error_code']??'')==='media_conversion_failed'&&array_key_exists('applied',$r)&&$r['applied']===null&&!empty($r['cleanup_required'])&&count($extra)===1,$r);
$n=$count();$replay=call('media/convert',$uncertain);check('66 uncertain insertion receipt never retries callback',!empty($replay['replayed'])&&$count()===$n&&array_key_exists('applied',$replay)&&$replay['applied']===null,$replay);
foreach($created as $new){$p=call('media/delete',['id'=>$new,'force'=>true]);$r=call('media/delete',['id'=>$new,'force'=>true,'confirm_token'=>$p['confirm_token']??'']);check('66 undo only new attachment',!empty($r['success'])&&!get_post($new)&&get_post($source)&&ContentTools::revision($source)===$revision,$r);}
foreach($origins as $origin)wp_delete_attachment($origin,true);
