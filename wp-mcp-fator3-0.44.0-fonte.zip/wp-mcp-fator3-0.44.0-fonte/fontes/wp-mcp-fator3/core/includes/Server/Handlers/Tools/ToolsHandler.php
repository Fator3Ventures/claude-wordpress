<?php
/**
 * Tools method handlers for MCP requests.
 *
 * @package McpAdapter
 */

declare( strict_types=1 );

namespace WpMcpUltimate\Server\Handlers\Tools;

use WpMcpUltimate\Server\McpRequestContext;
use WpMcpUltimate\Server\McpServer;
use WpMcpUltimate\Server\Domain\Utils\ContentBlockHelper;
use WpMcpUltimate\Server\Domain\Utils\McpValidator;
use WpMcpUltimate\Server\Handlers\HandlerHelperTrait;
use WpMcpUltimate\Server\Infrastructure\ErrorHandling\McpErrorFactory;
use WpMcpUltimate\Server\Infrastructure\Observability\FailureReason;
use WpMcpUltimate\McpSchema\Record\CallToolRequest;
use WpMcpUltimate\McpSchema\Record\ListToolsRequest;

/**
 * Handles tools-related MCP methods.
 */
class ToolsHandler {
	private const TEXT_JSON_FLAGS = JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
	use HandlerHelperTrait;

	/**
	 * Default MIME type for image results when none is specified.
	 *
	 * @var string
	 */
	private const DEFAULT_IMAGE_MIME_TYPE = 'image/png';

	/**
	 * The WordPress MCP instance.
	 *
	 * @var \WpMcpUltimate\Server\McpServer
	 */
	private McpServer $mcp;

	/**
	 * Constructor.
	 *
	 * @param \WpMcpUltimate\Server\McpServer $mcp The WordPress MCP instance.
	 */
	public function __construct( McpServer $mcp ) {
		$this->mcp = $mcp;
	}

	/**
	 * Handles the tools/list request.
	 *
	 * Returns logical data for exact revision projection.
	 * Tool records are protocol-only; internal adapter metadata is stored in McpTool instances and is never exposed
	 * to MCP clients.
	 *
	 * @param \WpMcpUltimate\McpSchema\Record\ListToolsRequest $request Validated request.
	 * @param \WpMcpUltimate\Server\McpRequestContext $request_context Exact request context.
	 * @return array<string, mixed> Logical tools-list result.
	 * @since n.e.x.t
	 */
	public function list_tools( ListToolsRequest $request, McpRequestContext $request_context ): array {
		unset( $request );
		$schema = $request_context->schema();
		$tools  = array_values( $this->mcp->get_tools( $schema ) );
        if(empty(\Fator3\McpFiles\ConnectionContext::get()['readonly_executor']))$tools=array_values(array_filter($tools,static fn($tool)=>$tool->getName()!==\WpMcpUltimate\Server\Domain\Utils\McpNameSanitizer::sanitize_name(\Fator3\McpFiles\ReadExecutor::NAME)));

		/**
		 * Filters the list of tools before returning to the client.
		 *
		 * Use this filter to hide tools per user/role, add dynamic tools,
		 * or reorder the tools list.
		 *
		 * @since 0.5.0
		 *
		 * @param array<\WpMcpUltimate\McpSchema\Record\Tool> $tools  Array of Tool records.
		 * @param \WpMcpUltimate\Server\McpServer                     $server The MCP server instance.
		 * @param \WpMcpUltimate\McpSchema\Schema                        $schema Selected schema.
		 */
		$tools = $this->validate_filtered_list(
			apply_filters( 'f3_mcp_tools_list', $tools, $this->mcp, $schema ),
			$tools,
			'f3_mcp_tools_list',
			$this->mcp->get_error_handler()
		);

		return array( 'tools' => $tools );
	}

	/**
	 * Handles the tools/call request.
	 *
	 * Returns either logical tool-result data or a protocol error array.
	 *
	 * The MCP spec distinguishes between:
	 * 1. **Protocol errors** (tool not found, server error) → JSONRPCErrorResponse
	 * 2. **Tool execution errors** (permission denied, runtime error) → CallToolResult with isError=true
	 *
	 * This distinction is critical for LLM self-correction - execution errors are
	 * visible to the LLM, while protocol errors indicate infrastructure issues.
	 *
	 * @param \WpMcpUltimate\McpSchema\Record\CallToolRequest $request Validated request.
	 * @param \WpMcpUltimate\Server\McpRequestContext $request_context Exact request context.
	 *
	 * @return array<string, mixed>
	 * @since n.e.x.t
	 */
	public function call_tool( CallToolRequest $request, McpRequestContext $request_context ): array {
		$request_params = $request->getParams();
		$request_id     = $request->getId();
		$root_context = null;
		$presentation_context = [];

		try {
			$tool_name = $request_params->getName();
			$args      = $this->callback_arguments( $request_params->getArguments() );

			$mcp_tool = $this->mcp->get_mcp_tool( $tool_name );
			if ( ! $mcp_tool || ! $mcp_tool->is_available_for( $request_context->schema() ) ) {
				$this->mcp->get_error_handler()->log(
					'Tool not found',
					array(
						'tool_name' => $tool_name,
					),
					'warning'
				);

				return McpErrorFactory::tool_not_found( $request_id, $tool_name );
			}

			$root_context = \Fator3\McpFiles\RootToolContext::open($this->mcp, $mcp_tool->get_observability_context()['ability_name'] ?? '');
			$permission = $mcp_tool->check_permission( $args );
			if ( true !== $permission ) {
				$error_message = __( 'Permission denied', 'mcp-adapter' );
				if ( is_wp_error( $permission ) ) {
					$error_message = $permission->get_error_message();

					$this->mcp->get_error_handler()->log(
						'Tool permission check failed',
						array(
							'tool_name'      => $tool_name,
							'error_code'     => $permission->get_error_code(),
							// Permission diagnostics carry codes, never domain payloads.
							'failure_reason' => FailureReason::PERMISSION_CHECK_FAILED,
						)
					);
				}

				return $this->create_error_result( $error_message, is_wp_error($permission)?\Fator3\McpFiles\Result::error($permission):['success'=>false,'error_code'=>'permission_denied'] );
			}

			/**
			 * Filters tool arguments before execution, or short-circuits execution entirely.
			 *
			 * Return the (optionally modified) arguments array to proceed with execution,
			 * or return a WP_Error to block execution and return an error to the client.
			 *
			 * @since 0.5.0
			 *
			 * @param array                        $args      The tool arguments.
			 * @param string                       $tool_name The tool name being called.
			 * @param \WpMcpUltimate\Server\Domain\Tools\McpTool $mcp_tool  The MCP tool instance.
			 * @param \WpMcpUltimate\Server\McpServer       $server    The MCP server instance.
			 */
			$args = apply_filters( 'f3_mcp_pre_tool_call', $args, $tool_name, $mcp_tool, $this->mcp );

			// Allow pre-filter to short-circuit execution by returning WP_Error.
			if ( is_wp_error( $args ) ) {
				return $this->create_error_result( $args->get_error_message(), \Fator3\McpFiles\Result::error($args) );
			}

			$presentation_context = \Fator3\McpFiles\SafeOutput::call_context($mcp_tool->get_observability_context()['ability_name'] ?? '', $args);
			$result = $mcp_tool->execute( $args );

			/**
			 * Filters the tool execution result before response assembly.
			 *
			 * Use this filter for result transformation, PII redaction,
			 * audit logging, or content enrichment.
			 *
			 * @since 0.5.0
			 *
			 * @param mixed|\WP_Error              $result    The raw execution result (may be WP_Error).
			 * @param array                        $args      The tool arguments used.
			 * @param string                       $tool_name The tool name that was called.
			 * @param \WpMcpUltimate\Server\Domain\Tools\McpTool $mcp_tool  The MCP tool instance.
			 * @param \WpMcpUltimate\Server\McpServer       $server    The MCP server instance.
			 */
			$result = apply_filters( 'f3_mcp_tool_call_result', $result, $args, $tool_name, $mcp_tool, $this->mcp );

			if ( is_wp_error( $result ) ) {
				$this->mcp->get_error_handler()->log(
					'Tool execution returned WP_Error',
					array(
						'tool_name'     => $tool_name,
						'error_code'    => $result->get_error_code(),
						// Domain payloads/messages can contain secrets; log codes only.
					)
				);

				return $this->create_error_result( $result->get_error_message(), \Fator3\McpFiles\Result::error($result), $presentation_context );
			}

			// Expose top-level content markers before handling binary image data.
			if ( $result instanceof \JsonSerializable ) {
				$result = $result->jsonSerialize();
			}
			$structured_content = $result;
			if ( is_object( $result ) ) {
				$result = get_object_vars( $result );
			} elseif ( ! is_array( $result ) ) {
				$result             = array( 'result' => $result );
				$structured_content = $result;
			}

			// Backward compatibility: treat `{ success: false, error: string }` as tool execution error.
			if (
				array_key_exists( 'success', $result )
				&& false === $result['success']
				
			) {
				return $this->create_error_result( (string)($result['message']??$result['error']??'Falha na habilidade.'), $result, $presentation_context );
			}

			// Successful tool execution - build logical result data.

			// Handle embedded resource results (MCP ContentBlock type: "resource").
			// This allows tools to return text/blob resources using the MCP schema's EmbeddedResource content block.
			//
			// Two shapes are accepted, and they place `_meta` differently:
			//
			// - Nested `{ type, resource: { uri, text, _meta }, _meta }` maps one-to-one onto
			//   the record tree, so the outer `_meta` belongs to the content block and the inner
			//   one to the resource contents.
			// - Flat `{ type, uri, mimeType, text, _meta }` is a resource-contents literal
			//   carrying a `type` tag: every key beside `type` is a `ResourceContents` field,
			//   and `_meta` is declared there alongside them. Its `_meta` therefore describes
			//   the resource, which is what the same literal already means to
			//   `ResourcesHandler::create_content_data()`. A caller who needs block-level
			//   `_meta` writes the nested form, which exists to express that distinction.
			if ( isset( $result['type'] ) && 'resource' === $result['type'] ) {
				$is_nested     = isset( $result['resource'] ) && ( is_array( $result['resource'] ) || $result['resource'] instanceof \stdClass );
				$resource_item = $is_nested ? (array) $result['resource'] : $result;

				$uri       = $resource_item['uri'] ?? null;
				$mime_type = $resource_item['mimeType'] ?? null;

				if ( is_string( $uri ) ) {
					$uri = trim( $uri );
				}

				// Only return an EmbeddedResource if we have a valid URI and some content.
				$has_text = isset( $resource_item['text'] ) && is_string( $resource_item['text'] );
				$has_blob = isset( $resource_item['blob'] ) && is_string( $resource_item['blob'] );

				if ( is_string( $uri ) && '' !== $uri && ( $has_text || $has_blob ) ) {
					$block_meta    = $is_nested
						? $this->content_metadata( $result['_meta'] ?? null )
						: null;
					$resource_meta = $this->content_metadata( $resource_item['_meta'] ?? null );

					if ( $has_text ) {
						return array(
							'content' => array(
								ContentBlockHelper::embedded_text_resource(
									$uri,
									$resource_item['text'],
									is_string( $mime_type ) ? $mime_type : null,
									null,
									$block_meta,
									$resource_meta
								),
							),
							'isError' => false,
						);
					}

					if ( $has_blob ) {
						return array(
							'content' => array(
								ContentBlockHelper::embedded_blob_resource(
									$uri,
									$resource_item['blob'],
									is_string( $mime_type ) ? $mime_type : null,
									null,
									$block_meta,
									$resource_meta
								),
							),
							'isError' => false,
						);
					}
				}
			}

			// Handle image results.
			//
			// `type` marks this result as a description of a content block rather than tool
			// data, so its sibling `_meta` is the block's, which is the reading the `resource`
			// branch above already applies to the same key.
			if ( isset( $result['type'] ) && 'image' === $result['type'] && isset( $result['results'] ) ) {
				$image_data = base64_encode( $result['results'] ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
				$mime_type  = $result['mimeType'] ?? self::DEFAULT_IMAGE_MIME_TYPE;

				return array(
					'content' => array(
						ContentBlockHelper::image(
							$image_data,
							$mime_type,
							null,
							$this->content_metadata( $result['_meta'] ?? null )
						),
					),
					'isError' => false,
				);
			}

			// The generic fallback carries no `type` marker, so every key it holds is tool
			// data: the result is JSON-encoded into the text block and returned verbatim as
			// `structuredContent`. Reading `_meta` off it would give one key two meanings,
			// with nothing to tell metadata from a domain field.

			// Standard result - JSON-encode for text content, include as structuredContent.
			// Throw before WordPress's repair retry can change invalid serializer output.
			$json_text = wp_json_encode( $structured_content, self::TEXT_JSON_FLAGS );
			if ( false === $json_text ) {
				throw new \RuntimeException( 'Tool result cannot be JSON encoded.' );
			}

			if (strlen($json_text) > 2097152) return $this->create_error_result('Tool result exceeds transport limit; request a smaller page.', ['success'=>false,'error_code'=>'result_size_limit','limit_bytes'=>2097152,'partial'=>false,'data'=>null]);

			// Apply the same typed presentation to success/error. Decode once so custom
			// serializers cannot bypass redaction; preserve JSON objects and nulls.
			$presentation = \Fator3\McpFiles\SafeOutput::presentation(json_decode($json_text, false, 512, JSON_THROW_ON_ERROR), $presentation_context);
			$public = $presentation['value'];
			$json_text = wp_json_encode($public, self::TEXT_JSON_FLAGS);
			// Reuse the encoded value so nested serializers run once and JSON objects remain objects.
			return array(
				'content'           => array( ContentBlockHelper::text( $json_text ) ),
				'isError'           => false,
				'structuredContent' => json_decode( $json_text, false, 512, JSON_THROW_ON_ERROR ),
                '_meta' => ['fator3/redaction'=>$presentation['metadata']],
			);
		} catch ( \Throwable $exception ) {
			$this->mcp->get_error_handler()->log(
				'Error calling tool',
				array(
					'tool'      => $request_params->getName(),
					'exception' => 'tool_execution_exception',
				)
			);

			return McpErrorFactory::internal_error( $request_id, 'Failed to execute tool' );
		} finally {
			\Fator3\McpFiles\RootToolContext::close($root_context);
		}
	}

	/**
	 * Project an explicit content metadata object to the helper's associative view.
	 *
	 * @param mixed $meta Content metadata.
	 * @return array<string, mixed>|null
	 */
	private function content_metadata( $meta ): ?array {
		return McpValidator::normalize_meta( $meta instanceof \stdClass ? (array) $meta : $meta );
	}

	/**
	 * Create logical tool-execution error data from a message string.
	 *
	 * @since 0.5.0
	 *
	 * @param string $message The error message.
	 *
	 * @return array<string, mixed>
	 */
	private function create_error_result( string $message, array $data=[], array $presentation_context=[] ): array {
		$json=wp_json_encode($data+['success'=>false,'message'=>$message,'error_code'=>'tool_execution_failed'],self::TEXT_JSON_FLAGS);
        if(strlen($json)>2097152)$json=wp_json_encode(['success'=>false,'error_code'=>'result_size_limit','message'=>'Tool result exceeds transport limit; request a smaller page.','limit_bytes'=>2097152,'partial'=>false,'data'=>null],self::TEXT_JSON_FLAGS);
        $presentation=\Fator3\McpFiles\SafeOutput::presentation(json_decode($json,false,512,JSON_THROW_ON_ERROR),$presentation_context);
        $public=$presentation['value'];
        $json=wp_json_encode($public,self::TEXT_JSON_FLAGS);
        return ['isError'=>true,'structuredContent'=>$public,'content'=>[ContentBlockHelper::text($json)],'_meta'=>['fator3/redaction'=>$presentation['metadata']]];

	}
}
