<?php
/** Persisted protocol sessions. Identity is provided by authenticated credentials. */
declare(strict_types=1);
namespace WpMcpUltimate\Server\Transport\Infrastructure;
use Fator3\McpFiles\Persistence;
use Fator3\McpFiles\ConnectionContext;
use Fator3\McpFiles\Locks;
final class SessionManager {
    private static function timeout(): int { return max(60,(int)apply_filters('f3_mcp_session_inactivity_timeout',DAY_IN_SECONDS)); }
    private static function key(int $user,string $id): string { return $user.':'.$id; }
    public static function create_session(int $user,array $params=[], $error_handler=null) {
        if (!$user || !get_user_by('id', $user)) return false;
        try {
            $connection = ConnectionContext::key();
            $result = Locks::run(['connection:'.$connection=>LOCK_EX], static function() use ($user, $params, $connection) {
                if ($connection === 'unauthorized' || ConnectionContext::key() !== $connection) return false;
                $max = max(1, min(128, (int)apply_filters('f3_mcp_session_max_per_user', 32)));
                $id = wp_generate_uuid4();
                $now = time();
                $protocol = \WpMcpUltimate\Server\McpVersionNegotiator::negotiate((string)($params['protocolVersion'] ?? ''));
                $client = array_intersect_key($params, array_flip(['protocolVersion','clientInfo','capabilities']));
                $client['negotiatedProtocolVersion'] = $protocol;
                $session = ['session_id'=>$id, 'user_id'=>$user, 'connection_id'=>$connection,
                    'created_at'=>$now, 'last_activity'=>$now, 'last_activity_us'=>(int)(microtime(true)*1000000),
                    'negotiated_protocol_version'=>$protocol, 'client_params'=>$client, 'status'=>'active',
                    'expires'=>$now + self::timeout()];
                global $wpdb;
                $table = Persistence::table('sessions');
                self::cleanup_expired_sessions($user, $connection);
                $active = Persistence::rows($wpdb->prepare(
                    "SELECT id FROM `$table` WHERE bucket='sessions' AND user_id=%d AND connection_id=%s
                     AND status='active' AND expires_at>%d ORDER BY
                     COALESCE(CAST(JSON_EXTRACT(payload,'$.last_activity_us') AS UNSIGNED),
                              CAST(JSON_EXTRACT(payload,'$.last_activity') AS UNSIGNED)*1000000,0) DESC, id DESC",
                    $user, $connection, $now
                ));
                $evict = array_column(array_slice($active, $max - 1), 'id');
                if (!$evict) return Persistence::put('sessions', self::key($user,$id), $session, true) ? $id : false;

                // Publish the new key and retire the least recently active keys as one transaction.
                return self::rotate(static function() use ($user,$id,$session,$evict,$table) {
                    if (!Persistence::put('sessions', self::key($user,$id), $session, true)) return false;
                    $ids = implode(',', array_map('intval', $evict));
                    if (Persistence::query("UPDATE `$table` SET status='deleted',payload='{\"status\":\"deleted\"}',
                        revision=revision+1 WHERE id IN ($ids) AND status='active'") !== count($evict)) {
                        throw new \RuntimeException('session_rotation_conflict');
                    }
                    return $id;
                });
            });
            return is_string($result) ? $result : false;
        } catch (\Throwable $error) {
            return false;
        }
    }

    /** SQLite's WordPress drop-in translates the transaction on its process-local connection. */
    private static function rotate(callable $callback) {
        global $wpdb;
        if (!($wpdb instanceof \WP_SQLite_DB)) return Persistence::transaction($callback);
        if (false === $wpdb->query('START TRANSACTION')) throw new \RuntimeException('session_transaction_failed');
        try {
            $result = $callback();
            if (false === $wpdb->query('COMMIT')) throw new \RuntimeException('session_commit_failed');
            return $result;
        } catch (\Throwable $error) {
            $wpdb->query('ROLLBACK');
            throw $error;
        }
    }

    public static function get_session(int $user,string $id) {
        if(!$user||!preg_match('/^[a-zA-Z0-9-]{1,128}$/D',$id)) return false;
        $row=Persistence::get('sessions',self::key($user,$id));
        if(!$row||($row['_storage']['status']??'')!=='active'||(int)($row['expires']??0)<=time()) return false;
        if(empty($row['negotiated_protocol_version']))return false;
        if(isset($row['connection_id']) && $row['connection_id']!==ConnectionContext::key()) return false;
        return $row;
    }
    public static function validate_session(int $user,string $id,$error_handler=null): bool {
        $connection = ConnectionContext::key();
        return true === Locks::run(['connection:'.$connection=>LOCK_EX], static function() use ($user,$id) {
            $row = self::get_session($user,$id);
            if (!$row) return false;
            global $wpdb;
            $now = time();
            $expires = $now + self::timeout();
            $table = Persistence::table('sessions');
            $updated = Persistence::query($wpdb->prepare(
                "UPDATE `$table` SET updated_at=%d, expires_at=%d, revision=revision+1,
                 payload=JSON_SET(payload,'$.last_activity',%d,'$.last_activity_us',%d,'$.expires',%d)
                 WHERE record_key=%s AND status='active' AND expires_at>%d",
                $now, $expires, $now, (int)(microtime(true)*1000000), $expires,
                Persistence::hash('sessions', self::key($user,$id)), $now
            ));
            return $updated === 1;
        });
    }
    public static function delete_session(int $user,string $id,$error_handler=null): bool {
        return true===Locks::run(['connection:'.ConnectionContext::key()=>LOCK_EX],static function()use($user,$id) { if(!self::get_session($user,$id))return false;return Persistence::delete('sessions',self::key($user,$id)); });
    }
    public static function get_all_user_sessions(int $user): array {
        if (!$user) return [];
        $sessions = [];
        $before = PHP_INT_MAX;
        $now = time();
        do {
            $rows = Persistence::listing('sessions', ['user_id'=>$user,'status'=>'active'], 1000, $before);
            foreach ($rows as $row) {
                $before = $row['_row_id'];
                if ($row['expires'] > $now) $sessions[$row['session_id']] = $row;
            }
        } while (count($rows) === 1000);
        return $sessions;
    }
    public static function cleanup_expired_sessions(int $user, ?string $connection=null): int {
        global $wpdb;
        $table = Persistence::table('sessions');
        $where = $wpdb->prepare("bucket='sessions' AND user_id=%d AND status='active' AND expires_at<=%d", $user, time());
        if ($connection !== null) $where .= $wpdb->prepare(' AND connection_id=%s', $connection);
        $count = Persistence::query("UPDATE `$table` SET status='deleted',payload='{\"status\":\"deleted\"}',
            revision=revision+1 WHERE $where");
        if ($count === false) throw new \RuntimeException('session_cleanup_failed');
        return $count;
    }
}
