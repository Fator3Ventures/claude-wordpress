<?php
/** Executado pelo fluxo de exclusão do WordPress, depois da desativação. */
if (!defined('WP_UNINSTALL_PLUGIN') || WP_UNINSTALL_PLUGIN !== 'wp-mcp-fator3/wp-mcp-fator3.php') {
    exit;
}
require_once __DIR__.'/includes/OwnedState.php';
require_once __DIR__.'/includes/Uninstall.php';
try {
    \Fator3\McpFiles\Uninstall::remove();
} catch (\Throwable $e) {
    wp_die(esc_html($e->getMessage()), 'Fator3 MCP', ['response'=>500, 'back_link'=>true]);
}
