<?php
/** Public, local package registry and origin selection. No network on discovery. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class PackageDistribution {
    public const CONTRACT='package-distribution/1.0.0';
    public const SELECTION_OPTION='f3_mcp_distribution_selection';
    private static array $packages=[];
    private static array $errors=[];
    public static function capabilities(): array {
        return ['contract'=>self::CONTRACT,'schema_revision'=>1,'provider'=>'wp-mcp-fator3','registration_hook'=>'f3_mcp_register_packages','selection_option'=>self::SELECTION_OPTION,'methods'=>['capabilities','register','status','selection','manifest','guard'],'available'=>true];
    }
    public static function init(): void {
        foreach(UpdateChannel::PACKAGES as $slug=>$plugin)self::$packages[$slug]=['contract'=>self::CONTRACT,'package'=>$slug,'plugin'=>$plugin,'provider'=>$slug];
        add_action('plugins_loaded',static function(){do_action('f3_mcp_register_packages',self::CONTRACT);self::publish_selection();},6);
    }
    public static function register(array $descriptor) {
        $slug=$descriptor['package']??'';$plugin=$descriptor['plugin']??'';$provider=$descriptor['provider']??'';
        if(($descriptor['contract']??'')!==self::CONTRACT||array_diff(array_keys($descriptor),['contract','package','plugin','provider'])||!is_string($slug)||!preg_match('/^[a-z0-9][a-z0-9-]{0,100}$/D',$slug)||!is_string($plugin)||!preg_match('~^'.preg_quote($slug,'~').'/[a-zA-Z0-9_-]+\.php$~D',$plugin)||!is_string($provider)||!Providers::known($provider))return new \WP_Error('package_registration_invalid','Informe o pacote, o arquivo de entrada e o provedor registrado.');
        if(isset(self::$errors[$slug]))return new \WP_Error('package_registration_conflict','Há uma declaração conflitante para o pacote.');
        foreach(self::$packages as $name=>$existing)if(($name===$slug||$existing['plugin']===$plugin)&&$existing!=$descriptor){self::$errors[$slug]='package_registration_conflict';return new \WP_Error('package_registration_conflict','A identidade do pacote já está registrada.');}
        self::$packages[$slug]=$descriptor;return true;
    }
    public static function packages(): array {return array_map(static fn($d)=>$d['plugin'],self::$packages);}
    public static function status(): array {return self::capabilities()+['packages'=>array_values(self::$packages),'errors'=>self::$errors];}
    public static function selection(string $package): array {
        $descriptor=self::$packages[$package]??null;$channel=get_option('f3_mcp_update_channels',[])[$package]??null;
        $origin=!empty($channel['url'])?'mcp':'provider';
        return ['contract'=>self::CONTRACT,'package'=>$package,'provider'=>$descriptor['provider']??null,'plugin'=>$descriptor['plugin']??null,'available'=>$descriptor!==null&&!isset(self::$errors[$package]),'origin'=>$origin,'revision'=>hash('sha256',serialize([$descriptor,$channel,self::$errors[$package]??null])),'fallback_allowed'=>false];
    }
    /** Public receipt contains no feed URLs/secrets. Consumers keep MCP ownership if MCP is absent. */
    public static function publish_selection(): void {
        $receipt=['contract'=>self::CONTRACT,'packages'=>[]];
        foreach(self::$packages as $slug=>$unused)$receipt['packages'][$slug]=self::selection($slug);
        if(get_option(self::SELECTION_OPTION)!==$receipt)update_option(self::SELECTION_OPTION,$receipt,false);
    }
    public static function guard(array $snapshot) {
        $current=self::selection((string)($snapshot['package']??''));
        return !empty($current['available'])&&$current===$snapshot?true:new \WP_Error('distribution_selection_changed','A origem ou configuração da distribuição mudou. Solicite outra oferta.');
    }
    public static function manifest(string $package) {
        $selected=self::selection($package);
        if(!$selected['available'])return new \WP_Error('package_unregistered','O registro de pacotes está indisponível ou contém dados conflitantes.');
        if($selected['origin']!=='mcp')return new \WP_Error('distribution_not_selected','O MCP não é a origem de distribuição selecionada.');
        $manifest=UpdateChannel::manifest($package);$guard=self::guard($selected);
        return is_wp_error($guard)?$guard:$manifest;
    }
}
