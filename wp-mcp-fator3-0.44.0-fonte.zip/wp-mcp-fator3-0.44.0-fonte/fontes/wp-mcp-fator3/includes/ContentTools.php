<?php
/** Revision-aware content deployment and localized block editing. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class ContentTools {
	public static function revision(int $id): string {
        // Database representation is independent of WP_Post cache/filter/type state.
        global $wpdb;
        $posts=Persistence::rows($wpdb->prepare("SELECT * FROM `$wpdb->posts` WHERE ID=%d",$id));
        if (!$posts) return '';
        $post=$posts[0];ksort($post);foreach($post as &$v)if($v!==null)$v=(string)$v;unset($v);
        $meta=Persistence::rows($wpdb->prepare("SELECT meta_key,meta_value FROM `$wpdb->postmeta` WHERE post_id=%d ORDER BY meta_key,meta_id",$id));
        $terms=Persistence::rows($wpdb->prepare("SELECT term_taxonomy_id,term_order FROM `$wpdb->term_relationships` WHERE object_id=%d ORDER BY term_taxonomy_id",$id));
        foreach($meta as &$row)foreach($row as &$v)if($v!==null)$v=(string)$v;unset($row,$v);
        foreach($terms as &$row)foreach($row as &$v)if($v!==null)$v=(string)$v;unset($row,$v);
        return hash('sha256',serialize(['content-revision/2',$post,$meta,$terms]));
	}
	public static function permission(array $input = []): bool {
		$post = get_post((int)($input['id'] ?? 0));
		return $post && current_user_can('edit_post', $post->ID) && (!in_array($post->post_type, ['wp_template', 'wp_template_part', 'wp_navigation', 'wp_global_styles'], true) || current_user_can('edit_theme_options'));
	}
	public static function lock(array $input, callable $run): array {
		$id = (int)($input['id'] ?? 0);
		return Locks::run(['post:' . get_current_blog_id() . ':' . $id => LOCK_EX], static function () use ($id, $input, $run) {
			clean_post_cache($id);
			if (!get_post($id)) return Result::fail('not_found', 'O conteúdo não foi encontrado.');
			if (!self::permission($input)) return Result::fail('permission_denied', 'Você não tem permissão para editar este conteúdo.');
			if (isset($input['expected_revision']) && !hash_equals(self::revision($id), $input['expected_revision'])) return Result::fail('content_conflict', 'O conteúdo mudou desde a revisão informada.', ['conflict' => true, 'current_revision' => self::revision($id)]);
			return $run();
		});
	}
	public static function register(): void {
		$id = ['id' => Registry::integer(1), 'expected_revision' => Registry::string('Opaque revision from a read; checked under the post lock.')];
		Registry::add('content/untrash', 'Restore trashed content through WordPress. Already restored is a success without change.', $id, ['id'], [self::class, 'untrash'], [self::class, 'permission'], false);
		Registry::add('content/restore-revision', 'Restore a revision belonging to this content item and verify its fields.', $id + ['revision_id' => Registry::integer(1)], ['id', 'revision_id'], [self::class, 'restore'], [self::class, 'permission'], false);
		Registry::add('content/diff', 'Preview a content replacement or compare with a stored revision. Does not save.', ['id' => Registry::integer(1), 'content' => Registry::string(), 'revision_id' => Registry::integer(1)], ['id'], [self::class, 'diff'], [self::class, 'permission']);
		Registry::add('content/blocks', 'Read parsed Gutenberg blocks and an index of named-block paths (freeform fragments excluded). Includes template/navigation references.', ['id' => Registry::integer(1)], ['id'], [self::class, 'blocks'], [self::class, 'permission']);
		Registry::add('content/edit-block', 'Edit one named block by path. Attributes update the comment; supply inner_html when saved markup must change too. children replaces named children while preserving surrounding wrapper. inner_html is refused when the block contains children; use children, including [] for intentional removal. PHP structure checks do not validate editor JavaScript save output.', $id + ['block_path' => ['type' => 'array', 'items' => Registry::integer(0), 'minItems' => 1, 'maxItems' => 32], 'attributes' => ['type' => 'object'], 'inner_html' => Registry::string(), 'children' => ['type' => 'array', 'items' => ['type' => 'object'], 'maxItems' => 1000], 'preview' => Registry::boolean()], ['id', 'block_path'], [self::class, 'edit_block'], [self::class, 'permission'], false);
		Registry::add('content/upsert', 'Create or update content by a stable external_ref and post_type. Existing references converge to the same ID. Supports posts, pages and editable custom types including navigation/templates; taxonomy supplies wp_theme for templates.', ['external_ref' => ['type' => 'string', 'minLength' => 1, 'maxLength' => 256], 'post_type' => Registry::string('Default page.'), 'title' => Registry::string(), 'content' => Registry::string(), 'excerpt' => Registry::string(), 'status' => ['type' => 'string', 'enum' => ['draft', 'pending', 'private', 'publish']], 'slug' => Registry::string(), 'parent' => Registry::integer(), 'taxonomy' => ['type' => 'object', 'additionalProperties' => ['type' => 'array', 'items' => ['type' => ['string', 'integer']]]], 'expected_revision' => Registry::string()], ['external_ref'], [self::class, 'upsert'], static fn() => current_user_can('edit_posts') || current_user_can('edit_theme_options'), false);
	}
	public static function untrash(array $input): array {
		return self::lock($input, static function () use ($input) {
			$id = (int)$input['id']; $post = get_post($id);
			if ('trash' !== $post->post_status) return Result::ok(['id' => $id, 'changed' => false, 'status' => $post->post_status, 'revision' => self::revision($id)]);
			$result = wp_untrash_post($id); clean_post_cache($id); $post = get_post($id);
			if (!$result || !$post || 'trash' === $post->post_status) return Result::fail('untrash_failed', 'O WordPress não confirmou a restauração do conteúdo.');
			return Result::ok(['id' => $id, 'changed' => true, 'status' => $post->post_status, 'revision' => self::revision($id)]);
		});
	}
	public static function restore(array $input): array {
		return self::lock($input, static function () use ($input) {
			$id = (int)$input['id']; $revision_id = (int)$input['revision_id']; $revision = wp_get_post_revision($revision_id);
			if (!$revision || (int)$revision->post_parent !== $id) return Result::fail('revision_mismatch', 'A revisão não pertence ao conteúdo solicitado.');
			if (!wp_revisions_enabled(get_post($id))) return Result::fail('revisions_disabled', 'As revisões estão desativadas para este tipo de conteúdo.');
			$before = self::revision($id); wp_save_post_revision($id);
			$result = wp_restore_post_revision($revision->ID); clean_post_cache($id); $actual = get_post($id);
			if (!$result || is_wp_error($result)) return Result::fail('revision_restore_failed', 'O WordPress não restaurou a revisão.');
			foreach (array_keys(_wp_post_revision_fields($actual)) as $field) if ($actual->$field !== $revision->$field) return Result::fail('revision_restore_mismatch', 'Um campo restaurado difere da revisão selecionada.', ['id' => $id, 'field' => $field, 'revision' => self::revision($id)]);
			return Result::ok(['id' => $id, 'revision' => self::revision($id), 'changed' => $before !== self::revision($id)]);
		});
	}
	public static function diff(array $input): array {
		$post = get_post((int)$input['id']);
		if (!$post) return Result::fail('not_found', 'O conteúdo não foi encontrado.');
		if (isset($input['content']) === isset($input['revision_id'])) return Result::fail('invalid_diff', 'Informe somente um dos campos content e revision_id.');
		$proposed = $input['content'] ?? '';
		if (isset($input['revision_id'])) { $revision_id = (int)$input['revision_id']; $rev = wp_get_post_revision($revision_id); if (!$rev || (int)$rev->post_parent !== $post->ID) return Result::fail('revision_mismatch', 'A revisão pertence a outro conteúdo.'); $proposed = $rev->post_content; }
		if (strlen($post->post_content) + strlen($proposed) > 2097152) return Result::fail('diff_limit', 'Os textos a comparar somam mais de 2 MiB.');
		return Result::ok(['id' => $post->ID, 'revision' => self::revision($post->ID), 'changed' => $post->post_content !== $proposed, 'current_sha256' => hash('sha256', $post->post_content), 'proposed_sha256' => hash('sha256', $proposed), 'diff_html' => wp_text_diff($post->post_content, $proposed) ?: '', 'preview' => true]);
	}
	public static function upsert(array $input): array {
		$type = $input['post_type'] ?? 'page'; $obj = get_post_type_object($type);
		if (!$obj || in_array($type, ['attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset'], true)) return Result::fail('post_type_unsupported', 'Use a habilidade específica para este tipo de conteúdo.');
		if (!current_user_can($obj->cap->create_posts) || in_array($type, ['wp_navigation', 'wp_template', 'wp_template_part', 'wp_global_styles'], true) && !current_user_can('edit_theme_options')) return Result::fail('permission_denied', 'Você não tem permissão para criar este tipo de conteúdo.');
		if (in_array($input['status'] ?? 'draft', ['publish', 'private'], true) && !current_user_can($obj->cap->publish_posts)) return Result::fail('permission_denied', 'Você não tem permissão para publicar este tipo de conteúdo.');
		$key = $type . ':' . $input['external_ref'];
		return Locks::run(['content-ref:' . get_current_blog_id() . ':' . $key => LOCK_EX], static function () use ($type, $input, $key) {
			$state = StateStore::get('content-refs', $key); $id = (int)($state['id'] ?? 0);
			$marker = hash('sha256', $key);
			if (!$id) {
				$found = get_posts(['post_type' => $type, 'post_status' => array_keys(get_post_stati()), 'meta_key' => '_f3_external_ref', 'meta_value' => $marker, 'posts_per_page' => 2, 'fields' => 'ids', 'suppress_filters' => true]);
				if (count($found) > 1) return Result::fail('external_ref_conflict', 'Mais de um item possui esta referência.', ['conflict' => true]);
				$id = (int)($found[0] ?? 0);
			}
			if ($state && 'creating' === ($state['status'] ?? '') && !$id) return Result::fail('upsert_uncertain', 'A criação anterior não registrou um ID ou marcador. Verifique o conteúdo antes de criar novamente.');
			if ($id && !get_post($id)) return Result::fail('external_ref_deleted', 'A referência aponta para conteúdo excluído. Para recriá-lo, use uma nova referência.', ['id' => $id, 'conflict' => true]);
			$run = static function () use ($id, $type, $input, $key, $marker) {
				$post = $id ? get_post($id) : null;
				if ($post && 'trash' === $post->post_status) return Result::fail('content_in_trash', 'Restaure o conteúdo da lixeira antes de atualizar pela referência.', ['id' => $id]);
				if (!$id && isset($input['expected_revision'])) return Result::fail('content_conflict', 'A referência ainda não existe.', ['conflict' => true]);
				$data = ['post_type' => $type]; if ($id) $data['ID'] = $id; else $data += ['post_status' => 'draft', 'meta_input' => ['_f3_external_ref' => $marker]];
				foreach (['title' => 'post_title', 'content' => 'post_content', 'excerpt' => 'post_excerpt', 'status' => 'post_status', 'slug' => 'post_name', 'parent' => 'post_parent'] as $from => $to) if (isset($input[$from])) $data[$to] = $input[$from];
				if (strlen($data['post_content'] ?? '') > PathGuard::max_bytes()) return Result::fail('content_size_limit', 'O conteúdo excede o limite configurado em bytes.');
				foreach ($input['taxonomy'] ?? [] as $tax => $terms) { $taxonomy = get_taxonomy($tax); if (!$taxonomy || !is_object_in_taxonomy($type, $tax) || !current_user_can($taxonomy->cap->assign_terms)) return Result::fail('taxonomy_permission_denied', 'Sem permissão para atribuir a taxonomia: ' . $tax); }
				$before = $id ? self::revision($id) : '';
				if (!$id) StateStore::put('content-refs', $key, ['status' => 'creating', 'time' => time()]);
				$saved = $id ? wp_update_post(wp_slash($data), true) : wp_insert_post(wp_slash($data), true);
				if (is_wp_error($saved) || !$saved) { if (!$id) StateStore::delete('content-refs', $key); return is_wp_error($saved) ? Result::error($saved) : Result::fail('content_write_failed', 'Não foi possível salvar o conteúdo.'); }
				StateStore::put('content-refs', $key, ['id' => (int)$saved, 'status' => 'complete', 'time' => time()]);
				foreach ($input['taxonomy'] ?? [] as $tax => $terms) { $assigned = wp_set_object_terms($saved, $terms, $tax); if (is_wp_error($assigned)) return Result::fail('taxonomy_write_failed', $assigned->get_error_message(), ['id' => (int)$saved, 'partial' => true]); }
				clean_post_cache($saved);
				return Result::ok(['id' => (int)$saved, 'created' => !$id, 'changed' => $before !== self::revision($saved), 'revision' => self::revision($saved), 'sha256' => hash('sha256', get_post_field('post_content', $saved, 'raw')), 'link' => get_permalink($saved)]);
			};
			return $id ? self::lock($input + ['id' => $id], $run) : $run();
		});
	}
	/** Obtain byte ranges using WordPress's own block tokenizer, requiring balanced names. */
	private static function index(string $content) {
		$parser = new \WP_Block_Parser(); $parser->document = $content; $parser->offset = 0;
		$stack = []; $nodes = []; $counter = [0 => 0];
		while (true) {
			[$kind, $name, $attrs, $start, $length] = $parser->next_token();
			if ('no-more-tokens' === $kind) break;
			$parser->offset = $start + $length;
			if ('block-closer' === $kind) {
				if (!$stack) return new \WP_Error('block_structure_invalid', 'Há um fechamento de bloco sem abertura correspondente.');
				$key = array_pop($stack); if ($nodes[$key]['name'] !== $name) return new \WP_Error('block_structure_invalid', 'Os nomes de abertura e fechamento do bloco divergem.');
				$nodes[$key]['close_start'] = $start; $nodes[$key]['end'] = $start + $length; continue;
			}
			$depth = count($stack); if ($depth > 32 || count($nodes) >= 5000) return new \WP_Error('block_structure_limit', 'O documento excede o limite de profundidade ou quantidade de blocos.');
			$parent = $stack ? end($stack) : null; $path = null !== $parent ? $nodes[$parent]['path'] : []; $path[] = $counter[$depth] ?? 0; $counter[$depth] = ($counter[$depth] ?? 0) + 1;
			$key = implode('.', $path); $void = 'void-block' === $kind;
			$nodes[$key] = ['path' => $path, 'name' => $name, 'attributes' => $attrs ?: [], 'start' => $start, 'open_end' => $start + $length, 'close_start' => $start + $length, 'end' => $start + $length, 'void' => $void, 'parent' => $parent];
			if (!$void) { $stack[] = $key; $counter[$depth + 1] = 0; }
		}
		if ($stack) return new \WP_Error('block_structure_invalid', 'Há um bloco sem fechamento.');
		return $nodes;
	}
	public static function blocks(array $input): array {
		$post = get_post((int)$input['id']); if (!$post) return Result::fail('not_found', 'O conteúdo não foi encontrado.');
		if (strlen($post->post_content) > PathGuard::max_bytes()) return Result::fail('content_size_limit', 'O conteúdo excede o limite da resposta.');
		$index = self::index($post->post_content); if (is_wp_error($index)) return Result::error($index);
		$references = []; foreach ($index as $node) if (isset($node['attributes']['ref'])) $references[] = ['block_path' => $node['path'], 'ref' => $node['attributes']['ref'], 'name' => $node['name']];
		return Result::ok(['id' => $post->ID, 'post_type' => $post->post_type, 'revision' => self::revision($post->ID), 'sha256' => hash('sha256', $post->post_content), 'blocks' => parse_blocks($post->post_content), 'index' => array_values($index), 'references' => $references, 'validation' => 'PHP structure only; editor save validation is not performed.']);
	}
	private static function valid_children(array $blocks, int $depth = 0): bool {
		if ($depth > 32 || count($blocks) > 1000) return false;
		foreach ($blocks as $block) {
			if (!is_array($block) || !array_key_exists('blockName', $block) || !isset($block['attrs'], $block['innerBlocks'], $block['innerContent']) || !is_array($block['innerContent']) || !is_array($block['innerBlocks'])) return false;
			if (null !== $block['blockName'] && !is_string($block['blockName'])) return false;
			$n = 0; foreach ($block['innerContent'] as $part) { if (null === $part) $n++; elseif (!is_string($part)) return false; }
			if ($n !== count($block['innerBlocks']) || !self::valid_children($block['innerBlocks'], $depth + 1)) return false;
		}
		return true;
	}
	public static function edit_block(array $input): array {
		return self::lock($input, static function () use ($input) {
			$post = get_post((int)$input['id']); $content = $post->post_content;
			$nodes = self::index($content); if (is_wp_error($nodes)) return Result::error($nodes);
			$key = implode('.', $input['block_path']); $node = $nodes[$key] ?? null;
			if (!$node) return Result::fail('block_not_found', 'O caminho do bloco nomeado não existe.');
			if (!isset($input['attributes']) && !isset($input['inner_html']) && !isset($input['children'])) return Result::fail('block_change_required', 'Informe attributes, inner_html ou children.');
			if (isset($input['inner_html'], $input['children'])) return Result::fail('block_change_conflict', 'Informe somente um dos campos inner_html e children.');
			$open = substr($content, $node['start'], $node['open_end'] - $node['start']);
			$inner = substr($content, $node['open_end'], $node['close_start'] - $node['open_end']);
			$close = $node['void'] ? '' : substr($content, $node['close_start'], $node['end'] - $node['close_start']);
			$attrs = array_replace((array)$node['attributes'], $input['attributes'] ?? []);
            if(isset($input['attributes'])){
                $type=\WP_Block_Type_Registry::get_instance()->get_registered($node['name']);
                if(!$type)return Result::fail('block_type_unregistered','Não há schema PHP registrado para validar atributos deste bloco.');
                foreach($input['attributes'] as $key=>$value){
                    if(!isset($type->attributes[$key]))return Result::fail('block_attribute_unknown','Atributo sem schema registrado: '.$key);
                    if($value===null)continue;$schema=$type->attributes[$key];if(($schema['type']??'')==='rich-text')$schema['type']='string';
                    $valid=rest_validate_value_from_schema($value,$schema,'attributes.'.$key);if(is_wp_error($valid))return Result::error($valid);
                }
            }
			foreach ($attrs as $attr => $value) if (null === $value) unset($attrs[$attr]);
			if (isset($input['attributes'])) {
				$name = str_starts_with($node['name'], 'core/') ? substr($node['name'], 5) : $node['name'];
				$open = '<!-- wp:' . $name . ($attrs ? ' ' . serialize_block_attributes($attrs) : '') . ($node['void'] ? ' /-->' : ' -->');
			}
			if (isset($input['inner_html']) || isset($input['children'])) {
				if ($node['void']) return Result::fail('block_has_no_body', 'Self-closing blocks have no editable children/body.');
				if (isset($input['inner_html'])) {
					foreach ($nodes as $child) if ($child['parent'] === $key) return Result::fail('block_children_would_be_lost', 'inner_html descartaria filhos. Use children para substituí-los explicitamente.');
					$inner = $input['inner_html'];
				}
				else {
					if (!self::valid_children($input['children'])) return Result::fail('block_children_invalid', 'Os blocos filhos devem ter a estrutura de parse_blocks e posições correspondentes em innerContent.');
					$children = array_values(array_filter($nodes, static fn($n) => $n['parent'] === $key));
					for ($i = 1; $i < count($children); $i++) if (trim(substr($content, $children[$i-1]['end'], $children[$i]['start'] - $children[$i-1]['end'])) !== '') return Result::fail('block_structure_unsupported', 'HTML intermediário entre filhos exige edição que preserve sua estrutura.');
					$prefix = $children ? substr($content, $node['open_end'], $children[0]['start'] - $node['open_end']) : $inner;
					$last = $children ? end($children) : null;
					$suffix = $last ? substr($content, $last['end'], $node['close_start'] - $last['end']) : '';
					$inner = $prefix . serialize_blocks($input['children']) . $suffix;
				}
			}
			$next = substr($content, 0, $node['start']) . $open . $inner . $close . substr($content, $node['end']);
			if (strlen($next) > PathGuard::max_bytes()) return Result::fail('content_size_limit', 'O resultado excede o limite do conteúdo em bytes.');
			$valid = self::index($next); if (is_wp_error($valid)) return Result::error($valid);
			$data = ['id' => $post->ID, 'changed' => $content !== $next, 'sha256' => hash('sha256', $next), 'validation' => 'PHP structure only; validate saved markup with the editor.'];
			if (!empty($input['preview'])) return Result::ok($data + ['preview' => true, 'content' => $next, 'revision' => self::revision($post->ID)]);
			if ($content !== $next) { $result = wp_update_post(wp_slash(['ID' => $post->ID, 'post_content' => $next]), true); if (is_wp_error($result)) return Result::error($result); }
			clean_post_cache($post->ID); $actual = get_post_field('post_content', $post->ID, 'raw');
			if ($actual !== $next) return Result::fail('content_filtered', 'O conteúdo gravado diverge do solicitado após a aplicação dos filtros do WordPress.', ['id' => $post->ID, 'revision' => self::revision($post->ID), 'sha256' => hash('sha256', $actual)]);
			return Result::ok($data + ['revision' => self::revision($post->ID)]);
		});
	}
}
