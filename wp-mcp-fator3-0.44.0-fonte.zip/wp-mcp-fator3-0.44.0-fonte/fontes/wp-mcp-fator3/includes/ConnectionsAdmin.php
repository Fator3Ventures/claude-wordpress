<?php
/** Local administrator management. No secrets are displayed or accepted as identity. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class ConnectionsAdmin {
    public static function init(): void { add_action('admin_post_f3_mcp_connection',[self::class,'submit']);
        add_action('load-tools_page_wp-mcp-fator3',static function() {
            if (($_SERVER['REQUEST_METHOD']??'')==='POST' && ($_POST['action']??'')==='f3_mcp_connection') self::submit();
        }); }
    public static function save(array $input): array {
        if(!current_user_can('manage_options'))return Result::fail('permission_denied','Permissão insuficiente.');
        $id=(string)($input['connection_id']??'');$user=(int)($input['user_id']??0);
        if(!$user||!get_userdata($user)||!current_user_can('edit_user',$user))return Result::fail('connection_user_invalid','Selecione um usuário que você possa gerenciar.');
        if(($input['intent']??'')==='create')return self::issue($user,$input);
        if(str_starts_with($id,'app:')) {
            $uuid=substr($id,4);$item=\WP_Application_Passwords::get_user_application_password($user,$uuid);
            if(!$item && !(($input['intent']??'')==='revoke' && (int)(Persistence::get('connections',$id)['user_id']??0)===$user))return Result::fail('connection_credential_missing','Senha de aplicação não existe para esse usuário.');
        } elseif($id==='integration:user:'.$user) { /* Explicit server-side user mapping; not per-credential isolation. */ }
        elseif(str_starts_with($id,'grant:')) {
            $grant=Persistence::get('oauth-grants',substr($id,6));
            if(!$grant||(int)$grant['user_id']!==$user)return Result::fail('connection_grant_missing','Concessão não pertence ao usuário.');
        } else return Result::fail('connection_invalid','Selecione uma identidade autenticada ou o usuário da integração.');
        return Locks::run(['connection:'.$id=>LOCK_EX],static function()use($input,$id,$user) {
            $old=Persistence::get('connections',$id)??['time'=>time()];
            if (!empty($input['_existing_form']) && !isset($old['_storage'])) {
                return Result::fail('connection_not_found','O cliente já não está disponível. Volte à lista de clientes.');
            }
            // A blank association form must never overwrite an existing policy, even a revision-zero record.
            if (($input['intent']??'')==='associate' && isset($old['_storage'])) {
                return Result::fail('connection_policy_conflict','Esta identidade já tem um perfil. Use Editar na lista de clientes.',['conflict'=>true]);
            }
            if(isset($input['expected_policy_version']) && (int)$input['expected_policy_version'] !== (int)($old['policy_version']??0))return Result::fail('connection_policy_conflict','O perfil foi alterado em outra tela. Reabra a identidade antes de salvar ou revogar.',['conflict'=>true]);
            if(($input['intent']??'')==='revoke') {
                if(str_starts_with($id,'app:') && \WP_Application_Passwords::get_user_application_password($user,substr($id,4))) { $r=\WP_Application_Passwords::delete_application_password($user,substr($id,4));if(is_wp_error($r))return Result::fail('credential_revocation_failed','Não foi possível revogar a senha.'); }
                if(str_starts_with($id,'grant:')) { $key=substr($id,6);$grant=Persistence::get('oauth-grants',$key);$grant['status']='revoked';Persistence::put('oauth-grants',$key,$grant); }
                $was_revoked=($old['status']??'')==='revoked';$old['policy_version']=(int)($old['policy_version']??0)+(int)!$was_revoked;$old['status']='revoked';$old['user_id']=$user;$old['connection_id']=$id;Persistence::put('connections',$id,$old);
                try {Persistence::revoke_sessions($id);}catch(\Throwable $error){return Result::fail('session_revocation_pending','Identidade revogada; marcação das sessões pendente. As chamadas continuam bloqueadas pelo contexto.',['revoked'=>true,'connection_id'=>$id,'applied'=>true]);}
                return Result::ok(['changed'=>!$was_revoked,'revoked'=>true,'scope'=>str_starts_with($id,'integration:')?'wordpress_user_integration':'credential']);
            }
            if(($old['_storage']['status']??'')==='revoked')return Result::fail('connection_revoked','Emita nova credencial; identidade revogada não pode ser reaberta.');
            $profile=(string)($input['profile']??'');
            if(!in_array($profile,['read','content','maintenance','custom'],true))return Result::fail('profile_invalid','Perfil inválido.');
            $expires=empty($input['expires'])?0:strtotime((string)$input['expires']);
            if($expires===false||$expires&&$expires<=time())return Result::fail('expiration_invalid','Expiração precisa estar no futuro.');
            $roots=[];foreach(preg_split('/\r?\n/',trim((string)($input['roots']??'')))?:[] as $path)if($path!=='') { $root=realpath(trim($path));if(!$root||!is_dir($root))return Result::fail('profile_root_invalid','Uma raiz não é diretório existente.');$roots[]=wp_normalize_path($root); }
            $abilities=preg_split('/[\s,]+/',trim((string)($input['abilities']??'')),-1,PREG_SPLIT_NO_EMPTY)?:[];
            if (isset($old['abilities']) && !array_diff($abilities,$old['abilities']) && !array_diff($old['abilities'],$abilities)) $abilities=$old['abilities'];
            foreach($abilities as $ability)if(!wp_get_ability($ability)&&!in_array($ability,$old['abilities']??[],true))return Result::fail('profile_ability_invalid','Habilidade não registrada.');
            $post_types=preg_split('/[\s,]+/',trim((string)($input['post_types']??'')),-1,PREG_SPLIT_NO_EMPTY)?:[];
            foreach($post_types as $type)if(!post_type_exists($type)&&!in_array($type,$old['post_types']??[],true))return Result::fail('profile_post_type_invalid','Tipo de conteúdo não registrado.');
            $row=['policy_explicit'=>true,'user_id'=>$user,'connection_id'=>$id,'profile'=>$profile,'status'=>'active','time'=>$old['time'],'policy_version'=>(int)($old['policy_version']??0)+1,'expires'=>$expires,'roots'=>$roots,'abilities'=>$abilities,'post_types'=>$post_types,'meta_keys'=>preg_split('/[\s,]+/',trim((string)($input['meta_keys']??'')),-1,PREG_SPLIT_NO_EMPTY)?:[],'allow_backup_export'=>!empty($input['allow_backup_export']),'allow_foreign_backup_export'=>!empty($input['allow_foreign_backup_export']),'database_write'=>!empty($input['database_write']),'readonly_executor'=>!empty($input['readonly_executor']),'label'=>sanitize_text_field($input['label']??'')];
            $row=array_replace($old,$row);if(!empty($input['_inherit_file_bytes']))unset($row['file_bytes']);if(isset($input['file_bytes'])&&$input['file_bytes']!==''){$limit=(int)$input['file_bytes'];if($limit<1048576||$limit>1073741824)return Result::fail('file_limit_invalid','Limite deve ficar entre 1 MiB e 1 GiB.');$row['file_bytes']=$limit;}
            $previous=$old;
            $next=$row;
            unset($previous['_storage'],$previous['policy_version'],$next['_storage'],$next['policy_version']);
            if ($old && $previous===$next) {
                return Result::ok(['changed'=>false,'persisted'=>true,'connection_id'=>$id,'profile'=>$profile]);
            }
            Persistence::put('connections',$id,$row);
            return Result::ok(['changed'=>true,'persisted'=>true,'connection_id'=>$id,'profile'=>$profile]);
        });
    }

    private static function issue(int $user,array $input): array {
        $name=sanitize_text_field($input['label']??'');
        if ($name==='')return Result::fail('connection_label_required','Informe um nome para identificar o cliente.');
        if (!wp_is_application_passwords_available_for_user($user))return Result::fail('application_password_unavailable','Senhas de aplicação indisponíveis para esta conta.');
        return Locks::run(['credential:'.get_current_blog_id().':'.$user=>LOCK_EX],static function()use($input,$user,$name){
            clean_user_cache($user);
            $created=\WP_Application_Passwords::create_new_application_password($user,['name'=>$name]);
            if (is_wp_error($created))return Result::fail('credential_creation_failed','O WordPress não conseguiu emitir a credencial.');
            [$password,$item]=$created;
            $id='app:'.$item['uuid'];
            try {
                $result=self::save(array_replace($input,['intent'=>'save','connection_id'=>$id,'label'=>$name,'expected_policy_version'=>0]));
            } catch (\Throwable $e) {
                $result=Result::fail('credential_policy_failed','Falha ao gravar a política de acesso.');
            }
            if (empty($result['success'])) {
                return self::discard_unissued($user,$item['uuid'],$result);
            }
            return $result+['application_password'=>$password,'user_login'=>get_userdata($user)->user_login,'credential_created'=>true];
        });
    }

    /** The caller still owns the credential lock; remove only the UUID just issued. */
    public static function discard_unissued(int $user,string $uuid,array $failure): array {
        try {
            \WP_Application_Passwords::delete_application_password($user,$uuid);
            if (!\WP_Application_Passwords::get_user_application_password($user,$uuid))return $failure;
        } catch (\Throwable $e) {
            // Receipt below contains the identity for the administrator, never a secret.
        }
        return Result::fail('credential_cleanup_pending','Confira e revogue a senha recém-criada no perfil WordPress antes de emitir outra.',
            ['connection_id'=>'app:'.$uuid,'retryable'=>false]);
    }

    /** Normalize structured local fields without changing the public connections/update schema. */
    public static function form_input(array $input) {
        foreach(['abilities','post_types'] as $key){
            $values=$input[$key]??[];
            if(!is_array($values)||count($values)>5000)return new \WP_Error('profile_selection_invalid','Seleção inválida.');
            foreach($values as $value)if(!is_string($value)||strlen($value)>200||preg_match('/[\s,]/',$value))return new \WP_Error('profile_selection_invalid','Seleção inválida.');
            $input[$key]=implode("\n",array_unique($values));
        }
        if(isset($input['expires'])&&$input['expires']!==''){
            if(!is_string($input['expires'])||!preg_match('/^\d{4}-\d\d-\d\dT\d\d:\d\d(?::\d\d)?$/D',$input['expires']))return new \WP_Error('expiration_invalid','Escolha uma data e hora válidas.');
            $format=strlen($input['expires'])===16?'Y-m-d\TH:i':'Y-m-d\TH:i:s';
            $date=\DateTimeImmutable::createFromFormat('!'.$format,$input['expires'],new \DateTimeZone('UTC'));
            if(!$date||$date->format($format)!==$input['expires'])return new \WP_Error('expiration_invalid','Escolha uma data e hora válidas.');
            $input['expires']=$date->format('c');
        }
        foreach(['connection_id','user_id','label','profile','roots','meta_keys','file_bytes','expected_policy_version','intent'] as $key)if(isset($input[$key])&&!is_string($input[$key]))return new \WP_Error('profile_input_invalid','Campo inválido.');
        foreach (['allow_backup_export','allow_foreign_backup_export','database_write','readonly_executor'] as $key) {
            if (isset($input[$key]) && $input[$key]!=='1')return new \WP_Error('profile_input_invalid','Permissão adicional inválida.');
        }
        if (isset($input['file_bytes']) && $input['file_bytes']!=='' && !ctype_digit($input['file_bytes']))return new \WP_Error('file_limit_invalid','Informe o limite como um número inteiro de bytes.');
        $input['_inherit_file_bytes']=isset($input['file_bytes'])&&$input['file_bytes']==='';
        return $input;
    }

    /** Claim the form before issuance. A browser retry never receives a second password. */
    private static function issue_from_form(array $input): array {
        $ticket=$input['issue_ticket']??null;
        if (!is_string($ticket) || !wp_is_uuid($ticket,4))return Result::fail('issue_form_invalid','Reabra o formulário de emissão.');
        $key='admin-issue:'.get_current_user_id().':'.$ticket;
        $receipt=['time'=>time(),'user_id'=>get_current_user_id(),'operation_id'=>$key,'status'=>'running'];
        try {
            if (!Persistence::put('idempotency',$key,$receipt,true)) {
                return Result::fail('issue_form_used','Este formulário já foi enviado. Confira a lista de clientes antes de iniciar outra emissão.');
            }
            $result=self::save($input);
            $receipt['status']='complete';
            $receipt['success']=!empty($result['success']);
            $receipt['connection_id']=$result['connection_id']??'';
            try { Persistence::put('idempotency',$key,$receipt); }
            catch (\Throwable $error) {
                // The initial claim remains in place. Still deliver a successfully issued secret once.
                $result['receipt_pending']=true;
            }
            return $result;
        } catch (\Throwable $error) {
            return Result::fail('issue_unconfirmed','A emissão não foi confirmada. Confira as credenciais desta conta antes de repetir.',['retryable'=>false]);
        }
    }

    public static function submit(): void {
        if(!current_user_can('manage_options'))wp_die('Permissão insuficiente.','',['response'=>403]);
        check_admin_referer('f3_mcp_connection');
        $input=wp_unslash($_POST);
        $intent=$input['intent']??null;
        if (!in_array($intent,['associate','create','save','revoke'],true)
            || !is_string($input['expected_policy_version']??null)
            || !ctype_digit($input['expected_policy_version'])
            || (($intent==='associate'||$intent==='create') && $input['expected_policy_version']!=='0')) {
            Admin::redirect_notice(Result::fail('profile_input_invalid','Pedido incompleto. Abra o cliente e tente novamente.'),'connections');
        }
        if ($intent==='revoke') {
            if (($input['confirm_revocation']??'')!=='1') {
                Admin::redirect_notice(Result::fail('confirmation_required','Confirme a interrupção do acesso antes de revogar.'),'connections');
            }
        } elseif (($input['form_complete']??'')!=='1') {
            Admin::redirect_notice(Result::fail('profile_input_incomplete','O formulário chegou incompleto. Confira o limite max_input_vars do PHP antes de salvar.'),'connections');
        }
        $input=self::form_input($input);
        if (is_wp_error($input))Admin::redirect_notice(Result::error($input),'connections');
        $input['_existing_form']=in_array($intent,['save','revoke'],true);
        $result=$intent==='create'?self::issue_from_form($input):self::save($input);
        Audit::record('admin/connection',['name'=>$input['connection_id']??''],$result,0);
        if(!empty($result['credential_created'])){
            nocache_headers();
            header('Referrer-Policy: no-referrer');
            header('Content-Type: text/html; charset='.get_option('blog_charset'));
            status_header(200);
            require __DIR__.'/views/credential-created.php';
            exit;
        }
        $args=[];
        if (in_array($intent,['save','revoke'],true))$args['connection']=$input['connection_id']??'';
        Admin::redirect_notice($result,'connections',$intent==='revoke'?'Identidade revogada.':'Perfil de acesso salvo.',$args);
    }
    public static function render(): void {
        if (!current_user_can('manage_options')) return;
        $id=is_string($_GET['connection']??null)?sanitize_text_field(wp_unslash($_GET['connection'])):'';
        $mode=is_string($_GET['mode']??null)?sanitize_key(wp_unslash($_GET['mode'])):'';
        if ($id!=='') {
            $editing=ConnectionContext::policy($id);
            if (!$editing || !current_user_can('edit_user',(int)$editing['user_id'])) {
                echo '<section class="f3-card"><h2>Cliente indisponível</h2><p>Escolha uma identidade que você possa administrar.</p><a href="'.esc_url(Admin::url('connections')).'">Voltar aos clientes</a></section>';
                return;
            }
            $mode='edit';
        } elseif (in_array($mode,['associate','create'],true) || isset($_GET['choose_user']) || isset($_GET['user_search'])) {
            $editing=null;
            if ($mode!=='create')$mode='associate';
        } else {
            self::client_list();
            return;
        }

        $values=$editing??[];
        if (empty($values['label']) && str_starts_with($values['connection_id']??'','grant:')) $values['label']=ConnectionContext::oauth_label($values);
        $user_search=is_string($_GET['user_search']??null)?sanitize_text_field(wp_unslash($_GET['user_search'])):'';
        if ($editing) {
            $user=get_userdata((int)$editing['user_id']);
        } else {
            $choosing=isset($_GET['choose_user']) || isset($_GET['user_search']);
            if ($choosing) {
                $users=get_users(['number'=>100,'orderby'=>'display_name','search'=>$user_search!==''?'*'.$user_search.'*':'','search_columns'=>['user_login','display_name']]);
                $users=array_values(array_filter($users, static fn($u)=>current_user_can('edit_user',$u->ID)));
                require __DIR__.'/views/connections-user.php';
                return;
            }
            $requested=$_GET['user_id']??(string)get_current_user_id();
            $user=is_string($requested) && ctype_digit($requested) ? get_userdata((int)$requested) : false;
            if (!$user || !current_user_can('edit_user',$user->ID))$user=false;
        }
        require __DIR__.'/views/connections-form.php';
    }

    private static function client_list(): void {
        $before=max(1,(int)($_GET['before_id']??PHP_INT_MAX));
        $rows=Persistence::listing('connections',[],51,$before);
        $more=count($rows)>50;
        $rows=array_slice($rows,0,50);
        $session_counts=Persistence::active_session_counts(array_column($rows,'connection_id'));
        if ($rows)cache_users(array_unique(array_column($rows,'user_id')));
        require __DIR__.'/views/connections-list.php';
    }
}
