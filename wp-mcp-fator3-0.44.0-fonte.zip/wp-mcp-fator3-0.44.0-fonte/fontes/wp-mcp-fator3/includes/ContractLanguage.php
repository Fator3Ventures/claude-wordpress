<?php
/** One localized description layer; parameter names always come from the effective schema. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class ContractLanguage {
    private static array $legacyDescriptions = [];

    /** Restore only the original blank descriptions when checking a pre-0.44 plan. */
    public static function legacy_input(array $schema, string $name): array {
        foreach (self::$legacyDescriptions[$name] ?? [] as $key => $prior) {
            if (!isset($schema['properties'][$key])) continue;
            if ($prior === null) unset($schema['properties'][$key]['description']);
            else $schema['properties'][$key]['description'] = $prior;
        }
        return $schema;
    }

    public static function describe(array $args, string $name): array {
        static $descriptions=null, $labels=null;
        if($labels===null)$labels=require __DIR__.'/labels-pt_BR.php';
        if(isset($labels[$name]))$args['label']=$labels[$name];
        if($descriptions===null)$descriptions=require __DIR__.'/descriptions-pt_BR.php';
        $args=self::properties($args,$name);
        if(!isset($descriptions[$name]))return $args;
        $params=array_keys($args['input_schema']['properties']??[]);$required=$args['input_schema']['required']??[];
        $args['description']=$descriptions[$name];
        if($params)$args['description'].=' Parâmetros: '.implode(', ',$params).'.';
        if($required)$args['description'].=' Obrigatórios: '.implode(', ',$required).'.';
        return $args;
    }
    /** Apply only to our registered abilities and the explicitly supported core callbacks. */
    public static function properties(array $args, string $name): array {
        static $map;
        $map ??= require __DIR__ . '/property-descriptions-pt_BR.php';
        if (!isset($args['input_schema']['properties']) || !is_array($args['input_schema']['properties'])) return $args;
        unset(self::$legacyDescriptions[$name]);
        foreach ($args['input_schema']['properties'] as $property => &$definition) {
            if (!is_array($definition)) continue;
            $previous = $definition['description'] ?? null;
            if (isset($map['ability'][$name][$property])) {
                $definition['description'] = $map['ability'][$name][$property];
            } elseif (is_string($previous) && isset($map['exact'][$previous])) {
                $definition['description'] = $map['exact'][$previous];
            } elseif ($previous === null || $previous === '') {
                $description = $map['context'][$name][$property] ?? $map['common'][$property] ?? null;
                if ($description !== null) {
                    self::$legacyDescriptions[$name][$property] = $previous;
                    $definition['description'] = $description;
                }
            }
        }
        unset($definition);
        return $args;
    }
}
