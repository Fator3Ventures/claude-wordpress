<?php
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Uninstall {
    public const OPTION = 'f3_mcp_remove_on_uninstall';
    private const BUCKETS = [
        'archive-staging','artifacts','backup-exports','backup-retired','backups','cron-runs',
        'database-recovery','diagnostics','locks','oauth-diagnostics','package-staging',
        'recovery','recovery-journals','theme-staging','transfers',
    ];

    public static function init(): void {
        add_action('f3_mcp_uninstall_settings', [self::class,'settings']);
        add_action('admin_post_f3_mcp_uninstall_settings', [self::class,'save']);
    }

    private static function enabled(): bool {
        return '1' === (string)get_option(self::OPTION, '0');
    }

    public static function settings(): void {
        if (is_multisite() || !current_user_can('delete_plugins') || !current_user_can('manage_options')) return;
        echo '<details class="f3-card"><summary>Desinstalação</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field('f3_mcp_uninstall_settings');
        echo '<input type="hidden" name="action" value="f3_mcp_uninstall_settings">';
        echo '<label><input type="checkbox" name="remove" value="1" '.checked(self::enabled(),true,false).'> Remover dados ao excluir o plugin</label>';
        echo '<p>Ao excluir o Fator3 MCP em Plugins, esta preferência apaga as conexões, o histórico, as configurações e os backups privados deste site. Faça uma cópia dos backups que precisa manter. As senhas de aplicação continuam na conta WordPress até a revogação.</p>';
        echo '<p>Com a opção desmarcada, a reinstalação pode reutilizar os dados.</p>';
        submit_button('Salvar preferência','secondary','submit',false);
        echo '</form></details>';
    }

    public static function save(): void {
        if (is_multisite() || !current_user_can('delete_plugins') || !current_user_can('manage_options')) wp_die('Permissão insuficiente.', '', ['response'=>403]);
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') wp_die('Envie a preferência pelo formulário.', '', ['response'=>405]);
        check_admin_referer('f3_mcp_uninstall_settings');
        $value = $_POST['remove'] ?? '0';
        if (!in_array($value, ['0','1'], true)) wp_die('Preferência inválida.', '', ['response'=>400]);
        update_option(self::OPTION,$value,false);
        Admin::redirect_notice(['success'=>self::enabled() === ($value === '1')], 'diagnostics','Preferência de desinstalação salva.');
    }

    /** Delete files without traversing a symbolic link, including a link inside a backup. */
    private static function erase(string $path): void {
        if (is_link($path) || is_file($path)) {
            if (!unlink($path)) throw new \RuntimeException('Falha ao excluir um arquivo privado do MCP.');
        } elseif (is_dir($path)) {
            foreach (new \FilesystemIterator($path) as $child) self::erase($child->getPathname());
            if (!rmdir($path)) throw new \RuntimeException('Falha ao excluir uma pasta privada do MCP.');
        }
    }

    private static function remove_files(): void {
        $base = rtrim(wp_normalize_path(defined('F3_MCP_PRIVATE_DIR') ? (string) F3_MCP_PRIVATE_DIR : WP_CONTENT_DIR.'/f3-mcp-private'),'/');
        if (!file_exists($base) && !is_link($base)) return;
        $canonical = realpath($base);
        if (!$canonical || wp_normalize_path($canonical) !== $base || is_link($base) || !is_dir($base)) {
            throw new \RuntimeException('Confira o caminho do armazenamento privado antes da exclusão.');
        }
        foreach ([ABSPATH,WP_CONTENT_DIR,WP_PLUGIN_DIR,WPMU_PLUGIN_DIR] as $protected) {
            $resolved = realpath($protected);
            if ($resolved && str_starts_with(trailingslashit(wp_normalize_path($resolved)),trailingslashit($base))) {
                throw new \RuntimeException('O diretório privado configurado contém arquivos da instalação WordPress.');
            }
        }
        if (is_link($base.'/index.php') || !is_file($base.'/index.php') || file_get_contents($base.'/index.php') !== "<?php exit; ?>\n") {
            throw new \RuntimeException('A marca de identificação do diretório privado MCP está ausente.');
        }
        foreach (self::BUCKETS as $bucket) self::erase($base.'/'.$bucket);
        $others = array_diff(scandir($base), ['.','..','index.php','.htaccess']);
        if ($others) return;
        $deny = "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n";
        if (is_link($base.'/.htaccess') || (is_file($base.'/.htaccess') && file_get_contents($base.'/.htaccess') !== $deny)) return;
        self::erase($base.'/.htaccess');
        self::erase($base.'/index.php');
        if (!rmdir($base)) throw new \RuntimeException('Falha ao excluir o diretório privado do MCP.');
    }

    public static function remove(): void {
        if (is_multisite() || !self::enabled()) return;
        global $wpdb;
        foreach (['f3_mcp_cron_observed','f3_mcp_query_job'] as $hook) {
            if (is_wp_error(wp_unschedule_hook($hook, true))) throw new \RuntimeException('Falha ao remover um agendamento do MCP.');
        }
        self::remove_files();
        $loader = WPMU_PLUGIN_DIR.'/000-f3-mcp-recovery.php';
        $engine = WPMU_PLUGIN_DIR.'/f3-mcp-recovery-runtime-v1.php';
        if (!is_link($loader) && is_file($loader) && str_starts_with((string) file_get_contents($loader),"<?php\n/** Fator3 MCP recovery sentinel v1. */\n")) self::erase($loader);
        if (!file_exists($loader) && !is_link($engine) && is_file($engine) && hash_file('sha256',$engine) === hash_file('sha256',__DIR__.'/RecoveryEngine.php')) self::erase($engine);
        foreach (OwnedState::tables() as $table) {
            if (false === $wpdb->query($wpdb->prepare('DROP TABLE IF EXISTS %i',$table))) throw new \RuntimeException('Falha ao excluir uma tabela do MCP.');
        }
        foreach (OwnedState::OPTIONS as $name) {
            if ($name !== self::OPTION) delete_option($name);
        }
        foreach (['f3_mcp_app_password','f3_mcp_connection_test'] as $key) delete_metadata('user',0,$key,'',true);
        foreach (['_transient_f3_mcp_notice_', '_transient_timeout_f3_mcp_notice_', '_transient_f3_mcp_sim_', '_transient_timeout_f3_mcp_sim_'] as $prefix) {
            $names = $wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like($prefix).'%'));
            foreach ($names as $name) delete_option($name);
        }
        delete_option(self::OPTION);
    }
}
