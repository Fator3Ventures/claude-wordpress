<?php
/** Bounded file maintenance; every mutation shares Locks::files with legacy tools. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Cursor {
	public static function encode(array $data): string {
		$payload = rtrim(strtr(base64_encode(json_encode($data, JSON_THROW_ON_ERROR)), '+/', '-_'), '=');
		return $payload . '.' . hash_hmac('sha256', $payload, wp_salt('auth'));
	}
	public static function decode(string $cursor) {
		if (strlen($cursor) > 8192 || 2 !== count($parts = explode('.', $cursor))) return new \WP_Error('cursor_invalid', 'O cursor é inválido.');
		if (!hash_equals(hash_hmac('sha256', $parts[0], wp_salt('auth')), $parts[1])) return new \WP_Error('cursor_invalid', 'A assinatura do cursor é inválida.');
		$data = json_decode((string)base64_decode(strtr($parts[0], '-_', '+/'), true), true);
		return is_array($data) ? $data : new \WP_Error('cursor_invalid', 'Os dados do cursor são inválidos.');
	}
}
final class FileTools {
	public static function permission(): bool { return PathGuard::is_enabled() && PathGuard::can_edit(); }
	public static function register(): void {
		$path = ['path' => Registry::string('Absolute path or path relative to ABSPATH.')];
		Registry::add('files/stat', 'Read file type, size, times, permissions and optional full SHA-256 without returning its contents.', $path + ['hash' => Registry::boolean(true)], ['path'], [self::class, 'stat'], [self::class, 'permission']);
		Registry::add('files/mkdir', 'Create a directory under the shared path lock. Existing directory is a no-op. No recursive deletion.', $path + ['parents' => Registry::boolean(), 'mode' => Registry::integer(448, 511)], ['path'], [self::class, 'mkdir'], [self::class, 'permission'], false);
		foreach (['copy', 'move'] as $action) Registry::add('files/' . $action, ucfirst($action) . ' one regular file. Source and destination are locked together; overwrite requires overwrite=true, destination is backed up. Directory trees and symlink entries are not moved.', ['source' => Registry::string(), 'destination' => Registry::string(), 'overwrite' => Registry::boolean(), 'expected_sha256' => Registry::string('Expected source hash.'), 'expected_destination_sha256' => Registry::string('Expected destination hash, when overwriting.')], ['source', 'destination'], static fn($input) => self::transfer($input, $action), [self::class, 'permission'], false);
		Registry::add('files/search', 'Search literal text or delimited PCRE in a regular file or directory; grep_regex defaults to false. Symlinks are not traversed. Reports truncated scans and continuation by file offset; hits within a truncated file must be continued with files/read.', $path + ['grep' => Registry::string(), 'grep_regex' => Registry::boolean(), 'recursive' => Registry::boolean(true), 'max_depth' => Registry::integer(1, 10), 'offset' => Registry::integer(), 'per_page' => Registry::integer(1, 200), 'max_matches' => Registry::integer(1, 500)], ['path', 'grep'], [self::class, 'search'], [self::class, 'permission']);
	}
	public static function stat(array $input): array {
		$path = PathGuard::resolve($input['path'], false); if (is_wp_error($path)) return Result::error($path);
		clearstatcache(true, $path); $stat = @stat($path); if (!$stat) return Result::fail('file_not_found', 'O caminho não existe.');
		$data = ['path' => PathGuard::to_relative($path), 'type' => is_dir($path) ? 'directory' : (is_file($path) ? 'file' : 'special'), 'bytes' => (int)$stat['size'], 'mtime' => (int)$stat['mtime'], 'mode' => substr(sprintf('%o', $stat['mode']), -4), 'readable' => is_readable($path), 'writable' => is_writable($path)];
		if (is_file($path) && ($input['hash'] ?? true)) { $hash = hash_file('sha256', $path); if (false === $hash) return Result::fail('file_read_failed', 'Não foi possível calcular o hash do arquivo.'); $data['sha256'] = $hash; }
		return Result::ok($data);
	}
	public static function mkdir(array $input): array {
		return Locks::files([$input['path']], static function ($paths) use ($input) {
			$path = $paths[$input['path']];
			if (is_dir($path)) return Result::ok(['path' => PathGuard::to_relative($path), 'changed' => false, 'created' => false]);
			if (file_exists($path)) return Result::fail('file_type_conflict', 'O caminho já existe e não é um diretório.', ['conflict' => true]);
			if (!empty($input['parents'])) { $parent = PathGuard::prepare_parent($path); if (is_wp_error($parent)) return Result::error($parent); }
			$mode = (int)($input['mode'] ?? 0755);
			if (!@mkdir($path, $mode, false) || !is_dir($path)) return Result::fail('directory_create_failed', 'Não foi possível criar o diretório.');
			return Result::ok(['path' => PathGuard::to_relative($path), 'changed' => true, 'created' => true]);
		});
	}
	public static function transfer(array $input, string $action): array {
		return Locks::files([$input['source'], $input['destination']], static function ($paths) use ($input, $action) {
			$source = $paths[$input['source']]; $dest = $paths[$input['destination']];
			if ($source === $dest) return Result::fail('same_file', 'A origem e o destino apontam para o mesmo arquivo.');
			if (!is_file($source)) return Result::fail('file_not_found', 'A origem deve ser um arquivo regular existente.');
			$conflict = Locks::check_hash($source, $input); if ($conflict) return $conflict;
			$conflict = Locks::check_hash($dest, $input, 'expected_destination_sha256'); if ($conflict) return $conflict;
			if (file_exists($dest) && (empty($input['overwrite']) || !is_file($dest))) return Result::fail('destination_exists', 'O destino existe. Para substituir um arquivo regular, informe overwrite=true.', ['conflict' => true]);
			foreach ([$source, $dest] as $path) { $valid = PathGuard::check_extension($path); if (is_wp_error($valid)) return Result::error($valid); }
			$size = filesize($source); if (false === $size || $size > PathGuard::max_bytes()) return Result::fail('file_size_limit', 'A origem excede o limite do canal de arquivos.');
			$bytes = @file_get_contents($source); if (false === $bytes || strlen($bytes) !== $size) return Result::fail('file_read_failed', 'Não foi possível ler a origem por completo.');
			if ('php' === strtolower(pathinfo($dest, PATHINFO_EXTENSION))) { $syntax = PathGuard::check_php_syntax($bytes); if (is_wp_error($syntax)) return Result::error($syntax); }
			$source_backup = 'move' === $action ? Backups::create_file($source) : '';
			if (is_wp_error($source_backup)) return Result::error($source_backup);
			$dest_backup = is_file($dest) ? Backups::create_file($dest) : '';
			if (is_wp_error($dest_backup)) return Result::error($dest_backup);
			if (!is_dir(dirname($dest))) return Result::fail('destination_parent_missing', 'Crie primeiro o diretório de destino com files/mkdir.');
			// Atomic rename for a move on one filesystem. Cross-device moves are refused,
			// because copy+unlink would claim atomic semantics that cannot be guaranteed.
			if ('move' === $action) {
				$source_stat = stat($source); $parent_stat = stat(dirname($dest));
				if ($source_stat['dev'] !== $parent_stat['dev']) return Result::fail('cross_device_move', 'Mover entre sistemas de arquivos não é atômico. Copie, verifique e exclua a origem explicitamente.');
				$moved=Recovery::file($dest,$bytes,static fn()=>Recovery::file($source,null,static fn()=>@rename($source,$dest)),['post_mode'=>fileperms($source)&0777]);
                if(is_wp_error($moved))return Result::error($moved);
                if(!$moved)return Result::fail('file_move_failed','Não foi possível renomear a origem para o destino.');
				if (function_exists('opcache_invalidate')) { @opcache_invalidate($source, true); @opcache_invalidate($dest, true); }
			} else { $written = Files::atomic_write($dest, $bytes); if (is_wp_error($written)) return Result::error($written); }
			return Result::ok(['source' => PathGuard::to_relative($source), 'path' => PathGuard::to_relative($dest), 'bytes' => strlen($bytes), 'sha256' => hash('sha256', $bytes), 'backup_id' => $dest_backup, 'source_backup_id' => $source_backup, 'changed' => true]);
		});
	}
	private static function entries(string $dir, bool $recursive, int $depth, string $base, array &$entries): void {
		$names = @scandir($dir); if (false === $names) throw new \RuntimeException('Cannot enumerate directory.');
		foreach ($names as $name) {
			if ('.' === $name || '..' === $name) continue;
			if (count($entries) >= 50000) throw new \RuntimeException('Directory scan exceeds 50000 entries. Query a narrower path.');
			$path = $dir . '/' . $name; $valid = PathGuard::resolve($path, false); if (is_wp_error($valid)) continue;
			$link = is_link($path); $is_dir = is_dir($path); $stat = @lstat($path); if (!$stat) continue;
			$entries[] = ['name' => $name, 'path' => PathGuard::to_relative($path), 'relative' => substr($path, strlen($base) + 1), 'type' => $is_dir ? 'dir' : 'file', 'is_symlink' => $link, 'size' => $is_dir ? null : (int)$stat['size'], 'mtime' => (int)$stat['mtime'], 'modified' => gmdate('c', (int)$stat['mtime']), 'writable' => is_writable($path)];
			if (!$link && $recursive && $is_dir && $depth > 1) self::entries($path, true, $depth - 1, $base, $entries);
		}
	}
	public static function listing(array $input): array {
		$dir = PathGuard::resolve((string)($input['path'] ?? '.'), false); if (is_wp_error($dir)) return Result::error($dir);
		if (!is_dir($dir)) return Result::fail('not_directory', 'O caminho não é um diretório.');
		$entries = [];
		try { self::entries($dir, !empty($input['recursive']), max(1, min(10, (int)($input['max_depth'] ?? 3))), $dir, $entries); }
		catch (\RuntimeException $e) { return Result::fail('directory_scan_failed', $e->getMessage()); }
		usort($entries, static fn($a, $b) => strcmp($a['relative'], $b['relative']));
		$offset = max(0, (int)($input['offset'] ?? 0)); $limit = max(1, min(1000, (int)($input['per_page'] ?? 200)));
		$total = count($entries); $page = array_slice($entries, $offset, $limit); $more = $offset + count($page) < $total;
		return Result::ok(['path' => PathGuard::to_relative($dir), 'entries' => $page, 'total' => $total, 'offset' => $offset, 'has_more' => $more, 'next_offset' => $more ? $offset + count($page) : null, 'listing_sha256' => hash('sha256', serialize($entries))]);
	}
	public static function search(array $input): array {
		if ('' === $input['grep'] || strlen($input['grep']) > 4096) return Result::fail('invalid_grep', 'Informe um texto literal de 1 a 4.096 bytes para grep.');
		if (!empty($input['grep_regex'])) { $valid = RegexGuard::validate($input['grep']); if ($valid) return Result::error($valid); }
		$target = PathGuard::resolve($input['path'], false); if (is_wp_error($target)) return Result::error($target);
		if (is_file($target)) {
			if (is_link($target) || !is_readable($target)) return Result::fail('file_read_failed', 'Arquivo deve ser regular e legível, sem link.');
			$entry = ['path'=>PathGuard::to_relative($target),'type'=>'file','size'=>(int)filesize($target),'mtime'=>(int)filemtime($target)];
			$page = ['success'=>true,'entries'=>empty($input['offset']) ? [$entry] : [],'total'=>1,'listing_sha256'=>hash('sha256',serialize($entry))];
		} else { $page = self::listing($input + ['recursive'=>true,'per_page'=>50]); if (!$page['success']) return $page; }

		$matches = []; $skipped = []; $read = 0; $processed = 0; $max = max(1, min(500, (int)($input['max_matches'] ?? 100))); $partial = [];
		foreach ($page['entries'] as $entry) {
			if (count($matches) >= $max || $read >= 16777216) break;
			$processed++;
			if ('file' !== $entry['type'] || !empty($entry['is_symlink'])) continue;
			if ($entry['size'] > 2097152) { $skipped[] = ['path' => $entry['path'], 'reason' => 'file_exceeds_2MiB']; continue; }
			$path = PathGuard::resolve($entry['path'], false); if (is_wp_error($path)) continue;
			$handle = @fopen($path, 'rb'); if (!$handle) { $skipped[] = ['path' => $entry['path'], 'reason' => 'unreadable']; continue; }
			$opened = fstat($handle); if (!$opened || ($opened['mode'] & 0170000) !== 0100000 || (int)$opened['size'] !== (int)$entry['size'] || (int)$opened['mtime'] !== (int)$entry['mtime']) { fclose($handle); return Result::fail('file_changed_during_read', 'Arquivo mudou antes da busca.', ['conflict'=>true]); }
			$line = 0;
			try { while (false !== ($text = fgets($handle, 65537))) {
				$line++; $read += strlen($text);
				if (!preg_match('//u', $text) || str_contains($text, "\0")) { $skipped[] = ['path' => $entry['path'], 'reason' => 'binary']; break; }
				$hit = !empty($input['grep_regex']) ? RegexGuard::match($input['grep'], rtrim($text, "\r\n")) : str_contains($text, $input['grep']);
				if (is_wp_error($hit)) return Result::error($hit);
				if ($hit) $matches[] = ['path' => $entry['path'], 'line' => $line, 'text' => substr(rtrim($text, "\r\n"), 0, 2048), 'byte_offset_after' => ftell($handle)];
				if (count($matches) >= $max || $read >= 16777216 || !str_ends_with($text, "\n") && strlen($text) >= 65536) { $partial[] = ['path' => $entry['path'], 'next_byte_offset' => ftell($handle), 'reason' => 'scan_limit']; break; }
			} } finally { fclose($handle); }
		}
		$next = (int)($input['offset'] ?? 0) + $processed;
		return Result::ok(['matches' => $matches, 'skipped' => $skipped, 'partial_files' => $partial, 'scanned_bytes' => $read, 'has_more' => $next < $page['total'], 'next_offset' => $next < $page['total'] ? $next : null, 'listing_sha256' => $page['listing_sha256']]);
	}
	public static function read_cursor(string $path, array $input): array {
		foreach (['offset', 'limit', 'tail_lines', 'grep', 'grep_regex'] as $option) if (isset($input[$option])) return Result::fail('conflicting_read_modes', 'O cursor de bytes não pode ser combinado com as opções de linha, cauda ou grep.');
		$state = [];
		if (isset($input['cursor'], $input['offset_bytes'])) return Result::fail('conflicting_read_modes', 'Use cursor ou offset_bytes.');
		if ('' !== ($input['cursor'] ?? '')) { $state = Cursor::decode($input['cursor']); if (is_wp_error($state)) return Result::error($state); }
		$handle = @fopen($path, 'rb'); if (!$handle) return Result::fail('file_read_failed', 'Não foi possível abrir o alvo do cursor.');
		try {
			$stat = fstat($handle); if (!$stat || ($stat['mode'] & 0170000) !== 0100000) return Result::fail('file_type_invalid', 'A leitura com cursor exige um arquivo regular.');
			$identity = (string)$stat['dev'] . ':' . (string)$stat['ino']; $size = (int)$stat['size']; $offset = (int)($state['offset'] ?? $input['offset_bytes'] ?? 0);
			if ($offset < 0 || $offset > $size) return Result::fail('offset_out_of_range', 'offset_bytes deve estar entre zero e o tamanho atual do arquivo.');
			if ($state && (($state['kind'] ?? '') !== 'file-bytes' || ($state['path'] ?? '') !== $path || ($state['user'] ?? 0) !== get_current_user_id() || ($state['blog'] ?? 0) !== get_current_blog_id() || ($state['connection']??'')!==ConnectionContext::key())) return Result::fail('cursor_invalid', 'O cursor não corresponde ao caminho, usuário e site desta chamada.');
			if ($state && ($state['identity'] !== $identity || $size < $offset || $size < $state['prefix_length'])) return Result::fail('file_rotated', 'A identidade do arquivo mudou ou o arquivo foi truncado. Inicie um novo cursor explicitamente.', ['conflict' => true, 'current_identity' => $identity]);
			$prefix_length = (int)($state['prefix_length'] ?? min(4096, $size));
			$prefix = $prefix_length ? fread($handle, $prefix_length) : '';
			if ($state) {
				fseek($handle, max(0, $offset - 256)); $window = $offset ? fread($handle, min(256, $offset)) : '';
				if (!hash_equals($state['prefix_sha256'], hash('sha256', $prefix)) || !hash_equals($state['window_sha256'], hash('sha256', $window))) return Result::fail('file_rotated', 'Os bytes lidos anteriormente mudaram. Verifique a rotação do arquivo e reinicie o cursor.', ['conflict' => true]);
			}
			if (0 !== fseek($handle, $offset)) return Result::fail('file_seek_failed', 'Não foi possível avançar até a posição do cursor.');
			$length = min($size - $offset, max(1, min(PathGuard::max_bytes(), (int)($input['byte_limit'] ?? 65536))));
			$content = $length ? fread($handle, $length) : '';
			if (false === $content || strlen($content) !== $length) return Result::fail('file_changed_during_read', 'O arquivo mudou durante a leitura. Repita com o mesmo cursor.', ['conflict' => true, 'retryable' => true]);
			$next = $offset + strlen($content);
			fseek($handle, max(0, $next - 256)); $window = $next ? fread($handle, min(256, $next)) : '';
			$cursor = Cursor::encode(['kind' => 'file-bytes', 'connection'=>ConnectionContext::key(), 'path' => $path, 'user' => get_current_user_id(), 'blog' => get_current_blog_id(), 'identity' => $identity, 'offset' => $next, 'prefix_length' => $prefix_length, 'prefix_sha256' => hash('sha256', $prefix), 'window_sha256' => hash('sha256', $window)]);
			$data = ['path' => PathGuard::to_relative($path), 'mode' => 'cursor', 'partial' => true, 'offset_bytes' => $offset, 'bytes' => strlen($content), 'file_bytes' => $size, 'file_identity' => $identity, 'sha256' => hash('sha256', $content), 'sha256_scope' => 'returned_content', 'has_more' => $next < $size, 'next_cursor' => $cursor];
			$data += DataSafety::bytes($content, $path);
			return Result::ok($data);
		} finally { fclose($handle); }
	}
}
