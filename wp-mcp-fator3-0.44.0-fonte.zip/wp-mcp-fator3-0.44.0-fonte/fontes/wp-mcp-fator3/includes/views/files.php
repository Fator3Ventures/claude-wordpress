<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$enabled=PathGuard::is_enabled();
$hard=Admin::hard_block();
$access=Admin::access_values();
$policy=SqlArtifacts::policy();
?>
<div class="f3-page-intro"><h2>Arquivos e banco</h2><p>Defina o acesso geral do site. Cada conexão também precisa de um perfil e das permissões do usuário WordPress.</p></div>
<section class="f3-card"><h3>Acesso</h3>
<?php if (is_wp_error($access)): ?><p role="alert"><?php echo esc_html($access->get_error_message()); ?></p>
<?php else: ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="f3-access-form">
<?php Admin::nonce('f3_mcp_access'); ?>
<input type="hidden" name="action" value="f3_mcp_access"><input type="hidden" name="revision" value="<?php echo esc_attr(hash('sha256',serialize($access))); ?>">
<?php foreach ([
    'channel'=>[PathGuard::OPTION_ENABLED,'Canal de arquivos e banco','Fechar o canal bloqueia as chamadas de arquivos, temas, plugins e banco. Conteúdo e mídia seguem as permissões do cliente.',$enabled?'Aberto':'Fechado'],
    'database'=>[Database::OPTION_WRITES,'Escrita SQL','Exige canal aberto, perfil autorizado e prévia confirmada pelo cliente.',$enabled && Database::writes_enabled()?'Liberada':'Bloqueada'],
] as $name=>[$option,$label,$help,$state]): ?>
<div class="f3-setting-row"><div><label for="f3-<?php echo esc_attr($name); ?>"><?php echo esc_html($label); ?></label><?php Admin::help('f3-help-'.$name,$help); ?></div><div class="f3-switch">
<input type="hidden" name="<?php echo esc_attr($name); ?>" value="<?php echo $name==='channel' && $hard?(int)$access[$option]:0; ?>"><input id="f3-<?php echo esc_attr($name); ?>" type="checkbox" name="<?php echo esc_attr($name); ?>" value="1" <?php checked($access[$option]); disabled($name==='channel' && $hard); ?> aria-describedby="f3-help-<?php echo esc_attr($name); ?>"><span><?php echo esc_html($state); ?></span></div></div>
<?php endforeach; ?>
<?php if ($hard || Admin::forced_by_filter() || has_filter('f3_mcp_db_writes_enabled')): ?><p class="f3-callout">A configuração do servidor também controla o estado efetivo. Confira as restrições abaixo.</p><?php endif; ?>
<div class="f3-setting-row"><div><label for="f3-global-limit">Limite por arquivo</label><?php Admin::help('f3-global-help','De 1 a 1.024 MiB. Um cliente de Manutenção pode ter limite próprio.'); ?></div>
<div><input id="f3-global-limit" type="number" required min="1" max="1024" step="any" name="file_mib" value="<?php echo esc_attr((string)($access['f3_mcp_file_bytes']/1048576)); ?>" aria-describedby="f3-global-help"> MiB</div></div>
<input type="hidden" name="form_complete" value="1"><div class="f3-actions"><button class="button button-primary">Salvar alterações</button><span class="description">Uma gravação para os três ajustes.</span></div></form><?php endif; ?>
<details><summary>Conferir alcance e restrições do servidor</summary><dl class="f3-facts">
<dt>Diretórios alcançáveis</dt><dd><?php echo esc_html(PathGuard::is_confined()?(implode(', ',PathGuard::roots())?:'Nenhuma raiz válida'):'Diretórios acessíveis ao processo PHP'); ?></dd>
<dt>Limite neste contexto</dt><dd><?php echo esc_html(size_format(PathGuard::max_bytes())); ?></dd>
<dt>Permissão da sua conta</dt><dd><?php echo PathGuard::can_edit()?'Autorizada':'Indisponível'; ?> · edit_themes + manage_options</dd>
<dt>open_basedir</dt><dd><?php echo esc_html(ini_get('open_basedir')?:'Não definido'); ?></dd>
<dt>Extensões permitidas</dt><dd><?php echo esc_html(implode(', ',PathGuard::allowed_extensions())?:'Todas, salvo bloqueios'); ?></dd>
<dt>Extensões bloqueadas</dt><dd><?php echo esc_html(implode(', ',PathGuard::denied_extensions())?:'Nenhuma regra adicional'); ?></dd>
<dt>Nomes protegidos</dt><dd><?php echo esc_html(implode(', ',PathGuard::denied_basenames())?:'Sem regra adicional'); ?></dd></dl></details></section>

<section class="f3-card"><h3 id="f3-retention">Retenção</h3><p>A prévia da limpeza seleciona cópias automáticas por idade ou quantidade. As cópias recentes protegidas e as referências ativas são preservadas.</p>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="f3-settings-form">
<?php Admin::nonce('f3_mcp_sql_retention'); ?>
<input type="hidden" name="action" value="f3_mcp_sql_retention"><input type="hidden" name="revision" value="<?php echo esc_attr(hash('sha256',serialize($policy))); ?>">
<div class="f3-field-grid"><?php foreach([
    'older_than_days'=>['Idade mínima (dias)',1,3650,'Idade a partir da qual uma cópia pode entrar na seleção.'],
    'max_count'=>['Máximo desejado',1,10000,'O excedente pode ser selecionado, inclusive antes da idade mínima.'],
    'min_keep'=>['Mínimo protegido',0,10000,'Quantidade de cópias recentes a preservar. Deve ser menor ou igual ao máximo.'],
] as $key=>$field): ?><div><label for="f3-<?php echo esc_attr($key); ?>"><?php echo esc_html($field[0]); ?></label>
<input id="f3-<?php echo esc_attr($key); ?>" name="<?php echo esc_attr($key); ?>" type="number" required aria-describedby="f3-retention-<?php echo esc_attr($key); ?>" min="<?php echo (int)$field[1]; ?>" max="<?php echo (int)$field[2]; ?>" value="<?php echo (int)$policy[$key]; ?>">
<?php Admin::help('f3-retention-'.$key,$field[3]); ?></div><?php endforeach; ?></div>
<button class="button button-primary">Salvar critérios</button><p class="description">Salvar define os critérios. A exclusão exige uma prévia e uma confirmação separadas.</p></form>
<?php OperationsAdmin::maintenance_form(); ?>
<p class="f3-related"><a href="<?php echo esc_url(add_query_arg('document','sql-retention',Admin::url('help'))); ?>">Como limpar backups SQL</a> · <a href="<?php echo esc_url(add_query_arg('document','release-0420',Admin::url('help'))); ?>">Pré-imagens de plugins</a> · <a href="<?php echo esc_url(add_query_arg('document','release-0390',Admin::url('help'))); ?>">Restaurar linhas de um UPDATE</a></p></section>
