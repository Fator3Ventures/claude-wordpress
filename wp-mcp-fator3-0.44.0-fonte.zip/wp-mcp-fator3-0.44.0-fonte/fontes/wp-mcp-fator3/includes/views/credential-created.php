<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$in_admin=get_current_screen() && get_current_screen()->id==='tools_page_wp-mcp-fator3';
if ($in_admin) require ABSPATH.'wp-admin/admin-header.php';
else {
    Admin::assets('tools_page_wp-mcp-fator3');
    iframe_header('Credencial criada · Fator3 MCP');
}
Admin::frame('connections');
?>
<div class="f3-page-intro"><h2>Credencial criada</h2><p>Confira a conta e copie a senha para configurar o cliente.</p></div>
<section class="f3-card"><h3><?php echo esc_html($input['label']); ?></h3><dl class="f3-facts">
<dt>Conta WordPress</dt><dd><?php echo esc_html($result['user_login']); ?></dd>
<dt>Perfil</dt><dd><?php echo esc_html(Admin::profile($result['profile'])); ?></dd>
<dt>Identidade</dt><dd><code><?php echo esc_html($result['connection_id']); ?></code></dd></dl>
<p>Copie a senha agora. Ela não será exibida novamente depois que você sair desta página.</p>
<details id="f3-receipt-secret"><summary>Mostrar senha de aplicação</summary><p><code id="f3-issued-password"><?php echo esc_html($result['application_password']); ?></code></p></details>
<?php if(!empty($result['receipt_pending'])): ?><p role="status">O perfil foi salvo. A atualização do comprovante de emissão ficou pendente.</p><?php endif; ?>
<p><a href="<?php echo esc_url(Admin::url('connections')); ?>">Voltar às conexões</a></p></section></div></div>
<script>
window.addEventListener('pagehide', () => {
    document.getElementById('f3-issued-password').textContent = '';
    document.getElementById('f3-receipt-secret').open = false;
});
</script>
<?php if ($in_admin) require ABSPATH.'wp-admin/admin-footer.php'; else iframe_footer(); ?>
