<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;

$channel=PathGuard::is_enabled();
$sql=$channel && Database::writes_enabled();
$ready=$status['server_registered'] && $status['tools_ready'] && !$status['errors'];
$active=0;
$inactive=0;
$clients=[];
$before=PHP_INT_MAX;
do {
    $page=Persistence::listing('connections',[],100,$before);
    $visible=array_filter($page,static fn($row)=>empty($row['internal_test']));
    $access=ConnectionContext::page_access($visible,time());
    $active+=count(array_filter($access));
    $inactive+=count($visible)-count(array_filter($access));
    $clients=array_merge($clients,$visible);
    usort($clients,static fn($a,$b)=>($b['last_seen']??0)<=>($a['last_seen']??0) ?: $b['_row_id']<=>$a['_row_id']);
    $clients=array_slice($clients,0,4);
    if ($page) $before=end($page)['_row_id'];
} while (count($page)===100);
$recent=Persistence::listing('audit',[],6);
$last_http=ConnectionStatus::previous(DAY_IN_SECONDS);
$private=Admin::storage_evidence();
$http_due=empty($last_http['success']);
$storage_due=empty($private['passed']) || strtotime($private['time'])<time()-DAY_IN_SECONDS;
$occupation=StateMaintenance::usage(['audit','backup-index']);
$policy=SqlArtifacts::policy();
?>
<div class="f3-page-intro"><h2>Visão geral</h2><p>Confira o estado do servidor, os clientes ativos e as verificações pendentes.</p></div>
<div class="f3-metrics">
<?php foreach ([
    ['Servidor MCP',$ready?'Em operação':'Requer atenção',$ready?'Rotas e ferramentas registradas':'Consulte o diagnóstico do servidor',$ready],
    ['Canal de arquivos e banco',$channel?'Aberto':'Fechado','Arquivos, temas, plugins e SQL',$channel],
    ['Escrita SQL',$sql?'Liberada':'Bloqueada','Exige perfil e prévia',$sql],
    ['Clientes ativos',(string)$active,$inactive.' sem acesso',true],
] as [$title,$value,$note,$ok]): ?>
<div class="f3-metric <?php echo $ok?'is-ready':''; ?>"><span><?php echo esc_html($title); ?></span><strong><?php echo esc_html($value); ?></strong><small><?php echo esc_html($note); ?></small></div>
<?php endforeach; ?></div>
<?php if ($http_due || $storage_due): ?><section class="f3-card f3-attention"><div class="f3-card-heading"><h3>Requer atenção</h3><span class="f3-badge is-muted"><?php echo ($http_due && $storage_due)?'2 itens':'1 item'; ?></span></div>
<?php if ($http_due): ?><div class="f3-summary-row" data-http-attention><span><?php echo $last_http?'A última verificação HTTP falhou.':'A comunicação HTTP não foi confirmada nas últimas 24 horas.'; ?></span><button class="button" id="f3-test" data-route="<?php echo esc_attr(ConnectionEndpoints::route()); ?>">Testar agora<span class="screen-reader-text"> a comunicação HTTP</span></button></div><p id="f3-test-result" role="status"></p><?php endif; ?>
<?php if ($storage_due): ?><div class="f3-summary-row"><span>A proteção HTTP do armazenamento privado requer verificação.</span><?php Admin::probe_form('overview'); ?></div><?php endif; ?></section><?php endif; ?>
<section class="f3-card f3-connection-card"><div class="f3-card-heading"><h3>Endereço do servidor</h3><a href="<?php echo esc_url(Admin::url('connection')); ?>">Como conectar um cliente</a></div>
<div class="f3-copy-row"><code id="f3-endpoint"><?php echo esc_html(ConnectionEndpoints::url()); ?></code><button class="button" type="button" data-copy="f3-endpoint">Copiar URL</button></div></section>
<div class="f3-overview-grid"><section class="f3-card"><div class="f3-card-heading"><h3>Atividade recente</h3><a href="<?php echo esc_url(Admin::url('history')); ?>">Abrir atividade</a></div>
<?php if (!$recent): ?><p>Nenhum evento registrado.</p><?php endif; ?>
<?php foreach ($recent as $event): $who=OperationsAdmin::event_client($event); ?><div class="f3-summary-row"><div><strong><?php echo esc_html(OperationsAdmin::event_label($event['ability'])); ?></strong> <?php if (empty($event['success'])): ?><span class="f3-badge f3-failed">Falhou</span><?php endif; ?><small><?php echo esc_html($who[0].' · '.$event['ability']); ?></small></div><small><?php echo Admin::time_html($event['time']); ?></small></div><?php endforeach; ?></section>
<div><section class="f3-card"><div class="f3-card-heading"><h3>Clientes</h3><a href="<?php echo esc_url(Admin::url('connections')); ?>">Gerenciar clientes</a></div>
<?php if (!$clients): ?><p>Nenhum cliente cadastrado.</p><?php endif; ?>
<?php foreach ($clients as $client): ?><div class="f3-summary-row"><div><strong><?php echo esc_html(OperationsAdmin::client_name($client)); ?></strong><small><?php echo empty($client['last_seen'])?'Acesso ainda não observado':'Último acesso '.Admin::time_html($client['last_seen']); ?></small></div><span class="f3-badge is-muted"><?php echo esc_html(Admin::profile($client['profile']??'')); ?></span></div><?php endforeach; ?></section>
<section class="f3-card"><div class="f3-card-heading"><h3>Armazenamento</h3><a href="<?php echo esc_url(Admin::url('files').'#f3-retention'); ?>">Retenção</a></div><dl class="f3-facts">
<dt>Registro de atividade</dt><dd><?php echo $occupation['audit']?esc_html($occupation['audit']['records'].' eventos · '.size_format($occupation['audit']['payload_bytes'],1)):'Indisponível'; ?></dd>
<dt>Backups indexados</dt><dd><?php echo $occupation['backup-index']?esc_html($occupation['backup-index']['records'].' cópias · '.size_format($occupation['backup-index']['indexed_file_bytes'],1)):'Indisponível'; ?></dd>
<dt>Backups SQL</dt><dd><?php echo esc_html(sprintf('Até %d cópias, mínimo protegido de %d, idade de %d dias.',$policy['max_count'],$policy['min_keep'],$policy['older_than_days'])); ?></dd></dl></section></div></div>
