<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$key = ConnectionStatus::key();
$oauth = (bool)apply_filters('wp_mcp_ultimate_enable_oauth', true) && class_exists('WpMcpUltimate\\OAuth\\Server');
$app_available = wp_is_application_passwords_available_for_user(wp_get_current_user());
$password_first = !$oauth && $app_available;
?>
<div class="f3-page-intro"><h2>Conexão</h2><p>Copie o endereço para o cliente MCP, escolha como ele vai se autenticar e verifique a comunicação.</p></div>
<section class="f3-card f3-connection-card">
    <div class="f3-card-heading"><h3>Endereço do servidor</h3><?php Admin::badge($status['core_loaded'], 'Servidor carregado', 'Servidor ausente'); ?></div>
    
    <div class="f3-copy-row"><code id="f3-endpoint"><?php echo esc_html(ConnectionEndpoints::url()); ?></code><button type="button" class="button" data-copy="f3-endpoint">Copiar URL</button></div>
    <p class="f3-subtle"><?php echo esc_html($status['registry_checked'] && !$status['errors'] ? 'Rotas e metatools registrados' : 'Abra o Diagnóstico para conferir o registro das rotas.'); ?></p>
    <?php foreach ($status['errors'] as $error): ?><p class="f3-error"><?php echo esc_html(ConnectionStatus::label($error)); ?></p><?php endforeach; ?>
    <details><summary>Compatibilidade com conexões existentes</summary><p>Conectores já configurados podem continuar usando este endereço.</p><div class="f3-copy-row"><code id="f3-legacy-endpoint"><?php echo esc_html(ConnectionEndpoints::url(ConnectionEndpoints::LEGACY)); ?></code><button type="button" class="button" data-copy="f3-legacy-endpoint">Copiar URL antiga</button></div></details>
</section>
<section class="f3-card">
    <h3>Autenticação do cliente</h3><p>Use OAuth se o cliente oferece uma tela de autorização. Para clientes que enviam credenciais no cabeçalho HTTP, use uma senha de aplicação.</p>
    <div class="f3-auth-tabs" role="tablist" aria-label="Forma de autenticação">
        <button type="button" id="f3-auth-oauth" role="tab" aria-selected="<?php echo $password_first?'false':'true'; ?>" tabindex="<?php echo $password_first?'-1':'0'; ?>" aria-controls="f3-oauth-panel" data-auth="oauth">OAuth</button>
        <button type="button" id="f3-auth-password" role="tab" aria-selected="<?php echo $password_first?'true':'false'; ?>" aria-controls="f3-password-panel" tabindex="<?php echo $password_first?'0':'-1'; ?>" data-auth="password">Senha de aplicação</button>
    </div>
    <div id="f3-oauth-panel" role="tabpanel" aria-labelledby="f3-auth-oauth" tabindex="0" <?php if($password_first)echo 'hidden'; ?>>
        <?php Admin::badge($oauth, 'OAuth habilitado', 'OAuth desabilitado'); ?>
        <p>Informe a URL no conector e autorize o acesso com sua conta WordPress. As ações respeitam as permissões dessa conta e o perfil autorizado no consentimento.</p>
        <?php if (!$oauth): ?><p>O OAuth foi desabilitado por configuração. Use uma senha de aplicação ou revise o filtro de autenticação com o administrador.</p><?php endif; ?>
        <p class="description">Este fluxo não exige gerar uma senha de aplicação nesta tela.</p>
    </div>
    <div id="f3-password-panel" role="tabpanel" aria-labelledby="f3-auth-password" tabindex="0" <?php if(!$password_first)echo 'hidden'; ?>>
        <p>Use esta opção em clientes que aceitam o cabeçalho Authorization com usuário e senha de aplicação. A senha também autentica sua conta nas APIs nativas do WordPress que aceitam senhas de aplicação.</p>
        <p id="f3-key-status"><?php echo esc_html($key ? 'Senha de aplicação cadastrada.' : 'Nenhuma senha de aplicação cadastrada por este plugin.'); ?></p>
        <p><label for="f3-key-profile">Perfil da nova conexão</label> <select id="f3-key-profile"><option value="read">Leitura</option><option value="content">Conteúdo</option></select></p><p class="description">Para definir diretórios, conceder Manutenção ou escolher uma conta de serviço, abra <a href="<?php echo esc_url(Admin::url('connections')); ?>">Clientes conectados</a>.</p>
        <div class="f3-actions"><button type="button" class="button button-primary" id="f3-generate" <?php echo $key ? 'hidden' : ''; ?> <?php disabled(!$app_available); ?>>Gerar senha de aplicação</button><button type="button" class="button f3-danger" id="f3-revoke" <?php echo !$key ? 'hidden' : ''; ?>>Revogar senha</button></div>
        <?php if (!$app_available): ?><p class="f3-error">Senhas de aplicação indisponíveis. Confira HTTPS e as restrições de autenticação deste ambiente.</p><?php endif; ?>
        <div id="f3-revoke-confirm" class="f3-inline-confirm" hidden><p>A revogação interrompe os conectores que usam esta senha de aplicação.</p><div class="f3-actions"><button type="button" class="button f3-danger" id="f3-revoke-yes">Confirmar revogação</button><button type="button" class="button" id="f3-revoke-no">Cancelar</button></div></div>
        <div id="f3-key-output" hidden><p><strong>Copie a senha agora.</strong> Ela não será exibida novamente após sair desta página.</p><div class="f3-copy-row"><code id="f3-key-value"></code><button type="button" class="button" data-copy="f3-key-value">Copiar senha</button></div></div>
    </div>
</section>
<section class="f3-card"><h3>Modelos de configuração</h3><p>Escolha o cliente para copiar o JSON da autenticação selecionada.</p>
    <?php foreach (['claude-code' => ['Claude Code', 'Arquivo .mcp.json do projeto; type=http.'], 'cursor' => ['Cursor', 'Arquivo .cursor/mcp.json.'], 'desktop' => ['Claude Desktop / cliente stdio', 'Para clientes que exigem um processo local: modelo com mcp-remote e Node.js instalado. Para conectores remotos nativos, use a URL e OAuth.']] as $id => $client): ?>
    <details class="f3-config" data-client="<?php echo esc_attr($id); ?>"><summary>Ver configuração para <?php echo esc_html($client[0]); ?></summary><p><?php echo esc_html($client[1]); ?></p><p class="f3-config-note">Modelo de configuração.</p><div class="f3-code-actions"><button type="button" class="button" data-copy="f3-json-<?php echo esc_attr($id); ?>">Copiar JSON</button></div><pre tabindex="0"><code id="f3-json-<?php echo esc_attr($id); ?>"></code></pre></details>
    <?php endforeach; ?>
    <noscript><p>Ative JavaScript para gerar e copiar os modelos JSON. A URL acima continua disponível para seleção manual.</p></noscript>
</section>
<section class="f3-card"><h3>Verificar comunicação</h3><?php Admin::test_controls($status); ?><p><a href="<?php echo esc_url(Admin::url('diagnostics')); ?>">Abrir diagnóstico</a></p></section>
