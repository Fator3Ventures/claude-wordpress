<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$report = $status;
$report['http_test'] = ConnectionStatus::previous();
$storage = ''; $storage_error = '';
try { $storage = StateStore::directory(); } catch (\Throwable $e) { $storage_error = 'Não foi possível acessar o armazenamento privado.'; }
?>
<div class="f3-page-intro"><h2>Diagnóstico</h2><p>Confira as rotas registradas, a proteção do armazenamento e a fonte de atualização.</p></div>
<section class="f3-card"><div class="f3-card-heading"><h3>Estado do servidor</h3><a href="<?php echo esc_url(add_query_arg('success','0',Admin::url('history'))); ?>">Ver falhas na Atividade</a></div>
<dl class="f3-facts"><dt>Servidor MCP</dt><dd><?php echo esc_html($status['core_loaded'] ? ($status['integrated_core_loaded'] ? 'Núcleo integrado carregado' : 'Núcleo externo carregado') : 'Núcleo ausente'); ?></dd><dt>API de habilidades</dt><dd><?php echo $status['abilities_api'] ? 'Disponível' : 'Não carregada'; ?></dd><dt>Registro REST</dt><dd><?php echo $status['registry_checked'] ? 'Verificado nesta solicitação' : 'Ainda não verificado'; ?></dd><dt>Ferramentas MCP</dt><dd><?php echo $status['tools_ready'] ? 'Ferramentas de controle disponíveis' : 'Registro pendente ou incompleto'; ?></dd><dt>Última verificação local</dt><dd><?php echo Admin::time_html($status['checked_at']); ?></dd></dl>
<?php foreach ($status['errors'] as $code): ?><p class="f3-error"><?php echo esc_html(ConnectionStatus::label($code)); ?> <code><?php echo esc_html($code); ?></code></p><?php endforeach; ?>
<div class="f3-table-scroll"><table class="widefat striped"><caption>Endereços deste servidor</caption><thead><tr><th scope="col">Endereço</th><th scope="col">Papel</th><th scope="col">Registro</th></tr></thead><tbody><?php foreach ($status['endpoints'] as $entry): ?><tr><td><code><?php echo esc_html($entry['url']); ?></code></td><td><?php echo esc_html(['primary' => 'Principal','legacy' => 'Compatibilidade','alias' => 'Alternativo'][$entry['role']]); ?></td><td><?php echo esc_html($entry['conflict'] ? 'Conflito de rota' : ($entry['registered'] ? 'Registrado' : 'Não confirmado')); ?></td></tr><?php endforeach; ?></tbody></table></div>
<details><summary>Relatório técnico sem credenciais</summary><p>Contém URLs e estados locais. Confira as informações antes de compartilhar.</p><button type="button" class="button" data-copy="f3-diagnostic-json">Copiar relatório</button><pre tabindex="0"><code id="f3-diagnostic-json"><?php echo esc_html(wp_json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)); ?></code></pre></details></section>
<?php $oauth_failures=\WpMcpUltimate\OAuth\ClientDiagnostics::listing(); ?>
<section class="f3-card"><h3>Falhas de autorização de clientes</h3>
<p>Últimas 128 falhas, da mais recente para a mais antiga. Compare o identificador exibido na autorização. A ausência de registro não comprova sucesso.</p>
<?php if(empty($oauth_failures['success'])): ?><p class="f3-error"><?php echo esc_html($oauth_failures['message']); ?></p>
<?php elseif(!$oauth_failures['entries']): ?><p>Nenhuma falha de autorização de cliente registrada.</p>
<?php else: ?><div class="f3-table-scroll" tabindex="0" role="region" aria-label="Falhas de autorização de clientes"><table class="widefat striped"><thead><tr><th scope="col">Identificador</th><th scope="col">Categoria</th><th scope="col">Quando</th></tr></thead><tbody>
<?php foreach($oauth_failures['entries'] as $failure): ?><tr><td><code><?php echo esc_html($failure['diagnostic_id']); ?></code></td><td><code><?php echo esc_html($failure['category']); ?></code></td><td><?php echo Admin::time_html($failure['time']); ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?></section>
<section class="f3-card"><h3>Armazenamento e backups</h3><?php if ($storage_error): ?><p class="f3-error"><?php echo esc_html($storage_error); ?></p><?php else: ?><dl class="f3-facts"><dt>Armazenamento privado atual</dt><dd><code><?php echo esc_html($storage); ?></code></dd><dt>Backups novos</dt><dd>Protegidos por envelope PHP, acessíveis por backups/list, backups/export e files/restore.</dd><dt>Acervo legado</dt><dd><code><?php echo esc_html(wp_normalize_path(WP_CONTENT_DIR) . '/f3-mcp-backups'); ?></code> — <?php echo is_dir(WP_CONTENT_DIR . '/f3-mcp-backups') ? 'diretório presente' : 'diretório não encontrado'; ?></dd></dl><p class="description">A configuração HTTP de proteção dos arquivos precisa ser verificada no servidor de hospedagem. A retenção de backups não é executada ao abrir esta tela.</p><?php endif; ?></section>
<section class="f3-card"><h3>Proteção HTTP do armazenamento privado</h3>
<p>A sonda faz uma requisição anônima a um marcador temporário e verifica se o servidor recusa o acesso.</p>
<?php $probe=Admin::storage_evidence(); if ($probe): ?><p><?php echo !empty($probe['passed'])?'Proteção confirmada':'Proteção não confirmada'; ?> · <?php echo Admin::time_html($probe['time']); ?> · HTTP <?php echo (int)$probe['status_code']; ?></p><?php else: ?><p>Nenhuma verificação registrada para este endereço.</p><?php endif; ?>
<?php Admin::probe_form('diagnostics'); ?></section>
<?php UpdateChannel::render(); do_action('f3_mcp_uninstall_settings'); ?>
