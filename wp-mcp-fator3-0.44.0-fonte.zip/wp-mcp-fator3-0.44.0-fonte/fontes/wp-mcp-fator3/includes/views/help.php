<?php
namespace Fator3\McpFiles;
require_once F3_MCP_FILES_DIR . 'includes/Markdown.php';
if (!current_user_can('manage_options'))return;
$url=Admin::url('help');
$release_document = 'release-' . str_replace('.', '', F3_MCP_FILES_VERSION);
$query=is_string($_GET['doc_search']??null)?trim(wp_unslash($_GET['doc_search'])):'';
$document=is_string($_GET['document']??null)?wp_unslash($_GET['document']):'indice';
?>
<div class="f3-page-intro"><h2>Ajuda</h2><p>Consulte o manual da versão <?php echo esc_html(F3_MCP_FILES_VERSION); ?>. O assistente pode ler os mesmos textos com <code>system/guide</code>.</p></div>
<section class="f3-card"><form method="get" class="f3-search" action="<?php echo esc_url(admin_url('tools.php')); ?>">
<input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="tab" value="help">
<label for="f3-doc-search">Pesquisar nos documentos instalados</label><div class="f3-actions"><input type="search" id="f3-doc-search" name="doc_search" minlength="2" maxlength="200" value="<?php echo esc_attr($query); ?>"><button class="button">Pesquisar</button></div>
</form>
<?php if($query!==''):
    $result=preg_match('/^.{2,200}$/usD',$query)?Guide::search(['query'=>$query,'limit'=>20]):Result::fail('guide_input_invalid','Use entre 2 e 200 caracteres.');
    if(empty($result['success'])): ?><p role="alert"><?php echo esc_html($result['message']); ?></p>
    <?php elseif(empty($result['matches'])): ?><p>Nenhuma seção encontrada. Experimente um termo como “perfil” ou “retenção”.</p>
    <?php else: ?><h3>Resultados da pesquisa</h3><p><?php echo (int)$result['returned']; ?> de <?php echo (int)$result['total_matches']; ?> seções encontradas.</p><ul class="f3-link-list">
        <?php foreach($result['matches'] as $hit): ?><li><a href="<?php echo esc_url(add_query_arg(['document'=>$hit['document_id'],'cursor'=>$hit['cursor']],$url)); ?>"><?php echo esc_html($hit['section']); ?></a><small><?php echo esc_html($hit['document_title']); ?></small><p><?php echo esc_html($hit['snippet']); ?></p></li><?php endforeach; ?>
    </ul><?php endif; ?>
    <p><a href="<?php echo esc_url($url); ?>">Limpar pesquisa</a></p></section><?php return; endif; ?>
<div class="f3-related"><a href="<?php echo esc_url(add_query_arg('document','administracao',$url)); ?>">Configurar o MCP</a> · <a href="<?php echo esc_url(add_query_arg('document','atualizacao',$url)); ?>">Instalar a versão</a> · <a href="<?php echo esc_url(add_query_arg('document', $release_document, $url)); ?>">Notas desta versão</a></div>
</section>
<?php

$catalog = Guide::documents() ?? [];
$groups = ['guia'=>'Guias', 'contrato'=>'Contratos', 'release'=>'Notas de versão', 'historico'=>'Histórico'];
$urls = [];
foreach (array_keys($catalog) as $key) $urls[$key] = add_query_arg('document', $key, $url);
$notice = isset($catalog[$document]) ? '' : 'Documento indisponível. Abra um documento da lista.';
$pages = $notice === '' ? Markdown::pages($catalog[$document]['content']) : [];
$index = 0;
if (isset($_GET['cursor']) && is_string($_GET['cursor'])) {
    $match = Guide::read(['document'=>$document, 'cursor'=>wp_unslash($_GET['cursor']), 'byte_limit'=>256]);
    if (empty($match['success'])) {
        $notice = $match['message'] ?? 'Seção indisponível.';
    } else {
        foreach ($pages as $i => $page) if ($page['offset'] <= $match['offset_bytes']) $index = $i;
    }
} elseif (isset($_GET['section'])) {
    $requested = filter_var($_GET['section'], FILTER_VALIDATE_INT);
    if ($requested === false || $requested < 1 || $requested > count($pages)) $notice = 'Página indisponível. Abra o documento novamente.';
    else $index = $requested - 1;
}
?>
<section class="f3-card"><form method="get" action="<?php echo esc_url(admin_url('tools.php')); ?>" class="f3-search">
<input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="tab" value="help">
<label for="f3-help-document">Abrir documento</label><div class="f3-actions"><select name="document" id="f3-help-document">
<?php foreach ($groups as $kind => $label): ?><optgroup label="<?php echo esc_attr($label); ?>">
<?php foreach ($catalog as $key => $doc): if ($doc['kind'] !== $kind) continue; ?>
<option value="<?php echo esc_attr($key); ?>" <?php selected($document, $key); ?>><?php echo esc_html($doc['title']); ?></option>
<?php endforeach; ?></optgroup><?php endforeach; ?>
</select><button class="button">Abrir</button></div></form>
<?php if ($notice !== ''): ?><p role="alert"><?php echo esc_html($notice); ?></p>
<?php else: ?>
<p class="description"><?php echo esc_html($catalog[$document]['title']); ?> · Página <?php echo $index+1; ?> de <?php echo count($pages); ?></p>
<article class="f3-guide"><?php echo Markdown::render($pages[$index]['content'], $urls); ?></article>
<nav class="f3-actions" aria-label="Páginas do documento">
<?php if ($index > 0): ?><a href="<?php echo esc_url(add_query_arg('section', $index, $urls[$document])); ?>">Página anterior</a><?php endif; ?>
<?php if ($index + 1 < count($pages)): ?><a class="button" href="<?php echo esc_url(add_query_arg('section', $index+2, $urls[$document])); ?>">Continuar leitura</a><?php endif; ?></nav>
<?php endif; ?></section>
