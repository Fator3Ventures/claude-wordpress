<?php
/** Environment diagnostics and compact capability discovery. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SystemTools {
	public static function register(): void {
		Registry::add('system/capabilities', 'Report the loaded MCP distribution, user capabilities, channel gates, optional components and configured limits.', [], [], [self::class, 'capabilities'], 'edit_posts');
		Registry::add('system/health', 'Read local diagnostics for MCP, PHP, WordPress, private storage and database. Does not claim an external HTTP or OAuth connectivity test.', Diagnostics::schema(['healthy','plugin_version','mutation_audit','cron','recovery','incidents_24h','checks','storage','environment','connection','audit','providers','maintenance','database_class','external_connectivity_tested']), [], [self::class, 'health'], 'manage_options');
        Registry::add('system/oauth-diagnostics', 'Consulta as últimas 128 falhas de autorização de clientes, com identificador, categoria e horário; sem credenciais ou consultas externas.', Diagnostics::schema(['entries','total','limit','order','time_format','retention','incidents_24h']), [], [Diagnostics::class,'oauth'], 'manage_options');
		$page = ['offset' => Registry::integer(), 'per_page' => Registry::integer(1, 200)];
		Registry::add('audit/list', 'List operation metadata without request payloads or credentials. Filtros exatos por habilidade, usuário, conexão, alvo, operação, resultado e período. before é alias de cursor; path é alias de target; aliases divergentes são recusados.', ['ability' => Registry::string(), 'user' => Registry::integer(1), 'success' => Registry::boolean(null), 'before' => Registry::string(), 'cursor'=>Registry::string(), 'path'=>Registry::string(),'target'=>Registry::string(),'connection_id'=>Registry::string(),'operation_id'=>Registry::string(),'since'=>Registry::string(),'until'=>Registry::string(), 'per_page' => Registry::integer(1, 200)], [], [Audit::class, 'listing']);
        Registry::add('audit/get-service-operation', 'Consulta o recibo técnico de uma escrita de serviço. Exige administrador, perfil autorizado e concessão vigente no provedor. Não reenvia conversões nem lê payloads.', MutationServiceAudit::identity_schema(), array_keys(MutationServiceAudit::identity_schema()), [MutationServiceAudit::class,'get']);
        Registry::add('audit/get-operation', 'Consulta antes/depois pelo leitor público do provedor. Exige administrador, usuário e conexão de origem, perfil autorizado e ativos ainda selecionados. Não restaura nem repete a operação.', ['provider'=>['type'=>'string','pattern'=>'^[a-z0-9-]{1,100}$'],'operation_id'=>['type'=>'string','pattern'=>'^[a-f0-9]{64}$']], ['provider','operation_id'], [MutationAudit::class,'get']);
		Registry::add('audit/prune', 'Evaluate or remove audit records older than the chosen age. dry_run defaults to true.', ['older_than_days' => Registry::integer(1, 3650), 'dry_run' => Registry::boolean(true),'max_total_bytes'=>Registry::integer(1),'before_id'=>Registry::integer(1),'expected_selection_sha256'=>Registry::string()], [], [Audit::class, 'prune'], 'manage_options', false);
		Registry::add('backups/list', 'List protected file/database backup metadata, from the supported private format.', $page + ['plugin'=>Registry::string(),'type'=>['type'=>'string','enum'=>['package_preimage','snapshot','file','database']],'category'=>['type'=>'string','enum'=>['backups','sql_mutation','sql_artifacts']],'path' => Registry::string(),'label'=>Registry::string(),'rotulo'=>Registry::string(),'since'=>Registry::string(),'until'=>Registry::string()], [], [Backups::class, 'listing'], [FileTools::class, 'permission']);
		Registry::add('backups/export', 'Export one backup as base64 JSON with SHA-256. Binary database cells use explicit base64 encoding.', ['backup_id' => Registry::string()], ['backup_id'], [Backups::class, 'export'], [FileTools::class, 'permission']);
		Registry::add('backups/prune', 'Simula poda por IDs ou política. package_preimages aceita slug ou arquivo principal e seleciona cópias substituídas no mesmo plugin ou anteriores a age_cutoff. Em inventory_incomplete, repita os critérios com next_cursor. Confira blocked antes de aplicar o lote com expected_selection_sha256.', ['policy'=>['type'=>'string','enum'=>['standard','package_preimages']],'plugin'=>Registry::string(),'category'=>['type'=>'string','enum'=>['backups','sql_mutation','sql_artifacts']],'artifact_ids'=>['type'=>'array','items'=>['type'=>'string','pattern'=>'^(?:db)?[a-fA-F0-9]{16,64}$'],'minItems'=>1,'maxItems'=>200,'uniqueItems'=>true],'exclude_ids'=>['type'=>'array','items'=>['type'=>'string','pattern'=>'^(?:db)?[a-fA-F0-9]{16,64}$'],'minItems'=>1,'maxItems'=>200,'uniqueItems'=>true],'max_count'=>Registry::integer(1,10000),'min_keep'=>Registry::integer(0,10000),'older_than_days' => Registry::integer(1, 3650), 'max_total_bytes' => Registry::integer(), 'dry_run' => Registry::boolean(true),'expected_selection_sha256'=>Registry::string(),'selection_sha256'=>Registry::string(),'cursor'=>Registry::string()], [], [Backups::class, 'prune'], [FileTools::class, 'permission'], false);
	}
	public static function capabilities(array $input = []): array {
		global $wp_version;
		$caps = []; foreach (['edit_posts','edit_pages','publish_posts','manage_options','edit_theme_options','switch_themes','install_themes','install_plugins','update_plugins','delete_plugins','edit_files','unfiltered_html'] as $cap) $caps[$cap] = current_user_can($cap);
		$loaded = defined('WP_MCP_ULTIMATE_DIR') ? wp_normalize_path(WP_MCP_ULTIMATE_DIR) : '';
		$integrated = '' !== $loaded && str_starts_with($loaded, wp_normalize_path(F3_MCP_FILES_DIR));
        $context=ConnectionContext::get()??[];
        $metatools=['Discover Abilities','Get Ability Info','Execute Ability'];if(!empty($context['readonly_executor']))$metatools[]='Execute Readonly Ability';
        $channel_allowed=static fn($name,$read)=>!is_wp_error(AuthorizationPolicy::check($name,[],$read,true));
		return Result::ok(['plugin_version' => F3_MCP_FILES_VERSION, 'mutation_audit'=>MutationAudit::status(), 'mutation_service_audit'=>MutationServiceAudit::status(), 'wordpress' => $wp_version, 'php' => PHP_VERSION, 'site_id' => get_current_blog_id(), 'user_id' => get_current_user_id(), 'connection_context'=>array_intersect_key(ConnectionContext::get()??[],array_flip(['connection_id','profile','policy_version','expires','transport','readonly_executor'])), 'endpoint' => ConnectionEndpoints::url(), 'legacy_endpoint' => ConnectionEndpoints::url(ConnectionEndpoints::LEGACY), 'endpoints' => ConnectionEndpoints::entries(), 'metatools' => $metatools, 'integrated_core_loaded' => $integrated, 'upstream_version' => F3_MCP_UPSTREAM_VERSION, 'abilities_api' => version_compare($wp_version, '6.9', '>=') ? 'wordpress-native' : 'bundled-polyfill', 'capabilities' => $caps, 'channels' => ['files' => PathGuard::is_enabled() && PathGuard::can_edit() && $channel_allowed('files/read',true) && (in_array($context['profile']??'',['maintenance'],true)||!empty($context['roots'])), 'database_read' => PathGuard::is_enabled() && current_user_can('manage_options') && $channel_allowed('db/query',true), 'database_write' => PathGuard::is_enabled() && current_user_can('manage_options') && Database::writes_enabled() && $channel_allowed('db/execute',false) && (in_array($context['profile']??'',['maintenance'],true)||!empty($context['database_write']))], 'limits' => ['file_bytes' => PathGuard::max_bytes(), 'sql_rows' => SqlGuard::MAX_ROWS, 'sql_bytes' => ConnectionContext::maintenance()?1048576:65536, 'query_response_bytes'=>16777216,'transfer_part_bytes'=>262144, 'db_confirmation_seconds' => 600, 'plan_steps' => 50, 'lock_wait_seconds' => max(0, min(10, (float)apply_filters('f3_mcp_lock_timeout', 2.0)))], 'file_scope' => in_array($context['profile']??'',['maintenance'],true) ? (PathGuard::is_confined() ? 'configured_roots' : 'php_reachable_paths') : 'connection_roots', 'file_roots'=>$context['roots']??[], 'concurrency_scope' => 'Cooperating operations in this plugin and shared lock storage. External writers must use the same lock API.']);
	}
	public static function health(array $input = []): array {
		global $wpdb;
		$checks = ['abilities_api' => function_exists('wp_get_abilities'), 'mcp_adapter' => class_exists('WpMcpUltimate\\Server\\McpAdapter'), 'json' => function_exists('json_encode'), 'random_bytes' => function_exists('random_bytes'), 'flock' => function_exists('flock'), 'rest_configured' => (bool)ConnectionEndpoints::url(), 'persistence_schema'=>(int)get_option('f3_mcp_schema_version',0)===2];
        $connection = ConnectionStatus::snapshot();
        $checks['mcp_registration'] = $connection['registry_checked'] && !$connection['errors'];
        $recovery = method_exists(\Fator3\RecoveryV1\Engine::class, 'sweep_status') ? \Fator3\RecoveryV1\Engine::sweep_status() : ['status'=>'unavailable','reason'=>'sentinel_update_pending'];
        $recovery['runtime_refresh'] = Recovery::runtime_refresh_status();
        $checks['recovery_sweep'] = match ($recovery['status']??'') { 'checked' => true, 'degraded' => false, default => null };
        if($recovery['runtime_refresh']==='failed')$checks['recovery_sweep']=false;
		$storage = [];
		try { $dir = StateStore::directory(); $storage = ['path' => $dir, 'writable' => is_writable($dir), 'free_bytes' => @disk_free_space($dir), 'php_envelopes' => true, 'outside_document_root' => !str_starts_with(wp_normalize_path($dir) . '/', wp_normalize_path(realpath(ABSPATH) ?: ABSPATH)), 'http_protection_tested' => false]; $checks['private_storage'] = $storage['writable']; }
		catch (\Throwable $e) { $checks['private_storage'] = false; $storage['error'] = 'Armazenamento privado indisponível.'; }
		$storage['sql_artifacts']=SqlArtifacts::health();
        $probe=StateStore::get('diagnostics','private-http');
        $fingerprint=isset($storage['path'])?hash('sha256',wp_normalize_path($storage['path']).'|'.home_url('/')):'';
        if($probe && ($probe['fingerprint']??'')===$fingerprint && strtotime($probe['time']??'')>time()-DAY_IN_SECONDS) { $storage['http_protection_tested']=!empty($probe['tested']);$storage['http_protection_passed']=!empty($probe['passed']);$storage['http_protection_evidence']=$probe; }
        $suppress = $wpdb->suppress_errors(true); $one = $wpdb->get_var('SELECT 1'); $checks['database'] = '1' === (string)$one && !$wpdb->last_error; $wpdb->suppress_errors($suppress);
		$full=Result::ok(['healthy' => !in_array(false, $checks, true), 'checks' => $checks, 'storage' => $storage, 'recovery' => $recovery, 'database_class' => get_class($wpdb), 'environment' => self::capabilities(), 'external_connectivity_tested' => false, 'connection' => $connection,'cron'=>Probe::cron(),'audit'=>Audit::status(),'providers'=>Providers::all(),'maintenance'=>StateMaintenance::storage()]);
        return Diagnostics::health($full,$input);
	}
}
final class Discovery {
    public const SCHEMA_PAGE = 25;
    private const FIELDS = ['name','label','description','category','readonly','availability','version','provider','version_reason','schema_sha256','input_schema','output_schema'];

    public static function schema(): array {
        return ['type'=>'object', 'properties'=>[
            'query'=>Registry::string('Termos presentes no nome, rótulo, descrição, categoria ou provedor.'),
            'prefix'=>Registry::string('Prefixo do nome da habilidade.'),
            'category'=>Registry::string('Categoria exata da habilidade.'),
            'provider'=>['type'=>'string','pattern'=>'^[a-z0-9][a-z0-9-]{1,100}$','description'=>'Identificador do provedor.'],
            'readonly'=>Registry::boolean(null) + ['description'=>'Omitido, inclui leituras e escritas. true seleciona leituras e false seleciona escritas.'],
            'per_page'=>Registry::integer(1,200) + ['description'=>'Solicita página de 1 a 200 itens. Sem paginação explícita, devolve todos os alvos. Com schemas, até 25.'],
            'cursor'=>Registry::string('Continuação da mesma consulta. Repita os filtros da primeira página.'),
            'compact'=>Registry::boolean() + ['description'=>'Devolve a descrição vazia em cada item.'],
            'include_schemas'=>Registry::boolean() + ['description'=>'Inclui schemas de entrada e saída, com até 25 itens por página.'],
            'fields'=>['type'=>'array','items'=>['type'=>'string','enum'=>self::FIELDS],'minItems'=>1,'uniqueItems'=>true,'description'=>'Chaves mostradas em cada item. Para incluir os schemas, ative include_schemas.'],
            'summary'=>Registry::boolean() + ['description'=>'Agrupa as habilidades visíveis por provedor e conta as leituras e escritas.'],
            'if_catalog_sha256'=>['type'=>'string','pattern'=>'^[a-fA-F0-9]{64}$','description'=>'Hash da última consulta para verificar se o catálogo mudou.'],
        ], 'additionalProperties'=>false];
    }

    public static function output_schema(): array {
        $string = ['type'=>'string'];
        $integer = ['type'=>'integer'];
        $nullable = ['type'=>['string','null']];
        $boolean = ['type'=>'boolean'];
        $row = [
            'name'=>$string,'label'=>$string,'description'=>$string,'category'=>$string,
            'readonly'=>$boolean,'availability'=>$string,'version'=>$nullable,'provider'=>$string,
            'version_reason'=>$nullable,'schema_sha256'=>$string,
            'input_schema'=>['type'=>'object'],'output_schema'=>['type'=>'object'],
        ];
        $provider = ['provider'=>$string,'version'=>$nullable,'prefixes'=>['type'=>'array','items'=>$string],'reads'=>$integer,'writes'=>$integer];
        return ['type'=>'object','properties'=>[
            'abilities'=>['type'=>'array','items'=>['type'=>'object','properties'=>$row]],
            'providers'=>['type'=>'array','items'=>['type'=>'object','properties'=>$provider,'required'=>array_keys($provider)]],
            'success'=>$boolean,'message'=>$string,'error_code'=>$string,'error'=>$string,'data'=>Result::any_schema(),'conflict'=>$boolean,'retryable'=>$boolean,
            'total'=>$integer,'unchanged'=>$boolean,'catalog_sha256'=>$string,'plugin_version'=>$string,
            'has_more'=>$boolean,'next_cursor'=>$nullable,'per_page_effective'=>$integer,
        ]];
    }
    /** Shared visibility contract; target-dependent permissions remain requires_input. */
    public static function eligibility(\WP_Ability $ability): array {
        $meta=$ability->get_meta();$name=$ability->get_name();
        if(empty($meta['mcp']['public']))return ['visible'=>false,'availability'=>'private'];
        if(!str_starts_with($name,'wp-mcp-ultimate/')&&is_wp_error(AuthorizationPolicy::check($name,[],!empty($meta['annotations']['readonly']),true)))return ['visible'=>false,'availability'=>'profile_denied'];
        if($ability->get_input_schema()['required']??[])return ['visible'=>true,'availability'=>'requires_input'];
        try{$permission=$ability->check_permissions([]);$allowed=!is_wp_error($permission)&&(bool)$permission;}catch(\Throwable $error){return ['visible'=>true,'availability'=>'requires_input'];}
        return ['visible'=>$allowed,'availability'=>$allowed?'available':'permission_denied'];
    }
    /** Case- and accent-insensitive text used by the query filter (0.29.0). */
    public static function normalize(string $text): string {
        $text=remove_accents($text);
        $text=function_exists('mb_strtolower')?mb_strtolower($text,'UTF-8'):strtolower($text);
        return (string)preg_replace('/\s+/u',' ',$text);
    }
    /** Every term must occur (any order); a single term keeps the historical substring semantics. */
    public static function terms(string $query): array {
        return array_values(array_unique(array_filter(explode(' ',trim(self::normalize($query))),static fn($t)=>$t!=='')));
    }
    public static function listing(array $abilities, array $input): array {
        $terms = self::terms($input['query'] ?? '');
        $schemas = !empty($input['include_schemas']) && empty($input['summary']);
        $schema_sources = [];
        [$rows, $context] = ConnectionContext::with_snapshot(static function () use ($abilities, $input, $terms, $schemas, &$schema_sources): array {
            $context = [ConnectionContext::key(), ConnectionContext::get()['policy_version'] ?? null, get_current_user_id(), get_current_blog_id()];
            $rows = [];
            foreach ($abilities as $ability) {
                $meta = $ability->get_meta();
                $name = $ability->get_name();
                if (str_starts_with($name, 'wp-mcp-ultimate/') || ($meta['mcp']['type'] ?? 'tool') !== 'tool' || empty($meta['mcp']['public'])) continue;
                $readonly = !empty($meta['annotations']['readonly']);
                $category = $ability->get_category();
                $provider = $meta['fator3'] ?? [];
                if (!isset($provider['provider'], $provider['version'])) $provider += Providers::metadata($name);
                if (isset($input['prefix']) && !str_starts_with($name, $input['prefix']) ||
                    isset($input['category']) && $category !== $input['category'] ||
                    isset($input['readonly']) && $readonly !== $input['readonly'] ||
                    isset($input['provider']) && $provider['provider'] !== $input['provider']) continue;
                $label = $ability->get_label();
                $description = $ability->get_description();
                if ($terms) {
                    $searchable = self::normalize(implode(' ', [$name, $label, $description, $category, $provider['provider']]));
                    foreach ($terms as $term) if (!str_contains($searchable, $term)) continue 2;
                }
                $eligibility = self::eligibility($ability);
                if (!$eligibility['visible']) continue;
                if ($schemas) $schema_sources[$name] = $ability;
                $rows[$name] = [
                    'name'=>$name, 'label'=>$label, 'description'=>$description, 'category'=>$category,
                    'readonly'=>$readonly, 'availability'=>$eligibility['availability'],
                    'version'=>$provider['version'], 'provider'=>$provider['provider'], 'version_reason'=>$provider['version_reason'] ?? null,
                    'schema_sha256'=>hash('sha256', serialize([$ability->get_input_schema(), $ability->get_output_schema()])),
                ];
            }
            return [$rows, $context];
        });
        ksort($rows, SORT_STRING);
        $total = count($rows);
        $hash = hash('sha256', serialize([$context, $rows]));
        $base = ['total'=>$total, 'catalog_sha256'=>$hash, 'plugin_version'=>F3_MCP_FILES_VERSION];
        $filters = $input;
        unset($filters['cursor'], $filters['if_catalog_sha256']);
        ksort($filters);
        $filter_hash = hash('sha256', serialize($filters));
        $offset = 0;
        if (!empty($input['cursor'])) {
            $state = Cursor::decode($input['cursor']);
            if (is_wp_error($state)) return Result::error($state) + ['abilities'=>[]];
            if (($state['kind'] ?? '') !== 'abilities' || ($state['connection_id'] ?? '') !== $context[0] ||
                ($state['user'] ?? 0) !== $context[2] || ($state['blog'] ?? 0) !== $context[3] || ($state['filter'] ?? '') !== $filter_hash) {
                return Result::fail('cursor_invalid', 'Cursor de outra consulta, conta ou conexão.', ['abilities'=>[]]);
            }
            if (($state['catalog'] ?? '') !== $hash) return Result::fail('catalog_changed', 'O catálogo mudou. Reinicie a consulta.', ['conflict'=>true,'abilities'=>[]]);
            $offset = $state['offset'] ?? null;
            if (!is_int($offset) || $offset < 0 || $offset >= $total) return Result::fail('cursor_invalid', 'Posição inválida no catálogo.', ['abilities'=>[]]);
        }
        $summary = !empty($input['summary']);
        if (isset($input['if_catalog_sha256']) && hash_equals($hash, strtolower($input['if_catalog_sha256']))) {
            return Result::ok($base + ['unchanged'=>true, 'has_more'=>false, 'next_cursor'=>null] + ($summary ? [] : ['abilities'=>[]]));
        }
        if ($summary) return Result::ok($base + ['unchanged'=>false, 'providers'=>self::provider_counts($rows), 'has_more'=>false, 'next_cursor'=>null]);

        $paginated = isset($input['per_page']) || isset($input['cursor']) || $schemas;
        $limit = $paginated ? max(1, min($schemas ? self::SCHEMA_PAGE : 200, (int)($input['per_page'] ?? 50))) : max(1, $total);
        $projection = isset($input['fields']) ? array_flip($input['fields']) : null;
        $page = [];
        foreach (array_slice($rows, $offset, $limit) as $row) {
            if (!empty($input['compact'])) $row['description'] = '';
            if ($schemas) {
                $ability = $schema_sources[$row['name']];
                $row['input_schema'] = $ability->get_input_schema();
                $output = $ability->get_output_schema();
                if ($output) $row['output_schema'] = $output;
            }
            $page[] = $projection === null ? $row : array_intersect_key($row, $projection);
        }
        $next = $offset + count($page);
        return Result::ok($base + [
            'abilities'=>$page, 'unchanged'=>false, 'has_more'=>$next < $total, 'per_page_effective'=>$limit,
            'next_cursor'=>$next < $total ? Cursor::encode(['kind'=>'abilities','connection_id'=>$context[0],'user'=>$context[2],'blog'=>$context[3],'filter'=>$filter_hash,'catalog'=>$hash,'offset'=>$next]) : null,
        ]);
    }

    /** Count only namespaces represented among the visible, filtered targets. */
    private static function provider_counts(array $rows): array {
        $groups = [];
        foreach ($rows as $row) {
            $id = $row['provider'];
            $groups[$id] ??= ['provider'=>$id, 'version'=>$row['version'], 'prefixes'=>[], 'reads'=>0, 'writes'=>0];
            $prefix = explode('/', $row['name'], 2)[0] . '/';
            $groups[$id]['prefixes'][$prefix] = $prefix;
            ++$groups[$id][$row['readonly'] ? 'reads' : 'writes'];
        }
        ksort($groups, SORT_STRING);
        foreach ($groups as &$group) sort($group['prefixes'], SORT_STRING);
        return array_values($groups);
    }
}
