<?php
namespace Fator3\McpFiles;

if (!defined('ABSPATH')) { exit; }

/** The installed handbook supports only these Markdown constructs. Text is always escaped. */
final class Markdown {
    /** Byte offsets are used only to locate a search match within whole administrative pages. */
    public static function pages(string $text, int $budget = 3500): array {
        $starts = [0];
        $pageStart = 0;
        $sectionStart = 0;
        $offset = 0;
        $fenced = false;
        foreach (explode("\n", $text) as $line) {
            if (preg_match('/^\s*```/', $line)) {
                $fenced = !$fenced;
            } elseif (!$fenced && preg_match('/^#{1,2} /', $line)) {
                if ($sectionStart > $pageStart && $offset - $pageStart > $budget) {
                    $starts[] = $sectionStart;
                    $pageStart = $sectionStart;
                }
                $sectionStart = $offset;
            }
            $offset += strlen($line) + 1;
        }
        if ($sectionStart > $pageStart && strlen($text) - $pageStart > $budget) {
            $starts[] = $sectionStart;
        }
        $pages = [];
        foreach ($starts as $i => $start) {
            $end = $starts[$i + 1] ?? strlen($text);
            $pages[] = ['offset' => $start, 'content' => substr($text, $start, $end - $start)];
        }
        return $pages;
    }

    private static function inline(string $line, array $urls): string {
        $pattern = '~`([^`\n]+)`|\*\*([^*\n]+)\*\*|\[([^]\n]+)\]\(([^)\s]+)\)~u';
        preg_match_all($pattern, $line, $tokens, PREG_SET_ORDER | PREG_OFFSET_CAPTURE | PREG_UNMATCHED_AS_NULL);
        $html = '';
        $offset = 0;
        foreach ($tokens as $token) {
            [$raw, $start] = $token[0];
            $html .= esc_html(substr($line, $offset, $start - $offset));
            if ($token[1][0] !== null) {
                $html .= '<code>' . esc_html($token[1][0]) . '</code>';
            } elseif ($token[2][0] !== null) {
                $html .= '<strong>' . esc_html($token[2][0]) . '</strong>';
            } else {
                $label = esc_html($token[3][0]);
                $id = strtolower(preg_replace('/\.md$/i', '', $token[4][0]));
                $html .= isset($urls[$id]) ? '<a href="' . esc_url($urls[$id]) . '">' . $label . '</a>' : $label;
            }
            $offset = $start + strlen($raw);
        }
        return $html . esc_html(substr($line, $offset));
    }

    private static function listType(string $line): ?string {
        if (preg_match('/^\s*[-*] +/', $line)) return 'ul';
        if (preg_match('/^\s*\d+[.)] +/', $line)) return 'ol';
        return null;
    }

    private static function cells(string $line): array {
        return array_map('trim', explode('|', trim(trim($line), '|')));
    }

    private static function tableStarts(array $lines, int $i): bool {
        return str_starts_with(trim($lines[$i]), '|') && isset($lines[$i + 1])
            && (bool) preg_match('/^\s*\|(?:\s*:?-{3,}:?\s*\|)+\s*$/', $lines[$i + 1]);
    }

    public static function render(string $markdown, array $urls): string {
        $lines = explode("\n", $markdown);
        $html = '';
        for ($i = 0, $count = count($lines); $i < $count;) {
            $line = $lines[$i++];
            if (trim($line) === '') continue;
            if (preg_match('/^\s*```/', $line)) {
                $code = [];
                while ($i < $count && !preg_match('/^\s*```/', $lines[$i])) $code[] = $lines[$i++];
                ++$i;
                $html .= '<pre tabindex="0"><code>' . esc_html(implode("\n", $code)) . '</code></pre>';
            } elseif (preg_match('/^(#{1,6})\s+(.+)$/', $line, $heading)) {
                $level = min(strlen($heading[1]) + 2, 6);
                $html .= "<h{$level}>" . self::inline($heading[2], $urls) . "</h{$level}>";
            } elseif (self::tableStarts($lines, $i - 1)) {
                ++$i;
                $html .= '<div class="f3-guide-table" tabindex="0" role="region" aria-label="Tabela do documento"><table class="widefat striped"><thead><tr>';
                foreach (self::cells($line) as $cell) $html .= '<th scope="col">' . self::inline($cell, $urls) . '</th>';
                $html .= '</tr></thead><tbody>';
                while ($i < $count && str_starts_with(trim($lines[$i]), '|')) {
                    $html .= '<tr>';
                    foreach (self::cells($lines[$i++]) as $cell) $html .= '<td>' . self::inline($cell, $urls) . '</td>';
                    $html .= '</tr>';
                }
                $html .= '</tbody></table></div>';
            } elseif (($type = self::listType($line)) !== null) {
                $html .= "<{$type}>";
                do {
                    $item = preg_replace('/^\s*(?:[-*]|\d+[.)]) +/', '', $line);
                    $html .= '<li>' . self::inline($item, $urls) . '</li>';
                    if ($i >= $count || self::listType($lines[$i]) !== $type) break;
                    $line = $lines[$i++];
                } while (true);
                $html .= "</{$type}>";
            } else {
                $paragraph = [$line];
                while ($i < $count && trim($lines[$i]) !== '' && !preg_match('/^\s*(?:```|#{1,6}\s)/', $lines[$i])
                    && self::listType($lines[$i]) === null && !self::tableStarts($lines, $i)) {
                    $paragraph[] = $lines[$i++];
                }
                $html .= '<p>' . self::inline(implode(' ', $paragraph), $urls) . '</p>';
            }
        }
        return $html;
    }
}
