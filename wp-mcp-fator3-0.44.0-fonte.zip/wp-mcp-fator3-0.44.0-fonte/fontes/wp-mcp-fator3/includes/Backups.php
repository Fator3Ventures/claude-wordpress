<?php
/** Private backup envelopes and metadata from the supported data format. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Backups {
    private static ?string $label=null;
    public static function labelled(array $input,callable $callback) { $old=self::$label;self::$label=$input['label']??$old;try{return $callback();}finally{self::$label=$old;} }
    public static function reference(string $id,string $plan): void {
        Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static function()use($id,$plan){$meta=self::metadata($id,false);if(is_wp_error($meta))return;$meta['protected_by_operations']=array_values(array_unique(array_merge($meta['protected_by_operations']??[],[$plan])));StateStore::put('backup-index',$id,$meta);});
    }
    public static function protect_child(string $id,string $parent): void {
        $result=Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static function()use($id,$parent){
            $meta=self::metadata($id,false);if(is_wp_error($meta))throw new \RuntimeException('backup_reference_failed');
            $refs=StateStore::get('backup-references',$id)??['parents'=>[]];$refs['parents']=array_values(array_unique(array_merge($refs['parents'],[$parent])));
            StateStore::put('backup-references',$id,$refs);$meta['protected_by_backups']=$refs['parents'];StateStore::put('backup-index',$id,$meta);return Result::ok();
        });if(empty($result['success']))throw new \RuntimeException('backup_reference_failed');
    }
    /** Enrich an old index from its signed journal; never rewrite the original preimage. */
    public static function package_metadata(array $payload): array {
        if(($payload['ability']??'')!=='recovery'||!preg_match('/^[a-f0-9]{32}$/D',(string)($payload['snapshot']['journal_id']??'')))return [];
        $s=\Fator3\RecoveryV1\Engine::read(Recovery::directory().'/'.$payload['snapshot']['journal_id'].'.journal.php');
        if(!$s||empty($s['plugin'])||!array_key_exists('expected_version',$s)||($s['backup_id']??'')!==($payload['id']??'')||($s['target']??null)!==($payload['snapshot']['target']??null))return [];
        if(!Persistence::get('package-history',$s['id']))Persistence::put('package-history',$s['id'],['time'=>$s['time'],'started_at'=>$s['started_at']??$s['time'],'status'=>$s['status'],'target'=>$s['plugin'],'package_operation_id'=>$s['id'],'backup_id'=>$s['backup_id']],true);
        return ['type'=>'package_preimage','plugin'=>$s['plugin'],'version_before'=>$s['old_version']??null,'version_after'=>$s['expected_version'],'package_operation_id'=>$s['id'],'zip_sha256'=>$s['zip_sha256']??$s['verification_evidence']['zip_sha256']??null,'metadata_source'=>'signed_recovery_journal'];
    }
    public static function retired(string $id): bool {
        $path=StateStore::path('backup-retired',$id);
        return is_file($path)||(Persistence::get('backup-index',$id)['status']??null)==='deleted';
    }
    public static function retire(string $id): void {
        StateStore::write(StateStore::path('backup-retired',$id),StateStore::HEADER.wp_json_encode(['id'=>$id,'site_id'=>get_current_blog_id(),'retired_at'=>time()]));
        StateStore::delete('backup-index',$id);
    }
    public static function create_snapshot(string $ability,array $snapshot,array $metadata=[]) {
        $id=bin2hex(random_bytes(12));
        try { self::persist($id,$metadata+['id'=>$id,'kind'=>'snapshot','ability'=>$ability,'snapshot'=>$snapshot,'time'=>gmdate('c'),'user'=>get_current_user_id(),'backup_contains_sensitive_values'=>'unknown']); }
        catch(\Throwable $e){return new \WP_Error('backup_write_failed','Não foi possível preservar a pré-imagem.');}return $id;
    }

	public static function metadata(string $id, bool $with_content = true) {
		if (!preg_match('/^(?:db)?[a-f0-9]{16,64}$/iD', $id)) return new \WP_Error('invalid_backup_id', 'O identificador da cópia de segurança é inválido.');
        if($with_content){$file=StateStore::path('backups',$id);if(is_file($file)){$limit=wp_convert_hr_to_bytes(ini_get('memory_limit'));if($limit>0&&filesize($file)*3+memory_get_usage(true)>$limit)return new \WP_Error('backup_memory_limit','Use leitura de metadados ou exportação em partes.');}}
		if(self::retired($id))return new \WP_Error('backup_not_found','Backup removido.');
		$stored = StateStore::get($with_content ? 'backups' : 'backup-index', $id);
		if (!$stored && !$with_content) { $file=StateStore::path('backups',$id);if(is_file($file))try{$stored=BackupStream::read($file);}catch(\Throwable $e){return new \WP_Error('backup_corrupt','Envelope inválido.');} }
        if (!$stored) return new \WP_Error('backup_not_found', 'A cópia de segurança não foi encontrada.');
        if (!empty($stored['legacy'])) return new \WP_Error('backup_format_unsupported', 'Formato anterior à base aceita; arquivos preservados.');
		if (($stored['id'] ?? '') !== $id) return new \WP_Error('backup_corrupt', 'A identidade da cópia de segurança diverge da solicitada.');
		return $stored;
	}
	private static function persist(string $id, array $payload): void {
		$payload['label']=self::$label??(isset($payload['plugin'])?$payload['plugin'].' '.($payload['version_before']??'absent').' → '.($payload['version_after']??'unknown'):null); $payload['connection_id']=ConnectionContext::key();
		$result = Locks::run(['backups:' . get_current_blog_id() => LOCK_EX], static function () use($id, $payload) {
			StateStore::put('backups', $id, $payload);
			unset($payload['rows'], $payload['sql'], $payload['content_base64'], $payload['snapshot']);
			$payload['stored_bytes'] = filesize(StateStore::path('backups', $id)); $payload['target']=$payload['plugin']??$payload['path']??$payload['table']??'';
			StateStore::put('backup-index', $id, $payload);
			return Result::ok();
		});
		if (!$result['success']) throw new \RuntimeException($result['message']);
	}
	public static function create_file(string $path) {
		$size = filesize($path);
		$max = (int)apply_filters('f3_mcp_backup_max_bytes', 64 * 1024 * 1024);
		if (false === $size || $size > $max) return new \WP_Error('backup_size_limit', 'O arquivo excede o limite configurado para cópias de segurança. A operação foi interrompida antes da alteração.');
        $id=bin2hex(random_bytes(12));
        try {
            $result=Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static function()use($id,$path){
                $dest=StateStore::path('backups',$id);
                $meta=BackupStream::create($path,['id'=>$id,'kind'=>'file','path'=>PathGuard::to_relative($path),'time'=>gmdate('c'),'user'=>get_current_user_id(),'label'=>self::$label,'connection_id'=>ConnectionContext::key()],$dest);
                $meta['stored_bytes']=filesize($dest);$meta['target']=$meta['path'];StateStore::put('backup-index',$id,$meta);return Result::ok();
            });if(empty($result['success']))return new \WP_Error('backup_write_failed','Backup não confirmado.');
        }catch(\Throwable $e){return new \WP_Error('backup_write_failed',$e->getMessage());}
		return $id;
	}
	public static function create_rows(string $table, string $sql, array $rows) {
		$id = 'db' . bin2hex(random_bytes(11));
		try {
			self::persist($id, ['id' => $id, 'kind' => 'database', 'table' => $table, 'sql' => $sql, 'rows' => DatabaseWriter::transport_rows($rows), 'binary_encoding' => 'Cells with encoding=base64 contain original binary bytes', 'time' => gmdate('c'), 'user' => get_current_user_id(), 'count' => count($rows)]);
		} catch (\Throwable $e) { return new \WP_Error('backup_write_failed', $e->getMessage()); }
		return $id;
	}
	public static function restore(array $input): array {
        $meta=self::metadata((string)($input['backup_id']??''),false);if(is_wp_error($meta))return Result::error($meta);
        if(($meta['kind']??'')!=='file')return Result::fail('backup_type_mismatch','files/restore exige backup de arquivo.');
        $path=PathGuard::resolve((string)$meta['path'],true);if(is_wp_error($path))return Result::error($path);
        $valid=PathGuard::check_extension($path);if(is_wp_error($valid))return Result::error($valid);
        $temp=StateStore::directory('backups').'/restore-'.bin2hex(random_bytes(16)).'.php';$sink=null;
        try {
            $free=@disk_free_space(dirname($temp));if($free!==false&&$free<(int)$meta['bytes']+2097152)throw new \RuntimeException('backup_disk_space');
            $sink=fopen($temp,'xb');if(!$sink)throw new \RuntimeException('restore_stage_failed');chmod($temp,0600);
            $decoded=BackupStream::read(StateStore::path('backups',$meta['id']),$sink);if(($decoded['id']??'')!==$meta['id']||($decoded['path']??'')!==$meta['path'])throw new \RuntimeException('backup_identity_mismatch');
            if(!fflush($sink))throw new \RuntimeException('restore_stage_failed');fclose($sink);$sink=null;
            if(filesize($temp)!==(int)$meta['bytes']||!hash_equals($meta['sha256'],(string)hash_file('sha256',$temp)))throw new \RuntimeException('backup_corrupt');
            // PHP writes retain the existing recovery/probe boundary and bounded syntax check.
            $php=strtolower(pathinfo($path,PATHINFO_EXTENSION))==='php';$content=null;
            if($php){$budget=wp_convert_hr_to_bytes(ini_get('memory_limit'));if((int)$meta['bytes']>2097152||$budget>0&&memory_get_usage(true)+(int)$meta['bytes']*6>$budget)return Result::fail('restore_php_memory_limit','PHP excede validação limitada; nada foi escrito.');$content=file_get_contents($temp);$check=PathGuard::check_php_syntax($content);if(is_wp_error($check))return Result::error($check);}
            $before=is_file($path)?self::create_file($path):'';if(is_wp_error($before))return Result::error($before);
            $result=$php?Files::atomic_write($path,$content):Files::atomic_copy($path,$temp,$meta['sha256']);if(is_wp_error($result))return Result::error($result);
            if(!hash_equals($meta['sha256'],(string)hash_file('sha256',$path)))return Result::fail('restore_readback_failed','Arquivo final divergiu.',['backup_id'=>$before,'applied'=>null]);
            PathGuard::audit('restore',PathGuard::to_relative($path),['backup_id'=>$meta['id']]);return Result::ok(['path'=>PathGuard::to_relative($path),'bytes'=>(int)$meta['bytes'],'backup_id'=>$before,'sha256'=>$meta['sha256'],'persisted'=>true],'Arquivo restaurado.');
        }catch(\Throwable $e){return Result::fail('backup_restore_failed',$e->getMessage());}
        finally{if(is_resource($sink))fclose($sink);if(is_file($temp))unlink($temp);}
    }

	public static function listing(array $input): array {
        if(($input['category']??'backups')!=='backups')return SqlArtifacts::listing($input);
        $inventory=Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static fn()=>BackupInventory::advance());
        if(!isset($inventory['complete']))return $inventory;
        $filters=[];
        if(isset($input['label']))$filters['label']=$input['label'];
        if(isset($input['plugin']))$filters['plugin']=$input['plugin'];
        if(isset($input['type']))$filters[$input['type']==='package_preimage'?'type':'kind']=$input['type'];
        if(!empty($input['path'])) { $wanted=PathGuard::lock_path($input['path']);if(is_wp_error($wanted))return Result::error($wanted);$filters['target']=PathGuard::to_relative($wanted); }
        foreach(['since','until'] as $key)if(isset($input[$key])) { $t=strtotime($input[$key]);if(false===$t)return Result::fail('invalid_date','Use data ISO 8601.');$filters[$key]=$t; }
        $limit=max(1,min(200,(int)($input['per_page']??30)));$offset=max(0,(int)($input['offset']??0));
        $rows=Persistence::listing('backup-index',$filters,$limit+1,PHP_INT_MAX,$offset);$more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);
        foreach($rows as &$row)unset($row['_row_id']);unset($row);
        return Result::ok(['backups'=>$rows,'has_more'=>$more,'next_offset'=>$more?$offset+count($rows):null,'history_complete'=>$inventory['complete'],'inventory'=>$inventory]);
    }

	public static function export(array $input): array {
        return Locks::run(['backups:'.get_current_blog_id()=>LOCK_SH],static function()use($input){
            $source=BackupExport::source($input['backup_id']);if(is_wp_error($source))return Result::error($source);
            $size=filesize($source['path'])-$source['skip'];
            if(4*(int)ceil($size/3)>PathGuard::max_bytes())return Result::fail('export_size_limit','Use backups/export-part para este backup.');
            $bytes=file_get_contents($source['path'],false,null,$source['skip']);if($bytes===false||strlen($bytes)!==$size)return Result::fail('backup_export_failed','Leitura incompleta.');
            return Result::ok(['filename'=>$input['backup_id'].'.json','content_base64'=>base64_encode($bytes),'sha256'=>hash('sha256',$bytes),'backup_contains_sensitive_values'=>$source['meta']['backup_contains_sensitive_values']??'unknown'],'Exportação com valores originais; base64 não é criptografia.');
        });
    }
    public static function prune(array $input): array {if(($input['category']??'backups')!=='backups'){if(isset($input['policy'])||isset($input['plugin'])||isset($input['type']))return Result::fail('artifact_filter_unsupported','Filtros de pacote atendem somente category:backups.');if(isset($input['exclude_ids']))return Result::fail('artifact_filter_unsupported','exclude_ids atende somente category:backups.');foreach($input['artifact_ids']??[] as $id)if(!preg_match('/^[a-f0-9]{32}$/D',$id))return Result::fail('invalid_artifact_id','Artefato SQL exige ID de 32 caracteres.');}return ($input['category']??'backups')==='backups'?Retention::prune($input):SqlArtifacts::prune($input);}
}
