<?php
/** Administrative views expose summaries, never private plan parameters or SQL previews. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class OperationsAdmin {
    public static function init(): void {
        add_action('admin_init',static function():void {if(($_GET['page']??'')==='wp-mcp-fator3'&&isset($_GET['mutation_operation']))nocache_headers();});
        add_action('admin_post_f3_mcp_admin_cancel',[self::class,'cancel']);
        add_action('admin_post_f3_mcp_export_activity',[self::class,'export_activity']);
        add_action('admin_post_f3_mcp_maintenance',[self::class,'maintain']);
    }
    private static function guard(string $nonce): void {
        if(!current_user_can('manage_options'))wp_die('Permissão insuficiente.','',['response'=>403]);
        check_admin_referer($nonce);
    }
    public static function cancel(): void {
        self::guard('f3_mcp_admin_cancel');$id=is_string($_POST['plan_id']??null)?wp_unslash($_POST['plan_id']):'';
        $plan=preg_match('/^[a-f0-9]{32}$/D',$id)?StateStore::get('plans',$id):null;
        if(!$plan){self::notice(Result::fail('plan_not_found','Plano não encontrado.'),'operations');return;}
        $terminal=in_array($plan['status'],['complete','cancelled','compensated','compensation_incomplete'],true);
        $changed=!$terminal&&Persistence::put('plan-cancel',$id,['plan_id'=>$id,'connection_id'=>$plan['connection_id'],'requested_by_admin'=>get_current_user_id(),'status'=>'cancel_requested','time'=>time()],true);
        $r=Result::ok(['changed'=>$changed,'plan_id'=>$id],'Pedido registrado. A etapa em andamento pode terminar; efeitos anteriores não foram revertidos.');
        Audit::record('admin/operations/cancel',['id'=>$id],$r,0);self::notice($r,'operations');
    }
    private static function notice(array $result,string $tab): void {
        $key=wp_generate_uuid4();set_transient('f3_mcp_notice_'.get_current_user_id().'_'.$key,['success'=>!empty($result['success']),'message'=>$result['message']??'Ação concluída.'],60);
        wp_safe_redirect(add_query_arg('notice',$key,Admin::url($tab)));exit;
    }
    private static function details(string $title,$data): void {
        echo '<details><summary>'.esc_html($title).'</summary><pre class="code">'.esc_html(wp_json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'</pre></details>';
    }
    public static function operations(): void {
        if(!current_user_can('manage_options'))return;
        $before=max(1,(int)($_GET['before_id']??PHP_INT_MAX));$filter=[];
        if(is_string($_GET['status']??null)&&$_GET['status']!=='')$filter['status']=array_key_exists($_GET['status'],Admin::states())?$_GET['status']:'__invalid__';
        $rows=Persistence::listing('plans',$filter,31,$before);$more=count($rows)>30;$rows=array_slice($rows,0,30);
        echo '<div class="f3-page-intro"><h2>Atividade</h2><p>Acompanhe os planos de execução e o resultado de cada etapa.</p><a href="'.esc_url(Admin::url('history')).'">Voltar ao registro de atividade</a></div><section class="f3-card"><h3>Planos</h3><p>Planos de todas as conexões deste site. Cancelar impede os próximos passos; uma etapa em andamento pode concluir. A prévia completa deve ser feita pelo conector que possui o plano.</p>';
        self::filters('operations',['Filtrar planos'=>['status'=>'Estado']]);
        foreach($rows as $row){
            $cancel=StateStore::get('plan-cancel',$row['plan_id']);$done=count(array_filter($row['steps'],static fn($s)=>$s['status']==='complete'));
            echo '<article><h3><code>'.esc_html($row['plan_id']).'</code></h3><p>'.esc_html(Admin::state($row['status']).($cancel?' · cancelamento solicitado':'').' · '.$done.'/'.count($row['steps']).' etapas · '.$row['connection_id']).'</p><div class="f3-table-scroll" tabindex="0" role="region" aria-label="Registros operacionais"><table class="widefat striped"><thead><tr><th>Etapa</th><th>Habilidade</th><th>Estado</th><th>Resultado observado</th></tr></thead><tbody>';
            foreach($row['steps'] as $step){
                $summary=array_intersect_key($step['result']??[],array_flip(['success','changed','persisted','applied','error_code','operation_id','backup_id','recovery_status']));
                echo '<tr><td>'.esc_html($step['id']).'</td><td>'.esc_html(Admin::ability_label($step['ability']).' — '.$step['ability']).'</td><td>'.esc_html(Admin::state($step['status'])).'</td><td>';self::details('Resultado', $summary);if(isset($step['preconditions']))self::details('Pré-condições da prévia',$step['preconditions']);echo '</td></tr>';
            }
            echo '</tbody></table></div>';
            if(!in_array($row['status'],['complete','cancelled','compensated','compensation_incomplete'],true)){
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';Admin::nonce('f3_mcp_admin_cancel');echo '<input type="hidden" name="action" value="f3_mcp_admin_cancel"><input type="hidden" name="plan_id" value="'.esc_attr($row['plan_id']).'"><p><button class="button">Solicitar cancelamento</button></p></form>';
            }
            echo '</article>';
        }
        if(!$rows)echo '<p>Nenhum plano encontrado.</p>';
        if($more)echo '<p><a class="button" href="'.esc_url(add_query_arg(['before_id'=>end($rows)['_row_id']]+$filter,Admin::url('operations'))).'">Próximos planos</a></p>';echo '</section>';
    }
    private static function filters(string $tab,array $groups,array $abilities=[]): void {
        echo '<form method="get" aria-label="Filtros"><input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="tab" value="'.esc_attr($tab).'">';
        foreach($groups as $legend=>$fields){
            echo '<fieldset><legend><strong>'.esc_html($legend).'</strong></legend><div class="f3-filters">';
            foreach($fields as $key=>$label){
                $value=is_string($_GET[$key]??null)?wp_unslash($_GET[$key]):'';
                $id='f3-filter-'.$key;
                echo '<p><label for="'.esc_attr($id).'">'.esc_html($label).'</label><br>';
                if($key==='ability'){
                    echo '<input type="search" id="'.esc_attr($id).'" name="ability" value="'.esc_attr($value).'" list="f3-history-abilities" aria-describedby="f3-filter-ability-help">';
                    echo '<datalist id="f3-history-abilities">';
                    foreach($abilities as $name=>$title)echo '<option value="'.esc_attr((string)$name).'">'.esc_html($title).'</option>';
                    echo '</datalist><small id="f3-filter-ability-help">Digite o identificador exato, inclusive de habilidades removidas. As sugestões vêm dos registros desta página.</small>';
                }elseif(in_array($key,['status','success'],true)){
                    $options=$key==='status'?Admin::states():['1'=>'Concluído','0'=>'Falhou'];
                    echo '<select id="'.esc_attr($id).'" name="'.esc_attr($key).'"><option value="">Todos</option>';
                    foreach($options as $v=>$title)echo '<option value="'.esc_attr((string)$v).'" '.selected($value,(string)$v,false).'>'.esc_html($title).'</option>';
                    echo '</select>';
                }elseif(in_array($key,['since','until'],true)){
                    $date=self::utc_date($value);
                    echo '<input type="datetime-local" step="1" id="'.esc_attr($id).'" name="'.esc_attr($key).'" value="'.esc_attr($date?$date->format('Y-m-d\TH:i:s'):'').'">';
                }else{
                    echo '<input type="text" id="'.esc_attr($id).'" name="'.esc_attr($key).'" value="'.esc_attr($value).'">';
                }
                echo '</p>';
            }
            echo '</div></fieldset>';
        }
        echo '<p><button class="button">Filtrar</button> <a href="'.esc_url(Admin::url($tab)).'">Limpar filtros</a></p></form>';
    }

    private static function utc_date(string $raw): ?\DateTimeImmutable {
        // Links generated before 0.41 sometimes decoded the plus of an ISO offset as a space.
        $raw=preg_replace('/ (\d\d:\d\d)$/D','+$1',$raw);
        if(!preg_match('/^\d{4}-\d\d-\d\dT\d\d:\d\d(?::\d\d)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)?$/D',$raw))return null;
        $utc=new \DateTimeZone('UTC');
        try{$date=new \DateTimeImmutable($raw,$utc);}catch(\Exception $e){return null;}
        $errors=\DateTimeImmutable::getLastErrors();
        return $errors&&($errors['warning_count']||$errors['error_count'])?null:$date->setTimezone($utc);
    }

    public static function history_input(array $query) {
        $input=['per_page'=>30];
        foreach(['connection_id','ability','target','operation_id','cursor','ability_or_target'] as $key){
            if(!array_key_exists($key,$query)||$query[$key]==='')continue;
            if(!is_string($query[$key]))return new \WP_Error('invalid_filter','Informe um único valor por filtro.');
            $input[$key]=$query[$key];
        }
        if(isset($query['success'])&&$query['success']!==''){
            if(!in_array($query['success'],['0','1'],true))return new \WP_Error('invalid_filter','Selecione um resultado válido.');
            $input['success']=$query['success']==='1';
        }
        foreach(['since','until'] as $key){
            if(!isset($query[$key])||$query[$key]==='')continue;
            $date=is_string($query[$key])?self::utc_date($query[$key]):null;
            if(!$date)return new \WP_Error('invalid_date','Escolha uma data e hora válidas.');
            $input[$key]=$date->format('c');
        }
        $period=$query['period']??'';
        if (!in_array($period,['','day','week','month'],true)) return new \WP_Error('invalid_period','Selecione um período válido.');
        if ($period!=='' && empty($input['since']) && empty($input['until'])) {
            $days=['day'=>1,'week'=>7,'month'=>30][$period];
            $input['since']=gmdate('c',time()-$days*DAY_IN_SECONDS);
        }
        if(isset($input['since'],$input['until'])&&strcmp($input['since'],$input['until'])>0)return new \WP_Error('invalid_date_range','A data inicial deve ser anterior ou igual à final.');
        return $input;
    }

    private static function history_url(array $params): string {
        foreach($params as $key=>$value)$params[$key]=rawurlencode((string)$value);
        return add_query_arg($params,Admin::url('history'));
    }
    public static function event_label(string $id): string {
        $internal=['admin/settings'=>'Painel · Ajustes de acesso','admin/file-limit'=>'Painel · Limite por arquivo','admin/connection'=>'Painel · Perfil de cliente','admin/sql-retention'=>'Painel · Retenção SQL','admin/maintenance'=>'Painel · Manutenção do acervo','admin/operations/cancel'=>'Painel · Cancelamento de plano','mcp/access-denied'=>'Transporte · Acesso recusado'];
        if (isset($internal[$id])) return $internal[$id];
        if (str_starts_with($id,'admin/')) return 'Ação do painel';
        return wp_has_ability($id)?Admin::ability_label($id):'Habilidade removida do catálogo';
    }
    public static function client_name(array $row): string {
        if (trim((string)($row['label']??''))!=='') return $row['label'];
        if (str_starts_with($row['connection_id']??'','grant:')) return ConnectionContext::oauth_label($row);
        if (!empty($row['client_id'])) return $row['client_id'];
        return $row['connection_id']??'Cliente sem identificação';
    }
    public static function event_client(array $event): array {
        if (str_starts_with($event['ability'],'admin/')) return ['Painel do WordPress',''];
        if (($event['principal_type']??'')==='service') return [$event['consumer_id']??'Serviço',$event['principal_ref']??''];
        $id=$event['connection_id']??'';
        static $clients=[];
        $key=get_current_blog_id().':'.$id;
        if (!isset($clients[$key])) {
            $row=$id!==''?ConnectionContext::policy($id):null;
            $clients[$key]=$row?[self::client_name($row),Admin::profile($row['profile']??'')]:[$id?:'Sem identificação',''];
        }
        return $clients[$key];
    }
    private static function activity_filters(array $q): void {
        $value=static fn($key)=>is_string($q[$key]??null)?$q[$key]:'';
        $select=static function($key,$label,$options) use ($value) {
            echo '<label>'.esc_html($label).'<select name="'.esc_attr($key).'">';
            foreach ($options as $v=>$name) echo '<option value="'.esc_attr((string)$v).'" '.selected($value($key),(string)$v,false).'>'.esc_html($name).'</option>';
            echo '</select></label>';
        };
        $clients=[''=>'Todos'];
        $before=PHP_INT_MAX;
        do {
            $rows=Persistence::listing('connections',[],100,$before);
            foreach ($rows as $row) $clients[$row['connection_id']]=self::client_name($row);
            if ($rows) $before=end($rows)['_row_id'];
        } while (count($rows)===100);
        $id=$value('connection_id');
        if ($id!=='' && !isset($clients[$id])) $clients[$id]=$id;
        echo '<form method="get" class="f3-activity-filter"><input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="tab" value="history"><div class="f3-filterbar">';
        $select('connection_id','Cliente',$clients);
        $select('success','Resultado',[''=>'Todos','1'=>'Concluído','0'=>'Falhou']);
        $select('period','Período',[''=>'Todo o histórico','day'=>'Últimas 24 horas','week'=>'Últimos 7 dias','month'=>'Últimos 30 dias']);
        echo '<label>Habilidade ou alvo<input type="search" name="ability_or_target" placeholder="content/update-page" value="'.esc_attr($value('ability_or_target')).'"></label><button class="button button-primary">Filtrar</button></div>';
        $advanced=['ability'=>'Habilidade exata','target'=>'Alvo ou caminho exato','operation_id'=>'ID da operação','since'=>'A partir de (UTC)','until'=>'Antes de (UTC)'];
        $open=false;
        foreach (array_keys($advanced) as $key) if ($value($key)!=='') $open=true;
        echo '<details '.($open?'open':'').'><summary>Mais filtros</summary><p>O intervalo exato em UTC tem prioridade sobre o período selecionado.</p><div class="f3-filters">';
        foreach ($advanced as $key=>$label) {
            $date=in_array($key,['since','until'],true);
            $v=$value($key);
            if ($date && $v!=='') $v=self::utc_date($v)?->format('Y-m-d\TH:i:s')??'';
            echo '<label>'.esc_html($label).'<input name="'.esc_attr($key).'" type="'.($date?'datetime-local':'text').'" '.($date?'step="1"':'').' value="'.esc_attr($v).'"></label>';
        }
        echo '</div><a href="'.esc_url(Admin::url('history')).'">Limpar filtros</a></details></form>';
    }
    public static function history(): void {
        if (!current_user_can('manage_options')) return;
        echo '<div class="f3-page-intro"><h2>Atividade</h2><p>Consulte chamadas de clientes e ações do painel por data, cliente, habilidade e resultado.</p></div><section class="f3-card">';
        self::mutation_detail();
        $q=wp_unslash($_GET);
        $input=self::history_input($q);
        $r=is_wp_error($input)?Result::error($input):Audit::listing($input);
        self::activity_filters($q);
        if (empty($r['success'])) echo '<p role="alert">'.esc_html($r['message']).'</p>';
        elseif (!$r['entries']) echo '<p role="status">Nenhum registro encontrado. Revise os filtros ou consulte outro período.</p>';
        else {
            echo '<div class="f3-table-scroll" tabindex="0" role="region" aria-label="Registro de atividade"><table class="widefat striped f3-activity"><thead><tr><th scope="col">Quando</th><th scope="col">Cliente</th><th scope="col">Ação</th><th scope="col">Alvo</th><th scope="col">Resultado</th></tr></thead><tbody>';
            foreach ($r['entries'] as $event) {
                [$name,$profile]=self::event_client($event);
                $ok=!empty($event['success']);
                echo '<tr><td data-label="Quando">'.Admin::time_html($event['time']).'</td><td data-label="Cliente">'.esc_html($name).'<small>'.esc_html($profile).'</small></td><td data-label="Ação">'.esc_html(self::event_label($event['ability'])).'<small><code>'.esc_html($event['ability']).'</code></small></td><td data-label="Alvo">'.esc_html($event['target']??'').'</td><td data-label="Resultado">';
                if (in_array($event['kind']??'', ['mutation_reference','service_mutation_reference'],true)) {
                    echo '<strong>'.esc_html($event['state']??'Estado desconhecido').'</strong>';
                    $link=['mutation_provider'=>$event['provider'],'mutation_operation'=>$event['operation_id']];
                    if ($event['kind']==='service_mutation_reference') $link+=['mutation_principal'=>$event['principal_ref'],'mutation_grant'=>$event['grant_revision'],'mutation_consumer'=>$event['consumer_id']];
                    echo '<small><a href="'.esc_url(self::history_url($link)).'">Consultar recibo</a></small>';
                } else {
                    echo '<span class="f3-badge '.($ok?'is-ok':'f3-failed').'">'.($ok?'Concluído':'Falhou').'</span>';
                    if (!empty($event['error_code'])) echo '<small>'.esc_html($event['error_code']).'</small>';
                }
                if (!empty($event['operation_id'])) echo '<small><code>'.esc_html($event['operation_id']).'</code></small>';
                echo '</td></tr>';
            }
            echo '</tbody></table></div>';
            if ($r['has_more']) {
                unset($input['per_page']);
                if (isset($input['success'])) $input['success']=$input['success']?'1':'0';
                $input['cursor']=$r['next_cursor'];
                echo '<p><a class="button" href="'.esc_url(self::history_url($input)).'">Próximos registros</a></p>';
            }
        }
        if (!empty($r['success'])&&!$r['history_complete']) echo '<p role="status">Falha ao gravar um evento nesta requisição. O histórico pode estar incompleto.</p>';
        echo '<p><a href="'.esc_url(Admin::url('operations')).'">Planos em andamento</a>';
        if (!is_wp_error($input) && !empty($r['success'])) {
            unset($input['cursor'],$input['per_page']);
            if (isset($input['success'])) $input['success']=$input['success']?'1':'0';
            $params=array_map(static fn($v)=>rawurlencode((string)$v),$input);
            $url=add_query_arg(['action'=>'f3_mcp_export_activity','_wpnonce'=>wp_create_nonce('f3_mcp_export_activity')]+$params,admin_url('admin-post.php'));
            echo ' · <a href="'.esc_url($url).'">Exportar esta consulta</a>';
        }
        echo '</p></section>';
    }
    public static function export_activity(): void {
        self::guard('f3_mcp_export_activity');
        $input=self::history_input(wp_unslash($_GET));
        if (is_wp_error($input)) wp_die(esc_html($input->get_error_message()),'',['response'=>400]);
        unset($input['cursor']);
        $input['per_page']=200;
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="fator3-mcp-atividade.json"');
        echo '{"entries":[';
        $separator='';
        try {
            do {
                $result=Audit::listing($input);
                if (empty($result['success'])) break;
                foreach ($result['entries'] as $row) {
                    echo $separator.wp_json_encode($row,JSON_INVALID_UTF8_SUBSTITUTE|JSON_UNESCAPED_UNICODE);
                    $separator=',';
                }
                $input['cursor']=$result['next_cursor'];
            } while ($result['has_more']);
            $complete=!empty($result['success']) && !empty($result['history_complete']);
        } catch (\Throwable $error) { $complete=false; }
        echo '],"complete":'.($complete?'true':'false').'}';
        exit;
    }
    public static function maintenance_form(): void {
        $key=is_string($_GET['simulation']??null)?wp_unslash($_GET['simulation']):'';
        $preview=preg_match('/^[a-f0-9-]{36}$/D',$key)?get_transient('f3_mcp_sim_'.get_current_user_id().'_'.$key):false;
        echo '<details id="f3-maintenance" '.($key!==''?'open':'').'><summary>Limpar o histórico interno</summary><p>Simule um lote e confira a seleção antes de aplicar a limpeza.</p>';
        if ($key!=='' && !$preview) echo '<p>A prévia expirou. Simule um novo lote.</p>';
        if ($preview) {
            self::details('Seleção desta simulação',$preview['result']);
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
            Admin::nonce('f3_mcp_maintenance');
            foreach (['action'=>'f3_mcp_maintenance','apply'=>'1','category'=>$preview['category'],'older_than_days'=>$preview['age'],'expected_selection_sha256'=>$preview['result']['selection_sha256']] as $name=>$v) echo '<input type="hidden" name="'.esc_attr($name).'" value="'.esc_attr((string)$v).'">';
            echo '<button class="button">Aplicar esta seleção</button> <a href="'.esc_url(Admin::url('files')).'">Voltar sem aplicar</a></form>';
        }
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        Admin::nonce('f3_mcp_maintenance');
        echo '<input type="hidden" name="action" value="f3_mcp_maintenance"><label>Categoria <select name="category">';
        foreach (['audit'=>'Auditoria','oauth-clients'=>'Clientes sem autorização expirados','oauth-codes'=>'Códigos OAuth expirados','oauth-tokens'=>'Tokens OAuth expirados','sessions'=>'Sessões expiradas','transfers'=>'Partes de uploads expirados','idempotency'=>'Resultados de idempotência'] as $v=>$label) echo '<option value="'.esc_attr($v).'">'.esc_html($label).'</option>';
        echo '</select></label> <label>Idade mínima em dias <input required type="number" min="1" max="3650" name="older_than_days" value="90"></label><p><button class="button">Simular lote</button></p></form></details>';
    }
    private static function mutation_detail(): void {
        if (!isset($_GET['mutation_provider'],$_GET['mutation_operation'])) return;
        $identity=['provider'=>wp_unslash($_GET['mutation_provider']),'operation_id'=>wp_unslash($_GET['mutation_operation'])];
        $service=isset($_GET['mutation_principal']);
        $result=$service?MutationServiceAudit::read_panel($identity+['principal_ref'=>wp_unslash($_GET['mutation_principal']),'grant_revision'=>wp_unslash($_GET['mutation_grant']??''),'consumer_id'=>wp_unslash($_GET['mutation_consumer']??'')]):MutationAudit::read_panel($identity);
        echo '<article aria-label="Detalhes da operação"><h3>Antes e depois</h3>';
        if(empty($result['success']))echo '<p role="status">'.esc_html($result['message']).'</p>';
        else {
            echo '<p>'.($service?'Principal: serviço. ':'').'Estado: '.esc_html($result['state']).'. Dados consultados no diário do provedor; campos sensíveis são ocultados.</p>';
            self::details('Antes',$result['before']);self::details('Depois',$result['after']);
        }
        echo '</article>';
    }
    public static function maintain(): void {
        self::guard('f3_mcp_maintenance');$category=is_string($_POST['category']??null)?sanitize_key(wp_unslash($_POST['category'])):'';
        $days=$_POST['older_than_days']??'90';
        if (!is_string($days) || !ctype_digit($days) || (int)$days<1 || (int)$days>3650) self::notice(Result::fail('invalid_age','Informe uma idade de 1 a 3.650 dias.'),'files');
        $input=['category'=>$category,'older_than_days'=>(int)$days,'dry_run'=>($_POST['apply']??'')!=='1'];
        if(is_string($_POST['expected_selection_sha256']??null))$input['expected_selection_sha256']=wp_unslash($_POST['expected_selection_sha256']);
        $r=StateMaintenance::run($input);Audit::record('admin/maintenance',['name'=>$category],$r,0);
        if (empty($r['success']) || !$input['dry_run']) self::notice($r,'files');
        $key=wp_generate_uuid4();
        $saved=set_transient('f3_mcp_sim_'.get_current_user_id().'_'.$key,['result'=>$r,'category'=>$category,'age'=>$input['older_than_days']],600);
        if (!$saved) self::notice(Result::fail('preview_unavailable','Não foi possível guardar a prévia. Simule novamente.'),'files');
        wp_safe_redirect(add_query_arg('simulation',$key,Admin::url('files')).'#f3-maintenance');
        exit;
    }
}
