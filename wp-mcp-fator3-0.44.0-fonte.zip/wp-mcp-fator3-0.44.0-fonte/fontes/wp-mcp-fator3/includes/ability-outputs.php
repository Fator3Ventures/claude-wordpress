<?php
/** Chaves de saída dos callbacks registrados por Registry. Campos dependem da operação e do resultado. */
declare(strict_types=1);
namespace Fator3\McpFiles;

defined('ABSPATH') || exit;

$string = ['type' => 'string'];
$integer = ['type' => 'integer'];
$boolean = ['type' => 'boolean'];
$null = ['type' => 'null'];
$object = ['type' => 'object'];
$nullableString = ['type' => ['string', 'null']];
$nullableInteger = ['type' => ['integer', 'null']];
$nullableObject = ['type' => ['object', 'null']];
$booleanOrString = ['type' => ['boolean', 'string']];
$value = Result::any_schema();
$objects = ['type' => 'array', 'items' => $object];
$strings = ['type' => 'array', 'items' => $string];
$integers = ['type' => 'array', 'items' => $integer];
// Mapas PHP sem entradas são serializados como listas vazias.
$map = ['type' => ['object', 'array'], 'items' => $value];

$postMeta = [
    'id' => $integer, 'key' => $string, 'values' => $objects, 'registered' => $boolean,
];
$seo = [
    'id' => $integer, 'provider' => $string, 'provider_version' => $string, 'values' => $map,
    'value_scope' => $string, 'rendered_html_verified' => $boolean,
];
$phase = [
    'preview' => $boolean, 'confirm_token' => $string, 'expires_at' => $string, 'summary' => $object,
];
$destructive = $phase + [
    'ability' => $string, 'target' => $map, 'recovery' => $string, 'backup_id' => $nullableString,
    'deletion_metadata_backup_id' => $string,
];
$maintenance = [
    'dry_run' => $boolean, 'selected' => $integer, 'selected_bytes' => $integer, 'selection_sha256' => $string,
    'has_more' => $boolean, 'next_before_id' => $nullableInteger, 'items' => $objects, 'completed' => $integer,
];
$exportJob = [
    'status' => $string, 'sql_sha256' => $string, 'format' => $string, 'gzip' => $boolean, 'time' => $integer,
    'expires' => $integer, 'timeout_seconds' => $integer, 'artifact_id' => $string, 'row_count' => $integer,
    'bytes' => $integer, 'sha256' => $string, 'duration_ms' => $integer, 'lease_until' => $integer,
    'checkpoint_rows' => $integer, 'heartbeat_at' => $integer, 'retry_requires_new_operation' => $boolean,
    'consistency' => $string,
];
$tree = [
    'backup_id' => $nullableString, 'journal_id' => $string, 'tree_sha256' => $string, 'path' => $string,
    'probe_tested' => $boolean, 'probe_after' => $nullableObject, 'recovery' => $object,
];
$transfer = [
    'source' => $string, 'path' => $string, 'bytes' => $integer, 'sha256' => $string,
    'backup_id' => $nullableString, 'source_backup_id' => $nullableString,
];
$option = [
    'name' => $string, 'normalized' => $boolean, 'old_value' => $value, 'new_value' => $value,
    'requested_value' => $value, 'backup_id' => $nullableString, 'probe_before' => $object,
    'probe_after' => $object, 'rolled_back' => $boolean,
];
$settings = [
    'sql_retention' => $object, 'file_bytes' => $integer, 'enabled' => $boolean, 'update_channels' => $map,
];
$themeUpload = [
    'stylesheet' => $string, 'version' => $string, 'old_version' => $nullableString,
    'active_before' => $boolean, 'active_after' => $boolean, 'backup_id' => $nullableString,
    'zip_sha256' => $string, 'probe_before' => $object, 'probe_after' => $object, 'recovery' => $object,
];

return [
    'audit/get-operation' => [
        'contract' => $string, 'audit_id' => $string, 'provider' => $string, 'state' => $string,
        'reference_state' => $string, 'reference_current' => $boolean, 'snapshot_source' => $string,
        'redacted' => $boolean, 'before' => $value, 'after' => $value,
    ],
    'audit/get-service-operation' => [
        'contract' => $string, 'audit_id' => $string, 'principal_type' => $string, 'identity' => $object,
        'state' => $string, 'reference_state' => $string, 'reference_current' => $boolean,
        'snapshot_source' => $string, 'redacted' => $boolean, 'before' => $value, 'after' => $value,
    ],
    'audit/list' => [
        'entries' => $objects, 'has_more' => $boolean, 'next_cursor' => $nullableString, 'history_scope' => $string,
        'history_complete' => $boolean,
    ],
    'audit/prune' => $maintenance,
    'backups/export' => [
        'filename' => $string, 'content_base64' => $string, 'sha256' => $string,
        'backup_contains_sensitive_values' => $booleanOrString,
    ],
    'backups/export-part' => [
        'filename' => $string, 'content_base64' => $string, 'sha256' => $string,
        'backup_contains_sensitive_values' => $booleanOrString, 'encoding' => $string, 'offset_bytes' => $integer,
        'bytes' => $integer, 'total_bytes' => $integer, 'part_sha256' => $string, 'has_more' => $boolean,
        'next_cursor' => $nullableString, 'notice' => $string,
    ],
    'backups/list' => [
        'backups' => $objects, 'has_more' => $boolean, 'next_offset' => $nullableInteger,
        'history_complete' => $boolean, 'inventory' => $object,
    ],
    'connections/list' => [
        'connections' => $objects, 'has_more' => $boolean, 'next_before_id' => $nullableInteger,
    ],
    'connections/revoke' => $phase + [
        'revoked' => $boolean, 'scope' => $string, 'policy_version' => $integer, 'connection_id' => $string,
    ],
    'connections/update' => $phase + [
        'profile' => $string, 'policy_version' => $integer, 'connection_id' => $string,
    ],
    'content/blocks' => [
        'id' => $integer, 'post_type' => $string, 'sha256' => $string, 'blocks' => $objects, 'index' => $objects,
        'references' => $objects, 'validation' => $string,
    ],
    'content/deduplicate-seo-indexables' => $phase + [
        'id' => $integer, 'keep_id' => $nullableInteger, 'removed_ids' => $integers, 'backup_id' => $nullableString,
        'readback' => $object,
    ],
    'content/delete-meta' => $destructive + [
        'id' => $integer, 'meta_id' => $integer,
    ],
    'content/delete-orphan-seo-indexable' => $phase + [
        'indexable_id' => $integer, 'backup_id' => $nullableString, 'readback' => $object,
    ],
    'content/delete-term' => $phase + [
        'term_id' => $integer, 'term_taxonomy_id' => $integer, 'taxonomy' => $string,
        'deletion_hooks_invoked' => $boolean, 'readback' => $object, 'backup_id' => $nullableString,
    ],
    'content/diff' => [
        'id' => $integer, 'proposed_sha256' => $string, 'diff_html' => $string, 'preview' => $boolean,
    ],
    'content/edit-block' => [
        'id' => $integer, 'sha256' => $string, 'validation' => $string, 'content' => $string, 'preview' => $boolean,
    ],
    'content/get-meta' => $postMeta,
    'content/get-seo' => $seo,
    'content/restore-revision' => [
        'id' => $integer, 'field' => $string,
    ],
    'content/untrash' => [
        'id' => $integer, 'status' => $string,
    ],
    'content/update-meta' => $postMeta + [
        'backup_id' => $nullableString, 'normalized' => $boolean,
    ],
    'content/update-seo' => $seo + [
        'backup_id' => $nullableString, 'indexable_rebuilt' => $boolean, 'filtered_fields' => $strings,
        'count' => $integer, 'repair_ability' => $string,
    ],
    'content/update-term' => $phase + [
        'term_id' => $integer, 'term_taxonomy_id' => $integer, 'taxonomy' => $string,
        'backup_id' => $nullableString, 'filtered_fields' => $strings, 'url' => $value,
        'indexable_rebuilt' => $boolean, 'native_hooks_invoked' => $boolean, 'redirect_created' => $boolean,
        'partial' => $boolean,
    ],
    'content/upsert' => [
        'id' => $integer, 'created' => $boolean, 'sha256' => $string, 'link' => $booleanOrString,
        'partial' => $boolean,
    ],
    'cron/list' => [
        'events' => $objects, 'total' => $integer, 'has_more' => $boolean,
    ],
    'cron/run' => [
        'executed' => $boolean, 'callback_result' => $null, 'business_result' => $string,
        'result_semantics' => $string, 'duration_ms' => $integer, 'next_run' => $nullableInteger, 'hook' => $string,
    ],
    'cron/schedule' => [
        'scheduled' => $boolean, 'changed' => $boolean,
    ],
    'cron/unschedule' => [
        'changed' => $boolean, 'persisted' => $boolean,
    ],
    'db/export' => [
        'artifact_id' => $string, 'sha256' => $string, 'bytes' => $integer, 'row_count' => $integer,
        'tables' => $map, 'triggers' => $strings, 'format' => $string, 'gzip' => $boolean,
        'backup_contains_sensitive_values' => $boolean,
    ],
    'db/export-cancel' => [
        'cancel_requested' => $boolean,
    ],
    'db/export-part' => [
        'artifact_id' => $string, 'format' => $string, 'gzip' => $boolean, 'content_base64' => $string,
        'offset_bytes' => $integer, 'bytes' => $integer, 'total_bytes' => $integer, 'row_count' => $integer,
        'sha256' => $string, 'part_sha256' => $string, 'has_more' => $boolean, 'next_offset_bytes' => $integer,
    ],
    'db/query-export' => $exportJob,
    'db/query-page' => [
        'rows' => $objects, 'row_count' => $integer, 'total_rows' => $integer, 'has_more' => $boolean,
        'next_cursor' => $nullableString, 'consistency' => $string,
    ],
    'db/recovery-status' => [
        'id' => $string, 'status' => $string, 'artifact_id' => $string, 'started_at' => $integer,
        'finished_at' => $integer, 'completed_statements' => $integer, 'recovery_error' => $string,
        'rollback_artifact_id' => $string,
    ],
    'db/restore' => $phase + [
        'backup_scope' => $string, 'restore_tables' => $strings, 'restores_entire_tables' => $boolean,
        'artifact_id' => $string, 'backup_id' => $nullableString, 'restored_statements' => $integer,
        'runtime_state_preserved' => $boolean, 'preserved_state_manifest' => $object, 'atomic' => $boolean,
        'recovery_id' => $nullableString, 'affected_rows' => $integer, 'mysql_errno' => $integer,
    ],
    'files/archive' => $tree + [
        'sha256' => $string, 'bytes' => $integer,
    ],
    'files/copy' => $transfer,
    'files/extract' => $tree + [
        'entry_count' => $integer,
    ],
    'files/mkdir' => [
        'path' => $string, 'created' => $boolean,
    ],
    'files/move' => $transfer,
    'files/rollback-tree' => [
        'recovery' => $object,
    ],
    'files/search' => [
        'matches' => $objects, 'skipped' => $objects, 'partial_files' => $objects, 'scanned_bytes' => $integer,
        'has_more' => $boolean, 'next_offset' => $nullableInteger, 'listing_sha256' => $string,
    ],
    'files/stat' => [
        'path' => $string, 'type' => $string, 'bytes' => $integer, 'mtime' => $integer, 'mode' => $string,
        'readable' => $boolean, 'writable' => $boolean, 'sha256' => $string,
    ],
    'files/upload-cancel' => [
        'status' => $string, 'changed' => $boolean,
    ],
    'files/upload-create' => [
        'transfer_id' => $string, 'part_bytes' => $integer, 'part_count' => $integer, 'expires_at' => $string,
    ],
    'files/upload-finalize' => [
        'path' => $string, 'bytes' => $integer, 'sha256' => $string, 'backup_id' => $nullableString,
        'created' => $boolean,
    ],
    'files/upload-part' => [
        'index' => $integer, 'sha256' => $string, 'received' => $integer,
    ],
    'files/upload-status' => [
        'transfer_id' => $string, 'status' => $string, 'total_bytes' => $integer, 'sha256' => $string,
        'part_count' => $integer, 'expires' => $integer, 'received_indices' => $integers,
    ],
    'media/convert' => [
        'id' => $integer, 'source_id' => $integer, 'source_revision' => $string, 'formato' => $string,
        'mime_type' => $nullableString, 'url' => $booleanOrString, 'files' => $map, 'source_file' => $object,
        'savings_bytes' => $integer, 'original_preserved' => $boolean, 'metadata_copied' => $boolean,
        'generation' => $object, 'undo' => $object, 'file' => $string, 'partial' => $boolean,
        'cleanup_required' => $boolean,
    ],
    'media/regenerate' => [
        'id' => $integer, 'sizes' => $map, 'missing_sizes' => $strings, 'skipped_sizes' => $map,
        'metadata' => $value, 'original_preserved' => $boolean, 'backup_id' => $nullableString,
    ],
    'media/set-site-icon' => [
        'id' => $integer, 'site_icon' => $integer, 'previous_site_icon' => $integer, 'urls' => $map,
        'backup_id' => $nullableString, 'generation' => $object,
    ],
    'menus/delete' => $destructive + [
        'menu_id' => $integer, 'removed_items' => $integer, 'remaining_items' => $integers, 'locations' => $map,
    ],
    'operations/apply' => [
        'plan' => $object, 'plan_id' => $string, 'atomic' => $boolean,
    ],
    'operations/assert' => [
        'matched' => $boolean,
    ],
    'operations/cancel' => [
        'plan_id' => $string, 'status' => $string, 'rolled_back' => $boolean,
        'in_flight_step_may_complete' => $boolean,
    ],
    'operations/list' => [
        'operations' => $objects, 'has_more' => $boolean, 'next_cursor' => $nullableString,
    ],
    'operations/plan' => [
        'plan_id' => $string, 'status' => $string, 'steps' => $integer, 'expires_at' => $string,
        'atomic' => $boolean,
    ],
    'operations/preview' => [
        'plan_id' => $string, 'preview_id' => $string, 'steps' => $objects, 'preview' => $boolean,
    ],
    'operations/status' => $exportJob + [
        'plan' => $object, 'atomic' => $boolean, 'business_result' => $string, 'hook' => $string,
        'request_user_id' => $integer, 'execution_user_id' => $integer, 'finished_at' => $integer,
        'site_id' => $integer, 'reason' => $string, 'ability' => $string, 'expires_at' => $string,
        'result' => $object, 'backup' => $object, 'recovery_id' => $string, 'recovery_status' => $string,
    ],
    'options/delete' => $destructive + [
        'removed' => $strings, 'unchanged' => $strings, 'failed' => $map, 'pending' => $strings,
        'atomic' => $boolean, 'resume_with_same_confirmation' => $boolean,
    ],
    'plugins/cleanup-orphaned-uninstall' => $destructive + [
        'removed' => $strings, 'callbacks_executed' => $boolean,
    ],
    'plugins/install' => [
        'plugin' => $string, 'version' => $string, 'activated' => $boolean,
    ],
    'plugins/rollback' => [
        'dry_run' => $boolean, 'rollback_ready' => $boolean, 'already_restored' => $boolean,
        'backup_id' => $nullableString, 'plugin' => $string, 'package_operation_id' => $string,
        'preimage_verified' => $boolean, 'database_effects_reversible' => $boolean, 'recovery_status' => $string,
        'version_before' => $nullableString, 'version_after' => $nullableString, 'old_version' => $nullableString,
        'version' => $nullableString, 'versao_anterior' => $nullableString, 'versao' => $nullableString,
        'mudou' => $boolean, 'active_before' => $boolean, 'active_after' => $boolean, 'active' => $boolean,
        'activated' => $boolean, 'cache_invalidation' => $object, 'attempted_change' => $boolean, 'recovery' => $object, 'probe_recovery' => $object,
    ],
    'rewrite/flush' => [
        'before' => $object, 'after' => $object, 'hard' => $boolean,
    ],
    'roles/delete' => $phase + [
        'role' => $string, 'backup_id' => $nullableString,
    ],
    'roles/list' => [
        'roles' => $map,
    ],
    'roles/restore' => $phase + [
        'role' => $string, 'backup_id' => $nullableString, 'source_backup_id' => $string,
    ],
    'roles/update' => $phase + [
        'role' => $string, 'backup_id' => $nullableString,
    ],
    'site/set-address' => $phase + [
        'home' => $string, 'siteurl' => $string, 'backup_id' => $nullableString, 'probe_after' => $object,
        'search_replace' => $nullableObject,
    ],
    'site/set-admin-email' => $option,
    'site/set-language' => $option + [
        'effective_locale' => $string, 'storage' => $string,
    ],
    'system/cache-flush' => [
        'object_cache_flushed' => $boolean,
    ],
    'system/capabilities' => [
        'plugin_version' => $string, 'mutation_audit' => $object, 'mutation_service_audit' => $object,
        'wordpress' => $string, 'php' => $string, 'site_id' => $integer, 'user_id' => $integer,
        'connection_context' => $map, 'endpoint' => $string, 'legacy_endpoint' => $string, 'endpoints' => $objects,
        'metatools' => $strings, 'integrated_core_loaded' => $boolean, 'upstream_version' => $string,
        'abilities_api' => $string, 'capabilities' => $map, 'channels' => $object, 'limits' => $object,
        'file_scope' => $string, 'file_roots' => $strings, 'concurrency_scope' => $string,
    ],
    'system/delete-transient' => [
        'storage' => $string,
    ],
    'system/error-log' => [
        'groups' => $objects, 'total_groups' => $integer, 'has_more' => $boolean, 'next_cursor' => $nullableString,
        'since' => $string, 'until' => $string, 'file_timezone' => $string, 'site_timezone' => $string,
        'aggregation_scope' => $string, 'files_scanned' => $integer, 'gzip_files_scanned' => $integer,
        'lines_scanned' => $integer, 'unparsed_lines' => $integer, 'unparsed_samples' => $objects,
        'unparsed_scope' => $string, 'unparsed_sample_limit' => $integer, 'bytes_scanned' => $integer,
    ],
    'system/guide' => [
        'plugin_slug' => $string, 'plugin_version' => $string, 'source' => $string, 'ability' => $string,
        'description' => $string, 'availability' => $string, 'input_schema' => $object, 'output_schema' => $object,
        'documents' => $objects, 'topics' => $objects, 'document_id' => $string, 'document_revision' => $string,
        'document_sha256' => $string, 'topic' => $string, 'title' => $string, 'content' => $string,
        'offset_bytes' => $integer, 'returned_bytes' => $integer, 'total_bytes' => $integer, 'has_more' => $boolean,
        'next_cursor' => $nullableString, 'query' => $string, 'terms' => $strings, 'matches' => $objects,
        'returned' => $integer, 'total_matches' => $integer, 'truncated' => $boolean, 'next_step' => $string,
    ],
    'system/health' => [
        'healthy' => $boolean, 'checks' => $object, 'storage' => $object, 'recovery' => $object,
        'database_class' => $string, 'environment' => $object, 'external_connectivity_tested' => $boolean,
        'connection' => $object, 'cron' => $object, 'audit' => $object, 'providers' => $map,
        'maintenance' => $object, 'plugin_version' => $string, 'mutation_audit' => $object,
        'incidents_24h' => $object,
    ],
    'system/maintenance' => $maintenance,
    'system/oauth-diagnostics' => [
        'entries' => $objects, 'total' => $integer, 'limit' => $integer, 'order' => $string,
        'time_format' => $string, 'retention' => $string, 'incidents_24h' => $object,
    ],
    'system/probe' => [
        'contexto_teste' => $boolean, 'classe_trafego' => $string, 'traffic_class_scope' => $string,
        'cache' => $string, 'passed' => $boolean, 'status' => $string, 'samples' => $objects,
        'sample_count' => $integer, 'cache_bypass_verified' => $boolean, 'origin_scope' => $string,
        'external_access_proven' => $boolean, 'private_storage' => $object,
    ],
    'system/settings' => $settings,
    'system/settings-update' => $settings + $phase + [
        'backup_id' => $nullableString, 'observed' => $object,
    ],
    'themes/activate' => $phase + [
        'stylesheet' => $string, 'template' => $string, 'backup_id' => $nullableString, 'probe_after' => $object,
        'recovery' => $object,
    ],
    'themes/delete' => $phase + [
        'backup_id' => $nullableString,
    ],
    'themes/install' => [
        'slug' => $string, 'theme' => $object, 'activated' => $boolean,
    ],
    'themes/list' => [
        'themes' => $objects, 'stylesheet' => $string, 'template' => $string,
    ],
    'themes/rollback' => [
        'recovery' => $object,
    ],
    'themes/update' => $themeUpload,
    'themes/upload' => $themeUpload,
    'themes/validate' => [
        'theme' => $object, 'valid' => $boolean,
    ],
];
