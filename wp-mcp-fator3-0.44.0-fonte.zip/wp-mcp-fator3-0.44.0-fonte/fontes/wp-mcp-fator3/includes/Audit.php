<?php
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Audit {
    private static bool $write_failed=false;
    private static ?\WeakMap $denied_requests=null;
    /** WordPress can check permissions repeatedly to compute Allow/links. One row per request. */
    public static function transport_denied(\WP_REST_Request $request, string $code): bool {
        self::$denied_requests ??= new \WeakMap();
        if (isset(self::$denied_requests[$request])) return false;
        self::$denied_requests[$request] = true;
        // Never persist Authorization, cookies, query strings, IPs or request bodies here.
        self::record('mcp/access-denied', ['path'=>$request->get_route()], Result::fail($code, 'Acesso MCP recusado.'), 0);
        return true;
    }
    public static function record(string $name,array $input,array $result,int $duration): void {
        if(str_starts_with($name,'audit/') || $name === 'system/guide') return;
        try {
            $id=gmdate('YmdHis').'-'.bin2hex(random_bytes(8));
            $target=$result['plugin']??$input['plugin']??$input['path']??$input['destination']??$input['source']??$input['id']??$input['name']??$input['slug']??'';
            $reference=null;$operation=$result['operation_id']??'';
            if(is_string($operation)&&preg_match('/^[a-f0-9]{64}$/D',$operation)) {
                $key=MutationAudit::reference_id(Providers::metadata($name)['provider'],$operation);$row=Persistence::get('audit',$key);
                if(($row['kind']??'')==='mutation_reference'&&($row['connection_id']??'')===ConnectionContext::key()&&($row['user']??0)===get_current_user_id())$reference=$key;
            }
            Persistence::put('audit',$id,SafeOutput::error(['id'=>$id,'time'=>gmdate('c'),'user'=>get_current_user_id(),'connection_id'=>ConnectionContext::key(),'ability'=>$name,'target'=>is_scalar($target)?DataSafety::diagnostic_text((string)$target):'','duration_ms'=>$duration,'success'=>$result['success']??true,'error_code'=>$result['error_code']??'','operation_id'=>$result['operation_id']??'','backup_id'=>$result['backup_id']??'','replayed'=>$result['replayed']??false,'mutation_reference'=>$reference]+($name==='users/delete'?array_intersect_key($result,array_flip(['applied','persisted','user_exists','deletion_scope'])):[])+array_intersect_key($result,array_flip(['plugin','package_operation_id','zip_sha256']))+(['version_before'=>$result['old_version']??null,'version_after'=>$result['version']??null])),true);
        } catch(\Throwable $error) { self::write_failure(); }
    }
    public static function write_failure(): void {
        self::$write_failed=true;try{StateStore::write(StateStore::directory('diagnostics').'/audit-failure.php',StateStore::HEADER.json_encode(['time'=>time(),'code'=>'audit_persistence_failed']));}catch(\Throwable $ignored){}
    }
    public static function status(): array {
        $path=StateStore::directory('diagnostics').'/audit-failure.php';$last=null;
        if(is_file($path)){$raw=file_get_contents($path);if(str_starts_with($raw,StateStore::HEADER))$last=json_decode(substr($raw,strlen(StateStore::HEADER)),true);}
        return ['current_request_write_failed'=>self::$write_failed,'last_failure'=>$last];
    }
    public static function listing(array $input): array {
        $filters=[];
        foreach(['user','connection_id','ability','target','operation_id','success','ability_or_target'] as $key) if(isset($input[$key])) $filters[$key==='user'?'user_id':$key]=$input[$key];
        foreach(['since','until'] as $key) if(isset($input[$key])) { $t=strtotime($input[$key]);if(false===$t) return Result::fail('invalid_date','Use data ISO 8601.');$filters[$key]=$t; }
        $before=PHP_INT_MAX;
        if(!empty($input['cursor'])) { $cursor=Cursor::decode($input['cursor']); if(is_wp_error($cursor)) return Result::error($cursor); if(($cursor['kind']??'')!=='audit'||($cursor['connection']??'')!==ConnectionContext::key()||($cursor['filters']??'')!==hash('sha256',serialize($filters))) return Result::fail('cursor_invalid','Cursor não corresponde à conexão e filtros.');$before=(int)$cursor['before']; }
        $limit=max(1,min(200,(int)($input['per_page']??50)));$rows=Persistence::listing('audit',$filters,$limit+1,$before);$more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);
        $cursor=$more?Cursor::encode(['kind'=>'audit','connection'=>ConnectionContext::key(),'filters'=>hash('sha256',serialize($filters)),'before'=>end($rows)['_row_id']]):null;
        foreach($rows as &$row) unset($row['_row_id']);unset($row);
        return Result::ok(['entries'=>$rows,'has_more'=>$more,'next_cursor'=>$cursor,'history_scope'=>'persisted_sql_audit','history_complete'=>!self::$write_failed]);
    }
    public static function prune(array $input): array {
        return StateMaintenance::run(array_replace($input,['category'=>'audit']));
    }
}
