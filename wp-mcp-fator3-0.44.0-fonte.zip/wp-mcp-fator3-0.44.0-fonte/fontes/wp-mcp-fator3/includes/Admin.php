<?php
/** Unified settings UI. Operational status is supplied by ConnectionStatus. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Admin {
    private const SLUG = 'wp-mcp-fator3';
    public static function init(): void {
        add_action('admin_post_f3_mcp_access', [self::class, 'handle_access']);
        add_action('admin_post_f3_mcp_storage_probe', [self::class, 'storage_probe']);
        add_action('admin_menu', [self::class, 'menu']);
        add_action('admin_enqueue_scripts', [self::class, 'assets']);
        add_action('admin_post_f3_mcp_save', [self::class, 'handle_save']);
        add_action('admin_post_f3_mcp_file_limit', [self::class, 'handle_file_limit']);
        add_action('admin_post_f3_mcp_sql_retention', [self::class, 'handle_retention']);
        add_action('admin_post_f3_mcp_files_toggle', [self::class, 'handle_toggle']);
        add_action('admin_post_f3_mcp_db_toggle', [self::class, 'handle_db_toggle']);
    }
    public static function menu(): void { add_management_page('Fator3 MCP', 'Fator3 MCP', 'manage_options', self::SLUG, [self::class, 'render']); }
    public static function url(string $tab = 'overview'): string { return add_query_arg(['page' => self::SLUG, 'tab' => $tab], admin_url('tools.php')); }
    public static function forced_by_filter(): bool { return (bool)has_filter('f3_mcp_files_enabled'); }
    public static function hard_block(): bool { return (defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT) || (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS); }
    public static function assets(string $hook): void {
        if (!in_array($hook, ['tools_page_wp-mcp-fator3','tools_page_wp-mcp-ultimate'], true)) return;
        $base = plugin_dir_url(F3_MCP_FILES_DIR . 'wp-mcp-fator3.php') . 'core/assets/';
        wp_enqueue_style('f3-mcp-admin', $base . 'css/admin.css', [], F3_MCP_FILES_VERSION);
        wp_enqueue_script('f3-mcp-admin', $base . 'js/admin.js', [], F3_MCP_FILES_VERSION, true);
        wp_localize_script('f3-mcp-admin', 'f3McpAdmin', ['ajaxUrl' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('wp-mcp-ultimate'), 'endpoint' => ConnectionEndpoints::url()]);
    }
    private static function switch_revision(string $section, bool $stored): string {
        return hash('sha256', $section . ':' . (int)$stored);
    }
    public static function save(string $section, bool $enable, ?string $revision = null): array {
        if (!current_user_can('manage_options')) return Result::fail('permission_denied', 'Permissão insuficiente.');
        if (!in_array($section, ['channel','database'], true)) return Result::fail('invalid_section', 'Seção inválida.');
        if ('channel' === $section && $enable && self::hard_block()) return Result::fail('channel_blocked', 'O canal está bloqueado pelo wp-config.php.');
        $option = 'channel' === $section ? PathGuard::OPTION_ENABLED : Database::OPTION_WRITES;
        $result = Locks::run(['channel-settings'=>LOCK_EX, 'option:' . get_current_blog_id() . ':' . $option=>LOCK_EX], static function() use ($section,$option,$enable,$revision) {
            $stored=VerifiedOptions::stored($option,true);
            if (is_wp_error($stored))return Result::error($stored);
            if ($revision !== null && !hash_equals(self::switch_revision($section,(bool)$stored), $revision)) {
                return Result::fail('settings_conflict','A preferência mudou desde que você abriu a tela. Confira o estado atual antes de salvar novamente.',['conflict'=>true]);
            }
            return VerifiedOptions::update($option, ['value' => $enable ? '1' : '0']);
        });
        if (empty($result['success'])) {
            Audit::record('admin/settings', ['name'=>$section], $result, 0);
            return $result;
        }
        $effective = 'channel' === $section ? PathGuard::is_enabled() : (PathGuard::is_enabled() && Database::writes_enabled());
        $result['effective'] = $effective;
        $result['overridden'] = $effective !== $enable;
        $result['message'] = empty($result['success']) ? 'Não foi possível salvar a configuração. Confira o estado atual e tente novamente.' : ($result['overridden'] ? 'Preferência salva. O estado efetivo depende das restrições indicadas nesta seção.' : (!empty($result['changed']) ? 'Configurações salvas.' : 'Nenhuma alteração necessária.'));
        Audit::record('admin/settings', ['name' => $section], $result, 0);
        return $result;
    }
    private static function submit(string $nonce, ?string $section = null): void {
        if (!current_user_can('manage_options')) wp_die('Permissão insuficiente.', '', ['response' => 403]);
        check_admin_referer($nonce);
        $section = $section ?? (isset($_POST['section']) && is_string($_POST['section']) ? sanitize_key(wp_unslash($_POST['section'])) : '');
        $value = $_POST['enable'] ?? null;
        $revision = $_POST['revision'] ?? null;
        $result = in_array($value,['0','1'],true) && is_string($revision)
            ? self::save($section,$value==='1',$revision)
            : Result::fail('settings_input_invalid','O formulário está incompleto. Reabra a tela antes de salvar.');
        self::redirect_notice($result,'files');
    }

    /** Persist a single-use, user-bound message before the POST/redirect/GET. */
    public static function redirect_notice(array $result, string $tab, string $success_message='', array $args=[]): void {
        $key=wp_generate_uuid4();
        $ok=!empty($result['success']);
        $message=$ok && $success_message!=='' ? $success_message : ($result['message']??'');
        if (!$ok && in_array($result['error_code']??'', ['option_write_failed','option_write_rejected'],true)) {
            $message='A gravação não foi confirmada. Confira o valor atual e as restrições do servidor antes de repetir.';
        }
        if ($message==='')$message=$ok?'Alteração salva.':'Não foi possível concluir a ação.';
        set_transient('f3_mcp_notice_'.get_current_user_id().'_'.$key,['success'=>$ok,'message'=>$message],60);
        wp_safe_redirect(add_query_arg(['notice'=>$key]+$args,self::url($tab)));
        exit;
    }
    public static function handle_retention(): void {
        if(!current_user_can('manage_options'))wp_die('Permissão insuficiente.','',['response'=>403]);
        check_admin_referer('f3_mcp_sql_retention');$policy=[];
        foreach(['older_than_days','max_count','min_keep'] as $k){$raw=$_POST[$k]??null;$policy[$k]=is_string($raw)&&ctype_digit($raw)?(int)$raw:-1;}
        $revision=is_string($_POST['revision']??null)?wp_unslash($_POST['revision']):'';
        $result=Locks::run(['channel-settings'=>LOCK_EX],static function()use($policy,$revision){
            if(!SqlArtifacts::valid_policy($policy))return Result::fail('artifact_policy_invalid','Use idade de 1 a 3650 dias, quantidade de 1 a 10000 e mínimo entre zero e a quantidade.');
            $stored=VerifiedOptions::stored('f3_mcp_sql_retention',[]);
            if (is_wp_error($stored))return Result::error($stored);
            if(!hash_equals(hash('sha256',serialize(SqlArtifacts::effective_policy((array)$stored))),$revision))return Result::fail('settings_conflict','A política mudou. Recarregue a página antes de salvar.');
            return VerifiedOptions::update('f3_mcp_sql_retention',['value'=>$policy]);
        });
        Audit::record('admin/sql-retention',[],$result,0);
        self::redirect_notice($result,'files','Política de retenção salva. Para remover cópias, faça a prévia da limpeza.');
    }
    public static function handle_save(): void { self::submit('f3_mcp_settings'); }
    public static function handle_toggle(): void { self::submit('f3_mcp_files_toggle', 'channel'); }
    public static function handle_db_toggle(): void { self::submit('f3_mcp_db_toggle', 'database'); }
    public static function badge(bool $ok, string $yes, string $no): void { echo '<span class="f3-badge ' . ($ok ? 'is-ok' : 'is-muted') . '">' . esc_html($ok ? $yes : $no) . '</span>'; }

    /** UI formatting only: stored protocol identifiers remain unchanged. */
    public static function nonce(string $action): void {
        static $number=0;++$number;
        echo str_replace('id="_wpnonce"','id="f3-nonce-'.esc_attr($action).'-'.$number.'"',wp_nonce_field($action,'_wpnonce',false,false));
    }
    public static function states(): array { return ['pending'=>'Pendente','running'=>'Em andamento','paused'=>'Pausado','complete'=>'Concluído','failed'=>'Falhou','cancelled'=>'Cancelado','compensated'=>'Revertido por compensação','compensation_incomplete'=>'Compensação incompleta']; }
    public static function state(string $state): string { return self::states()[$state] ?? 'Estado não reconhecido'; }
    public static function profile(string $profile): string { return ['read'=>'Leitura','content'=>'Conteúdo','maintenance'=>'Manutenção','custom'=>'Personalizado'][$profile] ?? 'Sem acesso'; }
    public static function date($value): string {
        $time=is_numeric($value)?(int)$value:strtotime((string)$value);
        return $time ? wp_date('d/m/Y H:i',$time) : 'Não informado';
    }
    public static function time_html($value): string {
        $time=is_numeric($value)?(int)$value:strtotime((string)$value);
        if (!$time) return 'Não informado';
        $utc=gmdate('Y-m-d\TH:i:s\Z',$time);
        return '<time datetime="'.esc_attr($utc).'" title="'.esc_attr(gmdate('d/m/Y H:i:s',$time).' UTC').'">'.esc_html(self::date($time)).'</time>';
    }

    /** Compare normalized persisted values, including defaults on older installations. */
    public static function access_values() {
        $settings=[];
        foreach ([PathGuard::OPTION_ENABLED=>true,Database::OPTION_WRITES=>true,'f3_mcp_file_bytes'=>PathGuard::MAX_BYTES] as $key=>$default) {
            $value=VerifiedOptions::stored($key,$default);
            if (is_wp_error($value)) return $value;
            $settings[$key]=is_bool($default)?(int)(bool)$value:(int)$value;
        }
        return $settings;
    }
    public static function save_access(array $input): array {
        if (!current_user_can('manage_options')) return Result::fail('permission_denied','Permissão insuficiente.');
        if (($input['form_complete']??'')!=='1' || !is_string($input['revision']??null)
            || !in_array($input['channel']??null,['0','1'],true) || !in_array($input['database']??null,['0','1'],true)
            || !is_string($input['file_mib']??null) || !is_numeric($input['file_mib'])) {
            return Result::fail('settings_input_invalid','Formulário incompleto. Confira os três ajustes.');
        }
        $locks=['channel-settings'=>LOCK_EX];
        foreach ([PathGuard::OPTION_ENABLED,Database::OPTION_WRITES,'f3_mcp_file_bytes'] as $key) $locks['option:'.get_current_blog_id().':'.$key]=LOCK_EX;
        return Locks::run($locks,static function() use ($input) {
            global $wpdb;
            $old=self::access_values();
            if (is_wp_error($old)) return Result::error($old);
            if (!hash_equals(hash('sha256',serialize($old)),$input['revision'])) return Result::fail('settings_conflict','Os ajustes mudaram. Confira os valores atuais antes de salvar.');
            $mib=$input['file_mib'];
            // Older releases accepted an exact byte count. Round only when the administrator edits the limit.
            $bytes=$old['f3_mcp_file_bytes'];
            if ($mib!==(string)($bytes/1048576)) {
                if (!ctype_digit($mib) || (int)$mib<1 || (int)$mib>1024) return Result::fail('file_limit_invalid','Informe um número inteiro de 1 a 1.024 MiB.');
                $bytes=(int)$mib*1048576;
            }
            $desired=[PathGuard::OPTION_ENABLED=>(int)$input['channel'],Database::OPTION_WRITES=>(int)$input['database'],'f3_mcp_file_bytes'=>$bytes];
            if (self::hard_block() && $desired[PathGuard::OPTION_ENABLED] && !$old[PathGuard::OPTION_ENABLED]) return Result::fail('channel_blocked','O wp-config.php bloqueia a abertura do canal.');
            $changed=array_diff_assoc($desired,$old);
            if (!$changed) return Result::ok(['changed'=>false],'Os ajustes já tinham esses valores.');
            if ($wpdb->query('START TRANSACTION')===false) return Result::fail('settings_transaction_failed','Não foi possível iniciar a gravação.');
            $committed=false;
            try {
                foreach ($changed as $key=>$value) {
                    $r=VerifiedOptions::update($key,['value'=>(string)$value]);
                    if (empty($r['success']) || (string)($r['new_value']??'')!==(string)$value) return Result::fail('option_write_rejected','O servidor recusou um dos ajustes.');
                }
                $committed=$wpdb->query('COMMIT')!==false;
            } finally {
                if (!$committed) $wpdb->query('ROLLBACK');
                foreach (array_keys($changed) as $key) wp_cache_delete($key,'options');
                wp_cache_delete('alloptions','options');
                wp_cache_delete('notoptions','options');
            }
            return $committed ? Result::ok(['changed'=>true],'Ajustes de acesso salvos.') : Result::fail('settings_transaction_failed','Confira os valores. A gravação não foi confirmada.');
        });
    }
    public static function handle_access(): void {
        if (!current_user_can('manage_options')) wp_die('Permissão insuficiente.','',['response'=>403]);
        check_admin_referer('f3_mcp_access');
        $r=self::save_access(wp_unslash($_POST));
        Audit::record('admin/settings',['name'=>'access'],$r,0);
        self::redirect_notice($r,'files');
    }
    public static function storage_probe(): void {
        if (!current_user_can('manage_options')) wp_die('Permissão insuficiente.','',['response'=>403]);
        check_admin_referer('f3_mcp_storage_probe');
        try {
            $probe=Probe::storage_test(true);
            $r=!empty($probe['passed']) ? Result::ok([],'Proteção HTTP confirmada para o marcador privado.') : Result::fail('storage_probe_unconfirmed',$probe['reason']??'A sonda não confirmou a proteção do marcador privado.');
        } catch (\Throwable $e) { $r=Result::fail('storage_probe_failed','Não foi possível executar a sonda de armazenamento.'); }
        self::redirect_notice($r,($_POST['tab']??'')==='overview'?'overview':'diagnostics');
    }
    public static function probe_form(string $tab): void {
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        self::nonce('f3_mcp_storage_probe');
        echo '<input type="hidden" name="action" value="f3_mcp_storage_probe"><input type="hidden" name="tab" value="'.esc_attr($tab).'"><button class="button">Testar agora<span class="screen-reader-text"> a proteção do armazenamento</span></button></form>';
    }
    public static function storage_evidence(): ?array {
        try {
            $record=StateStore::get('diagnostics','private-http');
            if (!$record) return null;
            $fingerprint=hash('sha256',wp_normalize_path(StateStore::directory()).'|'.home_url('/'));
            return ($record['fingerprint']??'')===$fingerprint ? $record : null;
        } catch (\Throwable $e) { return null; }
    }

    public static function help(string $id,string $text): void { echo '<p class="description" id="'.esc_attr($id).'">'.esc_html($text).'</p>'; }
    public static function ability_label(string $id): string {
        $ability=wp_get_ability($id);if(!$ability)return 'Habilidade indisponível';
        return $ability->get_label();
    }

    public static function choices(string $name,array $choices,array $selected,string $label,string $help): void {
        $id='f3-choice-'.$name;
        echo '<fieldset class="f3-choices" data-choices><legend>'.esc_html($label).'</legend><label for="'.esc_attr($id).'">Pesquisar '.esc_html(strtolower($label)).'</label><input type="search" id="'.esc_attr($id).'" data-choice-search autocomplete="off" aria-controls="'.esc_attr($id.'-list').'"><p class="description" id="'.esc_attr($id.'-help').'">'.esc_html($help).'</p><p data-choice-count role="status" aria-live="polite"></p><div class="f3-choice-list" id="'.esc_attr($id.'-list').'">';
        $groups=[];
        foreach ($choices as $key=>$title) {
            $group='';
            if ($name==='abilities') {
                $meta=wp_has_ability($key)?wp_get_ability($key)->get_meta():[];
                $provider=$meta['fator3']['provider']??Providers::metadata($key)['provider'];
                $group=($provider==='unknown'?'Provedor sem registro':$provider).' · '.explode('/',$key,2)[0];
            }
            $groups[$group][$key]=$title;
        }
        ksort($groups,SORT_NATURAL|SORT_FLAG_CASE);
        if ($name==='abilities') echo '<label data-selection-control hidden><input type="checkbox" data-only-selected> Mostrar só selecionadas</label>';
        foreach ($groups as $group=>$items) {
            if ($group!=='') {
                $count=count(array_intersect(array_keys($items),$selected));
                echo '<details data-choice-group><summary>'.esc_html($group).' <span data-group-count>'.esc_html($count.' de '.count($items)).'</span></summary><div data-selection-control class="f3-actions" hidden><button type="button" class="button" data-mark="1">Marcar grupo</button><button type="button" class="button" data-mark="0">Desmarcar grupo</button></div>';
            }
            foreach ($items as $key=>$title) echo '<label data-choice><input type="checkbox" name="'.esc_attr($name).'[]" value="'.esc_attr($key).'" '.checked(in_array($key,$selected,true),true,false).' aria-describedby="'.esc_attr($id.'-help').'"> <span>'.esc_html($title).'<small><code>'.esc_html($key).'</code></small></span></label>';
            if ($group!=='') echo '</details>';
        }
        echo '</div></fieldset>';
    }
    public static function file_limit(int $limit,string $revision): array {
        if(!current_user_can('manage_options'))return Result::fail('permission_denied','Permissão insuficiente.');
        return Locks::run(['channel-settings'=>LOCK_EX],static function()use($limit,$revision){
            if($limit<1048576||$limit>1073741824)return Result::fail('file_limit_invalid','Use um limite entre 1 MiB e 1 GiB.');
            $stored=VerifiedOptions::stored('f3_mcp_file_bytes',PathGuard::MAX_BYTES);
            if (is_wp_error($stored))return Result::error($stored);
            if(!hash_equals(hash('sha256',serialize($stored)),$revision))return Result::fail('settings_conflict','O limite mudou. Recarregue a página.');
            return VerifiedOptions::update('f3_mcp_file_bytes',['value'=>$limit]);
        });
    }
    public static function handle_file_limit(): void {
        if(!current_user_can('manage_options'))wp_die('Permissão insuficiente.','',['response'=>403]);
        check_admin_referer('f3_mcp_file_limit');$raw=$_POST['file_bytes']??null;
        $r=self::file_limit(is_string($raw)&&ctype_digit($raw)?(int)$raw:0,is_string($_POST['revision']??null)?wp_unslash($_POST['revision']):'');
        Audit::record('admin/file-limit',[],$r,0);
        self::redirect_notice($r,'files','Limite por arquivo salvo.');
    }

    public static function render(): void {
        if (!current_user_can('manage_options')) return;
        $tab=is_string($_GET['tab']??null)?sanitize_key(wp_unslash($_GET['tab'])):'overview';
        $tabs=self::tabs();
        $section=['operations'=>'history','updates'=>'diagnostics'][$tab]??$tab;
        if (!isset($tabs[$section])) $section=$tab='overview';
        if ($tab==='updates') $tab='diagnostics';
        if (in_array($tab,['overview','connection','diagnostics'],true)) $status=ConnectionStatus::snapshot();
        self::frame($section);
        if (isset($_GET['notice']) && is_string($_GET['notice']) && preg_match('/^[a-f0-9-]{36}$/D', $_GET['notice'])) {
            $key = 'f3_mcp_notice_' . get_current_user_id() . '_' . $_GET['notice']; $notice = get_transient($key); delete_transient($key);
            if (is_array($notice)) echo '<div class="notice ' . ($notice['success'] ? 'notice-success' : 'notice-error') . ' inline"><p>' . esc_html($notice['message']) . '</p></div>';
        }
        echo '<div id="f3-feedback" class="f3-feedback" role="status" aria-live="polite" hidden></div>';
        include F3_MCP_FILES_DIR . 'includes/views/' . $tab . '.php';
        echo '</div></div>';
    }
    public static function tabs(): array {
        return ['overview'=>'Visão geral','connection'=>'Conexão','connections'=>'Clientes','files'=>'Arquivos e banco','history'=>'Atividade','diagnostics'=>'Diagnóstico','help'=>'Ajuda'];
    }
    public static function frame(string $section): void {
        echo '<div class="wrap f3-mcp-admin"><header class="f3-header"><h1>Fator3 MCP</h1><span class="f3-version">Versão '.esc_html(F3_MCP_FILES_VERSION).'</span></header><nav class="nav-tab-wrapper f3-tabs" aria-label="Seções do Fator3 MCP">';
        foreach (self::tabs() as $key=>$label) {
            $active=$key===$section;
            echo '<a class="nav-tab'.($active?' nav-tab-active':'').'" '.($active?'aria-current="page"':'').' href="'.esc_url(self::url($key)).'">'.esc_html($label).'</a>';
        }
        echo '</nav><div class="f3-panel">';
    }
    public static function test_controls(array $status): void {
        $previous = ConnectionStatus::previous();
        $observed = $status['observed_connections'] ?? [];
        echo '<p>Registro local: ' . esc_html(empty($status['errors']) ? 'confirmado' : 'requer atenção') . '. OAuth: ' . esc_html(count(array_filter($observed, static fn($r) => $r['authentication'] === 'oauth')) ? 'requisição autenticada observada' : 'ainda não observado') . '.</p>';
        if ($observed) {
            echo '<details><summary>Conexões autenticadas observadas</summary><ul>';
            foreach ($observed as $row) echo '<li>' . esc_html($row['connection_id'] . ' · ' . $row['route'] . ' · ' . ($row['protocol_version'] ?? 'versão não informada')).' · '.self::time_html($row['observed_at']) . '</li>';
            echo '</ul><p>Confirma requisições reais; não identifica a origem de rede através de proxies. Credenciais temporárias do autoteste são excluídas.</p></details>';
        } else echo '<p>Nenhuma requisição de conector foi observada desde esta atualização.</p>';
        echo '<label for="f3-test-route">Endereço para testar</label><div class="f3-actions"><select id="f3-test-route">';
        foreach ($status['endpoints'] as $entry) echo '<option value="' . esc_attr($entry['route']) . '">' . esc_html($entry['role'] === 'legacy' ? 'Compatibilidade — wp-mcp-ultimate' : ($entry['role'] === 'primary' ? 'URL principal' : 'Alias Fator3')) . '</option>';
        echo '</select><button type="button" class="button" id="f3-test">Testar comunicação HTTP</button></div><p class="description">O teste parte deste servidor, com uma senha temporária. Verifica autenticação e os três metatools; o acesso do seu conector e o fluxo OAuth precisam ser verificados no próprio cliente.</p>';
        echo '<p id="f3-test-result" role="status" aria-live="polite">' . ($previous ? esc_html($previous['message']).' Último teste em '.self::time_html($previous['tested_at']).' · '.esc_html($previous['route']) : 'Comunicação HTTP ainda não verificada.') . '</p>';
    }
}
