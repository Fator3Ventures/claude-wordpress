<?php
/**
 * Habilidades files/* — leitura, escrita, exclusão e download de arquivos
 * de temas e plugins, via Abilities API.
 *
 * Registradas na Abilities API global; o WP MCP Ultimate as expõe
 * automaticamente como ferramentas MCP (o `discover-abilities` dele varre
 * wp_get_abilities(), sem filtrar por plugin de origem).
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class Files {

	/**
	 * Portão comum a todas as habilidades.
	 *
	 * @return array|null Array de erro pronto para devolver, ou null se liberado.
	 */
	private static function gate(): ?array {
		if ( ! PathGuard::is_enabled() ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'O canal de arquivos está fechado. Reabra em Ferramentas > Fator3 MCP no wp-admin (ou remova DISALLOW_FILE_EDIT do wp-config.php, se for o caso).', 'wp-mcp-fator3' ),
			);
		}

		if ( ! PathGuard::can_edit() ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'Permissão insuficiente: são exigidas as capacidades edit_themes e manage_options.', 'wp-mcp-fator3' ),
			);
		}

		return null;
	}

	/**
	 * Converte um WP_Error no formato de resposta das habilidades.
	 */
	private static function fail( \WP_Error $error ): array {
		return Result::error($error);
	}

	/**
	 * Callback de permissão compartilhado.
	 */
	private static function permission(): bool {
		return PathGuard::is_enabled() && PathGuard::can_edit();
	}

	public static function register(): void {

		// =====================================================================
		// FILES — List
		// =====================================================================
		wp_register_ability(
			'files/list',
			array(
				'label'               => 'List Server Files',
				'description'         => 'Lista arquivos alcançáveis pelo usuário do PHP, respeitando o confinamento opcional. Params: path (opcional, relativo à raiz do WordPress), recursive (opcional), max_depth (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path'      => array(
							'type'        => 'string',
							'description' => 'Caminho absoluto (ex.: /home/usuario/site/arquivo.txt) ou relativo à raiz do WordPress, ex.: wp-content/plugins/meu-plugin. Vazio lista ABSPATH.',
						),
						'recursive' => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Percorrer subdiretórios.',
						),
						'max_depth' => array(
							'type'        => 'integer',
							'default'     => 3,
							'minimum'     => 1,
							'maximum'     => 10,
							'description' => 'Profundidade máxima quando recursive=true.',
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'path'    => array( 'type' => 'string' ),
						'entries' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
					),
				),
				'execute_callback' => static fn($input = []) => FileTools::permission() ? FileTools::listing(is_array($input) ? $input : []) : Result::fail('permission_denied', 'O canal de arquivos está indisponível.'),
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
                    'fator3' => array('owned'=>true, 'provider'=>'wp-mcp-fator3', 'version'=>F3_MCP_FILES_VERSION),
					'annotations' => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);

		// =====================================================================
		// FILES — Read
		// =====================================================================
		wp_register_ability(
			'files/read',
			array(
				'label'               => 'Read Server File',
				'description'         => 'Lê um arquivo alcançável pelo PHP. Só path mantém a leitura integral. tail_lines lê do fim; offset pula linhas (do fim em tail, do início nos demais casos); limit pagina do início (padrão 1000). grep filtra ANTES de offset/tail/limit; literal por padrão, ou PCRE com grep_regex=true. Leitura parcial aceita arquivos grandes sem carregar tudo; respeita o teto de bytes por resposta. O SHA-256 parcial cobre somente o conteúdo devolvido.',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path' => array(
							'type'        => 'string',
							'description' => 'Caminho absoluto (ex.: /home/usuario/site/arquivo.txt) ou relativo à raiz do WordPress, ex.: wp-content/themes/meu-tema/functions.php',
						),
						'tail_lines' => array(
							'type' => 'integer', 'minimum' => 1, 'maximum' => FileReader::MAX_LINES,
							'description' => 'Quantidade de últimas linhas correspondentes, devolvidas na ordem original. Não combinar com limit.',
						),
						'offset' => array(
							'type' => 'integer', 'minimum' => 0,
							'description' => 'Linhas correspondentes a ignorar, começando em zero. Conta do fim com tail_lines e do início com limit. Padrão 0.',
						),
						'limit' => array(
							'type' => 'integer', 'minimum' => 1, 'maximum' => FileReader::MAX_LINES,
							'description' => 'Máximo de linhas correspondentes por página do início. Padrão 1000 no modo parcial. Não combinar com tail_lines.',
						),
						'grep' => array(
							'type' => 'string', 'maxLength' => 4096,
							'description' => 'Substring literal sensível a maiúsculas/minúsculas; vazio corresponde a todas as linhas. Com grep_regex=true, informar PCRE com delimitadores, ex.: /error|fatal/i. Máximo 4096 bytes.',
						),
						'grep_regex' => array(
							'type' => 'boolean',
							'description' => 'Interpreta grep como PCRE. Padrão false. Não executa comandos de shell.',
						),
					),
					'required'             => array( 'path' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'path'    => array( 'type' => 'string' ),
						'content' => array( 'type' => 'string' ),
						'bytes'   => array( 'type' => 'integer' ),
						'sha256'  => array( 'type' => 'string' ),
						'file_bytes'     => array( 'type' => 'integer', 'description' => 'Tamanho do arquivo ao abrir, no modo parcial.' ),
						'sha256_scope'   => array( 'type' => 'string', 'enum' => array( 'returned_content' ) ),
						'partial'        => array( 'type' => 'boolean', 'description' => 'true indica modo por linhas; sha256 não serve como hash do arquivo integral para escrita.' ),
						'mode'           => array( 'type' => 'string', 'enum' => array( 'tail', 'lines' ) ),
						'returned_lines' => array( 'type' => 'integer' ),
						'offset'         => array( 'type' => 'integer' ),
						'has_more'       => array( 'type' => 'boolean' ),
						'next_offset'    => array( 'type' => array( 'integer', 'null' ), 'description' => 'Próximo offset na mesma direção, mantendo grep e demais parâmetros; null ao terminar.' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['path'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetro obrigatório ausente: path', 'wp-mcp-fator3' ) );
					}

					$path = PathGuard::resolve( (string) $input['path'], false );
					if ( is_wp_error( $path ) ) {
						return self::fail( $path );
					}

					$ext_ok = PathGuard::check_extension( $path );
					if ( is_wp_error( $ext_ok ) ) {
						return self::fail( $ext_ok );
					}

					if ( ! is_file( $path ) || ! is_readable( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Arquivo não encontrado ou sem permissão de leitura.', 'wp-mcp-fator3' ) );
					}

					$compression=$input['compression']??'none';
                    if($compression!=='none') {
                        $signature=@file_get_contents($path,false,null,0,2);
                        if($compression==='gzip'||$compression==='auto'&&$signature==="\x1f\x8b")return GzipReader::read($path,$input);
                    }
                    if (array_key_exists('cursor', $input) || array_key_exists('offset_bytes', $input)) return FileTools::read_cursor($path, $input);
					if ( array_intersect( array( 'tail_lines', 'offset', 'limit', 'grep', 'grep_regex' ), array_keys( $input ) ) ) {
						$result = FileReader::read( $path, $input, PathGuard::max_bytes() );
						return is_wp_error( $result ) ? self::fail( $result ) : $result;
					}

					$size = (int) filesize( $path );
					if ( $size > PathGuard::max_bytes() ) {
						return array(
							'success' => false,
							'message' => esc_html(
								sprintf(
									/* translators: 1: tamanho do arquivo, 2: limite. */
									__( 'Arquivo grande demais (%1$s); o limite deste canal é %2$s.', 'wp-mcp-fator3' ),
									size_format( $size ),
									size_format( PathGuard::max_bytes() )
								)
							),
						);
					}

					$content = file_get_contents( $path );
					if ( false === $content ) {
						return array( 'success' => false, 'message' => esc_html__( 'Falha ao ler o arquivo.', 'wp-mcp-fator3' ) );
					}

					return array(
						'success' => true,
						'message' => esc_html__( 'Arquivo lido com sucesso.', 'wp-mcp-fator3' ),
						'path'    => PathGuard::to_relative( $path ),
						'encoding' => DataSafety::binary($content, $path) ? 'base64' : 'utf-8',
						(DataSafety::binary($content, $path) ? 'content_base64' : 'content') => DataSafety::binary($content, $path) ? base64_encode($content) : $content,
						'bytes'   => $size,
						'sha256'  => hash( 'sha256', $content ),
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
                    'fator3' => array('owned'=>true, 'provider'=>'wp-mcp-fator3', 'version'=>F3_MCP_FILES_VERSION),
					'annotations' => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);

		// =====================================================================
		// FILES — Write
		// =====================================================================
		wp_register_ability(
			'files/write',
			array(
				'label'               => 'Write Server File',
				'description'         => 'Cria ou sobrescreve qualquer arquivo alcançável pelo usuário do PHP, com confinamento opcional por site — qualquer extensão (php, css, js, csv, tsv, json, mo, sql…) e também arquivos sem extensão. Faz backup automático, valida sintaxe PHP antes de gravar e grava de forma atômica. Params: path (required), content ou content_base64 (required), expected_sha256 (opcional), backup (opcional, padrão true).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path'            => array(
							'type'        => 'string',
							'description' => 'Caminho absoluto (ex.: /home/usuario/site/arquivo.txt) ou relativo à raiz do WordPress.',
						),
						'content'         => array(
							'type'        => 'string',
							'description' => 'Conteúdo do arquivo em texto.',
						),
						'content_base64'  => array(
							'type'        => 'string',
							'description' => 'Bytes em base64. Informe exatamente um entre content e content_base64; extensões binárias exigem base64.',
						),
						'expected_sha256' => array(
							'type'        => 'string',
							'description' => 'SHA-256 do conteúdo atual. Se informado e não bater, a gravação é abortada — evita sobrescrever alteração feita por outra pessoa.',
						),
						'backup'          => array(
							'type'        => 'boolean',
							'default'     => true,
							'description' => 'Guardar cópia do conteúdo anterior antes de sobrescrever.',
						),
						'append'          => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Acrescentar ao final em vez de substituir. Use para enviar um arquivo grande em pedaços, um por chamada.',
						),
						'create_dirs'     => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Criar os diretórios que faltarem no caminho. Necessário para começar um tema ou plugin novo.',
						),
					),
					'required'             => array( 'path' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'   => array( 'type' => 'boolean' ),
						'message'   => array( 'type' => 'string' ),
						'path'      => array( 'type' => 'string' ),
						'bytes'     => array( 'type' => 'integer' ),
						'sha256'    => array( 'type' => 'string' ),
						'backup_id' => array( 'type' => 'string' ),
						'created'   => array( 'type' => 'boolean' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['path'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetro obrigatório ausente: path', 'wp-mcp-fator3' ) );
					}

					if ( ! isset( $input['content'] ) && ! isset( $input['content_base64'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Informe content ou content_base64.', 'wp-mcp-fator3' ) );
					}

					if (isset($input['content'], $input['content_base64'])) return Result::fail('conflicting_content', 'Informe content OU content_base64.');
					if (isset($input['content']) && DataSafety::binary_extension((string)$input['path'])) return Result::fail('binary_content_required', 'Extensão binária exige content_base64.');
					if ( isset( $input['content_base64'] ) ) {
						$content = base64_decode( (string) $input['content_base64'], true );
						if ( false === $content ) {
							return array( 'success' => false, 'message' => esc_html__( 'content_base64 não é base64 válido.', 'wp-mcp-fator3' ) );
						}
					} else {
						$content = (string) $input['content'];
					}

					if ( strlen( $content ) > PathGuard::max_bytes() ) {
						return array(
							'success' => false,
							'message' => esc_html(
								sprintf(
									/* translators: %s: limite de tamanho. */
									__( 'Conteúdo maior que o limite deste canal (%s).', 'wp-mcp-fator3' ),
									size_format( PathGuard::max_bytes() )
								)
							),
						);
					}

					if ( ! empty( $input['create_dirs'] ) ) {
						$prepared = PathGuard::prepare_parent( (string) $input['path'] );
						if ( is_wp_error( $prepared ) ) {
							return self::fail( $prepared );
						}
					}

					$path = PathGuard::resolve( (string) $input['path'], true );
					if ( is_wp_error( $path ) ) {
						return self::fail( $path );
					}

					$ext_ok = PathGuard::check_extension( $path );
					if ( is_wp_error( $ext_ok ) ) {
						return self::fail( $ext_ok );
					}

					$exists = is_file( $path );
					$append = ! empty( $input['append'] );

					// No modo append o conteúdo final é o que já existe mais o
					// pedaço novo — e é ele que precisa passar pela checagem de
					// sintaxe, não só o pedaço.
					if ( $append && $exists ) {
						$previous = file_get_contents( $path );
						if ( false === $previous ) {
							return array( 'success' => false, 'message' => esc_html__( 'Falha ao ler o conteúdo atual para acrescentar.', 'wp-mcp-fator3' ) );
						}
						$content = $previous . $content;

						if ( strlen( $content ) > PathGuard::max_bytes() ) {
							return array(
								'success' => false,
								'message' => esc_html(
									sprintf(
										/* translators: %s: limite de tamanho. */
										__( 'O arquivo passaria do limite deste canal (%s) com este acréscimo.', 'wp-mcp-fator3' ),
										size_format( PathGuard::max_bytes() )
									)
								),
							);
						}
					}

					// Concorrência otimista: só grava se o conteúdo atual for o esperado.
					if ( ! empty( $input['expected_sha256'] ) ) {
						$current = $exists ? file_get_contents( $path ) : '';
						$actual  = hash( 'sha256', false === $current ? '' : $current );
						if ( ! hash_equals( $actual, strtolower( (string) $input['expected_sha256'] ) ) ) {
							return array(
								'success' => false,
								'message' => esc_html__( 'O arquivo mudou desde a última leitura. Leia de novo antes de gravar.', 'wp-mcp-fator3' ),
								'sha256'  => $actual,
							);
						}
					}

					// A checagem de sintaxe vem antes de qualquer escrita: PHP
					// quebrado em functions.php derruba o site e, com ele, o
					// próprio endpoint MCP usado para consertar.
					if ( 'php' === strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ) {
						$syntax = PathGuard::check_php_syntax( $content );
						if ( is_wp_error( $syntax ) ) {
							return self::fail( $syntax );
						}
					}

					if ( $exists && ! is_writable( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'O arquivo existe mas não tem permissão de escrita.', 'wp-mcp-fator3' ) );
					}
					if ( ! $exists && ! is_writable( dirname( $path ) ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'O diretório de destino não tem permissão de escrita.', 'wp-mcp-fator3' ) );
					}

					$backup_id = '';
					$do_backup = ! isset( $input['backup'] ) || ! empty( $input['backup'] );
					if ( $exists && $do_backup ) {
						$backup_id = self::make_backup( $path );
						if ( is_wp_error( $backup_id ) ) {
							return self::fail( $backup_id );
						}
					}

					$written = self::atomic_write( $path, $content );
					if ( is_wp_error( $written ) ) {
						return self::fail( $written );
					}

					$sha = hash( 'sha256', $content );

					PathGuard::audit(
						$exists ? 'write:overwrite' : 'write:create',
						PathGuard::to_relative( $path ),
						array(
							'bytes'     => strlen( $content ),
							'sha256'    => $sha,
							'backup_id' => $backup_id,
						)
					);

					return array(
						'success'   => true,
						'message'   => esc_html(
							$exists
								? __( 'Arquivo atualizado. Backup guardado; use files/restore para reverter.', 'wp-mcp-fator3' )
								: __( 'Arquivo criado.', 'wp-mcp-fator3' )
						),
						'path'      => PathGuard::to_relative( $path ),
						'bytes'     => strlen( $content ),
						'sha256'    => $sha,
						'backup_id' => $backup_id,
						'created'   => ! $exists,
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
                    'fator3' => array('owned'=>true, 'provider'=>'wp-mcp-fator3', 'version'=>F3_MCP_FILES_VERSION),
					'annotations' => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => true,
					),
				),
			)
		);

		// =====================================================================
		// FILES — List Backups
		// =====================================================================
		wp_register_ability(
			'files/backups',
			array(
				'label'               => 'List Server File Backups',
				'description'         => 'Lista os backups criados automaticamente pelo files/write. Params: path (opcional, filtra por arquivo), per_page (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path'     => array(
							'type'        => 'string',
							'description' => 'Filtra backups de um arquivo específico (caminho relativo).',
						),
						'per_page' => array(
							'type'        => 'integer',
							'default'     => 20,
							'minimum'     => 1,
							'maximum'     => 100,
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'backups' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
					),
				),
				'execute_callback' => function ( $input = array() ): array {
					$gate = self::gate();
					return null !== $gate ? $gate : Backups::listing( is_array( $input ) ? $input : array() );
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
                    'fator3' => array('owned'=>true, 'provider'=>'wp-mcp-fator3', 'version'=>F3_MCP_FILES_VERSION),
					'annotations' => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);

		// =====================================================================
		// FILES — Restore
		// =====================================================================
		wp_register_ability(
			'files/restore',
			array(
				'label'               => 'Restore Server File Backup',
				'description'         => 'Restaura um arquivo alcançável pelo usuário do PHP a partir de backup, validando SHA-256 e sintaxe PHP. Caminhos relativos a ABSPATH ou absolutos, como /home/usuario/arquivo.php. Params: backup_id (required).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'backup_id' => array(
							'type'        => 'string',
							'description' => 'Identificador devolvido por files/write, patch, delete, fetch, restore ou files/backups.',
						),
					),
					'required'             => array( 'backup_id' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'path'    => array( 'type' => 'string' ),
						'bytes'   => array( 'type' => 'integer' ),
						'backup_id' => array( 'type' => 'string', 'description' => 'Backup do conteúdo anterior à restauração; vazio se o destino não existia.' ),
					),
				),
				'execute_callback' => function ( $input = array() ): array {
					$gate = self::gate();
					return null !== $gate ? $gate : Backups::restore( is_array( $input ) ? $input : array() );
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
                    'fator3' => array('owned'=>true, 'provider'=>'wp-mcp-fator3', 'version'=>F3_MCP_FILES_VERSION),
					'annotations' => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => true,
					),
				),
			)
		);

		self::register_transfer();
		self::register_patch();
		self::register_selftest();
	}

	/**
	 * Registra `files/patch` — edição por trecho, não por arquivo inteiro.
	 *
	 * Existe por economia, e a economia é grande: mudar quatro linhas de um CSS
	 * de 28 KB com `files/write` custa o arquivo inteiro na leitura MAIS o
	 * arquivo inteiro na escrita. Com `patch`, custa o tamanho do trecho — na
	 * prática duas ordens de grandeza a menos.
	 *
	 * A disciplina que faz isso ser seguro: **o trecho procurado precisa ser
	 * único**. Substituição que casa em vários lugares sem o autor saber é a
	 * forma clássica de estragar um arquivo achando que se fez uma correção
	 * cirúrgica. Quem quiser trocar todas as ocorrências pede `all: true` por
	 * escrito.
	 */
	private static function register_patch(): void {
		wp_register_ability(
			'files/patch',
			array(
				'label'               => 'Patch Server File',
				'description'         => 'Substitui um trecho dentro de um arquivo, sem reenviar o arquivo inteiro. Muito mais barato que files/write para edições pontuais. O trecho procurado precisa ser único, a menos que all=true. Params: path (required), find (required), replace (required), all, regex, expected_sha256, backup.',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path'            => array(
							'type'        => 'string',
							'description' => 'Caminho absoluto (ex.: /home/usuario/site/arquivo.txt) ou relativo à raiz do WordPress.',
						),
						'find'            => array(
							'type'        => 'string',
							'description' => 'Trecho a procurar. Inclua contexto suficiente para ser único no arquivo.',
						),
						'replace'         => array(
							'type'        => 'string',
							'description' => 'Texto que entra no lugar. String vazia remove o trecho.',
						),
						'all'             => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Substituir todas as ocorrências. Sem isto, mais de uma ocorrência é recusada.',
						),
						'regex'           => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Tratar find como expressão regular (PCRE, sem delimitadores).',
						),
						'expected_sha256' => array(
							'type'        => 'string',
							'description' => 'SHA-256 do conteúdo atual. Se informado e não bater, a edição é abortada.',
						),
						'backup'          => array(
							'type'    => 'boolean',
							'default' => true,
						),
					),
					'required'             => array( 'path', 'find', 'replace' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'      => array( 'type' => 'boolean' ),
						'message'      => array( 'type' => 'string' ),
						'path'         => array( 'type' => 'string' ),
						'replacements' => array( 'type' => 'integer' ),
						'bytes'        => array( 'type' => 'integer' ),
						'sha256'       => array( 'type' => 'string' ),
						'backup_id'    => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['path'] ) || ! isset( $input['find'] ) || ! isset( $input['replace'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetros obrigatórios: path, find e replace.', 'wp-mcp-fator3' ) );
					}

					if ( '' === (string) $input['find'] ) {
						return array( 'success' => false, 'message' => esc_html__( 'O parâmetro find não pode ser vazio.', 'wp-mcp-fator3' ) );
					}

					$path = PathGuard::resolve( (string) $input['path'], true );
					if ( is_wp_error( $path ) ) {
						return self::fail( $path );
					}

					$ext_ok = PathGuard::check_extension( $path );
					if ( is_wp_error( $ext_ok ) ) {
						return self::fail( $ext_ok );
					}

					if ( ! is_file( $path ) || ! is_readable( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Arquivo não encontrado ou sem permissão de leitura.', 'wp-mcp-fator3' ) );
					}

					if ( filesize( $path ) > PathGuard::max_bytes() ) {
						return array( 'success' => false, 'message' => 'Arquivo excede o limite configurado.' );
					}
					$original = file_get_contents( $path );
					if ( false === $original ) {
						return array( 'success' => false, 'message' => esc_html__( 'Falha ao ler o arquivo.', 'wp-mcp-fator3' ) );
					}

					if ( ! empty( $input['expected_sha256'] ) ) {
						$actual = hash( 'sha256', $original );
						if ( ! hash_equals( $actual, strtolower( (string) $input['expected_sha256'] ) ) ) {
							return array(
								'success' => false,
								'message' => esc_html__( 'O arquivo mudou desde a última leitura. Leia de novo antes de editar.', 'wp-mcp-fator3' ),
								'sha256'  => $actual,
							);
						}
					}

					$find    = (string) $input['find'];
					$replace = (string) $input['replace'];
					$all     = ! empty( $input['all'] );
					$regex   = ! empty( $input['regex'] );
					$pattern = '/' . str_replace( '/', '\/', $find ) . '/';

					// Conta antes de substituir. Zero ocorrências é ERRO, não
					// sucesso silencioso: quem pediu a edição precisa saber que
					// ela não aconteceu, senão segue confiando num arquivo que
					// não mudou.
					if ( $regex ) {
						// phpcs:ignore Generic.PHP.NoSilencedErrors -- padrão inválido é erro do chamador, tratado na linha seguinte.
						$count = @preg_match_all( $pattern, $original );
						if ( false === $count ) {
							return array( 'success' => false, 'message' => esc_html__( 'Expressão regular inválida.', 'wp-mcp-fator3' ) );
						}
					} else {
						$count = substr_count( $original, $find );
					}

					if ( 0 === $count ) {
						return array(
							'success'      => false,
							'message'      => esc_html__( 'O trecho procurado não existe no arquivo. Nada foi alterado — confira o texto exato, inclusive espaços e quebras de linha.', 'wp-mcp-fator3' ),
							'replacements' => 0,
						);
					}

					if ( $count > 1 && ! $all ) {
						return array(
							'success'      => false,
							'message'      => esc_html(
								sprintf(
									/* translators: %d: número de ocorrências. */
									__( 'O trecho aparece %d vezes no arquivo. Acrescente contexto para torná-lo único, ou passe all=true se a intenção for trocar todas.', 'wp-mcp-fator3' ),
									$count
								)
							),
							'replacements' => 0,
						);
					}

					if ( $regex ) {
						$novo = preg_replace( $pattern, $replace, $original, $all ? -1 : 1 );
						if ( null === $novo ) {
							return array( 'success' => false, 'message' => esc_html__( 'Falha ao aplicar a expressão regular.', 'wp-mcp-fator3' ) );
						}
					} else {
						$novo = $all
							? str_replace( $find, $replace, $original )
							: self::replace_first( $original, $find, $replace );
					}

					if ( $novo === $original ) {
						return array(
							'success'      => false,
							'message'      => esc_html__( 'A substituição não mudou nada — find e replace produzem o mesmo texto.', 'wp-mcp-fator3' ),
							'replacements' => 0,
						);
					}

					if ( strlen( $novo ) > PathGuard::max_bytes() ) {
						return array(
							'success' => false,
							'message' => esc_html(
								sprintf(
									/* translators: %s: limite. */
									__( 'O resultado passaria do limite deste canal (%s).', 'wp-mcp-fator3' ),
									size_format( PathGuard::max_bytes() )
								)
							),
						);
					}

					// A sintaxe conferida é a do RESULTADO. Um patch pequeno e
					// aparentemente inocente pode desbalancear uma chave.
					if ( 'php' === strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ) {
						$syntax = PathGuard::check_php_syntax( $novo );
						if ( is_wp_error( $syntax ) ) {
							return self::fail( $syntax );
						}
					}

					if ( ! is_writable( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'O arquivo não tem permissão de escrita.', 'wp-mcp-fator3' ) );
					}

					$backup_id = '';
					if ( ! isset( $input['backup'] ) || ! empty( $input['backup'] ) ) {
						$backup_id = self::make_backup( $path );
						if ( is_wp_error( $backup_id ) ) {
							return self::fail( $backup_id );
						}
					}

					$written = self::atomic_write( $path, $novo );
					if ( is_wp_error( $written ) ) {
						return self::fail( $written );
					}

					$aplicadas = $all ? $count : 1;
					$relative  = PathGuard::to_relative( $path );

					PathGuard::audit(
						'patch',
						$relative,
						array(
							'replacements' => $aplicadas,
							'bytes'        => strlen( $novo ),
							'backup_id'    => $backup_id,
						)
					);

					return array(
						'success'      => true,
						'message'      => esc_html(
							sprintf(
								/* translators: 1: substituições, 2: id do backup. */
								_n( '%1$d substituição aplicada. Backup: %2$s', '%1$d substituições aplicadas. Backup: %2$s', $aplicadas, 'wp-mcp-fator3' ),
								$aplicadas,
								'' !== $backup_id ? $backup_id : '—'
							)
						),
						'path'         => $relative,
						'replacements' => $aplicadas,
						'bytes'        => strlen( $novo ),
						'sha256'       => hash( 'sha256', $novo ),
						'backup_id'    => $backup_id,
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
                    'fator3' => array('owned'=>true, 'provider'=>'wp-mcp-fator3', 'version'=>F3_MCP_FILES_VERSION),
					'annotations' => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/** Substitui apenas a primeira ocorrência literal. */
	private static function replace_first( string $haystack, string $find, string $replace ): string {
		$pos = strpos( $haystack, $find );
		if ( false === $pos ) {
			return $haystack;
		}
		return substr_replace( $haystack, $replace, $pos, strlen( $find ) );
	}

	/**
	 * Registra `files/selftest`.
	 */
	private static function register_selftest(): void {
		wp_register_ability(
			'files/selftest',
			array(
				'label'               => 'Self-Test Server File Channel',
				'description'         => 'Testa sintaxe PHP, permissões, kill-switch, confinamento opcional e ida/volta de backup no servidor. Cria arquivos temporários próprios e os remove ao terminar. Exige canal aberto. Sem parâmetros.',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'passed'  => array( 'type' => 'integer' ),
						'failed'  => array( 'type' => 'integer' ),
						'checks'  => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					if ( ! PathGuard::can_edit() ) {
						return array(
							'success' => false,
							'message' => esc_html__( 'Permissão insuficiente: são exigidas as capacidades edit_themes e manage_options.', 'wp-mcp-fator3' ),
						);
					}

					// O teste de ida/volta exige que o canal esteja aberto.
					$report = SelfTest::run();
					PathGuard::audit( 'selftest', '-', array( 'passed' => $report['passed'], 'failed' => $report['failed'] ) );

					return $report;
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
                    'fator3' => array('owned'=>true, 'provider'=>'wp-mcp-fator3', 'version'=>F3_MCP_FILES_VERSION),
					'annotations' => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/** Remove only the named empty directory; rmdir enforces emptiness again. */
	private static function remove_empty_directory( string $requested, array $input ): array {
		if ( isset( $input['expected_sha256'] ) && '' !== (string) $input['expected_sha256'] ) {
			return array( 'success' => false, 'message' => 'expected_sha256 se aplica a arquivos; não pode ser usado com empty_dir=true.' );
		}
		$path = PathGuard::rmdir_path( $requested );
		if ( is_wp_error( $path ) ) {
			return self::fail( $path );
		}
		if ( ! is_dir( $path ) ) {
			return array( 'success' => false, 'message' => 'empty_dir=true exige um diretório existente. Arquivos não são apagados nesse modo.' );
		}
		$handle = @opendir( $path );
		if ( false === $handle ) {
			return array( 'success' => false, 'message' => 'Não foi possível verificar o conteúdo do diretório. Verifique as permissões.' );
		}
		try {
			while ( false !== ( $entry = readdir( $handle ) ) ) {
				if ( '.' !== $entry && '..' !== $entry ) {
					return array( 'success' => false, 'message' => 'O diretório não está vazio. Remova seu conteúdo explicitamente antes de usar empty_dir=true.' );
				}
			}
		} finally {
			closedir( $handle );
		}

		$relative = PathGuard::to_relative( realpath( $path ) ?: $path );
		// Use the validated entry, not its canonical target. Never recurse.
		// If a file arrives after the check above, native rmdir still refuses.
		if ( ! @rmdir( $path ) ) {
			return array( 'success' => false, 'message' => 'Falha ao remover o diretório. Verifique as permissões e se a pasta continua vazia.' );
		}
		clearstatcache( true, $path );
		PathGuard::audit( 'rmdir', $relative, array( 'backup_id' => '' ) );
		return array(
			'success'   => true,
			'message'   => 'Diretório vazio removido. Esta operação não gera backup por files/restore.',
			'path'      => $relative,
			'backup_id' => '',
		);
	}

	/**
	 * Registra `files/delete` e `files/fetch`.
	 *
	 * Separado de register() só para manter os métodos legíveis.
	 */
	private static function register_transfer(): void {

		// =====================================================================
		// FILES — Delete
		// =====================================================================
		wp_register_ability(
			'files/delete',
			array(
				'label'               => 'Delete Server File or Empty Directory',
				'description'         => 'Apaga um arquivo alcançável pelo PHP, com backup por padrão e confinamento opcional. Para rmdir de uma pasta vazia, informe empty_dir=true: recusa arquivos, links simbólicos e pastas com qualquer conteúdo, inclusive oculto ou subpastas; não há remoção recursiva. backup e expected_sha256 são opções de arquivos; pastas vazias não geram backup. Params: path (required), empty_dir (opcional, padrão false), expected_sha256, backup.',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path'            => array(
							'type'        => 'string',
							'description' => 'Caminho absoluto (ex.: /home/usuario/site/arquivo.txt) ou relativo à raiz do WordPress.',
						),
						'expected_sha256' => array(
							'type'        => 'string',
							'description' => 'SHA-256 do conteúdo atual do arquivo. Se informado e não bater, a exclusão é abortada. Não usar com empty_dir=true.',
						),
						'backup'          => array(
							'type'        => 'boolean',
							'default'     => true,
							'description' => 'Guardar cópia do arquivo antes de apagar. Aplica-se apenas a arquivos; diretórios vazios não geram backup.',
						),
						'empty_dir'       => array(
							'type'        => 'boolean',
							'description' => 'Remove exclusivamente um diretório vazio usando rmdir. Não apaga arquivos nem conteúdo dentro de pastas. Padrão false mantém o modo de arquivos.',
						),
					),
					'required'             => array( 'path' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'   => array( 'type' => 'boolean' ),
						'message'   => array( 'type' => 'string' ),
						'path'      => array( 'type' => 'string' ),
						'backup_id' => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['path'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetro obrigatório ausente: path', 'wp-mcp-fator3' ) );
					}

					if ( array_key_exists( 'empty_dir', $input ) && ! is_bool( $input['empty_dir'] ) ) {
						return array( 'success' => false, 'message' => 'empty_dir deve ser booleano.' );
					}
					if ( true === ( $input['empty_dir'] ?? false ) ) {
						return self::remove_empty_directory( (string) $input['path'], $input );
					}

					$path = PathGuard::resolve( (string) $input['path'], true );
					if ( is_wp_error( $path ) ) {
						return self::fail( $path );
					}

					$ext_ok = PathGuard::check_extension( $path );
					if ( is_wp_error( $ext_ok ) ) {
						return self::fail( $ext_ok );
					}

					// The legacy mode only removes files. Directories require opt-in.
					if ( is_dir( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Para remover um diretório vazio, informe empty_dir=true. Pastas com conteúdo não são removidas.', 'wp-mcp-fator3' ) );
					}

					if ( ! is_file( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Arquivo não encontrado.', 'wp-mcp-fator3' ) );
					}

					if ( ! empty( $input['expected_sha256'] ) ) {
						$current = file_get_contents( $path );
						$actual  = hash( 'sha256', false === $current ? '' : $current );
						if ( ! hash_equals( $actual, strtolower( (string) $input['expected_sha256'] ) ) ) {
							return array(
								'success' => false,
								'message' => esc_html__( 'O arquivo mudou desde a última leitura. Leia de novo antes de apagar.', 'wp-mcp-fator3' ),
							);
						}
					}

					$backup_id = '';
					if ( ! isset( $input['backup'] ) || ! empty( $input['backup'] ) ) {
						$backup_id = self::make_backup( $path );
						if ( is_wp_error( $backup_id ) ) {
							return self::fail( $backup_id );
						}
					}

					// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
					$deleted=Recovery::file($path,null,static fn()=>@unlink($path));
                    if(is_wp_error($deleted))return Result::error($deleted);
                    if ( ! $deleted ) {
						return array( 'success' => false, 'message' => esc_html__( 'Falha ao apagar o arquivo (verifique as permissões).', 'wp-mcp-fator3' ) );
					}

					if ( function_exists( 'opcache_invalidate' ) ) {
						@opcache_invalidate( $path, true );
					}

					$relative = PathGuard::to_relative( $path );
					PathGuard::audit( 'delete', $relative, array( 'backup_id' => $backup_id ) );

					return array(
						'success'   => true,
						'message'   => esc_html(
							$backup_id
								? __( 'Arquivo apagado. Backup guardado; use files/restore para trazer de volta.', 'wp-mcp-fator3' )
								: __( 'Arquivo apagado sem backup — esta exclusão não é reversível por este canal.', 'wp-mcp-fator3' )
						),
						'path'      => $relative,
						'backup_id' => $backup_id,
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
                    'fator3' => array('owned'=>true, 'provider'=>'wp-mcp-fator3', 'version'=>F3_MCP_FILES_VERSION),
					'annotations' => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);

		// =====================================================================
		// FILES — Fetch (o servidor baixa; o agente não transporta os bytes)
		// =====================================================================
		wp_register_ability(
			'files/fetch',
			array(
				'label'               => 'Fetch Server File From URL',
				'description'         => 'Baixa um arquivo de uma URL pública direto para o servidor, sem passar o conteúdo pela conversa. Use para imagens, fontes e arquivos grandes. Params: url (required), path (required), overwrite (opcional), create_dirs (opcional), backup (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'url'         => array(
							'type'        => 'string',
							'description' => 'URL pública http/https do arquivo de origem.',
						),
						'path'        => array(
							'type'        => 'string',
							'description' => 'Destino absoluto ou relativo a ABSPATH.',
						),
						'overwrite'   => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Permitir substituir um arquivo existente.',
						),
						'create_dirs' => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Criar os diretórios que faltarem no caminho de destino.',
						),
						'backup'      => array(
							'type'        => 'boolean',
							'default'     => true,
							'description' => 'Guardar cópia do conteúdo anterior ao substituir.',
						),
					),
					'required'             => array( 'url', 'path' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'   => array( 'type' => 'boolean' ),
						'message'   => array( 'type' => 'string' ),
						'path'      => array( 'type' => 'string' ),
						'bytes'     => array( 'type' => 'integer' ),
						'sha256'    => array( 'type' => 'string' ),
						'source'    => array( 'type' => 'string' ),
						'backup_id' => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['url'] ) || empty( $input['path'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetros obrigatórios: url e path', 'wp-mcp-fator3' ) );
					}

					if ( ! empty( $input['create_dirs'] ) ) {
						$prepared = PathGuard::prepare_parent( (string) $input['path'] );
						if ( is_wp_error( $prepared ) ) {
							return self::fail( $prepared );
						}
					}

					// O destino é validado ANTES de sair baixando: não faz
					// sentido buscar megabytes para descobrir depois que o
					// caminho era proibido.
					$path = PathGuard::resolve( (string) $input['path'], true );
					if ( is_wp_error( $path ) ) {
						return self::fail( $path );
					}

					$ext_ok = PathGuard::check_extension( $path );
					if ( is_wp_error( $ext_ok ) ) {
						return self::fail( $ext_ok );
					}

					$exists = is_file( $path );
					if ( $exists && empty( $input['overwrite'] ) ) {
						return array(
							'success' => false,
							'message' => esc_html__( 'O arquivo já existe. Passe overwrite=true para substituir.', 'wp-mcp-fator3' ),
						);
					}

					$result = Http::fetch( (string) $input['url'], PathGuard::max_fetch_bytes() );
					if ( is_wp_error( $result ) ) {
						return self::fail( $result );
					}

					$content = $result['body'];

					// Conteúdo vindo de fora passa pelas mesmas travas de
					// conteúdo gerado aqui — inclusive a de sintaxe.
					if ( 'php' === strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ) {
						$syntax = PathGuard::check_php_syntax( $content );
						if ( is_wp_error( $syntax ) ) {
							return self::fail( $syntax );
						}
					}

					$backup_id = '';
					if ( $exists && ( ! isset( $input['backup'] ) || ! empty( $input['backup'] ) ) ) {
						$backup_id = self::make_backup( $path );
						if ( is_wp_error( $backup_id ) ) {
							return self::fail( $backup_id );
						}
					}

					$written = self::atomic_write( $path, $content );
					if ( is_wp_error( $written ) ) {
						return self::fail( $written );
					}

					$relative = PathGuard::to_relative( $path );
					PathGuard::audit(
						'fetch',
						$relative,
						array(
							'bytes'  => $result['bytes'],
							'source' => $result['url_final'],
						)
					);

					return array(
						'success'   => true,
						'message'   => esc_html(
							sprintf(
								/* translators: %s: tamanho baixado. */
								__( 'Baixado e gravado (%s).', 'wp-mcp-fator3' ),
								size_format( $result['bytes'] )
							)
						),
						'path'      => $relative,
						'bytes'     => $result['bytes'],
						'sha256'    => hash( 'sha256', $content ),
						'source'    => $result['url_final'],
						'backup_id' => $backup_id,
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
                    'fator3' => array('owned'=>true, 'provider'=>'wp-mcp-fator3', 'version'=>F3_MCP_FILES_VERSION),
					'annotations' => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => true,
					),
				),
			)
		);
	}

	/**
	 * Varre um diretório, respeitando raízes e profundidade.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function scan( string $dir, bool $recursive, int $max_depth, int $depth ): array {
		$out   = array();
		$items = @scandir( $dir );

		if ( false === $items ) {
			return $out;
		}

		$denied = array_map( 'strtolower', PathGuard::denied_basenames() );

		foreach ( $items as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}
			if ( in_array( strtolower( $item ), $denied, true ) ) {
				continue;
			}

			$full = $dir . '/' . $item;
			$resolved = PathGuard::resolve( $full, false );
			if ( is_wp_error( $resolved ) ) { continue; }
			// Do not recurse through directory symlinks (cycles, duplicate trees).

			$is_dir = is_dir( $full );

			$out[] = array(
				'name'     => $item,
				'path'     => PathGuard::to_relative( $full ),
				'type'     => $is_dir ? 'dir' : 'file',
				'size'     => $is_dir ? null : (int) filesize( $full ),
				'modified' => gmdate( 'c', (int) filemtime( $full ) ),
				'writable' => is_writable( $full ),
			);

			if ( $is_dir && ! is_link( $full ) && $recursive && $depth + 1 < $max_depth ) {
				$out = array_merge( $out, self::scan( $full, true, $max_depth, $depth + 1 ) );
			}
		}

		return $out;
	}

	/**
	 * Guarda o conteúdo atual do arquivo antes de sobrescrever.
	 *
	 * @return string|\WP_Error Identificador do backup.
	 */
	private static function make_backup( string $path ) {
		return Backups::create_file( $path );
	}

	/**
	 * Escrita atômica: grava num temporário e renomeia por cima.
	 *
	 * Evita deixar um functions.php pela metade se o processo morrer no meio
	 * da escrita. Preserva as permissões do arquivo original — rename() herda
	 * as do temporário, o que alargaria silenciosamente um arquivo restrito.
	 *
	 * @return true|\WP_Error
	 */
    /** Copy a validated non-PHP staging file without materializing the payload. */
    public static function atomic_copy(string $path,string $source,string $sha256) {
        $temp=$path.'.f3-'.bin2hex(random_bytes(8)).'.tmp';$in=null;$out=null;
        try {
            $resolved=PathGuard::resolve(PathGuard::to_relative($path),true);if(is_wp_error($resolved)||$resolved!==$path||is_link($path))throw new \RuntimeException('restore_path_changed');
            $free=@disk_free_space(dirname($path));if($free!==false&&$free<filesize($source)+2097152)throw new \RuntimeException('restore_disk_space');
            $in=fopen($source,'rb');$out=fopen($temp,'xb');if(!$in||!$out)throw new \RuntimeException('restore_stage_failed');chmod($temp,0600);
            while(!feof($in)){$chunk=fread($in,BackupStream::CHUNK);if($chunk===false)throw new \RuntimeException('restore_read_failed');BackupStream::write($out,$chunk);}
            if(!fflush($out)||function_exists('fsync')&&!fsync($out))throw new \RuntimeException('restore_flush_failed');fclose($out);$out=null;
            if(!hash_equals($sha256,(string)hash_file('sha256',$temp)))throw new \RuntimeException('restore_hash_failed');
            $resolved=PathGuard::resolve(PathGuard::to_relative($path),true);if(is_wp_error($resolved)||$resolved!==$path||is_link($path))throw new \RuntimeException('restore_path_changed');
            chmod($temp,is_file($path)?(fileperms($path)&0777):(defined('FS_CHMOD_FILE')?FS_CHMOD_FILE:0644));
            if(!rename($temp,$path))throw new \RuntimeException('restore_commit_failed');return true;
        }catch(\Throwable $e){return new \WP_Error('restore_failed',$e->getMessage());}
        finally{if(is_resource($in))fclose($in);if(is_resource($out))fclose($out);if(is_file($temp))unlink($temp);}
    }
	public static function atomic_write( string $path, string $content ) {
        return Recovery::file($path,$content,static fn()=>self::atomic_write_native($path,$content));
    }
    private static function atomic_write_native( string $path, string $content ) {
		$temp = $path . '.f3-' . bin2hex( random_bytes( 6 ) ) . '.tmp';

		$cleanup = static function () use ( $temp ) {
			if ( is_file( $temp ) ) {
				@unlink( $temp );
			}
		};
		add_action( 'shutdown', $cleanup );

		if ( strlen( $content ) !== file_put_contents( $temp, $content, LOCK_EX ) ) {
			@unlink( $temp );
			return new \WP_Error( 'f3_files_stage', __( 'Falha ao preparar a gravação.', 'wp-mcp-fator3' ) );
		}

		if ( is_file( $path ) ) {
			$perms = @fileperms( $path );
			if ( false !== $perms ) {
				@chmod( $temp, $perms & 0777 );
			}
		} else {
			@chmod( $temp, defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : 0644 );
		}

		if ( ! @rename( $temp, $path ) ) {
			@unlink( $temp );
			return new \WP_Error( 'f3_files_rename', __( 'Falha ao gravar o arquivo.', 'wp-mcp-fator3' ) );
		}

		if ( function_exists( 'opcache_invalidate' ) ) {
			@opcache_invalidate( $path, true );
		}

		return true;
	}
}
