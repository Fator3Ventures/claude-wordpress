<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
final class Api {
    public static function writes(string $op): bool {return in_array($op,['save-connection','validate-connection','create-job','run-job','control-job','save-schedule','export','save-grant','lead-create-subscription','lead-delete-subscription'],true);}
    public static function adminOnly(string $op): bool {return in_array($op,['save-connection','validate-connection','list-accounts','save-schedule','list-schedules','save-grant','list-grants','audit'],true)||str_starts_with($op,'lead-');}
    public static function capabilities(): array {
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'contract'=>'social-reporting/1.0.0','channels'=>Config::CHANNELS,'reports'=>Adapter::reports(),'independent'=>true,'mcp_optional'=>true,'api_version_default'=>Config::API_VERSION,'remote_homologation'=>'requires_authorized_credentials','exports'=>['csv','json'],'commercial_ingestion'=>false,'local_sdk'=>Config::KEY==='f3_linkedin'?PublicApi::capabilities():null];
    }
    public static function dispatch(string $op,array $i=[],bool $channel=false): array {
        $result=Result::run(static function()use($op,$i,$channel){
            Access::human();Schemas::validate($op,$i);if(self::adminOnly($op))Access::admin();
            if($channel&&class_exists('\\Fator3\\McpFiles\\AuthorizationPolicy')){$check=\Fator3\McpFiles\AuthorizationPolicy::check(Config::PREFIX.'/'.$op,$i,!self::writes($op));if($check!==true)throw new Fault('not_authorized','Política do transporte recusou esta habilidade.');}
            Http::budget();
            if(str_starts_with($op,'lead-')){
                if($op==='lead-discover-forms'){$c=Connections::get($i['connection_id']);Access::connection($c,'leads',$i['account_id']);Connections::usable($c);$start=$i['offset']??0;$r=Http::request($c,'leadForms',['q'=>'owner','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:'.$i['account_id']],'start'=>$start,'count'=>50])['body'];$rows=Adapter::elements($r);foreach($rows as $row)if(($row['owner']['sponsoredAccount']??'')!=='urn:li:sponsoredAccount:'.$i['account_id'])throw new Fault('upstream_invalid','Proprietário divergente.');return ['forms'=>$rows,'next_offset'=>Adapter::more($r,$start,count($rows),50)?$start+count($rows):null,'selection_required'=>true];}
                $method=str_replace('-','_',substr($op,5));$r=PublicApi::lead_reader('')->$method($i);if(!$r['success'])throw new Fault($r['code'],$r['message'],$r['details']);return $r['data'];
            }
            return match($op){
                'capabilities'=>self::capabilities(),
                'status'=>['provider'=>Config::SLUG,'version'=>Config::VERSION,'storage_ready'=>Store::ready(),'crypto_ready'=>Crypto::available(),'connection_count'=>count(self::connections()),'mcp_installed'=>class_exists('\\Fator3\\McpFiles\\ExtensionContract'),'abilities_available'=>function_exists('wp_register_ability'),'cron'=>['next'=>wp_next_scheduled(Config::KEY.'_worker')?:null,'last'=>get_option(Config::KEY.'_last_worker',null),'traffic_required'=>!(defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON)],'audit_health'=>get_option(Config::KEY.'_audit_health','unknown')],
                'selftest'=>SelfTest::run(),
                'configuration-schema'=>['contract'=>'social-configuration/1.0.0','schema'=>Schemas::all()['save-connection'],'credential_input'=>'manual_token','empty_secret_keeps_existing'=>true,'scope_empty_means_none'=>true,'revision_required'=>true],
                'contracts'=>['input'=>Schemas::all(),'output'=>['envelope'=>['success'=>'boolean','code'=>'string','data'=>'object on success; null on failure','error_code'=>'stable failure code','conflict'=>'true for revision_conflict'],'report'=>'social-reporting/1.0.0'],'capabilities'=>self::capabilities()],
                'documentation'=>self::documentation($i['document']??'README.md'),
                'list-connections'=>['connections'=>self::connections()],
                'audit'=>Audit::list($i),
                'save-connection'=>Connections::save($i),
                'validate-connection'=>Query::validate($i),
                'list-accounts'=>Query::accounts($i),
                'list-fields'=>['report'=>$i['report'],'fields'=>Adapter::fields($i['report'])],
                'query'=>Query::execute($i),
                'create-job'=>Jobs::create($i),
                'list-jobs'=>Jobs::list($i),
                'job-status'=>Jobs::status($i['job_id']),
                'run-job'=>Jobs::run($i['job_id']),
                'control-job'=>Jobs::control($i),
                'job-results'=>Jobs::results($i),
                'save-schedule'=>Schedules::save($i),
                'list-schedules'=>['schedules'=>Schedules::list()],
                'export'=>Export::create($i),
                'export-read'=>Export::read($i),
                'save-grant'=>PublicApi::grant($i),
                'list-grants'=>['grants'=>PublicApi::grants(),'consumers'=>PublicApi::capabilities()['consumers']],
                default=>throw new Fault('unsupported','Operação não implementada.')
            };
        });
        if(isset($result['data'])&&strlen(Util::json($result['data']))>900000)$result=Result::fail(new Fault('response_limit','Resposta excedeu o orçamento.'));
        Audit::record($op,$i,$result,null,$channel?'ability':'rest_or_local');
        return $result;
    }
    private static function connections(): array {return array_values(array_filter(Connections::list(),static fn($c)=>current_user_can('manage_options')||in_array(get_current_user_id(),$c['users'],true)));}
    private static function documentation(string $name): array {$path=Config::DIR.'docs/'.$name;if(!is_file($path))throw new Fault('not_found','Documento não disponível neste pacote.');return ['document'=>$name,'content'=>file_get_contents($path)];}
    public static function abilities(): void {
        if(!function_exists('wp_register_ability'))return;
        foreach(Schemas::all() as $op=>$schema){$write=self::writes($op);wp_register_ability(Config::PREFIX.'/'.$op,['label'=>Config::NAME.' — '.$op,'description'=>self::description($op),'category'=>Config::PREFIX,'input_schema'=>$schema,'output_schema'=>['type'=>'object','properties'=>['success'=>['type'=>'boolean'],'code'=>['type'=>'string'],'data'=>['type'=>['object','null']]]],'permission_callback'=>static fn()=>is_user_logged_in()&&current_user_can(self::adminOnly($op)?'manage_options':'read'),'execute_callback'=>static fn($i=[])=>self::dispatch($op,(array)$i,true),'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>!$write,'destructive'=>in_array($op,['lead-delete-subscription','save-connection','save-grant'],true),'idempotent'=>!$write],'fator3'=>['provider'=>Config::SLUG,'version'=>Config::VERSION,'policy_contract'=>1,'mode'=>$write?'write':'read','remote_effect'=>str_starts_with($op,'lead-')&&$write?'write':(in_array($op,['query','list-accounts','validate-connection','run-job'],true)||str_starts_with($op,'lead-')?'read':'none'),'local_effect'=>$write?'write':'none','execution_contract_version'=>'1.0.0']]]);}
    }
    private static function description(string $op): string {
        return match($op){'query'=>'Consulta uma página. Preserve seleção e next_cursor; complete e ausência de métricas não equivalem a acesso integral.','save-connection'=>'Salva conexão cifrada com expected_revision. Token vazio mantém o atual. Ativos vazios não concedem acesso.','create-job'=>'Admite coleta persistente de leitura; use run-job/status/resultados. Idempotência vinculada à identidade.','lead-create-subscription'=>'Cria assinatura exclusivamente do consumidor/conta/formulário. Resultado incerto não repete POST.','lead-delete-subscription'=>'Remove somente assinatura com autoria local confirmada e contexto vigente.','selftest'=>'Diagnóstico local, sem consultas externas. Não homologa credenciais ou escopos remotos.',default=>'Operação '.$op.' do plugin '.Config::NAME.'. Consulte contracts e documentation para schema e limites.'};
    }
    public static function routes(): void {
        foreach(Schemas::all() as $op=>$schema)register_rest_route(Config::REST,'/'.$op,['methods'=>'POST','permission_callback'=>static fn()=>current_user_can(self::adminOnly($op)?'manage_options':'read'),'callback'=>static function($r)use($op){$input=$r->get_json_params();if(!is_array($input))$input=[];$v=self::dispatch($op,$input);$response=new \WP_REST_Response($v,200);$response->header('Cache-Control','private, no-store');return $response;}]);
    }
}
final class SelfTest {
    public static function run(): array {
        $checks=[];$test=static function($name,$fn)use(&$checks){try{$ok=$fn();$checks[]=['name'=>$name,'state'=>$ok?'ok':'failed'];}catch(\Throwable $e){$checks[]=['name'=>$name,'state'=>'failed'];}};
        $test('storage',static fn()=>Store::ready());$test('authenticated_encryption',static fn()=>Crypto::open(Crypto::seal('f3-selftest'))==='f3-selftest');
        $test('cursor_roundtrip',static fn()=>Util::uncursor(Util::cursor(['expires'=>time()+30,'value'=>'x']))['value']==='x');
        $test('endpoint_allowlist',static fn()=>!Adapter::allowed('https://example.com/','GET')&&!Adapter::allowed('../secrets','GET'));
        $test('closed_schema',static function(){try{Schemas::validate('status',['unknown'=>1]);return false;}catch(Fault $e){return $e->reason==='invalid_input';}});
        $test('empty_scope_denied',static function(){try{Access::asset(['assets'=>[]],Config::CHANNELS[0],'123');return false;}catch(Fault $e){return $e->reason==='asset_access_denied';}});
        $test('csv_formula_protection',static fn()=>Export::safeCell('=1+1')==="'=1+1");
        $test('schema_catalog',static fn()=>count(Schemas::all())>=20);
        $failed=count(array_filter($checks,static fn($x)=>$x['state']!=='ok'));
        if($failed)throw new Fault('selftest_failed','Diagnóstico local reprovado.',['checks'=>$checks]);
        return ['execution_success'=>true,'local_checks_ok'=>true,'checks'=>$checks,'external_checks'=>'not_run','remote_homologated'=>false];
    }
}

final class Audit {
    public static function record(string $op,array $i,array &$result,?string $consumer=null,string $transport='local_sdk'): void {
        try {if(Store::ready()){Store::put('audit',wp_generate_uuid4(),['operation'=>$op,'actor'=>['type'=>$consumer?'plugin':'user','id'=>$consumer?:get_current_user_id()],'transport'=>$transport,'connection_id'=>$i['connection_id']??null,'code'=>$result['code']??'unknown','at'=>time()],0,time()+30*86400);update_option(Config::KEY.'_audit_health','ok',false);}}
        catch(\Throwable $e){$result['audit_warning']='audit_write_failed';update_option(Config::KEY.'_audit_health','failed',false);}
    }
    public static function list(array $i): array {Access::admin();$offset=$i['offset']??0;$rows=Store::list('audit',$offset,50);return ['events'=>array_map(static fn($r)=>['event_id'=>$r['key']]+$r['value'],$rows),'next_offset'=>count($rows)===50?$offset+50:null,'retention_days'=>30];}
}
