<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

final class PublicApi {
    private static array $consumers=[];
    public static function capabilities(): array {
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'contracts'=>['social-reporting/1.0.0','linkedin-lead-reader/1.0.0'],'entrypoint'=>self::class,'registration_hook'=>'f3_linkedin_register_consumers','methods'=>['register_consumer','lead_reader','capabilities'],'consumers'=>array_values(self::$consumers),'commercial_ingestion'=>false,'core_selection_required'=>true];
    }
    public static function register_consumer(array $descriptor): array {
        return Result::run(static function()use($descriptor){Util::guardKeys($descriptor,['id','label','contract']);$id=Util::id($descriptor['id']??'');if(($descriptor['contract']??'')!=='linkedin-lead-reader/1.0.0')throw new Fault('unsupported','Contrato de consumidor incompatível.');if(isset(self::$consumers[$id])){if(self::$consumers[$id]!==$descriptor)throw new Fault('consumer_conflict','Registro de consumidor divergente.');return $descriptor;}self::$consumers[$id]=$descriptor;return $descriptor;});
    }
    public static function registered(string $id): bool {return isset(self::$consumers[$id]);}
    public static function lead_reader(string $consumer): LeadReader {
        if($consumer!==''&&!self::registered($consumer))throw new Fault('consumer_unregistered','Consumidor local não registrado.');
        if($consumer==='')Access::admin();return new LeadReader($consumer);
    }
    public static function grant(array $i): array {
        Access::admin();Schemas::validate('save-grant',$i);if(!self::registered($i['consumer_id']))throw new Fault('consumer_unregistered','O consumidor deve registrar seu contrato primeiro.');
        $c=Connections::get($i['connection_id']);$forms=[];
        foreach($i['forms'] as $account=>$ids){$account=(string)$account;Access::asset($c,'leads',$account);foreach($ids as $form){Util::numeric($form);if(!in_array($form,$c['forms'][$account]??[],true))throw new Fault('asset_access_denied','Formulário não selecionado na conexão.');}$forms[$account]=array_values(array_unique($ids));}
        $key=$i['consumer_id'].':'.$c['id'];$value=['consumer_id'=>$i['consumer_id'],'connection_id'=>$c['id'],'enabled'=>$i['enabled'],'permissions'=>$i['permissions'],'forms'=>$forms,'credential_revision'=>$c['revision'],'callback_url'=>$i['callback_url']??'','configured_by'=>get_current_user_id(),'updated_at'=>time()];
        if($value['callback_url']!==''&&(!wp_http_validate_url($value['callback_url'])||wp_parse_url($value['callback_url'],PHP_URL_SCHEME)!=='https'||wp_parse_url($value['callback_url'],PHP_URL_HOST)!==wp_parse_url(home_url(),PHP_URL_HOST)))throw new Fault('invalid_input','Callback deve usar HTTPS no domínio deste site.');
        $r=Store::put('grant',$key,$value,$i['expected_revision']);return ['persisted'=>true,'grant_revision'=>$r['revision'],'grant'=>$value];
    }
    public static function grants(): array {Access::admin();$a=[];foreach(Store::list('grant',0,100) as $r)$a[]=$r['value']+['revision'=>$r['revision']];return $a;}
}
final class LeadReader {
    public const CONTRACT='linkedin-lead-reader/1.0.0';
    private string $consumer;
    public function __construct(string $consumer) {if($consumer!==''&&!PublicApi::registered($consumer))throw new Fault('consumer_unregistered','Consumidor não registrado.');$this->consumer=$consumer;}
    public function descriptor(): array {return ['contract'=>self::CONTRACT,'provider'=>Config::SLUG,'version'=>Config::VERSION,'consumer_id'=>$this->consumer,'lead_types'=>['SPONSORED'],'methods'=>['descriptor','effective_status','check_access','list_forms','get_form','read_responses','get_response','verify_challenge','verify_notification','list_subscriptions','create_subscription','delete_subscription'],'opaque_cursor_transferable'=>false,'credential_secret_export'=>false];}
    private function call(string $method,array $i,callable $fn): array {
        $result=Result::run(function()use($method,$i,$fn){Schemas::validate('lead-'.str_replace('_','-',$method),$i);$grantBefore=$this->consumer!==''?Store::get('grant',$this->consumer.':'.$i['connection_id']):null;$principal=$this->consumer===''?Access::principal():null;Http::budget(12,25);$data=['contract'=>self::CONTRACT,'consumer_id'=>$this->consumer]+$fn();if($grantBefore){$grantNow=Store::get('grant',$this->consumer.':'.$i['connection_id']);if(!$grantNow||$grantNow['revision']!==$grantBefore['revision']||!$grantNow['value']['enabled'])throw new Fault('revision_conflict','Concessão alterada durante a operação.');}if($principal)Access::checkPrincipal($principal);if(strlen(Util::json($data))>700000)throw new Fault('response_limit','Página excedeu o orçamento.');return $data;});Audit::record('lead-'.$method,$i,$result,$this->consumer?:null);return $result;
    }
    private function context(array $i,string $permission,bool $requireToken=true): array {
        $c=Connections::get($i['connection_id']);$account=Util::numeric($i['account_id']);Access::asset($c,'leads',$account);
        if($this->consumer===''){
            Access::admin();$g=['forms'=>$c['forms'],'permissions'=>['metadata','responses','verify','subscriptions'],'callback_url'=>'','credential_revision'=>$c['revision']];$gr=0;
        }else{
            if(!PublicApi::registered($this->consumer))throw new Fault('consumer_unregistered','Consumidor não está disponível.');$grant=Store::get('grant',$this->consumer.':'.$c['id']);if(!$grant||!$grant['value']['enabled'])throw new Fault('not_authorized','Consumidor sem concessão ativa.');$g=$grant['value'];$gr=$grant['revision'];
            if($g['credential_revision']!==$c['revision'])throw new Fault('revision_conflict','A credencial mudou; reconfirme a concessão do consumidor.');
        }
        if(!in_array($permission,$g['permissions'],true))throw new Fault('not_authorized','Permissão de domínio não concedida.');
        if(isset($i['credential_revision'])&&$i['credential_revision']!==$c['revision']||isset($i['grant_revision'])&&$i['grant_revision']!==$gr)throw new Fault('revision_conflict','Revisão do contrato de acesso mudou.');
        if(!$c['enabled'])throw new Fault('connection_paused','Conexão pausada.');if($requireToken)Connections::usable($c);
        $forms=array_values(array_intersect($g['forms'][$account]??[],$c['forms'][$account]??[]));
        return [$c,$g,$gr,$forms];
    }
    private function formAllowed(string $id,array $forms): void {Util::numeric($id);if(!in_array($id,$forms,true))throw new Fault('asset_access_denied','Formulário não concedido.');}
    private function binding(array $c,int $gr,array $i): string {$q=$i;unset($q['cursor']);return hash('sha256',Util::json([$this->consumer,$this->consumer===''?Access::principal():null,$c['revision'],$gr,$q]));}
    public function effective_status(array $i): array {
        return $this->call('effective_status',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'metadata',false);return ['descriptor'=>$this->descriptor(),'connection_id'=>$c['id'],'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'forms'=>$forms,'enabled'=>$c['enabled'],'token_configured'=>(bool)$c['token'],'secret_configured'=>(bool)$c['client_secret'],'expires_at'=>$c['expires_at'],'remote_access_verified'=>false];});
    }
    public function check_access(array $i): array {
        return $this->call('check_access',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'metadata');$proof=Adapter::validate($c,'leads',$i['account_id']);$checked=[];foreach(array_slice($forms,0,5) as $id){$r=$this->fetchForm($c,$i['account_id'],$id);$checked[]=['id'=>$id,'version'=>(string)$r['versionId']];}return ['proof'=>$proof,'forms_checked'=>$checked,'forms_remaining'=>max(0,count($forms)-5),'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'lead_responses_read'=>false];});
    }
    private function fetchForm(array $c,string $account,string $form): array {
        $f=Http::request($c,'leadForms/'.Util::numeric($form))['body'];
        if((string)($f['id']??'')!==$form||($f['owner']['sponsoredAccount']??'')!=='urn:li:sponsoredAccount:'.$account||!preg_match('/^[0-9]+$/D',(string)($f['versionId']??'')))throw new Fault('asset_access_denied','Formulário ou proprietário divergente.');return $f;
    }
    public function list_forms(array $i): array {
        return $this->call('list_forms',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'metadata');$binding=$this->binding($c,$gr,$i);$at=0;
            if(!empty($i['cursor'])){$cur=Util::uncursor($i['cursor']);if(($cur['binding']??'')!==$binding)throw new Fault('revision_conflict','Continuação alterada.');$at=$cur['offset'];}
            $rows=[];foreach(array_slice($forms,$at,5) as $id)$rows[]=$this->fetchForm($c,$i['account_id'],$id);$next=$at+count($rows)<count($forms)?Util::cursor(['binding'=>$binding,'offset'=>$at+count($rows),'expires'=>time()+3600]):null;
            return ['forms'=>$rows,'next_cursor'=>$next,'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'complete'=>$next===null];});
    }
    public function get_form(array $i): array {
        return $this->call('get_form',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'metadata');$this->formAllowed($i['form_id'],$forms);return ['form'=>$this->fetchForm($c,$i['account_id'],$i['form_id']),'credential_revision'=>$c['revision'],'grant_revision'=>$gr];});
    }
    public static function formVersion(string $urn): array {
        if(!preg_match('/^urn:li:versionedLeadGenForm:\(urn:li:leadGenForm:([0-9]+),\s*([0-9]+)\)$/D',$urn,$m))throw new Fault('upstream_invalid','Identidade versionada do formulário inválida.');return ['id'=>$m[1],'version'=>$m[2],'urn'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:'.$m[1].','.$m[2].')'];
    }
    private function response(array $r,string $account,array $forms,?string $form=null): array {
        $f=self::formVersion((string)($r['versionedLeadGenFormUrn']??''));$this->formAllowed($f['id'],$forms);
        if($form!==null&&$f['id']!==$form||($r['owner']['sponsoredAccount']??'')!=='urn:li:sponsoredAccount:'.$account||($r['leadType']??'')!=='SPONSORED'||!preg_match('/^[A-Za-z0-9_-]{1,150}$/D',(string)($r['id']??''))||!is_bool($r['testLead']??null))throw new Fault('upstream_invalid','Resposta fora do escopo autorizado.');
        $stamp=$r['submittedAt']??null;if((!is_string($stamp)&&!is_int($stamp))||!preg_match('/^[0-9]{13}$/D',(string)$stamp))throw new Fault('upstream_invalid','submittedAt deve preservar milissegundos.');
        return ['identity'=>['source'=>'linkedin','account_id'=>$account,'form_id'=>$f['id'],'response_id'=>(string)$r['id'],'submitted_at_ms'=>(string)$stamp],'form_version'=>$f['version'],'raw'=>$r];
    }
    public function read_responses(array $i): array {
        return $this->call('read_responses',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'responses');$this->formAllowed($i['form_id'],$forms);
            $from=$i['from_ms'];$to=$i['to_ms'];if(strcmp($from,$to)>0||(int)$to-(int)$from>31*86400000)throw new Fault('invalid_input','Janela de leads limitada a 31 dias.');
            $binding=$this->binding($c,$gr,$i);$start=0;$version=$i['form_version'];
            if(!empty($i['cursor'])){$cur=Util::uncursor($i['cursor']);if(($cur['binding']??'')!==$binding)throw new Fault('revision_conflict','Continuação fora da concessão/seleção.');$start=$cur['offset'];}
            $q=['q'=>'owner','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:'.$i['account_id']],'leadType'=>['leadType'=>'SPONSORED'],'versionedLeadGenFormUrn'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:'.$i['form_id'].','.$version.')','submittedAtTimeRange'=>['start'=>$from,'end'=>$to],'start'=>$start,'count'=>50,'limitedToTestLeads'=>$i['test_only']??false];
            $r=Http::request($c,'leadFormResponses',$q)['body'];$elements=Adapter::elements($r);if(count($elements)>50)throw new Fault('upstream_invalid','Página de leads excedeu o limite.');$rows=[];
            foreach($elements as $x){$v=$this->response($x,$i['account_id'],$forms,$i['form_id']);$stamp=$v['identity']['submitted_at_ms'];if($v['form_version']!==$version||strcmp($stamp,$from)<0||strcmp($stamp,$to)>0)throw new Fault('upstream_invalid','Resposta fora da versão/janela.');$rows[]=$v;}
            $more=Adapter::more($r,$start,count($elements),50);$next=$more?Util::cursor(['binding'=>$binding,'offset'=>$start+count($elements),'expires'=>time()+86400]):null;
            return ['responses'=>$rows,'next_cursor'=>$next,'coverage'=>['complete'=>!$more,'all_rows_guaranteed'=>null,'from_ms'=>$from,'to_ms'=>$to],'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'commercial_effects'=>false];});
    }
    public function get_response(array $i): array {
        return $this->call('get_response',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'responses');$this->formAllowed($i['form_id'],$forms);$r=Http::request($c,'leadFormResponses/'.$i['response_id'])['body'];
            if((string)($r['id']??'')!==$i['response_id'])throw new Fault('upstream_invalid','Resposta divergente.');return ['response'=>$this->response($r,$i['account_id'],$forms,$i['form_id']),'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'commercial_effects'=>false];});
    }
    public function verify_challenge(array $i): array {
        return $this->call('verify_challenge',$i,function()use($i){[$c]=$this->context($i,'verify',false);if(!$c['client_secret'])throw new Fault('not_configured','Client secret ausente.');if(isset($i['application_id'])&&$i['application_id']!==$c['application_id'])throw new Fault('asset_access_denied','App divergente.');return ['challengeCode'=>$i['challenge_code'],'challengeResponse'=>hash_hmac('sha256',$i['challenge_code'],$c['client_secret']),'credential_revision'=>$c['revision']];});
    }
    public function verify_notification(array $i): array {
        return $this->call('verify_notification',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'verify',false);if(!$c['client_secret'])throw new Fault('not_configured','Client secret ausente.');$raw=$i['raw_body'];
            if(!hash_equals(hash_hmac('sha256','hmacsha256='.$raw,$c['client_secret']),$i['signature']))throw new Fault('signature_invalid','Assinatura recusada.');
            $p=json_decode($raw,true,48,JSON_BIGINT_AS_STRING);if(!is_array($p)||($p['type']??'')!=='LEAD_ACTION'||($p['leadType']??'')!=='SPONSORED'||(is_array($p['owner']??null)?($p['owner']['sponsoredAccount']??''):($p['owner']??''))!=='urn:li:sponsoredAccount:'.$i['account_id']||!in_array($p['leadAction']??'',['CREATED','DELETED'],true))throw new Fault('notification_out_of_scope','Notificação fora do escopo.');
            $f=self::formVersion((string)($p['leadGenForm']??''));$this->formAllowed($f['id'],$forms);if(!preg_match('/^urn:li:leadGenFormResponse:([A-Za-z0-9_-]{1,150})$/D',(string)($p['leadGenFormResponse']??''),$m)||!preg_match('/^[0-9]{13}$/D',(string)($p['occurredAt']??'')))throw new Fault('upstream_invalid','Notificação sem identidade temporal válida.');
            return ['verified'=>true,'notification'=>$p,'form_id'=>$f['id'],'form_version'=>$f['version'],'response_id'=>$m[1],'occurred_at_ms'=>(string)$p['occurredAt'],'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'receipt_persisted'=>false,'consumer_must_persist_before_ack'=>true];});
    }
    public function list_subscriptions(array $i): array {
        return $this->call('list_subscriptions',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'subscriptions');$r=Http::request($c,'leadNotifications',['q'=>'owner','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:'.$i['account_id']],'leadType'=>['leadType'=>'SPONSORED'],'start'=>$i['offset']??0,'count'=>50])['body'];$rows=Adapter::elements($r);$safe=[];foreach($rows as $v){try{$f=self::formVersion((string)($v['versionedForm']??$v['versionedFormUrn']??''));}catch(Fault $e){continue;}if(in_array($f['id'],$forms,true)&&($v['owner']['sponsoredAccount']??'')==='urn:li:sponsoredAccount:'.$i['account_id'])$safe[]=$v;}$more=Adapter::more($r,$i['offset']??0,count($rows),50);return ['subscriptions'=>$safe,'next_offset'=>$more?($i['offset']??0)+count($rows):null,'ownership_not_inferred'=>true];});
    }
    private function wanted(array $i,array $g): array {
        $url=$i['callback_url'];if(!wp_http_validate_url($url)||wp_parse_url($url,PHP_URL_SCHEME)!=='https'||wp_parse_url($url,PHP_URL_HOST)!==wp_parse_url(home_url(),PHP_URL_HOST))throw new Fault('invalid_input','Callback deve usar HTTPS neste site.');
        if($this->consumer!==''&&$url!==$g['callback_url'])throw new Fault('not_authorized','Callback diferente da concessão.');
        return ['webhook'=>$url,'owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:'.$i['account_id']],'versionedForm'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:'.$i['form_id'].','.$i['form_version'].')','leadType'=>'SPONSORED'];
    }
    private static function equivalent(array $a,array $b): bool {return ($a['webhook']??'')===$b['webhook']&&($a['owner']??null)===$b['owner']&&($a['leadType']??'')==='SPONSORED'&&($a['versionedForm']??$a['versionedFormUrn']??'')===$b['versionedForm'];}
    public function create_subscription(array $i): array {
        return $this->call('create_subscription',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'subscriptions');$this->formAllowed($i['form_id'],$forms);$want=$this->wanted($i,$g);$key=hash('sha256',Util::json([$this->consumer,$c['id'],$i['idempotency_key']]));
            return Store::lock('subscriptions:'.$c['id'],function()use($i,$c,$want,$key){
                $old=Store::get('subscription',$key);if($old){if(!Util::same($old['value']['wanted'],$want))throw new Fault('idempotency_conflict','Chave de assinatura reutilizada.');$v=$old['value'];if($v['credential_revision']!==$c['revision'])throw new Fault('revision_conflict','Credencial alterada.');if($v['state']==='deleted')throw new Fault('job_terminal','Esta intenção já foi removida.');if($v['state']==='confirmed')return ['subscription_id'=>$v['remote_id'],'ownership_key'=>$key,'state'=>'confirmed','replayed'=>true];return $this->reconcile($c,$key,$old);}
                // Exhaustive bounded lookup before creation prevents silent duplication.
                $matches=$this->findSubscriptions($c,$want);if($matches)throw new Fault('subscription_exists_unowned','Assinatura equivalente já existe; não foi adotada nem modificada.',['count'=>count($matches)]);
                $v=['consumer'=>$this->consumer,'connection_id'=>$c['id'],'credential_revision'=>$c['revision'],'wanted'=>$want,'state'=>'creating','remote_id'=>null,'created_at'=>time()];$r=Store::put('subscription',$key,$v);
                try{$remote=Http::request($c,'leadNotifications',[],'POST',$want);$id=$remote['id']?:($remote['body']['id']??'');if(!preg_match('/^[0-9]+$/D',(string)$id))throw new Fault('operation_uncertain','Criação sem identificador confirmado.');$v['remote_id']=(string)$id;$v['state']='uncertain';$r=Store::put('subscription',$key,$v,$r['revision']);return $this->reconcile($c,$key,$r);
                }catch(Fault $e){$cur=Store::get('subscription',$key);$v=$cur['value'];$v['state']=in_array($e->reason,['operation_uncertain','revision_conflict','persistence_unconfirmed','upstream_error','rate_limited','budget_exhausted'],true)?'uncertain':'rejected';$v['last_code']=$e->reason;Store::put('subscription',$key,$v,$cur['revision']);throw $e;}
            });});
    }
    private function findSubscriptions(array $c,array $want): array {
        $start=0;$found=[];for($page=0;$page<8;$page++){$r=Http::request($c,'leadNotifications',['q'=>'owner','owner'=>$want['owner'],'leadType'=>['leadType'=>'SPONSORED'],'start'=>$start,'count'=>50])['body'];$rows=Adapter::elements($r);foreach($rows as $row)if(self::equivalent($row,$want))$found[]=$row;if(!Adapter::more($r,$start,count($rows),50))return $found;$start+=count($rows);}throw new Fault('coverage_incomplete','Listagem de assinaturas excedeu o orçamento; criação recusada.');
    }
    private function reconcile(array $c,string $key,array $r): array {
        $v=$r['value'];if($v['credential_revision']!==$c['revision'])throw new Fault('revision_conflict','Credencial mudou; contexto antigo requer reconciliação explícita.');if(!$v['remote_id'])throw new Fault('operation_uncertain','Criação sem ID confirmado; confira remotamente antes de outra intenção.');$found=$this->findSubscriptions($c,$v['wanted']);
        if(count($found)!==1)throw new Fault('operation_uncertain','Resultado remoto não confirmado; a criação não será repetida.',['matches'=>count($found)]);
        $id=(string)($found[0]['id']??'');if(!preg_match('/^[0-9]+$/D',$id)||$v['remote_id']!==null&&$v['remote_id']!==$id)throw new Fault('operation_uncertain','Identidade de assinatura divergente.');
        $v['remote_id']=$id;$v['state']='confirmed';Store::put('subscription',$key,$v,$r['revision']);return ['subscription_id'=>$id,'ownership_key'=>$key,'state'=>'confirmed','delivery_verified'=>false];
    }
    public function delete_subscription(array $i): array {
        return $this->call('delete_subscription',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'subscriptions');$key=$i['ownership_key'];
            return Store::lock('subscriptions:'.$c['id'],function()use($key,$c,$i,$forms){$r=Store::get('subscription',$key);if(!$r)throw new Fault('ownership_missing','Assinatura sem autoria local.');$v=$r['value'];if($v['credential_revision']!==$c['revision'])throw new Fault('revision_conflict','Credencial alterada.');if($v['consumer']!==$this->consumer||$v['connection_id']!==$c['id']||$v['wanted']['owner']['sponsoredAccount']!=='urn:li:sponsoredAccount:'.$i['account_id'])throw new Fault('not_authorized','Assinatura fora do consumidor/conta.');$f=self::formVersion($v['wanted']['versionedForm']);$this->formAllowed($f['id'],$forms);if($v['state']==='deleted')return ['state'=>'deleted','replayed'=>true];if(!$v['remote_id'])throw new Fault('operation_uncertain','Reconcilie a criação antes da remoção.');
                try{$remote=Http::request($c,'leadNotifications/'.$v['remote_id'])['body'];if(!self::equivalent($remote,$v['wanted']))throw new Fault('ownership_mismatch','Assinatura remota mudou.');}
                catch(Fault $e){if($e->reason!=='resource_not_found')throw $e;$v['state']='deleted';Store::put('subscription',$key,$v,$r['revision']);return ['state'=>'deleted','remote_absence_verified'=>true];}
                $v['state']='deleting';$r=Store::put('subscription',$key,$v,$r['revision']);Http::request($c,'leadNotifications/'.$v['remote_id'],[],'DELETE');
                try{Http::request($c,'leadNotifications/'.$v['remote_id']);throw new Fault('operation_uncertain','Remoção ainda não confirmada.');}catch(Fault $e){if($e->reason!=='resource_not_found')throw $e;}
                $v['state']='deleted';Store::put('subscription',$key,$v,$r['revision']);return ['state'=>'deleted','remote_absence_verified'=>true];
            });});
    }
}
