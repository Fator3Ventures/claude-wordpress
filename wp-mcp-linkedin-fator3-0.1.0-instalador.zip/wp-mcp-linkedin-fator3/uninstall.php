<?php
// Uninstall intentionally erases this site's integration data. Deactivation preserves it.
if(!defined('WP_UNINSTALL_PLUGIN'))exit;
global $wpdb;
$wpdb->query($wpdb->prepare('DROP TABLE IF EXISTS %i',$wpdb->prefix.'f3_linkedin_records'));
foreach(['schema','scan','last_worker','audit_health'] as $name)delete_option('f3_linkedin_'.$name);
wp_clear_scheduled_hook('f3_linkedin_worker');wp_clear_scheduled_hook('f3_linkedin_maintenance');
