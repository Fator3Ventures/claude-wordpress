# SDK PHP público — 0.1.0

## Relatórios locais

Entradas autorizadas: `Fator3\Meta\Api::dispatch(string $op, array $input = [], bool $channel = false): array` e `Fator3\LinkedIn\Api::dispatch(...)`. `channel=false` é execução local sujeita ao usuário WordPress e às permissões de domínio. Não invente usuário no cron: jobs guardam e revalidam a identidade original. Para automação sem usuário, o SDK de consumidor disponível nesta versão é especificamente o leitor Lead Sync abaixo.

`Api::capabilities(): array` descreve contratos; `Schemas::all(): array` publica as entradas fechadas. Código do consumidor não deve incluir arquivos privados, ler tabelas, usar Connections/Http/Store ou transportar segredos.

## linkedin-lead-reader/1.0.0

Produtor: `Fator3\LinkedIn\PublicApi`. Entrada estável e métodos:

```php
add_action('f3_linkedin_register_consumers', static function ($api) {
    $result = $api::register_consumer([
        'id' => 'meu-consumidor',
        'label' => 'Meu consumidor',
        'contract' => 'linkedin-lead-reader/1.0.0',
    ]);
    // Registrar código não concede acesso. Tratar success:false.
});

// Após o hook e a concessão explícita pelo administrador:
$reader = \Fator3\LinkedIn\PublicApi::lead_reader('meu-consumidor');
$status = $reader->effective_status([
    'connection_id' => 'linkedin-principal',
    'account_id' => '222',
]);
```

Não registrar automaticamente o Core por este plugin. O futuro consumidor Core deve declarar seu próprio descritor, callback e seleção comercial. Core 1.33.0 não contém esse adaptador.

- `PublicApi::capabilities(): array`: descritor, contrato, consumidores registrados.
- `PublicApi::register_consumer(array $descriptor): array`: envelope; id, label, contract; mesmo descritor é idempotente.
- `PublicApi::lead_reader(string $consumer): LeadReader`: objeto para consumidor registrado; desconhecido lança Fault. String vazia é acesso humano e exige administrador.
- `PublicApi::grant(array $input): array`: administrador; schema `save-grant`; retorno com grant_revision. O transporte recomendado é `linkedin/save-grant` ou painel.
- `LeadReader::descriptor(): array`: descritor sem rede; não é prova de autorização.
- Todos os métodos de domínio abaixo recebem `array` e retornam envelope `success/code/provider/version/data`. `data` inclui contract e consumer_id.

| Método | Entrada adicional à conexão/conta | Resultado |
|---|---|---|
| effective_status | Revisões opcionais | Presença de token/secret, formulários e revisões; remote_access_verified:false |
| check_access | Revisões opcionais | Metadados da conta e até cinco formulários; não lê leads |
| list_forms | cursor opcional | Metadados apenas dos formulários concedidos, até cinco por página |
| get_form | form_id | Formulário com versão, perguntas, consentimentos nativos |
| read_responses | form_id, form_version, from_ms, to_ms; test_only/cursor opcionais | Até 50 respostas por página; janela até 31 dias |
| get_response | form_id, response_id | Resposta individual conferida contra conta/formulário |
| verify_challenge | challenge_code; application_id opcional | challengeCode, challengeResponse HMAC SHA-256 e revisão |
| verify_notification | raw_body, signature | Verificação e identidade de notificação; nenhum recibo persistido |
| list_subscriptions | offset opcional | Até 50, filtradas pelos formulários concedidos; autoria não inferida |
| create_subscription | form_id, form_version, callback_url, idempotency_key | ID remoto, ownership_key, estado; delivery_verified:false |
| delete_subscription | ownership_key | Remoção somente da assinatura própria, com ausência remota conferida |

`credential_revision` e `grant_revision` opcionais permitem fixar explicitamente o contexto em qualquer método. A concessão já fixa a revisão vigente mesmo quando esses campos são omitidos. Callback do consumidor é uma URL HTTPS no domínio do site e deve coincidir exatamente com a declarada na concessão. Apenas SPONSORED é aceito. Outros tipos não são reinterpretados.

O consumidor deve guardar as revisões resolvidas e informar ambas nas operações subsequentes. Mudanças durante uma leitura são conferidas novamente antes de retornar. Conexão pausada, grant removido/revogado ou mudança de revisão interrompem o fluxo. Não há fallback para token/cliente Core. A execução local concedida funciona com usuário WordPress zero; registrar código não é impersonação humana.

## Identidade e webhook

Resposta preserva `raw` sem reconstruir perguntas ou consentimentos e acrescenta `identity` com source, account_id, form_id, response_id e submitted_at_ms. Milissegundos são strings de 13 dígitos; IDs remotos não são convertidos em float. Guest leads podem omitir submitter. A identidade comercial inclui o instante de submissão, não apenas response_id.

Notificação exige bytes originais e assinatura hexadecimal minúscula de 64 caracteres do header X-LI-Signature. A assinatura usa `HMAC-SHA256("hmacsha256=" + raw_body, client_secret)`. Challenge usa HMAC do challengeCode. Não recodifique JSON antes da verificação.

O produtor valida tipo, ação CREATED/DELETED, conta, formulário versionado, response URN e occurredAt em milissegundos. Não grava recebimento nem devolve ACK HTTP ao LinkedIn. O consumidor deve persistir recibo antes de confirmar, manter tombstone/deduplicação e consultar a resposta quando apropriado. Notificação não avança marco de polling.

## Assinaturas e incerteza

Criação grava intenção antes do POST. Faz busca exaustiva limitada a 400 assinaturas para recusar equivalência preexistente. Após resposta com ID, confere a assinatura na origem. Repetição da mesma chave/intenção não faz outro POST. URL igual não comprova autoria.

Timeout ou criação sem ID confirmado ficam incertos. Não há adoção automática por mera equivalência. Corrigir o contexto, conferir o app remoto e resolver a intenção antes de usar outra chave. Uma nova chave não transforma resultado desconhecido em ausente. Remoção exige ownership_key do diário, consumidor, conta, formulário e revisão iguais, consulta remota anterior e confirmação de ausência posterior.

Esta versão não entrega passagem de contexto antigo/nova credencial durante troca comercial, nem o seletor Core → plugin → Core. Esses protocolos pertencem à entrega conjunta futura com o consumidor Core. Reconciliar pendências antes de trocar credencial. A API não promete execução remota exatamente uma vez.

## Erros relevantes

`consumer_unregistered`, `not_authorized`, `connection_paused`, `not_configured`, `token_expired`, `token_rejected`, `asset_access_denied`, `signature_invalid`, `notification_out_of_scope`, `revision_conflict`, `idempotency_conflict`, `subscription_exists_unowned`, `ownership_missing`, `ownership_mismatch`, `operation_uncertain`, `coverage_incomplete`, `response_limit`, `rate_limited`, `upstream_error`, `upstream_invalid`.

Consumidor deve tratar `operation_uncertain` como necessidade de conferência, jamais retry automático da mutação. Fixture de produtor está em `tests/native-qa.php`; usa dados sintéticos e interceptação HTTP somente no request autenticado de teste, sem modo de simulação no plugin de produção.
