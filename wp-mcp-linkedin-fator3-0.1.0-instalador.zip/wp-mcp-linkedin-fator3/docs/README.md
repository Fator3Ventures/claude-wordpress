# Fator3 Meta e LinkedIn — 0.1.0

Implementação independente para WordPress 6.4+ e PHP 8.1+ de 64 bits. Instale o ZIP correspondente por Plugins → Adicionar plugin → Enviar. Configure em Ferramentas → Fator3 MCP Meta ou Fator3 MCP LinkedIn. A ativação não cria conexão externa nem assinatura de webhook.

## Capacidades

| Plugin | Entrega |
|---|---|
| Meta | Instagram profissional via Facebook Login: perfil, mídias, Stories disponíveis, insights de conta/mídia e demografia agregada |
| LinkedIn | Organização, publicações, estatísticas de página, compartilhamentos, seguidores, demografia; contas, grupos, campanhas, criativos e analytics de anúncios |
| LinkedIn Lead Sync | SDK autônomo para SPONSORED: formulários, respostas, challenge, assinatura de notificações e assinaturas remotas próprias |
| Ambos | Conexões cifradas, permissões por usuário/ativo, painel, coletas persistentes, agendas analíticas, CSV/JSON privados, auditoria, autoteste, REST e Abilities/MCP opcionais |

Core, MCP e Google não são requisitos de instalação. O MCP 0.22.0 adiciona transporte e aplica sua política de concessões. No WordPress sem Abilities API, painel, REST, SDK e cron continuam disponíveis. Não há infraestrutura compartilhada a instalar. Cada pacote contém sua própria cópia isolada da infraestrutura.

## Configurar

1. Abra **Conexões** e cadastre identificador, nome, token e versão de API. Os padrões fixados são Meta `v24.0` e LinkedIn `202609`; não representam seleção automática da versão mais recente.
2. Informe os IDs de usuários WordPress e ativos autorizados. IDs remotos devem ser strings numéricas. Lista vazia concede zero ativos. Administradores gerenciam a conexão; demais usuários só leem as conexões explicitamente concedidas.
3. Meta: selecione o ID da conta Instagram profissional. A descoberta usa `me/accounts` e a Página vinculada; tokens de Página podem exigir seleção manual. A rota Instagram Login não está implementada nesta versão.
4. LinkedIn: selecione separadamente IDs de organizações, contas Ads e contas Lead Sync. Para leads, cadastre o mapa de formulários, por exemplo `{"222":["333"]}`. Client secret é necessário para verificações criptográficas. Credenciais do Core não são copiadas.
5. Use **Validar conta selecionada**. Essa operação comprova metadados da identidade escolhida e grava evidência datada; não comprova todos os produtos/escopos. A revisão da conexão muda. Depois conceda o SDK ao consumidor, quando houver.
6. Em **Relatórios**, selecione conexão, conta, relatório, campos e datas. Consulte uma página ou crie a coleta. O botão de próxima página preserva a seleção da consulta anterior.
7. Em **Coletas e agendas**, acompanhe, avance, pause, retome ou cancele. A exportação de coleta incompleta é identificada como parcial. O download exige autenticação; não há URL pública de arquivos.

Tokens são informados manualmente. Campo vazio preserva o valor existente; remoção exige a caixa específica. O prazo informado é uma declaração local, não introspecção do fornecedor. Não há emissão, renovação automática ou aprovação automática de apps. O painel expõe presença de credencial, nunca seu conteúdo.

## Escopos e homologação externa

Meta: obtenha o acesso exigido pela família Instagram com Facebook Login, incluindo acesso à conta profissional, Página associada e Insights. Dependendo da configuração do app, são necessários `instagram_basic`, `instagram_manage_insights`, `pages_show_list` e permissões de leitura da Página. Papéis e aprovações precisam ser conferidos no app real. Métricas dependem da versão, tipo de mídia, período e limiares; o catálogo anuncia `requires_remote_validation`.

LinkedIn: Advertising, Community Management e Lead Sync são produtos distintos. Em geral, leitura Ads usa `r_ads` e analytics `r_ads_reporting`; Pages depende dos escopos de organização aplicáveis ao endpoint, como `r_organization_social` e `rw_organization_admin`. Respostas Lead Sync exigem `r_marketing_leadgen_automation`, aprovação do produto e papéis apropriados. Ler um formulário com `r_ads` não prova autorização para ler respostas pessoais.

Antes de produção, validar cada produto com token, conta e app autorizados: consultas representativas, páginas seguintes, restrição de ativos, expiração, métricas do catálogo e notificações reais. Fixtures do WordPress não comprovam aprovação nem resposta da API externa. A documentação detalhada de métricas Meta não pôde ser integralmente consultada durante esta entrega; campos recusados são explícitos como indisponíveis, nunca convertidos em zero.

## Operação e retenção

- Agendas são optativas e analíticas; mínimo 60 minutos. Elas congelam conexão/ativos e calculam os últimos dias completos de UTC. Coletas congelam as datas de admissão.
- WP-Cron depende de tráfego ou de um cron real do servidor. Com WP-CLI: `wp f3-meta run`, `wp f3-linkedin run`; diagnóstico: `wp f3-meta selftest` / `wp f3-linkedin selftest`.
- Cada avanço processa uma página; dados são persistidos antes do checkpoint. Repetição após interrupção reutiliza a página já confirmada. Travas de banco impedem dois avanços simultâneos do mesmo job.
- Troca da configuração pausa jobs e invalida cursores antigos. Para a nova revisão, crie uma nova coleta com a mesma seleção. Resultados já confirmados permanecem legíveis enquanto a identidade, conexão e os ativos continuarem autorizados. Não existe migração automática de cursor entre credenciais.
- Resultados: 1–365 dias, padrão 90; exportações: 24 horas; auditoria: 30 dias; resumos de jobs encerrados: 90 dias. Rotina horária remove até 100 registros vencidos por passagem. Agendas, concessões e diários de assinaturas permanecem até exclusão do plugin.
- Segredos e dados persistidos usam cifra autenticada vinculada ao site e ao salt WordPress. Backup precisa preservar banco e salts. Alterar salts pode tornar o conteúdo anterior ilegível; não há recuperação de segredo ou fallback em texto puro.
- Desativar preserva dados e remove eventos próprios. Excluir o plugin pelo WordPress apaga sua tabela, opções e eventos no site atual. Ativação em rede multisite é recusada; ative por site.

## Fronteiras preservadas

Meta Ads continua fora deste cliente. Pixel/CAPI, consentimento, tracking e Meta Lead Ads permanecem no Core. Não são inseridas tags públicas pelo novo plugin.

O Core 1.33.0 continua usando seu cliente interno LinkedIn. Instalar este SDK não seleciona outro cliente nem conecta o SDK à callback Core. O seletor/adaptador comercial planejado para Core 1.34.0 precisa de entrega própria. O consumidor mantém deduplicação, recibos, tombstones, polling, CRM e mensagens. Não há segundo executor comercial neste plugin.

Google Sheets não faz parte desta entrega. Não há stubs ou dependência Google. Atualização é por ZIP manual; não há feed próprio nem troca automática de origem. Registro no SDK opcional de distribuição pode ser acrescentado quando existir origem de distribuição definida.

Veja `CONTRACTS.md`, `SDK-PHP.md`, schemas JSON, testes reproduzíveis e o relatório de validação distribuído com os fontes.
