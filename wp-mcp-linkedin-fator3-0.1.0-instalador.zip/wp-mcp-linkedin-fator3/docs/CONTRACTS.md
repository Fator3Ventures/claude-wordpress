# Contratos efetivos — 0.1.0

Os schemas executáveis de cada pacote ficam em `docs/input-schemas.json` e são expostos por `meta/contracts` ou `linkedin/contracts`. O código da versão entregue prevalece sobre propostas anteriores. Não aceitar aliases de campos ou parâmetros extras.

## Transporte e entrada

Abilities: `meta/<operação>` e `linkedin/<operação>`. Provedores: `wp-mcp-meta-fator3` e `wp-mcp-linkedin-fator3`. Registro via `f3_mcp_register_providers`, política 1. Nenhuma bridge ou executor genérico é instalado. Nomes existentes de Core, Google e MCP permanecem intactos.

REST: POST JSON autenticado em `/wp-json/f3-meta/v1/<operação>` ou `/wp-json/f3-linkedin/v1/<operação>`. Sessão do painel usa nonce `wp_rest`; Application Passwords seguem autenticação WordPress. Autenticação não elimina verificação de usuário, conexão, canal e ativo. O código do transporte MCP aplica ainda sua própria política. Não usar HTTP 200 isoladamente como sucesso: conferir o envelope.

| Operação | Efeito e permissão |
|---|---|
| capabilities, status, selftest, configuration-schema, contracts, documentation | Leitura; usuário com read |
| list-connections, list-fields, query | Leitura; conexões/ativos concedidos; credencial só em armazenamento cifrado |
| save-connection | Escrita local; administrador; expected_revision obrigatório |
| list-accounts | Descoberta remota; administrador; não seleciona ativos automaticamente |
| validate-connection | Leitura remota + evidência local/revisão; administrador |
| create-job, run-job, control-job | Escrita local; identidade proprietária; idempotência na criação e revisão no controle |
| list-jobs, job-status, job-results | Leitura de jobs/resultados da própria identidade/concessão |
| save-schedule, list-schedules | Administração de agendas analíticas; gravação por revisão |
| export, export-read | Criação local e leitura autenticada; exportação vinculada ao proprietário |
| audit | Administrador; eventos seguros paginados, sem parâmetros, respostas pessoais ou segredos |
| save-grant, list-grants | LinkedIn; administrador; concessão por consumidor registrado |
| lead-* | LinkedIn; administrador pelo transporte; SDK local usa identidade de consumidor concedida |

`save-connection` aceita token e client secret somente como entrada protegida. Campo vazio preserva o existente. As respostas não incluem valores secretos. Não enviar token em query string, logs ou exemplos. `raw_body` no verificador de notificação é entrada necessária para HMAC, não um executor HTTP genérico.

## Envelope e revisão

Sucesso: `{success:true,code:"ok",provider,version,data}`. Falha: `{success:false,code,error_code,message,conflict,retryable,data:null,details}`. `conflict:true` identifica `revision_conflict`. Mensagens não incluem corpos remotos ou tokens. O MCP pode acrescentar seu envelope e request_id; consulte o envelope de domínio interno.

Revisão inteira é local ao registro; zero significa criação. CAS é conferido no banco e a escrita é relida. Conflito nunca sobrescreve outra revisão. Grants do SDK também fixam a revisão de credencial. Mudança posterior pausa o consumo até reconfirmação administrativa.

Falhas distinguem configuração ausente, token expirado localmente, token rejeitado remotamente, ativo recusado, quota, validação remota, resposta inválida, conflito, limite e operação incerta. Não afirmar revogação ou escopo específico quando o fornecedor só comprova rejeição genérica. HTTP 400 Meta com código 190 não vira “métrica indisponível”. Quotas persistem cooldown por conexão.

## social-reporting/1.0.0

Entrada mínima: `connection_id`, `channel`, `account_id`, `report`. Campos e filtros variam conforme schemas; `account_insights`, estatísticas temporais de Pages e `ad_analytics` exigem `date_from/date_to`. IDs e milissegundos usados em identidades são strings.

Saída inclui provider/channel/conexão/revisão/conta/versão API, request_id, fetched_at, seleção, catálogo de campos, linhas, fuso, moeda, semântica temporal, cobertura, avisos e next_cursor.

`coverage.plan_complete` indica término das partições executáveis. `coverage.complete` exige também ausência de erros conhecidos de campos. `all_rows_guaranteed:null` preserva ausência de prova de cobertura integral do fornecedor. Nenhum desses campos comprova aprovação do app. Intervalo pedido é preservado; datas/breakdowns efetivos permanecem nas linhas de origem.

Zero, null, campo ausente, lista vazia, supressão e erro de autorização não são intercambiáveis. Demografias são agregadas. Valores únicos, taxas, moedas e snapshots não podem ser somados automaticamente. CTR/CPC/CPM/ROAS são calculados somente dos componentes do mesmo recorte; denominador zero resulta em null. Valores monetários nativos são preservados; derivados usam ponto flutuante e não servem como razão contábil.

Meta pagina listas com cursor remoto e métricas por campo. Não segue URLs `paging.next`: usa somente o cursor na origem fixa. Insights de conta usam até 30 dias por consulta. Stories só cobrem histórico disponibilizado pela origem; a coleta não reconstrói Stories passadas.

LinkedIn lista entidades Ads com `metadata.nextPageToken`, endpoints por conta e header FINDER. adAnalytics não tem paginação nativa: divide DAILY em até sete dias, campos em grupos de até 18 + duas chaves, junta pelo conjunto exato de dateRange/pivotValues e pagina localmente sobre respostas reconsultadas e verificadas por hash. Se houver divergência ou limite de 15.000 elementos, a consulta falha explicitamente. ALL não é dividido temporalmente. Não soma alcance único entre janelas.

Cursores são cifrados e autenticados, expiram e fixam seleção, ator/concessão, site e revisão. Mudança exige nova consulta. Limites: 100 linhas/página, 700 KB por relatório/SDK, 900 KB por resposta de domínio, 1,8 MB por resposta HTTP remota; timeout de até 8 s por chamada e orçamento de execução. Payloads muito grandes retornam erro, não truncamento silencioso.

## Coletas, agendas, exportação e auditoria

Coletas usam até 500 páginas, com pausa após falhas não recuperáveis; até cinco retentativas antes da sexta falha interromper a sequência. Backoff respeita quota. HTTP 5xx de leitura e rate limit são recuperáveis; POST remoto incerto não é repetido automaticamente.

A identidade inclui usuário WordPress e, quando existe, projeção estável da concessão MCP. Worker valida a identidade original, concessão vigente, conexão e ativos. Não assume usuário administrador durante cron. Resultados MCP são vinculados à concessão e lidos pelo mesmo transporte; o painel baixa os resultados que ele próprio criou.

Exportação exige job completo ou `allow_partial:true`. Limite de 8 MB de dados e 12 MB de arquivo. JSON conserva metadados e páginas. CSV inclui colunas `row.*`, metadados e cobertura; objetos/listas ficam em JSON dentro da célula. Fórmulas em células são neutralizadas. `export-read` retorna base64 em blocos de até 196608 bytes, offsets, tamanho e SHA256. Conteúdo é cifrado no banco e expira em 24 horas.

Auditoria conserva operação, identidade, transporte, conexão, instante e código, por 30 dias. Falha de auditoria devolve `audit_warning`; não apaga o efeito já conhecido. Esse diário não é um log completo de cada tentativa HTTP. Diários de assinatura conservam intenção e estado remoto sem payload de leads.
