# Impacto de wp-mcp-linkedin-fator3 0.17.1 em base-site-core-fator3

Data: 02/11/2026 · Revisão 2 · Etapa: entrega · Situação: demanda-aberta.
Emissor: wp-mcp-linkedin-fator3, base aceita 0.16.0, alvo 0.17.1. Destinatário: base-site-core-fator3 1.68.0. Classificação: validacao-coordenada. Referências: Pedidos MCP LinkedIn 21(d/e/f), 22 e 23; Pedidos core 369.
Instalador emissor: wp-mcp-linkedin-fator3-0.17.1-instalador.zip, SHA-256 e3a6c06d2c254a50af60e434a0575424e552ed4f62422ea1aabcff6bd591f1f9.

## Consequência técnica

Na descoberta 1.2, assinatura já confirmada pelo contrato 1.1 pode ser reutilizada quando o recibo local pertence ao mesmo consumidor/conexão/aplicativo/recurso/callback e a releitura remota confirma o vínculo e o ID. A nova intenção guarda alias local, e o retorno usa a ownership_key canônica antiga, adopted:true, sem outro POST. O consumidor deve persistir a chave retornada; não substituí-la pela nova chave de solicitação nem exigir que elas coincidam. Intenção incerta, assinatura estrangeira ou callback divergente continuam bloqueadas.

Uma passagem processa até cinco formulários, com teto de doze chamadas/20 segundos por tarefa e continuação. Uma conta com quatro formulários conhecidos pode agora gerar seus quatro eventos na mesma passagem dentro do orçamento. Outbox continua at_least_once; checkpoint deve acompanhar a persistência de seleção/recibo pelo Core. Falha parcial não autoriza recriar assinatura.

A leitura de respostas repete um GET sem fields apenas no HTTP400 de campo projetado ausente. Os demais filtros, janela, dono e revisões permanecem conferidos. A campanha pode ficar not_provided; o consumidor deve prosseguir sem nome e retomar suas janelas pendentes. Isso não amplia campaign_lookup nem altera o método opcional resolve_campaign. Mudança apenas de leads mantém concessões CAPI correntes, destino e identidades de serviço; concessão já obsoleta não é reativada automaticamente.

## Orientação e validação solicitada

Responsável Core, em conjunto com dono/frota no site autorizado: conferir a persistência das quatro ownership_key canônicas já existentes ao habilitar todos os formulários; verificar que não aparece novo POST nem falha subscription_intent_blocked para recibos próprios confirmados; conferir retomada das quatro janelas após o erro de projeção e ausência de duplicação de contatos; verificar readiness CAPI após mudança apenas de formulários. Não criar contato comercial sintético sem autorização específica.

Não há atualização Core obrigatória para o fluxo já implementado na 1.68.0. LinkedIn pode ser instalado primeiro. O pedido anterior de adoção opcional de resolve_campaign permanece vinculado ao impacto LinkedIn 0.16.0, sem reemissão aqui. Respostas e desfechos devem ser registrados nos relatórios principais dos responsáveis.

## Evidências que fundamentam o pedido

Bancada WordPress real: atualização direta da 0.16.0 com quatro assinaturas operadas via SDK 1.1, preservação de payloads e adoção sem novo POST; descoberta 4 e 7 formulários, retomada e negativas de propriedade; consumidor Core 1.68.0 original com 37 verificações. HTTP LinkedIn sintético com forma conferida na documentação 202609. Esta prova não certifica o fornecedor real nem encerra os aceites de ctooffice.

## Alterações técnicas desta revisão

Detalha a semântica efetiva de alias/ownership_key, limites de lote e orientação de persistência/retomada ao consumidor, além da proposta da revisão 1 preservada no planejamento. O alvo passa de 0.17.0 para 0.17.1 pelo ajuste documental identificado na validação. Não é resposta nem encerramento de impacto recebido; nenhum pacote/documento central Core foi alterado. Arquivo preparado para encaminhamento, sem envio a terceiros.
