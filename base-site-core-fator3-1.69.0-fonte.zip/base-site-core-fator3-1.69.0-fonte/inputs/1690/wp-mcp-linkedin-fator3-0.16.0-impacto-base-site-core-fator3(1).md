# Impacto — LinkedIn 0.16.0 → Site Core

Revisão 3, etapa entrega, 02/11/2026, America/Sao_Paulo. Emissor `wp-mcp-linkedin-fator3`; base aceita 0.15.0, alvo 0.16.0. Destinatário `base-site-core-fator3` 1.68.0. Situação **aberto**: produtor implementado; adoção do fallback e aceite fornecedor pendentes. Natureza contrato, configuração e dados. Classificações `acao-necessaria` e `validacao-coordenada`. Ticket existente: Pedidos core 369(d), continuidade dos pedidos LinkedIn 20/21. Responde a `base-site-core-fator3-1.68.0-impacto-wp-mcp-linkedin-fator3.md`, revisão 2.

## Identidade examinada

- Base LinkedIn 0.15.0: SHA-256 e12b2b468b71c53d7ecc67c55f758ee1af5ba2b24082f9b12046c66944169e85.
- Entrega LinkedIn 0.16.0: `wp-mcp-linkedin-fator3-0.16.0-instalador.zip`, 363060 bytes, SHA-256 `beb018c0e89a6fcc25beff7d5e2955f606c78ea1cbc8148c17666dd4e9c50bc8`.
- Core 1.68.0 original: `base-site-core-fator3-1.68.0-instalador.zip`, 4231467 bytes, SHA-256 afff3783f11aff3395e2a37cd3938958d93dfe1d01e5e566789f1333ccf134a8.

## Contrato entregue e consequência

`get_response`/`read_responses` solicitam explicitamente `leadMetadataInfo` e conservam todos os campos padrão documentados. Validação vincula ID decorado à referência da campanha no lead e ao proprietário autorizado da resposta. Decoração inválida não fornece nome em raw; lead válido continua disponível. Campo aditivo `campaign` separa nome/id/conta, origem, situação, código e retryable do conteúdo pessoal.

O Core 1.68.0 já usa a decoração em raw e mantém precedência do mapa local. Esse caminho não exige nova concessão Ads. Seu consumidor original já adota Lead Reader 1.2, eventos e recibos; a pendência de adoção 1.2 emitida pela 0.15.0 está atendida pelo pacote Core recebido. A homologação ponta a ponta externa continua separada.

Nova extensão `linkedin-lead-campaign/1.0.0`, anunciada em `capabilities` e `descriptor.extensions.campaign`, sem mudar contratos negociados 1.0/1.1/1.2. Método `$reader->resolve_campaign` e operação humana `linkedin/lead-resolve-campaign`. Entrada: connection_id/account_id/form_id/response_id, revisões opcionais credential_revision/grant_revision; não aceita campaign_id arbitrário. Exige consumidor registrado, concessão ativa `campaign_lookup` + `responses`, conta selecionada em Leads e Ads e formulário permitido. Concessão requer prévia/confirmação; instalação não a amplia.

O método relê o lead, aproveita decoração válida ou faz uma introspecção atual (r_ads/rw_ads) e GET da campanha exata sob a conta autorizada. Valida resposta/conta/campanha e revalida principal, seleção e revisões antes/depois dos despachos. Funciona com usuário corrente 0, usando autorização atual do configurador; não usa admin-options, token privado, cache persistente ou escrita comercial. Até dois GETs e uma introspecção; prazo observado de 25 segundos, sem retry automático. Retorna campaign/response_identity/revisões, remote_effect:none e commercial_effects:false, sem respostas pessoais ou outros dados Ads.

Ausência real (`not_provided`/`not_applicable`), autorização (`not_authorized`), revisão (`stale_context`), inconsistência (`invalid_metadata`) e transitório (`temporarily_unavailable`, retryable=true) têm diagnósticos separados. Em erro, data é null e a classificação fica em details.campaign_status. Preservar código original e retry_after. Contrato ausente deve ser detectado antes de chamar. Especificação completa instalada: CAMPAIGN-METADATA.md, lead-campaign-schema.json e input-schemas.json.

## Ações e critério de aceite

1. Responsável Core: descobrir a extensão e consumir campaign/decoração após o mapa local. Quando faltar nome, usar resolve_campaign somente com a nova concessão autorizada. Sem acesso Ads, manter ingestão e ocorrência diagnosticável; não transformar recusa em nome ausente silencioso.
2. Responsável Core: persistir enriquecimento e retry limitado em seu domínio. Não reimportar lead nem recriar webhook/conversão para completar nome. Nova decoração de uma resposta histórica pode produzir conflito de conteúdo conforme a proteção já existente; não sobrepor contato automaticamente.
3. Dono: decidir e confirmar a permissão campaign_lookup/conta Ads quando quiser fallback. Acesso a Lead Sync isolado continua válido.
4. Core/frota: validar nome ausente na decoração, consulta autorizada em serviço, 403/429/timeout, revogação e mudança de revisão; confirmar que lead continua único, contato original preservado e retry não repete efeitos comerciais. Homologar conta real/produtos e callback após instalação autorizada.

Sequência: LinkedIn 0.15.0 → 0.16.0 diretamente; Core 1.68.0 pode permanecer e aproveitar a projeção. Não existe bloqueio global exigindo Core novo para instalar LinkedIn. A integração explícita adicional exige implementação do responsável Core e configuração do dono. Não alteramos código, documentos centrais ou relatório recebido do Core/MCP.

## Evidências e evolução

Revisão 1: planejamento e impacto emitidos antes da implementação; instalador-alvo inexistente. Revisão 2: contrato implementado, especificado e testado. Base 0.15.0 reproduz falta de projeção/método em duas verificações. Matriz integrada do produtor: 443 verificações funcionais e 39 documentais sem falhas; 39 dirigidas incluem MCP original, serviço sem usuário, revogação em três momentos, vínculo, ausência, erros e orçamento. Upgrade direto preserva tabelas/cron/concessões e identidades. Ensaio Core usa runtime original e HTTP sintético que só inclui decoração solicitada; 37 verificações aprovadas, incluindo precedência do mapa local, serviço sem usuário e novo nome sobre lead histórico sem duplicar/sobrepor contato. Revisão 3: mínimo WP 6.4/PHP 8.1.2 e painel (46 checks) aprovados; Site-Teste atualizado para 0.16.0, 9 autotestes e 38 documentos lidos/verificados. O relatório principal registra a operação e a identidade do fonte. Situação permanece aberta exclusivamente para adoção do novo fallback pelo Core e aceite externo. Nenhum envio a outro responsável foi realizado.
