// Native PHP form HTML, real form/analytics scripts and synthetic same-origin HTTP.
// F3_JSDOM=/path/to/node_modules/jsdom node tests/request-317-dom.cjs <native-form.html>
const fs=require('fs'),path=require('path');
const {JSDOM}=require(process.env.F3_JSDOM||'jsdom');
const root=path.resolve(__dirname,'..'),asset=path.join(root,'work/plugin/base-site-core-fator3/assets');
const html=fs.readFileSync(process.argv[2]||'/tmp/core1580-dev/request-317-form.html','utf8');
const checks={};let variant='';
function ck(ok,name){checks[variant+'_'+name]=!!ok;if(!ok)throw new Error('FAIL '+variant+'_'+name);}
const tick=()=>new Promise(r=>setTimeout(r,12));
async function scene({consent=true,second=true,twice=false,failAnalytics=false}={}){
 const dom=new JSDOM('<!doctype html><html><body>'+html+(twice?html:'')+'</body></html>',{runScripts:'outside-only',url:'https://fixture317.example.test/qa-317',pretendToBeVisual:true});
 const w=dom.window,events=[],requests=[],observers=[],forms=Array.from(w.document.querySelectorAll('form'));let permit=consent,fail=failAnalytics;
 const Observer=w.MutationObserver;w.MutationObserver=class extends Observer{constructor(fn){super(fn);observers.push(this);}};
 w.TextEncoder=TextEncoder;w.AbortController=AbortController;w.matchMedia=()=>({matches:false});w.f3baseAnaliseDados={endpoint:'/analytics',caminho:'/qa-317',token:'synthetic-analytics'};
 w.f3baseTracking={permiteTags:()=>permit,sessao:()=>permit?'c'.repeat(32):'',visitante:()=>permit?'b'.repeat(32):''};
 w.f3baseContexto={teste:()=>true,navegacao:()=>({navegacao:'d'.repeat(32),anterior:''}),sinais:()=>({}),audiencia:()=>({largura:1200,max_touch_points:0,retorno:'',visitas:1,visitas_desde:0}),atribuicao:()=>({}),token:async()=> 'synthetic-analytics',estado:()=> 'pronto',destino:()=> 'whatsapp'};
 w.f3baseConsentimento={permiteCategoria:()=>permit};w.HTMLFormElement.prototype.reportValidity=function(){return true;};
 const response=data=>({ok:true,status:200,headers:{get:()=>null},text:async()=>JSON.stringify(data)});
 const token=Buffer.from(JSON.stringify({t:Math.floor(Date.now()/1000)})).toString('base64')+'.fixture';
 w.fetch=async(url,options={})=>{requests.push(String(url));if(String(url)==='/analytics'){
   const payload=JSON.parse(options.body);events.push(...payload.eventos);if(fail){fail=false;throw new TypeError('synthetic interrupted response');}
   return response({ok:true,confirmados:payload.eventos.map(e=>({evento:e.evento,sequencia:e.sequencia}))});
  }
  if(String(url).endsWith('/token'))return response({ok:true,token});
  if(String(url).endsWith('/enviar'))return response({ok:true,aceito:true,record_id:'f'.repeat(32),correlation_id:forms[0].elements.submissao.value,method:'formulario',contexto_teste:true,classe_trafego:'teste',etapa_pendente:second,etapas_restantes:second?[2]:[],continuacao:second?'signed-continuation':'',revisao:forms[0].dataset.revisao});
  if(String(url).endsWith('/complementar'))return response({ok:true,aceito:true,record_id:'f'.repeat(32),method:'formulario',pulado:options.body.get('pular')==='1',revisao_complemento:'r2'});
  if(String(url).endsWith('/tentativas'))return response({ok:true,persisted:true});
  throw new Error('Unexpected synthetic route: '+url);
 };
 w.eval(fs.readFileSync(path.join(asset,'f3base-formularios'+variant+'.js'),'utf8'));
 w.eval(fs.readFileSync(path.join(asset,'f3base-analise'+variant+'.js'),'utf8'));
 w.eval(fs.readFileSync(path.join(asset,'f3base-formulario-analise'+variant+'.js'),'utf8'));
 w.document.dispatchEvent(new w.Event('DOMContentLoaded'));await tick();
 const field=(name,f=forms[0])=>f.querySelector('[name="campos['+name+']"],[name="campos['+name+'][]"]');
 const input=(name,value,f=forms[0])=>{const el=field(name,f);el.focus();el.value=value;el.dispatchEvent(new w.Event('input',{bubbles:true}));return el;};
 const queued=()=>JSON.parse(w.sessionStorage.getItem('f3base_analise_fila')||'{}').eventos||[];
 const all=()=>{const found=new Map();for(const e of [...events,...queued()])found.set(e.evento,e);return [...found.values()];};
 const closed=()=>all().filter(e=>e.tipo==='form_fechado');
 const exit=async()=>{w.dispatchEvent(new w.Event('pagehide'));await tick();};
 const submit=async(f=forms[0])=>{f.dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await tick();await tick();};
 return {w,forms,field,input,all,closed,exit,submit,requests,queued,destroy:()=>{observers.forEach(o=>o.disconnect());w.close();},setConsent:v=>{permit=v;w.document.dispatchEvent(new w.Event('f3base-consentimento'));}};
}
async function run(){
 let s=await scene();s.input('nome','PRIVATE317 Name');await s.exit();let e=s.closed()[0];ck(s.closed().length===1&&e.ultimo_campo==='nome'&&e.etapa===1&&e.campos_preenchidos===1,'name_only_page_exit');ck(!JSON.stringify(s.all()).includes('PRIVATE317'),'typed_value_absent_from_analytics');ck(e.formulario_prova===s.forms[0].dataset.analiseProva&&e.formulario_revisao===s.forms[0].dataset.revisao,'frozen_schema_preserved');s.destroy();
 s=await scene();await s.exit();ck(s.closed().length===0,'untouched_page_exit_not_abandonment');s.destroy();
 s=await scene();s.input('nome','PRIVATE317 keyboard');s.field('email').focus();await s.exit();e=s.closed()[0];ck(e.ultimo_campo==='email'&&e.campos_preenchidos===1,'keyboard_focus_tracks_last_field_without_value');s.destroy();
 s=await scene();const choices=s.forms[0].querySelectorAll('[name="campos[interesses][]"]');for(const el of choices){el.checked=true;el.dispatchEvent(new s.w.Event('input',{bubbles:true}));el.dispatchEvent(new s.w.Event('change',{bubbles:true}));}await s.exit();e=s.closed()[0];ck(e.ultimo_campo==='interesses'&&e.campos_preenchidos===1,'checkbox_group_counted_once');s.destroy();
 s=await scene();s.input('nome','PRIVATE317 File');const file=s.field('anexo');Object.defineProperty(file,'files',{value:[new s.w.File(['PRIVATE317 CONTENT'],'PRIVATE317-FILENAME.txt',{type:'text/plain'})]});file.focus();file.dispatchEvent(new s.w.Event('change',{bubbles:true}));await s.exit();e=s.closed()[0];ck(e.ultimo_campo==='anexo'&&e.campos_preenchidos===2,'file_presence_counted_without_name');ck(!JSON.stringify(s.all()).includes('PRIVATE317'),'file_and_name_not_leaked');s.destroy();
 s=await scene();s.input('nome','PRIVATE317 close');s.w.f3baseFormularios.fechar(s.forms[0]);await s.exit();ck(s.closed().length===1,'explicit_close_then_pagehide_deduplicated');s.destroy();
 s=await scene();s.input('nome','PRIVATE317 Stage1');await s.submit();ck(s.w.f3baseFormularios.etapa(s.forms[0])===2,'real_form_moves_to_second_stage');s.input('mensagem','PRIVATE317 Stage2');await s.exit();e=s.closed()[0];ck(e&&e.ultimo_campo==='mensagem'&&e.etapa===2&&e.campos_preenchidos===2,'second_stage_abandonment_counts_saved_first_stage');ck(s.all().some(e=>e.tipo==='form_aceito')&&!JSON.stringify(s.all()).includes('PRIVATE317'),'first_stage_acceptance_preserved_without_values');s.destroy();
 s=await scene();s.input('nome','PRIVATE317 done');await s.submit();s.input('mensagem','PRIVATE317 complement');await s.submit();await s.exit();ck(s.closed().length===0&&s.all().some(e=>e.tipo==='form_complemento'),'completed_complement_not_abandoned');s.destroy();
 s=await scene();s.input('nome','PRIVATE317 skip');await s.submit();s.forms[0].querySelector('[data-f3base-pular]').click();await tick();await s.exit();ck(s.closed().length===0&&s.all().some(e=>e.tipo==='form_pulada'),'skipped_second_stage_is_terminal');s.destroy();
 s=await scene({second:false});s.input('nome','PRIVATE317 accepted');await s.submit();await s.exit();ck(s.closed().length===0&&s.all().some(e=>e.tipo==='form_aceito'),'single_stage_accepted_not_abandoned');s.destroy();
 s=await scene({consent:false});s.input('nome','PRIVATE317 no consent');await s.exit();ck(s.all().length===0&&!s.requests.includes('/analytics'),'no_measurement_without_consent');s.destroy();
 s=await scene({twice:true});s.input('nome','PRIVATE317 first',s.forms[0]);s.input('nome','PRIVATE317 second',s.forms[1]);s.w.f3baseFormularios.fechar(s.forms[0]);await tick();ck(s.closed().length===1&&s.closed()[0].correlacao===s.forms[0].elements.submissao.value,'same_form_instances_closed_independently');await s.exit();ck(s.closed().length===2&&new Set(s.closed().map(e=>e.correlacao)).size===2,'both_instances_have_separate_receipts');s.destroy();
 s=await scene();s.input('nome','PRIVATE317 detached');s.forms[0].remove();await s.exit();e=s.closed()[0];ck(e&&e.ultimo_campo==='nome'&&e.campos_preenchidos===1,'detached_form_keeps_technical_position');s.destroy();
 s=await scene();s.input('nome','PRIVATE317 revoke');s.setConsent(false);s.setConsent(true);await s.exit();ck(s.closed().length===0,'consent_cycle_does_not_reuse_old_interaction');s.destroy();
 s=await scene();s.input('nome','PRIVATE317 first consent');s.setConsent(false);s.setConsent(true);s.input('email','private317@example.test');await s.exit();e=s.closed()[0];ck(e&&e.ultimo_campo==='email'&&s.all().filter(e=>e.tipo==='form_inicio').length===1,'new_interaction_after_consent_has_own_start');s.destroy();
 s=await scene({failAnalytics:true});s.input('nome','PRIVATE317 retry');await s.exit();const original=s.closed()[0].evento;s.w.dispatchEvent(new s.w.Event('online'));await tick();ck(s.closed().length===1&&s.closed()[0].evento===original&&s.closed()[0].ultimo_campo==='nome','retry_retains_event_identity_and_position');s.destroy();
}
(async()=>{for(const v of ['','.min']){variant=v;await run();}const out=path.join(root,'evidence/1651/request-317-dom.json');fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify({ambiente:'jsdom 27.4.0; HTML gerado pelo WordPress; scripts fonte e minificados; HTTP sintético; sem navegação gráfica',checks},null,2)+'\n');console.log(Object.keys(checks).length+' DOM checks OK');})().catch(e=>{console.error(e.stack);process.exit(1);});
