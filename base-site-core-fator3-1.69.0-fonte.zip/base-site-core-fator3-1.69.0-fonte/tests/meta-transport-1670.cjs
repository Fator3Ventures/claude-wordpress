'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert'),crypto=require('crypto').webcrypto;
const root=path.resolve(__dirname,'..');let checks=0;const check=(v,msg)=>{assert(v,msg);checks++};
async function run(file){
 let allowed=true,test=false,ready=true,now=1793570000000,next=1,requests=[],timers=new Map(),release=null;
 class Bus{constructor(){this.listeners={}}addEventListener(n,f){(this.listeners[n]??=[]).push(f)}emit(n,detail){for(const f of this.listeners[n]||[])f({detail})}}
 const document=new Bus();document.cookie='';document.visibilityState='visible';const window=new Bus();
 Object.assign(window,{f3baseMetaTransporteDados:{pixel:'1670367',endpoint:'https://fixture.test/meta-eventos',modo:'navegador',material:true,token:'fixture'},f3baseConsentimento:{permiteCategoria:()=>allowed},f3baseContexto:{pronto:()=>ready,teste:()=>test,token:async()=> 'fixture'}});
 const fetch=async(url,args)=>{const body=JSON.parse(args.body);requests.push(body);if(body.nome==='Lead'&&!body.navegador_observado&&!release){await new Promise(r=>{release=r})}return {ok:true,status:200,json:async()=>({ok:true})}};
 const ctx={window,document,crypto,Uint8Array,Uint32Array,Map,URLSearchParams,AbortController,location:{protocol:'https:',pathname:'/',search:''},fetch,Date:class extends Date{static now(){return now}},setTimeout:(f,ms)=>{const n=next++;timers.set(n,{f,ms});return n},clearTimeout:n=>timers.delete(n)};
 vm.runInNewContext(fs.readFileSync(file,'utf8'),ctx);
 const settle=async()=>{for(let i=0;i<12;i++)await Promise.resolve()};
 await settle();const id='fixture367-browser-0001';document.emit('f3base-lead-confirmado',{id,metodo:'formulario',meta_evento:'Lead',teste:false});await settle();
 check(requests.some(x=>x.evento===id&&!x.navegador_observado),'confirmed lead captured locally');document.emit('f3base-meta-pixel',{id,nome:'Lead'});release();await settle();
 for(const [n,t] of Array.from(timers)){if(t.ms<=1000){timers.delete(n);t.f()}}await settle();
 const lead=requests.filter(x=>x.evento===id);check(lead.length===2&&lead[1].navegador_observado===true,'pixel arriving during POST is persisted by followup');check(lead[0].criado_em===lead[1].criado_em,'original occurrence preserved');check(lead.every(x=>x.nome==='Lead'&&x.contexto_teste===false),'exact identity name and class');
 document.emit('f3base-lead-confirmado',{id:'fixture367-suppressed',metodo:'formulario',meta_evento:''});await settle();check(!requests.some(x=>x.evento==='fixture367-suppressed'),'suppressed Meta conversion not captured');
 document.emit('f3base-lead-confirmado',{id:'fixture367-material00',metodo:'conteudo',meta_evento:'MaterialDownload'});document.emit('f3base-meta-pixel',{id:'fixture367-material00',nome:'MaterialDownload'});await settle();check(requests.some(x=>x.nome==='MaterialDownload'),'material remains separate');
 const count=requests.length;allowed=false;document.emit('f3base-consentimento',{});document.emit('f3base-meta-pixel',{id:'fixture367-withdrawn0',nome:'Lead'});await settle();check(requests.length===count,'withdrawal stops observations');allowed=true;test=true;document.emit('f3base-meta-pixel',{id:'fixture367-test000000',nome:'Lead'});await settle();check(requests.length===count,'test never becomes unmarked production');
 check(!JSON.stringify(requests).includes('@')&&!JSON.stringify(requests).includes('nome_contato'),'technical payload only');
 return {arquivo:path.relative(root,file),checks:9,lead_posts:lead.map(x=>({evento:x.evento,nome:x.nome,navegador_observado:x.navegador_observado,criado_em:x.criado_em}))};
}
(async()=>{const files=['f3base-meta-transporte.js','f3base-meta-transporte.min.js'];const results=[];for(const f of files)results.push(await run(path.join(root,'work/plugin/base-site-core-fator3/assets',f)));fs.writeFileSync(path.join(root,'evidence/1670/meta-transport-js.json'),JSON.stringify({checks,ambiente:'JavaScript real em VM, transporte simulado, sem envio externo',results},null,2));console.log(checks+' JS checks OK')})().catch(e=>{console.error(e);process.exit(1)});
