<?php
define('WP_CACHE',true);
function wp_cache_clear_cache(){}
require __DIR__.'/bootstrap.php';global $wpdb,$cache_enabled,$super_cache_enabled,$wpsc_save_headers,$cache_max_time;
$cache_enabled=true;$super_cache_enabled=false;$wpsc_save_headers=true;$cache_max_time=86400;
$dir=getenv('F3BASE_ROOT').'/evidence/1670';
file_put_contents($dir.'/catalog-1660.json',wp_json_encode(F3Base_Options::proprias(),JSON_PRETTY_PRINT));
$fixture=WP_CONTENT_DIR.'/cache/supercache/127.0.0.1';wp_mkdir_p($fixture);$file='wp-cache-'.str_repeat('a',32).'.php';file_put_contents($fixture.'/'.$file,"<?php exit; ?>\nfixture public cache");
$oldHome=get_option('home');raw('home','https://127.0.0.1:8136');raw('blog_public','1');
$cache=F3Base_Publicacao_Sonda::resolver_cache($file);
check(empty($cache['ok'])&&str_contains($cache['motivo'],'origem distinta'),'366_https_home_cli_content_url_rejected');
raw('home',$oldHome);unlink($fixture.'/'.$file);
$cons=F3Base_Options::ler('f3base_consentimento');$cons['modo']='legado';$cons['padrao']='pre-aprovado';raw('f3base_consentimento',$cons);
raw(F3Base_Contato_Identidade::OPCAO,F3Base_Contato_Identidade::padroes());
$r=F3Base_Leads_Repositorio::guardar(['nome'=>'Fixture 367','email'=>'fixture367@example.test','telefone'=>'+5511999991234','metodo'=>'formulario','captura'=>'aceito','correlacao'=>str_repeat('c',32),'origem_nativa'=>['origem'=>'fixture367'],'notificar'=>false,'consentimento_medicao'=>true,'consentimento_publicidade'=>true],bin2hex(random_bytes(32)));
check(!empty($r['persisted']),'367_native_record_created');$lead=F3Base_Leads_Repositorio::obter($r['record_id']);$acq=F3Base_Aquisicoes::reservar($lead);
check(!empty($acq['elegivel'])&&$acq['event_id']===$lead['record_id']&&$acq['event_id']!==$lead['correlacao'],'367_actual_acquisition_id_differs_from_correlation');
$req=new WP_REST_Request('POST','/f3base/v1/meta-eventos');$req->set_header('content-type','application/json');$req->set_body(wp_json_encode(['token'=>F3Base_Modulo_Endpoint_Leads::emitir_token(),'nome'=>'Lead','evento'=>$acq['event_id'],'criado_em'=>time(),'caminho'=>'/','navegador_observado'=>true]));
$resp=F3Base_Meta_Transporte::receber($req);check($resp->get_status()===409&&$resp->get_data()['codigo']==='lead_aceito_ausente','367_native_lead_beacon_rejected');
F3Base_Leads_Repositorio::eliminar($lead['record_id'],'fixture');
file_put_contents($dir.'/reproduction-1660-details.json',wp_json_encode(['cache'=>$cache,'lead_response'=>$resp->get_data(),'identificadores_distintos'=>true,'sem_http_externo'=>true],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
evidence('reproduction-1660');
