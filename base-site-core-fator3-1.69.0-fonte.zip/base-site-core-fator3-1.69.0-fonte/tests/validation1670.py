"""Exact ZIP native cycles followed by functional tests on the reinstalled fresh site."""
from pathlib import Path
import os,subprocess
root=Path(__file__).resolve().parents[1]
subprocess.run(['python',str(root/'tests/native-cycles.py')],env=os.environ,check=True)
lab=Path(os.environ['F3BASE_LAB_DIR'])
env=dict(os.environ,F3BASE_LAB_CONTENT=str(lab/'content-fresh'),F3BASE_LAB_DB=os.environ.get('F3BASE_LAB_DB','core_lab')+'_fresh')
for name in ['request-365.php','request-366.php','request-367.php','docs-1670.php','request-360-cta.php','request-362.php','schema-coverage-1640.php']:
 subprocess.run([str(root/'build/php'),str(root/'tests'/name)],env=env,check=True)
