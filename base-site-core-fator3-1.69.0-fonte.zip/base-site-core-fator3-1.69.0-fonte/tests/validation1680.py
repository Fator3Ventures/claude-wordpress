from pathlib import Path
import os,subprocess,shutil,json,hashlib
root=Path(__file__).resolve().parents[1];lab=Path(os.environ['F3BASE_LAB_DIR'])
subprocess.run(['python',str(root/'tests/native-cycles.py')],env=os.environ,check=True)
env=dict(os.environ,F3BASE_LAB_CONTENT=str(lab/'content-fresh'),F3BASE_LAB_DB=os.environ.get('F3BASE_LAB_DB','core_lab')+'_fresh')
def run(name):
 x=subprocess.run([str(root/'build/php'),str(root/name)],env=env,capture_output=True,text=True,timeout=150)
 print(name,x.returncode,x.stdout[-1000:],x.stderr[-1000:],flush=True)
 if x.returncode:raise RuntimeError(name+' failed')
for name in ['request-365.php','request-366.php','request-367.php','docs-1680.php','request-360-cta.php','request-362.php','schema-coverage-1640.php','request-368.php','request-370.php','request-370-collector.php']:run('tests/'+name)
for slug in ['wp-mcp-fator3','wp-mcp-google-fator3','wp-mcp-meta-fator3','wp-mcp-linkedin-fator3']:
 src=root/'inputs/companions'/slug if slug!='wp-mcp-linkedin-fator3' else root/'inputs/companions/linkedin0150-runtime'/slug
 shutil.copytree(src,lab/'content-fresh/plugins'/slug,dirs_exist_ok=True)
run('tests/activate-companions-1670.php')
for name in ['docs-1680.php','request-369.php','request-367-meta019.php']:run('tests/'+name)
