from pathlib import Path
import os, subprocess, json
r=Path(__file__).resolve().parents[1]
def call(*args):
 p=subprocess.run([str(r/'build/php'),*map(str,args)],capture_output=True,text=True)
 if p.returncode: raise RuntimeError(p.stdout[-2000:]+p.stderr[-2000:])
 return p.stdout
print(call(r/'tests/cycle-1370.php','install')[:150])
print(call(r/'dependencies/wp-cli.phar','--allow-root','--path='+str(r/'lab/wordpress'),'plugin','activate','wp-mcp-fator3','wp-mcp-linkedin-fator3','wp-mcp-google-fator3','wp-mcp-meta-fator3')[-1000:])
print(call(r/'build/bootstrap-methods.php')[:100])
print(call(r/'dependencies/wp-cli.phar','--allow-root','--path='+str(r/'lab/wordpress'),'cron','event','run','--due-now')[-1300:])
