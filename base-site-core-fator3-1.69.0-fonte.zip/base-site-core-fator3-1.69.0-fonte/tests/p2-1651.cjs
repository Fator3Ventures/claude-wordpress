// Actual scripts; synthetic collector and controlled optional script completion.
const fs=require('fs'),path=require('path'),assert=require('assert'),{JSDOM}=require('./dom/node_modules/jsdom');
const root=path.resolve(__dirname,'..'),assets=path.join(root,'work/plugin/base-site-core-fator3/assets'),checks={};
const tick=()=>new Promise(r=>setTimeout(r,25));
const check=(value,label)=>{checks[label]=!!value;assert(value,label);};
function formHtml(){return '<form data-f3base-formulario="demo" data-revisao="r"><input type="hidden" name="submissao" value="'+'d'.repeat(32)+'"><input type="hidden" name="token"><div class="f3base-campo"><input name="campos[nome]"></div><div class="f3base-campo"><input name="campos[email]"></div></form>';}
async function scene(suffix='',html='',profile=null){
 const dom=new JSDOM('<!doctype html><html><head></head><body>'+html+'</body></html>',{url:'https://fixture.test/',runScripts:'outside-only',pretendToBeVisual:true});
 const w=dom.window;let allowed=true,test=false;const events=[],loads=[];
 w.TextEncoder=TextEncoder;w.AbortController=AbortController;w.matchMedia=()=>({matches:false});
 w.f3baseConsentimento={permiteCategoria:()=>allowed};
 w.f3baseTracking={permiteTags:()=>allowed,sessao:()=>'a'.repeat(32),visitante:()=>'b'.repeat(32)};
 w.f3baseContexto={teste:()=>test,navegacao:()=>({navegacao:'c'.repeat(32),anterior:''}),sinais:()=>({}),audiencia:()=>({}),atribuicao:()=>({}),token:async()=> 'fixture'};
 w.f3baseAnaliseDados={endpoint:'/analytics',caminho:'/',token:'fixture',recursos:{formularios:{handle:'f3base-formulario-analise',src:'/assets/f3base-formulario-analise.min.js'},ofertas:{handle:'f3base-ofertas',src:'/assets/f3base-ofertas-modulo.min.js'}}};
 w.fetch=async(url,opts)=>{const b=JSON.parse(opts.body);events.push(...b.eventos);return {status:200,headers:{get:()=>null},text:async()=>JSON.stringify({ok:true,confirmados:b.eventos.map(e=>({evento:e.evento,sequencia:e.sequencia}))})};};
 const append=w.document.head.appendChild.bind(w.document.head);w.document.head.appendChild=n=>{if(n.tagName==='SCRIPT'){loads.push(n.src);}return append(n);};
 const css=w.getComputedStyle.bind(w);w.getComputedStyle=n=>{const c=css(n);return {display:c.display,visibility:c.visibility,opacity:c.opacity||'1'};};
 w.HTMLElement.prototype.getBoundingClientRect=function(){return {x:0,y:0,top:0,left:0,right:200,bottom:100,width:200,height:100};};
 const load=n=>w.eval(fs.readFileSync(path.join(assets,n+suffix+'.js'),'utf8'));
 load(profile===null?'f3base-analise':'perfis/analise-'+profile);w.document.dispatchEvent(new w.Event('DOMContentLoaded'));await tick();
 return {w,events,loads,load,consent:v=>{allowed=v;w.document.dispatchEvent(new w.Event('f3base-consentimento'));},test:v=>{test=v;w.document.dispatchEvent(new w.Event('f3base-teste-alterado'));},close:()=>w.close(),flush:async()=>{w.dispatchEvent(new w.Event('pagehide'));await tick();await tick();}};
}
(async()=>{
 for(const suffix of ['', '.min']){
  let s=await scene(suffix);check(s.loads.length===0,suffix+' absent resources have zero optional downloads');
  const shell=s.w.document.createElement('section');shell.dataset.f3baseOferta='modal';shell.dataset.f3baseOfertaId='demo';shell.innerHTML=formHtml();s.w.document.body.appendChild(shell);
  const f=shell.querySelector('form'),input=f.querySelector('[name="campos[nome]"]');
  const before=s.w.f3baseOfertas.contexto(f);check(before&&before.instancia.length===32,suffix+' synchronous offer context before optional script');
  shell.dispatchEvent(new s.w.CustomEvent('f3base-oferta-aberta',{bubbles:true,detail:{gatilho:'clique'}}));
  input.value='PRIVATE_VALUE_MUST_NOT_LEAVE_FORM';input.dispatchEvent(new s.w.Event('input',{bubbles:true}));
  shell.dispatchEvent(new s.w.CustomEvent('f3base-oferta-fechada',{bubbles:true,detail:{motivo:'botao'}}));shell.hidden=true;
  const occurred=Math.floor(Date.now()/1000);await tick();
  check(s.loads.filter(x=>x.includes('formulario-analise')).length===1&&s.loads.filter(x=>x.includes('ofertas')).length===1,suffix+' dynamic modules requested once');
  s.load('f3base-formulario-analise');s.load('f3base-ofertas-modulo');await s.flush();
  const offerEvents=s.events.filter(e=>e.tipo.startsWith('oferta_'));
  check(JSON.stringify(offerEvents.map(e=>e.tipo))===JSON.stringify(['oferta_exibida','oferta_aberta','oferta_fechada']),suffix+' early offer open close preserved in order');
  check(offerEvents.every(e=>e.oferta.instancia===before.instancia&&e.criado_em<=occurred),suffix+' offer instance and occurrence time preserved');
  check(s.events.some(e=>e.tipo==='form_inicio'),suffix+' early form input retained');
  check(s.events.some(e=>e.tipo==='form_fechado'&&e.campos_preenchidos===1&&e.ultimo_campo==='nome'),suffix+' early abandonment technical detail retained');
  check(!JSON.stringify(s.events).includes('PRIVATE_VALUE'),suffix+' field values not copied to analytics');
  check(s.w.f3baseOfertas.podeExibir('demo',1)===false,suffix+' synchronous offer frequency retained');
  check(!Object.values(s.w.f3baseRecursos.diagnostico()).some(x=>x.pendentes||x.limite),suffix+' pending bridge drained without overflow');
  s.load('f3base-formulario-analise');s.load('f3base-ofertas-modulo');await s.flush();
  check(s.events.filter(e=>e.tipo==='oferta_aberta').length===1,suffix+' duplicate optional execution does not duplicate events');s.close();

  s=await scene(suffix,formHtml());check(s.loads.length===1&&s.loads[0].includes('formulario-analise'),suffix+' form page does not request offer module');
  const initial=s.w.document.querySelector('form');initial.querySelector('[name="campos[nome]"]').value='PRIVATE_VALUE';initial.querySelector('[name="campos[nome]"]').dispatchEvent(new s.w.Event('input',{bubbles:true}));
  s.consent(false);s.load('f3base-formulario-analise');await s.flush();check(!s.events.some(e=>e.tipo.startsWith('form_')),suffix+' revocation discards pending form observations');s.close();

  s=await scene(suffix,formHtml());
  const early=s.w.document.querySelector('form');early.querySelector('[name="campos[nome]"]').value='PRIVATE_VALUE';early.querySelector('[name="campos[nome]"]').dispatchEvent(new s.w.Event('input',{bubbles:true}));
  await s.flush();check(s.events.filter(e=>e.tipo==='form_inicio').length===1&&s.events.filter(e=>e.tipo==='form_fechado').length===1,suffix+' exit before optional form load still records abandonment');
  s.load('f3base-formulario-analise');await s.flush();check(s.events.filter(e=>e.tipo==='form_inicio').length===1&&s.events.filter(e=>e.tipo==='form_fechado').length===1,suffix+' late form load after exit does not duplicate fallback');s.close();

  s=await scene(suffix,'<section data-f3base-oferta="modal" data-f3base-oferta-id="early">'+formHtml()+'</section>');
  const earlyOffer=s.w.document.querySelector('section');earlyOffer.dispatchEvent(new s.w.CustomEvent('f3base-oferta-aberta',{bubbles:true,detail:{gatilho:'clique'}}));earlyOffer.dispatchEvent(new s.w.CustomEvent('f3base-oferta-fechada',{bubbles:true,detail:{motivo:'botao'}}));earlyOffer.hidden=true;
  await s.flush();check(s.events.filter(e=>e.tipo==='oferta_aberta').length===1&&s.events.filter(e=>e.tipo==='oferta_fechada').length===1,suffix+' exit before offer module load records open and close');
  s.load('f3base-ofertas-modulo');await s.flush();check(s.events.filter(e=>e.tipo==='oferta_aberta').length===1&&s.events.filter(e=>e.tipo==='oferta_fechada').length===1,suffix+' late offer module does not duplicate fallback');s.close();

  s=await scene(suffix,formHtml());s.load('f3base-formulario-analise');
  const ready=s.w.document.querySelector('form');ready.dispatchEvent(new s.w.CustomEvent('f3base-formulario-inicio',{bubbles:true}));ready.dispatchEvent(new s.w.CustomEvent('f3base-formulario-aceito',{bubbles:true,detail:{duplicado:false}}));await s.flush();
  check(s.events.filter(e=>e.tipo==='form_aceito').length===1&&!s.events.some(e=>e.tipo==='form_fechado'),suffix+' accepted form does not become abandoned');s.close();
 }
 for(let mask=0;mask<4;mask++){const html=mask&2?'<section data-f3base-oferta="modal" data-f3base-oferta-id="bundle">'+formHtml()+'</section>':(mask&1?formHtml():'');const s=await scene('.min',html,mask);check(s.loads.length===((mask===2)?1:0),'bundle '+mask+' avoids duplicate bundled downloads');check(s.w.f3baseRecursos.pronto('formularios')===!!(mask&1)&&s.w.f3baseRecursos.pronto('ofertas')===!!(mask&2),'bundle '+mask+' registers exactly selected modules');s.close();}
 fs.writeFileSync(path.join(root,'evidence/1651/p2-dom.json'),JSON.stringify({environment:'jsdom; actual source/minified; controlled delayed optional load; no provider HTTP',checks},null,2));
 console.log(Object.keys(checks).length+' P2 checks passed');
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
