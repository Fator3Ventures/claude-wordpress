<?php
require __DIR__.'/bootstrap.php';global $wpdb;$table=$wpdb->prefix.'f3base_meta_eventos';$hash=hash('sha256','cycle1670-legacy');$mode=$argv[1]??'check';$columns=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$table));
if($mode==='seed'){
 check(F3BASE_PLUGIN_VERSAO==='1.66.0'&&!in_array('event_id',$columns,true),'1670_base_has_original_schema');
 check($wpdb->insert($table,['evento'=>$hash,'nome'=>'Lead','pixel_id'=>'1670367','criado_em'=>1790000000,'rota'=>'navegador','navegador_observado'=>1,'classe_trafego'=>'teste','atualizado_em'=>1790000001])===1,'1670_legacy_fixture');
}else{
 check(F3BASE_PLUGIN_VERSAO==='1.67.0'&&in_array('event_id',$columns,true),'1670_additive_column_installed');
 if($mode==='reinstall'){check(empty(get_option(F3Base_Instalacao::OPTION)['reinstalacao_pendente']),'1670_reinstall_new_cycle');check(F3Base_Instalacao::verificar(),'1670_reinstall_required_tables');$schema=get_option(F3Base_Esquema::OPTION);foreach($schema['_donos'] as $name=>$owner){check($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($name)))===$name,'1670_reinstall_table_'.$name);check(F3Base_Esquema::pronta($owner[0]),'1670_reinstall_ready_'.$owner[0]);}check((bool)get_option(F3Base_Instalacao::HISTORICO),'1670_reinstall_prior_receipts_kept');}
 $row=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE evento=%s',$table,$hash),ARRAY_A);
 if($mode==='upgrade'){check($row&&$row['event_id']===''&&$row['evento']===$hash&&(int)$row['criado_em']===1790000000&&$row['rota']==='navegador'&&(int)$row['navegador_observado']===1&&$row['classe_trafego']==='teste','1670_legacy_identity_not_invented_counts_preserved');}
}
echo wp_json_encode(['ok'=>true,'checks'=>$checks,'version'=>F3BASE_PLUGIN_VERSAO]);
