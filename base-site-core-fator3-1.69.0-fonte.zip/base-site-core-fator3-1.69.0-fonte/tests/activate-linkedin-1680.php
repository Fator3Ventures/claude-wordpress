<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';$r=activate_plugin('wp-mcp-linkedin-fator3/wp-mcp-linkedin-fator3.php');check(!is_wp_error($r),'linkedin0150_activated');evidence('activate-linkedin-1680');
