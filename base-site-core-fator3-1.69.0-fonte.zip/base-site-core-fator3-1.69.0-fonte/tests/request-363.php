<?php
require __DIR__.'/bootstrap.php';
raw('f3base_ga4_measurement_id','G-QA12345678');F3Base_Perfil_Publico::atualizar(false);
$snapshot=F3Base_Medicao_Contexto::snapshot();check($snapshot['ok'],'363_snapshot_readable');
$schema=F3Base_Medicao_Contexto::schema('snapshot');check(!is_wp_error(rest_validate_value_from_schema($snapshot,$schema)),'363_full_snapshot_schema');
$method=new ReflectionMethod(F3Base_Medicao_Contexto::class,'politica');
$inputs=array();foreach(['f3base_consentimento','f3base_google_carregamento','f3base_carregamento_destinos','f3base_testes','f3base_comportamento','f3base_eventos_destinos'] as $name){$inputs[$name]=F3Base_Options::ler($name);}
$before=hash('sha256',serialize($inputs));$policySchema=$schema['oneOf'][0]['properties']['data']['properties']['policy'];
$modes=['herdar','imediato','apos_interacao','ocioso'];$destinations=['ga4','google_ads','gtm','meta','linkedin','clarity'];$count=0;
for($n=0;$n<4096;$n++){
 $i=$n;$v=$inputs;foreach($destinations as $dest){$v['f3base_carregamento_destinos'][$dest]=$modes[$i%4];$i=intdiv($i,4);}
 foreach([false,true] as $enabled){foreach(['load','navegacao','elegibilidade'] as $clock){foreach([false,true] as $accelerate){
  $v['f3base_carregamento_destinos']['ativo']=$enabled;$v['f3base_carregamento_destinos']['referencia']=$clock;$v['f3base_carregamento_destinos']['antecipar_conversao']=$accelerate;
  $policy=$method->invoke(null,$v);$r=rest_validate_value_from_schema($policy,$policySchema);if(is_wp_error($r)){throw new RuntimeException($n.':'.$r->get_error_message());}++$count;
 }}}
}
check($count===49152,'363_all_discrete_mode_combinations');
foreach($destinations as $dest){for($n=1;$n<=30;$n++){$v=$inputs;$v['f3base_carregamento_destinos'][$dest.'_teto_segundos']=$n;check(!is_wp_error(rest_validate_value_from_schema($method->invoke(null,$v),$policySchema)),'363_deadline_'.$dest.'_'.$n);}}
check($before===hash('sha256',serialize($inputs)),'363_configuration_unchanged');
$notices=[];$capture=static function($name,$message)use(&$notices){if(str_contains($message,'f3base-tracking')){$notices[]=$message;}};add_action('doing_it_wrong_run',$capture,10,2);
F3Base_Ativos_Publicos::preparar_ciclo();wp_set_current_user(0);(new F3Base_Modulo_Tracking())->enfileirar();remove_action('doing_it_wrong_run',$capture,10);
check(!$notices,'363_no_alias_strategy_notice');$alias=wp_scripts()->registered['f3base-tracking']??null;check($alias&&$alias->src===false&&empty($alias->extra['strategy']),'363_alias_has_no_strategy');
wp_set_current_user(0);$ability=wp_get_ability('f3base/medicao-contexto-ler');$r=$ability->execute([]);check(is_wp_error($r)||empty($r['ok']),'363_anonymous_ability_denied');
evidence('request-363');
