<?php
require __DIR__.'/bootstrap.php';global $wpdb;
$catalog=F3Base_Options::catalogo();$saved=[];
// Exercise the catalog with no registration filters, as an early consumer can do.
$hooks=$GLOBALS['wp_filter']['f3base_options_catalogo']??null;$GLOBALS['wp_filter']['f3base_options_catalogo']=new WP_Hook();
try{$method=new ReflectionMethod(F3Base_Options::class,'montar_catalogo');$early=$method->invoke(null);foreach(['f3base_instagram_conversas','f3base_instagram_conversas_estado'] as $key){check(isset($early[$key]),'365_instagram_without_registration_'.$key);check(F3Base_Options::equivalente($early[$key]['padrao'],$catalog[$key]['padrao']),'365_instagram_same_default_'.$key);}}finally{if($hooks===null){unset($GLOBALS['wp_filter']['f3base_options_catalogo']);}else{$GLOBALS['wp_filter']['f3base_options_catalogo']=$hooks;}}
$put=static function($name,$value)use(&$saved){if(!array_key_exists($name,$saved)){$saved[$name]=get_option($name,null);}raw($name,$value);};
try{
 foreach($catalog as $name=>$def){if(get_option($name,null)===null){$put($name,$def['padrao']);}}
 $inventory=F3Base_Estado_Inventario::documento();foreach($inventory['estados_internos'] as $d){$put($d['nome'],get_option($d['nome'],['fixture'=>true]));check(F3Base_Estado_Inventario::estado_interno($d['nome']),'365_declared_'.$d['nome']);}
 foreach(['f3base_trava_'.str_repeat('a',64),'f3base_clarity_cota_'.str_repeat('a',64),'f3base_intencoes_origem_'.str_repeat('a',12)] as $name){$put($name,['fixture'=>true]);check(F3Base_Estado_Inventario::estado_interno($name),'365_dynamic_'.$name);}
 $missing=F3Base_Options::catalogo_ausentes();if($missing['quantidade']){echo wp_json_encode($missing)."\n";}check($missing['ok']&&$missing['quantidade']===0&&!$missing['parcial'],'365_all_declared_modules_and_states_no_false_warning');
 $remote=json_decode(file_get_contents(getenv('F3BASE_ROOT').'/evidence/1670/site-1660-option-names.json'),true);foreach($remote as $name){check(isset($catalog[$name])||in_array($name,F3Base_Options::proprias(),true)||F3Base_Estado_Inventario::estado_interno($name),'365_observed_site_name_'.$name);}
 foreach(['f3base_qa1670_unknown','f3base_clarity_cota_wrong','f3base_release_9999','f3base_trava_'.str_repeat('a',63),'f3base_journal','f3base_instagram_conversas_typo'] as $name){$put($name,'PRIVATE-VALUE-MUST-NOT-APPEAR');check(!F3Base_Estado_Inventario::estado_interno($name),'365_not_overbroad_'.$name);}
 $missing=F3Base_Options::catalogo_ausentes();check($missing['quantidade']===6&&!str_contains(wp_json_encode($missing),'PRIVATE-VALUE'),'365_unknown_values_still_warn_names_only');
 wp_set_current_user(0);check(F3Base_Options::catalogo_ausentes()['codigo']==='sem_permissao','365_admin_only');wp_set_current_user(1);
}finally{foreach($saved as $name=>$value){if($value===null){delete_option($name);}else{raw($name,$value);}}}
evidence('request-365');
