<?php
/** Temporary request-only comparison on the authorized Site-Teste.
 * Template: replace HASH and EXPIRES before installing; remove after probes.
 * Never changes active_plugins, cron, options, data or provider configuration.
 */
if (!defined('ABSPATH') || PHP_SAPI === 'cli') { return; }
if (($_SERVER['HTTP_HOST'] ?? '') !== 'fator3-teste-mcp-1.dreamhosters.com') { return; }
if (!in_array(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), ['/', '/wp-login.php'], true)) { return; }
if (!is_string($_GET['f3qa_token'] ?? null) || time() > __EXPIRES__ || !hash_equals('__HASH__', hash('sha256', $_GET['f3qa_token']))) { return; }
$f3qa_mode = $_GET['f3qa_mode'] ?? '';
if (!in_array($f3qa_mode, ['with', 'without'], true)) { return; }
if (!preg_match('/^[a-f0-9]{32}$/D', $_SERVER['HTTP_X_F3_PROBE_NONCE'] ?? '')) { return; }
if (!defined('DONOTCACHEPAGE')) { define('DONOTCACHEPAGE', true); }
if ($f3qa_mode === 'without') {
    add_filter('option_active_plugins', static function ($plugins) {
        return array_values(array_diff((array)$plugins, [
            'base-site-core-fator3/base-site-core-fator3.php',
            'wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php',
        ]));
    }, PHP_INT_MAX);
}
add_action('init', static function () use ($f3qa_mode) {
    $loaded = [];
    foreach (get_included_files() as $file) {
        foreach (['base-site-core-fator3', 'wp-mcp-pipedrive-fator3'] as $slug) {
            if (str_ends_with($file, '/'.$slug.'/'.$slug.'.php')) { $loaded[$slug] = true; }
        }
    }
    $matches = count($loaded) === ($f3qa_mode === 'with' ? 2 : 0);
    nocache_headers();
    header('X-F3-QA1650-Mode: '.($matches ? $f3qa_mode : 'mismatch'));
}, 0);
