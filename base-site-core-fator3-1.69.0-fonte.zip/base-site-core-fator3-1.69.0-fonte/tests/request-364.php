<?php
$kind=getenv('F3BASE_CONTEXT')?:'cli';if($kind==='rest'||$kind==='mcp'){define('REST_REQUEST',true);}if($kind==='cron'){define('DOING_CRON',true);}
require __DIR__.'/bootstrap.php';
$catalog=F3Base_Options::catalogo();$early=$GLOBALS['qa1660_early_catalog']??[];check(array_keys($catalog)===array_keys($early),'364_catalog_before_registration_'.$kind);
foreach(['f3base_meta_ads','f3base_meta_monitoramento','f3base_ga4_acervo','f3base_google_ads_acervo'] as $name){check(isset($early[$name]),'364_early_'.$name);}
if(getenv('F3BASE_SEED_CATALOG')==='1'){
 foreach($catalog as $name=>$def){if(get_option($name,null)===null){raw($name,$def['padrao']);}}
 $meta=F3Base_Options::ler('f3base_meta_ads');$meta['conexao']='qa1660';$meta['conta_id']='1803436740776667';raw('f3base_meta_ads',$meta);F3Base_Perfil_Publico::atualizar(false);
}
foreach($catalog as $name=>$def){$raw=get_option($name,null);$expected=$raw===null?$def['padrao']:F3Base_Options::sanitizar($name,$raw);check(F3Base_Options::equivalente($expected,F3Base_Options::ler($name)),'364_value_'.$kind.'_'.$name);}
check(F3Base_Options::ler('f3base_meta_ads')['conta_id']==='1803436740776667','364_saved_selection_'.$kind);
raw('f3base_qa1660_unknown',['secret'=>'not returned']);$missing=F3Base_Options::catalogo_ausentes();check(in_array('f3base_qa1660_unknown',$missing['nomes'],true),'364_unknown_warning');check(!str_contains(wp_json_encode($missing),'not returned'),'364_no_value_in_warning');delete_option('f3base_qa1660_unknown');
wp_set_current_user(0);check(F3Base_Options::catalogo_ausentes()['codigo']==='sem_permissao','364_diagnostic_admin_gate');evidence('request-364-'.$kind);
