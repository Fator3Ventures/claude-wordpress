<?php
require __DIR__.'/bootstrap.php';
F3Base_Servicos::iniciar_cta();
register_block_type('qa/deep',array('render_callback'=>static fn()=>do_blocks('<!-- wp:group {"className":"f3base-acao-contato"} --><div class="wp-block-group f3base-acao-contato">'.str_repeat('<!-- wp:html --><a href="/contato">C</a><!-- /wp:html -->',140).'</div><!-- /wp:group -->')));
$before=F3Base_Servicos::cta_diagnostico();$html=do_blocks('<!-- wp:group --><main class="wp-block-group"><!-- wp:qa/deep /--><!-- wp:qa/deep /--><!-- wp:qa/deep /--></main><!-- /wp:group -->');$after=F3Base_Servicos::cta_diagnostico();
check($after['profundidade_atual']===0,'354_depth_balanced_after_nested_do_blocks');
check($after['raizes_carimbadas']-$before['raizes_carimbadas']===1,'354_nested_do_blocks_only_outer_root');
check(substr_count($html,'data-f3base-lead="contato"')===420,'354_all_nested_links_stamped');
check(($after['fases']['render_block']['parseamentos']??0)-($before['fases']['render_block']['parseamentos']??0)===1,'354_one_parse_for_420_nested_links');
$skip=static fn($pre,$block)=>($block['blockName']??'')==='qa/skipped'?'<p>Cached block</p>':$pre;add_filter('pre_render_block',$skip,10,2);
$html=do_blocks('<!-- wp:group --><div><!-- wp:qa/skipped /--><!-- wp:html --><a class="f3base-acao-contato" href="/contato">CTA</a><!-- /wp:html --></div><!-- /wp:group -->');
check(F3Base_Servicos::cta_diagnostico()['profundidade_atual']===0&&str_contains($html,'data-f3base-lead'),'354_short_circuit_does_not_leak_depth');remove_filter('pre_render_block',$skip,10);
$type=WP_Block_Type_Registry::get_instance()->get_registered('core/template-part');$callback=$type->render_callback;$type->render_callback=static fn()=>'<div class="f3base-acao-contato"><a href="/contato">Header</a></div>';
try{$html=do_blocks('<!-- wp:group --><div><!-- wp:template-part {"slug":"qa","area":"header"} /--></div><!-- /wp:group -->');check(str_contains($html,'data-f3base-superficie="cabecalho"'),'354_nested_header_preserves_surface');}finally{$type->render_callback=$callback;}
evidence('request-354-depth');
