from pathlib import Path
import os,subprocess
r=Path(__file__).resolve().parents[1]
def run(file,**extra):
 env=dict(os.environ,**extra)
 subprocess.run([str(r/'build/php'),str(r/'tests'/file)],env=env,check=True)
for context in ['public','rest','mcp','cron','cli']:
 run('request-364.php',F3BASE_CONTEXT=context,F3BASE_SEED_CATALOG='1' if context=='public' else '0')
run('request-354-roots.php',F3BASE_ROOTS_WARM='0')
run('request-354-roots.php',F3BASE_ROOTS_WARM='1')
run('request-354.php')
run('request-354-warm.php')
(r/'lab/wordpress/wp-content/mu-plugins/qa1660-catalog.php').unlink(missing_ok=True)
