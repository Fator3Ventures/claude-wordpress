<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
foreach(['wp-mcp-fator3'=>'0.38.0','wp-mcp-google-fator3'=>'0.25.1','wp-mcp-meta-fator3'=>'0.18.0','wp-mcp-linkedin-fator3'=>'0.14.0'] as $slug=>$v){$file=$slug.'/'.$slug.'.php';$result=activate_plugin($file);check(!is_wp_error($result),'activation_'.$slug);check(get_plugin_data(WP_PLUGIN_DIR.'/'.$file)['Version']===$v,'version_'.$slug);}
evidence('companions1660');
