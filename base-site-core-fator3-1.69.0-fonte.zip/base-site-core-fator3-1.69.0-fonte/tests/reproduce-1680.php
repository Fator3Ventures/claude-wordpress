<?php
require getenv('F3BASE_SITE');wp_set_current_user(1);
if(F3BASE_PLUGIN_VERSAO!=='1.67.0'){throw new RuntimeException('Expected immutable 1.67.0 baseline');}
$cfg=array_replace(F3Base_Linkedin_Integracoes::padrao(),['conta_id'=>'222','formularios'=>['8333']]);$form=['id'=>'8333','versionId'=>'1','content'=>['questions'=>[['questionId'=>1,'predefinedField'=>'PHONE_NUMBER']]]];
$r=['id'=>'synthetic','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:222'],'leadType'=>'SPONSORED','testLead'=>true,'versionedLeadGenFormUrn'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:8333,1)','submittedAt'=>(string)((time()-100)*1000),'formResponse'=>['answers'=>[['questionId'=>1,'answerDetails'=>['textQuestionAnswer'=>['answer'=>' +12025550123 ']]]]]];
$a=F3Base_Linkedin::traduzir($r,$cfg,$form);$r['formResponse']['answers'][0]['answerDetails']['textQuestionAnswer']['answer']='+12025550123';$b=F3Base_Linkedin::traduzir($r,$cfg,$form);
$defect=$a['payload']['_linkedin']['papeis']['telefone']!==$b['payload']['_linkedin']['papeis']['telefone'];if(!$defect){throw new RuntimeException('Expected text canonicalization defect not reproduced');}
echo wp_json_encode(['base'=>F3BASE_PLUGIN_VERSAO,'text_edges_mismatch_reproduced'=>true,'values_omitted'=>true,'read_only'=>true]);
