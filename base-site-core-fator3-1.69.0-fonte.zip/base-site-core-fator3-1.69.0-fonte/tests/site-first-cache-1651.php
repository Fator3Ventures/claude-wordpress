<?php
/** Temporary observation only, Site-Teste, Core 1.65.1; remove after verification. */
if(!defined('ABSPATH')||($_SERVER['HTTP_HOST']??'')!=='fator3-teste-mcp-1.dreamhosters.com'){return;}
add_filter('wpsupercache_buffer',static function($html){
 if(!defined('F3BASE_PLUGIN_VERSAO')||F3BASE_PLUGIN_VERSAO!=='1.65.1'||($_SERVER['REQUEST_URI']??'')!=='/'||time()>__EXPIRES__){return $html;}
 $file=WP_CONTENT_DIR.'/f3base-qa-1651/first-cache-9a62.php';$f=@fopen($file,'x');if(!$f){return $html;}
 $m=get_option('f3base_ativos_publicos',array());$c=get_option('f3base_instalacao',array());
 $row=array('escopo'=>'primeiro buffer da home entregue ao WP Super Cache nesta versão; arquivo final conferido separadamente','em'=>time(),'versao'=>F3BASE_PLUGIN_VERSAO,'html_sha256'=>hash('sha256',$html),'bytes'=>strlen($html),'referencia_publica'=>str_contains($html,'wp-content/f3base-publico/'),'manifesto_versao'=>$m['versao']??null,'manifesto_gerado_em'=>$m['gerado_em']??null,'manifesto_sha256'=>$m['sha256']??null,'confirmada_no_executor_em'=>$c['confirmada_no_executor_em']??null,'ciclo'=>$c['ciclo']??null);
 fwrite($f,"<?php exit; ?>\n".wp_json_encode($row,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));fclose($f);return $html;
},PHP_INT_MAX);
