<?php
/** Native WP in CLI with WPSC layout/HTTP fixtures; no provider traffic. */
define('WP_CACHE',true);function wp_cache_clear_cache(){}function get_supercache_dir(){return WP_CONTENT_DIR.'/cache/supercache/127.0.0.1/';}
require __DIR__.'/bootstrap.php';global $wpdb,$cache_enabled,$super_cache_enabled,$wpsc_save_headers,$cache_max_time;
$cache_enabled=true;$super_cache_enabled=false;$wpsc_save_headers=true;$cache_max_time=86400;
$fixture=get_supercache_dir();wp_mkdir_p($fixture);$file='wp-cache-'.str_repeat('a',32).'.php';$saved=[];$put=static function($name,$value)use(&$saved){$saved[$name]=get_option($name,null);raw($name,$value);};
$put('home','https://127.0.0.1:8136');$put('blog_public','1');$put('show_on_front','posts');$put(F3Base_Cache_Pagina::ESTADO,['versao'=>F3BASE_PLUGIN_VERSAO,'geracao'=>'fixture366','pendente'=>false]);
$put('f3base_cabecalhos',F3Base_Options::catalogo()['f3base_cabecalhos']['padrao']);
$requests=[];$response=['response'=>['code'=>200],'headers'=>[],'body'=>''];$http=static function($pre,$args,$url)use(&$requests,&$response){$requests[]=['url'=>$url,'redirects'=>$args['redirection']??null,'limit'=>$args['limit_response_size']??null];return $response;};add_filter('pre_http_request',$http,99999,3);
try{
 file_put_contents($fixture.$file,"<?php exit; ?>\nfixture public cache");
 check(!is_ssl()&&str_starts_with(content_url(),'http:')&&str_starts_with(home_url(),'https:'),'366_reproduces_cli_scheme_difference');

 $cfg_file=WP_CONTENT_DIR.'/wp-cache-config.php';check(!file_exists($cfg_file),'366_disposable_config_fixture');
 $had_setting=isset($GLOBALS['wpsc_ignore_tracking_parameters']);$old_setting=$GLOBALS['wpsc_ignore_tracking_parameters']??null;
 try{
  $GLOBALS['wpsc_ignore_tracking_parameters']=1;$web_context=F3Base_Cache_Pagina::contexto();unset($GLOBALS['wpsc_ignore_tracking_parameters']);
  check(F3Base_Cache_Pagina::contexto()!==$web_context,'366_reproduces_missing_cli_global');
  file_put_contents($cfg_file,"<?php\n// normal WPSC literal\n\$wpsc_ignore_tracking_parameters = 1;\n");
  check(F3Base_Cache_Pagina::contexto()===$web_context,'366_cli_and_web_context_equal');
  check(!isset($GLOBALS['wpsc_ignore_tracking_parameters']),'366_configuration_not_executed_or_global_mutated');
  $GLOBALS['wpsc_ignore_tracking_parameters']=false;check(!F3Base_Cache_Pagina::requisitos()['rastreamento']['ativado'],'366_explicit_false_preserved');unset($GLOBALS['wpsc_ignore_tracking_parameters']);
  foreach(['0','false'] as $value){file_put_contents($cfg_file,'<?php $wpsc_ignore_tracking_parameters = '.$value.';');check(!F3Base_Cache_Pagina::requisitos()['rastreamento']['ativado'],'366_disabled_literal_'.$value);}
  file_put_contents($cfg_file,'<?php $wpsc_ignore_tracking_parameters = true;');check(F3Base_Cache_Pagina::requisitos()['rastreamento']['ativado'],'366_boolean_literal');
  foreach(['// $wpsc_ignore_tracking_parameters = 1;', '$wpsc_ignore_tracking_parameters = getenv("NO_EXEC");', 'if(false){$wpsc_ignore_tracking_parameters = 1;}', 'if(false) $wpsc_ignore_tracking_parameters = 1;', '$wpsc_ignore_tracking_parameters = 1; $wpsc_ignore_tracking_parameters = 0;'] as $i=>$code){file_put_contents($cfg_file,'<?php '.$code);check(!F3Base_Cache_Pagina::requisitos()['rastreamento']['ativado'],'366_ambiguous_config_rejected_'.$i);}
  foreach(['if(false): $irrelevant=0; $wpsc_ignore_tracking_parameters=1; endif;', 'while(false): $irrelevant=0; $wpsc_ignore_tracking_parameters=1; endwhile;', 'foreach([] as $item): $irrelevant=0; $wpsc_ignore_tracking_parameters=1; endforeach;', 'for(;false;): $irrelevant=0; $wpsc_ignore_tracking_parameters=1; endfor;'] as $i=>$code){file_put_contents($cfg_file,'<?php '.$code);check(!F3Base_Cache_Pagina::requisitos()['rastreamento']['ativado'],'366_alternative_control_syntax_rejected_'.$i);}
 }finally{unlink($cfg_file);if($had_setting){$GLOBALS['wpsc_ignore_tracking_parameters']=$old_setting;}else{unset($GLOBALS['wpsc_ignore_tracking_parameters']);}}
 $r=F3Base_Publicacao_Sonda::resolver_cache($file);if(empty($r['ok'])){echo wp_json_encode(['resolver'=>$r,'home'=>home_url(),'content'=>content_url(),'base'=>F3Base_Publicacao_Sonda::base_cache()])."\n";}check($r['ok']&&str_starts_with($r['url'],'https:'),'366_canonical_https_artifact_in_cli');
 $proof=F3Base_Cache_Pagina::sondar_artefato(true);check($proof['status']==='verified'&&$proof['codigo']==='cache_corpo_vazio'&&$proof['bytes']===0,'366_protected_served_artifact_24h');check(F3Base_Cache_Pagina::ttl()['ttl_configurado_segundos']===86400,'366_ttl_24h_observed');
 check($requests[0]['redirects']===0&&$requests[0]['limit']===F3Base_Publicacao_Sonda::MAX_BYTES+1,'366_bounded_no_redirect_probe');
 foreach([403,404,410] as $status){$response['response']['code']=$status;check(F3Base_Cache_Pagina::sondar_artefato()['status']==='verified','366_empty_protection_'.$status);}
 $response['response']['code']=200;$response['body']=file_get_contents($fixture.$file);check(F3Base_Cache_Pagina::sondar_artefato()['codigo']==='artefato_cache_exposto','366_exposed_cache_rejected');
 $response['body']='forbidden';check(F3Base_Cache_Pagina::sondar_artefato()['status']==='failed','366_nonempty_error_not_success');$response['body']='';$response['response']['code']=302;check(F3Base_Cache_Pagina::sondar_artefato()['status']==='pending','366_redirect_inconclusive');
 $foreign=static fn($url)=>str_replace('127.0.0.1','external.example.test',$url);add_filter('content_url',$foreign);check(!F3Base_Publicacao_Sonda::resolver_cache($file)['ok'],'366_cdn_origin_still_rejected');remove_filter('content_url',$foreign);
 unlink($fixture.$file);$r=F3Base_Cache_Pagina::sondar_artefato();check($r['codigo']==='sem_artefato_elegivel'&&count($r['recusas'])===2&&$r['busca']['diretorio']==='cache/supercache/127.0.0.1','366_no_artifact_has_directory_and_reasons');
 $durable=F3Base_Cache_Evidencia::prova(['artefato_cache'=>$r]);check($durable['artefato_cache']['recusas']===$r['recusas']&&$durable['artefato_cache']['busca']===$r['busca'],'366_diagnostic_survives_persistence');
 check(!str_contains(wp_json_encode($r),ABSPATH),'366_no_absolute_server_path');
 file_put_contents($fixture.'unrelated.txt','private');symlink($fixture.'unrelated.txt',$fixture.$file);check(!F3Base_Publicacao_Sonda::resolver_cache($file)['ok'],'366_symlink_rejected');unlink($fixture.$file);unlink($fixture.'unrelated.txt');
 $cycle=['ciclo'=>'qa366','versao'=>F3BASE_PLUGIN_VERSAO,'confirmada_no_executor_em'=>time()-10];$put(F3Base_Instalacao::OPTION,$cycle);$initial=['estado'=>'atencao','codigo'=>'sem_artefato_elegivel','em'=>time()-100];$put(F3Base_Pos_Atualizacao::STATE,['ciclo'=>'qa366','concluida_em'=>time()-90,'etapas'=>['cabecalhos'=>$initial]]);
 $put(F3Base_Cache_Evidencia::OPTION,['ultima_tentativa'=>['contexto'=>F3Base_Cache_Pagina::contexto(),'checked_at'=>time(),'status'=>'verified','codigo'=>'cabecalhos_comprovados','motivo'=>'Fixture proof','hit'=>true,'persisted'=>true]]);
 $current=F3Base_Options::verificar_configuracao('f3base_cabecalhos',F3Base_Options::ler('f3base_cabecalhos'));$summary=F3Base_Pos_Atualizacao::resumo();
 check($current['status']==='verified'&&$summary['etapas']['cabecalhos']['codigo']===$current['codigo']&&$summary['etapas']['cabecalhos']['estado']==='verificado','366_current_health_and_post_update_agree');
 check($summary['etapas']['cabecalhos']['recibo_inicial']===$initial&&get_option(F3Base_Pos_Atualizacao::STATE)['etapas']['cabecalhos']===$initial,'366_initial_receipt_immutable');
 check(!isset(F3Base_Pos_Atualizacao::avisos()['pos_atualizacao_cabecalhos']),'366_warning_clears_without_manual_cycle_reset');
 raw(F3Base_Cache_Pagina::ESTADO,['versao'=>F3BASE_PLUGIN_VERSAO,'geracao'=>'changed366','pendente'=>true]);$current=F3Base_Options::verificar_configuracao('f3base_cabecalhos',F3Base_Options::ler('f3base_cabecalhos'));$summary=F3Base_Pos_Atualizacao::resumo();check($summary['etapas']['cabecalhos']['codigo']===$current['codigo']&&isset(F3Base_Pos_Atualizacao::avisos()['pos_atualizacao_cabecalhos']),'366_new_pending_reason_not_old_failure');
}finally{remove_filter('pre_http_request',$http,99999);foreach($saved as $n=>$v){if($v===null){delete_option($n);}else{raw($n,$v);}}if(is_file($fixture.$file)){unlink($fixture.$file);}}
evidence('request-366');
