from pathlib import Path
import os,subprocess
r=Path(__file__).resolve().parents[1]
for mode in ['install','migrate','finalize']:
 x=subprocess.run([str(r/'build/php'),str(r/'tests/cycle-1370.php'),mode],env=os.environ,capture_output=True,text=True)
 print(mode,x.returncode,x.stdout[:1000],x.stderr[-1000:],flush=True)
 if x.returncode:raise SystemExit(x.returncode)
