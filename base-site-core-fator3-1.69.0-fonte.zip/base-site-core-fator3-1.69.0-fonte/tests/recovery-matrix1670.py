"""Final recovery matrix. Use one private MySQL at a time, shared tablespace for this filesystem."""
from pathlib import Path
import os,subprocess
r=Path(__file__).resolve().parents[1]
for lab_name,folder in [('lab','recovery-current'),('lab-min','recovery-minimum')]:
 lab=r/lab_name
 env=dict(os.environ,F3BASE_LAB_DIR=str(lab),F3BASE_MYSQL_DATA=str(lab/'mysql-recovery-shared1670final'),F3BASE_MYSQL_FILE_PER_TABLE='OFF',F3BASE_LAB_DB='core_recovery1670',F3BASE_EVIDENCE_DIR='evidence/1670/'+folder,F3BASE_BASE_VERSION='1.66.0',F3BASE_TARGET_VERSION='1.67.0',F3BASE_TARGET_CONTRACT='8.30.0',F3BASE_CANDIDATE=str(r/'release/base-site-core-fator3-1.67.0-instalador.zip'))
 subprocess.run(['python3',str(r/'tests/run-lab.py'),'tests/validation1670.py'],env=env,check=True,cwd=r)
 print(folder,'COMPLETE',flush=True)
