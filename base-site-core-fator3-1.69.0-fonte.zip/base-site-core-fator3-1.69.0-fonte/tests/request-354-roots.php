<?php
require __DIR__.'/bootstrap.php';$warm=getenv('F3BASE_ROOTS_WARM')==='1';
if(!$warm){F3Base_Servicos::invalidar_cta();}wp_set_current_user(0);
$markup='<!-- wp:group {"className":"f3base-acao-contato"} --><div class="wp-block-group f3base-acao-contato">'.str_repeat('<!-- wp:html --><a href="/contato">Contato</a><!-- /wp:html -->',424).'</div><!-- /wp:group -->';
$t=microtime(true);$html=do_blocks($markup);$d=F3Base_Servicos::cta_diagnostico();
check(substr_count($html,'data-f3base-lead="contato"')===424,'354_all_links_preserved');check($d['profundidade_atual']===0,'354_depth_balanced');check($d['raizes_carimbadas']===1,'354_only_root_stamped');
check(($d['fases']['render_block']['parseamentos']??0)===($warm?0:1),'354_root_parse_expected');check(($d['fases']['render_block']['cache_acertos']??0)===($warm?1:0),'354_root_cross_request_hit');
$file=getenv('F3BASE_ROOT').'/evidence/1660/roots-'.($warm?'warm':'cold').'.json';file_put_contents($file,wp_json_encode(['ms'=>(microtime(true)-$t)*1000,'sha256'=>hash('sha256',$html),'cta'=>$d],JSON_PRETTY_PRINT));
F3Base_Servicos::gravar_cache_raizes();if(!$warm){check(F3Base_Servicos::cta_diagnostico()['fases']['render_block']['cache_gravacoes']===1,'354_single_bucket_write');}
if($warm){$old=get_option('f3base_cta_cache');wp_set_current_user(1);$post=wp_insert_post(['post_title'=>'QA 1660 invalidation','post_status'=>'draft']);wp_set_current_user(0);check(get_option('f3base_cta_cache')!==$old,'354_root_invalidated');$again=do_blocks($markup);check($again===$html,'354_root_invalidation_parity');check(F3Base_Servicos::cta_diagnostico()['fases']['render_block']['parseamentos']===1,'354_root_reparsed_after_save');}
if(isset($post)){wp_set_current_user(1);wp_delete_post($post,true);}
evidence('request-354-roots-'.($warm?'warm':'cold'));
