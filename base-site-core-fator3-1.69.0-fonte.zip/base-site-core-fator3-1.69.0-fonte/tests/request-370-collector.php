<?php
require __DIR__.'/bootstrap.php';
$cfg=F3Base_Options::ler('f3base_anuncios_meta');$cfg=array_replace($cfg,['ativo'=>true,'proprietario_confirmado'=>true,'conta_id'=>'222','paginas'=>['123'],'formularios'=>[],'formularios_modo'=>'todos_paginas_autorizadas']);raw('f3base_anuncios_meta',$cfg);raw('f3base_anuncios_meta_token',F3Base_Segredos::cifrar('f3base_anuncios_meta_token','synthetic-token'));
$state=['ativado_em'=>time()-3600,'conta_id'=>'222','permissoes_em'=>time(),'conta_verificada_em'=>time(),'revisao'=>F3Base_Options::revisao('f3base_anuncios_meta'),'credencial_revisao'=>F3Base_Options::revisao('f3base_anuncios_meta_token'),'paginas'=>['123'=>['completa'=>true,'em'=>time(),'itens'=>['111'=>['id'=>'111','nome'=>'Known','pagina_id'=>'123','questions'=>[]]]]]];raw('f3base_anuncios_estado',['meta'=>$state]);
$calls=[];$pass=1;$http=static function($pre,$args,$url)use(&$calls,&$pass){$path=parse_url($url,PHP_URL_PATH);parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);$calls[]=[$path,$q];$r=static fn($j)=>['response'=>['code'=>200],'body'=>wp_json_encode($j),'headers'=>[]];
 if(str_ends_with($path,'/123/leadgen_forms')){check($q['fields']==='id,name,status','370_collector_minimal_query_'.$pass);if($pass===3){return new WP_Error('synthetic_offline');}return $r(['data'=>[['id'=>$pass===1?'111':'222','name'=>'Synthetic','status'=>'ACTIVE']]]+($pass===1?['paging'=>['next'=>'opaque','cursors'=>['after'=>'next-page']]]:[]));}
 if(str_ends_with($path,'/123')){return $r(['id'=>'123','access_token'=>'synthetic-page-token']);}
 if(str_ends_with($path,'/222')){check($q['fields']==='id,questions','370_collector_new_questions_only');return $r(['id'=>'222','questions'=>[]]);}
 if(str_ends_with($path,'/leads')){return $r(['data'=>[]]);}return new WP_Error('unexpected_fixture_path');
};add_filter('pre_http_request',$http,PHP_INT_MAX,3);
try{
 $x=F3Base_Anuncios::consultar();check(!$x['ok']&&$x['codigo']==='catalogo_paginando','370_collector_partial_catalog_reported');check(count(array_filter($calls,static fn($c)=>str_ends_with($c[0],'/111/leads')))===1,'370_known_form_collected_during_catalog_pagination');
 $pass=2;$x=F3Base_Anuncios::consultar();check($x['ok']&&$x['formularios_incluidos']===1,'370_collector_discovers_new_form_in_next_pass');$s=get_option('f3base_anuncios_estado')['meta'];check(count($s['paginas']['123']['itens'])===2&&isset($s['paginas']['123']['itens'][222]['incluido_em']),'370_inclusion_in_persisted_diagnostic');check(count(array_filter($calls,static fn($c)=>str_ends_with($c[0],'/222/leads')))===1,'370_new_form_collected_same_pass');
 $pass=3;$x=F3Base_Anuncios::consultar();check(!$x['ok']&&$x['codigo']==='graph_transporte_indisponivel','370_catalog_failure_reported');check(count(array_filter($calls,static fn($c)=>str_ends_with($c[0],'/111/leads')))===3,'370_known_collection_survives_catalog_failure');$s=get_option('f3base_anuncios_estado')['meta'];check($s['proxima_execucao']<=time()+3600,'370_retry_at_most_one_hour');
}finally{remove_filter('pre_http_request',$http,PHP_INT_MAX);$cfg['ativo']=false;raw('f3base_anuncios_meta',$cfg);}
evidence('request-370-collector');
