<?php
require __DIR__.'/bootstrap.php';
F3Base_Perfil_Publico::atualizar(false);$r=F3Base_Ativos_Publicos::preparar_ciclo();check(!empty($r['ok']),'362_manifest_ready_before_confirmation');
$manifest=get_option(F3Base_Ativos_Publicos::OPTION);check($manifest['versao']===F3BASE_PLUGIN_VERSAO,'362_manifest_current_version');
$cycle=get_option(F3Base_Instalacao::OPTION);$cycle['concluido_em']=time();unset($cycle['finalizacao_em'],$cycle['confirmada_no_executor_em']);raw(F3Base_Instalacao::OPTION,$cycle);
$method=new ReflectionMethod(F3Base_Instalacao::class,'finalizar');$method->setAccessible(true);
// Missing current manifest plus another publisher holding the lock must stop confirmation.
raw(F3Base_Ativos_Publicos::OPTION,array());$lock=F3Base_Trava::adquirir('ativos-publicos',45);check((bool)$lock,'362_fixture_lock');
try{$r=$method->invoke(null,$cycle);check(empty($r['ok'])&&$r['codigo']==='aguardando_ativos_publicos','362_no_confirmation_without_manifest');check(empty(get_option(F3Base_Instalacao::OPTION)['confirmada_no_executor_em']),'362_confirmation_not_written_early');}finally{F3Base_Trava::liberar($lock);}
$fallback=F3Base_Ativos_Publicos::configurar_tracking();check(defined('DONOTCACHEPAGE')&&DONOTCACHEPAGE,'362_fallback_not_page_cached');
$r=F3Base_Ativos_Publicos::preparar_ciclo();check(!empty($r['ok']),'362_manifest_recovered');
$r=F3Base_Instalacao::atualizar();$cycle=get_option(F3Base_Instalacao::OPTION);$manifest=get_option(F3Base_Ativos_Publicos::OPTION);
check(!empty($cycle['confirmada_no_executor_em']),'362_cycle_confirmed_after_publication');check($manifest['gerado_em']<=$cycle['confirmada_no_executor_em']&&($cycle['ativos_publicos_confirmados']['sha256']??'')===$manifest['sha256'],'362_manifest_record_precedes_confirmation');
$config=F3Base_Ativos_Publicos::configurar_tracking();check(in_array('f3base-config-publica',$config['dependencias'],true),'362_first_render_uses_public_files');
evidence('request-362');
