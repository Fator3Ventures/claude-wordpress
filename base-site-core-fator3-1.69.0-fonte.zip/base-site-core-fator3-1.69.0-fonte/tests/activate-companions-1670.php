<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
foreach(['wp-mcp-fator3','wp-mcp-google-fator3','wp-mcp-meta-fator3','wp-mcp-linkedin-fator3'] as $slug){$r=activate_plugin($slug.'/'.$slug.'.php');check(!is_wp_error($r),'activate_'.$slug);}
evidence('activate-companions');
