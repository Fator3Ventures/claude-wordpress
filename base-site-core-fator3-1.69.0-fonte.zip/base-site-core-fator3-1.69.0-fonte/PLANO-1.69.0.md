# Plano — Fator3 Site Core 1.69.0

02/11/2026 · Implementação · Normas comuns revisão 5 lidas integralmente.
Base imutável: 1.68.0, instalador afff3783f11aff3395e2a37cd3938958d93dfe1d01e5e566789f1333ccf134a8. Alvo ainda não gerado. PHP >= 8.3; WordPress >= 7.1.4. Referências atuais: MCP 0.38.0, Google 0.26.0, Meta 0.19.0, LinkedIn 0.17.1 (e3a6c06d2c254a50af60e434a0575424e552ed4f62422ea1aabcff6bd591f1f9), Pipedrive 0.5.0. Site-Teste observado Core 1.68.0/LinkedIn 0.17.1 ativos. Autorização explícita de atualização e alterações necessárias no Site-Teste.

## Escopo

- Pedidos core 369(f): união estável da seleção explícita e descoberta, sem remover os selecionados por atualização parcial do catálogo; autorização do produtor continua em cada leitura.
- 369(g,h): preservar recibo confirmado quando chega evento de falha sem prova de remoção; adotar ownership_key canônica do produtor, sem novo POST. Reproduzir quatro assinaturas originadas pelo contrato 1.1, hoje sob o produtor vigente.
- 369(d): extensão pública linkedin-lead-campaign/1.0.0; prioridade mapa > decoração válida > consulta autorizada. Jornal cifrado no armazenamento já existente, retry limitado/configurável, erros classificados; completar apenas nome vazio com vínculo/revisão conferidos, sem reimportar contato nem repetir efeitos comerciais.
- Remover negociação histórica 1.1 no adaptador alterado; exigir contrato atual 1.2 apenas no fluxo SDK. Preservar cliente Core direto selecionado explicitamente. Nenhum downgrade ou suporte operacional a pacotes substituídos.
- Atualizar requisitos, contrato administrativo se campos/abilities forem acrescentados, documentação e catálogo gerado.

## Impactos avaliados antes da implementação

Contratos entregues pelo LinkedIn 0.17.1 cobrem o pedido; não há alteração solicitada ao produtor neste ponto. Adotar impactos recebidos 0.16.0 rev3 e 0.17.1 rev2 e registrar desfechos no relatório principal. O impacto Core 1.68.0 rev2 terá encerramento da dependência de implementação com referência à prova, sem gerar outro encaminhamento só para anunciar atendimento. Google, Meta, MCP e Pipedrive não precisam de nova interface; funções próprias preservadas. Se a integração revelar lacuna real, registrar proposta antes de consolidar e testar cópia isolada do produtor.

## Provas e entrega

Reprodução na base, integração PHP real com HTTP sintético estrito, identidade/revisão/permissão/indisponibilidade, retry, preservação de contato e ausência de POST duplicado. WordPress nativo 7.1.4: limpa isolada, migração direta 1.68.0, conjunto vigente e leitura documental MCP. PHP disponível 8.3.6; requisito mínimo 8.3.0 será declarado sem inventar prova no patch exato. Instalar ZIP exato no Site-Teste, conferir prontidão/documentação e retirar artefato temporário. Finalizar fonte/instalador/relatório português, sem segredos ou laboratório. Fornecedor real em ctooffice pertence ao aceite da frota e não será inferido de HTTP sintético.

## Fechamento — 02/11/2026

Implementados 369(d,f,g,h). A consulta de campanha usa fila cifrada de metadados e uma consulta por tarefa, respeitando o orçamento de 25 segundos do produtor; nenhuma entrega comercial é reenviada. Configuração opcional de tentativas e reabertura auditada com motivo/revisão. União dos quatro formulários e adoção de recibos 1.1 comprovadas, com quinto automático e sem POST duplicado.

Instalador final: 4256023 bytes, SHA-256 8659ce0e526d378cf8424d0ff42deed660fee9f957be08f2bf26a74ce7f52996. Lint 594 PHP, 130 verificações funcionais; leitura integral documental e ciclos nativos limpo/1.68.0 aprovados. Instalado no Site-Teste, operação 2958b85fc4b511893825371b999f4322; ciclo concluído, contrato 8.32.0, zero avisos, acompanhantes preservados, ZIP temporário removido. Imutável após instalação.

Impactos recebidos 0.16.0 rev3/0.17.1 rev2 atendidos no código e contrato; dependência de desenvolvimento emitida pela 1.68.0 encerrada. Sem nova alteração demandada a outro pacote. Aceites reais da frota, PHP 8.3.0 exato e navegador permanecem explicitados no relatório externo; não foram substituídos pelos testes sintéticos.
