# Fator3 Site Core 1.69.0 — fonte

Runtime em work/plugin/base-site-core-fator3, idêntico ao instalador. Base 1.68.0, contrato 8.32.0. Leia PLANO-1.69.0.md e docs/RELEASE-1.69.0.md. Evidências atuais em evidence/1690; antigas não representam teste repetido. Laboratório, banco, credenciais e pacotes acompanhantes não integram o fonte.
