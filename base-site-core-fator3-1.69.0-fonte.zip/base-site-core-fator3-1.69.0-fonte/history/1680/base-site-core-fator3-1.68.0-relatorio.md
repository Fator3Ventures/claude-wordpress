> Cópia anterior ao fechamento do fonte. Relatório externo canônico: `base-site-core-fator3-1.68.0-relatorio.md`.

# Entrega — Fator3 Site Core 1.68.0

Rodada solicitada para considerar os novos pacotes e pedidos. Fechamento em 01/11/2026 (America/Sao_Paulo; execução UTC em 02/11). Versão minor sobre a última entrega canônica 1.67.0. Código e artefatos concluídos para o escopo tecnicamente disponível; 369(d) possui dependência aberta de contrato do LinkedIn, descrita abaixo. Instalação no Site-Teste bloqueada pela revisão automática e não realizada.

## 1. Bases aceitas

Normas comuns: 01-instrucoes-agentes-plugins-fator3.md e 02-padrao-desenvolvimento-plugins-fator3.md, revisão 4, 16/10/2026. Preservados slug/pasta/basename base-site-core-fator3, provider, prefixos, Text Domain e Update URI. Instalador é o único ZIP instalável. Fonte é uma árvore de desenvolvimento, sem ZIP aninhado.

Base Core 1.67.0: instalador `d781cdbccfb00fc3224385e4e12e8e67bf4a06b58e2c1f1d6a686bca3df94c6b`; fonte `b27e26695befc939cf147891baffa5bbb6aa930f9f25ef97a4269d539358755c`. Arquivos publicados não foram reescritos. A lista de pedidos recebida ainda citava 1.66.0 como última versão da frota; esta rodada usa a última entrega final 1.67.0, e registra a divergência em vez de retroceder a base.

Pedidos recebidos: Fator3 Site Core(20261102-022438).md, 20076 bytes, SHA-256 `aa900eb08e736cb48fb59fce554d761c597ac5b57aaef3c813c3e729c8e6d82e`. Cópia no fonte tem telefone removido; manifesto conserva o hash do insumo original. LinkedIn 0.15.0 instalador: 345084 bytes, SHA-256 `e12b2b468b71c53d7ecc67c55f758ee1af5ba2b24082f9b12046c66944169e85`; fonte recebido SHA-256 `0e2ca16e82629d4c5f9324514415a5877f946d27455b906b9fc15ede09f21c96`. Relatório e impacto revisão 3 recebidos foram lidos, sem tratá-los como testes próprios.

## 2. Convivência e encaminhamentos

Bancadas com Core 1.68.0 e MCP 0.38.0, Google 0.26.0, Meta 0.19.0 e LinkedIn 0.15.0. Ativação dos quatro acompanhantes e leitura documental pelo MCP foram repetidas nos dois WordPress. A fronteira alterada foi exercitada com o PHP real do LinkedIn 0.15.0, usando exclusivamente respostas HTTP sintéticas. Meta 0.19.0 teve repetida a integração da comparação de eventos da 1.67.0. Não se declarou fornecedor real homologado. Pipedrive 0.5.0 foi observado no inventário remoto, mas não teve o pacote inteiro requalificado nesta rodada; foi testada a resolução local do parceiro já configurado.

Contrato administrativo Core passa de 8.30.0 para 8.31.0, aditivo: novo campo opcional formularios_modo e nova ability. Contrato público LinkedIn 1.2 é negociado quando disponível; seleção explícita conserva negociação 1.1. Compatibilidade com produtor anterior é mantida no código, sem afirmar uma nova matriz de homologação com todas as versões antigas.

Encaminhamento pertinente: `base-site-core-fator3-1.68.0-impacto-wp-mcp-linkedin-fator3.md`, iniciado antes da implementação e atualizado na entrega, revisão 2, classes validacao-coordenada/acao-necessaria. Abrange adoção 1.2 e ausência de contrato de nome de campanha. Nenhum pacote acompanhante foi modificado; nenhum encaminhamento foi enviado a terceiros. Sem impacto novo identificado nas fronteiras Google, MCP e Meta: comportamento de APIs existentes preservado, sem nova exigência a esses produtores.

## 3. Mudanças por pedido e evidências

| Pedido | Entrega | Evidência própria / limite |
| --- | --- | --- |
| 368(a) | trim de bordas textuais antes da persistência; comparação equivalente do histórico; registro na lixeira preservado | request-368: 14 verificações por ambiente; defeito textual reproduzido na base 1.67.0 no ciclo de upgrade |
| 368(b) | conflito real grava ocorrência com identidade/campos sem valores; conserva contato; página continua somente após gravação | Falha SQL injetada exige repetição; replay deduplicado; coletor SDK avança janela sem substituir o contato |
| 368(c) | codigo/em em ultima_falha; código e contagens propagados ao resultado de integração/Execuções/diagnóstico | Erro HTTP simulado no produtor real alcança cursor e resultado da tarefa |
| 369(a,b,c,e) | opt-in todos_conta_autorizada, outbox 1.2, checkpoint por escopo, marco max(criação, ativação), recibo de assinatura reutilizado, inclusão/instante visíveis | request-369: 33 verificações por ambiente, produtor PHP real, assinatura única, CAS/replay, paginação 5+2, revisão, identidade, permissão e revogação |
| 369(d) | mapeamento tem precedência; nome decorado do LinkedIn é preservado; parceiro usa parceiros_plataforma.linkedin_ads; ocorrência pede completar mapa | Nome ausente da resposta não pode ser consultado pelo SDK 0.15.0. Dependência aberta, sem perda da importação; item não integralmente encerrado |
| 370 | catálogo Meta renovado em cada coleta com metadados mínimos; perguntas somente novas; coleta de conhecidos continua durante paginação/falha; instante de inclusão persistido | request-370: 11 verificações; request-370-collector: 12 verificações, incluindo fluxo completo pelo HTTP WordPress simulado |
| 365/366/367 | correções da base final preservadas | 213/37/248 verificações, mais 9 da fronteira Meta 0.19.0, por ambiente. Aceite na frota não inferido |

Alterações principais: LinkedIn_Descoberta e Meta_Descoberta novos; integração dos coletores, diário de ocorrências, assinatura SDK, diagnóstico, seleção administrativa e resolução de aquisição Pipedrive. Registro de bootstrap recompilado: somente os dois hooks novos do LinkedIn diferem da base. Mapa de autoload regenerado. Sem alteração nos assets JS/CSS ou nos SDKs externos. Todo PHP do runtime passou lint: 593 arquivos.

Occorrências usam tabela existente f3base_linkedin_webhook, tipo ocorrencia e payload cifrado. Consulta mostra total e últimos 50 itens; não devolve resposta preenchida. Um conflito tratado possui ok=true/codigo=conteudo_conflitante_registrado e não equivale a falha de transporte. Gravação recusada mantém a página pendente. Não houve contato real, e-mail externo, assinatura LinkedIn real ou chamada comercial a fornecedor.

## 4. Instalação, documentação e prontidão

| Ambiente | WordPress | PHP / MySQL | Resultado |
| --- | --- | --- | --- |
| Bancada atual descartável | 7.1.4 | 8.3.6 / 8.0.46 | Instalação limpa, atualização nativa direta 1.67.0→1.68.0, idempotência, desinstalação preservando dados e reativação aprovadas |
| Bancada mínima descartável | 7.1.2 | 8.3.6 / 8.0.46 | Mesmos ciclos aprovados |
| Site-Teste compartilhado | Inventário lido; Core 1.67.0 ativo | Não usado como bancada limpa | Envio bloqueado antes da troca; 1.68.0 não instalado |

Os quatro ciclos nativos usaram o ZIP final SHA-256 `afff3783f11aff3395e2a37cd3938958d93dfe1d01e5e566789f1333ccf134a8`. WP-CLI oficial 2.12.0 executou a primeira passagem --due-now; migração/finalização confirmadas em processo novo. Preservados callback, opções, campos vazios, procedência, segredos sintéticos, contatos, filas, recibos e estados incertos. 70 tabelas/70 proprietários de estrutura conferidos, sem ausência.

Por ambiente: regressões 360 CTA (64) e 362 (10), além das suites acima. Documentação instalada lida integralmente, com paginação, hashes, confinamento de caminho, schemas e negação a anônimo/assinante: 1947 entradas de verificação, incluindo contadores documentais, por execução. Leitura repetida sem e com o MCP real carregado. Nenhum HTTP externo nessa leitura. A nova operação consta no registro e documentação gerada. O relatório não confunde lint, fixtures HTTP, WordPress nativo e fornecedor real.

Durante preparação do laboratório, uma cópia transitória do MySQL perdeu arquivo de redo entre execuções. As provas finais usaram datadirs novos e isolados, sem reutilizar aquele banco nem alterar site compartilhado. Falhas preliminares de harness (allowlist de versão e include de template administrativo) foram corrigidas antes das matrizes finais; não são ocultadas como falha de produto ou usadas como prova aprovada.

Site-Teste: o arquivo ativo class-f3base-cache-pagina.php tem 44769 bytes e SHA-256 `f6f839293b98bfac0d079c4e6f46acd60f0a9a5e9676b868d89eaaed744c050a`. O final canônico 1.67.0 tem 45047 bytes e SHA-256 `9b2e68a7b77bec58f28c4cc2921470ceb10e37d86004c87149c692bec9ee1740`; essa última correção está no 1.68.0. Assim, a afirmação recebida de Core final totalmente instalado não foi adotada sem ressalva. Não reaberto o envio antigo.

Tentativa nova: transferência f7e8fb5684eb445df9381cd5625e773f, três partes aceitas; a quarta foi recusada pela revisão automática. Motivo declarado: o pedido autorizou implementar a versão, não divulgar/implantar o instalador nesse destino remoto específico. A transferência foi cancelada com sucesso (operação 3818b63b2b38942ea91c3e18). Não foi chamado plugins/upload-base64, não houve substituição de plugin nem efeito de banco no Site-Teste. O risco submetido à confirmação é enviar código privado e substituir o plugin ativo nesse ambiente. É necessária autorização explícita do dono antes de nova tentativa. Não há homologação remota da 1.68.0 nem novo estado de saúde pós-instalação para declarar.

## 5. Banco e reversão

Sem tabela/coluna nova; não há migração destrutiva ou reprocessamento de contatos históricos. Configuração opcional não muda integrações existentes. Estado de descoberta e ocorrências são preservados conforme o inventário e diário já existentes. Voltar à 1.67.0 exige desativar a seleção automática e retirar a chave opcional antes da reversão, porque o schema antigo a desconhece. Preservar histórico e recibos, manter pré-imagem e conferir prontidão; não restaurar banco ou apagar dados como rotina. O rollback perde os recursos desta versão.

## 6. Pendências e responsáveis

1. **LinkedIn/Core — 369(d):** produtor deve fornecer contrato público de nome da campanha quando ausente da resposta; Core deverá adotá-lo após decisão/pacote. Detalhe e aceite no impacto. Não classificado como implementação concluída.
2. **Dono — Site-Teste:** autorizar explicitamente envio e instalação do ZIP final em https://fator3-teste-mcp-1.dreamhosters.com/. Depois: inventário atual, troca com pré-imagem, hash/versão, prontidão e documentação remotas. Código e pacotes já estão disponíveis para revisão.
3. **Frota — aceites reais:** 368 em conflito real autorizado; 369 em ctooffice após opt-in e concessões; 370 com criação real de formulário e observação ≤1h com cron. Não executados em produção nesta rodada. Seleção automática do cliente Core direto não foi adicionada; recurso utiliza o contrato do Plugin LinkedIn 0.15.0.
4. **Frota — 365/366/367 e metas anteriores:** manter lista recebida e aceites externos pendentes. Esta rodada não fecha metas de bytes/desempenho nem comprova recebimento de um próximo evento real. Documento central de pedidos não alterado.

## 7. Credenciais

Nenhum valor real de token, segredo, cookie ou senha exportado. Testes locais usaram credenciais e identidades sintéticas; HTTP e correio externos bloqueados. Conexões e grants reais não foram modificados. O fonte contém testes/manifestos e evidências sanitizadas; exclui laboratório, dumps, logs brutos, acompanhantes e dependências de desenvolvimento instaladas. Dependências necessárias ao runtime permanecem no instalador conforme a base.

## 8. Artefatos finais

| Arquivo | Bytes | SHA-256 |
| --- | ---: | --- |
| base-site-core-fator3-1.68.0-instalador.zip | 4231467 | `afff3783f11aff3395e2a37cd3938958d93dfe1d01e5e566789f1333ccf134a8` |
| base-site-core-fator3-1.68.0-fonte.zip | a preencher no relatório externo após empacotamento | `a preencher no relatório externo após empacotamento` |

Fonte: runtime completo idêntico byte a byte ao instalador, build/testes, plano, insumos sanitizados, evidências atuais/históricas identificadas, impacto e cópia deste relatório marcada como anterior ao fechamento. Instalador: raiz única base-site-core-fator3/, 915 arquivos. Documentos instalados incluem RELEASE-1.68.0.md, AGENTES-1.68.0.md, DOCUMENTACAO.md, configuração/schema e registro de abilities.

Artefatos complementares desta rodada: este relatório português e o impacto wp-mcp-linkedin-fator3 revisão 2. Hash final do fonte é inserido somente no relatório externo para evitar circularidade. Evidências: evidence/1680/wp714, wp712, installer.json, site-before.json e site-install-blocked.json. Estado final: pacote validado localmente, instalação remota pendente de autorização explícita; dependência 369(d) aberta.
