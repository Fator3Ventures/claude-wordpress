# Impacto — Site Core 1.68.0 → Fator3 MCP LinkedIn

- Emissor: base-site-core-fator3, base 1.67.0, alvo entregue 1.68.0.
- Destinatário: wp-mcp-linkedin-fator3, base recebida/testada 0.15.0.
- Etapa: entrega; revisão 2 deste encaminhamento; 01/11/2026, America/Sao_Paulo.
- Situação: adoção 1.2 validada em bancada; ação necessária aberta para 369(d); aceite de frota pendente.
- Classes: validacao-coordenada e acao-necessaria.
- Tickets: Core 368/369; LinkedIn 20/21 conforme impacto recebido revisão 3.
- Instalador Core: base-site-core-fator3-1.68.0-instalador.zip, 4231467 bytes, SHA-256 `afff3783f11aff3395e2a37cd3938958d93dfe1d01e5e566789f1333ccf134a8`.
- Instalador LinkedIn recebido: SHA-256 `e12b2b468b71c53d7ecc67c55f758ee1af5ba2b24082f9b12046c66944169e85`.

## Decisão e contrato efetivo

Core registra linkedin-lead-reader/1.2.0 quando anunciado, preservando 1.1 para seleção explícita em produtor anterior. Não há cópia de credenciais nem acesso ao Store privado no runtime consumidor. Opt-in todos_conta_autorizada é separado da lista antiga, com prévia/confirmacão vinculada à configuração e às revisões do produtor. Conexão e grant precisam all_forms_accounts e permissões metadata/responses/verify/subscriptions; callback deve coincidir com o Core e recebimento imediato estar habilitado. Instalar não concede nada.

O hook apenas agenda trabalho. Core lê list_form_events, verifica consumidor/conexão/conta/revisões, incorpora até cinco eventos por passagem e persiste checkpoint, seleção, cursor inicial e recibo em uma atualização atômica. Recibo do produtor mantém ownership_key/state/remote_effect/operation_revision. Core não cria outra chave de POST para esse formulário/versão. Marco inicial é max(criação do formulário, ativação/retencão da importação). Erro de persistência impede avanço; revisão antiga é registrada como ignorada. Uma notificação autenticada anterior à passagem Core consulta a outbox e retorna 503 se ainda precisar de continuação.

## Ação necessária — nome ausente da campanha, 369(d)

Evidência: PublicApi/LeadReader 0.15.0 oferece leitura de formulário/resposta/outbox/assinatura; não oferece lookup de campanha. read_responses e get_response não solicitam explicitamente a decoração de leadMetadataInfo. O catálogo administrativo linkedin/admin-options exige usuário administrador e não é contrato de serviço concedido ao consumidor de leads. Usá-lo como administrador em cron ou ler token privado seria violar a fronteira.

Core preserva o nome decorado quando disponível, usa mapeamento local com precedência e parceiro já configurado em parceiros_plataforma.linkedin_ads. Sem nome, a importação continua com campanha_sem_nome_e_mapeamento e ID nativa; não inventa nome. Portanto a garantia de obter nome em todos os casos ainda não foi entregue.

Proposta ao responsável LinkedIn: definir extensão pública aditiva que forneça id/nome/conta da campanha associada à resposta autorizada, seja por decoração garantida e validada ou método tipado autorizado por concessão explícita. Validar conta e vínculo da resposta, revisões de credencial/grant, erro/retry e orçamento. Não ampliar privilégio de anúncios implicitamente. Resposta sem nome deve distinguir ausência do fornecedor, falta de autorização e falha transitória. Manter 1.0/1.1/1.2 existentes e publicar o contrato escolhido antes da adoção adicional Core.

Aceite: bancada com resposta sem leadMetadataInfo, nome obtido pela API pública sem administrador corrente, dono/conta verificados, grant revogado recusado, transporte indisponível diagnosticado e nenhum lead perdido/duplicado. Depois, aceite coordenado no site autorizado, sem geração de contato comercial sintético.

## Provas próprias desta rodada

WordPress 7.1.4 e 7.1.2/PHP 8.3.6/MySQL 8.0.46, produtor 0.15.0 PHP real com HTTP simulado. request-369: 33 verificações por ambiente, incluindo contrato 1.2, confirmação, assinatura única, resposta anterior à descoberta, ocorrência de campanha, conflito que avança janela, falha/código no cursor, CAS interrompido e retomada, paginação 5+2, identidade estrangeira, revisão obsoleta, permissão e revogação. request-368: 14 verificações por ambiente. Nenhuma dessas provas comprova fornecedor real.

## Pendências e responsáveis

- Responsável LinkedIn: decidir/implementar contrato de nome de campanha acima; este documento não declara trabalho dele concluído.
- Responsável Core: adotar/testar esse contrato após pacote disponível. Item 369(d) permanece parcial.
- Dono/frota: conceder/ativar seleção automática somente nas integrações autorizadas e validar formulário novo em ctooffice após implantação.
- Instalação 1.68.0 no Site-Teste: bloqueada pela revisão automática, que exige autorização explícita para enviar/implantar nesse destino. Transferência parcial cancelada; nenhum arquivo ativo substituído.

Histórico: revisão 1 foi emitida no planejamento, antes da implementação, como validacao-coordenada da adoção 1.2. Revisão 2 registra provas próprias e abre a lacuna concreta de 369(d), sem reescrever pacote do produtor. Não enviado a outro agente ou pessoa.
