Versão vigente 1.69.0 / contrato 8.32.0: RELEASE-1.69.0.md prevalece para o pedido 369. LinkedIn atual 0.17.1; nome ausente consultado por resolve_campaign, seleção em união e adoção de recibos existentes. Orientações de versões anteriores abaixo são históricas nos pontos substituídos.

Versão vigente 1.68.0: veja RELEASE-1.68.0.md. Contrato 8.31.0 aditivo; seleção automática LinkedIn opt-in. Limite 369(d) de consulta de nome ausente documentado. Notas anteriores são históricas.

Versão vigente 1.67.0: veja RELEASE-1.67.0.md para os pedidos 365/366/367. Contrato 8.30.0 preservado; notas históricas abaixo permanecem aplicáveis salvo alteração expressa.

> Vigente em 1.64.0: contrato 8.29.0; pedidos 357–360 e 354 em RELEASE-1.64.0.md e AGENTES-1.64.0.md. As notas atuais prevalecem nos pontos alterados.

> Atualização vigente: Core 1.60.0, contrato 8.24.0. Leia RELEASE-1.60.0.md e os guias 1.60 para as alterações dos pedidos 322 e 330–334; as regras anteriores incompatíveis são históricas.

> Consolidação 1.57.1: leia RELEASE-1.57.1.md para as correções e campos opcionais dos pedidos 312/313. Base direta canônica 1.57.0.

# Fator3 Site Core 1.57.1

Comece em DOCUMENTACAO.md e AGENTES-1.57.1.md. Pedidos 312/313 em RELEASE-1.57.1.md, ACERVO-GA4-1.57.md e INSTAGRAM-EXCLUSAO-1.57.md. Pedidos anteriores 307–311 permanecem documentados em history/RELEASE-1.56.0.md e CONVERSAS-1.56.md; contatos externos do pedido 302 em CONTATOS-EXTERNOS-1.54.md. Contrato administrativo 8.22.1, cliente pipedrive-api-client/1.0.0 preservado.
