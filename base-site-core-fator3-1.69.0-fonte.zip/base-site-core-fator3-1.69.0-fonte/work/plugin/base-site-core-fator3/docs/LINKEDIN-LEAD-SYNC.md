Versão vigente 1.69.0 / contrato 8.32.0: RELEASE-1.69.0.md prevalece para o pedido 369. LinkedIn atual 0.17.1; nome ausente consultado por resolve_campaign, seleção em união e adoção de recibos existentes. Orientações de versões anteriores abaixo são históricas nos pontos substituídos.

# LinkedIn Lead Sync — Core 1.34.0

## Modelo e permissões

`f3base_anuncios_linkedin.integracoes` é a representação canônica única. Cada chave estável tem UUID, rótulo, ativo, cliente (`core` ou `linkedin_plugin`), connection_id, conta, formulários, confirmação de proprietário, mapeamento e preferência de webhook. Estado operacional fica em `f3base_linkedin_estado.integracoes[id]`. Coleção até 20 integrações, até 100 formulários por integração. Lista vazia importa zero. IDs remotos e timestamps em milissegundos preservam precisão; não usar números de ponto flutuante.

Tela, configuração e abilities administrativas exigem `manage_options`. Cron legítimo usa usuário zero e concessão própria. `integracao_id` é obrigatório quando há mais de uma integração. Consumidor público estável: `site-core-li-` seguido do UUID sem hífens. Conta/tipo SPONSORED/formulário sobrepostos são recusados, mesmo com connection_id diferente. Mapeamentos, cursores, callback e leases são separados por integração; trava de submissão conserva a identidade comercial do recurso.

O cliente Core usa a referência `principal` aos segredos já cifrados no Core; várias integrações Core podem referenciar esse perfil. Não foi criado outro cofre ou gerenciador genérico de credenciais. O cliente plugin referencia conexão do Fator3 MCP LinkedIn 0.2.0, contrato `linkedin-lead-reader/1.1.0`, registro no hook público e descriptor negociado. Não copia token, options, tabelas ou caches do produtor. Meta orgânico não participa da captura comercial.

## Configurar e verificar

1. Em Site Core → LinkedIn, escolha a integração ou crie uma pausada com ID única.
2. Para Core, configure token e Client Secret pelos campos protegidos; vazio mantém, exclusão é explícita. Para plugin, configure a conexão no produtor e conceda o consumidor específico.
3. Na prévia da seleção, informe cliente/conexão/conta/formulários. Conceda `metadata` e `responses`; webhook exige também `verify`, `subscriptions` e a callback exata apresentada pelo Core.
4. Execute prévia e confirme com a revisão atual e chave da operação. A configuração genérica recusa alteração de cliente/conexão/conta/formulários de integração existente; use `f3base/anuncios-linkedin-cliente-alterar`.
5. Verificação de acesso confere metadados e permissões; não comprova leitura de leads nem entrega de webhook. Ler diagnóstico/tela não faz HTTP. A prévia explícita pode consultar fornecedor e consumir quota.

O SDK verifica até cinco formulários em check_access; a prévia completa os selecionados por get_form limitado por tempo e revalida revisões. Cobertura parcial impede promoção e aparece com ação. Coleta usa até 50 respostas e janelas de 30 dias (contrato aceita até 31), sem converter cursores opacos em deslocamentos. Revogação/rotação invalida continuação, preserva marco confirmado e reinicia janela sobreposta. `forms_remaining` nunca significa zero leads.

## Troca e recuperação

A operação persiste diário com chave, hash, origem, destino e fases `drenando`, `commit_preparado`, `concluida`. Pausa polling, exclui workers concorrentes e revalida destino antes do commit. Falha de gravação mantém seleção anterior; repetir a mesma operação retoma. Depois do commit, limpa continuação específica do cliente e conserva o menor marco confirmado das versões. Não reenvia histórico nem cria sessão web.

Recebimento anterior deve ser demonstravelmente encerrado. Notificações autenticadas pendentes são processadas pelo cliente anterior. Havendo histórico de assinaturas, o Core solicita remoção/reconciliação das próprias assinaturas; mesmo uma remoção confirmada não prova ausência de notificações em trânsito. Sem prova pública suficiente, retorna `notificacoes_em_transito_sem_prova` e mantém seleção anterior pausada. Não há prazo arbitrário nem botão para declarar drenagem fictícia. O responsável pela integração deve coordenar evidência/capacidade com o produtor antes de promover. A alternância de fluxos sem esse histórico é operacional nos dois sentidos.

A migração 1.33→1.34 preserva a URL de callback anterior, inclusive seu contexto. A URL resolve integração existente, não um cliente escolhido pelo remetente. Corpo bruto original é verificado pelo cliente correspondente. ACK 2xx só depois de persistir recibo; falha SQL retorna 503. Desafio assinado comprova resposta ao desafio; não comprova entrega de lead.

## Assinaturas e recibos

`anuncios-linkedin-webhook-configurar`: consultar/ativar/desativar/reconciliar, revisão e chave de operação; `simular` é true por padrão. Gerencia somente autoria local. POST sem recibo conhecido bloqueia novo POST equivalente, inclusive após GET vazio. Um recibo remoto conhecido é preservado antes de confirmar contexto ou consultar novamente. No SDK, ownership_key e operation_revision são opacos e guardados no diário do Core; get_subscription_operation/reconcile_subscription recuperam resultado. Alterar grant no preflight bloqueia mutação; alteração em voo conserva efeito/incerteza. Não usar outra chave para contornar incerteza.

CREATED e polling convergem na mesma identidade: origem/conta/formulário/ID/submissao_ms. Repetição é deduplicada; mesma URN com submissão posterior é nova captura. DELETED mantém tombstone, cancela pendências elegíveis e conserva contato/CRM já entregue. 404 transitório não exclui contato. Metadados, consentimentos, `testLead`, respostas por ID e atribuição passam ao pipeline comum; nenhuma jornada de navegador é fabricada.

Pausas, quota, SDK ausente/incompatível e revogação são estados distintos. Não há fallback automático. Restore exige preservar diários e suspender/reconciliar efeitos antes de retomar. Nunca eliminar histórico para destravar uma criação incerta.
