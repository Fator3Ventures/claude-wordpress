<?php
/**
 * Gravador único de options do site-core.
 *
 * Regra dura do contrato: nenhuma chamada direta a `update_option`,
 * `update_site_option` ou `delete_option` fora desta classe. Todo módulo, a tela
 * de administração e o `uninstall.php` passam por aqui — o ponto único de escrita
 * é o que torna a leitura de volta e a procedência auditáveis.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Catálogo, sanitização, escrita com leitura de volta e procedência.
 */
final class F3Base_Options {

	/**
	 * Option onde o implantador registra a procedência de cada chave gravada.
	 */
	public const OPTION_PROVENIENCIA = 'f3base_proveniencia';

	/**
	 * Option onde o implantador declara quais chaves são operáveis pelo operador.
	 */
	public const OPTION_OPERAVEIS = 'f3base_operaveis';

	/**
	 * Procedências fechadas.
	 */
	public const ORIGEM_IMPLANTADOR = 'implantador';
	public const ORIGEM_MANUAL      = 'edicao-manual';
	public const ORIGEM_PADRAO      = 'padrao';

	/**
	 * As SEÇÕES da tela, por assunto — e a ordem delas é a ordem de instalação.
	 */
	public const SECAO_CONTATO       = 'contato';
	public const SECAO_MEDICAO       = 'medicao';
	public const SECAO_CONSENTIMENTO = 'consentimento';
	public const SECAO_PRIVACIDADE   = 'privacidade';

	/**
	 * Catálogo resolvido (memoizado por requisição).
	 *
	 * @var array<string,array<string,mixed>>|null
	 */
	private static ?array $catalogo = null;

	/**
	 * As SEÇÕES da tela, na ORDEM em que ela as apresenta.
	 *
	 * POR QUE A ORDEM MORA AQUI. Até a 1.1.3 a tela apresentava as chaves na
	 * ordem do catálogo, que é a ordem em que elas foram escritas — e o
	 * catálogo é ordenado por quem construiu o pacote, não por quem opera o
	 * site. Quem abre esta tela quer resolver UMA coisa, e as coisas têm ordem:
	 * primeiro por onde falam com você, depois o que você mede, depois o que o
	 * visitante pode recusar, depois o que o site guarda e por quanto tempo.
	 * A ordem é declarada num lugar só porque ela é conferida: a tela renderiza
	 * daqui e a bancada mede o DOM contra esta mesma lista.
	 *
	 * @return array<string,array{titulo:string,resumo:string}>
	 */
	public static function secoes_da_tela(): array {
		return array(
			self::SECAO_CONTATO       => array(
				'titulo' => __( 'Contato', 'f3base' ),
				'resumo' => __( 'Por onde quem visita o site fala com você. Enquanto o número não estiver preenchido, o botão de contato não é publicado.', 'f3base' ),
			),
			self::SECAO_MEDICAO       => array(
				'titulo' => __( 'Medição e anúncios', 'f3base' ),
				'resumo' => __( 'As contas que recebem o que acontece no site. Cada campo vazio é uma conta que não recebe nada: o site continua funcionando, e aquela conta continua sem resposta.', 'f3base' ),
			),
			self::SECAO_CONSENTIMENTO => array(
				'titulo' => __( 'Consentimento', 'f3base' ),
				'resumo' => __( 'O que o site faz antes de o visitante decidir, e por onde ele muda de ideia depois. Esta escolha é jurídica antes de ser técnica, e ela muda os números de todos os relatórios.', 'f3base' ),
			),
			self::SECAO_PRIVACIDADE   => array(
				'titulo' => __( 'Privacidade e retenção', 'f3base' ),
				'resumo' => __( 'O que o site guarda, por quanto tempo, e o que ele oferece a leitores automáticos. Os prazos daqui são os que a política de privacidade do site promete.', 'f3base' ),
			),
		);
	}

	/**
	 * As FOLHAS OPERÁVEIS do catálogo: o que a tela apresenta como campo.
	 *
	 * Uma folha é o que tem valor próprio — a option inteira quando ela não é
	 * grupo, e cada sub-campo declarado quando ela é. É esta lista que o
	 * detector `estatica.campo_operavel_tem_impacto_e_exemplo` cobra, e é ela
	 * que a tela percorre.
	 *
	 * @return array<int,array{option:string,chave:string,rotulo:string,declaracao:array<string,mixed>}>
	 */
	public static function folhas_operaveis(): array {
		$folhas = array();

		foreach ( self::catalogo() as $nome => $declaracao ) {
			if ( ! self::operavel( (string) $nome ) ) {
				continue;
			}

			$subcampos = isset( $declaracao['subcampos'] ) && is_array( $declaracao['subcampos'] )
				? $declaracao['subcampos']
				: array();

			if ( array() === $subcampos ) {
				$folhas[] = array(
					'option'     => (string) $nome,
					'chave'      => '',
					'rotulo'     => (string) $declaracao['rotulo'],
					'declaracao' => $declaracao,
				);
				continue;
			}

			foreach ( $subcampos as $chave => $sub ) {
				if ( ! is_array( $sub ) ) {
					continue;
				}

				$folhas[] = array(
					'option'     => (string) $nome,
					'chave'      => (string) $chave,
					'rotulo'     => isset( $sub['rotulo'] ) ? (string) $sub['rotulo'] : (string) $chave,
					'declaracao' => $sub,
				);
			}
		}

		return $folhas;
	}

	/**
	 * Catálogo das options gerenciadas pelo site-core.
	 *
	 * Cada entrada declara: rótulo, descrição, se é operável na tela, o tipo de
	 * campo do formulário, o padrão embutido e o sanitizador. O catálogo é a
	 * fonte única — a tela, a guarda do canal MCP e o relatório leem daqui.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public static function catalogo(): array {
		if ( null !== self::$catalogo ) {
			return self::$catalogo;
		}

		$catalogo = array(
			'f3base_contato'             => array(
				'rotulo'    => __( 'Contato pelo WhatsApp', 'f3base' ),
				'descricao' => __( 'Para onde vai quem clica no botão de contato do site, e com que mensagem a conversa começa.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_CONTATO,
				'campo'     => 'grupo',
				'padrao'    => array(
					'whatsapp_e164'   => '',
					'email_leads'     => '',
					'mensagem_padrao' => '',
				),
				/*
				 * `email_leads` SAIU DO FORMULÁRIO na 1.1.4, e quem a tirou foi
				 * a obrigação de escrever o IMPACTO dela. A varredura de
				 * consumidores em runtime é conclusiva: nenhum módulo deste
				 * plugin lê esta subchave — o destino do regime por e-mail mora
				 * na entrada do formulário desde a 1.1.0. Um campo cujo impacto
				 * honesto é "preencher não muda nada" não é campo: é armadilha
				 * na tela de quem opera. A subchave CONTINUA no padrão e no
				 * sanitizador, então o valor que o agente gravar ali pelo canal
				 * é preservado como qualquer chave desconhecida.
				 */
				'subcampos' => array(
					'whatsapp_e164'   => array(
						'tipo'      => 'texto',
						'rotulo'    => __( 'Número de WhatsApp', 'f3base' ),
						'descricao' => __( 'Código do país, DDD e número, somente dígitos.', 'f3base' ),
						'impacto'   => __( 'Com o número preenchido, o botão de contato passa a ser publicado nas páginas, abre a conversa no WhatsApp já com a mensagem pronta, e o clique é contado como conversão nas contas de anúncio que estiverem configuradas. Enquanto o campo está vazio, o botão não é publicado em página nenhuma: o site continua no ar e sem esse caminho de contato.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 5511900000000 — o 55 do país, o 11 do DDD e o número, sem espaço, traço ou parêntese.', 'f3base' ),
					),
					'mensagem_padrao' => array(
						'tipo'      => 'textarea',
						'rotulo'    => __( 'Mensagem que abre a conversa', 'f3base' ),
						'descricao' => __( 'Texto já escrito na conversa quando o visitante chega ao WhatsApp.', 'f3base' ),
						'impacto'   => __( 'Preenchida, é este texto que aparece escrito na conversa antes de o visitante digitar qualquer coisa — é onde se diz de qual página ele veio. Vazia, o site usa uma frase própria com o nome do site: o botão funciona igual, e só o texto inicial muda.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: "Olá! Vim pelo site e gostaria de falar com a equipe."', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_contato' ),
			),
			'f3base_ga4_measurement_id'  => array(
				'rotulo'    => __( 'Google Analytics 4 — ID da métrica', 'f3base' ),
				'descricao' => __( 'Identificador do fluxo de dados da propriedade do Google Analytics.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o site passa a carregar o Google Analytics e a enviar para lá as páginas vistas, os contatos e o comportamento que ele já mede: profundidade de rolagem, seções alcançadas, cliques que saem do site, sinais de dificuldade, erros de página e tempo de carregamento. Vazio, nada disso chega ao Google Analytics — o site continua guardando o resumo próprio, e a análise completa, com público, origem de tráfego e comparação de períodos, deixa de existir.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo, na forma que o próprio Google usa na documentação: G-XXXXXXXXXX. O valor real aparece no fluxo de dados da propriedade.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_id_de_tag' ),
			),
			'f3base_gtm_container_id'    => array(
				'rotulo'    => __( 'Google Tag Manager — ID do contêiner', 'f3base' ),
				'descricao' => __( 'Identificador do contêiner do Gerenciador de Tags.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, ele passa a ser o único caminho de medição do site: a página publica o contêiner, entrega os eventos a ele, e as etiquetas diretas do Analytics, da Meta e do LinkedIn deixam de ser publicadas — é assim que nada é contado duas vezes. Vazio, o site publica as etiquetas diretas de cada identificador preenchido nesta seção.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo, na forma que o próprio Google usa na documentação: GTM-XXXXXXX. O valor real aparece no painel do contêiner.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_id_de_tag' ),
			),
			'f3base_google_ads'          => array(
				'rotulo'    => __( 'Google Ads — conversão', 'f3base' ),
				'descricao' => __( 'A conta e a ação de conversão que recebem o clique no botão de contato.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'grupo',
				'padrao'    => array(
					'conversion_id'    => '',
					'conversion_label' => '',
				),
				'subcampos' => array(
					'conversion_id'    => array(
						'tipo'      => 'texto',
						'rotulo'    => __( 'ID de conversão', 'f3base' ),
						'descricao' => __( 'O identificador da conta de Google Ads que recebe a conversão.', 'f3base' ),
						'impacto'   => __( 'Preenchido junto com o rótulo, o clique no botão de contato passa a ser registrado como conversão na conta do Google Ads, e as campanhas passam a otimizar por ele em vez de otimizar por cliques. Faltando este campo, nenhuma conversão é enviada ao Google Ads e o investimento continua sendo decidido sem saber quem procurou contato.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo, na forma que o próprio Google usa na documentação: AW-000000000. O valor real aparece na ação de conversão da conta.', 'f3base' ),
					),
					'conversion_label' => array(
						'tipo'      => 'texto',
						'rotulo'    => __( 'Rótulo da conversão', 'f3base' ),
						'descricao' => __( 'A segunda metade do endereço da conversão: qual ação da conta recebe o clique.', 'f3base' ),
						'impacto'   => __( 'É ele que diz QUAL ação de conversão recebe o clique. Preenchido junto com o ID, a conversão chega à ação certa. Vazio, nada é enviado: um envio sem rótulo chegaria à conta sem dizer a que ação pertence, e o relatório de campanha não teria onde somá-lo.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: rotulo-da-acao-de-conversao. O valor real é gerado pelo Google junto com a ação e aparece ao lado do ID de conversão.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_google_ads' ),
			),
			'f3base_meta_pixel_id'       => array(
				'rotulo'    => __( 'Meta — Pixel', 'f3base' ),
				'descricao' => __( 'Identificador do Pixel usado por campanhas de Facebook e Instagram.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o site publica o Pixel da Meta e envia a ele as páginas vistas e o contato — é o que permite às campanhas de Facebook e Instagram saber o que aconteceu depois do clique no anúncio. Vazio, nenhum código da Meta existe na página e essas campanhas otimizam sem resultado de volta.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: 000000000000000 — somente dígitos. O valor real aparece no Gerenciador de Eventos da Meta.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_id_de_tag' ),
			),
			/*
			 * O TOKEN DA CONVERSIONS API É SEGREDO, e por isso ele mora AQUI e
			 * em lugar nenhum do `config/site.json`. O arquivo único viaja
			 * dentro do zip, é lido pela suíte e chega a quem faz o upload:
			 * segredo em arquivo que viaja é segredo copiado. Nenhum lote do
			 * implantador grava esta option, e a ausência dela no schema é a
			 * declaração disso. Quem a grava é o agente, pelo canal.
			 */
			'f3base_meta_capi_token'     => array(
				'rotulo'    => __( 'Meta — token do envio de servidor', 'f3base' ),
				'descricao' => __( 'Credencial do conjunto de dados do Pixel, usada para enviar o contato do servidor.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o contato passa a ser enviado também do servidor para a Meta, com o mesmo identificador de evento que o navegador manda — é essa identidade que faz os dois caminhos contarem uma conversão só, e é ela que recupera as conversões que o navegador perde por bloqueio ou por falha de rede. Vazio, existe apenas o envio pelo navegador, e o que ele perder está perdido.', 'f3base' ),
				'exemplo'   => __( 'Este campo não tem exemplo de valor, porque um valor de exemplo aqui seria uma credencial. O token é gerado no Gerenciador de Eventos da Meta, nas configurações do conjunto de dados do Pixel. Ele é o único campo desta tela que nunca viaja no arquivo de configuração do pacote: é gravado só aqui, ou pelo canal de manutenção.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_segredo_opaco' ),
			),
			'f3base_linkedin_partner_id' => array(
				'rotulo'    => __( 'LinkedIn — identificador de parceiro', 'f3base' ),
				'descricao' => __( 'Identificador da conta de anúncios do LinkedIn.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o site publica a etiqueta do LinkedIn e passa a registrar as páginas vistas por quem chega de campanhas de lá. Vazio, nenhum código do LinkedIn existe na página e as campanhas do canal ficam sem retorno de audiência.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: 0000000 — somente dígitos. O valor real aparece no Campaign Manager do LinkedIn.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_partner_id' ),
			),
			'f3base_linkedin_conversion_id' => array(
				'rotulo'    => __( 'LinkedIn — conversão', 'f3base' ),
				'descricao' => __( 'Identificador da conversão do LinkedIn disparada no clique do botão de contato.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o clique no botão de contato passa a ser registrado como conversão no LinkedIn, e as campanhas de lá passam a otimizar por contato. Vazio, o identificador de parceiro sozinho registra apenas visitas: nenhuma conversão é declarada.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: 00000000 — somente dígitos. O valor real é gerado ao criar a conversão no Campaign Manager do LinkedIn.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_partner_id' ),
			),
			'f3base_atribuicao'          => array(
				'rotulo'    => __( 'Origem do contato', 'f3base' ),
				'descricao' => __( 'Qual campanha leva o crédito pelo contato, e por quanto tempo ela o mantém.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'grupo',
				'padrao'    => array(
					'modelo'   => F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE,
					'ttl_dias' => 30,
				),
				'subcampos' => array(
					'modelo'   => array(
						'tipo'      => 'enum',
						'rotulo'    => __( 'Campanha que leva o crédito', 'f3base' ),
						'descricao' => __( 'A primeira que trouxe o visitante, ou a última antes do contato.', 'f3base' ),
						'opcoes'    => array(
							F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE => __( 'a primeira visita — a campanha que descobriu o cliente', 'f3base' ),
							'last-touch'  => __( 'a última visita — a campanha que fechou o contato', 'f3base' ),
						),
						'impacto'   => __( 'Escolher a primeira visita credita quem descobriu o cliente, e favorece campanhas de topo; escolher a última credita quem estava lá no momento do contato, e favorece campanhas de retomada. O relatório de cada canal muda com esta escolha, e comparar dois períodos com escolhas diferentes compara coisas diferentes.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: a primeira visita, que é o padrão deste site.', 'f3base' ),
					),
					'ttl_dias' => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Por quantos dias a origem é lembrada', 'f3base' ),
						'descricao' => __( 'Prazo em que a origem do visitante continua guardada no navegador dele.', 'f3base' ),
						'impacto'   => __( 'É a janela em que o visitante pode sumir e voltar sem perder a origem. Um prazo curto credita como direto quem voltou depois dele; um prazo longo mantém a campanha antiga levando o crédito muito depois de ela ter deixado de influenciar a decisão.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 30, o prazo que este site usa por padrão.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_atribuicao' ),
			),
			'f3base_verificacao_google'  => array(
				'rotulo'    => __( 'Verificação de domínio — Google', 'f3base' ),
				'descricao' => __( 'Código que comprova ao Google que este domínio é seu.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o site publica no cabeçalho a etiqueta que comprova a posse do domínio, e a propriedade do Search Console pode ser verificada — é o que destrava o relatório de busca e o envio de sitemap. Vazio, nenhuma etiqueta é publicada; a verificação por DNS continua sendo uma alternativa que dispensa este campo.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: valor-de-verificacao-do-console. O valor real é fornecido pelo Search Console ao escolher a verificação por etiqueta HTML.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_token_de_verificacao' ),
			),
			'f3base_verificacao_meta'    => array(
				'rotulo'    => __( 'Verificação de domínio — Meta', 'f3base' ),
				'descricao' => __( 'Código que comprova à Meta que este domínio é seu.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o site publica a etiqueta que reivindica o domínio no Gerenciador de Negócios — é o que permite controlar quem pode anunciar com links deste site e configurar eventos de página. Vazio, nenhuma etiqueta é publicada e o domínio permanece sem dono declarado para a Meta.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: valor-de-verificacao-do-dominio. O valor real é fornecido pelo Gerenciador de Negócios ao reivindicar o domínio.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_token_de_verificacao' ),
			),
			'f3base_consentimento'       => array(
				'rotulo'    => __( 'Consentimento', 'f3base' ),
				'descricao' => __( 'O que o site faz antes de o visitante decidir, e como ele muda de ideia depois.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_CONSENTIMENTO,
				'campo'     => 'grupo',
				'padrao'    => array(
					'padrao'                => 'pre-aprovado',
					'controle_rodape'       => true,
					'aviso_primeira_visita' => false,
					'ttl_dias'              => 180,
				),
				'subcampos' => array(
					'padrao'                => array(
						'tipo'      => 'enum',
						'rotulo'    => __( 'O que vale antes de o visitante decidir', 'f3base' ),
						'descricao' => __( 'A posição do site na primeira visita, antes de qualquer clique do visitante.', 'f3base' ),
						'opcoes'    => array(
							'pre-aprovado' => __( 'pré-aprovado — a medição começa e o visitante pode recusar', 'f3base' ),
							'negado'       => __( 'negado — nada é medido até o visitante aceitar', 'f3base' ),
						),
						'impacto'   => __( 'Em pré-aprovado, a medição começa na primeira visita e quem recusa interrompe a partir do clique: os números cobrem quase todo mundo. Em negado, nada é carregado até o aceite, e os números passam a cobrir só quem aceitou — a diferença aparece como queda de tráfego no relatório, sem que o tráfego tenha caído. A escolha é jurídica antes de ser técnica. O QUE A RECUSA TARDIA NÃO DESFAZ: ela vale do clique em diante e não apaga o que já foi enviado. Google Analytics e Google Ads recebem a recusa como atualização de consentimento e passam a operar sem armazenamento no dispositivo; o que já chegou ao Google permanece com ele. Pixel da Meta e Insight Tag do LinkedIn não têm mecanismo equivalente: se o script deles já carregou nesta página, recusar não o descarrega — ele fica ali até a navegação seguinte. O que este site garante a partir da recusa é que nenhum evento novo é enviado a eles, e que na página seguinte eles não voltam a ser carregados. Em negado nada disso chega a carregar, e é por isso que nesse modo o script de consentimento é servido bloqueando o carregamento da página: ali a ordem é a garantia, e ela custa os 5.085 bytes comprimidos desse script no caminho crítico da página.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: pré-aprovado, que é a posição deste site.', 'f3base' ),
					),
					'controle_rodape'       => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Link de revisão no rodapé', 'f3base' ),
						'descricao' => __( 'Instrumento permanente para o visitante rever a decisão dele.', 'f3base' ),
						'impacto'   => __( 'Ligado, toda página ganha no rodapé um link que reabre a decisão — é o caminho pelo qual quem aceitou pode recusar depois, e a demonstração de que a escolha é reversível. Desligado, o visitante que mudar de ideia não tem por onde: a decisão dele fica presa até o prazo abaixo vencer.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: ligado, que é como este site é entregue.', 'f3base' ),
					),
					'aviso_primeira_visita' => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Aviso na primeira visita', 'f3base' ),
						'descricao' => __( 'Faixa não bloqueante exibida a quem chega pela primeira vez.', 'f3base' ),
						'impacto'   => __( 'Ligado, quem chega pela primeira vez vê uma faixa na base da página avisando que o site mede a navegação; ela não bloqueia a leitura e não espera resposta. Desligado — como o site é entregue —, nenhuma faixa aparece, e o único ponto de decisão é o link do rodapé.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: desligado, que é como este site é entregue.', 'f3base' ),
					),
					'ttl_dias'              => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Por quantos dias a decisão vale', 'f3base' ),
						'descricao' => __( 'Prazo em que a recusa e o novo aceite continuam guardados no navegador.', 'f3base' ),
						'impacto'   => __( 'É o prazo em que a recusa continua sendo respeitada sem perguntar de novo. Vencido, o visitante volta à posição padrão do site e é medido outra vez até recusar de novo. Prazo curto pergunta demais; prazo longo mantém a decisão por mais tempo do que ela costuma ser lembrada.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 180, o prazo que este site usa por padrão.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_consentimento' ),
			),
			'f3base_retencao_meses'      => array(
				'rotulo'    => __( 'Guarda dos contatos recebidos (meses)', 'f3base' ),
				'descricao' => __( 'Por quanto tempo os registros de contato ficam no site antes da limpeza automática.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_PRIVACIDADE,
				'campo'     => 'inteiro',
				'padrao'    => 12,
				'impacto'   => __( 'É o prazo que a limpeza automática usa: passado ele, o registro do contato vai para a lixeira e depois é eliminado, com o número de registros anotado. Um prazo longo mantém disponível o histórico comercial e mantém dado pessoal guardado por mais tempo do que a finalidade justifica; um prazo curto faz o contrário. O prazo declarado aqui é o que a política de privacidade do site promete.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: 12, o prazo que este site usa por padrão.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_retencao_meses' ),
			),
			'f3base_comportamento'       => array(
				'rotulo'    => __( 'Resumo de comportamento no próprio site', 'f3base' ),
				'descricao' => __( 'O resumo que o site guarda por conta própria sobre como as páginas são usadas.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_PRIVACIDADE,
				'campo'     => 'grupo',
				'padrao'    => array(
					'ligado'                => true,
					'retencao_dias'         => 90,
					'retencao_eventos_dias' => 30,
					'dias_no_painel'        => 28,
				),
				'subcampos' => array(
					'ligado'         => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Guardar o resumo no site', 'f3base' ),
						'descricao' => __( 'O resumo é somado por dia e por página, sem identificar visitante.', 'f3base' ),
						'impacto'   => __( 'Ligado, ao sair de cada página o navegador envia uma vez os totais daquela visita — marcos de rolagem, seções vistas, cliques para fora, sinais de dificuldade, erros e tempo de carregamento — e o site os soma na linha do dia. É o que faz o quadro desta tela ter números sem depender de conta nenhuma de fornecedor. Desligado, nada é enviado nem guardado, e o quadro fica permanentemente vazio; o envio ao Google Analytics, quando configurado, não muda.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: ligado, que é como este site é entregue.', 'f3base' ),
					),
					'retencao_dias'  => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Por quantos dias o resumo é guardado', 'f3base' ),
						'descricao' => __( 'Prazo depois do qual as linhas antigas do resumo são apagadas pela limpeza automática.', 'f3base' ),
						'impacto'   => __( 'A limpeza que já roda no site apaga as linhas mais antigas que este prazo. Um prazo maior permite comparar períodos distantes e faz a tabela crescer; um prazo menor mantém a tabela pequena e impede a comparação com o mesmo mês do ano passado. Este quadro não é arquivo histórico: quem precisa de série longa a tem no Google Analytics.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 90, o prazo que este site usa por padrão.', 'f3base' ),
					),
					'retencao_eventos_dias' => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Por quantos dias o registro detalhado é guardado', 'f3base' ),
						'descricao' => __( 'Prazo do registro que guarda visitante, sessão e horário de cada acontecimento — mais curto que o do resumo, e nunca maior.', 'f3base' ),
						'impacto'   => __( 'O site guarda duas coisas diferentes. O RESUMO soma por dia e por página e não identifica ninguém; o REGISTRO DETALHADO guarda, para cada acontecimento, um apelido sorteado do navegador do visitante, o identificador da visita e o horário com precisão de milésimo — é ele que responde quanto tempo a pessoa levou para descer a página e se ela voltou e leu de novo. Por guardar isso, ele é dado pessoal, ainda que o apelido não diga quem a pessoa é: o prazo dele é curto de propósito e nunca pode passar o do resumo. Vencido o prazo, as linhas detalhadas são apagadas pela mesma limpeza automática e o resumo continua, porque ele não identifica ninguém.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 30, o prazo que este site usa por padrão.', 'f3base' ),
					),
					'dias_no_painel' => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Período mostrado no quadro', 'f3base' ),
						'descricao' => __( 'Quantos dias o quadro desta tela soma ao exibir os números.', 'f3base' ),
						'impacto'   => __( 'Muda apenas o que esta tela mostra, nunca o que é guardado. Um período curto revela o efeito de uma mudança recente; um período longo dilui o dia atípico e mostra a tendência. O número aparece ao lado de cada total, para que ninguém leia o quadro sem saber de quantos dias ele fala.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 28, o período que este site usa por padrão.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_comportamento' ),
			),
			'f3base_origem_confiavel'    => array(
				'rotulo'    => __( 'Como o site descobre o endereço do visitante', 'f3base' ),
				'descricao' => __( 'Quando o site está atrás de CDN ou proxy, o endereço real chega num cabeçalho.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_PRIVACIDADE,
				'campo'     => 'grupo',
				'padrao'    => array(
					'cabecalho' => '',
					'saltos'    => 1,
				),
				'subcampos' => array(
					'cabecalho' => array(
						'tipo'      => 'texto',
						'rotulo'    => __( 'Cabeçalho em que este site confia', 'f3base' ),
						'descricao' => __( 'Nome do cabeçalho que a sua CDN ou proxy escreve com o endereço do visitante.', 'f3base' ),
						'impacto'   => __( 'Preenchido, o limite de envios por visitante passa a contar cada visitante separadamente mesmo atrás de CDN. Vazio — que é o padrão e é a posição segura —, o site conta pelo endereço da conexão: atrás de CDN esse endereço é o mesmo para todo mundo, e um único visitante intenso pode esgotar o limite do site inteiro. Preencher com o nome errado é pior que deixar vazio: o visitante passaria a escolher em que balde ele conta.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: X-Forwarded-For, ou CF-Connecting-IP em sites atrás da Cloudflare. Só preencha o cabeçalho que a sua hospedagem confirmar.', 'f3base' ),
					),
					'saltos'    => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Quantos proxies seus estão na frente do site', 'f3base' ),
						'descricao' => __( 'Usado apenas quando o cabeçalho acima está preenchido.', 'f3base' ),
						'impacto'   => __( 'O endereço é lido descontando esta quantidade a partir do fim da lista do cabeçalho — que é a única parte escrita pelo seu próprio proxy. Um número menor que o real faz o site ler um endereço que o visitante escreveu; um número maior faz a leitura falhar e voltar ao endereço da conexão.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 1, quando há uma única CDN na frente do site.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_origem_confiavel' ),
			),
			'f3base_llms'                => array(
				'rotulo'    => __( 'Arquivo llms.txt para leitores automáticos', 'f3base' ),
				'descricao' => __( 'Índice curto que apresenta o site a assistentes e agentes que o leem.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_PRIVACIDADE,
				'campo'     => 'grupo',
				'padrao'    => array(
					'ligado'               => true,
					'introducao'           => '',
					'apresentacao'         => '',
					'modo'                 => F3Base_Llms::MODO_MISTO,
					'tipos'                => array( 'page', 'post' ),
					'full'                 => false,
					'indexavel'            => true,
					'politica_privacidade' => array(),
					'livres'               => array(),
				),
				'subcampos' => array(
					'ligado'     => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Publicar o llms.txt', 'f3base' ),
						'descricao' => __( 'Serve o arquivo em /llms.txt quando não existe um arquivo físico na raiz.', 'f3base' ),
						'impacto'   => __( 'Ligado, o endereço /llms.txt passa a responder com um índice curto das páginas escolhidas — é o que um assistente lê para citar o site com precisão em vez de resumir a página inicial. Desligado, o endereço deixa de responder e a leitura automática volta a depender de rastreamento comum. Um arquivo físico na raiz do site sempre tem precedência sobre esta chave.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: ligado, que é como este site é entregue.', 'f3base' ),
					),
					'introducao' => array(
						'tipo'      => 'textarea',
						'rotulo'    => __( 'Primeira frase do arquivo', 'f3base' ),
						'descricao' => __( 'Uma linha dizendo do que este site trata.', 'f3base' ),
						'impacto'   => __( 'Preenchida, é a primeira frase que um leitor automático encontra, e ela costuma virar o resumo citado. Vazia, o site usa a apresentação abaixo e, se ela também estiver vazia, a descrição cadastrada nas configurações gerais do WordPress — que serve, mas foi escrita para outra finalidade.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: "Consultoria de operações para indústrias de médio porte, com atendimento em todo o país."', 'f3base' ),
					),
					'apresentacao' => array(
						'tipo'      => 'textarea',
						'rotulo'    => __( 'Apresentação do negócio', 'f3base' ),
						'descricao' => __( 'Um parágrafo dizendo o que o site é, para quem e com que oferta.', 'f3base' ),
						'impacto'   => __( 'Preenchida, é o texto que um assistente lê antes da lista de links, e é dele que sai a frase com que ele apresenta o site a quem perguntar. É o campo de maior retorno do arquivo inteiro: sem ele, o arquivo é uma lista de endereços e o posicionamento do negócio precisa ser inferido das páginas. Vazia, o site cai para a primeira frase acima e, na falta dela, para a descrição cadastrada no WordPress.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: "Somos uma consultoria de operações industriais para fábricas de 50 a 500 funcionários. Fazemos diagnóstico de linha, redesenho de processo e acompanhamento de indicadores, com contrato mensal e equipe em campo."', 'f3base' ),
					),
					'modo'       => array(
						'tipo'      => 'enum',
						'rotulo'    => __( 'Como a lista é formada', 'f3base' ),
						'descricao' => __( 'A escolha entre listar só o que foi escolhido na entrega e listar também o que for publicado depois.', 'f3base' ),
						'opcoes'    => self::opcoes_de_modo_llms(),
						'impacto'   => __( 'Listando apenas o escolhido na entrega, o arquivo é previsível e toda página criada depois fica de fora para sempre. Listando apenas o publicado, ele acompanha o site e perde a ordem que alguém escolheu. Com os dois — que é como este site é entregue —, a curadoria vem primeiro e o resto entra em seguida: o arquivo continua vivo quando o site cresce, sem perder a ordem escolhida.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: os dois eixos juntos, com a lista escolhida na entrega à frente do que for publicado depois.', 'f3base' ),
					),
					'tipos'      => array(
						'tipo'      => 'lista',
						'rotulo'    => __( 'Tipos de conteúdo enumerados', 'f3base' ),
						'descricao' => __( 'Nomes separados por vírgula. Usado apenas nos modos que enumeram o conteúdo publicado.', 'f3base' ),
						'impacto'   => __( 'Cada tipo listado passa a ter o conteúdo publicado dele no arquivo. Tipo que este site não tem é descartado com o nome, em vez de gerar lista vazia em silêncio. Remover um tipo tira o conteúdo dele do arquivo na requisição seguinte, sem apagar nada do site.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: as páginas e os artigos do blog, que é como este site é entregue.', 'f3base' ),
					),
					'full'       => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Publicar também o texto integral', 'f3base' ),
						'descricao' => __( 'Serve /llms-full.txt com o conteúdo completo de cada item listado.', 'f3base' ),
						'impacto'   => __( 'Ligado, o endereço /llms-full.txt passa a responder com o texto integral das mesmas páginas — um assistente passa a citar o conteúdo em vez de só o endereço. É uma segunda cópia do site em texto puro, com o custo de banda e de superfície que isso traz. Desligado, que é o padrão, o endereço não responde: nenhum hook é registrado e a rota não existe.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: desligado, que é como este site é entregue.', 'f3base' ),
					),
					'indexavel'  => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Deixar o arquivo ser indexado', 'f3base' ),
						'descricao' => __( 'Controla o cabeçalho X-Robots-Tag na resposta do arquivo.', 'f3base' ),
						'impacto'   => __( 'Ligado, que é o padrão, a resposta NÃO leva X-Robots-Tag: noindex — o arquivo existe para ser lido por rastreador automático, e pedir para não indexá-lo faz um rastreador que respeita a diretiva deixar de usar o conteúdo. Desligado, o cabeçalho volta e o arquivo fica fora de índice, ao preço de ser ignorado por quem obedece à diretiva. Em ambos os casos a resposta continua sem cache.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: ligado, que é como este site é entregue.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_llms' ),
			),
			'f3base_redirects'           => array(
				'rotulo'    => __( 'Redirects declarados', 'f3base' ),
				'descricao' => __( 'Pares origem/destino do próprio site aplicados antes do 404, além do redirecionamento por slug antigo.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(),
				'sanitiza'  => array( __CLASS__, 'sanitiza_redirects' ),
			),
			'f3base_seo_entidade'        => array(
				'rotulo'    => __( 'Entidade de SEO', 'f3base' ),
				'descricao' => __( 'Propriedades de entidade e serviços usados para estender o grafo do plugin de SEO. sameAs vazio fica vazio.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(
					'nome'             => '',
					'same_as'          => array(),
					'area_servida'     => array(),
					'conhece_sobre'    => array(),
					'ponto_de_contato' => array(),
					'organizacao_mae'  => '',
					'servicos'         => array(),
					'faq_schema'       => false,
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_seo_entidade' ),
			),
			'f3base_cabecalhos'          => array(
				'rotulo'    => __( 'Cabeçalhos de resposta', 'f3base' ),
				'descricao' => __( 'Cabeçalhos de segurança emitidos no front-end. O COOP EMITIDO É O VALOR GRAVADO, dentro do vocabulário fechado do cabeçalho: fora de same-origin-allow-popups o navegador corta a relação com a janela que o CTA abre, o módulo fecha degradado NOMEANDO essa consequência, e nada é recusado. HSTS desligado por padrão.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(
					'x_content_type_options' => true,
					'x_frame_options'        => F3Base_Vocabulario::FRAME_MESMA_ORIGEM,
					'csp_frame_ancestors'    => "'self'",
					'referrer_policy'        => F3Base_Vocabulario::REFERRER_ESTRITO_ENTRE_SITES,
					'coop'                   => F3Base_Vocabulario::COOP_PERMITE_POPUP,
					'permissions_policy'     => F3Base_Vocabulario::PERMISSOES_NEGADAS,
					'hsts'                   => false,
					'hsts_max_age'           => 300,
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_cabecalhos' ),
			),
			'f3base_nav_id'              => array(
				'rotulo'    => __( 'ID da navegação', 'f3base' ),
				'descricao' => __( 'Post wp_navigation gerenciado. Estrutural: quebrar o vínculo derruba o menu do topo.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'inteiro',
				'padrao'    => 0,
				'sanitiza'  => array( __CLASS__, 'sanitiza_id_post' ),
			),
			'f3base_mcp_files_audit'     => array(
				'rotulo'    => __( 'Auditoria de escritas do canal MCP', 'f3base' ),
				'descricao' => __( 'Registro mantido pelo complemento do canal. Estrutural: leitura apenas.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(),
				'sanitiza'  => array( __CLASS__, 'sanitiza_lista_generica' ),
			),
			'f3base_atividade'           => array(
				'rotulo'    => __( 'Última atividade relevante', 'f3base' ),
				'descricao' => __( 'Carimbos do que cada módulo fez por último. Estado de execução, não configuração.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(),
				'autoload'  => false,
				'sanitiza'  => array( __CLASS__, 'sanitiza_atividade' ),
			),
			'f3base_journal_eliminacao'  => array(
				'rotulo'    => __( 'Journal de eliminação', 'f3base' ),
				'descricao' => __( 'Identificador, contagem, carimbo, operador e regime de cada eliminação. Nunca o conteúdo eliminado.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(),
				'autoload'  => false,
				'sanitiza'  => array( __CLASS__, 'sanitiza_journal' ),
			),
			'f3base_cadencia'            => array(
				'rotulo'    => __( 'Cadência do modo somente-relatório', 'f3base' ),
				'descricao' => __( 'Periodicidade, gatilho por número de ajustes, mecanismo e nome do hook. Gravada pelo implantador e LIDA pelo módulo de cadência do site-core, que é quem engancha o evento e conta os ajustes.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(
					'periodicidade'  => 'nenhuma',
					'apos_n_ajustes' => 0,
					'mecanismo'      => '',
					'hook'           => '',
				),
				'autoload'  => false,
				'sanitiza'  => array( __CLASS__, 'sanitiza_cadencia' ),
			),
			'f3base_cadencia_estado'     => array(
				'rotulo'    => __( 'Estado da cadência', 'f3base' ),
				'descricao' => __( 'Contador de ajustes desde o último relatório e carimbo previsto da próxima execução. Estado de execução, não configuração.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(
					'ajustes'  => 0,
					'previsto' => 0,
				),
				'autoload'  => false,
				'sanitiza'  => array( __CLASS__, 'sanitiza_cadencia_estado' ),
			),
			'f3base_endpoint_segredo'    => array(
				'rotulo'    => __( 'Segredo do token efêmero', 'f3base' ),
				'descricao' => __( 'Chave HMAC do token do endpoint de leads. Gerada na ativação; nunca exibida.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'segredo',
				'padrao'    => '',
				'autoload'  => false,
				'sanitiza'  => array( __CLASS__, 'sanitiza_segredo' ),
			),
		);

		/**
		 * Permite ao implantador ou ao complemento do canal declarar options
		 * gerenciadas adicionais sem editar o catálogo embutido.
		 *
		 * @param array<string,array<string,mixed>> $catalogo Catálogo declarado.
		 */
		$catalogo = apply_filters( 'f3base_options_catalogo', $catalogo );

		self::$catalogo = is_array( $catalogo ) ? $catalogo : array();

		return self::$catalogo;
	}

	/**
	 * Nomes das options gerenciadas.
	 *
	 * @return string[]
	 */
	public static function nomes(): array {
		return array_keys( self::catalogo() );
	}

	/**
	 * As options que são SEGREDO DO SITE — ÂNCORA declarada.
	 *
	 * O QUE ISTO DECLARA, e por que uma lista é melhor que um comentário. O
	 * `config/site.json` viaja dentro do zip: ele é lido pela suíte, entra no
	 * bundle e chega inteiro a quem faz o upload. Um segredo declarado ali é um
	 * segredo copiado para todo lugar por onde o pacote passa — e a cópia
	 * sobrevive a qualquer rotação da credencial, porque ninguém volta ao zip
	 * para apagá-la.
	 *
	 * As options desta lista, portanto, têm duas invariantes que valem para
	 * TODAS elas e que um detector cobra a cada rodada
	 * (`estatica.segredo_fora_da_configuracao`):
	 *
	 * 1. o nome NÃO aparece no arquivo único nem no schema — a ausência é a
	 *    declaração, e é ela que o detector mede;
	 * 2. NENHUM lote do implantador as grava — quem as grava é o agente, pelo
	 *    canal, ou o próprio site-core quando o segredo é gerado aqui dentro.
	 *
	 * `f3base_endpoint_segredo` está aqui pelo mesmo motivo, embora nasça dentro
	 * deste plugin: ele nunca deve poder ser declarado de fora.
	 *
	 * @return string[]
	 */
	public static function segredos_do_site(): array {
		return array(
			'f3base_meta_capi_token',
			'f3base_endpoint_segredo',
		);
	}

	/**
	 * Declaração de uma option do catálogo.
	 *
	 * @param string $nome Nome da option.
	 * @return array<string,mixed>|null Declaração, ou null quando não gerenciada.
	 */
	public static function declaracao( string $nome ): ?array {
		$catalogo = self::catalogo();

		return isset( $catalogo[ $nome ] ) ? $catalogo[ $nome ] : null;
	}

	/**
	 * Uma option é operável pelo operador na tela?
	 *
	 * A declaração do catálogo é o teto; `f3base_operaveis`, quando presente,
	 * restringe — o implantador pode fechar o que não quer aberto, nunca abrir
	 * o que o catálogo declarou estrutural.
	 *
	 * @param string $nome Nome da option.
	 * @return bool
	 */
	public static function operavel( string $nome ): bool {
		$declaracao = self::declaracao( $nome );
		if ( null === $declaracao || empty( $declaracao['operavel'] ) ) {
			return false;
		}

		$lista = get_option( self::OPTION_OPERAVEIS, null );
		if ( ! is_array( $lista ) || array() === $lista ) {
			return true;
		}

		return in_array( $nome, array_map( 'strval', $lista ), true );
	}

	/**
	 * Lê uma option gerenciada já normalizada pelo sanitizador declarado.
	 *
	 * Ler pelo sanitizador garante forma: chave ausente ou valor corrompido não
	 * vira notice no consumidor.
	 *
	 * @param string $nome Nome da option.
	 * @return mixed Valor normalizado.
	 */
	public static function ler( string $nome ) {
		$declaracao = self::declaracao( $nome );
		if ( null === $declaracao ) {
			return null;
		}

		$bruto = get_option( $nome, null );
		if ( null === $bruto ) {
			return $declaracao['padrao'];
		}

		return self::sanitizar( $nome, $bruto );
	}

	/**
	 * A option existe no banco?
	 *
	 * @param string $nome Nome da option.
	 * @return bool
	 */
	public static function existe( string $nome ): bool {
		return null !== get_option( $nome, null );
	}

	/**
	 * Sanitiza um valor com o sanitizador declarado da option.
	 *
	 * @param string $nome  Nome da option.
	 * @param mixed  $valor Valor bruto.
	 * @return mixed Valor normalizado.
	 */
	public static function sanitizar( string $nome, $valor ) {
		$declaracao = self::declaracao( $nome );
		if ( null === $declaracao ) {
			return null;
		}

		$sanitizador = isset( $declaracao['sanitiza'] ) ? $declaracao['sanitiza'] : null;
		if ( ! is_callable( $sanitizador ) ) {
			return $declaracao['padrao'];
		}

		return call_user_func( $sanitizador, $valor, $declaracao['padrao'] );
	}

	/**
	 * Grava uma option gerenciada e devolve a leitura de volta.
	 *
	 * @param string $nome   Nome da option.
	 * @param mixed  $valor  Valor bruto (será sanitizado).
	 * @param string $origem Procedência da escrita.
	 * @return array{ok:bool,lido:mixed,motivo:string} Resultado com leitura de volta.
	 */
	public static function gravar( string $nome, $valor, string $origem = self::ORIGEM_MANUAL ): array {
		$declaracao = self::declaracao( $nome );
		if ( null === $declaracao ) {
			return array(
				'ok'     => false,
				'lido'   => null,
				'motivo' => sprintf(
					/* translators: %s: nome da option. */
					__( 'Option %s não é gerenciada pelo site-core: escrita recusada.', 'f3base' ),
					$nome
				),
			);
		}

		$normalizado = self::sanitizar( $nome, $valor );
		$autoload    = array_key_exists( 'autoload', $declaracao ) ? (bool) $declaracao['autoload'] : true;

		self::escrever( $nome, $normalizado, $autoload );

		$lido = self::ler( $nome );

		$conferiu = self::equivalente( $normalizado, $lido );
		$motivo   = '';

		if ( ! $conferiu ) {
			$motivo = sprintf(
				/* translators: %s: nome da option. */
				__( 'Leitura de volta divergiu do valor gravado em %s.', 'f3base' ),
				$nome
			);
		} elseif ( ! self::equivalente( $valor, $lido ) && is_scalar( $valor ) ) {
			$motivo = sprintf(
				/* translators: %s: nome da option. */
				__( 'Valor normalizado pela sanitização de %s antes da gravação.', 'f3base' ),
				$nome
			);
		}

		if ( self::OPTION_PROVENIENCIA !== $nome ) {
			self::registrar_proveniencia( $nome, $origem );
		}

		return array(
			'ok'     => $conferiu,
			'lido'   => $lido,
			'motivo' => $motivo,
		);
	}

	/**
	 * Remove uma option gerenciada. Ponto único de `delete_option`.
	 *
	 * @param string $nome Nome da option.
	 * @return bool Verdadeiro quando a option deixou de existir.
	 */
	public static function remover( string $nome ): bool {
		if ( null === self::declaracao( $nome ) ) {
			return false;
		}

		delete_option( $nome );

		return ! self::existe( $nome );
	}

	/**
	 * Procedência conhecida de uma option gerenciada.
	 *
	 * @param string $nome Nome da option.
	 * @return string Uma das constantes de origem.
	 */
	public static function proveniencia( string $nome ): string {
		$registro = get_option( self::OPTION_PROVENIENCIA, array() );

		if ( is_array( $registro ) && isset( $registro[ $nome ] ) ) {
			$entrada = $registro[ $nome ];
			$origem  = is_array( $entrada ) && isset( $entrada['origem'] ) ? (string) $entrada['origem'] : (string) $entrada;

			if ( in_array( $origem, array( self::ORIGEM_IMPLANTADOR, self::ORIGEM_MANUAL, self::ORIGEM_PADRAO ), true ) ) {
				return $origem;
			}
		}

		return self::existe( $nome ) ? self::ORIGEM_IMPLANTADOR : self::ORIGEM_PADRAO;
	}

	/**
	 * Carimbo da última escrita conhecida de uma option.
	 *
	 * @param string $nome Nome da option.
	 * @return int Timestamp UTC, ou 0 quando desconhecido.
	 */
	public static function carimbo( string $nome ): int {
		$registro = get_option( self::OPTION_PROVENIENCIA, array() );

		if ( is_array( $registro ) && isset( $registro[ $nome ] ) && is_array( $registro[ $nome ] ) && isset( $registro[ $nome ]['em'] ) ) {
			return (int) $registro[ $nome ]['em'];
		}

		return 0;
	}

	/**
	 * Rótulo humano de uma procedência.
	 *
	 * @param string $origem Constante de origem.
	 * @return string
	 */
	public static function rotulo_origem( string $origem ): string {
		switch ( $origem ) {
			case self::ORIGEM_IMPLANTADOR:
				return __( 'implantador', 'f3base' );
			case self::ORIGEM_MANUAL:
				return __( 'edição manual', 'f3base' );
			default:
				return __( 'padrão embutido (option ausente)', 'f3base' );
		}
	}

	/**
	 * Escrita física. ÚNICO ponto de `update_option` do plugin.
	 *
	 * @param string $nome     Nome da option.
	 * @param mixed  $valor    Valor já sanitizado.
	 * @param bool   $autoload Carregar automaticamente.
	 * @return void
	 */
	private static function escrever( string $nome, $valor, bool $autoload ): void {
		update_option( $nome, $valor, $autoload );
	}

	/**
	 * Registra a procedência de uma escrita.
	 *
	 * @param string $nome   Nome da option.
	 * @param string $origem Procedência.
	 * @return void
	 */
	private static function registrar_proveniencia( string $nome, string $origem ): void {
		$permitidas = array( self::ORIGEM_IMPLANTADOR, self::ORIGEM_MANUAL, self::ORIGEM_PADRAO );
		if ( ! in_array( $origem, $permitidas, true ) ) {
			$origem = self::ORIGEM_MANUAL;
		}

		$registro = get_option( self::OPTION_PROVENIENCIA, array() );
		if ( ! is_array( $registro ) ) {
			$registro = array();
		}

		$registro[ $nome ] = array(
			'origem' => $origem,
			'em'     => time(),
		);

		self::escrever( self::OPTION_PROVENIENCIA, $registro, true );
	}

	/**
	 * Comparação tolerante a ordem de chaves para a leitura de volta.
	 *
	 * Pública porque a cadência do modo somente-relatório relê as options
	 * gravadas para saber se alguma passou a divergir depois da entrega: fossem
	 * duas implementações de equivalência, a releitura poderia acusar
	 * divergência onde a gravação tinha conferido, e vice-versa.
	 *
	 * @param mixed $a Valor gravado.
	 * @param mixed $b Valor lido.
	 * @return bool
	 */
	public static function equivalente( $a, $b ): bool {
		if ( is_array( $a ) && is_array( $b ) ) {
			return wp_json_encode( self::ordenar( $a ) ) === wp_json_encode( self::ordenar( $b ) );
		}

		return $a === $b;
	}

	/**
	 * Ordena arrays associativos recursivamente para comparação estável.
	 *
	 * @param array<mixed> $valor Array de entrada.
	 * @return array<mixed>
	 */
	private static function ordenar( array $valor ): array {
		ksort( $valor );

		foreach ( $valor as $chave => $item ) {
			if ( is_array( $item ) ) {
				$valor[ $chave ] = self::ordenar( $item );
			}
		}

		return $valor;
	}

	/* ------------------------------------------------------------------ *
	 * Sanitizadores declarados
	 * ------------------------------------------------------------------ */

	/**
	 * PRESERVA as chaves que este pacote não conhece.
	 *
	 * A REGRA DA 1.1.0, e ela tem um lado só: **normaliza o conhecido, preserva
	 * o desconhecido.** Até a 1.0.19 todo sanitizador de grupo RECONSTRUÍA o
	 * array a partir das chaves declaradas, e o efeito estava medido: o agente
	 * de manutenção acrescentava `telefone` a `f3base_contato` pelo canal MCP, a
	 * escrita entrava no banco, e a primeira LEITURA a devolvia sem a chave —
	 * apagada em silêncio, sem erro, sem log, sem ninguém para acusar. Sob a
	 * premissa de que toda modificação futura é do agente, um sanitizador que
	 * descarta o que não conhece é um sanitizador que desfaz trabalho alheio.
	 *
	 * O que NÃO muda: a chave conhecida continua passando pela normalização
	 * declarada. Preservar o desconhecido não é aceitar qualquer coisa — o valor
	 * desconhecido é sanitizado como dado (texto, número, booleano ou lista
	 * deles), e a chave é reduzida ao alfabeto de um nome de chave.
	 *
	 * @param array<string,mixed> $normalizado Valor já normalizado pelo sanitizador.
	 * @param mixed               $bruto       Valor bruto, como chegou.
	 * @return array<string,mixed>
	 */
	public static function preservar_desconhecidas( array $normalizado, $bruto ): array {
		if ( ! is_array( $bruto ) ) {
			return $normalizado;
		}

		foreach ( $bruto as $chave => $valor ) {
			$chave = self::chave_preservavel( (string) $chave );

			if ( '' === $chave || array_key_exists( $chave, $normalizado ) ) {
				continue;
			}

			$normalizado[ $chave ] = self::sanitiza_desconhecido( $valor );
		}

		return $normalizado;
	}

	/**
	 * Reduz uma chave desconhecida ao alfabeto de um nome de chave.
	 *
	 * Chave vazia depois da redução não é preservada: nome que não sobrou não é
	 * nome, e gravar sob `''` é perder o valor de outro jeito.
	 *
	 * @param string $chave Chave bruta.
	 * @return string Chave reduzida, ou vazia quando não sobrou nome.
	 */
	private static function chave_preservavel( string $chave ): string {
		$limpo = preg_replace( '/[^A-Za-z0-9_.:\-]/', '', $chave );

		return is_string( $limpo ) ? substr( $limpo, 0, 120 ) : '';
	}

	/**
	 * Sanitiza um valor DESCONHECIDO como dado.
	 *
	 * Escalares mantêm o tipo; texto com quebra de linha passa pelo sanitizador
	 * de área de texto, e o de uma linha pelo de campo. Lista é percorrida até a
	 * profundidade declarada — estrutura mais funda que isso deixa de ser
	 * configuração e vira arquivo, e arquivo tem outro lugar.
	 *
	 * @param mixed $valor      Valor bruto.
	 * @param int   $profundeza Profundidade restante.
	 * @return mixed
	 */
	private static function sanitiza_desconhecido( $valor, int $profundeza = 6 ) {
		if ( is_bool( $valor ) || is_int( $valor ) || is_float( $valor ) ) {
			return $valor;
		}

		if ( is_array( $valor ) ) {
			if ( $profundeza <= 0 ) {
				return array();
			}

			$saida = array();

			foreach ( $valor as $chave => $item ) {
				$limpa = is_int( $chave ) ? $chave : self::chave_preservavel( (string) $chave );

				if ( '' === $limpa ) {
					continue;
				}

				$saida[ $limpa ] = self::sanitiza_desconhecido( $item, $profundeza - 1 );
			}

			return $saida;
		}

		if ( null === $valor || is_object( $valor ) ) {
			return '';
		}

		$texto = (string) $valor;

		return str_contains( $texto, "\n" ) ? sanitize_textarea_field( $texto ) : sanitize_text_field( $texto );
	}

	/**
	 * Sanitiza `f3base_contato`.
	 *
	 * @param mixed                $valor  Valor bruto.
	 * @param array<string,string> $padrao Padrão declarado.
	 * @return array<string,string>
	 */
	public static function sanitiza_contato( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$e164 = isset( $valor['whatsapp_e164'] ) ? preg_replace( '/[^0-9]/', '', (string) $valor['whatsapp_e164'] ) : '';
		$e164 = is_string( $e164 ) ? substr( $e164, 0, 15 ) : '';

		if ( '' !== $e164 && strlen( $e164 ) < 8 ) {
			$e164 = '';
		}

		return self::preservar_desconhecidas(
			array(
				'whatsapp_e164'   => $e164,
				'email_leads'     => isset( $valor['email_leads'] ) ? sanitize_email( (string) $valor['email_leads'] ) : $padrao['email_leads'],
				'mensagem_padrao' => isset( $valor['mensagem_padrao'] ) ? sanitize_textarea_field( (string) $valor['mensagem_padrao'] ) : $padrao['mensagem_padrao'],
			),
			$valor
		);
	}

	/**
	 * Sanitiza `f3base_consentimento`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_consentimento( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$politica = isset( $valor['padrao'] ) ? sanitize_key( (string) $valor['padrao'] ) : $padrao['padrao'];
		if ( ! in_array( $politica, array( 'pre-aprovado', 'negado' ), true ) ) {
			$politica = 'pre-aprovado';
		}

		$ttl = isset( $valor['ttl_dias'] ) ? (int) $valor['ttl_dias'] : (int) $padrao['ttl_dias'];
		$ttl = max( 1, min( 3650, $ttl ) );

		return self::preservar_desconhecidas(
			array(
				'padrao'                => $politica,
				'controle_rodape'       => isset( $valor['controle_rodape'] ) ? (bool) $valor['controle_rodape'] : (bool) $padrao['controle_rodape'],
				'aviso_primeira_visita' => isset( $valor['aviso_primeira_visita'] ) ? (bool) $valor['aviso_primeira_visita'] : (bool) $padrao['aviso_primeira_visita'],
				'ttl_dias'              => $ttl,
			),
			$valor
		);
	}

	/**
	 * Sanitiza `f3base_atribuicao`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_atribuicao( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$modelo = isset( $valor['modelo'] ) ? sanitize_key( (string) $valor['modelo'] ) : (string) $padrao['modelo'];
		if ( ! in_array( $modelo, F3Base_Vocabulario::modelos_de_atribuicao(), true ) ) {
			$modelo = F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE;
		}

		$ttl = isset( $valor['ttl_dias'] ) ? (int) $valor['ttl_dias'] : (int) $padrao['ttl_dias'];

		return self::preservar_desconhecidas(
			array(
				'modelo'   => $modelo,
				'ttl_dias' => max( 1, min( 3650, $ttl ) ),
			),
			$valor
		);
	}

	/**
	 * Sanitiza `f3base_retencao_meses`.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return int
	 */
	public static function sanitiza_retencao_meses( $valor, $padrao ): int {
		$meses = is_scalar( $valor ) ? (int) $valor : (int) $padrao;

		return max( 1, min( 600, $meses ) );
	}

	/**
	 * Sanitiza o Partner ID do LinkedIn.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_partner_id( $valor, $padrao ): string {
		unset( $padrao );

		$id = is_scalar( $valor ) ? preg_replace( '/[^0-9]/', '', (string) $valor ) : '';

		return is_string( $id ) ? substr( $id, 0, 20 ) : '';
	}

	/**
	 * Sanitiza um IDENTIFICADOR DE TAG de terceiro.
	 *
	 * Reduz ao alfabeto que os quatro fornecedores usam nos próprios
	 * identificadores — letra, dígito, hífen e sublinhado — e corta no limite
	 * declarado. NÃO recusa por formato: um `G-` faltando não é motivo para o
	 * pacote apagar o que alguém gravou, e apagar em silêncio é justamente o que
	 * esta release parou de fazer. Quem NOMEIA o formato errado é o módulo de
	 * tracking, no estado que o operador lê.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_id_de_tag( $valor, $padrao ): string {
		unset( $padrao );

		if ( ! is_scalar( $valor ) ) {
			return '';
		}

		$limpo = preg_replace( '/[^A-Za-z0-9_-]/', '', trim( (string) $valor ) );

		return is_string( $limpo ) ? substr( $limpo, 0, 40 ) : '';
	}

	/**
	 * Sanitiza `f3base_google_ads`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_google_ads( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		return self::preservar_desconhecidas(
			array(
				'conversion_id'    => isset( $valor['conversion_id'] ) ? self::sanitiza_id_de_tag( $valor['conversion_id'], '' ) : (string) $padrao['conversion_id'],
				'conversion_label' => isset( $valor['conversion_label'] ) ? self::sanitiza_id_de_tag( $valor['conversion_label'], '' ) : (string) $padrao['conversion_label'],
			),
			$valor
		);
	}

	/**
	 * Sanitiza um SEGREDO OPACO — hoje, o token da Conversions API da Meta.
	 *
	 * Distinto de `sanitiza_segredo()`, que trata do HMAC hexadecimal gerado
	 * por este pacote e pode reduzir ao alfabeto que ele mesmo produz. Este
	 * valor vem de FORA e o alfabeto é do fornecedor.
	 *
	 * Ele não tem forma pública declarada pelo fornecedor, e inventar uma seria
	 * pior que não ter nenhuma: um token legítimo recusado por um formato que
	 * este pacote imaginou é uma medição que some sem ninguém saber por quê. O
	 * que a sanitização faz é o que dá para fazer com segurança — tirar espaço
	 * das pontas e cortar no teto declarado — e nada além disso.
	 *
	 * O valor NÃO é impresso em página nenhuma: ele viaja no corpo da chamada à
	 * Meta e no dump sanitizado do relatório, que já reduz segredo a marcador.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_segredo_opaco( $valor, $padrao ): string {
		unset( $padrao );

		if ( ! is_scalar( $valor ) ) {
			return '';
		}

		return substr( trim( (string) $valor ), 0, 512 );
	}

	/**
	 * Sanitiza um token de VERIFICAÇÃO DE DOMÍNIO.
	 *
	 * NÃO REDUZ O ALFABETO, e essa é a diferença deliberada em relação a
	 * `sanitiza_id_de_tag()`. Um ID de tag tem forma pública e conhecida; um
	 * token de verificação é opaco, e o fornecedor pode mudar o alfabeto dele
	 * sem avisar ninguém. Filtrar caractere aqui seria apagar em silêncio metade
	 * de um valor válido — e produzir uma verificação que nunca fecha sem uma
	 * linha dizendo por quê. O que sai fora da forma é PRESERVADO e avisado pelo
	 * módulo, e a saída passa por `esc_attr()` no ponto em que vira atributo.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_token_de_verificacao( $valor, $padrao ): string {
		unset( $padrao );

		if ( ! is_scalar( $valor ) ) {
			return '';
		}

		return substr( trim( (string) $valor ), 0, F3Base_Modulo_Verificacao_Dominio::TETO );
	}

	/**
	 * Sanitiza `f3base_llms`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_llms( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		return self::preservar_desconhecidas(
			array(
				'ligado'               => isset( $valor['ligado'] ) ? (bool) $valor['ligado'] : (bool) $padrao['ligado'],
				'introducao'           => isset( $valor['introducao'] ) ? sanitize_textarea_field( (string) $valor['introducao'] ) : '',
				'apresentacao'         => isset( $valor['apresentacao'] ) ? sanitize_textarea_field( (string) $valor['apresentacao'] ) : (string) ( $padrao['apresentacao'] ?? '' ),
				/*
				 * O MODO É VALIDADO CONTRA OS SÍMBOLOS DECLARADOS, e a lista sai
				 * de `F3Base_Llms::modos()`: valor fora do vocabulário volta ao
				 * padrão em vez de virar um modo que ninguém implementou.
				 */
				'modo'                 => self::sanitiza_modo_llms( $valor['modo'] ?? null, (string) ( $padrao['modo'] ?? F3Base_Llms::MODO_MISTO ) ),
				/*
				 * OS TIPOS SÃO VALIDADOS CONTRA A INSTALAÇÃO, nunca contra uma
				 * lista literal: o conjunto válido é o dos tipos públicos que
				 * este site tem agora, e tipo que o agente criar depois passa a
				 * ser aceito sem release nova.
				 */
				'tipos'                => self::sanitiza_tipos_llms( $valor['tipos'] ?? null, (array) ( $padrao['tipos'] ?? array() ) ),
				'full'                 => isset( $valor['full'] ) ? (bool) $valor['full'] : (bool) ( $padrao['full'] ?? false ),
				'indexavel'            => isset( $valor['indexavel'] ) ? (bool) $valor['indexavel'] : (bool) ( $padrao['indexavel'] ?? true ),
				'politica_privacidade' => isset( $valor['politica_privacidade'] ) ? self::sanitiza_item_llms( $valor['politica_privacidade'] ) : array(),
				'livres'               => isset( $valor['livres'] ) && is_array( $valor['livres'] )
					? array_values(
						array_filter(
							array_map( array( __CLASS__, 'sanitiza_item_llms' ), $valor['livres'] ),
							static fn ( array $item ): bool => '' !== $item['url']
						)
					)
					: array(),
			),
			$valor
		);
	}

	/**
	 * Sanitiza um item de listagem do llms.txt.
	 *
	 * O `id` viaja junto porque o dedupe entre a curadoria e a enumeração é POR
	 * ID: URL muda quando o slug muda, e o mesmo conteúdo sairia duas vezes no
	 * arquivo sem que nada acusasse.
	 *
	 * @param mixed $item Item bruto.
	 * @return array{id:int,titulo:string,url:string,descricao:string}
	 */
	public static function sanitiza_item_llms( $item ): array {
		$item = is_array( $item ) ? $item : array();

		return array(
			'id'        => isset( $item['id'] ) ? max( 0, (int) $item['id'] ) : 0,
			'titulo'    => isset( $item['titulo'] ) ? sanitize_text_field( (string) $item['titulo'] ) : '',
			'url'       => isset( $item['url'] ) ? esc_url_raw( (string) $item['url'] ) : '',
			'descricao' => isset( $item['descricao'] ) ? sanitize_text_field( (string) $item['descricao'] ) : '',
		);
	}

	/**
	 * As OPÇÕES do modo de seleção, com o rótulo que a tela mostra.
	 *
	 * As chaves saem de `F3Base_Llms::modos()` — o vocabulário fechado mora num
	 * lugar só, e uma lista escrita aqui seria a segunda declaração do mesmo
	 * conjunto, divergindo no dia em que um modo entrar ou sair.
	 *
	 * @return array<string,string>
	 */
	public static function opcoes_de_modo_llms(): array {
		$rotulos = array(
			F3Base_Llms::MODO_CURADA     => __( 'apenas a lista escolhida na entrega', 'f3base' ),
			F3Base_Llms::MODO_AUTOMATICA => __( 'apenas o conteúdo publicado dos tipos abaixo', 'f3base' ),
			F3Base_Llms::MODO_MISTO      => __( 'os dois: a lista escolhida primeiro, o publicado em seguida', 'f3base' ),
		);

		$opcoes = array();

		foreach ( F3Base_Llms::modos() as $modo ) {
			$opcoes[ $modo ] = $rotulos[ $modo ] ?? $modo;
		}

		return $opcoes;
	}

	/**
	 * MODO de seleção do llms.txt, contra o vocabulário declarado.
	 *
	 * @param mixed  $valor  Valor bruto.
	 * @param string $padrao Modo padrão.
	 * @return string
	 */
	public static function sanitiza_modo_llms( $valor, string $padrao ): string {
		$modo  = is_scalar( $valor ) ? trim( (string) $valor ) : '';
		$modos = F3Base_Llms::modos();

		if ( in_array( $modo, $modos, true ) ) {
			return $modo;
		}

		return in_array( $padrao, $modos, true ) ? $padrao : F3Base_Llms::MODO_MISTO;
	}

	/**
	 * TIPOS enumerados do llms.txt, contra os tipos públicos desta instalação.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Tipos padrão.
	 * @return array<int,string>
	 */
	public static function sanitiza_tipos_llms( $valor, array $padrao ): array {
		if ( is_string( $valor ) ) {
			/* A TELA ENTREGA UMA LINHA, e a configuração entrega uma lista: as duas formas chegam aqui. */
			$valor = array_map( 'trim', explode( ',', $valor ) );
		}

		$declarados = is_array( $valor ) ? $valor : $padrao;
		$publicos   = array_values( (array) get_post_types( array( 'public' => true ), 'names' ) );

		return F3Base_Llms::tipos_validos( array_map( 'strval', $declarados ), array_map( 'strval', $publicos ) )['tipos'];
	}

	/**
	 * Sanitiza `f3base_redirects`.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<int,array{de:string,para:string,status:int}>
	 */
	public static function sanitiza_redirects( $valor, array $padrao ): array {
		unset( $padrao );

		if ( ! is_array( $valor ) ) {
			return array();
		}

		$saida = array();

		foreach ( $valor as $regra ) {
			if ( ! is_array( $regra ) ) {
				continue;
			}

			$de   = isset( $regra['de'] ) ? self::sanitiza_caminho( (string) $regra['de'] ) : '';
			$para = isset( $regra['para'] ) ? self::sanitiza_caminho( (string) $regra['para'] ) : '';

			if ( '' === $de || '' === $para || $de === $para ) {
				continue;
			}

			$status = isset( $regra['status'] ) ? (int) $regra['status'] : 301;
			if ( ! in_array( $status, array( 301, 302, 307, 308, 410 ), true ) ) {
				$status = 301;
			}

			$saida[] = self::preservar_desconhecidas(
				array(
					'de'     => $de,
					'para'   => $para,
					'status' => $status,
				),
				$regra
			);
		}

		return $saida;
	}

	/**
	 * Normaliza um caminho relativo do próprio site.
	 *
	 * @param string $caminho Caminho bruto.
	 * @return string Caminho começando por barra, ou vazio quando inválido.
	 */
	public static function sanitiza_caminho( string $caminho ): string {
		$caminho = trim( $caminho );
		if ( '' === $caminho ) {
			return '';
		}

		if ( str_contains( $caminho, '://' ) || str_starts_with( $caminho, '//' ) ) {
			return '';
		}

		if ( str_contains( $caminho, '..' ) ) {
			return '';
		}

		$partes = wp_parse_url( $caminho );
		if ( ! is_array( $partes ) || isset( $partes['host'] ) ) {
			return '';
		}

		$limpo = isset( $partes['path'] ) ? (string) $partes['path'] : '';
		if ( '' === $limpo ) {
			return '';
		}

		$limpo = '/' . ltrim( sanitize_text_field( rawurldecode( $limpo ) ), '/' );

		if ( isset( $partes['query'] ) && '' !== $partes['query'] ) {
			$limpo .= '?' . sanitize_text_field( (string) $partes['query'] );
		}

		return substr( $limpo, 0, 500 );
	}

	/**
	 * Sanitiza `f3base_seo_entidade`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_seo_entidade( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$texto_lista = static function ( $lista ): array {
			if ( ! is_array( $lista ) ) {
				return array();
			}

			return array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'strval', $lista ) ), static fn ( string $item ): bool => '' !== $item ) );
		};

		$urls = array();
		if ( isset( $valor['same_as'] ) && is_array( $valor['same_as'] ) ) {
			foreach ( $valor['same_as'] as $url ) {
				$limpa = esc_url_raw( (string) $url );
				if ( '' !== $limpa ) {
					$urls[] = $limpa;
				}
			}
		}

		$contato = array();
		if ( isset( $valor['ponto_de_contato'] ) && is_array( $valor['ponto_de_contato'] ) ) {
			foreach ( $valor['ponto_de_contato'] as $ponto ) {
				if ( ! is_array( $ponto ) ) {
					continue;
				}
				$contato[] = array(
					'tipo'     => isset( $ponto['tipo'] ) ? sanitize_text_field( (string) $ponto['tipo'] ) : 'customer support',
					'telefone' => isset( $ponto['telefone'] ) ? sanitize_text_field( (string) $ponto['telefone'] ) : '',
					'email'    => isset( $ponto['email'] ) ? sanitize_email( (string) $ponto['email'] ) : '',
					'idiomas'  => isset( $ponto['idiomas'] ) ? $texto_lista( $ponto['idiomas'] ) : array(),
				);
			}
		}

		$servicos = array();
		if ( isset( $valor['servicos'] ) && is_array( $valor['servicos'] ) ) {
			foreach ( $valor['servicos'] as $servico ) {
				if ( ! is_array( $servico ) ) {
					continue;
				}
				$nome = isset( $servico['nome'] ) ? sanitize_text_field( (string) $servico['nome'] ) : '';
				if ( '' === $nome ) {
					continue;
				}
				$servicos[] = array(
					'nome'         => $nome,
					'descricao'    => isset( $servico['descricao'] ) ? sanitize_text_field( (string) $servico['descricao'] ) : '',
					'url'          => isset( $servico['url'] ) ? esc_url_raw( (string) $servico['url'] ) : '',
					'tipo_servico' => isset( $servico['tipo_servico'] ) ? sanitize_text_field( (string) $servico['tipo_servico'] ) : '',
					'area_servida' => isset( $servico['area_servida'] ) ? $texto_lista( $servico['area_servida'] ) : array(),
				);
			}
		}

		return self::preservar_desconhecidas(
			array(
				'nome'             => isset( $valor['nome'] ) ? sanitize_text_field( (string) $valor['nome'] ) : (string) $padrao['nome'],
				'same_as'          => $urls,
				'area_servida'     => isset( $valor['area_servida'] ) ? $texto_lista( $valor['area_servida'] ) : array(),
				'conhece_sobre'    => isset( $valor['conhece_sobre'] ) ? $texto_lista( $valor['conhece_sobre'] ) : array(),
				'ponto_de_contato' => $contato,
				'organizacao_mae'  => isset( $valor['organizacao_mae'] ) ? sanitize_text_field( (string) $valor['organizacao_mae'] ) : '',
				'servicos'         => $servicos,
				'faq_schema'       => isset( $valor['faq_schema'] ) ? (bool) $valor['faq_schema'] : (bool) $padrao['faq_schema'],
			),
			$valor
		);
	}

	/**
	 * Sanitiza `f3base_cabecalhos`.
	 *
	 * COOP DEIXOU DE SER LITERAL NA 1.1.0. Até a 1.0.19 esta função devolvia
	 * `coop` escrito à mão no catálogo, IGNORANDO o valor
	 * armazenado: quem gravasse outro valor pelo canal lia de volta o valor do
	 * pacote e ficava sem saber por quê — a leitura de volta conferia contra o
	 * que a própria sanitização tinha imposto. Agora o valor gravado é o que
	 * sai, dentro do vocabulário fechado do cabeçalho.
	 *
	 * O que o pacote continua a fazer: `same-origin` corta a janela aberta pelo
	 * fluxo de leads do WhatsApp, e o módulo de cabeçalhos fecha DEGRADADO
	 * nomeando essa consequência. Nomear a consequência é o instrumento; recusar
	 * a escrita não é.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_cabecalhos( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$frame = isset( $valor['x_frame_options'] ) ? strtoupper( sanitize_text_field( (string) $valor['x_frame_options'] ) ) : (string) $padrao['x_frame_options'];
		if ( ! in_array( $frame, F3Base_Vocabulario::politicas_de_frame(), true ) ) {
			$frame = F3Base_Vocabulario::FRAME_MESMA_ORIGEM;
		}

		$referrer  = isset( $valor['referrer_policy'] ) ? sanitize_text_field( (string) $valor['referrer_policy'] ) : (string) $padrao['referrer_policy'];
		$aceitos = F3Base_Vocabulario::politicas_de_referrer();
		$referrer  = in_array( $referrer, $aceitos, true ) ? $referrer : (string) $padrao['referrer_policy'];
		$max_age   = isset( $valor['hsts_max_age'] ) ? (int) $valor['hsts_max_age'] : (int) $padrao['hsts_max_age'];
		$max_age   = max( 0, min( 63072000, $max_age ) );
		$permissoes = isset( $valor['permissions_policy'] ) ? sanitize_text_field( (string) $valor['permissions_policy'] ) : (string) $padrao['permissions_policy'];

		$coop = isset( $valor['coop'] ) ? strtolower( sanitize_text_field( (string) $valor['coop'] ) ) : (string) $padrao['coop'];
		$coop = in_array( $coop, self::coop_aceitos(), true ) ? $coop : (string) $padrao['coop'];

		return self::preservar_desconhecidas(
			array(
				'x_content_type_options' => isset( $valor['x_content_type_options'] ) ? (bool) $valor['x_content_type_options'] : (bool) $padrao['x_content_type_options'],
				'x_frame_options'        => $frame,
				'csp_frame_ancestors'    => isset( $valor['csp_frame_ancestors'] ) ? sanitize_text_field( (string) $valor['csp_frame_ancestors'] ) : (string) $padrao['csp_frame_ancestors'],
				'referrer_policy'        => $referrer,
				'coop'                   => $coop,
				'permissions_policy'     => $permissoes,
				'hsts'                   => isset( $valor['hsts'] ) ? (bool) $valor['hsts'] : (bool) $padrao['hsts'],
				'hsts_max_age'           => $max_age,
			),
			$valor
		);
	}

	/**
	 * Vocabulário fechado do `Cross-Origin-Opener-Policy`.
	 *
	 * Fechado porque cabeçalho com valor que o navegador não conhece é
	 * cabeçalho ignorado — e ignorado em silêncio é pior que ausente. O que a
	 * lista NÃO faz é escolher por quem grava: `same-origin` está nela, e o
	 * preço dele para o fluxo de leads sai nomeado no estado do módulo.
	 *
	 * @return array<int,string>
	 */
	public static function coop_aceitos(): array {
		return F3Base_Vocabulario::politicas_de_coop();
	}

	/**
	 * Sanitiza um ID de post.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return int
	 */
	public static function sanitiza_id_post( $valor, $padrao ): int {
		unset( $padrao );

		return is_scalar( $valor ) ? max( 0, (int) $valor ) : 0;
	}

	/**
	 * Sanitiza uma lista genérica gravada por outro artefato do pacote.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<mixed>
	 */
	public static function sanitiza_lista_generica( $valor, array $padrao ): array {
		unset( $padrao );

		return is_array( $valor ) ? $valor : array();
	}

	/**
	 * Sanitiza `f3base_atividade`.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<string,array<string,mixed>>
	 */
	public static function sanitiza_atividade( $valor, array $padrao ): array {
		unset( $padrao );

		if ( ! is_array( $valor ) ) {
			return array();
		}

		$saida = array();

		foreach ( $valor as $chave => $dados ) {
			$chave_limpa = sanitize_key( (string) $chave );
			if ( '' === $chave_limpa || ! is_array( $dados ) ) {
				continue;
			}

			$entrada = array();
			foreach ( $dados as $campo => $conteudo ) {
				$campo_limpo = sanitize_key( (string) $campo );
				if ( '' === $campo_limpo ) {
					continue;
				}
				if ( is_int( $conteudo ) || is_float( $conteudo ) ) {
					$entrada[ $campo_limpo ] = $conteudo + 0;
				} elseif ( is_bool( $conteudo ) ) {
					$entrada[ $campo_limpo ] = $conteudo;
				} else {
					$entrada[ $campo_limpo ] = sanitize_text_field( (string) $conteudo );
				}
			}

			$saida[ $chave_limpa ] = $entrada;
		}

		return $saida;
	}

	/**
	 * Sanitiza `f3base_origem_confiavel`.
	 *
	 * O nome do cabeçalho é reduzido ao alfabeto de um nome de cabeçalho HTTP e
	 * os saltos ficam entre 1 e 10: cabeçalho não é caminho nem expressão, e
	 * salto zero significaria ler a ponta que o próprio cliente escreveu.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_origem_confiavel( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$cabecalho = isset( $valor['cabecalho'] ) ? trim( sanitize_text_field( (string) $valor['cabecalho'] ) ) : (string) $padrao['cabecalho'];
		$cabecalho = preg_replace( '/[^A-Za-z0-9_-]/', '', $cabecalho );
		$cabecalho = is_string( $cabecalho ) ? $cabecalho : '';

		$saltos = isset( $valor['saltos'] ) ? (int) $valor['saltos'] : (int) $padrao['saltos'];

		return self::preservar_desconhecidas(
			array(
				'cabecalho' => $cabecalho,
				'saltos'    => max( 1, min( 10, $saltos ) ),
			),
			$valor
		);
	}

	/**
	 * Sanitiza o resumo de comportamento guardado no próprio site.
	 *
	 * OS DOIS PRAZOS TÊM TETO, e o teto não é enfeite. `retencao_dias` governa
	 * o que a limpeza automática apaga: um prazo sem limite superior faria a
	 * tabela crescer sem fim numa instalação em que ninguém revisa esta tela, e
	 * este resumo não é arquivo histórico — quem precisa de série longa a tem
	 * na conta de medição. `dias_no_painel` governa só a leitura, e é limitado
	 * pelo que existe: pedir mais dias do que a retenção guarda mostraria um
	 * período cujo começo foi apagado, com o total parecendo queda de tráfego.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão embutido.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_comportamento( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$retencao = isset( $valor['retencao_dias'] ) ? (int) $valor['retencao_dias'] : (int) $padrao['retencao_dias'];
		$retencao = max( 1, min( 730, $retencao ) );

		$painel = isset( $valor['dias_no_painel'] ) ? (int) $valor['dias_no_painel'] : (int) $padrao['dias_no_painel'];
		$painel = max( 1, min( $retencao, $painel ) );

		/*
		 * O PRAZO DO REGISTRO BRUTO NUNCA PASSA O DO AGREGADO, e o teto é
		 * estrutural. O registro é dado pessoal pseudonimizado — visitante,
		 * sessão e carimbo de milissegundo —; o agregado não identifica
		 * ninguém. Guardar o identificável por MAIS tempo que o anônimo
		 * inverteria a única razão de as duas tabelas existirem, e o operador
		 * conseguiria fazê-lo digitando um número maior num campo.
		 */
		$eventos = isset( $valor['retencao_eventos_dias'] ) ? (int) $valor['retencao_eventos_dias'] : (int) $padrao['retencao_eventos_dias'];
		$eventos = max( 1, min( $retencao, $eventos ) );

		return self::preservar_desconhecidas(
			array(
				'ligado'                => isset( $valor['ligado'] ) ? (bool) $valor['ligado'] : (bool) $padrao['ligado'],
				'retencao_dias'         => $retencao,
				'retencao_eventos_dias' => $eventos,
				'dias_no_painel'        => $painel,
			),
			$valor
		);
	}

	/**
	 * Sanitiza a cadência declarada.
	 *
	 * @param mixed                $valor  Valor bruto.
	 * @param array<string,mixed>  $padrao Padrão embutido.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_cadencia( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$periodicidade = isset( $valor['periodicidade'] ) ? sanitize_key( (string) $valor['periodicidade'] ) : (string) $padrao['periodicidade'];

		if ( ! in_array( $periodicidade, array( 'nenhuma', 'semanal', 'quinzenal', 'mensal' ), true ) ) {
			$periodicidade = (string) $padrao['periodicidade'];
		}

		return self::preservar_desconhecidas(
			array(
				'periodicidade'  => $periodicidade,
				'apos_n_ajustes' => max( 0, isset( $valor['apos_n_ajustes'] ) ? (int) $valor['apos_n_ajustes'] : (int) $padrao['apos_n_ajustes'] ),
				'mecanismo'      => isset( $valor['mecanismo'] ) ? sanitize_text_field( (string) $valor['mecanismo'] ) : (string) $padrao['mecanismo'],
				'hook'           => isset( $valor['hook'] ) ? sanitize_key( (string) $valor['hook'] ) : (string) $padrao['hook'],
			),
			$valor
		);
	}

	/**
	 * Sanitiza o estado de execução da cadência.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão embutido.
	 * @return array<string,int>
	 */
	public static function sanitiza_cadencia_estado( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		return self::preservar_desconhecidas(
			array(
				'ajustes'  => max( 0, isset( $valor['ajustes'] ) ? (int) $valor['ajustes'] : (int) $padrao['ajustes'] ),
				'previsto' => max( 0, isset( $valor['previsto'] ) ? (int) $valor['previsto'] : (int) $padrao['previsto'] ),
			),
			$valor
		);
	}

	/**
	 * Sanitiza `f3base_journal_eliminacao`.
	 *
	 * O journal guarda identificador, contagem, carimbo, operador e regime.
	 * Nenhum campo de conteúdo é aceito: campo desconhecido é descartado.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão embutido.
	 * @return array<int,array<string,mixed>>
	 */
	public static function sanitiza_journal( $valor, array $padrao ): array {
		unset( $padrao );

		if ( ! is_array( $valor ) ) {
			return array();
		}

		$saida = array();

		foreach ( $valor as $entrada ) {
			if ( ! is_array( $entrada ) ) {
				continue;
			}

			$regime = isset( $entrada['regime'] ) ? sanitize_key( (string) $entrada['regime'] ) : '';
			if ( ! in_array( $regime, array( 'operacional', 'titular' ), true ) ) {
				continue;
			}

			$saida[] = self::preservar_desconhecidas(
				array(
					'regime'          => $regime,
					'identificador'   => isset( $entrada['identificador'] ) ? sanitize_text_field( (string) $entrada['identificador'] ) : '',
					'identificador_hash' => isset( $entrada['identificador_hash'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $entrada['identificador_hash'] ) ) : '',
					'contagem'        => isset( $entrada['contagem'] ) ? max( 0, (int) $entrada['contagem'] ) : 0,
					'em'              => isset( $entrada['em'] ) ? max( 0, (int) $entrada['em'] ) : 0,
					'operador'        => isset( $entrada['operador'] ) ? sanitize_text_field( (string) $entrada['operador'] ) : '',
					'reversivel_ate'  => isset( $entrada['reversivel_ate'] ) ? max( 0, (int) $entrada['reversivel_ate'] ) : 0,
				),
				$entrada
			);
		}

		$limite = (int) apply_filters( 'f3base_journal_limite_entradas', 500 );
		$limite = max( 10, $limite );

		if ( count( $saida ) > $limite ) {
			$saida = array_slice( $saida, count( $saida ) - $limite );
		}

		return array_values( $saida );
	}

	/**
	 * Sanitiza um segredo hexadecimal.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_segredo( $valor, $padrao ): string {
		unset( $padrao );

		if ( ! is_scalar( $valor ) ) {
			return '';
		}

		$limpo = preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $valor ) );

		return is_string( $limpo ) ? substr( $limpo, 0, 128 ) : '';
	}
}
