<?php
/**
 * Última atividade relevante por módulo.
 *
 * Cada módulo declara as chaves de atividade que a tela mostra; a escrita passa
 * pelo gravador único, como qualquer option gerenciada.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registro de carimbos de execução.
 */
final class F3Base_Atividade {

	/**
	 * Option que guarda os carimbos.
	 */
	public const OPTION = 'f3base_atividade';

	/**
	 * Chaves conhecidas.
	 */
	public const ULTIMO_LEAD        = 'ultimo_lead';
	public const ULTIMA_FALHA_LEAD  = 'ultima_falha_lead';
	public const ULTIMO_CAPI        = 'ultimo_capi';
	public const ULTIMA_FALHA_CAPI  = 'ultima_falha_capi';
	public const ULTIMA_CADENCIA    = 'ultima_cadencia';
	public const ATRASO_CADENCIA    = 'atraso_cadencia';
	public const ULTIMA_LIMPEZA     = 'ultima_limpeza_retencao';
	public const REDIRECTS_SERVIDOS = 'redirects_servidos';
	public const ULTIMA_ELIMINACAO  = 'ultima_eliminacao';
	public const ULTIMA_ORIGEM      = 'ultima_origem';
	public const ULTIMO_LLMS        = 'ultimo_llms_servido';
	public const ATRASO_CRON        = 'atraso_cron_retencao';
	public const ULTIMO_COMPORTAMENTO = 'ultimo_comportamento';
	public const ULTIMA_PODA_COMPORTAMENTO = 'ultima_poda_comportamento';

	/**
	 * Registra ou atualiza um carimbo de atividade.
	 *
	 * @param string              $chave Chave declarada.
	 * @param array<string,mixed> $dados Campos escalares do carimbo.
	 * @return void
	 */
	public static function registrar( string $chave, array $dados = array() ): void {
		$chave = sanitize_key( $chave );
		if ( '' === $chave ) {
			return;
		}

		$atual = F3Base_Options::ler( self::OPTION );
		if ( ! is_array( $atual ) ) {
			$atual = array();
		}

		$anterior = isset( $atual[ $chave ] ) && is_array( $atual[ $chave ] ) ? $atual[ $chave ] : array();

		$dados['em']     = time();
		$atual[ $chave ] = array_merge( $anterior, $dados );

		F3Base_Options::gravar( self::OPTION, $atual, F3Base_Options::ORIGEM_MANUAL );
	}

	/**
	 * Incrementa um contador dentro de uma chave de atividade.
	 *
	 * @param string $chave  Chave declarada.
	 * @param string $campo  Campo contador.
	 * @param int    $quanto Incremento.
	 * @return void
	 */
	public static function incrementar( string $chave, string $campo, int $quanto = 1 ): void {
		$atual = self::ler( $chave );
		$campo = sanitize_key( $campo );

		if ( '' === $campo ) {
			return;
		}

		$valor = isset( $atual[ $campo ] ) ? (int) $atual[ $campo ] : 0;

		self::registrar( $chave, array( $campo => $valor + $quanto ) );
	}

	/**
	 * Lê um carimbo.
	 *
	 * @param string $chave Chave declarada.
	 * @return array<string,mixed> Carimbo, ou array vazio quando nunca houve atividade.
	 */
	public static function ler( string $chave ): array {
		$atual = F3Base_Options::ler( self::OPTION );
		$chave = sanitize_key( $chave );

		if ( is_array( $atual ) && isset( $atual[ $chave ] ) && is_array( $atual[ $chave ] ) ) {
			return $atual[ $chave ];
		}

		return array();
	}

	/**
	 * Descreve um carimbo em texto legível para a tela e o relatório.
	 *
	 * @param string $chave  Chave declarada.
	 * @param string $rotulo Rótulo do que está sendo medido.
	 * @return string Frase pronta, já traduzida e sem escape (o consumidor escapa).
	 */
	public static function descrever( string $chave, string $rotulo ): string {
		$carimbo = self::ler( $chave );

		if ( array() === $carimbo || empty( $carimbo['em'] ) ) {
			return sprintf(
				/* translators: %s: rótulo da atividade. */
				__( '%s: sem registro até agora.', 'f3base' ),
				$rotulo
			);
		}

		$quando = wp_date( 'd/m/Y H:i', (int) $carimbo['em'] );
		$quando = is_string( $quando ) ? $quando : (string) $carimbo['em'];

		$detalhes = array();
		foreach ( $carimbo as $campo => $valor ) {
			if ( 'em' === $campo || is_array( $valor ) ) {
				continue;
			}
			if ( is_bool( $valor ) ) {
				$valor = $valor ? __( 'sim', 'f3base' ) : __( 'não', 'f3base' );
			}
			if ( '' === (string) $valor ) {
				continue;
			}
			$detalhes[] = $campo . ': ' . (string) $valor;
		}

		if ( array() === $detalhes ) {
			return sprintf(
				/* translators: 1: rótulo da atividade, 2: data e hora. */
				__( '%1$s: %2$s.', 'f3base' ),
				$rotulo,
				$quando
			);
		}

		return sprintf(
			/* translators: 1: rótulo da atividade, 2: data e hora, 3: campos do carimbo. */
			__( '%1$s: %2$s — %3$s.', 'f3base' ),
			$rotulo,
			$quando,
			implode( ', ', $detalhes )
		);
	}
}
