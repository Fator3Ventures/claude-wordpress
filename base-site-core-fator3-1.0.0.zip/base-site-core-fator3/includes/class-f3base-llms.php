<?php
/**
 * Regra COMPARTILHADA do arquivo llms.txt: seleção, ordem, descrição e emissor.
 *
 * POR QUE ESTA CLASSE EXISTE. Dois módulos servem o mesmo conjunto de itens —
 * `llms-txt-reserva`, no índice curto, e `llms-full-txt`, no texto integral. A
 * seleção, as exclusões, a ordem, a origem de cada descrição e a precedência de
 * emissor são a MESMA pergunta nos dois, e duas cópias divergiriam na primeira
 * condição acrescentada: um arquivo passaria a listar o que o outro exclui, e
 * nada acusaria.
 *
 * A classe não estende `F3Base_Modulo` de propósito, pelo mesmo motivo de
 * `F3Base_Emissores`: ela é regra, não superfície. As funções que DECIDEM são
 * puras e recebem fatos já medidos; as que MEDEM estão separadas e nomeadas
 * como tal. É essa separação que dá teto e piso a cada uma sem precisar de um
 * WordPress para exercitá-la.
 *
 * O QUE ELA NÃO FAZ, e é decisão: ela não lê meta de noindex. Quem produz esse
 * fato é `F3Base_Modulo_Noindex_Honrado::post_e_noindex()`, e esta classe
 * PERGUNTA a ele. Dois leitores da mesma chave é como uma exclusão passa a
 * nunca disparar sem que nada acuse.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Seleção, ordem e apresentação do llms.txt.
 */
final class F3Base_Llms {

	/**
	 * Vocabulário FECHADO do modo de seleção.
	 */
	public const MODO_CURADA    = 'curada';
	public const MODO_AUTOMATICA = 'automatica';
	public const MODO_MISTO     = F3Base_Vocabulario::LLMS_MISTO;

	/**
	 * Vocabulário FECHADO da origem de cada item, que decide a ordem.
	 */
	public const ORIGEM_HOME       = 'home';
	public const ORIGEM_CURADO     = 'curado';
	public const ORIGEM_AUTOMATICO = 'automatico';

	/**
	 * Vocabulário FECHADO da fonte de uma descrição.
	 */
	public const FONTE_META     = 'meta-do-plugin-de-seo';
	public const FONTE_RESUMO   = 'resumo-declarado-no-conteudo';
	public const FONTE_CONTEUDO = 'resumo-do-conteudo-limpo';
	public const FONTE_NENHUMA  = 'nenhuma';

	/**
	 * Vocabulário FECHADO de quem responde pelo endereço público.
	 */
	public const QUEM_ARQUIVO     = 'arquivo-fisico';
	public const QUEM_CONCORRENTE = 'emissor-concorrente';
	public const QUEM_NOSSA_ROTA  = 'rota-reserva';

	/**
	 * Elementos que são INTERFACE e não texto, removidos COM o conteúdo.
	 *
	 * Removê-los é diferente de tirar as tags: `wp_strip_all_tags()` apaga a tag
	 * e PRESERVA o texto de dentro, e o texto de dentro de um formulário é o
	 * rótulo do botão. Um resumo que termina no rótulo do botão de busca
	 * descreve a interface do site, não o assunto da página.
	 *
	 * @return string[]
	 */
	public static function elementos_de_interface(): array {
		return array( 'form', 'script', 'style', 'nav', 'aside', 'button', 'svg' );
	}

	/**
	 * O modo declarado usa a CURADORIA?
	 *
	 * @param string $modo Modo declarado.
	 * @return bool
	 */
	public static function modo_cura( string $modo ): bool {
		return in_array( $modo, array( self::MODO_CURADA, self::MODO_MISTO ), true );
	}

	/**
	 * O modo declarado ENUMERA o conteúdo publicado?
	 *
	 * @param string $modo Modo declarado.
	 * @return bool
	 */
	public static function modo_enumera( string $modo ): bool {
		return in_array( $modo, array( self::MODO_AUTOMATICA, self::MODO_MISTO ), true );
	}

	/**
	 * Modos fechados, para o sanitizador e para a tela.
	 *
	 * @return string[]
	 */
	public static function modos(): array {
		return array( self::MODO_CURADA, self::MODO_AUTOMATICA, self::MODO_MISTO );
	}

	/**
	 * TIPOS válidos: os declarados que EXISTEM entre os públicos desta instalação.
	 *
	 * O conjunto válido é medido, nunca literal: tipo declarado que este site não
	 * tem é descartado COM O NOME, e tipo que o agente criar depois passa a poder
	 * ser declarado sem release nova.
	 *
	 * @param array<int,string> $declarados Tipos declarados na configuração.
	 * @param array<int,string> $publicos   Tipos públicos medidos na instalação.
	 * @return array{tipos:array<int,string>,descartados:array<int,string>}
	 */
	public static function tipos_validos( array $declarados, array $publicos ): array {
		$tipos       = array();
		$descartados = array();

		foreach ( $declarados as $tipo ) {
			$tipo = trim( (string) $tipo );

			if ( '' === $tipo ) {
				continue;
			}

			if ( ! in_array( $tipo, $publicos, true ) ) {
				$descartados[] = $tipo;
				continue;
			}

			if ( ! in_array( $tipo, $tipos, true ) ) {
				$tipos[] = $tipo;
			}
		}

		return array(
			'tipos'       => $tipos,
			'descartados' => $descartados,
		);
	}

	/**
	 * PRECEDÊNCIA de quem responde pelo endereço público. Regra pura.
	 *
	 * Três respostas possíveis, nesta ordem, e a ordem é a regra:
	 *
	 * 1. **Arquivo físico na raiz** — a mesma física do robots.txt: arquivo
	 *    existente vence, e a rota fica de reserva.
	 * 2. **Emissor concorrente medido** — outro plugin com a função ligada
	 *    serviria a MESMA URL. Nosso módulo sai de cena e o motivo NOMEIA quem
	 *    ficou, que é a mesma regra de `tracking.emissor_unico`: dois emissores
	 *    para o mesmo endereço é o defeito, e quem cala é quem chegou depois.
	 * 3. **Nossa rota** — não há arquivo e não há concorrente.
	 *
	 * @param bool   $arquivo_fisico   Existe arquivo físico na raiz.
	 * @param string $caminho_fisico   Caminho do arquivo, para a mensagem.
	 * @param bool   $concorrente      Outro emissor está ligado para esta URL.
	 * @param string $nome_concorrente Nome do outro emissor, para a mensagem.
	 * @return array{serve:bool,quem:string,motivo:string}
	 */
	public static function veredito_do_emissor( bool $arquivo_fisico, string $caminho_fisico, bool $concorrente, string $nome_concorrente ): array {
		if ( $arquivo_fisico ) {
			return array(
				'serve'  => false,
				'quem'   => self::QUEM_ARQUIVO,
				'motivo' => sprintf(
					/* translators: %s: caminho do arquivo físico. */
					__( 'arquivo físico presente em %s: é ele quem responde, e a rota fica em espera — que é o desenho.', 'f3base' ),
					'' !== $caminho_fisico ? $caminho_fisico : __( 'raiz do site', 'f3base' )
				),
			);
		}

		if ( $concorrente ) {
			return array(
				'serve'  => false,
				'quem'   => self::QUEM_CONCORRENTE,
				'motivo' => sprintf(
					/* translators: %s: nome do emissor concorrente medido. */
					__( 'EMISSOR CONCORRENTE MEDIDO: %s está com a publicação deste arquivo ligada e responderia pela MESMA URL. Este módulo sai de cena e não serve — duas respostas para um endereço é o defeito, e quem cala é quem chegou depois. Desligue lá para que a rota daqui volte a responder, ou deixe como está e o arquivo continua existindo, servido pelo outro.', 'f3base' ),
					'' !== $nome_concorrente ? $nome_concorrente : __( 'outro plugin instalado', 'f3base' )
				),
			);
		}

		return array(
			'serve'  => true,
			'quem'   => self::QUEM_NOSSA_ROTA,
			'motivo' => __( 'sem arquivo físico e sem emissor concorrente medido: quem responde no endereço público é esta rota.', 'f3base' ),
		);
	}

	/**
	 * RESUMO LIMPO do conteúdo, sem a interface junto. Regra pura.
	 *
	 * A ordem das quatro etapas é a regra, e cada uma existe por um defeito
	 * concreto que a anterior não resolve:
	 *
	 * 1. `strip_shortcodes()` — shortcode não renderizado vira texto literal no
	 *    resumo, com colchetes e atributos.
	 * 2. **Elementos de interface removidos COM o conteúdo.** Tirar só as tags
	 *    preserva o texto de dentro, e o texto de dentro de um formulário de
	 *    busca é o rótulo do botão: o resumo terminaria descrevendo a interface.
	 * 3. **Quebra de linha antes de tirar as tags.** Sem ela, o título de um
	 *    bloco e o parágrafo seguinte colam numa frase só, sem pontuação.
	 * 4. Só então tirar as tags e cortar em palavras.
	 *
	 * @param string $conteudo Conteúdo bruto.
	 * @param int    $palavras Teto de palavras.
	 * @return string
	 */
	public static function resumo_limpo( string $conteudo, int $palavras ): string {
		if ( '' === trim( $conteudo ) ) {
			return '';
		}

		$texto = strip_shortcodes( $conteudo );

		foreach ( self::elementos_de_interface() as $elemento ) {
			$texto = (string) preg_replace(
				'#<' . $elemento . '\b[^>]*>.*?</' . $elemento . '\s*>#is',
				' ',
				$texto
			);

			/* Elemento sem par de fechamento não pode sobreviver por acidente de markup. */
			$texto = (string) preg_replace( '#<' . $elemento . '\b[^>]*/?>#i', ' ', $texto );
		}

		$texto = (string) preg_replace( '#<(?:/?)(?:p|div|section|article|header|footer|li|ul|ol|h[1-6]|br|tr|td|th|table|figure|figcaption|blockquote)\b[^>]*>#i', "\n", $texto );

		$texto = wp_strip_all_tags( $texto );
		$texto = (string) preg_replace( '/[ \t]+/', ' ', $texto );
		$texto = (string) preg_replace( '/\s*\n\s*/', "\n", $texto );
		$texto = trim( $texto );

		if ( '' === $texto ) {
			return '';
		}

		/*
		 * A QUEBRA VIRA PONTUAÇÃO antes do corte: "Título Corpo" numa frase só é
		 * o que sai quando as linhas são simplesmente concatenadas.
		 */
		$texto = (string) preg_replace( '/\n+/', '. ', $texto );
		$texto = (string) preg_replace( '/\.\s*\.\s*/', '. ', $texto );

		return trim( wp_trim_words( $texto, max( 1, $palavras ), '…' ) );
	}

	/**
	 * DESCRIÇÃO de um item e a FONTE que respondeu. Regra pura.
	 *
	 * A cadeia é declarada e tem ordem: a descrição escrita no plugin de SEO
	 * vence, porque é o texto que alguém escreveu PARA ser o resumo; depois o
	 * resumo declarado no próprio conteúdo; e só então o corte do corpo, que é
	 * derivado e é o que erra.
	 *
	 * A função devolve o texto E a fonte porque sem a fonte não há como provar
	 * que a primeira foi preferida: um resumo bom, obtido do lugar errado,
	 * continua sendo o instrumento medindo outra coisa.
	 *
	 * @param string $meta_seo Descrição gravada no plugin de SEO.
	 * @param string $resumo   Resumo declarado no conteúdo.
	 * @param string $conteudo Conteúdo bruto, para o corte de última instância.
	 * @param int    $palavras Teto de palavras do corte.
	 * @return array{texto:string,fonte:string}
	 */
	public static function descricao_do_item( string $meta_seo, string $resumo, string $conteudo, int $palavras ): array {
		$meta_seo = trim( $meta_seo );

		if ( '' !== $meta_seo ) {
			return array(
				'texto' => $meta_seo,
				'fonte' => self::FONTE_META,
			);
		}

		$resumo = trim( $resumo );

		if ( '' !== $resumo ) {
			return array(
				'texto' => $resumo,
				'fonte' => self::FONTE_RESUMO,
			);
		}

		$cortado = self::resumo_limpo( $conteudo, $palavras );

		if ( '' !== $cortado ) {
			return array(
				'texto' => $cortado,
				'fonte' => self::FONTE_CONTEUDO,
			);
		}

		return array(
			'texto' => '',
			'fonte' => self::FONTE_NENHUMA,
		);
	}

	/**
	 * ENDEREÇO DO SITEMAP, medido. Regra pura.
	 *
	 * Quem serve sitemap neste site é uma pergunta com resposta, e ela tem três
	 * saídas. Sitemap do plugin de SEO ligado responde em `sitemap_index.xml`, e
	 * nesse caso o núcleo DESATIVA o endereço dele; sem o plugin, o do núcleo
	 * responde em `wp-sitemap.xml` quando estiver habilitado; e quando nenhum
	 * dos dois serve, a seção inteira é OMITIDA. Imprimir um endereço fixo é
	 * afirmar mais do que se mediu — e o endereço fixo errado é justamente o que
	 * o núcleo desliga quando o plugin assume.
	 *
	 * @param bool   $sitemap_do_seo   O plugin de SEO serve sitemap.
	 * @param bool   $sitemap_do_nucleo O núcleo serve sitemap.
	 * @param string $home             Endereço base do site, com ou sem barra final: a normalização é feita aqui.
	 * @return array{url:string,fonte:string}
	 */
	public static function endereco_do_sitemap( bool $sitemap_do_seo, bool $sitemap_do_nucleo, string $home ): array {
		/*
		 * A BARRA FINAL É GARANTIDA AQUI, e não no chamador. Função pura que
		 * confia no formato do argumento é defeito esperando o segundo
		 * chamador: com o home sem barra, a concatenação produz
		 * "https://exemplo.com.brsitemap_index.xml" — endereço que nada serve,
		 * impresso como se fosse medido.
		 */
		$base = '' === $home ? '/' : trailingslashit( $home );

		if ( $sitemap_do_seo ) {
			return array(
				'url'   => $base . 'sitemap_index.xml',
				'fonte' => 'plugin-de-seo',
			);
		}

		if ( $sitemap_do_nucleo ) {
			return array(
				'url'   => $base . 'wp-sitemap.xml',
				'fonte' => 'nucleo',
			);
		}

		return array(
			'url'   => '',
			'fonte' => 'nenhum',
		);
	}

	/**
	 * SELEÇÃO: junta curados e enumerados, aplica as exclusões, dedupe por ID.
	 *
	 * As três exclusões, e nenhuma delas é escrita duas vezes no pacote:
	 *
	 * - **noindex** — o fato vem de `F3Base_Modulo_Noindex_Honrado`, e chega
	 *   aqui já medido, no campo `noindex` de cada candidato.
	 * - **já curado** — dedupe por **ID**, nunca por URL: URL muda quando o slug
	 *   muda, e o mesmo conteúdo sairia duas vezes no arquivo.
	 * - **excluídos declarados** — a política de privacidade quando a
	 *   configuração manda não incluí-la. A regra é a mesma de sempre, aplicada
	 *   por ID, e não uma segunda cópia dela.
	 *
	 * @param array<int,array<string,mixed>> $curados     Itens da curadoria, na ordem declarada.
	 * @param array<int,array<string,mixed>> $enumerados  Candidatos enumerados.
	 * @param array<int,int>                 $excluir_ids IDs excluídos por declaração.
	 * @return array{itens:array<int,array<string,mixed>>,excluidos:array<string,array<int,int>>}
	 */
	public static function selecionar( array $curados, array $enumerados, array $excluir_ids ): array {
		$excluir  = array_map( 'intval', array_values( $excluir_ids ) );
		$vistos   = array();
		$itens    = array();
		$por_noindex = array();
		$por_dedupe  = array();
		$por_declaracao = array();

		foreach ( array_merge( $curados, $enumerados ) as $item ) {
			$id = (int) ( $item['id'] ?? 0 );

			if ( in_array( $id, $excluir, true ) && $id > 0 ) {
				$por_declaracao[] = $id;
				continue;
			}

			if ( ! empty( $item['noindex'] ) ) {
				$por_noindex[] = $id;
				continue;
			}

			if ( $id > 0 && in_array( $id, $vistos, true ) ) {
				$por_dedupe[] = $id;
				continue;
			}

			if ( $id > 0 ) {
				$vistos[] = $id;
			}

			$itens[] = $item;
		}

		return array(
			'itens'     => $itens,
			'excluidos' => array(
				'noindex'   => $por_noindex,
				'duplicado' => $por_dedupe,
				'declarado' => $por_declaracao,
			),
		);
	}

	/**
	 * ORDEM do arquivo. Regra pura, e ela não é a ordem de leitura do banco.
	 *
	 * A página inicial primeiro, porque é ela que define o site; depois os itens
	 * curados NA ORDEM DECLARADA, porque a ordem é a curadoria; e só então o
	 * enumerado, páginas antes de posts e por data decrescente dentro de cada
	 * um. Ordenar tudo por data joga a página inicial para o rodapé, depois de
	 * qualquer artigo publicado — e o que define o site não pode sair por
	 * último.
	 *
	 * @param array<int,array<string,mixed>> $itens Itens já selecionados.
	 * @return array<int,array<string,mixed>>
	 */
	public static function ordenar( array $itens ): array {
		$peso_da_origem = array(
			self::ORIGEM_HOME       => 0,
			self::ORIGEM_CURADO     => 1,
			self::ORIGEM_AUTOMATICO => 2,
		);

		$indexados = array();

		foreach ( array_values( $itens ) as $posicao => $item ) {
			$indexados[] = array( 'posicao' => $posicao, 'item' => $item );
		}

		usort(
			$indexados,
			static function ( array $a, array $b ) use ( $peso_da_origem ): int {
				$origem_a = (string) ( $a['item']['origem'] ?? self::ORIGEM_AUTOMATICO );
				$origem_b = (string) ( $b['item']['origem'] ?? self::ORIGEM_AUTOMATICO );

				$pa = $peso_da_origem[ $origem_a ] ?? 2;
				$pb = $peso_da_origem[ $origem_b ] ?? 2;

				if ( $pa !== $pb ) {
					return $pa <=> $pb;
				}

				if ( self::ORIGEM_AUTOMATICO === $origem_a ) {
					$tipo_a = (string) ( $a['item']['tipo'] ?? '' );
					$tipo_b = (string) ( $b['item']['tipo'] ?? '' );

					$pagina_a = 'page' === $tipo_a ? 0 : 1;
					$pagina_b = 'page' === $tipo_b ? 0 : 1;

					if ( $pagina_a !== $pagina_b ) {
						return $pagina_a <=> $pagina_b;
					}

					$data_a = (string) ( $a['item']['data'] ?? '' );
					$data_b = (string) ( $b['item']['data'] ?? '' );

					if ( $data_a !== $data_b ) {
						return strcmp( $data_b, $data_a );
					}
				}

				/* Empate conserva a ordem de entrada: é ela que carrega a curadoria. */
				return $a['posicao'] <=> $b['posicao'];
			}
		);

		$saida = array();

		foreach ( $indexados as $linha ) {
			$saida[] = $linha['item'];
		}

		return $saida;
	}

	/**
	 * A LINHA de um item no índice curto.
	 *
	 * @param array<string,mixed> $item Item selecionado.
	 * @return string
	 */
	public static function linha_de_item( array $item ): string {
		$url = isset( $item['url'] ) ? trim( (string) $item['url'] ) : '';

		if ( '' === $url ) {
			return '';
		}

		$titulo = isset( $item['titulo'] ) ? trim( (string) $item['titulo'] ) : '';
		$titulo = '' !== $titulo ? $titulo : $url;

		$linha = '- [' . $titulo . '](' . $url . ')';

		$descricao = isset( $item['descricao'] ) ? trim( (string) $item['descricao'] ) : '';

		return '' !== $descricao ? $linha . ': ' . $descricao : $linha;
	}

	/* ------------------------------------------------------------------ *
	 * A partir daqui: o que MEDE. Separado do que decide, e nomeado.
	 * ------------------------------------------------------------------ */

	/**
	 * O plugin de SEO está com a publicação deste arquivo LIGADA?
	 *
	 * @return array{ligado:bool,nome:string}
	 */
	public static function concorrente_de_llms(): array {
		$wpseo = get_option( 'wpseo', array() );
		$ligado = is_array( $wpseo ) && ! empty( $wpseo['enable_llms_txt'] );

		return array(
			'ligado' => $ligado,
			'nome'   => __( 'o plugin de SEO, pela chave enable_llms_txt', 'f3base' ),
		);
	}

	/**
	 * Quem serve sitemap neste site, medido nas duas fontes possíveis.
	 *
	 * @return array{url:string,fonte:string}
	 */
	public static function sitemap_medido(): array {
		$wpseo = get_option( 'wpseo', array() );
		$do_seo = is_array( $wpseo ) && ! empty( $wpseo['enable_xml_sitemap'] );

		$do_nucleo = function_exists( 'wp_sitemaps_enabled' ) ? (bool) wp_sitemaps_enabled() : false;

		return self::endereco_do_sitemap( $do_seo, $do_nucleo, trailingslashit( home_url( '/' ) ) );
	}

	/**
	 * CANDIDATOS enumerados do conteúdo publicado, com o noindex já medido.
	 *
	 * @param array<int,string> $tipos    Tipos válidos.
	 * @param int               $palavras Teto de palavras do resumo.
	 * @param int               $teto     Teto de itens enumerados.
	 * @return array<int,array<string,mixed>>
	 */
	public static function enumerar( array $tipos, int $palavras, int $teto ): array {
		if ( array() === $tipos ) {
			return array();
		}

		$posts = get_posts(
			array(
				'post_type'        => $tipos,
				'post_status'      => 'publish',
				'numberposts'      => max( 1, $teto ),
				'orderby'          => 'date',
				'order'            => 'DESC',
				'suppress_filters' => false,
			)
		);

		$saida = array();

		foreach ( is_array( $posts ) ? $posts : array() as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}

			$meta = get_post_meta( $post->ID, F3Base_Modulo_Noindex_Honrado::META_DESCRICAO, true );
			$meta = is_scalar( $meta ) ? (string) $meta : '';

			$descricao = self::descricao_do_item( $meta, (string) $post->post_excerpt, (string) $post->post_content, $palavras );

			$saida[] = array(
				'id'        => (int) $post->ID,
				'titulo'    => wp_specialchars_decode( (string) get_the_title( $post ), ENT_QUOTES ),
				'url'       => (string) get_permalink( $post ),
				'descricao' => $descricao['texto'],
				'fonte'     => $descricao['fonte'],
				'tipo'      => (string) $post->post_type,
				'data'      => (string) $post->post_date_gmt,
				'conteudo'  => (string) $post->post_content,
				'origem'    => self::ORIGEM_AUTOMATICO,
				'noindex'   => F3Base_Modulo_Noindex_Honrado::post_e_noindex( (int) $post->ID ),
			);
		}

		return $saida;
	}
}
