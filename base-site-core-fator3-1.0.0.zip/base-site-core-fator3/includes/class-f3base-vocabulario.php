<?php
/**
 * VOCABULÁRIO compartilhado pelos dois runtimes: os valores, num lugar só.
 *
 * POR QUE ESTE ARQUIVO EXISTE. Este pacote decide um valor num lado e o
 * reconhece no outro. O IMPLANTADOR escolhe — em `config/decisoes.tsv` — qual
 * modelo de atribuição usar, qual política de frame enviar, que modo de lista o
 * `llms.txt` monta, qual plugin ocupa o papel de SEO. O `site-core` RECONHECE
 * esses valores: o sanitizador de options precisa saber o conjunto aceito para
 * recusar lixo, e o módulo precisa ramificar sobre o valor que recebeu.
 *
 * Enquanto quem decide e quem reconhece não compartilhavam fonte, os dois
 * concordavam por COINCIDÊNCIA. O catálogo podia mudar de `first-touch` para
 * `last-touch` e o sanitizador continuaria devolvendo `first-touch` como padrão;
 * o plugin de SEO podia trocar no catálogo e o módulo de noindex continuaria
 * procurando o slug antigo. Nada quebra nesses casos — é essa a parte ruim: a
 * medição some, a exclusão nunca dispara, e a única evidência é um número que
 * não aparece no relatório de ninguém.
 *
 * O que este arquivo é: o CONJUNTO de valores que existem. O que ele não é: a
 * escolha entre eles. Quem escolhe é `config/decisoes.tsv`, com o motivo escrito
 * ao lado, e `decisoes.fonte_unica` cruza os dois — toda decisão que este
 * vocabulário governa precisa valer um dos valores que ele declara. É esse
 * cruzamento que torna duas fontes seguras; sem ele, seriam duas verdades.
 *
 * A classe NÃO tem pai e NÃO usa nada do WordPress, pelo mesmo motivo de
 * `F3Base_Chaves_Seo`, de `F3Base_Emissores` e de `F3Base_Censo_Demonstrativo`:
 * ela roda em dois runtimes que não se enxergam. O `site-core` a carrega pelo
 * autoload declarado dele; o implantador a alcança por `require_once` da cópia
 * de origem em `fontes/plugin/includes/`, que é ESTE arquivo antes do
 * empacotamento. A guarda de `class_exists` existe porque os dois caminhos de
 * arquivo são diferentes e `require_once` não os reconhece como o mesmo.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'F3Base_Vocabulario' ) ) {

	/**
	 * Os valores que os dois runtimes reconhecem.
	 */
	final class F3Base_Vocabulario {

		/**
		 * Atribuição pelo PRIMEIRO toque: a origem que descobriu o cliente.
		 */
		public const ATRIBUICAO_PRIMEIRO_TOQUE = 'first-touch';

		/**
		 * Atribuição pelo ÚLTIMO toque.
		 */
		public const ATRIBUICAO_ULTIMO_TOQUE = 'last-touch';

		/**
		 * Lista curada apenas.
		 */
		public const LLMS_CURADA = 'curada';

		/**
		 * Enumeração automática apenas.
		 */
		public const LLMS_AUTOMATICA = 'automatica';

		/**
		 * Curadoria primeiro, enumeração automática depois.
		 */
		public const LLMS_MISTO = 'curada-mais-automatica';

		/**
		 * X-Frame-Options que permite o frame do mesmo domínio.
		 */
		public const FRAME_MESMA_ORIGEM = 'SAMEORIGIN';

		/**
		 * X-Frame-Options que recusa todo frame.
		 */
		public const FRAME_NEGADO = 'DENY';

		/**
		 * Referrer-Policy que preserva a origem e corta o caminho entre sites.
		 */
		public const REFERRER_ESTRITO_ENTRE_SITES = 'strict-origin-when-cross-origin';

		/**
		 * COOP que isola a janela SEM cortar o popup do fluxo de leads.
		 */
		public const COOP_PERMITE_POPUP = 'same-origin-allow-popups';

		/**
		 * COOP que desliga o isolamento.
		 */
		public const COOP_SEM_ISOLAMENTO = 'unsafe-none';

		/**
		 * Permissions-Policy que nega as três capacidades que um site
		 * institucional não usa.
		 */
		public const PERMISSOES_NEGADAS = 'geolocation=(), camera=(), microphone=()';

		/**
		 * Papel do plugin que responde pelo SEO.
		 */
		public const PAPEL_SEO = 'seo';

		/**
		 * Papel do plugin que guarda a cópia do lead.
		 */
		public const PAPEL_CAIXA_DE_LEADS = 'caixa-de-leads';

		/**
		 * Modelos de atribuição aceitos.
		 *
		 * @return array<int,string>
		 */
		public static function modelos_de_atribuicao(): array {
			return array( self::ATRIBUICAO_PRIMEIRO_TOQUE, self::ATRIBUICAO_ULTIMO_TOQUE );
		}

		/**
		 * Modos de montagem da lista do `llms.txt`.
		 *
		 * @return array<int,string>
		 */
		public static function modos_de_llms(): array {
			return array( self::LLMS_CURADA, self::LLMS_AUTOMATICA, self::LLMS_MISTO );
		}

		/**
		 * Políticas de X-Frame-Options aceitas, incluindo o vazio.
		 *
		 * O VAZIO É UM VALOR, e não a ausência de um: ele diz "não envie este
		 * cabeçalho", que é diferente de "ninguém decidiu".
		 *
		 * @return array<int,string>
		 */
		public static function politicas_de_frame(): array {
			return array( self::FRAME_MESMA_ORIGEM, self::FRAME_NEGADO, '' );
		}

		/**
		 * Políticas de COOP aceitas.
		 *
		 * @return array<int,string>
		 */
		public static function politicas_de_coop(): array {
			return array(
				self::COOP_SEM_ISOLAMENTO,
				'same-origin',
				self::COOP_PERMITE_POPUP,
				'noopener-allow-popups',
			);
		}

		/**
		 * Políticas de Referrer-Policy aceitas, na grafia da especificação.
		 *
		 * @return array<int,string>
		 */
		public static function politicas_de_referrer(): array {
			return array(
				'no-referrer',
				'no-referrer-when-downgrade',
				'origin',
				'origin-when-cross-origin',
				'same-origin',
				'strict-origin',
				self::REFERRER_ESTRITO_ENTRE_SITES,
				'unsafe-url',
				'',
			);
		}

		/**
		 * O SLUG do plugin que ocupa um papel.
		 *
		 * O `site-core` não tem como ler `config/decisoes.tsv` — ele não viaja
		 * com o catálogo —, e por isso o slug precisa estar aqui. O que impede
		 * as duas fontes de divergirem é o cruzamento: `decisoes.fonte_unica`
		 * exige que a entrada do catálogo naquele papel traga EXATAMENTE este
		 * slug, e acusa quando não traz.
		 *
		 * @param string $papel Papel declarado.
		 * @return string Slug, ou vazio quando o papel não é conhecido.
		 */
		public static function slug_do_papel( string $papel ): string {
			$por_papel = array(
				self::PAPEL_SEO             => 'wordpress-seo',
				self::PAPEL_CAIXA_DE_LEADS  => 'flamingo',
			);

			return (string) ( $por_papel[ $papel ] ?? '' );
		}

		/**
		 * AS DECISÕES QUE ESTE VOCABULÁRIO GOVERNA, e os valores que cada uma
		 * pode ter.
		 *
		 * É por este mapa que `decisoes.fonte_unica` cruza os dois lados sem uma
		 * segunda lista: o catálogo escolhe, esta classe declara o conjunto, e a
		 * checagem exige que a escolha esteja no conjunto. Decisão fora daqui
		 * não é governada por vocabulário nenhum e não entra no cruzamento.
		 *
		 * @return array<string,array<int,string>> Chave da decisão => valores aceitos.
		 */
		public static function decisoes_governadas(): array {
			return array(
				'atribuicao.modelo'              => self::modelos_de_atribuicao(),
				'bots_ia.llms_txt_modo'          => self::modos_de_llms(),
				'cabecalhos.x_frame_options'     => self::politicas_de_frame(),
				'cabecalhos.coop'                => self::politicas_de_coop(),
				'cabecalhos.referrer_policy'     => self::politicas_de_referrer(),
				'cabecalhos.permissions_policy'  => array( self::PERMISSOES_NEGADAS ),
			);
		}

		/**
		 * OS PAPÉIS QUE ESTE VOCABULÁRIO FIXA, e a entrada do catálogo em que
		 * cada slug precisa aparecer.
		 *
		 * @return array<string,string> Papel => slug exigido.
		 */
		public static function papeis_governados(): array {
			return array(
				self::PAPEL_SEO            => self::slug_do_papel( self::PAPEL_SEO ),
				self::PAPEL_CAIXA_DE_LEADS => self::slug_do_papel( self::PAPEL_CAIXA_DE_LEADS ),
			);
		}
	}
}
