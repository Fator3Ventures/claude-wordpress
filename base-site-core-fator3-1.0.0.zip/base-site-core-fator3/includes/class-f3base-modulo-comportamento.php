<?php
/**
 * Módulo: o RESUMO DE COMPORTAMENTO que o próprio site guarda.
 *
 * A PERGUNTA QUE ESTE MÓDULO RESPONDE, nas palavras de quem a fez: *"O site
 * nasce instrumentado, onde posso ver os dados desta instrumentação."* A
 * resposta, até a 1.1.3, era: em lugar nenhum do site. Os seis coletores de
 * comportamento da 1.1.3 saem do navegador direto para a conta de medição —
 * `grep` dos seis nomes de evento dentro do plugin devolve zero — e
 * `f3base_atividade` guarda só o que passa pelo servidor. Com o slot de medição
 * vazio, os eventos nem chegavam a existir.
 *
 * O QUE ELE FAZ. Ao SAIR de cada página, o navegador manda UMA vez os TOTAIS
 * daquela visita, por `sendBeacon`, e este módulo os soma numa tabela própria —
 * uma linha por dia, caminho da página, evento e detalhe. Duas leituras vivem
 * dessa tabela: a pessoa, na tela do plugin, e o agente, por rota de banco do
 * canal, sem depender de credencial de fornecedor nenhum.
 *
 * O QUE ELE NÃO É. Ele NÃO substitui a conta de medição. Aqui não há público,
 * origem de tráfego, funil, comparação com o setor nem retenção por coorte —
 * há contagem por página e por dia. A tela diz isso com todas as letras, porque
 * um resumo que se apresenta como análise completa é pior que resumo nenhum.
 *
 * AS QUATRO RECUSAS DO PAYLOAD, e cada uma tem onde falhar:
 *
 * 1. NENHUM IDENTIFICADOR DE VISITANTE. Não há id de sessão, não há cookie e
 *    nada é gravado no armazenamento do navegador: a sessão existe só na
 *    memória da aba, e existe apenas para não enviar duas vezes.
 * 2. NENHUMA URL COM QUERY. A chave é o CAMINHO da página, sem query e sem
 *    fragmento — é na query que mora o identificador que a campanha de outra
 *    pessoa colou lá.
 * 3. NENHUM TEXTO LIVRE. O detalhe de cada evento passa por um alfabeto
 *    fechado, sem espaço, sem arroba, sem barra e sem dois-pontos: host de
 *    destino, nome de seção, marco de rolagem e nome de métrica passam; e-mail,
 *    caminho de arquivo e mensagem de erro não têm como passar.
 * 4. NENHUM EVENTO SEM DECLARAÇÃO. O navegador manda o GATILHO, nunca o nome do
 *    evento; quem resolve o nome é o servidor, contra
 *    `dados/eventos-comportamento.tsv`. Gatilho que não está lá não vira linha.
 *
 * O PORTÃO É O MESMO DA INSTRUMENTAÇÃO: sem consentimento o navegador não
 * envia. O servidor não tem como conferir consentimento de quem não mandou
 * nada, e é por isso que a tela declara, ao lado dos números, que eles contam
 * só as sessões com consentimento — quem lê um total sem essa frase acha que
 * está vendo o universo.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Coleta agregada, armazenamento próprio e leitura do comportamento no site.
 */
final class F3Base_Modulo_Comportamento extends F3Base_Modulo {

	/**
	 * Rota REST que recebe o resumo da sessão.
	 */
	public const ROTA = '/comportamento';

	/**
	 * Rota que APAGA o registro de um visitante, a pedido dele.
	 */
	public const ROTA_ESQUECER = '/comportamento/esquecer';

	/**
	 * Sufixo da tabela própria.
	 */
	public const TABELA = 'f3base_comportamento';

	/**
	 * Sufixo da tabela de REGISTRO DE EVENTOS.
	 *
	 * DUAS TABELAS, E A AGREGADA CONTINUA SENDO ESCRITA EM PARALELO — não
	 * derivada do registro. A decisão tem dois motivos e os dois são de
	 * consequência:
	 *
	 * 1. AS RETENÇÕES SÃO DIFERENTES, e essa é a razão maior. O registro bruto
	 *    é dado pessoal pseudonimizado e tem prazo CURTO; o agregado não
	 *    identifica ninguém e pode durar. Derivar o agregado do registro faria
	 *    a série histórica do painel evaporar junto com o log na primeira
	 *    execução da retenção — o operador perderia a comparação de trimestre
	 *    para proteger uma privacidade que o agregado já protegia sozinho.
	 * 2. A LEITURA DO PAINEL É BARATA e precisa continuar sendo. Recalcular
	 *    totais varrendo o registro a cada abertura de tela é aceitável com
	 *    cem linhas e inaceitável com um milhão — e o site que mais precisa da
	 *    tela é justamente o que tem tráfego.
	 *
	 * O preço é uma escrita a mais por requisição, na mesma chamada, sobre o
	 * mesmo corpo já validado. É um preço declarado, e é menor que os dois
	 * riscos acima.
	 */
	public const TABELA_EVENTOS = 'f3base_eventos';

	/**
	 * Colunas que ESTA versão usa. A prontidão é medida por elas, nunca pelo
	 * `SHOW TABLES`: tabela antiga responde à existência e faz o `INSERT` desta
	 * versão falhar em silêncio.
	 */
	public const COLUNAS = array( 'chave', 'dia', 'caminho', 'metrica', 'detalhe', 'contagem', 'soma', 'atualizado_em' );

	/**
	 * Colunas do REGISTRO DE EVENTOS desta versão.
	 */
	public const COLUNAS_EVENTOS = array( 'id', 'visitante', 'sessao', 'dia', 'caminho', 'metrica', 'detalhe', 'valor', 'ocorrencia', 'ms', 'criado_em' );

	/**
	 * Forma do pseudônimo do visitante e do identificador de sessão.
	 *
	 * HEXADECIMAL SORTEADO, e o alfabeto fechado é a garantia: um campo que
	 * aceitasse texto livre aceitaria um e-mail, e o dia em que alguém
	 * resolvesse "melhorar" o identificador do lado do cliente o site passaria
	 * a guardar dado direto sem que nada acusasse.
	 */
	public const FORMA_PSEUDONIMO = '/^[a-f0-9]{32}$/';

	/**
	 * Teto de eventos no registro, por corpo recebido.
	 *
	 * O registro bruto cresce por travessia, e não por sessão: um visitante
	 * inquieto produz dezenas de linhas de rolagem numa página só. O teto é
	 * declarado aqui para que o CORTE SEJA NOSSO — o excedente é somado no
	 * agregado, e não descartado em silêncio.
	 */
	public const MAX_EVENTOS = 120;

	/**
	 * Teto de linhas que uma VISITA inteira pode gravar.
	 *
	 * O usuário pediu TODOS os acionamentos, inclusive repetidos na mesma
	 * visita, e um teto apertado responderia "não sei" justamente para quem lê
	 * com atenção. Duzentos é generoso por conta: uma página de cinco blocos,
	 * lida com três releituras, gasta cerca de trinta linhas — quatro marcos e
	 * cinco blocos, três travessias cada, mais a abertura da página e as quatro
	 * medidas de carregamento. Seis páginas assim numa visita cabem nas 200.
	 *
	 * O que ele impede é outra coisa, e é por isso que ele não pode sumir: erro
	 * de JavaScript em laço de render dispara milhares de vezes em segundos, e
	 * uma visita nessas condições encheria a tabela sozinha. O corte é NOSSO,
	 * declarado, e sai nomeado na resposta.
	 */
	public const MAX_POR_VISITA = 200;

	/**
	 * Maior distância aceita entre o carregamento e o evento, em milissegundos.
	 *
	 * Vinte e quatro horas. Acima disso o carimbo não é tempo de leitura: é aba
	 * esquecida aberta, e um valor desses arrastaria qualquer média. A mediana
	 * que a tela usa já é robusta a isso; o teto existe para o caso absurdo, e
	 * para que o campo tenha limite declarado como todo campo deste endpoint.
	 */
	public const MAX_MS = 86400000;

	/**
	 * Alfabeto fechado do detalhe. Sem espaço, arroba, barra e dois-pontos.
	 */
	public const FORMA_DETALHE = '/^[A-Za-z0-9][A-Za-z0-9._-]{0,59}$/';

	/**
	 * Forma do caminho aceito: caminho do próprio site, sem query e sem âncora.
	 */
	public const FORMA_CAMINHO = '/^\/[A-Za-z0-9\/_\-.~%]{0,189}$/';

	/**
	 * Teto de bytes do corpo aceito.
	 */
	public const MAX_BYTES = 8192;

	/**
	 * O nome sob o qual o DESCARTE é somado na tabela do resumo.
	 *
	 * POR QUE ELE EXISTE. O corte já era contado — o cliente conta o que
	 * estourou o orçamento da visita, o servidor conta o que estourou o teto do
	 * corpo — e o número saía NOMEADO na resposta da rota, onde ninguém o lê:
	 * a resposta morre no navegador. Quem abre a tela Medição via uma tabela e
	 * não tinha como saber que faltava alguma coisa nela, e somava achando que
	 * tinha tudo.
	 *
	 * POR QUE NA MESMA TABELA, e não numa nova. O descarte tem exatamente a
	 * granularidade do resumo — dia, caminho — e exatamente o prazo dele: uma
	 * tabela nova seria uma segunda migração, uma segunda poda e um segundo
	 * prazo para manter, para guardar um inteiro por dia e por página.
	 *
	 * POR QUE UM NOME FORA DA DECLARAÇÃO. Cortada não é comportamento de
	 * ninguém: nenhum visitante "cortou" nada, foi o pacote que descartou.
	 * Declará-la em `eventos-comportamento.tsv` a faria aparecer como evento na
	 * tela, no `dataLayer` e na série histórica, respondendo uma pergunta que
	 * ela não responde. Ela é somada aqui e LIDA em separado, e todo leitor do
	 * resumo a exclui pelo nome — que tem produtor único, esta constante.
	 */
	public const METRICA_CORTADAS = 'f3base_cortadas';

	/**
	 * Prontidão memoizada por requisição.
	 *
	 * @var bool|null
	 */
	private static ?bool $tabela_pronta = null;

	/**
	 * Prontidão do registro de eventos, memoizada por requisição.
	 *
	 * @var bool|null
	 */
	private static ?bool $eventos_prontos = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'comportamento';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Resumo de comportamento no site', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Recebe, ao fim de cada visita, os totais agregados daquela página e os soma numa tabela própria — uma linha por dia, caminho, evento e detalhe. É a leitura que o site tem por conta própria, sem depender de conta de fornecedor.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'init',
				'metodo'     => 'garantir_estrutura',
				'prioridade' => 20,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'rest_api_init',
				'metodo'     => 'registrar_rota',
				'prioridade' => 10,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_comportamento' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$declarados = class_exists( 'F3Base_Modulo_Tracking' )
			? F3Base_Modulo_Tracking::eventos_de_comportamento()
			: array();

		return array(
			array(
				'rotulo'   => 'dados/eventos-comportamento.tsv',
				'presente' => array() !== $declarados,
				'detalhe'  => array() !== $declarados
					? sprintf(
						/* translators: %d: quantidade de eventos declarados. */
						__( '%d evento(s) declarado(s): é desta lista que o servidor resolve o nome a partir do gatilho que o navegador manda.', 'f3base' ),
						count( $declarados )
					)
					: __( 'declaração ausente ou ilegível: sem ela nenhum gatilho vira linha, porque o nome do evento não existe em lugar nenhum do cliente.', 'f3base' ),
			),
			array(
				'rotulo'   => self::nome_tabela(),
				'presente' => self::tabela_pronta(),
				'detalhe'  => self::tabela_pronta()
					? __( 'tabela presente com as colunas desta versão.', 'f3base' )
					: __( 'tabela ausente ou sem as colunas desta versão: a rota responde 503 e nada é somado, em vez de descartar em silêncio.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMO_COMPORTAMENTO, __( 'Último resumo de sessão somado', 'f3base' ) ),
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_PODA_COMPORTAMENTO, __( 'Última poda pelo prazo declarado', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = F3Base_Options::ler( 'f3base_comportamento' );

		if ( empty( $config['ligado'] ) ) {
			return array(
				'estado' => self::INATIVO,
				'motivo' => __( 'o resumo está desligado em f3base_comportamento.ligado: o navegador não envia nada, a rota não é registrada e o quadro da tela fica vazio. O envio para a conta de medição, quando houver, não depende desta chave.', 'f3base' ),
			);
		}

		if ( ! self::tabela_pronta() ) {
			return array(
				'estado' => self::DEGRADADO,
				'motivo' => sprintf(
					/* translators: %s: nome da tabela. */
					__( 'a tabela %s não está pronta com as colunas desta versão: a rota continua registrada e responde 503 nomeando o motivo, para que a perda seja visível em vez de silenciosa.', 'f3base' ),
					self::nome_tabela()
				),
			);
		}

		return array(
			'estado' => self::ATIVO,
			'motivo' => sprintf(
				/* translators: 1: prazo de retenção em dias, 2: nome da tabela. */
				__( 'somando as visitas em %2$s e apagando o que passa de %1$d dia(s). Contam só as sessões em que o consentimento permitiu medição.', 'f3base' ),
				self::retencao_dias(),
				self::nome_tabela()
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function instalar(): void {
		self::criar_tabela();
	}

	/**
	 * MIGRAÇÃO NA REQUISIÇÃO SEGUINTE, e é por isso que ela existe.
	 *
	 * O gancho de ativação NÃO roda numa ATUALIZAÇÃO de plugin: um site que sai
	 * da 1.1.3 para a 1.1.4 sem desativar e reativar nunca chamaria
	 * `instalar()`, a tabela nunca nasceria, e o módulo ficaria degradado para
	 * sempre com a rota respondendo 503. O transiente é a guarda contra repetir
	 * o `dbDelta` a cada requisição enquanto a criação não tiver terminado.
	 *
	 * O TRANSIENTE É TRAVA DA TENTATIVA, E NÃO ESPERA PELO FRACASSO — e esta
	 * frase substitui os quinze minutos que estavam aqui.
	 *
	 * O QUE OS QUINZE MINUTOS FAZIAM. `set_transient()` devolve `false` quando
	 * o valor gravado é o mesmo que já estava lá, e é por essa devolução que
	 * esta função saía cedo. Um `dbDelta` que falhasse — permissão de CREATE
	 * ausente, disco cheio, tabela em estado inconsistente — punha o site em
	 * QUINZE MINUTOS de 503 na rota, sem nenhuma nova tentativa no meio. O
	 * transiente foi medido vivo em `fator3-teste-mcp-1`. Enquanto o cliente
	 * descartava cada lote recusado, quinze minutos de 503 eram perda garantida
	 * com o contador andando o tempo todo.
	 *
	 * POR QUE UM MINUTO. A trava existe para impedir que requisições
	 * simultâneas disparem `dbDelta` umas por cima das outras; ela não existe
	 * para castigar o site pela falha. Um minuto é folgadamente mais que um
	 * `dbDelta` de duas tabelas pequenas e folgadamente menos que a janela em
	 * que um lote pendente ainda é retentativa — que é a janela da visita, e é
	 * o que garante que a migração terminada alcance o lote antes de ele vencer.
	 * Repetir a tentativa a cada minuto num site que nunca vai conseguir criar
	 * a tabela custa um `dbDelta` por minuto; ficar quinze minutos calado custa
	 * a medição de quinze minutos.
	 *
	 * E A TRAVA CAI NO SUCESSO. Criada a estrutura, não há mais o que travar:
	 * mantê-la seria deixar o site preso à espera de um prazo que já não
	 * protege nada.
	 *
	 * @return void
	 */
	public function garantir_estrutura(): void {
		/*
		 * AS DUAS TABELAS, e o motivo de a guarda perguntar pelas duas: num site
		 * que JÁ tinha o resumo, perguntar só por ele faz esta função sair cedo
		 * e a tabela de registro nunca nascer. Instalação limpa passava; a
		 * ATUALIZAÇÃO sobre site existente — que é o caso de todo site já
		 * entregue — ficava sem o registro, sem erro nenhum e com a tela
		 * mostrando "pessoas diferentes" em branco para sempre.
		 */
		if ( self::tabela_pronta() && self::eventos_prontos() ) {
			return;
		}

		if ( false === set_transient( 'f3base_comportamento_migrando', 1, MINUTE_IN_SECONDS ) ) {
			return;
		}

		self::criar_tabela();

		if ( self::tabela_pronta() && self::eventos_prontos() ) {
			delete_transient( 'f3base_comportamento_migrando' );
		}
	}

	/* ------------------------------------------------------------------ *
	 * Configuração lida
	 * ------------------------------------------------------------------ */

	/**
	 * O resumo está ligado?
	 *
	 * @return bool
	 */
	public static function ligado(): bool {
		$config = F3Base_Options::ler( 'f3base_comportamento' );

		return ! empty( $config['ligado'] );
	}

	/**
	 * Prazo de guarda das linhas, em dias.
	 *
	 * @return int
	 */
	public static function retencao_dias(): int {
		$config = F3Base_Options::ler( 'f3base_comportamento' );

		return is_array( $config ) ? max( 1, (int) ( $config['retencao_dias'] ?? 90 ) ) : 90;
	}

	/**
	 * Prazo do REGISTRO BRUTO, em dias — próprio e nunca maior que o do resumo.
	 *
	 * @return int
	 */
	public static function retencao_eventos_dias(): int {
		$config = F3Base_Options::ler( 'f3base_comportamento' );

		if ( ! is_array( $config ) ) {
			return 30;
		}

		return max( 1, min( self::retencao_dias(), (int) ( $config['retencao_eventos_dias'] ?? 30 ) ) );
	}

	/**
	 * Período somado pelo quadro da tela, em dias.
	 *
	 * @return int
	 */
	public static function dias_no_painel(): int {
		$config = F3Base_Options::ler( 'f3base_comportamento' );

		return is_array( $config ) ? max( 1, (int) ( $config['dias_no_painel'] ?? 28 ) ) : 28;
	}

	/**
	 * O que o navegador precisa saber para enviar o resumo.
	 *
	 * Viaja DENTRO do mesmo objeto das tags, pelo mesmo portão: um segundo
	 * caminho até o navegador seria um segundo portão para manter e uma segunda
	 * chance de esquecer.
	 *
	 * @return array<string,mixed>
	 */
	public static function dados_do_cliente(): array {
		if ( ! self::ligado() ) {
			return array(
				'ativo'     => false,
				'endpoint'  => '',
				'esquecer'  => '',
				'token'     => '',
				'maximo'    => 0,
				'maximoLog' => 0,
				'maximoVisita' => 0,
				'maximoBytes' => 0,
			);
		}

		return array(
			'ativo'     => true,
			'endpoint'  => esc_url_raw( rest_url( F3BASE_REST_NAMESPACE . self::ROTA ) ),
			/*
			 * O ENDEREÇO DA EXCLUSÃO VIAJA JUNTO. Sem ele no navegador, o
			 * apelido seria apagável só no papel: quem quisesse exercer o
			 * direito teria de descobrir uma rota que ninguém publicou.
			 */
			'esquecer'  => esc_url_raw( rest_url( F3BASE_REST_NAMESPACE . self::ROTA_ESQUECER ) ),
			'token'     => F3Base_Modulo_Endpoint_Leads::emitir_token(),
			'maximo'    => self::maximo_de_metricas(),
			'maximoLog' => self::MAX_EVENTOS,
			'maximoVisita' => self::MAX_POR_VISITA,
			/*
			 * O TETO DE CORPO É PUBLICADO desde a 1.3.5, e ele é o mesmo que a
			 * rota já cobrava. Enquanto o cliente descartava o lote no primeiro
			 * `true` do beacon, um corpo grande era um 413 que ninguém via.
			 * Agora o lote recusado FICA para a tentativa seguinte, e um lote
			 * que nunca cabe seria uma fila que nunca drena — o cliente parte o
			 * registro em lotes que caibam aqui, e para isso ele precisa saber
			 * o número. Escrito lá, ele seria uma segunda verdade sobre o mesmo
			 * limite, divergindo no dia em que alguém mexesse neste.
			 */
			'maximoBytes' => self::MAX_BYTES,
		);
	}

	/**
	 * A JANELA DA VISITA em segundos, lida da MESMA declaração que o cliente lê.
	 *
	 * Ela responde, dos dois lados, à mesma pergunta: até quando duas coisas
	 * ainda são a mesma visita. No navegador ela decide se o carregamento
	 * continua a visita e se um lote pendente ainda é retentativa; aqui ela
	 * decide por quanto tempo o selo daquele lote é lembrado. Um número
	 * escrito aqui divergiria do de lá na primeira vez que alguém mexesse num
	 * só, e a divergência apareceria como linha contada duas vezes — o
	 * cliente reenviando um lote cujo selo o servidor já esqueceu.
	 *
	 * @return int Janela em segundos.
	 */
	public static function janela_da_visita(): int {
		$minutos = 0;

		if ( class_exists( 'F3Base_Modulo_Tracking' ) ) {
			foreach ( F3Base_Modulo_Tracking::eventos_de_comportamento() as $declaracao ) {
				if ( 'pagina' !== (string) ( $declaracao['gatilho'] ?? '' ) ) {
					continue;
				}

				$lista   = (array) ( $declaracao['limiar']['inatividade_min'] ?? array() );
				$minutos = isset( $lista[0] ) ? (int) $lista[0] : 0;
			}
		}

		/*
		 * O PADRÃO DE RESERVA só existe para o caso de a declaração chegar
		 * truncada, e ele é o MESMO que o cliente usa na mesma situação:
		 * reserva diferente dos dois lados é a divergência que esta função
		 * existe para impedir, acontecendo justamente no dia em que o arquivo
		 * se corrompe.
		 */
		return max( MINUTE_IN_SECONDS, ( $minutos > 0 ? $minutos : 30 ) * MINUTE_IN_SECONDS );
	}

	/**
	 * A correlação de um lote, no espaço de chaves DESTA rota.
	 *
	 * O selo é sorteado pelo navegador e só vale dentro de uma visita: são a
	 * visita E o selo que identificam o lote. O prefixo separa este espaço de
	 * chaves do da deduplicação de leads, que usa a mesma tabela e o mesmo
	 * mecanismo — sem ele, um selo de lote e uma correlação de lead com o mesmo
	 * texto seriam a mesma linha, e um deles recusaria o outro.
	 *
	 * @param string $sessao Identificador da visita.
	 * @param string $lote   Selo sorteado do lote.
	 * @return string
	 */
	public static function correlacao_do_lote( string $sessao, string $lote ): string {
		return 'f3base-comportamento-lote|' . $sessao . '|' . $lote;
	}

	/**
	 * Teto de linhas por sessão, DERIVADO da declaração — nunca digitado.
	 *
	 * O teto por página de cada evento já limita quantas vezes ele pode ser
	 * emitido; a soma deles é, por construção, o máximo de linhas distintas que
	 * uma visita pode produzir. Um número escrito aqui seria uma segunda
	 * verdade sobre a mesma coisa, e ela envelheceria na primeira linha
	 * acrescentada ao arquivo de declaração.
	 *
	 * @return int
	 */
	public static function maximo_de_metricas(): int {
		$soma = 0;

		if ( class_exists( 'F3Base_Modulo_Tracking' ) ) {
			foreach ( F3Base_Modulo_Tracking::eventos_de_comportamento() as $dados ) {
				$soma += (int) $dados['teto'];
			}
		}

		return max( 1, $soma );
	}

	/* ------------------------------------------------------------------ *
	 * Rota
	 * ------------------------------------------------------------------ */

	/**
	 * Registra a rota REST.
	 *
	 * @return void
	 */
	public function registrar_rota(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA,
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'receber' ),
				'permission_callback' => '__return_true',
				'args'                => array(),
			)
		);

		/*
		 * O DIREITO DE EXCLUSÃO PRECISA DE UMA PORTA, e ela não pode ser a das
		 * ferramentas de privacidade do WordPress: aquelas procuram por
		 * E-MAIL, e aqui não há e-mail nenhum a que ligar — o apelido é
		 * sorteado no navegador e o site não sabe de quem é. Quem pode pedir a
		 * exclusão é quem tem o apelido: o próprio navegador. É isto que torna
		 * o pseudônimo APAGÁVEL de verdade, e não só no texto da política.
		 */
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA_ESQUECER,
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'esquecer' ),
				'permission_callback' => '__return_true',
				'args'                => array(),
			)
		);
	}

	/**
	 * Apaga o registro detalhado de um visitante, a pedido do navegador dele.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return WP_REST_Response
	 */
	public function esquecer( WP_REST_Request $requisicao ): WP_REST_Response {
		$bruto = $requisicao->get_json_params();
		$bruto = is_array( $bruto ) ? $bruto : array();

		foreach ( array_keys( $bruto ) as $chave ) {
			if ( ! in_array( (string) $chave, array( 'token', 'visitante' ), true ) ) {
				return self::resposta(
					400,
					array(
						'ok'      => false,
						'apagado' => false,
						'codigo'  => 'f3base_campo_desconhecido',
						'campo'   => sanitize_key( (string) $chave ),
						'motivo'  => __( 'Campo fora do schema fechado do endpoint.', 'f3base' ),
					)
				);
			}
		}

		if ( ! F3Base_Modulo_Endpoint_Leads::validar_token( isset( $bruto['token'] ) ? (string) $bruto['token'] : '' ) ) {
			return self::resposta(
				403,
				array(
					'ok'      => false,
					'apagado' => false,
					'codigo'  => 'f3base_token_invalido',
					'motivo'  => __( 'Token efêmero ausente, expirado ou com assinatura inválida.', 'f3base' ),
				)
			);
		}

		if ( ! self::dentro_do_rate_limit() ) {
			return self::resposta(
				429,
				array(
					'ok'      => false,
					'apagado' => false,
					'codigo'  => 'f3base_rate_limit',
					'motivo'  => __( 'Limite de pedidos por janela excedido para esta origem.', 'f3base' ),
				)
			);
		}

		$visitante = isset( $bruto['visitante'] ) ? (string) $bruto['visitante'] : '';

		if ( 1 !== preg_match( self::FORMA_PSEUDONIMO, $visitante ) ) {
			return self::resposta(
				400,
				array(
					'ok'      => false,
					'apagado' => false,
					'codigo'  => 'f3base_pseudonimo_invalido',
					'campo'   => 'visitante',
					'motivo'  => __( 'O apelido do visitante é um hexadecimal sorteado de 32 caracteres.', 'f3base' ),
				)
			);
		}

		$apagadas = self::esquecer_visitante( $visitante );

		/*
		 * ZERO LINHA APAGADA NÃO É ERRO. Um apelido sem registro nenhum é o
		 * caso comum de quem nunca foi medido, e responder 404 diria ao pedinte
		 * se aquele apelido existe no banco — que é informação sobre outra
		 * pessoa quando o apelido é chutado.
		 */
		return self::resposta(
			200,
			array(
				'ok'      => true,
				'apagado' => true,
				'linhas'  => $apagadas,
			)
		);
	}

	/**
	 * Schema FECHADO do corpo aceito.
	 *
	 * @return array<string,string>
	 */
	public static function campos(): array {
		return array(
			'token'     => 'token',
			'caminho'   => 'caminho',
			'metricas'  => 'lista',
			/*
			 * OS TRÊS CAMPOS DA 1.2.0, e eles mudam a natureza do dado. O
			 * `visitante` é um apelido SORTEADO no navegador, de primeira parte
			 * e apagável; `sessao` distingue uma visita da seguinte; `eventos`
			 * é o registro com carimbo de tempo. Com eles o site passa a
			 * guardar dado pessoal pseudonimizado, com prazo próprio e mais
			 * curto — e é por isso que eles são campos declarados no schema
			 * fechado, e não algo que o cliente possa acrescentar.
			 */
			'visitante' => 'pseudonimo',
			'sessao'    => 'pseudonimo',
			'eventos'   => 'lista',
			/*
			 * O QUE O CLIENTE CORTOU, contado por ele. O teto da visita é
			 * gasto ao longo de várias páginas, e só o navegador sabe quanto
			 * já foi. Sem este campo o corte sumiria entre um carregamento e
			 * outro, e o total do painel deixaria de bater com a tabela sem
			 * nada em lugar nenhum dizendo por quê.
			 */
			'cortados'  => 'inteiro',
			/*
			 * O SELO DO LOTE, e ele é o que torna o REENVIO seguro. O cliente
			 * passou a confirmar a entrega em vez de confiar no enfileiramento
			 * do `sendBeacon`, e confirmar implica reenviar: uma resposta
			 * perdida no caminho de volta faria o mesmo lote chegar duas vezes
			 * e a tabela contar duas vezes. Com o selo, o segundo é reconhecido
			 * e recusado — e respondido 2xx assim mesmo, porque para quem envia
			 * "já tenho isto" e "acabei de gravar" são a mesma coisa boa.
			 *
			 * A FORMA É A DO PSEUDÔNIMO, e não um tipo novo: é um hexadecimal
			 * sorteado de 32 caracteres, pelo mesmo alfabeto fechado e pela
			 * mesma razão — um campo que aceitasse texto livre aceitaria um
			 * e-mail. Vazio é aceito: sem gerador criptográfico o navegador não
			 * tem selo, e nesse caso ele também não tem apelido nem visita
			 * gravada, então não há retentativa para deduplicar.
			 */
			'lote'      => 'pseudonimo',
		);
	}

	/**
	 * Schema FECHADO de cada linha do REGISTRO.
	 *
	 * @return array<string,string>
	 */
	public static function campos_do_evento(): array {
		return array(
			'gatilho'    => 'chave',
			'detalhe'    => 'detalhe',
			'valor'      => 'numero',
			'ocorrencia' => 'inteiro',
			'ms'         => 'inteiro',
		);
	}

	/**
	 * Valida o REGISTRO recebido.
	 *
	 * O corte do excedente é NOSSO e é declarado: acima do teto, o evento não
	 * vira linha de registro — mas ele já foi somado no agregado pelo mesmo
	 * corpo, então o número total continua certo e o que se perde é só o
	 * detalhe individual. Descartar em silêncio seria a outra saída, e ela faz
	 * o operador ler um total que não bate com o registro.
	 *
	 * @param mixed  $bruto     Lista recebida.
	 * @param string $visitante Pseudônimo do visitante.
	 * @param string $sessao    Identificador da visita.
	 * @param string $caminho   Caminho normalizado.
	 * @return array{linhas:array<int,array<string,mixed>>,cortados:int,erro?:array<string,mixed>}
	 */
	public static function validar_eventos( $bruto, string $visitante, string $sessao, string $caminho ): array {
		if ( null === $bruto || array() === $bruto ) {
			return array(
				'linhas'   => array(),
				'cortados' => 0,
			);
		}

		if ( ! is_array( $bruto ) ) {
			return array(
				'linhas'   => array(),
				'cortados' => 0,
				'erro'     => array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_eventos_invalidos',
					'campo'      => 'eventos',
					'motivo'     => __( 'O registro precisa ser uma lista de acontecimentos.', 'f3base' ),
				),
			);
		}

		$declarados = class_exists( 'F3Base_Modulo_Tracking' )
			? F3Base_Modulo_Tracking::eventos_de_comportamento()
			: array();

		$por_gatilho = array();

		foreach ( $declarados as $nome => $dados ) {
			$por_gatilho[ (string) $dados['gatilho'] ] = (string) $nome;
		}

		$permitidos = self::campos_do_evento();
		$linhas     = array();
		$cortados   = 0;

		foreach ( $bruto as $entrada ) {
			if ( ! is_array( $entrada ) ) {
				return array(
					'linhas'   => array(),
					'cortados' => 0,
					'erro'     => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_evento_invalido',
						'campo'      => 'eventos',
						'motivo'     => __( 'Cada acontecimento do registro precisa ser um objeto com gatilho e carimbo de tempo.', 'f3base' ),
					),
				);
			}

			foreach ( array_keys( $entrada ) as $chave ) {
				if ( ! isset( $permitidos[ (string) $chave ] ) ) {
					return array(
						'linhas'   => array(),
						'cortados' => 0,
						'erro'     => array(
							'ok'         => false,
							'registrado' => false,
							'codigo'     => 'f3base_campo_desconhecido',
							'campo'      => sanitize_key( (string) $chave ),
							'motivo'     => __( 'Campo fora do schema fechado de um acontecimento do registro. O schema é fechado também DENTRO da lista: é ele que impede um campo novo — e um dado novo — de entrar sem que ninguém tenha decidido que podia.', 'f3base' ),
						),
					);
				}
			}

			$gatilho = isset( $entrada['gatilho'] ) ? sanitize_key( (string) $entrada['gatilho'] ) : '';

			if ( ! isset( $por_gatilho[ $gatilho ] ) ) {
				return array(
					'linhas'   => array(),
					'cortados' => 0,
					'erro'     => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_gatilho_nao_declarado',
						'campo'      => 'gatilho',
						'motivo'     => __( 'Gatilho fora da declaração de eventos de comportamento: o nome sai da declaração, e gatilho sem linha lá não vira registro nenhum.', 'f3base' ),
					),
				);
			}

			$detalhe = isset( $entrada['detalhe'] ) ? trim( (string) $entrada['detalhe'] ) : '';

			if ( '' !== $detalhe && 1 !== preg_match( self::FORMA_DETALHE, $detalhe ) ) {
				return array(
					'linhas'   => array(),
					'cortados' => 0,
					'erro'     => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_detalhe_invalido',
						'campo'      => 'detalhe',
						'motivo'     => __( 'O detalhe está fora do alfabeto fechado, que é o que impede caminho de arquivo, endereço e texto livre de chegarem aqui.', 'f3base' ),
					),
				);
			}

			$ms = isset( $entrada['ms'] ) ? (int) $entrada['ms'] : -1;

			if ( $ms < 0 || $ms > self::MAX_MS ) {
				return array(
					'linhas'   => array(),
					'cortados' => 0,
					'erro'     => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_carimbo_invalido',
						'campo'      => 'ms',
						'motivo'     => __( 'O carimbo é a distância em milissegundos entre o carregamento da página e o acontecimento, e ele tem teto declarado: acima dele não é tempo de leitura, é aba esquecida aberta.', 'f3base' ),
					),
				);
			}

			$ocorrencia = isset( $entrada['ocorrencia'] ) ? (int) $entrada['ocorrencia'] : 1;

			if ( $ocorrencia < 1 ) {
				return array(
					'linhas'   => array(),
					'cortados' => 0,
					'erro'     => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_ocorrencia_invalida',
						'campo'      => 'ocorrencia',
						'motivo'     => __( 'A ocorrência diz se aquela foi a primeira, a segunda ou a enésima vez que o visitante passou por ali nesta visita, e começa em um.', 'f3base' ),
					),
				);
			}

			$valor = isset( $entrada['valor'] ) && is_numeric( $entrada['valor'] ) ? (float) $entrada['valor'] : 0.0;

			if ( ! is_finite( $valor ) || $valor < 0 ) {
				return array(
					'linhas'   => array(),
					'cortados' => 0,
					'erro'     => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_valor_invalido',
						'campo'      => 'valor',
						'motivo'     => __( 'O valor precisa ser um número finito não negativo.', 'f3base' ),
					),
				);
			}

			if ( count( $linhas ) >= self::MAX_EVENTOS ) {
				++$cortados;

				continue;
			}

			$linhas[] = array(
				'visitante'  => $visitante,
				'sessao'     => $sessao,
				'caminho'    => $caminho,
				'metrica'    => $por_gatilho[ $gatilho ],
				'detalhe'    => $detalhe,
				'valor'      => $valor,
				'ocorrencia' => $ocorrencia,
				'ms'         => $ms,
			);
		}

		return array(
			'linhas'   => $linhas,
			'cortados' => $cortados,
		);
	}

	/**
	 * Schema FECHADO de cada entrada da lista.
	 *
	 * @return array<string,string>
	 */
	public static function campos_da_metrica(): array {
		return array(
			'gatilho'  => 'chave',
			'detalhe'  => 'detalhe',
			'contagem' => 'inteiro',
			'soma'     => 'numero',
		);
	}

	/**
	 * Recebe o resumo de uma sessão.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return WP_REST_Response
	 */
	public function receber( WP_REST_Request $requisicao ): WP_REST_Response {
		if ( ! self::ligado() ) {
			return self::resposta(
				409,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_resumo_desligado',
					'motivo'     => __( 'O resumo de comportamento está desligado neste site: nada é somado e nada é guardado.', 'f3base' ),
				)
			);
		}

		$corpo = (string) $requisicao->get_body();

		if ( strlen( $corpo ) > self::MAX_BYTES ) {
			return self::resposta(
				413,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_corpo_grande',
					'limite'     => self::MAX_BYTES,
					'motivo'     => __( 'Corpo acima do limite declarado do endpoint.', 'f3base' ),
				)
			);
		}

		$bruto = $requisicao->get_json_params();

		if ( ! is_array( $bruto ) ) {
			$bruto = $requisicao->get_body_params();
		}

		if ( ! is_array( $bruto ) ) {
			$bruto = array();
		}

		$campos = self::campos();

		foreach ( array_keys( $bruto ) as $chave ) {
			if ( ! isset( $campos[ (string) $chave ] ) ) {
				return self::resposta(
					400,
					array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_campo_desconhecido',
						'campo'      => sanitize_key( (string) $chave ),
						'motivo'     => __( 'Campo fora do schema fechado do endpoint.', 'f3base' ),
					)
				);
			}
		}

		if ( ! F3Base_Modulo_Endpoint_Leads::validar_token( isset( $bruto['token'] ) ? (string) $bruto['token'] : '' ) ) {
			return self::resposta(
				403,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_token_invalido',
					'motivo'     => __( 'Token efêmero ausente, expirado ou com assinatura inválida.', 'f3base' ),
				)
			);
		}

		if ( ! self::dentro_do_rate_limit() ) {
			return self::resposta(
				429,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_rate_limit',
					'motivo'     => __( 'Limite de resumos por janela excedido para esta origem.', 'f3base' ),
				)
			);
		}

		$caminho = self::normalizar_caminho( isset( $bruto['caminho'] ) ? (string) $bruto['caminho'] : '' );

		if ( '' === $caminho ) {
			return self::resposta(
				400,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_caminho_invalido',
					'campo'      => 'caminho',
					'motivo'     => __( 'O caminho precisa ser um caminho deste site, começando por barra, sem query e sem fragmento.', 'f3base' ),
				)
			);
		}

		/*
		 * O PSEUDÔNIMO É EXIGIDO NA FORMA, e não na existência: uma sessão que
		 * não mande identificador nenhum continua somando no agregado — é o
		 * caminho de quem tem o armazenamento local bloqueado —, e o que ela
		 * perde é só o registro detalhado. Recusar o corpo inteiro por causa
		 * dele trocaria medição parcial por medição nenhuma.
		 */
		$visitante = isset( $bruto['visitante'] ) ? (string) $bruto['visitante'] : '';
		$sessao    = isset( $bruto['sessao'] ) ? (string) $bruto['sessao'] : '';
		$lote      = isset( $bruto['lote'] ) ? (string) $bruto['lote'] : '';

		foreach ( array( 'visitante' => $visitante, 'sessao' => $sessao, 'lote' => $lote ) as $campo_do_pseudonimo => $valor_do_pseudonimo ) {
			if ( '' !== $valor_do_pseudonimo && 1 !== preg_match( self::FORMA_PSEUDONIMO, $valor_do_pseudonimo ) ) {
				return self::resposta(
					400,
					array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_pseudonimo_invalido',
						'campo'      => $campo_do_pseudonimo,
						'motivo'     => __( 'O apelido do visitante e o da visita são hexadecimais sorteados de 32 caracteres. O alfabeto é fechado de propósito: um campo que aceitasse texto livre aceitaria um e-mail, e o site passaria a guardar dado direto sem que nada acusasse.', 'f3base' ),
					)
				);
			}
		}

		$linhas = self::validar_metricas( isset( $bruto['metricas'] ) ? $bruto['metricas'] : null );

		if ( isset( $linhas['erro'] ) ) {
			return self::resposta( 400, $linhas['erro'] );
		}

		if ( array() === $linhas['linhas'] ) {
			return self::resposta(
				200,
				array(
					'ok'         => true,
					'registrado' => false,
					'motivo'     => __( 'Sessão sem nenhum total a somar: nada foi gravado.', 'f3base' ),
				)
			);
		}

		if ( ! self::tabela_pronta() ) {
			return self::resposta(
				503,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_armazenamento_indisponivel',
					'tabela'     => self::nome_tabela(),
					'motivo'     => __( 'A tabela do resumo não está pronta com as colunas desta versão: nada foi somado. A perda é declarada em vez de silenciosa, e o módulo aparece como degradado na tela.', 'f3base' ),
				)
			);
		}

		/*
		 * O REGISTRO SÓ EXISTE COM OS DOIS PSEUDÔNIMOS. Sem eles não há como
		 * separar visitante de visitante nem visita de visita, que é a única
		 * coisa que esta tabela existe para fazer — e uma linha sem eles seria
		 * dado guardado sem servir a pergunta nenhuma.
		 */
		$registro  = array( 'linhas' => array(), 'cortados' => 0 );
		$registradas = 0;

		if ( '' !== $visitante && '' !== $sessao ) {
			$registro = self::validar_eventos( isset( $bruto['eventos'] ) ? $bruto['eventos'] : null, $visitante, $sessao, $caminho );

			if ( isset( $registro['erro'] ) ) {
				return self::resposta( 400, $registro['erro'] );
			}
		}

		/*
		 * O SELO É RESERVADO ANTES DE QUALQUER ESCRITA, e a reserva é a MESMA
		 * do lead — inserção atômica na chave única, confirmação depois da
		 * persistência, compensação quando nada foi gravado. Uma segunda
		 * implementação aqui seria uma segunda regra para o mesmo risco, e a
		 * segunda é a que fica para trás.
		 *
		 * POR QUE ELA PRECISA DAS TRÊS ETAPAS, e não de uma marca simples.
		 * Marcando o selo e gravando em seguida, uma escrita que FALHA deixa o
		 * selo queimado: a retentativa recebe "já gravei isto", o cliente
		 * esquece o lote, e as linhas somem — o mesmo buraco de sequência que
		 * esta release existe para fechar, agora vindo do conserto. A reserva
		 * nasce PENDENTE, vira FIRME só depois de a linha estar no banco, e é
		 * APAGADA quando nada foi gravado.
		 *
		 * SELO VAZIO NÃO RESERVA NADA. Sem gerador criptográfico o navegador
		 * não tem selo — e também não tem apelido nem visita gravada, então não
		 * há pendente para reenviar e não há o que deduplicar. Recusar o corpo
		 * por causa disso trocaria medição parcial por medição nenhuma, que é a
		 * mesma escolha já feita para o pseudônimo ausente.
		 */
		$selado = '' !== $lote && '' !== $sessao;
		$reserva = array( 'novo' => true );

		if ( $selado ) {
			$reserva = F3Base_Modulo_Endpoint_Leads::reservar(
				self::correlacao_do_lote( $sessao, $lote ),
				$lote,
				self::janela_da_visita()
			);
		}

		if ( ! (bool) $reserva['novo'] ) {
			/*
			 * REPETIÇÃO RESPONDE 2XX, e isso é decisão e não descuido. Para
			 * quem envia, "já tenho isto" e "acabei de gravar" precisam ser a
			 * mesma resposta boa: qualquer outro código faria o cliente reter o
			 * lote e reenviá-lo para sempre, exatamente o lote que o servidor
			 * já tem.
			 */
			return self::resposta(
				200,
				array(
					'ok'         => true,
					'registrado' => false,
					'codigo'     => 'f3base_lote_repetido',
					'motivo'     => __( 'Este lote já foi gravado para esta visita: nada foi somado de novo. É o que permite ao navegador reenviar um lote cuja resposta se perdeu no caminho de volta sem que a tabela conte duas vezes.', 'f3base' ),
				)
			);
		}

		$gravadas = 0;

		foreach ( $linhas['linhas'] as $linha ) {
			if ( self::somar( $caminho, (string) $linha['metrica'], (string) $linha['detalhe'], (int) $linha['contagem'], (float) $linha['soma'] ) ) {
				++$gravadas;
			}
		}

		/*
		 * A ORDEM IMPORTA: o agregado é somado ANTES do registro. Se o banco
		 * recusar a segunda escrita, o número do painel continua certo e o que
		 * se perde é o detalhe — a perda cai no lado menos grave, e não no
		 * total que o operador lê.
		 */
		foreach ( $registro['linhas'] as $evento_a_gravar ) {
			if ( self::registrar_evento( $evento_a_gravar ) ) {
				++$registradas;
			}
		}

		if ( 0 === $gravadas ) {
			/*
			 * NADA GRAVADO, SELO DEVOLVIDO. Sem esta compensação o lote ficaria
			 * marcado como recebido sobre um banco que recusou a escrita, e a
			 * retentativa do navegador — que agora existe — seria respondida
			 * "já tenho isto" sobre nada.
			 */
			if ( $selado ) {
				F3Base_Modulo_Endpoint_Leads::liberar_reserva( self::correlacao_do_lote( $sessao, $lote ) );
			}

			return self::resposta(
				503,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_gravacao_indisponivel',
					'tabela'     => self::nome_tabela(),
					'motivo'     => __( 'Nenhuma linha do resumo foi somada: o banco recusou a escrita. Nada foi guardado, e o navegador reenvia este mesmo lote na tentativa seguinte.', 'f3base' ),
				)
			);
		}

		if ( $selado ) {
			F3Base_Modulo_Endpoint_Leads::confirmar_reserva(
				self::correlacao_do_lote( $sessao, $lote ),
				$lote,
				self::janela_da_visita()
			);
		}

		/*
		 * O CORTE É GRAVADO, e não só respondido. Ele saía nomeado no corpo da
		 * resposta — que morre no navegador —, e quem abria a tela Medição não
		 * tinha como saber que a tabela estava incompleta. Somado aqui, ele
		 * viaja com a mesma granularidade e o mesmo prazo do resto do resumo, e
		 * a tela o mostra ao lado do total.
		 */
		$cortados = (int) $registro['cortados'] + max( 0, (int) ( $bruto['cortados'] ?? 0 ) );

		if ( $cortados > 0 ) {
			self::somar( $caminho, self::METRICA_CORTADAS, '', $cortados, 0.0 );
		}

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMO_COMPORTAMENTO,
			array(
				'caminho' => $caminho,
				'linhas'  => $gravadas,
			)
		);

		return self::resposta(
			201,
			array(
				'ok'         => true,
				'registrado' => true,
				'linhas'     => $gravadas,
				/*
				 * O CORTE SAI NOMEADO NA RESPOSTA. Um teto que corta em
				 * silêncio faz o operador ler um total do agregado que não bate
				 * com o registro, sem nada em lugar nenhum dizendo por quê.
				 */
				'registro'   => $registradas,
				'cortados'   => $cortados,
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Validação
	 * ------------------------------------------------------------------ */

	/**
	 * O caminho da página, normalizado — ou string vazia quando não serve.
	 *
	 * @param string $bruto Caminho recebido.
	 * @return string
	 */
	public static function normalizar_caminho( string $bruto ): string {
		$bruto = trim( $bruto );

		if ( '' === $bruto ) {
			return '';
		}

		/* Query e fragmento não entram: é ali que mora o identificador colado por terceiro. */
		if ( str_contains( $bruto, '?' ) || str_contains( $bruto, '#' ) ) {
			return '';
		}

		if ( 1 !== preg_match( self::FORMA_CAMINHO, $bruto ) ) {
			return '';
		}

		/* `..` sairia da árvore do site e faria duas páginas somarem na mesma linha. */
		if ( str_contains( $bruto, '..' ) ) {
			return '';
		}

		return $bruto;
	}

	/**
	 * Valida a lista de totais contra o schema fechado e a declaração.
	 *
	 * @param mixed $bruto Lista recebida.
	 * @return array{linhas:array<int,array<string,mixed>>,erro?:array<string,mixed>}
	 */
	public static function validar_metricas( $bruto ): array {
		if ( ! is_array( $bruto ) ) {
			return array(
				'linhas' => array(),
				'erro'   => array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_metricas_invalidas',
					'campo'      => 'metricas',
					'motivo'     => __( 'O campo de totais precisa ser uma lista.', 'f3base' ),
				),
			);
		}

		$maximo = self::maximo_de_metricas();

		if ( count( $bruto ) > $maximo ) {
			return array(
				'linhas' => array(),
				'erro'   => array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_metricas_demais',
					'campo'      => 'metricas',
					'limite'     => $maximo,
					'motivo'     => __( 'A sessão trouxe mais totais do que o teto somado que a declaração de eventos permite por página.', 'f3base' ),
				),
			);
		}

		$declarados = class_exists( 'F3Base_Modulo_Tracking' )
			? F3Base_Modulo_Tracking::eventos_de_comportamento()
			: array();

		$por_gatilho = array();

		foreach ( $declarados as $nome => $dados ) {
			$por_gatilho[ (string) $dados['gatilho'] ] = (string) $nome;
		}

		$permitidos = self::campos_da_metrica();
		$linhas     = array();

		foreach ( $bruto as $entrada ) {
			if ( ! is_array( $entrada ) ) {
				return array(
					'linhas' => array(),
					'erro'   => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_metrica_invalida',
						'campo'      => 'metricas',
						'motivo'     => __( 'Cada total precisa ser um objeto com gatilho e contagem.', 'f3base' ),
					),
				);
			}

			foreach ( array_keys( $entrada ) as $chave ) {
				if ( ! isset( $permitidos[ (string) $chave ] ) ) {
					return array(
						'linhas' => array(),
						'erro'   => array(
							'ok'         => false,
							'registrado' => false,
							'codigo'     => 'f3base_campo_desconhecido',
							'campo'      => sanitize_key( (string) $chave ),
							'motivo'     => __( 'Campo fora do schema fechado de um total. O schema é fechado também DENTRO da lista: um campo novo aqui é um payload que ninguém decidiu que podia existir.', 'f3base' ),
						),
					);
				}
			}

			$gatilho = isset( $entrada['gatilho'] ) ? sanitize_key( (string) $entrada['gatilho'] ) : '';

			if ( ! isset( $por_gatilho[ $gatilho ] ) ) {
				return array(
					'linhas' => array(),
					'erro'   => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_gatilho_nao_declarado',
						'campo'      => 'gatilho',
						'motivo'     => __( 'Gatilho fora da declaração de eventos de comportamento: o nome do evento sai da declaração, e gatilho sem linha lá não vira medição nenhuma.', 'f3base' ),
					),
				);
			}

			$detalhe = isset( $entrada['detalhe'] ) ? trim( (string) $entrada['detalhe'] ) : '';

			if ( '' !== $detalhe && 1 !== preg_match( self::FORMA_DETALHE, $detalhe ) ) {
				return array(
					'linhas' => array(),
					'erro'   => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_detalhe_invalido',
						'campo'      => 'detalhe',
						'motivo'     => __( 'O detalhe está fora do alfabeto fechado: ele aceita host, nome de seção, marco e nome de métrica, e não aceita espaço, arroba, barra nem dois-pontos — que é o que impede caminho de arquivo, endereço e texto livre de chegarem aqui.', 'f3base' ),
					),
				);
			}

			$contagem = isset( $entrada['contagem'] ) ? (int) $entrada['contagem'] : 0;
			$soma     = isset( $entrada['soma'] ) && is_numeric( $entrada['soma'] ) ? (float) $entrada['soma'] : 0.0;

			if ( $contagem < 1 || ! is_finite( $soma ) || $soma < 0 ) {
				return array(
					'linhas' => array(),
					'erro'   => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_total_invalido',
						'campo'      => 'contagem',
						'motivo'     => __( 'Contagem precisa ser inteiro positivo, e a soma precisa ser um número finito não negativo.', 'f3base' ),
					),
				);
			}

			$linhas[] = array(
				'metrica'  => $por_gatilho[ $gatilho ],
				'detalhe'  => $detalhe,
				'contagem' => $contagem,
				'soma'     => $soma,
			);
		}

		return array( 'linhas' => $linhas );
	}

	/**
	 * A origem está dentro do limite da janela?
	 *
	 * O balde é o MESMO mecanismo atômico do endpoint de leads — uma instrução,
	 * e quem soma é o banco. Uma segunda implementação aqui seria uma segunda
	 * regra para o mesmo risco, e a segunda é a que fica para trás.
	 *
	 * O EIXO CONTINUA SENDO A ORIGEM, e a alternativa foi medida antes de ser
	 * recusada: um balde por VISITANTE seria um balde cuja chave quem bate na
	 * porta escolhe. O apelido do visitante é sorteado dentro do navegador, e
	 * trocá-lo custa uma linha de JavaScript — o limite recusaria exatamente
	 * quem não tem nada a esconder e não recusaria mais ninguém. É a mesma
	 * razão pela qual o cabeçalho de proxy não é aceito sem declaração:
	 * controle chaveado por declaração do cliente não é controle.
	 *
	 * O NÚMERO MUDOU, E O MOTIVO É MEDIDO. Sessenta por dez minutos nasceu
	 * quando o envio era UM por sessão de página. Com o envio por lote, um
	 * leitor atento produz um lote por ocultamento — e ocultamento acontece
	 * toda vez que a aba perde o foco, não só na saída. Atrás de CDN, com
	 * `f3base_origem_confiavel` vazia (que é o caso medido em
	 * `fator3-teste-mcp-1`), a origem é a MESMA para todo mundo, e um visitante
	 * intenso esgotava o balde do site inteiro. O novo valor é
	 * `MAX_POR_VISITA`, e ele não é número novo: é o teto de linhas que UMA
	 * visita pode escrever, e um balde que não cabe uma visita inteira recusa o
	 * leitor mais atento do site antes de recusar qualquer abuso.
	 *
	 * O QUE O BALDE PASSOU A CUSTAR. Antes, cada 429 era um lote perdido em
	 * silêncio. Agora ele é retentativa: o lote fica pendente, com o mesmo
	 * selo, e parte no ocultamento seguinte ou no carregamento seguinte da
	 * mesma visita. O balde deixou de decidir o que é MEDIDO e passou a decidir
	 * QUANDO — e é por isso que ele pôde ser calibrado sem abrir a porta.
	 *
	 * O QUE ELE CONTINUA SEM RESOLVER, e fica escrito: atrás de CDN o balde é
	 * do site inteiro, e nenhum número conserta isso. A resposta certa é
	 * declarar `f3base_origem_confiavel`, que já existe e já é ensinada na tela
	 * de configuração — o que faltava era alguém dizer que ESTA rota depende
	 * dela tanto quanto a de leads.
	 *
	 * @return bool
	 */
	public static function dentro_do_rate_limit(): bool {
		$janela = max( 60, (int) apply_filters( 'f3base_comportamento_rate_limit_janela', 10 * MINUTE_IN_SECONDS ) );
		$limite = max( 1, (int) apply_filters( 'f3base_comportamento_rate_limit_maximo', self::MAX_POR_VISITA ) );

		$origem = F3Base_Modulo_Endpoint_Leads::origem();
		$chave  = hash( 'sha256', 'comportamento|' . $origem['valor'] . '|' . wp_salt( 'nonce' ) );

		return F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave, $janela ) <= $limite;
	}

	/* ------------------------------------------------------------------ *
	 * Armazenamento
	 * ------------------------------------------------------------------ */

	/**
	 * Nome completo da tabela.
	 *
	 * @return string
	 */
	public static function nome_tabela(): string {
		global $wpdb;

		return $wpdb->prefix . self::TABELA;
	}

	/**
	 * A tabela está PRONTA — existe e traz as colunas desta versão?
	 *
	 * @return bool
	 */
	public static function tabela_pronta(): bool {
		if ( null !== self::$tabela_pronta ) {
			return self::$tabela_pronta;
		}

		global $wpdb;

		$tabela = self::nome_tabela();
		$achado = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $tabela ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		if ( $achado !== $tabela ) {
			self::$tabela_pronta = false;

			return self::$tabela_pronta;
		}

		$colunas = $wpdb->get_col( "SHOW COLUMNS FROM {$tabela}" ); // phpcs:ignore WordPress.DB
		$colunas = is_array( $colunas ) ? array_map( 'strval', $colunas ) : array();

		self::$tabela_pronta = array() === array_diff( self::COLUNAS, $colunas );

		return self::$tabela_pronta;
	}

	/**
	 * Cria — ou migra — a tabela do resumo.
	 *
	 * TABELA PRÓPRIA, E NÃO OPTION. Contador diário cresce todo dia: uma option
	 * com o resumo dentro cresceria sem teto e, sendo autoload, seria lida em
	 * TODA requisição do site, inclusive nas que nada têm a ver com medição.
	 *
	 * @return void
	 */
	public static function criar_tabela(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$tabela  = self::nome_tabela();
		$collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$tabela} (
	chave char(64) NOT NULL,
	dia char(10) NOT NULL,
	caminho varchar(190) NOT NULL,
	metrica varchar(64) NOT NULL,
	detalhe varchar(60) NOT NULL DEFAULT '',
	contagem bigint(20) unsigned NOT NULL DEFAULT 0,
	soma double NOT NULL DEFAULT 0,
	atualizado_em bigint(20) unsigned NOT NULL DEFAULT 0,
	PRIMARY KEY  (chave),
	KEY dia (dia),
	KEY dia_metrica (dia,metrica)
) {$collate};";

		dbDelta( $sql );

		$eventos = self::nome_tabela_eventos();

		/*
		 * O REGISTRO DE EVENTOS. Chave primária artificial de propósito: aqui
		 * NADA soma — cada travessia de marco é uma linha, e é essa
		 * granularidade que responde "ele voltou e leu de novo?". Os índices
		 * são os três cortes que a tela faz: por dia, por página no dia, e por
		 * sessão, que é como o tempo até cada marco é reconstruído.
		 */
		$sql_eventos = "CREATE TABLE {$eventos} (
	id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
	visitante char(32) NOT NULL,
	sessao char(32) NOT NULL,
	dia char(10) NOT NULL,
	caminho varchar(190) NOT NULL,
	metrica varchar(64) NOT NULL,
	detalhe varchar(60) NOT NULL DEFAULT '',
	valor double NOT NULL DEFAULT 0,
	ocorrencia int(10) unsigned NOT NULL DEFAULT 1,
	ms bigint(20) unsigned NOT NULL DEFAULT 0,
	criado_em bigint(20) unsigned NOT NULL DEFAULT 0,
	PRIMARY KEY  (id),
	KEY dia (dia),
	KEY dia_caminho (dia,caminho),
	KEY sessao (sessao),
	KEY visitante (visitante)
) {$collate};";

		dbDelta( $sql_eventos );

		self::$tabela_pronta = null;
		self::$eventos_prontos = null;
	}

	/**
	 * Nome completo da tabela de registro.
	 *
	 * @return string
	 */
	public static function nome_tabela_eventos(): string {
		global $wpdb;

		return $wpdb->prefix . self::TABELA_EVENTOS;
	}

	/**
	 * O registro de eventos está pronto com as colunas desta versão?
	 *
	 * @return bool
	 */
	public static function eventos_prontos(): bool {
		if ( null !== self::$eventos_prontos ) {
			return self::$eventos_prontos;
		}

		global $wpdb;

		$tabela = self::nome_tabela_eventos();
		$achado = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $tabela ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		if ( $achado !== $tabela ) {
			self::$eventos_prontos = false;

			return self::$eventos_prontos;
		}

		$colunas = $wpdb->get_col( "SHOW COLUMNS FROM {$tabela}" ); // phpcs:ignore WordPress.DB
		$colunas = is_array( $colunas ) ? array_map( 'strval', $colunas ) : array();

		self::$eventos_prontos = array() === array_diff( self::COLUNAS_EVENTOS, $colunas );

		return self::$eventos_prontos;
	}

	/**
	 * Grava uma linha de registro. Aqui nada soma: cada evento é uma linha.
	 *
	 * @param array<string,mixed> $evento Evento já validado.
	 * @return bool
	 */
	public static function registrar_evento( array $evento ): bool {
		if ( ! self::eventos_prontos() ) {
			return false;
		}

		global $wpdb;

		$anterior = $wpdb->suppress_errors( true );

		$gravou = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			self::nome_tabela_eventos(),
			array(
				'visitante'  => (string) $evento['visitante'],
				'sessao'     => (string) $evento['sessao'],
				'dia'        => gmdate( 'Y-m-d' ),
				'caminho'    => (string) $evento['caminho'],
				'metrica'    => (string) $evento['metrica'],
				'detalhe'    => (string) $evento['detalhe'],
				'valor'      => (float) $evento['valor'],
				'ocorrencia' => (int) $evento['ocorrencia'],
				'ms'         => (int) $evento['ms'],
				'criado_em'  => time(),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%f', '%d', '%d', '%d' )
		);

		$wpdb->suppress_errors( $anterior );

		return false !== $gravou;
	}

	/**
	 * Apaga o REGISTRO que passou do prazo próprio dele.
	 *
	 * PRAZO PRÓPRIO E MAIS CURTO, e é a diferença entre as duas tabelas que
	 * justifica as duas existirem: o agregado não identifica ninguém e pode
	 * durar; o registro é pseudonimizado e some antes.
	 *
	 * @return int Linhas eliminadas.
	 */
	public static function podar_eventos(): int {
		if ( ! self::eventos_prontos() ) {
			return 0;
		}

		global $wpdb;

		$tabela = self::nome_tabela_eventos();
		$corte  = gmdate( 'Y-m-d', time() - ( self::retencao_eventos_dias() * DAY_IN_SECONDS ) );

		$linhas = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"DELETE FROM {$tabela} WHERE dia < %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$corte
			)
		);

		return is_numeric( $linhas ) ? (int) $linhas : 0;
	}

	/**
	 * ESQUECE UM VISITANTE — o direito de exclusão, exercido por quem tem o
	 * pseudônimo: o próprio navegador dele.
	 *
	 * O pseudônimo é de primeira parte e sorteado; ninguém, nem o operador,
	 * consegue ligá-lo a uma pessoa. Por isso a exclusão não pode passar pelas
	 * ferramentas de privacidade do WordPress, que procuram por e-mail: não há
	 * e-mail a que ligar. Quem pede é o navegador que guarda o identificador, e
	 * é a essa chamada que este método responde.
	 *
	 * @param string $visitante Pseudônimo.
	 * @return int Linhas apagadas.
	 */
	public static function esquecer_visitante( string $visitante ): int {
		if ( ! self::eventos_prontos() || 1 !== preg_match( self::FORMA_PSEUDONIMO, $visitante ) ) {
			return 0;
		}

		global $wpdb;

		$tabela = self::nome_tabela_eventos();

		$linhas = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"DELETE FROM {$tabela} WHERE visitante = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$visitante
			)
		);

		return is_numeric( $linhas ) ? (int) $linhas : 0;
	}

	/**
	 * A chave da linha: dia, caminho, evento e detalhe, e nada mais.
	 *
	 * @param string $dia     Dia em Y-m-d.
	 * @param string $caminho Caminho da página.
	 * @param string $metrica Nome declarado do evento.
	 * @param string $detalhe Detalhe do evento.
	 * @return string
	 */
	public static function chave_da_linha( string $dia, string $caminho, string $metrica, string $detalhe ): string {
		return hash( 'sha256', $dia . '|' . $caminho . '|' . $metrica . '|' . $detalhe );
	}

	/**
	 * Soma um total na linha do dia, criando-a quando ela ainda não existe.
	 *
	 * DUAS SESSÕES SOMAM NA MESMA LINHA, e é o banco que soma: `INSERT … ON
	 * DUPLICATE KEY UPDATE` numa instrução só. Ler, somar e gravar em três
	 * passos perderia incrementos sob concorrência exatamente no horário de
	 * pico, que é quando o número importa.
	 *
	 * @param string $caminho  Caminho da página.
	 * @param string $metrica  Nome declarado do evento.
	 * @param string $detalhe  Detalhe do evento.
	 * @param int    $contagem Quantidade a somar.
	 * @param float  $soma     Valor a somar (vitais).
	 * @return bool
	 */
	public static function somar( string $caminho, string $metrica, string $detalhe, int $contagem, float $soma ): bool {
		if ( ! self::tabela_pronta() ) {
			return false;
		}

		global $wpdb;

		$tabela = self::nome_tabela();
		$dia    = gmdate( 'Y-m-d' );
		$chave  = self::chave_da_linha( $dia, $caminho, $metrica, $detalhe );
		$agora  = time();

		$anterior = $wpdb->suppress_errors( true );

		$linhas = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"INSERT INTO {$tabela} (chave, dia, caminho, metrica, detalhe, contagem, soma, atualizado_em) VALUES (%s, %s, %s, %s, %s, %d, %f, %d) ON DUPLICATE KEY UPDATE contagem = contagem + %d, soma = soma + %f, atualizado_em = %d", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave,
				$dia,
				$caminho,
				$metrica,
				$detalhe,
				$contagem,
				$soma,
				$agora,
				$contagem,
				$soma,
				$agora
			)
		);

		$wpdb->suppress_errors( $anterior );

		return false !== $linhas;
	}

	/**
	 * Apaga o que passou do prazo declarado.
	 *
	 * @return int Linhas eliminadas.
	 */
	public static function podar(): int {
		if ( ! self::tabela_pronta() ) {
			return 0;
		}

		global $wpdb;

		$tabela = self::nome_tabela();
		$corte  = gmdate( 'Y-m-d', time() - ( self::retencao_dias() * DAY_IN_SECONDS ) );

		$linhas = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"DELETE FROM {$tabela} WHERE dia < %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$corte
			)
		);

		return is_numeric( $linhas ) ? (int) $linhas : 0;
	}

	/* ------------------------------------------------------------------ *
	 * Leitura
	 * ------------------------------------------------------------------ */

	/**
	 * DESDE QUANDO ESTE SITE ESTÁ COLETANDO, medido no dado e não na option.
	 *
	 * A tela vazia precisa responder "faz quanto tempo?", e a resposta honesta
	 * é o dia mais antigo que a tabela guarda. Ler a data em que a option foi
	 * ligada mentiria nos dois sentidos: a option pode ter sido ligada ontem
	 * sobre uma tabela antiga, e pode estar ligada desde a entrega sobre uma
	 * tabela que a retenção já esvaziou.
	 *
	 * @return string Dia no formato Y-m-d; vazio quando não há linha nenhuma.
	 */
	public static function coletando_desde(): string {
		if ( ! self::tabela_pronta() ) {
			return '';
		}

		global $wpdb;

		$tabela = self::nome_tabela();
		$dia    = $wpdb->get_var( "SELECT MIN(dia) FROM {$tabela}" ); // phpcs:ignore WordPress.DB

		return is_string( $dia ) ? $dia : '';
	}

	/**
	 * O evento cujo GATILHO é este, resolvido da declaração única.
	 *
	 * A tela precisa falar de "rolagem" e de "carregamento da página" sem
	 * escrever `f3base_rolagem` nem `f3base_pagina_vista` dentro do PHP: o nome
	 * do evento é renomeável num lugar só, e uma tela que o repete quebra a
	 * renomeação em silêncio.
	 *
	 * @param string $gatilho Gatilho declarado.
	 * @return string Nome do evento; vazio quando o gatilho não está declarado.
	 */
	public static function evento_do_gatilho( string $gatilho ): string {
		if ( ! class_exists( 'F3Base_Modulo_Tracking' ) ) {
			return '';
		}

		foreach ( F3Base_Modulo_Tracking::eventos_de_comportamento() as $nome => $declaracao ) {
			if ( $gatilho === (string) ( $declaracao['gatilho'] ?? '' ) ) {
				return (string) $nome;
			}
		}

		return '';
	}

	/**
	 * A TABELA BRUTA DE ACIONAMENTOS — uma linha por vez que o gatilho disparou.
	 *
	 * É o pedido central da 1.3.0, nas palavras do usuário: *"Não apenas a
	 * primeira vez que a trigger seja acionada, todas as vezes que ela for
	 * acionada mesmo que seja pelo mesmo visitante e durante a mesma sessão."*
	 *
	 * Vem do registro e não do resumo, porque o resumo soma por desenho. Sai da
	 * mais recente para a mais antiga, com paginação e filtro: uma linha por
	 * acionamento cresce rápido, e uma tela sem filtro fica inútil no primeiro
	 * site com tráfego.
	 *
	 * @param array<string,mixed> $filtro `visitante`, `sessao`, `limite`, `salto`.
	 * @return array{linhas:array<int,array<string,mixed>>,total:int}
	 */
	public static function acionamentos( array $filtro = array() ): array {
		if ( ! self::eventos_prontos() ) {
			return array( 'linhas' => array(), 'total' => 0 );
		}

		global $wpdb;

		$tabela = self::nome_tabela_eventos();
		$dias   = self::dias_no_painel();
		$desde  = gmdate( 'Y-m-d', time() - ( ( $dias - 1 ) * DAY_IN_SECONDS ) );

		$onde  = array( 'dia >= %s' );
		$valores = array( $desde );

		/*
		 * SÓ COMPORTAMENTO DE USO ENTRA NA TABELA. Trinta das sessenta e duas
		 * linhas do primeiro site real eram medida de carregamento, e elas
		 * dominavam a ordenação por horário: quem abria a tabela via TTFB, CLS e
		 * LCP empurrando para baixo a rolagem e os blocos que tinha ido
		 * procurar. As técnicas continuam sendo coletadas e continuam no resumo
		 * — elas só não são comportamento de ninguém.
		 *
		 * A lista sai da DECLARAÇÃO, e não daqui: uma lista de nomes escrita no
		 * PHP envelheceria no primeiro evento acrescentado e passaria a esconder
		 * ou a mostrar o errado sem que nada acusasse.
		 */
		$de_uso = self::eventos_de_uso();

		if ( array() === $de_uso ) {
			return array( 'linhas' => array(), 'total' => 0 );
		}

		$onde[]  = 'metrica IN ( ' . implode( ', ', array_fill( 0, count( $de_uso ), '%s' ) ) . ' )';
		$valores = array_merge( $valores, $de_uso );

		$visitante = isset( $filtro['visitante'] ) ? (string) $filtro['visitante'] : '';
		$sessao    = isset( $filtro['sessao'] ) ? (string) $filtro['sessao'] : '';

		if ( 1 === preg_match( self::FORMA_PSEUDONIMO, $visitante ) ) {
			$onde[]    = 'visitante = %s';
			$valores[] = $visitante;
		}

		if ( 1 === preg_match( self::FORMA_PSEUDONIMO, $sessao ) ) {
			$onde[]    = 'sessao = %s';
			$valores[] = $sessao;
		}

		$clausula = implode( ' AND ', $onde );

		$total = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$tabela} WHERE {$clausula}", // phpcs:ignore WordPress.DB.PreparedSQL
				$valores
			)
		);

		$limite = max( 1, min( 500, isset( $filtro['limite'] ) ? (int) $filtro['limite'] : 100 ) );
		$salto  = max( 0, isset( $filtro['salto'] ) ? (int) $filtro['salto'] : 0 );

		$linhas = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT id, visitante, sessao, dia, criado_em, ms, caminho, metrica, detalhe, ocorrencia FROM {$tabela} WHERE {$clausula} ORDER BY criado_em DESC, id DESC LIMIT %d OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL
				array_merge( $valores, array( $limite, $salto ) )
			),
			ARRAY_A
		);

		$saida = array();

		foreach ( is_array( $linhas ) ? $linhas : array() as $linha ) {
			$saida[] = array(
				/*
				 * O ID VIAJA JUNTO porque é ele que ordena dentro do mesmo
				 * segundo. Vários acionamentos de uma visita caem no mesmo
				 * carimbo de tempo, e sem o desempate a "ordem do mais recente
				 * para o mais antigo" seria a ordem que o banco quisesse.
				 */
				'id'         => (int) $linha['id'],
				'visitante'  => (string) $linha['visitante'],
				'sessao'     => (string) $linha['sessao'],
				'dia'        => (string) $linha['dia'],
				'criado_em'  => (int) $linha['criado_em'],
				'ms'         => (int) $linha['ms'],
				'caminho'    => (string) $linha['caminho'],
				'metrica'    => (string) $linha['metrica'],
				'detalhe'    => (string) $linha['detalhe'],
				'ocorrencia' => (int) $linha['ocorrencia'],
				'frase'      => self::frase_do_acionamento( (string) $linha['metrica'], (string) $linha['detalhe'] ),
			);
		}

		return array( 'linhas' => $saida, 'total' => $total );
	}

	/**
	 * OS EVENTOS QUE SÃO COMPORTAMENTO DE USO, lidos da declaração.
	 *
	 * @return array<int,string> Nomes declarados.
	 */
	public static function eventos_de_uso(): array {
		$declarados = class_exists( 'F3Base_Modulo_Tracking' )
			? F3Base_Modulo_Tracking::eventos_de_comportamento()
			: array();

		$saida = array();

		foreach ( $declarados as $nome => $declaracao ) {
			if ( 'uso' === (string) ( $declaracao['natureza'] ?? '' ) ) {
				$saida[] = (string) $nome;
			}
		}

		return $saida;
	}

	/**
	 * QUANTAS VEZES CADA PÁGINA FOI VISITADA, e por quantas pessoas.
	 *
	 * O quadro voltou a pedido do usuário: ele tinha cortado "páginas com mais
	 * registro", que somava TODA atividade — uma página longa e lida até o fim
	 * produzia mais registro que uma curta com o mesmo público, e o número não
	 * respondia nada. Visitas e pessoas são outra pergunta, e é a que ele fez.
	 *
	 * O denominador é o evento de abertura de página, que existe justamente para
	 * isso. Contar linhas da tabela daria atividade de novo.
	 *
	 * @param int $dias Período; zero usa o declarado.
	 * @return array<int,array{caminho:string,visitas:int,pessoas:int}>
	 */
	public static function visitas_por_pagina( int $dias = 0 ): array {
		$dias  = $dias > 0 ? $dias : self::dias_no_painel();
		$desde = gmdate( 'Y-m-d', time() - ( ( $dias - 1 ) * DAY_IN_SECONDS ) );

		$abertura = self::evento_do_gatilho( 'pagina' );

		if ( '' === $abertura || ! self::eventos_prontos() ) {
			return array();
		}

		global $wpdb;

		$tabela = self::nome_tabela_eventos();

		$linhas = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT caminho, visitante FROM {$tabela} WHERE dia >= %s AND metrica = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$desde,
				$abertura
			),
			ARRAY_A
		);

		$por_caminho = array();

		foreach ( is_array( $linhas ) ? $linhas : array() as $linha ) {
			$caminho = (string) $linha['caminho'];

			$por_caminho[ $caminho ] = $por_caminho[ $caminho ] ?? array(
				'caminho' => $caminho,
				'visitas' => 0,
				'pessoas' => array(),
			);

			++$por_caminho[ $caminho ]['visitas'];

			$por_caminho[ $caminho ]['pessoas'][ (string) $linha['visitante'] ] = true;
		}

		$saida = array();

		foreach ( $por_caminho as $registro ) {
			$saida[] = array(
				'caminho' => (string) $registro['caminho'],
				'visitas' => (int) $registro['visitas'],
				'pessoas' => count( $registro['pessoas'] ),
			);
		}

		usort(
			$saida,
			static function ( array $a, array $b ): int {
				return (int) $b['visitas'] <=> (int) $a['visitas'];
			}
		);

		return $saida;
	}

	/**
	 * O ACIONAMENTO EM PORTUGUÊS COMUM — "passou de 25%", "bloco abertura".
	 *
	 * A frase sai da DECLARAÇÃO, e não daqui: escrita no PHP, seria uma segunda
	 * descrição do mesmo evento e divergiria dela na primeira edição apressada.
	 * Sem frase declarada, o nome técnico aparece — é feio e é honesto, e diz a
	 * quem mantém o pacote que falta uma linha na declaração.
	 *
	 * @param string $metrica Nome declarado do evento.
	 * @param string $detalhe Discriminante.
	 * @return string
	 */
	public static function frase_do_acionamento( string $metrica, string $detalhe ): string {
		$declarados = class_exists( 'F3Base_Modulo_Tracking' )
			? F3Base_Modulo_Tracking::eventos_de_comportamento()
			: array();

		$frase = (string) ( $declarados[ $metrica ]['frase'] ?? '' );

		if ( '' === $frase ) {
			return '' === $detalhe ? $metrica : $metrica . ' · ' . $detalhe;
		}

		if ( ! str_contains( $frase, '%s' ) ) {
			return $frase;
		}

		return sprintf( $frase, '' === $detalhe ? '—' : $detalhe );
	}

	/**
	 * OS VISITANTES E AS VISITAS que aparecem no período, para os filtros.
	 *
	 * @return array{visitantes:array<int,string>,sessoes:array<int,string>}
	 */
	public static function chaves_do_periodo(): array {
		if ( ! self::eventos_prontos() ) {
			return array( 'visitantes' => array(), 'sessoes' => array() );
		}

		global $wpdb;

		$tabela = self::nome_tabela_eventos();
		$desde  = gmdate( 'Y-m-d', time() - ( ( self::dias_no_painel() - 1 ) * DAY_IN_SECONDS ) );

		$linhas = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT DISTINCT visitante, sessao FROM {$tabela} WHERE dia >= %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$desde
			),
			ARRAY_A
		);

		$visitantes = array();
		$sessoes    = array();

		foreach ( is_array( $linhas ) ? $linhas : array() as $linha ) {
			$visitantes[ (string) $linha['visitante'] ] = true;
			$sessoes[ (string) $linha['sessao'] ]       = true;
		}

		return array(
			'visitantes' => array_keys( $visitantes ),
			'sessoes'    => array_keys( $sessoes ),
		);
	}

	/**
	 * EXISTE LINK PARA FORA em alguma página publicada deste site?
	 *
	 * POR QUE ISTO É MEDIDO. O quadro de saídas mostrava zero, e zero sem
	 * explicação parece defeito — foi o que fez o usuário achar que o coletor
	 * estava quebrado. Ele não estava: nenhuma das páginas publicadas tinha um
	 * único `href` para fora do domínio, e não havia o que clicar. A tela passa
	 * a dizer isso, e a diferença entre "ninguém clicou" e "não há onde clicar"
	 * é a diferença entre um número e uma resposta.
	 *
	 * @return bool
	 */
	public static function ha_link_externo_publicado(): bool {
		$host_do_site = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );

		$publicados = get_posts(
			array(
				'post_type'              => array( 'page', 'post' ),
				'post_status'            => 'publish',
				'numberposts'            => (int) apply_filters( 'f3base_varredura_de_links', 200 ),
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
				'suppress_filters'       => false,
			)
		);

		foreach ( $publicados as $publicado ) {
			if ( ! preg_match_all( '/href="(https?:\/\/[^"]+)"/i', (string) $publicado->post_content, $enderecos ) ) {
				continue;
			}

			foreach ( $enderecos[1] as $endereco ) {
				$host = (string) wp_parse_url( (string) $endereco, PHP_URL_HOST );

				if ( '' !== $host && $host !== $host_do_site ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * A LEITURA DO REGISTRO, por página: releitura, tempo e visitantes.
	 *
	 * TRÊS PERGUNTAS QUE O AGREGADO NÃO RESPONDE, e é para elas que a tabela de
	 * registro existe:
	 *
	 * - **Primeira leitura ou releitura?** A coluna de ocorrência diz qual
	 *   travessia foi aquela. Ocorrência 1 é a descida inicial; de 2 em diante
	 *   é gente que subiu e desceu de novo, que é o comportamento que o usuário
	 *   pediu para enxergar.
	 * - **Quanto tempo levou?** O carimbo é a distância em milissegundos entre
	 *   o carregamento e o acontecimento. A tela usa a MEDIANA, e não a média:
	 *   uma aba esquecida aberta por três horas move a média da página inteira
	 *   e não move a mediana em nada. Com poucas amostras a média mente; a
	 *   mediana só fica imprecisa.
	 * - **Quantas pessoas?** Visitantes distintos, contados pelo apelido — não
	 *   é o mesmo que carregamentos, e a diferença entre os dois é justamente a
	 *   medida de quem volta.
	 *
	 * @param int $dias Período somado; zero usa o declarado.
	 * @return array<string,array<string,mixed>>
	 */
	public static function registro_por_pagina( int $dias = 0 ): array {
		$dias  = $dias > 0 ? $dias : self::dias_no_painel();
		$desde = gmdate( 'Y-m-d', time() - ( ( $dias - 1 ) * DAY_IN_SECONDS ) );

		$rolagem = self::evento_do_gatilho( 'rolagem' );

		if ( ! self::eventos_prontos() ) {
			return array();
		}

		global $wpdb;

		$tabela = self::nome_tabela_eventos();

		$linhas = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT caminho, metrica, detalhe, ocorrencia, ms, visitante FROM {$tabela} WHERE dia >= %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$desde
			),
			ARRAY_A
		);

		$por_caminho = array();

		foreach ( is_array( $linhas ) ? $linhas : array() as $linha ) {
			$caminho = (string) $linha['caminho'];

			$por_caminho[ $caminho ] = $por_caminho[ $caminho ] ?? array(
				'caminho'    => $caminho,
				'visitantes' => array(),
				'marcos'     => array(),
			);

			$por_caminho[ $caminho ]['visitantes'][ (string) $linha['visitante'] ] = true;

			if ( (string) $linha['metrica'] !== $rolagem ) {
				continue;
			}

			$marco = (string) $linha['detalhe'];

			$por_caminho[ $caminho ]['marcos'][ $marco ] = $por_caminho[ $caminho ]['marcos'][ $marco ] ?? array(
				'primeira'  => 0,
				'releitura' => 0,
				'tempos'    => array(),
			);

			if ( 1 === (int) $linha['ocorrencia'] ) {
				++$por_caminho[ $caminho ]['marcos'][ $marco ]['primeira'];

				/*
				 * SÓ A PRIMEIRA TRAVESSIA ENTRA NO TEMPO. A pergunta é "quanto
				 * tempo levou para percorrer a página"; a segunda descida
				 * aconteceu depois de a pessoa já ter lido, e misturá-la
				 * empurraria a mediana para cima medindo outra coisa.
				 */
				$por_caminho[ $caminho ]['marcos'][ $marco ]['tempos'][] = (int) $linha['ms'];

				continue;
			}

			++$por_caminho[ $caminho ]['marcos'][ $marco ]['releitura'];
		}

		$saida = array();

		foreach ( $por_caminho as $caminho => $registro ) {
			$marcos = array();

			foreach ( $registro['marcos'] as $marco => $dados_do_marco ) {
				$marcos[ (string) $marco ] = array(
					'primeira'  => (int) $dados_do_marco['primeira'],
					'releitura' => (int) $dados_do_marco['releitura'],
					'mediana'   => self::mediana( $dados_do_marco['tempos'] ),
					'amostra'   => count( $dados_do_marco['tempos'] ),
				);
			}

			uksort(
				$marcos,
				static function ( string $a, string $b ): int {
					return (int) $a <=> (int) $b;
				}
			);

			$saida[ (string) $caminho ] = array(
				'caminho'    => (string) $caminho,
				'visitantes' => count( $registro['visitantes'] ),
				'marcos'     => $marcos,
			);
		}

		return $saida;
	}

	/**
	 * A MEDIANA de uma lista de inteiros, em milissegundos.
	 *
	 * Mediana e não média, e o motivo é o caso comum: uma aba deixada aberta a
	 * tarde inteira produz um valor que arrasta a média da página e não move a
	 * mediana. O teto de vinte e quatro horas no endpoint cuida do absurdo; a
	 * mediana cuida do cotidiano.
	 *
	 * @param array<int,int> $valores Amostras.
	 * @return int|null Mediana, ou null quando não há amostra.
	 */
	public static function mediana( array $valores ): ?int {
		if ( array() === $valores ) {
			return null;
		}

		sort( $valores );

		$total = count( $valores );
		$meio  = intdiv( $total, 2 );

		if ( 0 === $total % 2 ) {
			return (int) round( ( $valores[ $meio - 1 ] + $valores[ $meio ] ) / 2 );
		}

		return (int) $valores[ $meio ];
	}

	/**
	 * VISITANTES DISTINTOS por dia, contados pelo apelido.
	 *
	 * @param int $dias Período; zero usa o declarado.
	 * @return array<int,array{dia:string,visitantes:int}>
	 */
	public static function visitantes_por_dia( int $dias = 0 ): array {
		$dias  = $dias > 0 ? $dias : self::dias_no_painel();
		$desde = gmdate( 'Y-m-d', time() - ( ( $dias - 1 ) * DAY_IN_SECONDS ) );

		if ( ! self::eventos_prontos() ) {
			return array();
		}

		global $wpdb;

		$tabela = self::nome_tabela_eventos();

		$linhas = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT dia, COUNT(DISTINCT visitante) AS visitantes FROM {$tabela} WHERE dia >= %s GROUP BY dia", // phpcs:ignore WordPress.DB.PreparedSQL
				$desde
			),
			ARRAY_A
		);

		$saida = array();

		foreach ( is_array( $linhas ) ? $linhas : array() as $linha ) {
			$saida[] = array(
				'dia'        => (string) $linha['dia'],
				'visitantes' => (int) $linha['visitantes'],
			);
		}

		usort(
			$saida,
			static function ( array $a, array $b ): int {
				return strcmp( (string) $b['dia'], (string) $a['dia'] );
			}
		);

		return $saida;
	}

	/**
	 * A PROFUNDIDADE DE LEITURA POR PÁGINA, com o denominador ao lado.
	 *
	 * "O usuário determinou: a profundidade de registro deve ser medida e
	 * exibida individualmente para cada página." Somada, ela não responde nada:
	 * uma página que ninguém termina e uma que todo mundo termina entram no
	 * mesmo total, e o operador não descobre qual das duas está longa demais.
	 *
	 * O DENOMINADOR É O CARREGAMENTO DAQUELA PÁGINA, e ele é um evento
	 * declarado — não uma inferência a partir do TTFB. "2 chegaram a 90%" pode
	 * ser 2 de 2 ou 2 de 200, e as duas leituras levam a decisões opostas.
	 *
	 * @param int $dias Período somado; zero usa o declarado.
	 * @return array<int,array{caminho:string,carregamentos:int,marcos:array<int,array{marco:string,total:int,proporcao:?float}>}>
	 */
	public static function profundidade_por_pagina( int $dias = 0 ): array {
		$dias  = $dias > 0 ? $dias : self::dias_no_painel();
		$desde = gmdate( 'Y-m-d', time() - ( ( $dias - 1 ) * DAY_IN_SECONDS ) );

		$rolagem = self::evento_do_gatilho( 'rolagem' );
		$pagina  = self::evento_do_gatilho( 'pagina' );

		if ( '' === $rolagem || ! self::tabela_pronta() ) {
			return array();
		}

		global $wpdb;

		$tabela = self::nome_tabela();

		$linhas = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT caminho, metrica, detalhe, SUM(contagem) AS total FROM {$tabela} WHERE dia >= %s AND metrica IN ( %s, %s ) GROUP BY caminho, metrica, detalhe", // phpcs:ignore WordPress.DB.PreparedSQL
				$desde,
				$rolagem,
				'' === $pagina ? $rolagem : $pagina
			),
			ARRAY_A
		);

		$por_caminho = array();

		foreach ( is_array( $linhas ) ? $linhas : array() as $linha ) {
			$caminho = (string) $linha['caminho'];
			$metrica = (string) $linha['metrica'];
			$conta   = (int) $linha['total'];

			$por_caminho[ $caminho ] = $por_caminho[ $caminho ] ?? array(
				'caminho'       => $caminho,
				'carregamentos' => 0,
				'marcos'        => array(),
			);

			if ( $metrica === $pagina && '' !== $pagina ) {
				$por_caminho[ $caminho ]['carregamentos'] += $conta;

				continue;
			}

			if ( $metrica !== $rolagem ) {
				continue;
			}

			$marco = (string) $linha['detalhe'];

			$por_caminho[ $caminho ]['marcos'][ $marco ] = ( $por_caminho[ $caminho ]['marcos'][ $marco ] ?? 0 ) + $conta;
		}

		$saida = array();

		foreach ( $por_caminho as $registro ) {
			/*
			 * A ORDEM DOS MARCOS É NUMÉRICA, e não a do banco: 25, 50, 75, 90
			 * lidos fora de ordem invertem a leitura de uma queda de leitura em
			 * subida, e ninguém confere a ordem de uma tabela pequena.
			 */
			$marcos = $registro['marcos'];
			uksort(
				$marcos,
				static function ( string $a, string $b ): int {
					return (int) $a <=> (int) $b;
				}
			);

			$carregamentos = (int) $registro['carregamentos'];
			$detalhado     = array();

			foreach ( $marcos as $marco => $total ) {
				$detalhado[] = array(
					'marco'     => (string) $marco,
					'total'     => (int) $total,
					/*
					 * SEM DENOMINADOR NÃO HÁ PROPORÇÃO, e null diz isso. Um
					 * zero ali seria lido como "ninguém chegou", que é o
					 * contrário do que a ausência significa.
					 */
					'proporcao' => $carregamentos > 0 ? ( (int) $total / $carregamentos ) : null,
				);
			}

			if ( array() === $detalhado && $carregamentos < 1 ) {
				continue;
			}

			$registro['marcos']        = $detalhado;
			$registro['carregamentos'] = $carregamentos;

			$saida[] = $registro;
		}

		usort(
			$saida,
			static function ( array $a, array $b ): int {
				return (int) $b['carregamentos'] <=> (int) $a['carregamentos'];
			}
		);

		return $saida;
	}

	/**
	 * O RESUMO POR EVENTO DECLARADO, com as páginas de cada um.
	 *
	 * A tela do menu Medição responde por evento — "quanto da página as pessoas
	 * leem", "onde elas clicam repetido" — e cada resposta precisa vir com as
	 * páginas em que ela aconteceu, senão o operador tem um número e nenhum
	 * lugar para ir olhar.
	 *
	 * OS SEIS EVENTOS SAEM DA DECLARAÇÃO, e nunca do que a tabela por acaso
	 * tem: evento declarado e sem nenhuma linha aparece com zero e com o motivo
	 * possível, porque "não aconteceu" é resposta, e sumir da tela não é. Uma
	 * lista montada a partir da tabela esconderia justamente o evento que parou
	 * de ser coletado, que é o defeito que mais importa descobrir.
	 *
	 * @param int $dias Período somado; zero usa o declarado.
	 * @return array<int,array{evento:string,pergunta:string,total:int,detalhes:array<int,array{rotulo:string,total:int}>,paginas:array<int,array{caminho:string,total:int}>}>
	 */
	public static function resumo_por_evento( int $dias = 0 ): array {
		$dias  = $dias > 0 ? $dias : self::dias_no_painel();
		$desde = gmdate( 'Y-m-d', time() - ( ( $dias - 1 ) * DAY_IN_SECONDS ) );

		$declarados = class_exists( 'F3Base_Modulo_Tracking' )
			? F3Base_Modulo_Tracking::eventos_de_comportamento()
			: array();

		$por_evento = array();

		foreach ( $declarados as $nome => $declaracao ) {
			$por_evento[ (string) $nome ] = array(
				'evento'   => (string) $nome,
				'pergunta' => (string) ( $declaracao['pergunta'] ?? '' ),
				'total'    => 0,
				'detalhes' => array(),
				'paginas'  => array(),
			);
		}

		if ( ! self::tabela_pronta() ) {
			return array_values( $por_evento );
		}

		global $wpdb;

		$tabela = self::nome_tabela();

		$linhas = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT caminho, metrica, detalhe, SUM(contagem) AS total FROM {$tabela} WHERE dia >= %s GROUP BY caminho, metrica, detalhe", // phpcs:ignore WordPress.DB.PreparedSQL
				$desde
			),
			ARRAY_A
		);

		foreach ( is_array( $linhas ) ? $linhas : array() as $linha ) {
			$metrica = (string) $linha['metrica'];
			$detalhe = (string) $linha['detalhe'];
			$caminho = (string) $linha['caminho'];
			$conta   = (int) $linha['total'];

			/*
			 * O DESCARTE NÃO É EVENTO, e sai daqui pelo nome. Ele mora na mesma
			 * tabela porque tem a mesma granularidade e o mesmo prazo, mas ele
			 * não responde "o que a pessoa fez": ninguém cortou nada, foi o
			 * pacote que descartou. Listado aqui, ele apareceria como um evento
			 * a mais, sem pergunta declarada, e quem lê somaria descarte com
			 * acionamento. Quem o mostra é a tela, em separado e nomeado.
			 */
			if ( self::METRICA_CORTADAS === $metrica ) {
				continue;
			}

			/*
			 * MÉTRICA FORA DA DECLARAÇÃO ENTRA MESMO ASSIM, com o nome que ela
			 * tem. Ela só pode existir por duas vias — uma release anterior que
			 * media outra coisa, ou um filtro do site —, e nos dois casos
			 * escondê-la faria a soma da tela não bater com a da tabela, sem
			 * nada na tela dizendo por quê.
			 */
			if ( ! isset( $por_evento[ $metrica ] ) ) {
				$por_evento[ $metrica ] = array(
					'evento'   => $metrica,
					'pergunta' => '',
					'total'    => 0,
					'detalhes' => array(),
					'paginas'  => array(),
				);
			}

			$por_evento[ $metrica ]['total'] += $conta;

			$rotulo = '' === $detalhe ? '—' : $detalhe;

			$por_evento[ $metrica ]['detalhes'][ $rotulo ] = ( $por_evento[ $metrica ]['detalhes'][ $rotulo ] ?? 0 ) + $conta;
			$por_evento[ $metrica ]['paginas'][ $caminho ] = ( $por_evento[ $metrica ]['paginas'][ $caminho ] ?? 0 ) + $conta;
		}

		$saida = array();

		foreach ( $por_evento as $registro ) {
			arsort( $registro['detalhes'] );
			arsort( $registro['paginas'] );

			$detalhes = array();

			foreach ( $registro['detalhes'] as $rotulo => $conta ) {
				$detalhes[] = array(
					'rotulo' => (string) $rotulo,
					'total'  => (int) $conta,
				);
			}

			$paginas = array();

			foreach ( $registro['paginas'] as $caminho => $conta ) {
				$paginas[] = array(
					'caminho' => (string) $caminho,
					'total'   => (int) $conta,
				);
			}

			$registro['detalhes'] = $detalhes;
			$registro['paginas']  = $paginas;

			$saida[] = $registro;
		}

		return $saida;
	}

	/**
	 * O resumo do período, já agregado para leitura humana.
	 *
	 * @param int $dias Período em dias; zero usa o declarado na option.
	 * @return array{dias:int,desde:string,linhas:int,total:int,paginas:array<int,array<string,mixed>>,eventos:array<int,array<string,mixed>>,vitais:array<int,array<string,mixed>>,cortadas:int,cortadas_paginas:array<int,array<string,mixed>>}
	 */
	public static function resumo( int $dias = 0 ): array {
		$dias  = $dias > 0 ? $dias : self::dias_no_painel();
		$desde = gmdate( 'Y-m-d', time() - ( ( $dias - 1 ) * DAY_IN_SECONDS ) );

		$vazio = array(
			'dias'    => $dias,
			'desde'   => $desde,
			'linhas'  => 0,
			'total'   => 0,
			'paginas' => array(),
			'eventos' => array(),
			'vitais'  => array(),
			/*
			 * O DESCARTE VIAJA AO LADO DO TOTAL, e nunca DENTRO dele: somá-lo
			 * ao total faria a tela dizer que recebeu o que ela justamente não
			 * recebeu. Ele é o número que responde "o que falta nesta tabela".
			 */
			'cortadas'          => 0,
			'cortadas_paginas'  => array(),
		);

		if ( ! self::tabela_pronta() ) {
			return $vazio;
		}

		global $wpdb;

		$tabela = self::nome_tabela();

		$linhas = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT caminho, metrica, detalhe, SUM(contagem) AS total, SUM(soma) AS acumulado FROM {$tabela} WHERE dia >= %s GROUP BY caminho, metrica, detalhe", // phpcs:ignore WordPress.DB.PreparedSQL
				$desde
			),
			ARRAY_A
		);

		if ( ! is_array( $linhas ) || array() === $linhas ) {
			return $vazio;
		}

		$paginas  = array();
		$eventos  = array();
		$vitais   = array();
		$cortadas = array();
		$total    = 0;
		$medidas  = 0;

		foreach ( $linhas as $linha ) {
			$caminho = (string) $linha['caminho'];
			$metrica = (string) $linha['metrica'];
			$detalhe = (string) $linha['detalhe'];
			$conta   = (int) $linha['total'];
			$acumula = (float) $linha['acumulado'];

			/*
			 * O DESCARTE SAI DAS SOMAS E VIRA UM CAMPO PRÓPRIO. Ele mora nesta
			 * tabela pela granularidade e pelo prazo, e não porque seja
			 * acontecimento: contá-lo no total faria a tela afirmar ter
			 * recebido justamente o que se perdeu, e listá-lo entre as páginas
			 * faria a página que mais descartou parecer a mais visitada.
			 */
			if ( self::METRICA_CORTADAS === $metrica ) {
				$cortadas[ $caminho ] = ( $cortadas[ $caminho ] ?? 0 ) + $conta;

				continue;
			}

			++$medidas;

			$total += $conta;

			$paginas[ $caminho ] = ( $paginas[ $caminho ] ?? 0 ) + $conta;

			$rotulo               = '' === $detalhe ? $metrica : $metrica . ' · ' . $detalhe;
			$eventos[ $rotulo ]   = ( $eventos[ $rotulo ] ?? 0 ) + $conta;

			if ( $acumula > 0.0 && '' !== $detalhe ) {
				$vitais[ $detalhe ] = $vitais[ $detalhe ] ?? array(
					'soma'  => 0.0,
					'conta' => 0,
				);

				$vitais[ $detalhe ]['soma']  += $acumula;
				$vitais[ $detalhe ]['conta'] += $conta;
			}
		}

		arsort( $paginas );
		arsort( $eventos );
		arsort( $cortadas );
		ksort( $vitais );

		$saida_paginas = array();

		foreach ( $paginas as $caminho => $conta ) {
			$saida_paginas[] = array(
				'caminho' => (string) $caminho,
				'total'   => (int) $conta,
			);
		}

		$saida_eventos = array();

		foreach ( $eventos as $rotulo => $conta ) {
			$saida_eventos[] = array(
				'rotulo' => (string) $rotulo,
				'total'  => (int) $conta,
			);
		}

		$saida_vitais = array();

		foreach ( $vitais as $nome => $dados ) {
			$saida_vitais[] = array(
				'metrica' => (string) $nome,
				'media'   => $dados['conta'] > 0 ? $dados['soma'] / $dados['conta'] : 0.0,
				'amostra' => (int) $dados['conta'],
			);
		}

		$saida_cortadas = array();
		$total_cortadas = 0;

		foreach ( $cortadas as $caminho => $conta ) {
			$total_cortadas += (int) $conta;

			$saida_cortadas[] = array(
				'caminho' => (string) $caminho,
				'total'   => (int) $conta,
			);
		}

		return array(
			'dias'    => $dias,
			/*
			 * `linhas` CONTA O QUE FOI MEDIDO, e por isso o descarte fica fora
			 * dele também: é `linhas` que decide se a tela mostra os quadros ou
			 * o estado vazio, e um site que só tivesse descarte veria tabelas
			 * vazias em vez da frase que explica por quê.
			 */
			'linhas'  => $medidas,
			'desde'   => $desde,
			'total'   => $total,
			'paginas' => $saida_paginas,
			'eventos' => $saida_eventos,
			'vitais'  => $saida_vitais,
			'cortadas'         => $total_cortadas,
			'cortadas_paginas' => $saida_cortadas,
		);
	}

	/**
	 * Monta a resposta REST.
	 *
	 * @param int                 $status Código HTTP.
	 * @param array<string,mixed> $corpo  Corpo da resposta.
	 * @return WP_REST_Response
	 */
	private static function resposta( int $status, array $corpo ): WP_REST_Response {
		$corpo['fase'] = 'comportamento';

		return new WP_REST_Response( $corpo, $status );
	}
}
