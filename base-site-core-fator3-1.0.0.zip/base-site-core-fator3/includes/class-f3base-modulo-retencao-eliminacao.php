<?php
/**
 * Módulo retencao-e-eliminacao.
 *
 * Limpeza por prazo em WP-Cron que MEDE O PRÓPRIO ATRASO e se recupera no
 * carregamento seguinte — WP-Cron não garante horário, e obrigação temporal
 * relevante leva recomendação de cron real no README.
 *
 * Exportador e eraser do core registrados, e uma rota de eliminação com journal
 * que distingue os dois regimes:
 *
 * - limpeza OPERACIONAL admite janela reversível com cópia protegida e expirável;
 * - eliminação A PEDIDO DO TITULAR é irreversível por desenho, e o journal guarda
 *   só identificador e carimbo, nunca o conteúdo eliminado — backup de dado
 *   pessoal apagado a pedido derrota o próprio direito que a rota atende.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Retenção, eliminação e journal.
 */
final class F3Base_Modulo_Retencao_Eliminacao extends F3Base_Modulo {

	/**
	 * Evento agendado da limpeza.
	 */
	public const EVENTO = 'f3base_retencao_limpeza';

	/**
	 * Rota de eliminação, dentro do namespace do plugin.
	 */
	public const ROTA = '/eliminacao';

	/**
	 * Ação do nonce aceito pela rota.
	 */
	public const NONCE = 'f3base_eliminacao';

	/**
	 * Meta que marca o fim da janela reversível.
	 */
	public const META_REVERSIVEL = '_f3base_reversivel_ate';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'retencao-e-eliminacao';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Retenção e eliminação', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Limpa registros de lead pelo prazo declarado em WP-Cron, medindo o próprio atraso e se recuperando no carregamento seguinte; registra exportador e eraser do core; e expõe a rota de eliminação com journal que separa limpeza operacional reversível de eliminação irreversível a pedido do titular.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'init',
				'metodo'     => 'garantir_agendamento',
				'prioridade' => 20,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => self::EVENTO,
				'metodo'     => 'executar_limpeza',
				'prioridade' => 10,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'rest_api_init',
				'metodo'     => 'registrar_rota',
				'prioridade' => 10,
				'args'       => 0,
			),
			array(
				'tipo'       => 'filter',
				'hook'       => 'wp_privacy_personal_data_exporters',
				'metodo'     => 'registrar_exportador',
				'prioridade' => 10,
				'args'       => 1,
			),
			array(
				'tipo'       => 'filter',
				'hook'       => 'wp_privacy_personal_data_erasers',
				'metodo'     => 'registrar_eraser',
				'prioridade' => 10,
				'args'       => 1,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_retencao_meses', 'f3base_journal_eliminacao' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$agendado = wp_next_scheduled( self::EVENTO );
		$cron_off = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;

		return array(
			array(
				'rotulo'   => __( 'Agendamento da limpeza', 'f3base' ),
				'presente' => false !== $agendado,
				'detalhe'  => false !== $agendado
					? sprintf(
						/* translators: %s: data e hora previstas. */
						__( 'próxima execução prevista para %s.', 'f3base' ),
						(string) wp_date( 'd/m/Y H:i', (int) $agendado )
					)
					: __( 'evento não agendado: a limpeza depende do carregamento seguinte para se recuperar.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'WP-Cron habilitado', 'f3base' ),
				'presente' => ! $cron_off,
				'detalhe'  => $cron_off
					? __( 'DISABLE_WP_CRON ligado: a limpeza depende de cron real do sistema, conforme o README.', 'f3base' )
					: __( 'WP-Cron não garante horário; o atraso é medido e reportado a cada execução.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_LIMPEZA, __( 'Última limpeza de retenção', 'f3base' ) ),
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_ELIMINACAO, __( 'Última eliminação pela rota', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$agendado = wp_next_scheduled( self::EVENTO );

		if ( false === $agendado ) {
			return $this->degradado(
				__( 'evento de limpeza sem agendamento: o prazo de retenção só é aplicado quando o carregamento seguinte recuperar a rotina.', 'f3base' )
			);
		}

		$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_LIMPEZA );
		$atraso  = isset( $carimbo['atraso_segundos'] ) ? (int) $carimbo['atraso_segundos'] : 0;
		$limite  = (int) apply_filters( 'f3base_retencao_atraso_tolerado', 2 * DAY_IN_SECONDS );

		if ( $atraso > $limite ) {
			return $this->degradado(
				sprintf(
					/* translators: %s: atraso medido, em formato humano. */
					__( 'última execução saiu com %s de atraso sobre o horário previsto, acima da tolerância declarada.', 'f3base' ),
					human_time_diff( 0, $atraso )
				)
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: 1: prazo em meses, 2: data e hora previstas. */
				__( 'guardando leads por %1$d meses; próxima limpeza prevista para %2$s, com o atraso medido a cada execução.', 'f3base' ),
				$this->meses(),
				(string) wp_date( 'd/m/Y H:i', (int) $agendado )
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function instalar(): void {
		$this->garantir_agendamento();
	}

	/**
	 * {@inheritDoc}
	 */
	public function desinstalar(): void {
		$timestamp = wp_next_scheduled( self::EVENTO );

		while ( false !== $timestamp ) {
			wp_unschedule_event( (int) $timestamp, self::EVENTO );
			$timestamp = wp_next_scheduled( self::EVENTO );
		}
	}

	/* ------------------------------------------------------------------ *
	 * Agendamento e recuperação
	 * ------------------------------------------------------------------ */

	/**
	 * Garante o agendamento e recupera a execução perdida.
	 *
	 * @return void
	 */
	public function garantir_agendamento(): void {
		$previsto = $this->previsto();

		if ( false === wp_next_scheduled( self::EVENTO ) ) {
			$proxima = time() + HOUR_IN_SECONDS;
			wp_schedule_event( $proxima, 'daily', self::EVENTO );
			$this->guardar_previsao( $proxima );
		}

		if ( $previsto <= 0 ) {
			return;
		}

		$tolerancia = (int) apply_filters( 'f3base_retencao_tolerancia_recuperacao', 6 * HOUR_IN_SECONDS );
		$tolerancia = max( MINUTE_IN_SECONDS, $tolerancia );

		if ( time() <= $previsto + $tolerancia ) {
			return;
		}

		if ( false === set_transient( 'f3base_retencao_recuperando', 1, 15 * MINUTE_IN_SECONDS ) ) {
			return;
		}

		$this->executar_limpeza( true );
	}

	/**
	 * Executa a limpeza por prazo.
	 *
	 * @param bool $recuperacao Verdadeiro quando disparada pelo carregamento.
	 * @return void
	 */
	public function executar_limpeza( bool $recuperacao = false ): void {
		$previsto = $this->previsto();
		$atraso   = $previsto > 0 ? max( 0, time() - $previsto ) : 0;

		$para_lixeira  = $this->arquivar_expirados();
		$eliminados    = $this->eliminar_janela_vencida();

		/*
		 * O RESUMO DE COMPORTAMENTO É PODADO PELA MESMA ROTINA, e por um motivo
		 * de desenho: prazo declarado que depende de uma segunda rotina é prazo
		 * que se cumpre pela metade no dia em que a segunda não roda. Ela já é
		 * a rotina de retenção deste site; o que muda é que ela passou a ter
		 * dois prazos para cumprir, cada um com a sua option, e o carimbo diz
		 * quantas linhas saíram — nunca o que havia nelas.
		 */
		$comportamento = class_exists( 'F3Base_Modulo_Comportamento' )
			? F3Base_Modulo_Comportamento::podar()
			: 0;

		/*
		 * O REGISTRO DETALHADO TEM PRAZO PRÓPRIO E MAIS CURTO, e ele é podado
		 * aqui, na mesma rotina e na mesma execução. São dois prazos porque são
		 * dois dados: o resumo soma por dia e por página e não identifica
		 * ninguém; o registro guarda o apelido do visitante, a visita e o
		 * horário em milissegundos, e isso é dado pessoal pseudonimizado. Uma
		 * segunda rotina para o segundo prazo seria um prazo que se cumpre pela
		 * metade no dia em que ela não rodar — e o que ficaria para trás é
		 * justamente o dado identificável.
		 */
		$registro_podado = class_exists( 'F3Base_Modulo_Comportamento' )
			? F3Base_Modulo_Comportamento::podar_eventos()
			: 0;

		if ( class_exists( 'F3Base_Modulo_Comportamento' ) ) {
			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMA_PODA_COMPORTAMENTO,
				array(
					'linhas'         => $comportamento,
					'dias'           => F3Base_Modulo_Comportamento::retencao_dias(),
					'registro'       => $registro_podado,
					'registro_dias'  => F3Base_Modulo_Comportamento::retencao_eventos_dias(),
				)
			);
		}

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMA_LIMPEZA,
			array(
				'arquivados'      => $para_lixeira,
				'eliminados'      => $eliminados,
				'comportamento'   => $comportamento,
				'registro'        => $registro_podado,
				'meses'           => $this->meses(),
				'atraso_segundos' => $atraso,
				'recuperada'      => $recuperacao,
			)
		);

		if ( $para_lixeira > 0 ) {
			$this->registrar_journal(
				'operacional',
				sprintf( 'retencao-%s', gmdate( 'Y-m-d-H-i-s' ) ),
				'',
				$para_lixeira,
				$recuperacao ? 'carregamento' : 'wp-cron',
				time() + $this->janela_reversivel()
			);
		}

		$proxima = wp_next_scheduled( self::EVENTO );
		$this->guardar_previsao( false !== $proxima ? (int) $proxima : time() + DAY_IN_SECONDS );

		delete_transient( 'f3base_retencao_recuperando' );
	}

	/**
	 * Move para a lixeira o que passou do prazo — a cópia protegida da janela.
	 *
	 * @return int Quantidade arquivada.
	 */
	private function arquivar_expirados(): int {
		$limite = gmdate( 'Y-m-d H:i:s', time() - ( $this->meses() * MONTH_IN_SECONDS ) );

		$ids = get_posts(
			array(
				'post_type'              => $this->tipos_de_lead(),
				'post_status'            => array( 'publish', 'private', 'draft', 'pending' ),
				'numberposts'            => (int) apply_filters( 'f3base_retencao_lote', 200 ),
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
				'suppress_filters'       => false,
				'date_query'             => array(
					array(
						'before'    => $limite,
						'inclusive' => true,
						'column'    => 'post_date_gmt',
					),
				),
			)
		);

		if ( ! is_array( $ids ) ) {
			return 0;
		}

		$conta    = 0;
		$expira   = time() + $this->janela_reversivel();

		foreach ( $ids as $id ) {
			$id = (int) $id;

			update_post_meta( $id, self::META_REVERSIVEL, $expira );

			if ( wp_trash_post( $id ) ) {
				++$conta;
			}
		}

		return $conta;
	}

	/**
	 * Elimina em definitivo o que já venceu a janela reversível.
	 *
	 * @return int Quantidade eliminada.
	 */
	private function eliminar_janela_vencida(): int {
		$ids = get_posts(
			array(
				'post_type'              => $this->tipos_de_lead(),
				'post_status'            => 'trash',
				'numberposts'            => (int) apply_filters( 'f3base_retencao_lote', 200 ),
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
				'suppress_filters'       => false,
				'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'key'     => self::META_REVERSIVEL,
						'value'   => time(),
						'compare' => '<=',
						'type'    => 'NUMERIC',
					),
				),
			)
		);

		if ( ! is_array( $ids ) ) {
			return 0;
		}

		$conta = 0;

		foreach ( $ids as $id ) {
			if ( wp_delete_post( (int) $id, true ) ) {
				++$conta;
			}
		}

		return $conta;
	}

	/* ------------------------------------------------------------------ *
	 * Rota de eliminação
	 * ------------------------------------------------------------------ */

	/**
	 * Registra a rota de eliminação.
	 *
	 * @return void
	 */
	public function registrar_rota(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA,
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'eliminar' ),
				'permission_callback' => array( $this, 'pode_eliminar' ),
				'args'                => array(
					'regime'        => array(
						'type'     => 'string',
						'required' => true,
						'enum'     => array( 'operacional', 'titular' ),
					),
					'identificador' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
	}

	/**
	 * Capability da rota.
	 *
	 * @return bool
	 */
	public function pode_eliminar(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Executa a eliminação pedida.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return WP_REST_Response
	 */
	public function eliminar( WP_REST_Request $requisicao ): WP_REST_Response {
		$nonce = (string) $requisicao->get_param( '_wpnonce' );
		if ( '' === $nonce ) {
			$cabecalho = $requisicao->get_header( 'x_wp_nonce' );
			$nonce     = is_string( $cabecalho ) ? $cabecalho : '';
		}

		$por_cookie = defined( 'LOGGED_IN_COOKIE' ) && isset( $_COOKIE[ LOGGED_IN_COOKIE ] );
		$nonce_ok   = '' !== $nonce && ( wp_verify_nonce( $nonce, self::NONCE ) || wp_verify_nonce( $nonce, 'wp_rest' ) );

		if ( ! $nonce_ok && $por_cookie ) {
			return new WP_REST_Response(
				array(
					'ok'     => false,
					'codigo' => 'f3base_nonce_invalido',
					'motivo' => __( 'Nonce ausente ou inválido para a rota de eliminação.', 'f3base' ),
				),
				403
			);
		}

		$regime        = sanitize_key( (string) $requisicao->get_param( 'regime' ) );
		$identificador = sanitize_text_field( (string) $requisicao->get_param( 'identificador' ) );

		if ( '' === $identificador ) {
			return new WP_REST_Response(
				array(
					'ok'     => false,
					'codigo' => 'f3base_identificador_ausente',
					'motivo' => __( 'Informe o identificador do titular ou do registro.', 'f3base' ),
				),
				400
			);
		}

		$alvos = $this->localizar( $identificador );

		if ( array() === $alvos ) {
			return new WP_REST_Response(
				array(
					'ok'       => true,
					'regime'   => $regime,
					'contagem' => 0,
					'motivo'   => __( 'Nenhum registro casou com o identificador informado.', 'f3base' ),
				),
				200
			);
		}

		$operador = wp_get_current_user()->user_login;
		$operador = is_string( $operador ) && '' !== $operador ? $operador : 'canal';

		if ( 'titular' === $regime ) {
			$contagem = 0;
			foreach ( $alvos as $id ) {
				if ( wp_delete_post( (int) $id, true ) ) {
					++$contagem;
				}
			}

			$this->registrar_journal(
				'titular',
				'',
				$this->impressao( $identificador ),
				$contagem,
				$operador,
				0
			);

			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMA_ELIMINACAO,
				array(
					'regime'   => 'titular',
					'contagem' => $contagem,
					'operador' => $operador,
				)
			);

			return new WP_REST_Response(
				array(
					'ok'          => true,
					'regime'      => 'titular',
					'contagem'    => $contagem,
					'reversivel'  => false,
					'motivo'      => __( 'Eliminação a pedido do titular é irreversível por desenho: nenhuma cópia foi mantida e o journal guarda só identificador e carimbo.', 'f3base' ),
				),
				200
			);
		}

		$expira   = time() + $this->janela_reversivel();
		$contagem = 0;

		foreach ( $alvos as $id ) {
			update_post_meta( (int) $id, self::META_REVERSIVEL, $expira );
			if ( wp_trash_post( (int) $id ) ) {
				++$contagem;
			}
		}

		$this->registrar_journal(
			'operacional',
			implode( ',', array_map( 'strval', $alvos ) ),
			'',
			$contagem,
			$operador,
			$expira
		);

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMA_ELIMINACAO,
			array(
				'regime'   => 'operacional',
				'contagem' => $contagem,
				'operador' => $operador,
			)
		);

		return new WP_REST_Response(
			array(
				'ok'             => true,
				'regime'         => 'operacional',
				'contagem'       => $contagem,
				'reversivel'     => true,
				'reversivel_ate' => $expira,
				'motivo'         => __( 'Limpeza operacional: cópia protegida na lixeira até o fim da janela declarada.', 'f3base' ),
			),
			200
		);
	}

	/* ------------------------------------------------------------------ *
	 * Exportador e eraser do core
	 * ------------------------------------------------------------------ */

	/**
	 * Registra o exportador do core.
	 *
	 * @param array<string,mixed> $exportadores Exportadores registrados.
	 * @return array<string,mixed>
	 */
	public function registrar_exportador( array $exportadores ): array {
		$exportadores['f3base-leads'] = array(
			'exporter_friendly_name' => __( 'Leads do Base Site Core Fator3', 'f3base' ),
			'callback'               => array( $this, 'exportar' ),
		);

		return $exportadores;
	}

	/**
	 * Registra o eraser do core.
	 *
	 * @param array<string,mixed> $erasers Erasers registrados.
	 * @return array<string,mixed>
	 */
	public function registrar_eraser( array $erasers ): array {
		$erasers['f3base-leads'] = array(
			'eraser_friendly_name' => __( 'Leads do Base Site Core Fator3', 'f3base' ),
			'callback'             => array( $this, 'apagar' ),
		);

		return $erasers;
	}

	/**
	 * Exporta os registros de um titular.
	 *
	 * @param string $email  E-mail do titular.
	 * @param int    $pagina Página da exportação.
	 * @return array{data:array<int,array<string,mixed>>,done:bool}
	 */
	public function exportar( string $email, int $pagina = 1 ): array {
		unset( $pagina );

		$dados = array();

		foreach ( $this->localizar( $email ) as $id ) {
			$post = get_post( (int) $id );
			if ( ! $post instanceof WP_Post ) {
				continue;
			}

			$dados[] = array(
				'group_id'    => 'f3base-leads',
				'group_label' => __( 'Leads', 'f3base' ),
				'item_id'     => 'f3base-lead-' . (int) $id,
				'data'        => array(
					array(
						'name'  => __( 'Assunto', 'f3base' ),
						'value' => (string) $post->post_title,
					),
					array(
						'name'  => __( 'Registrado em', 'f3base' ),
						'value' => (string) $post->post_date,
					),
					array(
						'name'  => __( 'Conteúdo', 'f3base' ),
						'value' => (string) $post->post_content,
					),
				),
			);
		}

		return array(
			'data' => $dados,
			'done' => true,
		);
	}

	/**
	 * Apaga os registros de um titular pelo fluxo do core.
	 *
	 * Este caminho é o do titular: irreversível, com journal de identificador e
	 * carimbo apenas.
	 *
	 * @param string $email  E-mail do titular.
	 * @param int    $pagina Página da eliminação.
	 * @return array{items_removed:bool,items_retained:bool,messages:string[],done:bool}
	 */
	public function apagar( string $email, int $pagina = 1 ): array {
		unset( $pagina );

		$contagem = 0;

		foreach ( $this->localizar( $email ) as $id ) {
			if ( wp_delete_post( (int) $id, true ) ) {
				++$contagem;
			}
		}

		if ( $contagem > 0 ) {
			$this->registrar_journal( 'titular', '', $this->impressao( $email ), $contagem, 'privacidade-do-core', 0 );

			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMA_ELIMINACAO,
				array(
					'regime'   => 'titular',
					'contagem' => $contagem,
					'operador' => 'privacidade-do-core',
				)
			);
		}

		return array(
			'items_removed'  => $contagem > 0,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => true,
		);
	}

	/* ------------------------------------------------------------------ *
	 * Journal e apoio
	 * ------------------------------------------------------------------ */

	/**
	 * Acrescenta uma entrada ao journal.
	 *
	 * Nenhum campo de conteúdo entra: identificador, contagem, carimbo, operador
	 * e regime, e só.
	 *
	 * @param string $regime         `operacional` ou `titular`.
	 * @param string $identificador  Identificadores técnicos afetados.
	 * @param string $impressao      Impressão do identificador do titular.
	 * @param int    $contagem       Quantos registros.
	 * @param string $operador       Quem pediu.
	 * @param int    $reversivel_ate Fim da janela reversível, 0 quando irreversível.
	 * @return void
	 */
	private function registrar_journal( string $regime, string $identificador, string $impressao, int $contagem, string $operador, int $reversivel_ate ): void {
		$journal = F3Base_Options::ler( 'f3base_journal_eliminacao' );
		$journal = is_array( $journal ) ? $journal : array();

		$journal[] = array(
			'regime'             => $regime,
			'identificador'      => $identificador,
			'identificador_hash' => $impressao,
			'contagem'           => $contagem,
			'em'                 => time(),
			'operador'           => $operador,
			'reversivel_ate'     => $reversivel_ate,
		);

		F3Base_Options::gravar( 'f3base_journal_eliminacao', $journal, F3Base_Options::ORIGEM_MANUAL );
	}

	/**
	 * Impressão irreversível do identificador do titular.
	 *
	 * O journal precisa provar QUE algo foi eliminado sem guardar QUEM em claro.
	 *
	 * @param string $identificador Identificador informado.
	 * @return string
	 */
	private function impressao( string $identificador ): string {
		return hash_hmac( 'sha256', strtolower( trim( $identificador ) ), wp_salt( 'auth' ) );
	}

	/**
	 * Localiza registros por e-mail, record_id ou ID de post.
	 *
	 * @param string $identificador Identificador informado.
	 * @return int[]
	 */
	private function localizar( string $identificador ): array {
		$identificador = trim( $identificador );

		if ( '' === $identificador ) {
			return array();
		}

		if ( ctype_digit( $identificador ) ) {
			$post = get_post( (int) $identificador );
			if ( $post instanceof WP_Post && in_array( $post->post_type, $this->tipos_de_lead(), true ) ) {
				return array( (int) $post->ID );
			}
		}

		$meta = is_email( $identificador ) ? '_f3base_email' : '_f3base_record_id';

		$ids = get_posts(
			array(
				'post_type'              => $this->tipos_de_lead(),
				'post_status'            => 'any',
				'numberposts'            => 500,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
				'suppress_filters'       => false,
				'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'key'     => $meta,
						'value'   => $identificador,
						'compare' => '=',
					),
				),
			)
		);

		return is_array( $ids ) ? array_map( 'intval', $ids ) : array();
	}

	/**
	 * Tipos de conteúdo que guardam lead.
	 *
	 * @return string[]
	 */
	private function tipos_de_lead(): array {
		$tipos = array( F3Base_Modulo_Endpoint_Leads::CPT );

		if ( post_type_exists( 'flamingo_inbound' ) ) {
			$tipos[] = 'flamingo_inbound';
		}

		/**
		 * Permite acrescentar outra caixa de leads à retenção.
		 *
		 * @param string[] $tipos Tipos de conteúdo cobertos.
		 */
		$tipos = apply_filters( 'f3base_tipos_de_lead', $tipos );

		return is_array( $tipos ) ? array_values( array_unique( array_map( 'strval', $tipos ) ) ) : array( F3Base_Modulo_Endpoint_Leads::CPT );
	}

	/**
	 * Prazo de retenção, em meses.
	 *
	 * @return int
	 */
	private function meses(): int {
		$meses = F3Base_Options::ler( 'f3base_retencao_meses' );

		return is_int( $meses ) ? $meses : 12;
	}

	/**
	 * Janela reversível da limpeza operacional, em segundos.
	 *
	 * @return int
	 */
	private function janela_reversivel(): int {
		$dias = (int) apply_filters( 'f3base_janela_reversivel_dias', 30 );

		return max( DAY_IN_SECONDS, $dias * DAY_IN_SECONDS );
	}

	/**
	 * Timestamp previsto da execução, guardado na atividade.
	 *
	 * @return int
	 */
	private function previsto(): int {
		$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ATRASO_CRON );

		return isset( $carimbo['previsto'] ) ? (int) $carimbo['previsto'] : 0;
	}

	/**
	 * Guarda a previsão da próxima execução, para medir o atraso seguinte.
	 *
	 * @param int $quando Timestamp previsto.
	 * @return void
	 */
	private function guardar_previsao( int $quando ): void {
		F3Base_Atividade::registrar(
			F3Base_Atividade::ATRASO_CRON,
			array( 'previsto' => $quando )
		);
	}
}
