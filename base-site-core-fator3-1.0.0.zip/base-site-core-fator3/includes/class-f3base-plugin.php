<?php
/**
 * Orquestrador do plugin.
 *
 * Registra os hooks LENDO O REGISTRO ÚNICO: nenhum `add_action` de módulo é
 * escrito aqui à mão. Módulo inativo não registra nada — é inerte de verdade.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ciclo de vida do site-core.
 */
final class F3Base_Site_Core {

	/**
	 * Prioridade em que os hooks dos módulos são registrados, dentro de `init`.
	 *
	 * Registrar em `init` (e não em `plugins_loaded`) mantém toda leitura de
	 * estado depois do carregamento do text domain: chamar tradução antes de
	 * `init` gera aviso do core desde o WordPress 6.7.
	 */
	public const PRIORIDADE_REGISTRO = 5;

	/**
	 * Liga o plugin.
	 *
	 * @return void
	 */
	public static function iniciar(): void {
		add_action( 'init', array( __CLASS__, 'carregar_traducoes' ), 0 );
		add_action( 'admin_notices', array( __CLASS__, 'avisar_copia_desativada' ) );
		add_action( 'init', array( __CLASS__, 'registrar' ), self::PRIORIDADE_REGISTRO );
		add_action( 'rest_api_init', array( __CLASS__, 'registrar_rota_relatorio' ), 10 );

		/*
		 * A HABILIDADE QUE DIZ AO AGENTE COMO USAR O PLUGIN. Ela é registrada no
		 * gancho da própria Abilities API, que só existe quando o servidor MCP
		 * está instalado — sem ele, nada acontece e nada falha.
		 */
		add_action( 'abilities_api_init', array( 'F3Base_Como_Usar', 'registrar' ) );
		add_action( 'abilities_api_init', array( 'F3Base_Config_Mcp', 'registrar' ) );

		if ( is_admin() ) {
			F3Base_Admin_Tela::iniciar();
			/*
			 * A MEDIÇÃO GANHOU CASA PRÓPRIA na 1.1.0. Ela morava no fim da tela
			 * de configuração, depois de trinta campos de formulário: quem abre
			 * aquela tela vai gravar uma option, e quem quer saber o que os
			 * visitantes fizeram tem outra pergunta — que não é sub-item de
			 * configuração nenhuma.
			 */
			F3Base_Admin_Medicao::iniciar();
		}
	}

	/**
	 * Carrega o text domain.
	 *
	 * @return void
	 */
	public static function carregar_traducoes(): void {
		load_plugin_textdomain(
			F3BASE_TEXT_DOMAIN,
			false,
			dirname( plugin_basename( F3BASE_PLUGIN_ARQUIVO ) ) . '/languages'
		);
	}

	/**
	 * Registra os hooks declarados pelos módulos do registro único.
	 *
	 * Módulo inativo continua inerte — nenhum asset, nenhum endpoint, nenhuma
	 * tabela —, com UMA exceção declarada por hook: o item marcado `sempre` é
	 * registrado de qualquer jeito. Ele existe para o filtro cuja decisão é POR
	 * OBJETO, e cujo caso mais importante acontece justamente com o módulo
	 * inativo: o bloco do CTA sem número. Antes desta exceção, o filtro que
	 * decidia publicar o botão só era registrado quando a condição dele já não
	 * podia acontecer, e a regra nunca rodava.
	 *
	 * @return void
	 */
	public static function registrar(): void {
		foreach ( F3Base_Registro::modulos() as $modulo ) {
			$ativo = $modulo->deve_registrar();

			foreach ( $modulo->hooks() as $hook ) {
				if ( ! $ativo && empty( $hook['sempre'] ) ) {
					continue;
				}

				$metodo = (string) $hook['metodo'];

				if ( ! method_exists( $modulo, $metodo ) ) {
					continue;
				}

				$callback   = array( $modulo, $metodo );
				$prioridade = (int) $hook['prioridade'];
				$args       = (int) $hook['args'];

				if ( 'filter' === (string) $hook['tipo'] ) {
					add_filter( (string) $hook['hook'], $callback, $prioridade, max( 1, $args ) );
					continue;
				}

				add_action( (string) $hook['hook'], $callback, $prioridade, $args );
			}
		}
	}

	/**
	 * Rota de leitura do relatório — a mesma estrutura que a tela renderiza.
	 *
	 * @return void
	 */
	public static function registrar_rota_relatorio(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			'/relatorio',
			array(
				'methods'             => 'GET',
				'callback'            => static function (): WP_REST_Response {
					return new WP_REST_Response( F3Base_Registro::relatorio(), 200 );
				},
				'permission_callback' => static function (): bool {
					return current_user_can( 'manage_options' );
				},
				'args'                => array(),
			)
		);
	}

	/**
	 * Relatório do plugin, para o implantador e para a suíte.
	 *
	 * @return array<string,mixed>
	 */
	public static function relatorio(): array {
		return F3Base_Registro::relatorio();
	}

	/**
	 * Nome do transiente que carrega, para a tela, o que a ativação desativou.
	 *
	 * Transiente e não option: a mensagem é de UMA ativação, tem prazo e não é
	 * estado do site. Option sem prazo obrigaria alguém a apagá-la depois, e
	 * option que ninguém apaga vira aviso permanente sobre um fato de um dia só.
	 */
	public const TRANSIENTE_MIGRACAO = 'f3base_copia_anterior_desativada';

	/**
	 * Marca que o arquivo principal de uma cópia deste plugin sempre carrega.
	 *
	 * O DISCRIMINANTE NÃO É O NOME DA PASTA, e é isso que o torna honesto. Uma
	 * lista literal de pastas antigas só reconhece o que alguém lembrou de
	 * escrever nela, e a pasta antiga deste plugin não é a única que pode
	 * existir: sites renomeados por `ferramentas/renomear-prefixo.sh` até a
	 * 1.6.6 receberam um FORK dele com outro nome de pasta ainda. O que TODAS
	 * essas cópias têm em comum é a reivindicação do mesmo namespace REST — é
	 * dela que vem a colisão, porque é ela que faz duas cópias registrarem as
	 * MESMAS rotas.
	 */
	public const MARCA_DE_COPIA = 'F3BASE_REST_NAMESPACE';

	/**
	 * DESATIVA QUALQUER OUTRA CÓPIA ATIVA DESTE MESMO PLUGIN.
	 *
	 * O DEFEITO QUE ISTO IMPEDE, e ele é real: existe pelo menos um site em
	 * produção com este plugin na pasta antiga (`f3base-site-core`, 1.3.6).
	 * Instalar a pasta nova ali deixa DUAS CÓPIAS DO MESMO PLUGIN ATIVAS ao
	 * mesmo tempo. O WordPress não impede isso e não avisa: são dois registros
	 * de hooks, dois `register_rest_route` para o mesmo endpoint, dois
	 * coletores enfileirados na mesma página e a conversão contada em dobro na
	 * conta de medição do fornecedor. Nada disso aparece como erro — aparece
	 * como número errado, semanas depois, sem nada que aponte para a causa.
	 *
	 * NÃO HÁ DADO A MIGRAR, e é exatamente por isso que o prefixo interno não
	 * mudou: as options são as mesmas `f3base_*` e as tabelas são as mesmas
	 * `f3base_comportamento` e `f3base_eventos`. A cópia nova encontra a
	 * configuração do site inteira, no lugar onde ela sempre esteve. O que
	 * mudou foi o ENDEREÇO do código, e endereço não guarda dado.
	 *
	 * POR QUE DESATIVAR A OUTRA, E NÃO RECUSAR ATIVAR ESTA. A recusa foi
	 * considerada e é pior por três razões medidas:
	 *
	 * 1. Recusar deixa o site rodando a cópia ANTIGA — que é o artefato que
	 *    esta release existe para substituir — e transfere a correção para uma
	 *    pessoa ler uma mensagem. A instalação é feita pelo implantador, sem
	 *    ninguém olhando; a mensagem chegaria a um relatório e o site seguiria
	 *    exatamente como estava.
	 * 2. O dano das duas cópias já existe no instante da ativação, e recusar
	 *    não o desfaz: ele só não fica pior. Desativar a antiga é a única ação
	 *    que devolve o site a UMA cópia.
	 * 3. Desativar plugin alheio seria atrevimento. Este não é alheio: é uma
	 *    cópia MAIS VELHA DESTE MESMO PLUGIN, reconhecida pela reivindicação do
	 *    mesmo namespace REST, e o WordPress não tem como servir os dois.
	 *
	 * O QUE ISTO NÃO FAZ, e o limite importa: não apaga arquivo nenhum, não
	 * toca em option nem em tabela, e não desativa nada que não carregue a
	 * marca. A pasta antiga continua em disco, legível, e reativá-la é um
	 * clique — a ação é reversível, e é isso que a torna aceitável. O que ela
	 * deixa é REGISTRO: um transiente que a tela lê e um nome, nunca um número.
	 *
	 * @return array<int,string> Os arquivos principais que foram desativados.
	 */
	public static function desativar_copias_do_mesmo_plugin(): array {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$este       = plugin_basename( F3BASE_PLUGIN_ARQUIVO );
		$desativar  = array();

		foreach ( array_keys( get_plugins() ) as $arquivo ) {
			$arquivo = (string) $arquivo;

			if ( $arquivo === $este || ! is_plugin_active( $arquivo ) ) {
				continue;
			}

			$principal = WP_PLUGIN_DIR . '/' . $arquivo;

			if ( ! is_readable( $principal ) ) {
				continue;
			}

			/*
			 * Os mesmos 8 KiB que `get_file_data()` lê. Um arquivo principal
			 * que define o namespace REST deste plugin É uma cópia dele: a
			 * constante é a reivindicação, e duas reivindicações do mesmo
			 * namespace são duas cópias servindo as mesmas rotas.
			 */
			$topo = (string) file_get_contents( $principal, false, null, 0, 8192 );

			if ( ! str_contains( $topo, self::MARCA_DE_COPIA ) ) {
				continue;
			}

			$desativar[] = $arquivo;
		}

		if ( array() === $desativar ) {
			return array();
		}

		/*
		 * `false` no terceiro argumento: NÃO roda o hook de desativação da
		 * cópia antiga. O hook dela desinstala os módulos — desagenda a
		 * cadência, remove regras de reescrita — e são os MESMOS agendamentos e
		 * as MESMAS regras que esta cópia acabou de instalar, porque as chaves
		 * são as mesmas. Rodar o hook desfaria a ativação em curso, e o site
		 * ficaria com o plugin ativo e a cadência desagendada, calado.
		 */
		deactivate_plugins( $desativar, true );

		set_transient( self::TRANSIENTE_MIGRACAO, $desativar, WEEK_IN_SECONDS );

		return $desativar;
	}

	/**
	 * Aviso da tela: o que a ativação desativou, com o nome e o motivo.
	 *
	 * Ele é lido UMA vez e apagado: o fato é de uma ativação, não do site.
	 *
	 * @return void
	 */
	public static function avisar_copia_desativada(): void {
		$desativados = get_transient( self::TRANSIENTE_MIGRACAO );

		if ( ! is_array( $desativados ) || array() === $desativados ) {
			return;
		}

		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		delete_transient( self::TRANSIENTE_MIGRACAO );

		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: %s: lista de arquivos principais de plugin desativados. */
					__( 'Base Site Core Fator3 desativou uma cópia mais velha de si mesmo que estava ativa neste site: %s. Duas cópias ativas registram os mesmos hooks e as mesmas rotas REST, e a conversão passa a ser contada em dobro sem nenhum erro aparecer. Nenhum dado foi tocado: as options f3base_* e as tabelas f3base_comportamento e f3base_eventos são as mesmas dos dois lados, e é por isso que não há o que migrar. A pasta antiga continua em disco e pode ser reativada por um clique — o que não pode existir é as duas ativas ao mesmo tempo.', 'f3base' ),
					implode( ', ', array_map( 'strval', $desativados ) )
				)
			)
		);
	}

	/**
	 * Ativação: desativa cópia anterior deste mesmo plugin, semeia os padrões,
	 * instala a estrutura dos módulos e regrava as regras de reescrita.
	 *
	 * A ORDEM É A DO CÓDIGO. A cópia velha sai ANTES de qualquer escrita: com
	 * ela ativa, os hooks dela ainda estão registrados nesta requisição, e o
	 * `flush_rewrite_rules()` do fim gravaria as regras das duas.
	 *
	 * @return void
	 */
	public static function ativar(): void {
		self::desativar_copias_do_mesmo_plugin();

		self::semear_padroes();

		foreach ( F3Base_Registro::instanciar() as $modulo ) {
			if ( $modulo->deve_registrar() ) {
				$modulo->instalar();
			}
		}

		flush_rewrite_rules( false );
	}

	/**
	 * Desativação: desfaz agendamentos e regrava as regras de reescrita.
	 *
	 * Nenhum dado de lead é tocado aqui: desativar plugin não é pedido de
	 * eliminação, e apagar registro pessoal sem journal é perda sem registro.
	 *
	 * @return void
	 */
	public static function desativar(): void {
		foreach ( F3Base_Registro::instanciar() as $modulo ) {
			$modulo->desinstalar();
		}

		flush_rewrite_rules( false );
	}

	/**
	 * Grava o padrão embutido apenas nas options que ainda não existem.
	 *
	 * Option já escrita pelo implantador nunca é sobrescrita na ativação.
	 *
	 * @return void
	 */
	private static function semear_padroes(): void {
		foreach ( F3Base_Options::catalogo() as $nome => $declaracao ) {
			if ( F3Base_Options::existe( $nome ) ) {
				continue;
			}

			if ( isset( $declaracao['campo'] ) && 'segredo' === $declaracao['campo'] ) {
				continue;
			}

			F3Base_Options::gravar( $nome, $declaracao['padrao'], F3Base_Options::ORIGEM_PADRAO );
		}
	}
}
