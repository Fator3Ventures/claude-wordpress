<?php
/**
 * Módulo cabecalhos.
 *
 * Emite os cabeçalhos de resposta da configuração — os de segurança que não
 * alteram o carregamento de recurso nenhum.
 *
 * COOP SAI DO VALOR GRAVADO desde a 1.1.0. `same-origin-allow-popups` continua
 * sendo o valor de que o fluxo de leads precisa — `same-origin` corta a relação
 * com a janela que o CTA abre —, mas o pacote passou a NOMEAR a consequência em
 * vez de impor o valor: quem grava outra coisa lê de volta o que gravou, e o
 * estado do módulo fecha degradado dizendo o que se perde.
 *
 * HSTS fica desligado por padrão — é o único da lista com efeito persistente no
 * navegador, e a decisão é do cliente, com implantação escalonada.
 *
 * `Referrer-Policy: no-referrer` é aceito e AVISADO: ele apaga o referenciador
 * de toda saída, e é dele que dependem a atribuição de origem do GA4 e o
 * reconhecimento de tráfego pago de Google Ads, Meta Ads e LinkedIn Ads quando
 * o clique chega sem parâmetro de campanha. O aviso nomeia a perda; recusar o
 * valor seria decidir pelo projeto.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cabeçalhos de resposta.
 */
final class F3Base_Modulo_Cabecalhos extends F3Base_Modulo {

	/**
	 * Valor de que o fluxo de leads PRECISA — recomendação medida, não trava.
	 */
	public const COOP_EXIGIDO = F3Base_Vocabulario::COOP_PERMITE_POPUP;

	/**
	 * Valor de `Referrer-Policy` que apaga a atribuição dos canais pagos.
	 */
	public const REFERRER_SEM_ORIGEM = 'no-referrer';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'cabecalhos';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Cabeçalhos de resposta', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Emite no front-end os cabeçalhos de segurança declarados na configuração, cada um com o valor gravado. COOP sai como está gravado, e o estado nomeia a consequência quando não for same-origin-allow-popups; HSTS sai apenas quando ligado por decisão e sobre HTTPS.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'send_headers',
				'metodo'     => 'emitir',
				'prioridade' => 10,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_cabecalhos' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		return array(
			array(
				'rotulo'   => __( 'HTTPS na requisição', 'f3base' ),
				'presente' => is_ssl(),
				'detalhe'  => is_ssl()
					? __( 'HSTS pode ser emitido quando a decisão do cliente ligar a chave.', 'f3base' )
					: __( 'sem HTTPS, HSTS não é emitido em hipótese alguma.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = $this->config();

		if ( self::COOP_EXIGIDO !== (string) $config['coop'] ) {
			return $this->degradado(
				sprintf(
					/* translators: 1: valor gravado, 2: valor recomendado. */
					__( 'COOP gravado como %1$s e emitido assim: o valor gravado é o que sai. O preço medido é este — o CTA abre a conversa em janela nova, e fora de %2$s o navegador corta a relação com ela: window.opener some e o retorno para esta aba deixa de existir. Gravar %2$s desfaz o corte na requisição seguinte.', 'f3base' ),
					(string) $config['coop'],
					self::COOP_EXIGIDO
				)
			);
		}

		if ( ! empty( $config['hsts'] ) && ! is_ssl() ) {
			return $this->degradado(
				__( 'HSTS ligado sem HTTPS nesta requisição: o cabeçalho não é emitido, e ligá-lo aqui não teria efeito seguro.', 'f3base' )
			);
		}

		if ( empty( $config['hsts'] ) ) {
			return $this->ativo(
				sprintf(
					/* translators: %s: valor do COOP. */
					__( 'emitindo a lista declarada com COOP %s; HSTS desligado por padrão, como decisão do cliente.', 'f3base' ),
					self::COOP_EXIGIDO
				)
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: max-age do HSTS, em segundos. */
				__( 'emitindo a lista declarada, com HSTS em max-age de %d segundos na etapa escalonada vigente.', 'f3base' ),
				(int) $config['hsts_max_age']
			)
		);
	}

	/**
	 * Emite os cabeçalhos.
	 *
	 * @return void
	 */
	public function emitir(): void {
		if ( is_admin() || headers_sent() ) {
			return;
		}

		foreach ( $this->lista_de_cabecalhos() as $nome => $valor ) {
			header( $nome . ': ' . $valor );
		}
	}

	/**
	 * A LISTA que `emitir()` manda para o navegador — nome => valor.
	 *
	 * Existe separada de `emitir()` porque `header()` não devolve nada e não se
	 * mede: a bancada da suíte lê ESTA lista e compara com o que foi gravado. O
	 * defeito que ela existe para impedir é o de 1.0.19, em que o COOP saía do
	 * literal da classe e a option gravada não tinha efeito nenhum.
	 *
	 * @return array<string,string>
	 */
	public function lista_de_cabecalhos(): array {
		$config = $this->config();
		$saida  = array();

		if ( ! empty( $config['x_content_type_options'] ) ) {
			$saida['X-Content-Type-Options'] = 'nosniff';
		}

		$frame = (string) $config['x_frame_options'];
		if ( '' !== $frame ) {
			$saida['X-Frame-Options'] = $frame;
		}

		$ancestrais = (string) $config['csp_frame_ancestors'];
		if ( '' !== $ancestrais ) {
			$saida['Content-Security-Policy'] = 'frame-ancestors ' . $ancestrais;
		}

		$referrer = (string) $config['referrer_policy'];
		if ( '' !== $referrer ) {
			$saida['Referrer-Policy'] = $referrer;
		}

		$coop = (string) $config['coop'];
		if ( '' !== $coop ) {
			$saida['Cross-Origin-Opener-Policy'] = $coop;
		}

		$permissoes = (string) $config['permissions_policy'];
		if ( '' !== $permissoes ) {
			$saida['Permissions-Policy'] = $permissoes;
		}

		if ( ! empty( $config['hsts'] ) && is_ssl() ) {
			$saida['Strict-Transport-Security'] = 'max-age=' . (int) $config['hsts_max_age'];
		}

		return $saida;
	}

	/**
	 * {@inheritDoc}
	 */
	public function avisos(): array {
		$config = $this->config();
		$avisos = array();

		if ( self::REFERRER_SEM_ORIGEM === (string) $config['referrer_policy'] ) {
			$avisos[] = array(
				'estado' => 'WARN',
				'motivo' => sprintf(
					/* translators: %s: valor gravado de Referrer-Policy. */
					__( 'Referrer-Policy gravado como %s: o navegador para de enviar o referenciador em TODA saída deste site, e com ele some a origem que o GA4 usa para classificar a sessão e que Google Ads, Meta Ads e LinkedIn Ads usam para reconhecer o próprio tráfego quando o clique chega sem parâmetro de campanha. O valor continua valendo — é decisão do projeto —, e o que este aviso faz é nomear o preço.', 'f3base' ),
					self::REFERRER_SEM_ORIGEM
				),
			);
		}

		return $avisos;
	}

	/**
	 * Configuração normalizada.
	 *
	 * @return array<string,mixed>
	 */
	private function config(): array {
		$declaracao = F3Base_Options::declaracao( 'f3base_cabecalhos' );
		$padrao     = null !== $declaracao && is_array( $declaracao['padrao'] ) ? $declaracao['padrao'] : array();
		$config     = F3Base_Options::ler( 'f3base_cabecalhos' );

		return array_merge( $padrao, is_array( $config ) ? $config : array() );
	}
}
