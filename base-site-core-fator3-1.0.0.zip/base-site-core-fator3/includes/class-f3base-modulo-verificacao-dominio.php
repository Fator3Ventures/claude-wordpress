<?php
/**
 * Módulo verificacao-dominio: as duas `<meta>` de posse do domínio.
 *
 * O BURACO MEDIDO. Até a 1.1.1 o pacote não tinha uma única ocorrência de
 * `google-site-verification` nem de `facebook-domain-verification` — zero, nas
 * fontes inteiras. As duas são o passo que autoriza a operação a mexer no que
 * este pacote já emite: sem a verificação do Search Console não há propriedade
 * do domínio a que ligar o GA4 e os relatórios de busca; sem a verificação de
 * domínio da Meta não há como reivindicar o domínio no Gerenciador de Negócios,
 * e é ela que decide quem edita o link e a criativa do anúncio que aponta para
 * este site. As duas eram passo humano no console E passo humano no HTML — e o
 * segundo não precisava ser.
 *
 * O desenho é o mesmo dos slots de medição da decisão 55, e por isso não inventa
 * um segundo mecanismo: option vazia é INERTE — sem tag nenhuma no `<head>` —, e
 * option preenchida emite. Quem grava é o agente, pelo canal; as chaves existem
 * no arquivo único para que um site cujo operador JÁ tenha os tokens nasça
 * verificado, sem uma segunda visita.
 *
 * VALOR FORA DA FORMA É PRESERVADO E AVISADO, nunca apagado — a regra da 1.1.0.
 * O token de verificação é um valor opaco que o fornecedor gera; o pacote sabe
 * qual é o alfabeto que as duas tags usam hoje e não sabe qual será amanhã.
 * Recusar o que ele não reconhece seria decidir por quem grava, e apagar em
 * silêncio é o que este pacote parou de fazer. A saída sempre passa por
 * `esc_attr()`: o valor estranho vira atributo escapado, não markup.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Emissão das metatags de verificação de posse do domínio.
 */
final class F3Base_Modulo_Verificacao_Dominio extends F3Base_Modulo {

	/**
	 * Teto de caracteres do token, medido em bytes na sanitização.
	 *
	 * Existe para que um valor absurdo não vire uma linha de `<head>` de
	 * quilobytes em toda página. É corte declarado e não silencioso: o
	 * sanitizador o aplica e este número é o que a descrição da option diz.
	 */
	public const TETO = 200;

	/**
	 * O mapa option => nome da metatag. FONTE ÚNICA das duas.
	 *
	 * Estado, dependências, avisos e emissão leem daqui. Duas listas divergiriam
	 * na primeira verificação acrescentada — e a terceira delas já existe lá
	 * fora (Bing, Pinterest); quem a acrescentar mexe num lugar só.
	 *
	 * @return array<string,array{tag:string,fornecedor:string,onde:string}>
	 */
	public static function tags(): array {
		return array(
			'f3base_verificacao_google' => array(
				'tag'        => 'google-site-verification',
				'fornecedor' => 'Google Search Console',
				'onde'       => __( 'a propriedade de prefixo de URL do Search Console, quando a verificação não é feita por DNS', 'f3base' ),
			),
			'f3base_verificacao_meta'   => array(
				'tag'        => 'facebook-domain-verification',
				'fornecedor' => 'Meta — Gerenciador de Negócios',
				'onde'       => __( 'a reivindicação do domínio no Gerenciador de Negócios, que é o que decide quem edita link e criativa dos anúncios que apontam para este site', 'f3base' ),
			),
		);
	}

	/**
	 * A FORMA declarada de um token de verificação.
	 *
	 * Ela não recusa: existe para o aviso. Os dois fornecedores emitem hoje
	 * tokens no alfabeto base64url — letra, dígito, hífen e sublinhado —, e um
	 * valor fora disso quase sempre é um recorte errado (a tag inteira colada em
	 * vez do conteúdo dela) que produz uma verificação que nunca fecha.
	 */
	public const FORMA_REGEX = '/^[A-Za-z0-9_-]+$/';

	/**
	 * A forma, em palavras, para a mensagem do aviso.
	 */
	public const FORMA_DIZ = 'letras, dígitos, hífen e sublinhado';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'verificacao-dominio';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Verificação de domínio', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Emite no <head> a metatag de verificação de posse do domínio de cada token gravado — google-site-verification e facebook-domain-verification. Option vazia é inerte: nenhuma tag é emitida por ela. Valor fora da forma esperada é preservado e avisado, nunca apagado.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_head',
				'metodo'     => 'emitir',
				'prioridade' => 1,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array_keys( self::tags() );
	}

	/**
	 * Os tokens gravados, por nome de option.
	 *
	 * @return array<string,string>
	 */
	public static function tokens(): array {
		$saida = array();

		foreach ( array_keys( self::tags() ) as $option ) {
			$valor           = F3Base_Options::ler( $option );
			$saida[ $option ] = is_string( $valor ) ? trim( $valor ) : '';
		}

		return $saida;
	}

	/**
	 * As options PREENCHIDAS.
	 *
	 * @return array<string,string>
	 */
	public static function preenchidas(): array {
		return array_filter( self::tokens(), static fn ( string $valor ): bool => '' !== $valor );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$tokens = self::tokens();
		$tags   = self::tags();
		$saida  = array();

		foreach ( $tags as $option => $tag ) {
			$saida[] = array(
				'rotulo'   => $option,
				'presente' => '' !== $tokens[ $option ],
				'detalhe'  => '' !== $tokens[ $option ]
					? sprintf(
						/* translators: %s: nome da metatag emitida. */
						__( 'preenchida: a metatag %s é emitida no <head> de toda página.', 'f3base' ),
						$tag['tag']
					)
					: sprintf(
						/* translators: 1: nome da metatag, 2: onde o token é obtido. */
						__( 'vazia: a metatag %1$s NÃO é emitida. O token sai de %2$s, e é passo humano no console do fornecedor — nenhum agente o obtém.', 'f3base' ),
						$tag['tag'],
						$tag['onde']
					),
			);
		}

		return $saida;
	}

	/**
	 * {@inheritDoc}
	 */
	public function avisos(): array {
		$avisos = array();

		foreach ( self::preenchidas() as $option => $valor ) {
			if ( 1 === preg_match( self::FORMA_REGEX, $valor ) ) {
				continue;
			}

			$tags = self::tags();

			$avisos[] = array(
				'estado' => 'WARN',
				'motivo' => sprintf(
					/* translators: 1: nome da option, 2: nome da metatag, 3: forma esperada em palavras. */
					__( '%1$s traz caractere fora do que a tag %2$s aceita (%3$s). O valor foi PRESERVADO — este pacote não apaga o que alguém gravou — e sai escapado no atributo; a consequência é esta: a tag existe no HTML, o fornecedor não reconhece o token, e a verificação nunca fecha. O engano mais comum é colar a tag inteira em vez do conteúdo dela.', 'f3base' ),
					$option,
					$tags[ $option ]['tag'],
					self::FORMA_DIZ
				),
			);
		}

		return $avisos;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$preenchidas = self::preenchidas();
		$tags        = self::tags();

		if ( array() === $preenchidas ) {
			return $this->inativo(
				sprintf(
					/* translators: %s: nomes das options, separados por vírgula. */
					__( 'nenhum token de verificação gravado: %s estão vazias e NENHUMA metatag de verificação é emitida. Os tokens são obtidos nos consoles dos fornecedores — passo humano, descrito em TEMPLATE.md — e gravá-los faz a tag passar a existir na página seguinte, sem release nova.', 'f3base' ),
					implode( ', ', array_keys( $tags ) )
				)
			);
		}

		$nomes = array();

		foreach ( array_keys( $preenchidas ) as $option ) {
			$nomes[] = $tags[ $option ]['tag'];
		}

		$faltando = array_diff( array_keys( $tags ), array_keys( $preenchidas ) );

		return $this->ativo(
			sprintf(
				/* translators: 1: metatags emitidas, 2: options ainda vazias. */
				__( 'metatag(s) emitida(s) no <head> de toda página: %1$s. Ainda sem token: %2$s.', 'f3base' ),
				implode( ', ', $nomes ),
				array() === $faltando ? __( 'nenhuma', 'f3base' ) : implode( ', ', $faltando )
			)
		);
	}

	/**
	 * O MARKUP das tags de verificação. FUNÇÃO PURA sobre os valores dados.
	 *
	 * Pura de propósito: é ela que o piso exercita, nos dois ramos — com valor a
	 * tag existe, sem valor não existe nada. Uma bancada que precisasse de um
	 * `wp_head` renderizado para provar isso estaria provando o WordPress.
	 *
	 * @param array<string,string> $tokens Tokens por nome de option.
	 * @return string
	 */
	public static function markup( array $tokens ): string {
		$linhas = array();

		foreach ( self::tags() as $option => $tag ) {
			$valor = trim( (string) ( $tokens[ $option ] ?? '' ) );

			if ( '' === $valor ) {
				continue;
			}

			$linhas[] = '<meta name="' . esc_attr( $tag['tag'] ) . '" content="' . esc_attr( $valor ) . '" />';
		}

		return array() === $linhas ? '' : implode( "\n", $linhas ) . "\n";
	}

	/**
	 * Emite as tags no `<head>`.
	 *
	 * @return void
	 */
	public function emitir(): void {
		$markup = self::markup( self::tokens() );

		if ( '' === $markup ) {
			return;
		}

		echo $markup; // phpcs:ignore WordPress.Security.EscapingOutput.OutputNotEscaped -- markup() escapa nome e conteúdo de cada atributo.
	}
}
