<?php
/**
 * A configuração do implantador, lida e escrita pelo agente MCP.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * LER E ESCREVER A CONFIGURAÇÃO SEM EDITAR ARQUIVO ÀS CEGAS.
 *
 * POR QUE ISTO MORA NO PLUGIN, e não no implantador. O implantador se
 * autodesativa quando termina, e plugin desativado não registra habilidade
 * nenhuma. O momento em que o agente mais precisa preencher a configuração é
 * justamente DEPOIS disso — para a próxima execução. Uma habilidade que só
 * funcionasse antes de a ferramenta terminar não serviria para a hora em que ela
 * é necessária.
 *
 * A alternativa seria o plugin guardar a configuração numa option e o
 * implantador ler as duas fontes. Isso cria duas respostas para o mesmo valor, e
 * é o defeito que este pacote passa a vida fechando. Um plugin nosso escrevendo
 * no arquivo de outro plugin nosso, num caminho declarado, é o preço menor.
 *
 * ESCRITA É TUDO OU NADA. Configuração que não passa no schema é recusada com o
 * campo nomeado e NADA é gravado: meia configuração no disco é pior que nenhuma,
 * porque a execução seguinte parte de um estado que ninguém escolheu.
 */
final class F3Base_Config_Mcp {

	/**
	 * Arquivos que a habilidade conhece, e o schema de cada um.
	 *
	 * @var array<string,array<string,string>>
	 */
	private const ARQUIVOS = array(
		'projeto' => array(
			'config' => 'config/projeto.json',
			'schema' => 'config/projeto.schema.json',
		),
		'site'    => array(
			'config' => 'config/site.json',
			'schema' => 'config/site.schema.json',
		),
	);

	/**
	 * Registra as habilidades quando a API existir.
	 *
	 * @return void
	 */
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			'f3base/config-ler',
			array(
				'label'               => __( 'Ler a configuração do implantador', 'f3base' ),
				'description'         => __( 'Devolve o conteúdo atual de config/projeto.json ou config/site.json e o schema correspondente. O schema diz, campo a campo, o que preencher e onde obter o valor.', 'f3base' ),
				'input_schema'        => array(
					'type'       => 'object',
					'properties' => array(
						'arquivo' => array(
							'type'        => 'string',
							'enum'        => array( 'projeto', 'site' ),
							'description' => __( '"projeto" é o arquivo que o operador preenche; "site" guarda conteúdo e referências internas.', 'f3base' ),
						),
					),
					'required'   => array( 'arquivo' ),
				),
				'output_schema'       => array( 'type' => 'object' ),
				'execute_callback'    => array( __CLASS__, 'ler' ),
				'permission_callback' => static function (): bool {
					return current_user_can( 'manage_options' );
				},
			)
		);

		wp_register_ability(
			'f3base/config-escrever',
			array(
				'label'               => __( 'Escrever a configuração do implantador', 'f3base' ),
				'description'         => __( 'Grava o conteúdo enviado depois de validá-lo contra o schema. Se a validação falhar, nada é gravado e a resposta nomeia os campos com problema.', 'f3base' ),
				'input_schema'        => array(
					'type'       => 'object',
					'properties' => array(
						'arquivo'  => array(
							'type' => 'string',
							'enum' => array( 'projeto', 'site' ),
						),
						'conteudo' => array(
							'type'        => 'object',
							'description' => __( 'O arquivo INTEIRO, não um pedaço: leia antes, altere o que precisa e devolva o todo.', 'f3base' ),
						),
					),
					'required'   => array( 'arquivo', 'conteudo' ),
				),
				'output_schema'       => array( 'type' => 'object' ),
				'execute_callback'    => array( __CLASS__, 'escrever' ),
				'permission_callback' => static function (): bool {
					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	/**
	 * O DIRETÓRIO DO IMPLANTADOR, descoberto pelo que ele carrega.
	 *
	 * A busca é pelo SCHEMA do projeto, não pelo nome da pasta: o implantador é
	 * renomeado a cada site — o prefixo técnico é do projeto —, e procurar por
	 * um slug fixo encontraria o pacote de um site e não o de outro.
	 *
	 * @return string Caminho absoluto com barra final, ou vazio.
	 */
	public static function diretorio(): string {
		if ( ! defined( 'WP_PLUGIN_DIR' ) || ! is_dir( WP_PLUGIN_DIR ) ) {
			return '';
		}

		$pastas = glob( WP_PLUGIN_DIR . '/*/config/projeto.schema.json' );

		if ( ! is_array( $pastas ) || array() === $pastas ) {
			return '';
		}

		return dirname( dirname( $pastas[0] ) ) . '/';
	}

	/**
	 * Lê um arquivo de configuração e o schema dele.
	 *
	 * @param array<string,mixed> $entrada Entrada da habilidade.
	 * @return array<string,mixed>
	 */
	public static function ler( array $entrada = array() ): array {
		$qual = (string) ( $entrada['arquivo'] ?? 'projeto' );
		$onde = self::localizar( $qual );

		if ( '' !== $onde['erro'] ) {
			return array(
				'ok'    => false,
				'erro'  => $onde['erro'],
			);
		}

		return array(
			'ok'       => true,
			'arquivo'  => self::ARQUIVOS[ $qual ]['config'],
			'conteudo' => json_decode( (string) file_get_contents( $onde['config'] ), true ),
			'schema'   => json_decode( (string) file_get_contents( $onde['schema'] ), true ),
			'como'     => __( 'O schema traz um $comment por campo dizendo o que preencher e onde obter o valor. Para gravar, altere o conteúdo lido e devolva o arquivo INTEIRO em f3base/config-escrever.', 'f3base' ),
		);
	}

	/**
	 * Grava um arquivo de configuração, depois de validá-lo.
	 *
	 * @param array<string,mixed> $entrada Entrada da habilidade.
	 * @return array<string,mixed>
	 */
	public static function escrever( array $entrada = array() ): array {
		$qual     = (string) ( $entrada['arquivo'] ?? 'projeto' );
		$conteudo = $entrada['conteudo'] ?? null;
		$onde     = self::localizar( $qual );

		if ( '' !== $onde['erro'] ) {
			return array(
				'ok'   => false,
				'erro' => $onde['erro'],
			);
		}

		if ( ! is_array( $conteudo ) ) {
			return array(
				'ok'   => false,
				'erro' => __( 'O conteúdo precisa ser um objeto com o arquivo inteiro. Leia com f3base/config-ler, altere o que precisa e devolva o todo.', 'f3base' ),
			);
		}

		$erros = self::validar( $conteudo, $onde['schema'] );

		if ( array() !== $erros ) {
			return array(
				'ok'       => false,
				'gravou'   => false,
				'erro'     => __( 'A configuração não passou no schema e NADA foi gravado. O arquivo continua como estava.', 'f3base' ),
				'campos'   => $erros,
			);
		}

		$json = wp_json_encode( $conteudo, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

		if ( ! is_string( $json ) ) {
			return array(
				'ok'   => false,
				'erro' => __( 'O conteúdo não pôde ser convertido para JSON e nada foi gravado.', 'f3base' ),
			);
		}

		/*
		 * GRAVAÇÃO EM DUAS FASES: escreve ao lado e renomeia por cima. Uma
		 * escrita interrompida no meio do arquivo deixaria a configuração
		 * truncada, e a execução seguinte partiria de um JSON quebrado.
		 */
		$temporario = $onde['config'] . '.novo';

		if ( false === file_put_contents( $temporario, $json . "\n" ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- arquivo do próprio pacote, sem rede.
			return array(
				'ok'   => false,
				'erro' => __( 'Não foi possível escrever no diretório do implantador. Confira a permissão de escrita da pasta de plugins.', 'f3base' ),
			);
		}

		if ( ! rename( $temporario, $onde['config'] ) ) {
			unlink( $temporario );

			return array(
				'ok'   => false,
				'erro' => __( 'Não foi possível substituir o arquivo de configuração, e nada foi gravado.', 'f3base' ),
			);
		}

		return array(
			'ok'      => true,
			'gravou'  => true,
			'arquivo' => self::ARQUIVOS[ $qual ]['config'],
			'aviso'   => __( 'Gravado. O valor só chega ao site na próxima execução do implantador.', 'f3base' ),
		);
	}

	/**
	 * Valida contra o schema, pelo validador do implantador.
	 *
	 * UM VALIDADOR SÓ. Escrever um segundo aqui seria um segundo conjunto de
	 * regras divergindo do primeiro, e o piso de mutantes que o do implantador
	 * tem não valeria para este.
	 *
	 * @param array<string,mixed> $dados  Conteúdo a validar.
	 * @param string              $schema Caminho absoluto do schema.
	 * @return array<int,string> Erros; vazio quando válido.
	 */
	public static function validar( array $dados, string $schema ): array {
		if ( ! class_exists( 'F3Base_Imp_Config' ) ) {
			$classe = self::diretorio() . 'includes/class-f3base-imp-config.php';

			if ( is_file( $classe ) ) {
				require_once $classe;
			}
		}

		if ( ! class_exists( 'F3Base_Imp_Config' ) ) {
			return array( __( 'O validador do implantador não está disponível, e gravar sem validar seria pior: nada foi gravado.', 'f3base' ) );
		}

		return F3Base_Imp_Config::validar_com_schema( $dados, $schema );
	}

	/**
	 * Localiza os dois arquivos de um par declarado.
	 *
	 * @param string $qual Nome do par.
	 * @return array{config:string,schema:string,erro:string}
	 */
	private static function localizar( string $qual ): array {
		$vazio = array(
			'config' => '',
			'schema' => '',
			'erro'   => '',
		);

		if ( ! isset( self::ARQUIVOS[ $qual ] ) ) {
			$vazio['erro'] = sprintf(
				/* translators: %s: nomes aceitos. */
				__( 'Arquivo desconhecido. Os aceitos são: %s.', 'f3base' ),
				implode( ', ', array_keys( self::ARQUIVOS ) )
			);

			return $vazio;
		}

		$dir = self::diretorio();

		if ( '' === $dir ) {
			$vazio['erro'] = __( 'O implantador não está instalado neste site: não há configuração para ler nem para escrever. Instale o plugin do implantador e tente de novo.', 'f3base' );

			return $vazio;
		}

		$config = $dir . self::ARQUIVOS[ $qual ]['config'];
		$schema = $dir . self::ARQUIVOS[ $qual ]['schema'];

		if ( ! is_file( $config ) || ! is_file( $schema ) ) {
			$vazio['erro'] = sprintf(
				/* translators: %s: caminho do arquivo procurado. */
				__( 'O implantador está instalado, mas %s não existe nele.', 'f3base' ),
				self::ARQUIVOS[ $qual ]['config']
			);

			return $vazio;
		}

		return array(
			'config' => $config,
			'schema' => $schema,
			'erro'   => '',
		);
	}
}
