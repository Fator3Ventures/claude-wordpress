<?php
/**
 * Plugin Name:       Base Site Core Fator3
 * Plugin URI:        https://github.com/Fator3Ventures/claude-wordpress
 * Description:       Plugin persistente do Método F3: leads e endpoint endurecido, consentimento, tracking de GA4, Google Ads, Meta e LinkedIn dirigido pelos IDs gravados e gateado pelo consentimento, resumo agregado do comportamento das páginas guardado no próprio site, rota de origem, reserva de llms.txt, redirects de slug, honra de noindex, extensão de schema, retenção e eliminação com journal, cabeçalhos de resposta e o ouvinte da cadência do modo somente-relatório. Tudo declarado num registro único de módulos que alimenta hooks, tela e relatório.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            Fator 3 Ventures
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       f3base
 * Domain Path:       /languages
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * A NUMERAÇÃO RECOMEÇA EM 1.0.0, E ISSO É DELIBERADO.
 *
 * Até a 1.3.6 este arquivo era `f3base-site-core.php`, construído pelo
 * implantador e numerado na esteira dele. A partir desta release ele é um
 * ARTEFATO PRÓPRIO, com identidade própria, publicado como zip e instalado em
 * qualquer site desta operação como qualquer outro plugin de catálogo. Herdar
 * o 1.3.7 diria que este é o mesmo artefato de antes com uma correção a mais;
 * ele não é — o que mudou foi o que ele É. O 1.0.0 é a afirmação de que a série
 * anterior pertence a outro objeto, e a migração de quem está na série antiga
 * está escrita em `F3Base_Site_Core::desativar_copias_do_mesmo_plugin()`.
 *
 * O PREFIXO INTERNO `f3base` NÃO MUDA, e é a metade que importa. Nome de pasta
 * é ENDEREÇO: trocá-lo custa uma reinstalação. Nome de option é CHAVE DE DADO:
 * trocá-lo orfana o valor sem apagar nada e sem erro nenhum, e o site continua
 * rodando com o padrão de fábrica em cima de uma configuração que ninguém
 * apagou. Nome de tabela é pior — renomear apaga a série histórica. Nome de
 * evento é pior ainda — renomear quebra a série na conta de medição do
 * fornecedor, onde não há como reparar depois. Por isso `f3base_*` continua
 * exatamente como está em options, tabelas, eventos, namespace REST, classes e
 * text domain.
 */

/*
 * Identidade e caminhos. Constantes definidas antes de qualquer require: as classes
 * do plugin as consomem no carregamento e o guard de PHP abaixo precisa da versão
 * para nomear o próprio motivo.
 *
 * A VERSÃO SAI DO CABEÇALHO, NUNCA DE UM LITERAL AO LADO DELE. O defeito era
 * medido e estava aqui: o cabeçalho dizia `Version: 1.3.6` e esta constante
 * dizia `'1.3.5'`. Ninguém acusava, porque as duas são verdadeiras isoladamente
 * — e quem lê a constante (a tela, o parâmetro de versão dos assets publicados)
 * carimbava um número que o WordPress não mostra em lugar nenhum. É a mesma
 * regra que o tema já cumpre com o cabeçalho do `style.css`: o contrato é o
 * cabeçalho que o código lê, e constante que repete o número sai de sincronia
 * na primeira release em que alguém esquece de mexer nos dois.
 *
 * `get_file_data()` mora em `wp-includes/functions.php`, carregado antes de
 * qualquer plugin: ela está disponível aqui e não exige `wp-admin`.
 */
if ( ! defined( 'F3BASE_PLUGIN_VERSAO' ) ) {
	define(
		'F3BASE_PLUGIN_VERSAO',
		(string) ( get_file_data( __FILE__, array( 'versao' => 'Version' ), 'plugin' )['versao'] ?? '' )
	);
}
if ( ! defined( 'F3BASE_PLUGIN_PHP_MINIMO' ) ) {
	define( 'F3BASE_PLUGIN_PHP_MINIMO', '8.1' );
}
if ( ! defined( 'F3BASE_PREFIXO' ) ) {
	define( 'F3BASE_PREFIXO', 'f3base' );
}
if ( ! defined( 'F3BASE_TEXT_DOMAIN' ) ) {
	define( 'F3BASE_TEXT_DOMAIN', 'f3base' );
}
if ( ! defined( 'F3BASE_REST_NAMESPACE' ) ) {
	define( 'F3BASE_REST_NAMESPACE', 'f3base/v1' );
}
if ( ! defined( 'F3BASE_PLUGIN_ARQUIVO' ) ) {
	define( 'F3BASE_PLUGIN_ARQUIVO', __FILE__ );
}
if ( ! defined( 'F3BASE_PLUGIN_DIR' ) ) {
	define( 'F3BASE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'F3BASE_PLUGIN_URL' ) ) {
	define( 'F3BASE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

/**
 * Guard de versão de PHP.
 *
 * `version_compare()` aqui usa `<`, operador da lista permitida pelo contrato
 * (`< lt <= le > gt >= ge == = eq != <> ne`).
 *
 * @return bool Verdadeiro quando o PHP em execução atende ao mínimo declarado.
 */
function f3base_site_core_php_suportado(): bool {
	return ! version_compare( PHP_VERSION, F3BASE_PLUGIN_PHP_MINIMO, '<' );
}

if ( ! f3base_site_core_php_suportado() ) {
	add_action(
		'admin_notices',
		static function (): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html(
					sprintf(
						/* translators: 1: versão mínima de PHP exigida, 2: versão de PHP em execução. */
						__( 'Base Site Core Fator3 exige PHP %1$s ou superior. Este servidor executa PHP %2$s: o plugin ficou inerte e nenhum hook foi registrado.', 'f3base' ),
						F3BASE_PLUGIN_PHP_MINIMO,
						PHP_VERSION
					)
				)
			);
		}
	);

	return;
}

/**
 * Autoload simples: lista declarada de arquivos, um `require_once` por arquivo.
 *
 * Sem PSR-4 e sem `spl_autoload_register` de propósito — o pacote precisa ser
 * legível por quem abre a pasta, e a lista é a mesma que o empacotador confere.
 *
 * CINCO DESTES ARQUIVOS NÃO MORAM NA FONTE DESTE PLUGIN, e é preciso dizer
 * qual é o preço. `class-f3base-chaves-seo.php`, `class-f3base-vocabulario.php`,
 * `class-f3base-emissores.php`, `class-f3base-censo-demonstrativo.php` e
 * `dados/emissores-conhecidos.tsv` são CONTRATO COMPARTILHADO: o implantador
 * precisa das mesmas regras ANTES de este plugin existir na instalação — o
 * preflight roda antes de instalar qualquer coisa —, e este plugin precisa
 * delas em runtime. Elas moram em `partilhado/` no repositório, e o
 * empacotamento as copia para dentro deste zip, no caminho declarado aqui.
 *
 * O QUE ISSO CUSTA, dito por inteiro: a pasta `fontes/plugin/` do repositório
 * NÃO é instalável como está — faltam cinco arquivos. Isso é aceitável porque
 * este plugin é ARTEFATO CONSTRUÍDO: quem o instala instala o zip publicado,
 * nunca uma cópia da pasta. `pacote.plugin_completo_no_zip` confere, em toda
 * rodada, que o zip montado contém cada arquivo desta lista — uma lista que
 * cita um arquivo que o zip não tem é um plugin que morre no `require_once` da
 * ativação, e o piso do detector planta exatamente esse defeito.
 *
 * A ALTERNATIVA REJEITADA era o implantador continuar lendo de dentro da
 * fonte deste plugin, como fazia até a 1.6.6. Era ela que obrigava a fonte do
 * plugin a viajar dentro do bundle do implantador, e era ela que fazia a
 * renomeação de prefixo produzir um FORK deste plugin por site.
 *
 * @return void
 */
function f3base_site_core_carregar(): void {
	$arquivos = array(
		'includes/class-f3base-chaves-seo.php',
		'includes/class-f3base-vocabulario.php',
		'includes/class-f3base-options.php',
		'includes/class-f3base-atividade.php',
		'includes/class-f3base-modulo.php',
		'includes/class-f3base-modulo-leads-whatsapp.php',
		'includes/class-f3base-modulo-endpoint-leads.php',
		'includes/class-f3base-modulo-consentimento.php',
		'includes/class-f3base-emissores.php',
		'includes/class-f3base-censo-demonstrativo.php',
		'includes/class-f3base-modulo-tracking.php',
		'includes/class-f3base-modulo-comportamento.php',
		'includes/class-f3base-modulo-meta-capi.php',
		'includes/class-f3base-modulo-verificacao-dominio.php',
		'includes/class-f3base-modulo-rota-origem.php',
		'includes/class-f3base-llms.php',
		'includes/class-f3base-modulo-llms-txt-reserva.php',
		'includes/class-f3base-modulo-llms-full-txt.php',
		'includes/class-f3base-modulo-redirects.php',
		'includes/class-f3base-modulo-noindex-honrado.php',
		'includes/class-f3base-modulo-schema-extensao.php',
		'includes/class-f3base-modulo-retencao-eliminacao.php',
		'includes/class-f3base-modulo-cabecalhos.php',
		'includes/class-f3base-modulo-cadencia-relatorio.php',
		'includes/class-f3base-registro.php',
		'includes/class-f3base-como-usar.php',
		'includes/class-f3base-config-mcp.php',
		'includes/class-f3base-plugin.php',
		'admin/class-f3base-admin-tela.php',
		'admin/class-f3base-admin-medicao.php',
	);

	foreach ( $arquivos as $relativo ) {
		require_once F3BASE_PLUGIN_DIR . $relativo;
	}
}

f3base_site_core_carregar();

register_activation_hook( __FILE__, array( 'F3Base_Site_Core', 'ativar' ) );
register_deactivation_hook( __FILE__, array( 'F3Base_Site_Core', 'desativar' ) );

F3Base_Site_Core::iniciar();
