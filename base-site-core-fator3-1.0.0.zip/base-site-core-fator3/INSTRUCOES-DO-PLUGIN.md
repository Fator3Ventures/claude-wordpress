# Instruções do plugin — Base Site Core Fator3

Este arquivo viaja **dentro do zip do plugin**. Ele é a única coisa que outro agente precisa
ler para entender, operar e MUDAR este plugin sem quebrá-lo. Quem o lê não tem a memória da
operação que o produziu, e por isso nada aqui depende de conversa anterior: cada afirmação
aponta para o arquivo em que ela pode ser conferida.

<!-- gerado:inicio=plugin-identidade -->
> Este bloco é **gerado** por leitura de disco na primeira etapa do comando único, antes de o zip
> ser montado, e conferido por `estatica.carimbo_de_release_nos_documentos`. Nenhum número deste
> documento é digitado à mão: número digitado envelhece em silêncio, e um documento que descreve
> outro plugin é pior do que documento nenhum.

| Fato medido | Valor |
|---|---|
| Nome do artefato | `Base Site Core Fator3` |
| Versão, lida do cabeçalho | `1.0.0` |
| Pasta instalada | `base-site-core-fator3` |
| Prefixo interno | `f3base` |
| Namespace REST | `f3base/v1` |
| Text domain | `f3base` |
| WordPress mínimo · PHP mínimo | `6.4` · `8.1` |
| Módulos no registro único | 16 |
| Options no catálogo | 26 |
| Options operáveis na tela | 16 |
| Eventos de comportamento declarados | 7 |
| Rotas REST registradas | 6 |
| Tabelas próprias com colunas declaradas | 2 |
| Arquivos na fonte do plugin | 36 |
| Arquivos vindos de `partilhado/` | 5 |
<!-- gerado:fim=plugin-identidade -->

**Nenhum número deste documento é digitado à mão.** Todos saem de leitura de disco, nos blocos
marcados `gerado:inicio` / `gerado:fim`, escritos pela primeira etapa do comando único do
pacote que constrói este plugin. `estatica.carimbo_de_release_nos_documentos` compara o que
está aqui com a medição de agora, e `pacote.instrucoes_do_plugin_no_zip` recusa número digitado
fora dos blocos gerados. Se você mudar o plugin, **não conserte os números aqui**: reempacote, e
eles se consertam sozinhos.

---

## O que o plugin é

É a **peça persistente** de uma arquitetura de três peças — implantador, tema e plugin. O
implantador constrói o site e se autodesativa; o tema pode ser trocado; este plugin fica. Tudo o
que precisa sobreviver à troca de tema mora aqui: medição, consentimento, leads, retenção,
cabeçalhos de resposta, arquivos para leitores automáticos.

Ele tem **release própria** e numeração própria: não é construído pelo implantador, é publicado
como zip e instalado em qualquer site desta operação como qualquer outro plugin de catálogo. A
numeração recomeçou em `1.0.0` na release `1.7.0` do implantador — herdar a série anterior diria
que este é o mesmo artefato de antes com uma correção a mais, e o que mudou foi o que ele **é**.

O **prefixo interno não muda de site para site**, e essa é a metade que importa. Nome de pasta é
ENDEREÇO: trocá-lo custa uma reinstalação. Nome de option é CHAVE DE DADO: trocá-lo orfana o
valor sem apagar nada e sem erro nenhum, e o site passa a rodar no padrão de fábrica em cima de
uma configuração que ninguém apagou. Nome de tabela é pior — renomear apaga a série histórica.
Nome de evento é pior ainda — renomear quebra a série na conta de medição do fornecedor, onde não
há como reparar depois. As grafias que sobrevivem a qualquer renomeação estão declaradas em
`dados/contrato-de-nomes.tsv`.

**A pasta `fontes/plugin/` do repositório NÃO é instalável como está.** Faltam cinco arquivos:
`includes/class-f3base-chaves-seo.php`, `includes/class-f3base-vocabulario.php`,
`includes/class-f3base-emissores.php`, `includes/class-f3base-censo-demonstrativo.php` e
`dados/emissores-conhecidos.tsv` são CONTRATO COMPARTILHADO com o implantador, moram em
`partilhado/` no repositório, e o empacotamento os copia para dentro deste zip. Quem instala,
instala o **zip publicado** — nunca uma cópia da pasta. `pacote.plugin_completo_no_zip` confere,
em toda rodada, que o zip contém cada arquivo da lista de autoload.

---

## O registro único de módulos

`includes/class-f3base-registro.php` guarda a **única** lista de módulos do plugin. Ela alimenta
três coisas e não existe segunda lista: (a) o registro dos hooks, em
`includes/class-f3base-plugin.php`; (b) a tela do wp-admin, em `admin/class-f3base-admin-tela.php`;
(c) o relatório que a rota de leitura devolve e que o implantador consome. Módulo novo aparece
nos três lugares sozinho.

Cada módulo estende `F3Base_Modulo` (`includes/class-f3base-modulo.php`) e declara: `id()`,
`nome()`, `descricao()`, `hooks()`, `options_que_controlam()`, `dependencias()`, `atividade()`,
`avisos()` e `calcular_estado()`. O estado é fechado em três valores — `ativo`, `degradado`,
`inativo` — e vem **sempre com motivo**.

**Módulo inativo é inerte de verdade**: nenhum hook é registrado, nenhum endpoint existe, nenhum
asset é enfileirado. A exceção é declarada por hook, no próprio item, pela marca `sempre`, e
existe por um motivo só: há filtro cuja decisão é POR OBJETO, e cujo caso mais importante
acontece justamente com o módulo inativo — o filtro que decide se o bloco do botão de contato é
publicado. Um filtro desses que não se registra não decide nada, e a regra vira letra morta sem
ninguém perceber.

`degradado` é reservado ao que está PIOR que o desenho. Reserva ociosa com o principal
funcionando é `ativo`.

`avisos()` é outra coisa: é o que funciona **e custa alguma coisa em outro lugar**. Aviso não é
estado — o módulo continua ativo e nada é recusado. Aviso sem consequência nomeada é descartado
pelo registro, porque aviso que sai sempre treina o operador a ignorar aviso.

<!-- gerado:inicio=plugin-modulos -->
| Módulo | Arquivo | Options que o controlam | Hooks (tipo, gancho, prioridade) |
|---|---|---|---|
| `F3Base_Modulo_Cabecalhos`<br>id `cabecalhos` | `class-f3base-modulo-cabecalhos.php` | `f3base_cabecalhos` | `action send_headers (10)` |
| `F3Base_Modulo_Cadencia_Relatorio`<br>id `cadencia-relatorio` | `class-f3base-modulo-cadencia-relatorio.php` | `f3base_cadencia`, `f3base_cadencia_estado` | `filter cron_schedules (10)`<br>`action init (20)`<br>`action f3base_cadencia_relatorio (10)`<br>`action updated_option (10)`<br>`action added_option (10)`<br>`action deleted_option (10)` |
| `F3Base_Modulo_Comportamento`<br>id `comportamento` | `class-f3base-modulo-comportamento.php` | `f3base_comportamento` | `action init (20)`<br>`action rest_api_init (10)` |
| `F3Base_Modulo_Consentimento`<br>id `consentimento` | `class-f3base-modulo-consentimento.php` | `f3base_consentimento` | `action wp_enqueue_scripts (1)`<br>`action wp_footer (20)` |
| `F3Base_Modulo_Endpoint_Leads`<br>id `endpoint-leads` | `class-f3base-modulo-endpoint-leads.php` | `f3base_contato`, `f3base_endpoint_segredo`, `f3base_origem_confiavel` | `action init (10)`<br>`action init (20)`<br>`action rest_api_init (10)` |
| `F3Base_Modulo_Leads_Whatsapp`<br>id `leads-whatsapp` | `class-f3base-modulo-leads-whatsapp.php` | `f3base_contato`, `f3base_atribuicao` | `action wp_enqueue_scripts (10)`<br>`filter render_block (10)` |
| `F3Base_Modulo_Llms_Full_Txt`<br>id `llms-full-txt` | `class-f3base-modulo-llms-full-txt.php` | `f3base_llms` | `action template_redirect (0)` |
| `F3Base_Modulo_Llms_Txt_Reserva`<br>id `llms-txt-reserva` | `class-f3base-modulo-llms-txt-reserva.php` | `f3base_llms` | `action template_redirect (0)` |
| `F3Base_Modulo_Meta_Capi`<br>id `meta-capi` | `class-f3base-modulo-meta-capi.php` | `f3base_meta_capi_token`, `f3base_meta_pixel_id` | `action f3base_meta_capi_enviar (10)` |
| `F3Base_Modulo_Noindex_Honrado`<br>id `noindex-honrado` | `class-f3base-modulo-noindex-honrado.php` | nenhuma | `filter wp_robots (20)` |
| `F3Base_Modulo_Redirects`<br>id `redirects` | `class-f3base-modulo-redirects.php` | `f3base_redirects` | `action template_redirect (1)` |
| `F3Base_Modulo_Retencao_Eliminacao`<br>id `retencao-e-eliminacao` | `class-f3base-modulo-retencao-eliminacao.php` | `f3base_retencao_meses`, `f3base_journal_eliminacao` | `action init (20)`<br>`action f3base_retencao_limpeza (10)`<br>`action rest_api_init (10)`<br>`filter wp_privacy_personal_data_exporters (10)`<br>`filter wp_privacy_personal_data_erasers (10)` |
| `F3Base_Modulo_Rota_Origem`<br>id `rota-origem` | `class-f3base-modulo-rota-origem.php` | nenhuma | `action rest_api_init (10)` |
| `F3Base_Modulo_Schema_Extensao`<br>id `schema-extensao` | `class-f3base-modulo-schema-extensao.php` | `f3base_seo_entidade` | `filter wpseo_schema_organization (20)`<br>`filter wpseo_schema_graph (20)` |
| `F3Base_Modulo_Tracking`<br>id `tracking` | `class-f3base-modulo-tracking.php` | `f3base_gtm_container_id`, `f3base_ga4_measurement_id`, `f3base_google_ads`, `f3base_meta_pixel_id`, `f3base_linkedin_partner_id`, `f3base_linkedin_conversion_id` | `action wp_enqueue_scripts (20)` |
| `F3Base_Modulo_Verificacao_Dominio`<br>id `verificacao-dominio` | `class-f3base-modulo-verificacao-dominio.php` | nenhuma | `action wp_head (1)` |
<!-- gerado:fim=plugin-modulos -->

---

## Módulo a módulo

A tabela acima é gerada de disco e traz options e hooks de cada um. O que vem abaixo é o que a
tabela não sabe dizer: a pergunta de negócio, quando o módulo fica inativo, e o que quebra se
alguém mexer nele errado.

### `F3Base_Modulo_Leads_Whatsapp` — Leads por WhatsApp

**O que faz.** Promove a link profundo do WhatsApp o botão de contato que ainda carrega o `href`
do modelo, monta a URL a partir do número gravado, e enfileira o cliente que registra a
interação por beacon antes da navegação e transporta a atribuição.

**Pergunta que responde.** "Como quem visita o site fala com a gente, e quem levou o crédito por
esse contato?"

**Quando fica INATIVO.** Sem número em `f3base_contato`. Nenhum script é enfileirado e nenhum
`href` é reescrito. O filtro `render_block` continua registrado — ele é declarado `sempre` —, e
nele o botão que ainda tem o `href` do modelo **não é publicado**, enquanto um botão com destino
próprio fica na página, intocado.

**Fica DEGRADADO** quando `WP_HTML_Tag_Processor` não existe nesta versão do WordPress: o caminho
sem JavaScript não recebe o link profundo.

**O que quebra.** Reescrever o `href` cegamente desfaz a escolha de quem trocou o destino a cada
render — foi um defeito medido. Suprimir o bloco cegamente apaga qualquer bloco da classe,
inclusive o que tem destino próprio: foi o outro. Os quatro quadrantes (com número ou sem, com
`href` do modelo ou próprio) são bancada em `leads.cta_preserva_destino`.

### `F3Base_Modulo_Endpoint_Leads` — Endpoint de leads

**O que faz.** Rota REST pública e endurecida que recebe o beacon do clique: schema fechado com
recusa de campo desconhecido pelo nome, limites por campo, token efêmero assinado, honeypot,
limite de pedidos por janela e deduplicação atômica por chave única no banco. Grava no Flamingo
quando ele existe, e no tipo de conteúdo privado de contingência quando não existe.

**Pergunta que responde.** "Quem procurou contato, quando, vindo de onde — e sem contar duas
vezes o mesmo clique?"

**Ele é infraestrutura de outros módulos.** `emitir_token()`, `validar_token()`, `origem()`,
`incrementar_janela()`, `reservar()`, `confirmar_reserva()` e `liberar_reserva()` são usados
também pelo módulo de comportamento. Uma segunda implementação de qualquer uma delas seria uma
segunda regra para o mesmo risco, e a segunda é a que fica para trás.

**Nunca fica inativo.** Fica DEGRADADO quando a tentativa mais recente não foi gravada e nenhuma
entrou depois dela; quando a tabela de reservas não tem a coluna de estado desta versão (a
deduplicação e o limite caem para transiente, e transiente faz ler-modificar-gravar, que perde
incremento sob concorrência); e quando o Flamingo está ausente.

**O que quebra.** A reserva nasce PENDENTE, vira FIRME depois da persistência e é APAGADA quando
nada foi gravado. Marcar e gravar em seguida deixa o selo queimado numa escrita que falhou, e a
retentativa recebe "já gravei isto" sobre nada.

### `F3Base_Modulo_Consentimento` — Consentimento

**O que faz.** Aplica a política declarada em `f3base_consentimento`, publica o controle de
revisão no rodapé de toda página, persiste a negativa pelo prazo configurado e religa no
re-aceite. `permite_tags()` é o portão que todo o resto consulta.

**Pergunta que responde.** "O que o site faz antes de o visitante decidir, e por onde ele muda de
ideia depois?"

**Nunca fica inativo.** Fica DEGRADADO quando `f3base_consentimento` nunca foi gravada pelo
implantador (o site opera sobre o padrão embutido, não sobre a política declarada do projeto) e
quando o controle do rodapé está desligado (o titular fica sem instrumento permanente de
revisão).

**O que quebra.** No modo pré-aprovado o script sai com `defer`, fora do caminho crítico, porque
o `default` desse modo é `granted` e ausência de `default` já é `granted` para o fornecedor. No
modo de negativa por padrão ele sai **bloqueante no cabeçalho**: ali a ordem é a garantia, e
chegar depois de uma tag de terceiro seria um primeiro `page_view` sem o `denied`. Trocar o
`defer` pelo bloqueante nos dois modos custa caminho crítico sem ganho; trocar o bloqueante pelo
`defer` no modo de negativa é o defeito. `js.ordem_do_consentimento` mede a ordem de execução, e
não a string do atributo.

### `F3Base_Modulo_Tracking` — Tracking

**O que faz.** Duas metades pelo mesmo portão. A primeira emite as tags de GA4, Google Ads, Meta
e LinkedIn a partir dos IDs gravados. A segunda instrumenta o COMPORTAMENTO do visitante — é o
assunto da seção **A medição de comportamento**, mais abaixo.

**Pergunta que responde.** "As contas que pagam anúncio recebem o que acontece no site, sem
receber duas vezes?"

**O caminho é um só.** `f3base_gtm_container_id` preenchido decide: o site publica o contêiner,
alimenta o `dataLayer` com objetos, e NENHUMA tag direta é emitida. Vazio, o site publica as tags
diretas de cada ID presente. Duas fontes para a mesma conversão é conversão contada em dobro, e
conversão em dobro reescreve o lance do leilão.

**Quando fica INATIVO.** Nenhum slot de medição preenchido **e** o resumo do próprio site
desligado. Repare na conjunção: com os slots vazios e o resumo ligado o módulo continua ATIVO,
porque o coletor de comportamento não depende de fornecedor nenhum.

**Fica DEGRADADO** quando o consentimento foi negado nesta requisição: nenhuma das quatro tags é
carregada. Pixel e Insight Tag não têm modo de consentimento — carregar e "atualizar para negado"
seria carregar assim mesmo —, e por isso a negativa vira ausência.

**O que quebra.** `ids()` é a fonte única dos slots: estado, dependências, aviso de forma e o que
vai para o navegador leem daqui. Duas listas de slots divergiriam no primeiro canal
acrescentado.

### `F3Base_Modulo_Comportamento` — Resumo de comportamento no site

**O que faz.** Recebe o lote selado com os totais agregados e o registro daquela visita, e os
soma numa tabela própria. Duas leituras vivem dela: a pessoa, no menu Medição, e o agente, por
consulta ao banco — sem depender de credencial de fornecedor nenhum. Tem seção própria abaixo.

**Pergunta que responde.** "O site nasce instrumentado; onde eu vejo os dados dessa
instrumentação, sem abrir a conta de ninguém?"

**Quando fica INATIVO.** `f3base_comportamento.ligado` desligado: o navegador não envia nada, a
rota não é registrada e o quadro da tela fica vazio. O envio para a conta de medição, quando
houver, não depende dessa chave.

**Fica DEGRADADO** quando a tabela não está pronta com as colunas desta versão. A rota continua
registrada e responde `503` nomeando o motivo — a perda é visível em vez de silenciosa.

**O que quebra.** A prontidão é medida pelas COLUNAS, nunca por `SHOW TABLES`: tabela antiga
responde à existência e faz o `INSERT` desta versão falhar em silêncio.

### `F3Base_Modulo_Meta_Capi` — Meta, Conversions API

**O que faz.** Envia o evento de lead **de servidor** para a Meta depois da persistência
confirmada, com o MESMO identificador de evento que o navegador manda no Pixel — é ele que
deduplica os dois caminhos. E-mail e telefone saem em resumo criptográfico sobre o valor
normalizado pela regra da Meta; nada de dado pessoal em claro.

**Pergunta que responde.** "As conversões que o navegador perde por bloqueio ou por falha de rede
chegam mesmo assim?"

**Quando fica INATIVO.** Sem token em `f3base_meta_capi_token`. Essa option é SEGREDO DO SITE:
ela não existe no arquivo de configuração do implantador nem no schema dele, nenhum lote a grava,
e a ausência dela ali é a declaração de que ela não viaja no pacote.

**Fica DEGRADADO** com token gravado e `f3base_meta_pixel_id` vazia (o endereço da API é montado
com o identificador do Pixel: sem ele não há destino), e quando a Meta recusou o evento mais
recente e nenhum foi aceito depois dele.

**O que quebra.** Recusa da Meta **nunca** muda o status de um lead: o lead já estava gravado
antes de o envio ser agendado. O evento é agendado COM ARGUMENTO, e por isso a desinstalação usa
`wp_unschedule_hook()` — `wp_next_scheduled()` sem argumento não encontra evento agendado com um,
e o agendamento ficaria órfão na option de cron para sempre.

### `F3Base_Modulo_Verificacao_Dominio` — Verificação de domínio

**O que faz.** Emite no `<head>` a metatag de verificação de posse do domínio de cada token
gravado, para o Google e para a Meta.

**Pergunta que responde.** "Este domínio é comprovadamente nosso nos consoles dos fornecedores?"

**Quando fica INATIVO.** Nenhum token gravado: nenhuma metatag é emitida. Os tokens vêm dos
consoles — passo humano —, e gravá-los faz a tag existir na página seguinte, sem release nova.

**O que quebra.** Valor fora da forma esperada é **preservado e avisado**, nunca apagado. O
pacote não apaga o que alguém gravou.

### `F3Base_Modulo_Rota_Origem` — Rota de origem

**O que faz.** Requisita um caminho do próprio site a partir do servidor e devolve status,
cabeçalhos e corpo carimbados com a fase `origem`.

**Pergunta que responde.** "O que o servidor entrega de verdade neste caminho, medido do lado de
dentro?"

**Nunca fica inativo.** Aceita apenas caminho do próprio `home_url()`, valida o host e não segue
redirecionamento para fora.

**O que quebra.** Aceitar host de fora transforma a rota num proxy aberto — a validação de host é
a rota inteira.

### `F3Base_Modulo_Llms_Txt_Reserva` — Reserva do llms.txt

**O que faz.** Serve `/llms.txt` por rota virtual **quando ela é a responsável pelo endereço**:
arquivo físico na raiz vence, emissor concorrente medido vem depois, e só então esta rota. A
lista junta a seleção curada com a enumeração do conteúdo publicado, conforme o modo declarado, e
exclui o que está em `noindex`.

**Pergunta que responde.** "Um assistente que lê este site consegue citá-lo com precisão, em vez
de resumir a página inicial?"

**Quando fica INATIVO.** `f3base_llms.ligado` desligado: nenhum hook, nenhuma rota, nenhuma
superfície pública.

**Fica DEGRADADO** quando não há arquivo físico, não há emissor concorrente e não há item nenhum
a listar — a rota responderia só com o cabeçalho do site.

**O que quebra.** Ele é registrado em `template_redirect` com prioridade zero para não receber a
barra final de `redirect_canonical`. Subir a prioridade quebra o endereço.

### `F3Base_Modulo_Llms_Full_Txt` — Texto integral em llms-full.txt

**O que faz.** Serve `/llms-full.txt` com o texto integral dos mesmos itens que o `llms.txt`
lista — mesma seleção, mesmas exclusões, mesma precedência de emissor.

**Pergunta que responde.** "O assistente cita o CONTEÚDO, e não só o endereço?"

**Quando fica INATIVO.** Duas condições, cada uma sozinha: `f3base_llms.ligado` desligado, ou
`f3base_llms.full` desligado — que é o padrão. Ele publica uma segunda cópia integral do site em
texto puro: o custo é certo e o ganho é hipótese. Com a chave desligada não há hook, rota nem
superfície pública.

### `F3Base_Modulo_Redirects` — Redirects de slug

**O que faz.** Redireciona slugs antigos de páginas e posts lendo a meta `_f3base_old_slug`,
tratando as variáveis de consulta `pagename` e `name`, e aplica os pares declarados em
`f3base_redirects` antes do `404`.

**Pergunta que responde.** "Um endereço que existia antes da implantação ainda leva a algum
lugar?"

**Nunca fica inativo.** O núcleo do WordPress cobre parte disso, e este módulo cobre o que ele
não cobre.

**O que quebra.** Aplicar depois do `404` já não redireciona nada — a prioridade em
`template_redirect` é o módulo inteiro.

### `F3Base_Modulo_Noindex_Honrado` — Honra de noindex

**O que faz.** Lê o `noindex` gravado nas chaves do plugin de SEO — meta por conteúdo, padrões
por tipo e taxonomia, `noindex` por termo — e o aplica pelo filtro `wp_robots` **mesmo com o
plugin de SEO desativado**.

**Pergunta que responde.** "O que foi marcado para não ser indexado continua fora do índice se
alguém desativar o plugin de SEO?"

**Nunca fica inativo.** Com o plugin de SEO presente ele imprime o `robots` e esta honra fica de
reserva sobre as mesmas chaves — isso é o desenho, e por isso o estado é `ativo` nos dois casos.

**O que quebra.** Este módulo é o **produtor único** do fato "este conteúdo está em noindex". Os
dois módulos de `llms` o consultam e nenhum lê a meta por conta própria. Uma segunda leitura
divergiria na primeira chave acrescentada, e o site publicaria numa lista para leitores
automáticos exatamente o que ele pediu para não ser indexado.

### `F3Base_Modulo_Schema_Extensao` — Extensão de schema

**O que faz.** Acrescenta ao grafo do plugin de SEO os nós de serviço e as propriedades de
entidade declaradas em `f3base_seo_entidade`, pelos filtros do próprio plugin de SEO. Lê o FAQ
dos blocos de detalhes da página.

**Pergunta que responde.** "O buscador entende quem é esta organização e o que ela vende?"

**Fica DEGRADADO** quando o plugin de SEO está ausente: sem grafo para estender, nada é emitido.

**O que quebra.** `sameAs` vazio fica vazio, por desenho. Preencher com endereço inventado é pior
que não preencher.

### `F3Base_Modulo_Retencao_Eliminacao` — Retenção e eliminação

**O que faz.** Três coisas que compartilham o mesmo assunto: limpa registros de lead pelo prazo
declarado em `f3base_retencao_meses`, medindo o próprio atraso e se recuperando no carregamento
seguinte; registra o exportador e o eliminador de dados pessoais do núcleo; e expõe a rota de
eliminação com journal.

**Pergunta que responde.** "O que o site guarda, por quanto tempo, e como se apaga a pedido do
titular sem perder o registro de que se apagou?"

**Nunca fica inativo.** Fica DEGRADADO quando o evento de limpeza está sem agendamento e quando a
última execução saiu com atraso acima da tolerância declarada.

**O que quebra.** O journal separa **limpeza operacional reversível** de **eliminação
irreversível a pedido do titular**, e guarda identificador, contagem, carimbo, operador e regime
— **nunca o conteúdo eliminado**. Apagar sem journal é perda sem registro.

### `F3Base_Modulo_Cabecalhos` — Cabeçalhos de resposta

**O que faz.** Emite no front-end os cabeçalhos de segurança declarados em `f3base_cabecalhos`,
cada um com o valor gravado.

**Pergunta que responde.** "O navegador está sendo instruído a proteger quem visita?"

**Fica DEGRADADO** quando o COOP gravado não é o que o botão de contato precisa: o valor gravado é
o que sai, e o módulo NOMEIA a consequência — o botão abre a conversa em janela nova, e fora
daquele valor o navegador corta a relação com ela. Também degrada com HSTS ligado sem HTTPS nesta
requisição.

**O que quebra.** O cabeçalho de `Referrer-Policy` é o caso em que um `avisos()` existe: há valor
que apaga a atribuição dos canais pagos. Isso funciona exatamente como foi pedido **e** custa
alguma coisa em outro lugar — é aviso, não estado.

### `F3Base_Modulo_Cadencia_Relatorio` — Cadência do modo somente-relatório

**O que faz.** Escuta o evento `f3base_cadencia_relatorio` que o implantador agenda, registra as
recorrências quinzenal e mensal que o núcleo do WordPress não tem, executa a releitura das
options gerenciadas e dos módulos, e registra última execução, próxima, duração, resultado, erro
e atraso. Conta também os ajustes em option gerenciada e dispara ao alcançar o número declarado.

**Pergunta que responde.** "O site continua igual ao que foi entregue, e alguém mexeu em alguma
coisa desde então?"

**Quando fica INATIVO.** A configuração declara periodicidade `nenhuma` **e** nenhum gatilho por
número de ajustes: não há evento a escutar nem contador a manter.

**Fica DEGRADADO** quando a última execução terminou em erro, quando o evento está sem
agendamento, quando a recorrência agendada não é a declarada (quem agendou não conhecia a
recorrência e degradou para a mais próxima) e quando o atraso passa da tolerância.

**O que quebra.** O contador de ajustes escuta `updated_option`, `added_option` e
`deleted_option`. Ele usa a MESMA função de equivalência do gravador único
(`F3Base_Options::equivalente()`) — duas implementações fariam a releitura acusar divergência
onde a gravação tinha conferido, e vice-versa.

---

## As options

`includes/class-f3base-options.php` é o **gravador único**. Regra dura do contrato: nenhuma
chamada direta a `update_option`, `update_site_option` ou `delete_option` fora dessa classe. Todo
módulo, a tela e o `uninstall.php` passam por ali.

Toda escrita faz **leitura de volta**: o valor é sanitizado, gravado, relido pelo mesmo
sanitizador e comparado. `gravar()` devolve `ok`, `lido` e `motivo` — e o motivo distingue
"divergiu da gravação" de "foi normalizado pela sanitização antes de gravar". A **procedência** de
cada chave (implantador, edição manual, padrão embutido) e o carimbo da última escrita ficam em
`f3base_proveniencia`; `f3base_operaveis`, quando presente, RESTRINGE o que a tela abre — o
catálogo é o teto e essa lista nunca abre o que o catálogo declarou estrutural.

**Ler passa pelo sanitizador.** Chave ausente ou valor corrompido não vira aviso no consumidor: a
leitura devolve forma. Chave desconhecida dentro de um grupo é **preservada**, e é por isso que o
que um agente gravar por um caminho lateral não é apagado pela primeira gravação da tela.

<!-- gerado:inicio=plugin-options -->
| Option | Seção da tela | Campo | Operável | Sub-campos | Sanitizador |
|---|---|---|---|---|---|
| `f3base_contato` | contato | grupo | sim | 2 | `sanitiza_contato` |
| `f3base_ga4_measurement_id` | medicao | texto | sim | — | `sanitiza_id_de_tag` |
| `f3base_gtm_container_id` | medicao | texto | sim | — | `sanitiza_id_de_tag` |
| `f3base_google_ads` | medicao | grupo | sim | 2 | `sanitiza_google_ads` |
| `f3base_meta_pixel_id` | medicao | texto | sim | — | `sanitiza_id_de_tag` |
| `f3base_meta_capi_token` | medicao | texto | sim | — | `sanitiza_segredo_opaco` |
| `f3base_linkedin_partner_id` | medicao | texto | sim | — | `sanitiza_partner_id` |
| `f3base_linkedin_conversion_id` | medicao | texto | sim | — | `sanitiza_partner_id` |
| `f3base_atribuicao` | medicao | grupo | sim | 2 | `sanitiza_atribuicao` |
| `f3base_verificacao_google` | medicao | texto | sim | — | `sanitiza_token_de_verificacao` |
| `f3base_verificacao_meta` | medicao | texto | sim | — | `sanitiza_token_de_verificacao` |
| `f3base_consentimento` | consentimento | grupo | sim | 4 | `sanitiza_consentimento` |
| `f3base_retencao_meses` | privacidade | inteiro | sim | — | `sanitiza_retencao_meses` |
| `f3base_comportamento` | privacidade | grupo | sim | 4 | `sanitiza_comportamento` |
| `f3base_origem_confiavel` | privacidade | grupo | sim | 2 | `sanitiza_origem_confiavel` |
| `f3base_llms` | privacidade | grupo | sim | 7 | `sanitiza_llms` |
| `f3base_redirects` | — | grupo | não | — | `sanitiza_redirects` |
| `f3base_seo_entidade` | — | grupo | não | — | `sanitiza_seo_entidade` |
| `f3base_cabecalhos` | — | grupo | não | — | `sanitiza_cabecalhos` |
| `f3base_nav_id` | — | inteiro | não | — | `sanitiza_id_post` |
| `f3base_mcp_files_audit` | — | grupo | não | — | `sanitiza_lista_generica` |
| `f3base_atividade` | — | grupo | não | — | `sanitiza_atividade` |
| `f3base_journal_eliminacao` | — | grupo | não | — | `sanitiza_journal` |
| `f3base_cadencia` | — | grupo | não | — | `sanitiza_cadencia` |
| `f3base_cadencia_estado` | — | grupo | não | — | `sanitiza_cadencia_estado` |
| `f3base_endpoint_segredo` | — | segredo | não | — | `sanitiza_segredo` |
<!-- gerado:fim=plugin-options -->

### O que cada uma é, e o que acontece com ela vazia

| Option | O que é | Forma esperada | Quem grava | Vazia |
|---|---|---|---|---|
| `f3base_contato` | Para onde vai quem clica no botão de contato, e com que mensagem a conversa começa | grupo: número em formato internacional só com dígitos, mensagem livre | implantador; tela; canal | O botão do modelo **não é publicado** em página nenhuma. O site continua no ar, sem esse caminho de contato |
| `f3base_ga4_measurement_id` | Fluxo de dados da propriedade do Google Analytics | identificador do fornecedor | implantador; tela; canal | Nada chega ao Google Analytics. O resumo próprio do site continua |
| `f3base_gtm_container_id` | Contêiner do Gerenciador de Tags | identificador do fornecedor | implantador; tela; canal | O site publica as tags diretas de cada ID preenchido. Preenchida, ela é o **único** caminho e desliga toda tag direta |
| `f3base_google_ads` | A conta e a ação de conversão que recebem o clique | grupo: identificador da conta e rótulo da ação | implantador; tela; canal | Nenhuma conversão vai ao Google Ads. **Só uma das metades preenchida também não envia nada**, e sai um aviso |
| `f3base_meta_pixel_id` | Pixel de Facebook e Instagram | só dígitos | implantador; tela; canal | Nenhum código da Meta existe na página |
| `f3base_meta_capi_token` | Credencial do envio de servidor | opaca | **só** tela ou canal — nunca o arquivo de configuração | Existe apenas o envio pelo navegador, e o que ele perder está perdido |
| `f3base_linkedin_partner_id` | Conta de anúncios do LinkedIn | só dígitos | implantador; tela; canal | Nenhum código do LinkedIn existe na página |
| `f3base_linkedin_conversion_id` | Conversão do LinkedIn no clique do botão | só dígitos | implantador; tela; canal | O identificador de parceiro sozinho registra apenas visitas |
| `f3base_atribuicao` | Qual campanha leva o crédito, e por quanto tempo | grupo: modelo do vocabulário e prazo em dias | implantador; tela; canal | Cai no padrão embutido: primeiro toque, com o prazo padrão |
| `f3base_verificacao_google` | Token de posse do domínio no Search Console | token do console | implantador; tela; canal | Nenhuma metatag é publicada; a verificação por DNS dispensa este campo |
| `f3base_verificacao_meta` | Token de posse do domínio no Gerenciador de Negócios | token do console | implantador; tela; canal | Nenhuma metatag é publicada |
| `f3base_consentimento` | O que vale antes de o visitante decidir, e por onde ele muda de ideia | grupo: política, controle no rodapé, aviso de primeira visita, prazo | implantador; tela; canal | O módulo fica DEGRADADO e o site opera sobre o padrão embutido, não sobre a política declarada do projeto |
| `f3base_retencao_meses` | Por quanto tempo os registros de contato ficam no site | inteiro em meses | implantador; tela; canal | O sanitizador eleva ao mínimo declarado. É o prazo que a política de privacidade promete |
| `f3base_comportamento` | O resumo que o site guarda por conta própria | grupo: liga/desliga, prazo do resumo, prazo do registro, período do painel | implantador; tela; canal | Cai no padrão embutido, que é **ligado** |
| `f3base_origem_confiavel` | Como o site descobre o endereço do visitante atrás de CDN | grupo: nome do cabeçalho e número de saltos | implantador; tela; canal | Posição segura: conta pelo endereço da conexão. **Preencher com o nome errado é pior que deixar vazio** — o visitante passaria a escolher em que balde ele conta |
| `f3base_llms` | O índice curto que apresenta o site a leitores automáticos | grupo: liga/desliga, textos, modo, tipos, texto integral, indexável | implantador; tela; canal | Cai no padrão embutido: ligado, texto integral desligado |
| `f3base_redirects` | Pares origem/destino aplicados antes do `404` | grupo de pares de caminho | implantador | Nenhum par declarado; o redirecionamento por slug antigo continua |
| `f3base_seo_entidade` | Propriedades de entidade e serviços para estender o grafo de SEO | grupo | implantador | Nada é acrescentado ao grafo. Vazio fica vazio, por desenho |
| `f3base_cabecalhos` | Cabeçalhos de segurança emitidos no front-end | grupo de vocabulário fechado por cabeçalho | implantador | Cai no padrão embutido, com HSTS desligado |
| `f3base_nav_id` | O post de navegação gerenciado | inteiro | implantador | Estrutural: quebrar o vínculo derruba o menu do topo |
| `f3base_mcp_files_audit` | Registro de escritas do canal de manutenção | grupo | complemento do canal | Leitura apenas; vazia significa nenhuma escrita registrada |
| `f3base_atividade` | Carimbos do que cada módulo fez por último | grupo | os próprios módulos | Estado de execução, não configuração. Vazia significa "nada aconteceu ainda", e a tela diz isso |
| `f3base_journal_eliminacao` | Identificador, contagem, carimbo, operador e regime de cada eliminação | grupo | o módulo de retenção | Nunca guarda o conteúdo eliminado. Vazia significa nenhuma eliminação |
| `f3base_cadencia` | Periodicidade, gatilho por ajustes, mecanismo e nome do hook | grupo | implantador | O módulo de cadência fica INATIVO |
| `f3base_cadencia_estado` | Contador de ajustes e carimbo previsto da próxima execução | grupo | o módulo de cadência | Estado de execução. Vazia recomeça a contagem |
| `f3base_endpoint_segredo` | Chave de assinatura do token efêmero do endpoint | opaca | **nasce dentro do plugin**, na ativação; nunca é exibida | Gerada na ativação. Declarada como segredo do site para que nunca possa ser declarada de fora |

Duas options ficam de fora do catálogo porque são **registro sobre o catálogo**, e não
configuração: `f3base_proveniencia` (origem e carimbo de cada escrita) e `f3base_operaveis` (o
que a tela abre). Elas são gravadas pelo mesmo gravador único.

**As duas ÂNCORAS de segredo** — `f3base_meta_capi_token` e `f3base_endpoint_segredo` — estão
declaradas em `F3Base_Options::segredos_do_site()`, e a declaração tem duas invariantes que um
detector cobra a cada rodada: o nome não aparece no arquivo de configuração do implantador nem no
schema dele, e nenhum lote do implantador as grava.

---

## As duas tabelas do banco

<!-- gerado:inicio=plugin-tabelas -->
**`<prefixo-do-wpdb>f3base_comportamento`**

| Coluna | Definição |
|---|---|
| `chave` | `char(64) NOT NULL` |
| `dia` | `char(10) NOT NULL` |
| `caminho` | `varchar(190) NOT NULL` |
| `metrica` | `varchar(64) NOT NULL` |
| `detalhe` | `varchar(60) NOT NULL DEFAULT ''` |
| `contagem` | `bigint(20) unsigned NOT NULL DEFAULT 0` |
| `soma` | `double NOT NULL DEFAULT 0` |
| `atualizado_em` | `bigint(20) unsigned NOT NULL DEFAULT 0` |
| _índice_ | `PRIMARY KEY (chave)` |
| _índice_ | `KEY dia (dia)` |
| _índice_ | `KEY dia_metrica (dia,metrica)` |

**`<prefixo-do-wpdb>f3base_eventos`**

| Coluna | Definição |
|---|---|
| `id` | `bigint(20) unsigned NOT NULL AUTO_INCREMENT` |
| `visitante` | `char(32) NOT NULL` |
| `sessao` | `char(32) NOT NULL` |
| `dia` | `char(10) NOT NULL` |
| `caminho` | `varchar(190) NOT NULL` |
| `metrica` | `varchar(64) NOT NULL` |
| `detalhe` | `varchar(60) NOT NULL DEFAULT ''` |
| `valor` | `double NOT NULL DEFAULT 0` |
| `ocorrencia` | `int(10) unsigned NOT NULL DEFAULT 1` |
| `ms` | `bigint(20) unsigned NOT NULL DEFAULT 0` |
| `criado_em` | `bigint(20) unsigned NOT NULL DEFAULT 0` |
| _índice_ | `PRIMARY KEY (id)` |
| _índice_ | `KEY dia (dia)` |
| _índice_ | `KEY dia_caminho (dia,caminho)` |
| _índice_ | `KEY sessao (sessao)` |
| _índice_ | `KEY visitante (visitante)` |
<!-- gerado:fim=plugin-tabelas -->

O prefixo real é o do `wpdb` da instalação. Uma terceira tabela, `f3base_leads_dedup`, pertence ao
endpoint de leads e guarda a reserva de deduplicação e o balde do limite de pedidos; ela não tem
constante de colunas e por isso não aparece no bloco gerado acima.

### O que cada uma responde

`f3base_comportamento` é o **agregado**. Uma linha por dia, caminho, evento e detalhe, com
contagem e soma. Ele não identifica ninguém. Responde: quantas visitas viram este bloco, quantas
passaram deste marco, para onde o tráfego saiu, quanto o carregamento demorou.

`f3base_eventos` é o **registro**. Uma linha por acontecimento, com apelido sorteado do visitante,
identificador da visita, número da ocorrência e carimbo em milissegundos desde o carregamento.
Responde: quanto tempo a pessoa levou para descer até aqui, ela voltou e leu de novo, quantas
pessoas diferentes passaram por esta página. Por guardar isso, ele é **dado pessoal
pseudonimizado**, ainda que o apelido não diga quem a pessoa é.

### Por que o agregado NÃO é derivado do registro

Duas razões, e as duas são de consequência.

**As retenções são diferentes, e essa é a razão maior.** O registro tem prazo CURTO
(`f3base_comportamento.retencao_eventos_dias`); o agregado pode durar
(`f3base_comportamento.retencao_dias`), e nunca menos. Derivar o agregado do registro faria a
série histórica do painel evaporar junto com o log na primeira execução da retenção — o operador
perderia a comparação de trimestre para proteger uma privacidade que o agregado já protegia
sozinho.

**A leitura do painel é barata e precisa continuar sendo.** Recalcular totais varrendo o registro
a cada abertura de tela é aceitável com cem linhas e inaceitável com um milhão — e o site que
mais precisa da tela é justamente o que tem tráfego.

O preço é uma escrita a mais por requisição, na mesma chamada, sobre o mesmo corpo já validado.
É um preço declarado, e é menor que os dois riscos acima.

**A ordem importa:** o agregado é somado ANTES do registro. Se o banco recusar a segunda escrita,
o número do painel continua certo e o que se perde é o detalhe — a perda cai no lado menos grave.

### Como o agregado soma

`somar()` faz `INSERT … ON DUPLICATE KEY UPDATE` numa instrução só, e a chave primária é um
resumo criptográfico de `dia | caminho | evento | detalhe`. Ler, somar e gravar em três passos
perderia incrementos sob concorrência exatamente no horário de pico, que é quando o número
importa.

### Consultas típicas

Trocar `wp_` pelo prefixo real da instalação.

Os totais dos últimos dias, por página e por evento — é o que o painel mostra:

```sql
SELECT caminho, metrica, detalhe, SUM(contagem) AS total, SUM(soma) AS acumulado
FROM wp_f3base_comportamento
WHERE dia >= DATE_FORMAT(NOW() - INTERVAL 28 DAY, '%Y-%m-%d')
GROUP BY caminho, metrica, detalhe
ORDER BY total DESC;
```

Quanto o site DESCARTOU, que é lido em separado e nunca entra no total:

```sql
SELECT dia, caminho, SUM(contagem) AS cortadas
FROM wp_f3base_comportamento
WHERE metrica = 'f3base_cortadas'
GROUP BY dia, caminho
ORDER BY dia DESC;
```

Pessoas diferentes por dia — só o registro responde isso:

```sql
SELECT dia, COUNT(DISTINCT visitante) AS visitantes
FROM wp_f3base_eventos
GROUP BY dia
ORDER BY dia DESC;
```

A releitura de um bloco dentro de uma visita, que é a pergunta que o registro existe para
responder:

```sql
SELECT caminho, detalhe, ocorrencia, ms, criado_em
FROM wp_f3base_eventos
WHERE metrica = 'f3base_secao_vista' AND sessao = ?
ORDER BY criado_em, id;
```

O tempo até cada marco de rolagem, por visita:

```sql
SELECT sessao, caminho, detalhe, MIN(ms) AS ms_ate_o_marco
FROM wp_f3base_eventos
WHERE metrica = 'f3base_rolagem'
GROUP BY sessao, caminho, detalhe
ORDER BY sessao, ms_ate_o_marco;
```

Desde quando este site está coletando — a resposta honesta é o dia mais antigo que a tabela
guarda, e não a data em que a option foi ligada:

```sql
SELECT MIN(dia) FROM wp_f3base_comportamento;
```

---

## As rotas REST

<!-- gerado:inicio=plugin-rotas -->
| Rota | Método | Autenticação | Onde é registrada |
|---|---|---|---|
| `/wp-json/f3base/v1/comportamento` | POST | `__return_true` | `includes/class-f3base-modulo-comportamento.php` |
| `/wp-json/f3base/v1/comportamento/esquecer` | POST | `__return_true` | `includes/class-f3base-modulo-comportamento.php` |
| `/wp-json/f3base/v1/eliminacao` | POST | `pode_eliminar()` | `includes/class-f3base-modulo-retencao-eliminacao.php` |
| `/wp-json/f3base/v1/lead` | POST | `__return_true` | `includes/class-f3base-modulo-endpoint-leads.php` |
| `/wp-json/f3base/v1/origem` | GET | `pode_ler()` | `includes/class-f3base-modulo-rota-origem.php` |
| `/wp-json/f3base/v1/relatorio` | GET | `current_user_can( manage_options )` | `includes/class-f3base-plugin.php` |
<!-- gerado:fim=plugin-rotas -->

### Como cada uma autentica

`/relatorio` e as rotas de eliminação e de origem exigem capacidade de administração — a de
eliminação e a de origem checam também um nonce próprio. As três públicas — lead, comportamento e
esquecer — validam um **token efêmero assinado**, e não cookie: `credentials: 'omit'` no cliente,
porque mandar o cookie de sessão do WordPress numa requisição de medição o entregaria também ao
CDN que estiver na frente, sem servir para nada aqui.

O token é `<expiração>.<assinatura>`, assinado com `f3base_endpoint_segredo`. Ele é recusado
quando a expiração não é numérica, quando já passou, quando está longe demais no futuro (um token
forjado com validade infinita) e quando a assinatura não confere — a comparação é feita em tempo
constante. O prazo padrão é `12 * HOUR_IN_SECONDS`, com piso e teto aplicados sobre o filtro que
o ajusta.

### Os limites, e o que a recusa devolve

| Limite | Valor | Onde |
|---|---|---|
| Tamanho do corpo aceito | `8192` bytes | rota de comportamento |
| Linhas de registro por corpo | `120` | rota de comportamento |
| Linhas que uma VISITA inteira pode gravar | `200` | orçamento da visita, gasto ao longo das páginas |
| Distância máxima entre o carregamento e o evento | `86400000` ms | rota de comportamento |
| Pedidos por janela, por origem | `10 * MINUTE_IN_SECONDS` de janela | rotas de lead e de comportamento |

O balde de pedidos conta pela origem que `f3base_origem_confiavel` declarar; sem declaração, ele
conta pelo endereço da conexão. Cabeçalho aceito sem declaração é o próprio visitante escolhendo
o balde em que quer contar.

**Toda recusa é NOMEADA.** O corpo traz `ok`, `registrado`, um `codigo` estável e um `motivo` em
português. Os códigos e o que cada um significa:

| Código HTTP | `codigo` | Quando |
|---|---|---|
| `400` | `f3base_campo_desconhecido` | Campo fora do schema fechado. O nome do campo recusado vem na resposta |
| `400` | `f3base_caminho_invalido` | O caminho não é deste site, ou traz query ou fragmento |
| `400` | `f3base_pseudonimo_invalido` | Apelido, visita ou selo fora da forma `[a-f0-9]{32}` |
| `403` | `f3base_token_invalido` | Token ausente, expirado ou com assinatura inválida |
| `409` | `f3base_resumo_desligado` | `f3base_comportamento.ligado` está desligado neste site |
| `413` | `f3base_corpo_grande` | Corpo acima do limite declarado. A resposta traz o `limite` |
| `429` | `f3base_rate_limit` | Limite de pedidos por janela excedido para esta origem |
| `503` | `f3base_armazenamento_indisponivel` | A tabela não está pronta com as colunas desta versão |
| `503` | `f3base_gravacao_indisponivel` | O banco recusou a escrita. Nada foi guardado, e o navegador reenvia o mesmo lote |
| `200` | `f3base_lote_repetido` | Este lote já foi gravado para esta visita. **Repetição responde `2xx` de propósito** |

Duas escolhas nessa tabela são decisões, e não descuido:

**Repetição responde `2xx`.** Para quem envia, "já tenho isto" e "acabei de gravar" precisam ser a
mesma resposta boa: qualquer outro código faria o cliente reter o lote e reenviá-lo para sempre,
exatamente o lote que o servidor já tem.

**Zero linha apagada na rota de esquecer não é erro.** Um apelido sem registro nenhum é o caso
comum de quem nunca foi medido, e responder `404` diria ao pedinte se aquele apelido existe no
banco — que é informação sobre outra pessoa quando o apelido é chutado.

---

## A medição de comportamento

Este é o subsistema mais caro do plugin e o que mais consumiu correção. Cada peça abaixo existe
porque um defeito real foi medido.

### A declaração única, e por que nome de evento não vive no JavaScript

`dados/eventos-comportamento.tsv` declara, num lugar só: nome do evento, parâmetros **na ordem em
que o coletor os entrega**, teto por página, gatilho, limiar, a pergunta que o evento responde em
português comum, a frase que a tabela bruta imprime, e a natureza (`uso` ou `tecnica`).

<!-- gerado:inicio=plugin-eventos -->
| Evento | Gatilho | Parâmetros | Teto por página | Limiar | Natureza |
|---|---|---|---|---|---|
| `f3base_rolagem` | `rolagem` | `f3base_marco` | 4 | `marcos=25,50,75,90;travessias_por_sessao=20;histerese_pp=5` | uso |
| `f3base_secao_vista` | `interseccao` | `f3base_secao` | 12 | `visivel=0.5;saida=0.2;travessias_por_sessao=20` | uso |
| `f3base_link_externo` | `clique-externo` | `f3base_dominio` | 10 | `—` | uso |
| `f3base_friccao` | `clique-repetido` | `f3base_cliques` | 3 | `cliques=4;janela_ms=1200;raio_px=24;alvo=interativo` | uso |
| `f3base_erro_js` | `erro` | `f3base_arquivo,f3base_linha` | 3 | `origem=site` | tecnica |
| `f3base_web_vital` | `desempenho` | `f3base_vital,f3base_valor` | 4 | `vitais=LCP,CLS,INP,TTFB;duracao_minima_ms=16` | tecnica |
| `f3base_pagina_vista` | `pagina` | nenhum | 1 | `inatividade_min=30` | uso |
<!-- gerado:fim=plugin-eventos -->

**O cliente NÃO conhece nome de evento.** Ele manda o GATILHO, e quem resolve o nome é o
servidor, contra esta declaração. Gatilho que não está lá não vira linha. É isso que torna o nome
renomeável num lugar só, sem tocar em uma linha de JavaScript.

A razão é a série histórica: quem lê é um agente comparando períodos, e para ele **nome que muda
entre releases é medição que sumiu sem erro nenhum** — o relatório do mês seguinte fica vazio e
ninguém sabe se o site parou de medir ou se os visitantes pararam de rolar.
`tracking.eventos_de_comportamento_declarados` reprova qualquer literal de nome declarado dentro
do JavaScript.

Nenhum número de limiar vive no cliente pela mesma razão: os marcos de rolagem, os cliques da
fricção, a janela e o raio, as faixas do observador — todos saem daqui, publicados ao navegador
por `F3Base_Modulo_Tracking::comportamento()`.

**A ORDEM DOS PARÂMETROS É CARREGADA.** O coletor entrega os valores POSICIONALMENTE e o servidor
os casa com a coluna, na ordem em que ela está escrita. Trocar a ordem de dois parâmetros troca o
significado dos dois no relatório.

**O que nunca entra em parâmetro:** texto digitado, seletor com valor, URL com query, mensagem de
erro. Quem varre o payload é `js.comportamento_instrumentado`.

### Os coletores

Seis coletores, todos em `assets/f3base-tracking.js`, todos instalados pelo mesmo portão de
consentimento e só quando há destino:

- **rolagem** — marcos de profundidade sobre a faixa ROLÁVEL do documento (`altura - visível`), e
  a altura é RELIDA a cada medição: a imagem que carrega depois, o acordeão que abre e o bloco que
  expande entram na conta na medição seguinte. Página que cabe na tela conta como lida inteira,
  mas só depois de a página TERMINAR de carregar — medindo cedo, uma página longa cujas imagens
  ainda não tinham altura emitia os quatro marcos de uma vez e os queimava.
- **interseccao** — seção vista, pelo NOME que o markup declara. Assunto da seção **Como marcar
  uma seção para ser medida**.
- **clique-externo** — só o HOST de destino, nunca a URL. Caminho e query são onde mora o
  identificador.
- **clique-repetido** — fricção: cliques repetidos no mesmo ponto, dentro de uma janela, em alvo
  interativo. O limiar não é dois nem três porque duplo clique é gesto normal de sistema e triplo
  clique é o gesto normal de selecionar um parágrafo.
- **erro** — erro de JavaScript **do próprio site**. A origem é o PORTÃO, não um parâmetro: erro
  de terceiro e de extensão do visitante ficam de fora porque nenhuma release nossa os conserta. A
  MENSAGEM não entra, porque ela carrega o valor interpolado que produziu o erro, e esse valor pode
  ser o dado do titular.
- **desempenho** — medidas de carregamento por observador nativo, sem biblioteca externa. O valor
  sai CRU e sem classificação: os cortes de bom/ruim são do fornecedor e mudam por calendário.
  `dados/vitais.tsv` guarda a explicação e o limiar que a tela mostra ao lado.

Mais um, que é o denominador: **pagina** — o contador de carregamentos. Sem ele não há proporção:
"duas pessoas chegaram ao fim" pode ser duas de duas ou duas de duzentas, e as duas leituras levam
a decisões opostas sobre o tamanho da página.

### O contador de travessias é da VISITA; o estado armado é do CARREGAMENTO

**O defeito medido.** Os contadores eram variáveis do CARREGAMENTO: nasciam zerados a cada página
e morriam na navegação. O rearme DENTRO do carregamento funcionava, mas quem passava por um
bloco, ia para outra página e voltava era registrado como se fosse a primeira vez, sempre — dois
carregamentos da mesma página na mesma visita produziam ocorrência `1` nos dois. E o limiar se
chama `travessias_por_sessao`: o nome prometia visita e a implementação entregava carregamento.

**O contador atravessa a navegação.** Ele mora no registro da visita, no armazenamento local, e é
chaveado por `caminho | gatilho | detalhe`. **O caminho está na chave** porque o mesmo nome de
bloco em duas páginas são duas seções diferentes: somá-las responderia uma pergunta que ninguém
fez e esconderia as duas.

**O estado armado NÃO atravessa.** `dentro` (marcos) e `dentroDaVista` (seções) continuam sendo do
carregamento, e isso é decisão: uma página nova começa com nada em vista e nada rolado. Persistir
"já estou dentro" faria a primeira entrada do carregamento seguinte ser engolida, e quem trocou de
página perderia justamente a passagem que acabou de fazer.

**Sem armazenamento, tudo degrada para medição parcial.** Navegador com o armazenamento local
bloqueado não tem apelido nem visita, não produz registro nenhum e continua somando o agregado.
Inventar um apelido de memória que muda a cada página produziria uma contagem de visitantes
inflada, que é pior que não contar.

### A linha de entrada e a linha de saída da seção

O observador é armado com três faixas: zero, a linha de SAÍDA e a linha de ENTRADA, ambas
declaradas na mesma célula de limiar do TSV. A seção ENTRA quando a razão alcança a linha de
entrada e só REARMA quando ela cai abaixo da linha de saída. Entre as duas nada muda de estado —
é banda, e não indecisão.

**O defeito que isso conserta.** Antes, a entrada usava o limiar declarado e a saída usava
`isIntersecting`, que a especificação define como o índice de faixa: com o zero na lista, qualquer
sobreposição o mantém verdadeiro, e a saída vira a razão ZERO. A assimetria fazia o bloco ser
gravado uma vez só por carregamento — medido em produção: oitenta linhas, todas com ocorrência
`1`, nenhuma reentrada.

**Declaração incoerente cai no comportamento simétrico.** Linha de saída ausente, não numérica,
negativa ou maior/igual à de entrada faz a saída virar a própria entrada — exatamente o
comportamento anterior a esta linha. A banda invertida não é uma banda mais larga: é o oposto de
uma banda, e ela faz a seção contar em laço enquanto o visitante não mexer em nada.

### A histerese do marco de rolagem

Fronteira sem banda transforma TREMOR em leitura. Rearmando na própria linha, um pixel de
oscilação — o dedo que segura a página, o cabeçalho que recolhe, a imagem que entra e empurra a
altura do documento — fabrica uma travessia que ninguém fez, e ela chega ao relatório com cara de
releitura.

O marco só rearma **abaixo de** `marco - histerese_pp`, nunca na própria linha. O número mora no
TSV, ao lado dos marcos que ele protege: um limiar escrito no JavaScript é um número que ninguém
revisa junto com a declaração que ele contradiz.

O que a banda **descarta** é o movimento abaixo dela, que é o tremor. O que ela **custa** é a
reentrada curta e legítima que não chega a cruzá-la — e esse é o lado certo de errar: ocorrência
perdida é um número menor; ocorrência fabricada é um número que descreve um comportamento que não
houve.

O **agregado continua contando uma vez por carregamento**. Somar releitura no total transformaria
uma pessoa inquieta em audiência que não existe. As duas leituras convivem: o total responde
"quantas visitas viram este bloco" e o registro responde "quantas vezes cada uma o viu".

### O envio: lote, confirmação de entrega e fila pendente durável

**Enviar-e-limpar, não enviar-uma-vez.** O evento de ocultamento não dispara só quando a pessoa
sai da página: dispara quando a aba perde o foco. No primeiro desses instantes o envio partia com
o que existia, uma trava fechava, e a página ficava SURDA pelo resto da visita — tudo o que o
visitante rolasse depois morria na memória. Numa visita real, cada carregamento registrou só o
primeiro segundo e nenhuma rolagem, nunca. Hoje a trava é apenas guarda de reentrância, e o lote
resolve a contagem dobrada por construção: cada selamento leva só o que foi acumulado desde o
anterior, e o acumulado é esvaziado ao selar.

**Confirmação de ENTREGA, não de enfileiramento.** O despacho usa `fetch` com `keepalive` quando
o navegador o tem — é a única combinação que dá as duas coisas: a requisição continua depois de a
página ser descarregada, e a resposta volta. O discriminante é `keepalive`, e não `fetch`: um
navegador com `fetch` e sem `keepalive` cancelaria a requisição na saída, que é pior que o
beacon. Sem essa combinação, cai para `sendBeacon` — e ali o `true` diz que o navegador ACEITOU a
carga, não que ela chegou. Essa perda residual está declarada, e é estritamente menor que a de
antes: o lote pendente já foi GRAVADO antes do despacho.

**A fila de pendentes é durável.** Cada entrada é um lote SELADO que já saiu do acumulado e ainda
não teve entrega confirmada, gravado no registro da visita e lido de volta pelo carregamento
seguinte da mesma visita. **A ordem é a do selamento, e o despacho a respeita: o pendente sai
antes do novo.** É o que faz a sequência de ocorrências fechar sem buraco mesmo quando um
carregamento inteiro morre no meio.

**A fila não tem teto próprio.** Toda linha que entra num lote já gastou o orçamento da visita.
Um segundo teto seria um número para revisar onde já há um, e divergiria do primeiro na primeira
vez que alguém mexesse num só.

**Recusa permanente x transitória.** `400` e `413` nunca mudam por esperar: o lote é esquecido e
as linhas dele viram cortadas nomeadas. Tudo o mais é transitório e o lote FICA, com o mesmo
selo: rede caindo, `403` de token expirado (o carregamento seguinte leva um fresco), `409` de
medição desligada, `429` de balde cheio, `503` de migração em curso. Reter sem critério produz o
pendente eterno, que bloqueia atrás dele tudo o que veio depois — a perda voltando pela porta dos
fundos, agora com atraso.

**Um lote é partido no SELAMENTO, nunca no despacho.** Partir um lote já selado mudaria o conteúdo
sob o mesmo selo. Os totais e as cortadas viajam só no primeiro pedaço: repeti-los somaria o mesmo
total tantas vezes quantas o registro precisou ser partido. Uma linha sozinha que não cabe vira
cortada nomeada — sem essa saída o laço não avançaria e o selamento repetiria para sempre.

### O selo do lote e a idempotência no servidor

Confirmar a entrega implica reenviar, e reenviar implica poder contar duas vezes: uma resposta
perdida no caminho de volta faria o mesmo lote chegar de novo.

O lote leva um **selo sorteado** pelo navegador, na mesma forma do apelido — `[a-f0-9]{32}` —, e
o que identifica o lote são a visita E o selo. No servidor, a reserva é a MESMA do lead:
**inserção atômica na chave única, confirmação depois da persistência, compensação quando nada foi
gravado**. Ela nasce PENDENTE, vira FIRME só depois de a linha estar no banco, e é APAGADA quando
nada foi gravado — marcar e gravar em seguida deixaria o selo queimado sobre uma escrita que
falhou, e a retentativa receberia "já gravei isto" sobre nada.

O prefixo `f3base-comportamento-lote|` separa este espaço de chaves do da deduplicação de leads,
que usa a mesma tabela e o mesmo mecanismo: sem ele, um selo de lote e uma correlação de lead com
o mesmo texto seriam a mesma linha, e um recusaria o outro.

**Selo vazio não reserva nada.** Sem gerador criptográfico o navegador não tem selo — e também não
tem apelido nem visita gravada, então não há pendente para reenviar e não há o que deduplicar.
Recusar o corpo por causa disso trocaria medição parcial por medição nenhuma.

**A janela em que o selo é lembrado é a MESMA janela da visita**, lida da mesma declaração que o
cliente lê (`inatividade_min` do evento de página). Um número escrito no servidor divergiria do de
lá na primeira vez que alguém mexesse num só, e a divergência apareceria como linha contada duas
vezes — o cliente reenviando um lote cujo selo o servidor já esqueceu.

### As cortadas

O corte já era contado — o cliente conta o que estourou o orçamento da visita, o servidor conta o
que estourou o teto do corpo — e o número saía NOMEADO na resposta da rota, **onde ninguém o lê**:
a resposta morre no navegador. Quem abria a tela Medição via uma tabela e não tinha como saber que
faltava alguma coisa nela, e somava achando que tinha tudo.

Hoje o descarte é **gravado**, na mesma tabela do resumo, sob o nome `f3base_cortadas` — que tem
produtor único, a constante `METRICA_CORTADAS`.

**Por que na mesma tabela.** O descarte tem exatamente a granularidade do resumo — dia, caminho —
e exatamente o prazo dele. Uma tabela nova seria uma segunda migração, uma segunda poda e um
segundo prazo para manter, para guardar um inteiro por dia e por página.

**Por que um nome FORA da declaração.** Cortada não é comportamento de ninguém: nenhum visitante
"cortou" nada, foi o pacote que descartou. Declará-la no TSV a faria aparecer como evento na tela,
no `dataLayer` e na série histórica, respondendo uma pergunta que ela não responde. **Todo leitor
do resumo a exclui pelo nome** — se você escrever uma leitura nova, exclua-a também, ou o total
passa a somar o que não aconteceu.

### A migração da estrutura, e por que ela não espera

O gancho de ativação NÃO roda numa ATUALIZAÇÃO de plugin: um site que sobe de versão sem desativar
e reativar nunca chamaria `instalar()`, a tabela nunca nasceria, e o módulo ficaria degradado para
sempre com a rota respondendo `503`. Por isso `garantir_estrutura()` roda em `init` e é guardada
por um transiente de `MINUTE_IN_SECONDS`.

**O transiente é trava da TENTATIVA, e não espera pelo fracasso.** Ele já foi de quinze minutos, e
o defeito foi medido vivo: um `dbDelta` que falhasse punha o site em quinze minutos de `503` na
rota, sem nenhuma nova tentativa no meio, com o contador andando o tempo todo. Um minuto é
folgadamente mais que um `dbDelta` de duas tabelas pequenas e folgadamente menos que a janela em
que um lote pendente ainda é retentativa. E a trava **cai no sucesso**.

A guarda pergunta pelas **duas** tabelas. Num site que já tinha o resumo, perguntar só por ele
fazia a função sair cedo e a tabela de registro nunca nascer: instalação limpa passava, e a
atualização sobre site existente — que é o caso de todo site já entregue — ficava sem o registro,
sem erro nenhum.

---

## Como marcar uma seção para ser medida

A seção precisa carregar a classe `f3base-secao-<nome>` no markup. No editor de blocos, isso é o
campo **`className`** de um bloco de grupo — nunca um atributo cru escrito à mão no HTML do bloco,
que o editor descarta na primeira revisão.

O nome sai do **markup**, nunca do texto. Derivar o nome de um título produziria uma série
histórica que muda sozinha na primeira revisão de texto, e quem lê a série é um agente comparando
períodos. **Seção sem a classe não é medida**, e essa é a escolha certa entre não medir e medir
errado.

**Essa grafia é contrato do PLUGIN, e não muda com o prefixo do site.** O pacote que gera sites é
um template: cada site nasce de uma cópia renomeada para o próprio prefixo técnico. A classe é
carimbada pelos patterns do TEMA e pelo CONTEÚDO — os dois renomeados — e é procurada pelo coletor
deste PLUGIN, que não é renomeado. Com o tema carimbando `<prefixo>-secao-abertura` e o plugin
observando `f3base-secao-`, o observador não receberia alvo nenhum e a medição de seções morreria
calada em todo site renomeado, com o evento continuando declarado e respondendo nada para sempre.

A grafia está declarada em `dados/contrato-de-nomes.tsv`, a ferramenta de renomeação a atravessa
sem tocá-la, e `renomeacao.secao_medida_apos_renomear` renomeia de verdade, monta a lista de
classes que o markup renomeado carimba e roda a função REAL do coletor contra cada uma.

O prefixo chega ao cliente por `prefixoSecao`, publicado de
`F3Base_Modulo_Tracking::PREFIXO_SECAO`. Não escreva a classe no JavaScript.

---

## Como mudar este plugin

### Onde fica o quê

| Caminho | O que é |
|---|---|
| `base-site-core-fator3.php` | Cabeçalho, constantes, guarda de versão de PHP e a **lista de autoload** — um `require_once` por arquivo, sem carregamento automático de propósito, para que quem abre a pasta consiga ler |
| `includes/class-f3base-registro.php` | O **registro único** de módulos |
| `includes/class-f3base-modulo.php` | O contrato que todo módulo estende |
| `includes/class-f3base-modulo-*.php` | Um arquivo por módulo |
| `includes/class-f3base-options.php` | O **gravador único** de options, com catálogo e sanitizadores |
| `includes/class-f3base-plugin.php` | Orquestrador: ativação, desativação, registro dos hooks lendo o registro, rota de relatório |
| `includes/class-f3base-atividade.php` | Carimbos de última atividade por módulo |
| `includes/class-f3base-llms.php` | Regra compartilhada pelos dois módulos de `llms` |
| `includes/class-f3base-como-usar.php` | A habilidade que diz ao agente por MCP o que o plugin já faz — montada do registro, nunca de texto à mão |
| `includes/class-f3base-config-mcp.php` | As habilidades de ler e escrever a configuração do implantador pelo canal |
| `admin/class-f3base-admin-tela.php` | A tela de configuração, renderizada do registro e do catálogo |
| `admin/class-f3base-admin-medicao.php` | O menu **Medição**: o que os visitantes fizeram |
| `assets/f3base-tracking.js` | Carregador das tags **e** os coletores de comportamento |
| `assets/f3base-leads.js` | O cliente do botão de contato e da conversão |
| `assets/f3base-consentimento.js` | O banner e o controle de revisão do rodapé |
| `dados/eventos-comportamento.tsv` | Declaração única dos eventos de comportamento |
| `dados/vitais.tsv` | Declaração única das medidas de carregamento |
| `dados/contrato-de-nomes.tsv` | As grafias que a renomeação de prefixo NÃO reescreve |
| `uninstall.php` | O destino declarado de cada conjunto de dados na desinstalação |

Os cinco arquivos de contrato compartilhado — as quatro classes sem pai e a declaração de
emissores — chegam de `partilhado/` no empacotamento e ficam nos mesmos caminhos relativos.

### Acrescentar um módulo

Quatro passos, e o quarto é o que a suíte cobra:

1. Criar `includes/class-f3base-modulo-<nome>.php` com uma classe que estende `F3Base_Modulo` e
   implementa `id()`, `nome()`, `descricao()`, `hooks()` e `calcular_estado()`. Declarar também
   `options_que_controlam()` e `dependencias()` quando houver.
2. Acrescentar o arquivo à lista de autoload em `base-site-core-fator3.php`, **antes** de
   `includes/class-f3base-registro.php`.
3. Acrescentar a classe a `F3Base_Registro::classes()`, na posição em que a tela deve apresentá-la.
4. Escrever a entrada dele **neste documento**, na seção *Módulo a módulo*.

Não escreva `add_action` de módulo em lugar nenhum: quem registra é o orquestrador, lendo o
registro. Se o módulo precisa criar estrutura própria (tabela, agendamento), implemente
`instalar()` e `desinstalar()` — a ativação chama `instalar()` só nos módulos que devem registrar,
e a desativação chama `desinstalar()` em todos.

Se a estrutura precisa nascer também numa ATUALIZAÇÃO de versão, não confie no gancho de
ativação: registre um hook em `init` que verifique e crie, como o módulo de comportamento faz.

### Acrescentar um evento de comportamento

**Edite o TSV, não o JavaScript.**

1. Acrescente a linha em `dados/eventos-comportamento.tsv`, com todas as colunas: nome,
   parâmetros na ordem em que o coletor os entrega, teto por página, gatilho, limiar, pergunta,
   frase, natureza e motivo.
2. Se o gatilho já existe, acabou: o coletor correspondente já pede a declaração por ele.
3. Se o gatilho é novo, escreva o coletor em `assets/f3base-tracking.js` chamando
   `declaracao( '<gatilho>' )` e `numeroDoLimiar( '<gatilho>', '<chave>', <reserva> )`. **Não
   escreva o nome do evento nem os números do limiar no cliente.** A reserva do
   `numeroDoLimiar()` deve ser o MESMO número da declaração: uma reserva menor aperta o teto em
   silêncio no dia em que o arquivo se corromper.
4. `natureza` ausente cai em `tecnica` de propósito — o silêncio não pode promover um evento novo
   a comportamento de uso sem que alguém decida.

O teto por página não é enfeite: sem ele, uma única página pode gerar mais eventos que o site
inteiro em um dia, e a conta de medição amostra ou descarta o excesso silenciosamente. O teto
está ali para que o descarte seja NOSSO e declarado.

### Acrescentar uma option

Três lugares, e nenhum a mais:

1. **O catálogo**, em `F3Base_Options::catalogo()`: rótulo, descrição, `operavel`, `secao`,
   `campo`, `padrao` e `sanitiza`. Quando o campo é grupo, declare `subcampos`.
2. **O sanitizador**, na mesma classe. Ele precisa normalizar o conhecido **e preservar o
   desconhecido**: chave que ele não conhece dentro de um grupo é mantida, para que o que um
   agente gravou pelo canal não seja apagado pela primeira gravação da tela.
3. **A tela** não precisa de nada: ela percorre `folhas_operaveis()`. Mas toda folha operável
   exige `impacto` e `exemplo` escritos, e um detector cobra isso — um campo cujo impacto honesto
   é "preencher não muda nada" não é campo, é armadilha na tela de quem opera.

Se a option é gravada pelo implantador, ela precisa também de linha em `dados/contrato-de-nomes.tsv`
— senão a renomeação de prefixo reescreve o lado que grava e não o lado que lê, e a configuração
fica órfã sem erro nenhum. Se ela é SEGREDO, acrescente-a a `segredos_do_site()` e **não** a
declare no arquivo de configuração do implantador.

Se ela guarda estado de execução e não configuração, declare `'autoload' => false`.

### O que a suíte vai cobrar de você

O pacote que constrói este plugin roda `bash suite/verificar.sh <caminho>`. Do lado do plugin,
estas são as linhas que reprovam com mais frequência:

- `pacote.plugin_completo_no_zip` — arquivo na lista de autoload que não entrou no zip. Não
  aparece como erro de build: aparece como erro fatal no `require_once` da ativação, no site do
  cliente.
- `pacote.instrucoes_do_plugin_no_zip` — este documento no zip, sem número digitado fora dos
  blocos gerados, e com **todo** módulo de `includes/` descrito no texto.
- `estatica.carimbo_de_release_nos_documentos` — os blocos gerados deste documento batendo com a
  medição de agora.
- `estatica.campo_operavel_tem_impacto_e_exemplo` — toda folha operável do catálogo com impacto e
  exemplo escritos.
- `estatica.option_fonte_unica` e `estatica.detector_escrita_unica` — nenhuma escrita de option
  fora do gravador único.
- `tracking.eventos_de_comportamento_declarados` — nenhum literal de nome de evento declarado
  dentro do JavaScript.
- `renomeacao.contrato_de_nomes_completo` — o contrato de nomes cobrindo toda option do catálogo,
  todo evento declarado e o prefixo de seção.
- `pacote.js_entregue_sem_comentario` — o JavaScript entregue é a fonte com cada comentário
  trocado por espaço, e **nada mais**, provado por fluxo de tokens.
- `navegador.comportamento_real` — a sonda de navegador, abaixo.

### O que NUNCA se toca

| O quê | Por quê |
|---|---|
| Nome de option (`f3base_*`) | Renomear orfana o valor sem apagar nada e sem erro nenhum. O site passa a rodar no padrão de fábrica em cima de uma configuração que ninguém apagou |
| Nome de tabela | Renomear não migra nada: cria uma tabela vazia ao lado e a série histórica fica órfã |
| Nome de evento declarado no TSV | Renomear quebra a série na conta de medição do fornecedor, onde não há como reparar depois |
| Namespace REST | O implantador e a suíte montam URLs contra ele; renomear de um lado só faz a chamada bater em `404`. É também a MARCA que reconhece uma cópia mais velha deste plugin na ativação |
| O prefixo `f3base-secao-` | É contrato do plugin, carimbado por tema e conteúdo renomeados. Trocá-lo mata a medição de seções em todo site derivado, calada |
| As classes de `partilhado/` | O implantador as carrega ANTES de o plugin existir na instalação. Renomear um lado só faz o autoload procurar um arquivo que não existe: erro fatal na ativação |
| A constante de versão derivada do cabeçalho | Constante que repete o número sai de sincronia na primeira release em que alguém mexe nos dois. O cabeçalho é o contrato; já foi medido dizendo um número e a constante dizendo outro |
| A ordem dos parâmetros no TSV | O coletor entrega posicionalmente. Trocar duas colunas troca o significado das duas no relatório |
| A escrita direta de option | O ponto único é o que torna a leitura de volta e a procedência auditáveis |
| O nome `f3base_cortadas` fora da declaração | Declará-lo como evento o faria responder, na tela e na série histórica, uma pergunta que ele não responde |

---

## A regra de teto e piso, aplicada a este plugin

**Toda checagem tem de saber falhar.** Detector sem fixture negativa e positiva não entra: a
negativa reproduz o defeito e a checagem PRECISA acusar; a positiva preserva o caso correto e a
checagem PRECISA ficar em silêncio. Uma suíte cujo piso reimplementa a regra prova que a cópia
funciona, não que o detector funciona — por isso o piso roda a MESMA função que roda contra o
pacote, trocando só a raiz.

E **escopo vazio não é aprovação**: uma checagem que não encontra o que mede fecha adverso, nunca
OK.

As checagens deste plugin moram em duas formas, e a forma segue a natureza:

- **Detector de análise estática** — piso em disco, em `suite/fixtures/<nome-da-checagem>/negativa`
  e `/positiva`. Rodar só o piso: `bash suite/verificar.sh piso <caminho-do-pacote>`.
- **Sonda funcional** — o caso negativo é um MUTANTE do próprio pacote, e não uma árvore de
  arquivos; o piso mora dentro da sonda e a declaração de onde ele mora está em
  `suite/pisos-em-sonda.tsv`. A declaração não absolve por si: ela só é aceita quando a sonda
  tem ramo de TETO e ramo de PISO escritos, e quem confere isso é `estatica.piso_em_sonda_declarado`
  — que tem fixture negativa e positiva em disco como qualquer outro detector.

As bancadas que exercitam este plugin de verdade são `suite/lib/sonda-site-core.php` (monta um
`wpdb` de mentira e roda o endpoint e a cadência REAIS contra ele), `suite/checagens/js.mjs` (roda
os clientes reais sob o Node contra uma plataforma de mentira), `suite/lib/sonda-migracao.php`
(monta um diretório de plugins de mentira) e `suite/lib/sonda-bundle.php` (lê o zip montado, e não
a árvore de origem).

Rodada inteira: `bash suite/verificar.sh <caminho-do-pacote>`. Ela empacota primeiro — arquivo em
disco fora de `suite/inventario.tsv` aborta o build com o nome — e o código de saída vem da
contagem de estados.

---

## A sonda de navegador

Ela existe porque **quatro releases seguidas a bancada aprovou o que o navegador reprovou**. A
bancada SIMULA o observador de interseção; o navegador TEM um. Nenhuma quantidade de asserção
sobre uma simulação prova o que a implementação de verdade faz.

**O que ela mede.** O cliente ENTREGUE — o de `dist/entregue/`, sem comentário, que é o que o
visitante baixa — rodado num Chromium real, dirigido **só por rolagem**, numa página de geometria
de site real: seções de uma tela cada, com a classe lida de `prefixoSecao` e a declaração de
eventos GERADA do TSV na hora. Dois percursos: o longo desce até o fim, volta ao topo e desce de
novo, com um ocultamento no meio; o curto sobe alguns passos perto do fim e desce de novo. As
sequências de ocorrência esperadas são **geometria, não sorteio** — os percursos são declarados em
pixels exatos da faixa rolável. Ela confere ainda: zero erro de página, zero cortada, e que o lote
**chegou ao servidor** — não basta o cliente ter despachado.

**Como rodar à mão:**

```
cd suite/sonda-navegador
node servidor.mjs <diretorio-pub> <porta> &
node sonda.mjs <porta> [caminho-do-chromium]
```

O `<diretorio-pub>` precisa de `dados.json` — a declaração gerada do TSV, nunca versionada — e do
`f3base-tracking.js` ENTREGUE. Quem monta os dois na suíte é a checagem
`navegador.comportamento_real`.

**Sem Chromium a linha fecha `N/A` com a condição declarada, e nunca OK**: um ambiente sem
navegador não é um pacote aprovado, e verde sobre medição que não aconteceu é o instrumento
mentindo com a melhor cara possível.

**Uma mudança na medição de comportamento não é dada por boa sem ela.** Se você mexeu em coletor,
em limiar, em contador de travessia, em banda de fronteira ou no envio, a bancada passando não é
evidência suficiente — foi exatamente esse o padrão das quatro releases.

---

## Migração e convivência

**Ativar sobre um site que roda a cópia antiga desativa a cópia antiga.** Existe pelo menos um
site em produção com este plugin na pasta anterior. Instalar a pasta nova ali deixaria DUAS
CÓPIAS DO MESMO PLUGIN ATIVAS: dois registros de hooks, duas rotas REST para o mesmo endereço,
dois coletores enfileirados na mesma página e a conversão contada em dobro. O WordPress não impede
isso e não avisa — nada aparece como erro, aparece como número errado, semanas depois, sem nada
que aponte para a causa.

**O discriminante não é o nome da pasta.** Uma lista literal de pastas antigas só reconhece o que
alguém lembrou de escrever nela, e sites renomeados receberam forks com outros nomes de pasta
ainda. O que TODAS as cópias têm em comum é a reivindicação do mesmo namespace REST, lida do topo
do arquivo principal de cada plugin ativo — é dela que vem a colisão.

**NÃO HÁ DADO A MIGRAR**, e é exatamente por isso que o prefixo interno não mudou: as options são
as mesmas e as tabelas são as mesmas. A cópia nova encontra a configuração do site inteira, no
lugar onde ela sempre esteve. O que mudou foi o ENDEREÇO do código, e endereço não guarda dado.

**Por que desativar a outra, e não recusar ativar esta.** Recusar deixaria o site rodando a cópia
ANTIGA — o artefato que esta release existe para substituir — e transferiria a correção para
alguém ler uma mensagem; a instalação é feita pelo implantador, sem ninguém olhando. E o dano das
duas cópias já existe no instante da ativação: recusar não o desfaz, só não o piora.

**O que ele NÃO faz, e o limite importa.** Não apaga arquivo nenhum, não toca em option nem em
tabela, e não desativa nada que não carregue a marca. A pasta antiga continua em disco e
reativá-la é um clique — a ação é reversível, e é isso que a torna aceitável. O que ela deixa é
REGISTRO: um transiente com prazo, lido uma vez pela tela, com o nome do que foi desativado.

O gancho de desativação da cópia antiga **não roda**. Ele desinstalaria os módulos — desagendaria
a cadência, removeria regras de reescrita — e são os MESMOS agendamentos e as MESMAS regras que
esta cópia acabou de instalar, porque as chaves são as mesmas. Rodá-lo desfaria a ativação em
curso, e o site ficaria com o plugin ativo e a cadência desagendada, calado.

**Na desativação simples**, os módulos são desinstalados e as regras de reescrita são regravadas.
**Nenhum dado de lead é tocado**: desativar plugin não é pedido de eliminação.

**Na desinstalação**, sai o que só o plugin usa e sabe recriar — estado de execução, o segredo do
endpoint, os agendamentos (inclusive o evento agendado com argumento, que exige
`wp_unschedule_hook()`), os transientes e as tabelas de chaves e de resumo. **Fica**, por decisão
declarada: os registros de lead, o journal de eliminação e as options de configuração gravadas
pelo implantador. Desinstalar plugin não é pedido de eliminação de dado pessoal, e apagar registro
sem journal é perda sem registro — a remoção desses dados tem rota própria, com capacidade
exigida, journal e regime declarado.

---

## O peso entregue

**Os comentários da fonte não viajam.** A disciplina de comentário deste plugin existe para
impedir regressão, e quem lê é quem MANTÉM o pacote — não o navegador de quem visita. O
empacotamento entrega os `.js` de `assets/` **sem comentário**, e a fonte continua com tudo.

<!-- gerado:inicio=plugin-peso -->
| Arquivo | Fonte | Entregue | Fonte comprimido | Entregue comprimido |
|---|---|---|---|---|
| `assets/f3base-consentimento.js` | 14260 B | 8834 B | 5063 B | 2636 B |
| `assets/f3base-leads.js` | 25940 B | 14584 B | 9059 B | 4205 B |
| `assets/f3base-tracking.js` | 93731 B | 30136 B | 31622 B | 7845 B |
<!-- gerado:fim=plugin-peso -->

**O corte é feito por TOKENIZADOR, nunca por expressão regular.** `/*` dentro de string e `//`
dentro de URL ou de literal de expressão regular existem NESTES arquivos, e um corte ingênuo os
apaga entregando um arquivo que ainda analisa e faz outra coisa.

**Quem mexer no empacotamento tem de manter a checagem que compara o FLUXO DE TOKENS.** Contar
comentários não veria nada disso — o arquivo corrompido também não tem comentário nenhum. A prova
é: fonte e entregue são tokenizados, os comentários são descartados dos dois, os espaços são
normalizados, e o que sobra tem de ser idêntico token a token. Quem diz que o entregue ainda é
JavaScript é o `node --check`; quem diz que ele se COMPORTA igual são as bancadas e a sonda de
navegador, que rodam contra o entregue e não contra a fonte.
