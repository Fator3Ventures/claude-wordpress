<?php
/**
 * Resumable copy/verify/switch; the frozen legacy source remains available for recovery.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Storage;

use Fator3\McpGoogle\{Ability, Automation\Jobs, Automation\Results, Lock, Options, Records, Response};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Migration {

	public const OPTION = 'f3_mcp_google_storage';
	public const HOOK   = 'f3_mcp_google_storage_step';
	public static function init(): void {
		add_action( self::HOOK, array( self::class, 'advance' ) );
		if ( ! self::active() && function_exists( 'wp_next_scheduled' ) && ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_single_event( time() + 5, self::HOOK );
		}
	}
	public static function advance(): array {
		$result = self::state() ? self::step() : self::begin();
		if ( ! self::active() && 'failed' !== ( self::state()['phase'] ?? '' ) && function_exists( 'wp_schedule_single_event' ) ) {
			wp_schedule_single_event( time() + 15, self::HOOK );
		}
		return $result;
	}
	public static function register(): void {
		Ability::register(
			'google/storage-status',
			'any',
			array(
				'label'       => 'Google: estado da migração',
				'description' => 'Consulta local da migração e do armazenamento ativo.',
				'callback'    => static fn () => Response::ok( array( 'storage' => self::state() ) ),
			)
		);
		Ability::register(
			'google/migrate-storage',
			'any',
			array(
				'label'       => 'Google: continuar migração',
				'description' => 'Copia e verifica um lote; preserva a origem. A fila permanece pausada até a verificação final.',
				'mode'        => 'write',
				'callback'    => static function (): array {
					return current_user_can( 'manage_options' ) ? self::advance() : Response::fail( new \WP_Error( 'f3_google_forbidden', 'Permissão insuficiente.' ) );
				},
			)
		);
	}
	public static function state(): array {
		$value = get_option( self::OPTION, array() );
		return is_array( $value ) ? $value : array(
			'phase' => 'failed',
			'error' => 'state_corrupt',
		);
	}
	public static function active(): bool {
		return 'indexed' === ( self::state()['phase'] ?? 'legacy' );
	}
	public static function paused(): bool {
		return in_array( self::state()['phase'] ?? 'legacy', array( 'drain', 'copy', 'verify', 'failed' ), true );
	}
	public static function begin(): array {
		if ( self::state() ) {
			return self::step();
		}
		$lock = Lock::acquire( 'queue-admission', 60 );
		if ( null === $lock ) {
			return Response::fail( new \WP_Error( 'f3_google_migration_busy', 'Aguarde a admissão em andamento.' ) );
		}
		try {
			// Freeze admission first. Already-running workers stop at their next dispatch guard.
			$saved = Options::set(
				self::OPTION,
				array(
					'phase'      => 'drain',
					'cursor'     => '',
					'copied'     => 0,
					'started_at' => time(),
				)
			);
			if ( ! $saved['success'] ) {
				return $saved;
			}
		} finally {
			Lock::release( $lock );
		}
		return self::step();
	}
	private static function draining(): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'f3_mcp_google_lock_' ) . '%' ) );
		if ( $wpdb->last_error ) {
			return true;
		}
		$self = 'f3_mcp_google_lock_' . hash( 'sha256', 'storage-migration' );
		foreach ( $names as $name ) {
			if ( $name === $self ) {
				continue;
			}$lease = Options::stored( $name );
			if ( ! $lease['success'] ) {
				return true;
			}if ( is_array( $lease['value'] ) && ( $lease['value']['expires'] ?? 0 ) > time() ) {
				return true;
			}
		}
		return false;
	}
	public static function step( int $limit = 100 ): array {
		global $wpdb;
		$limit = max( 1, min( 500, $limit ) );
		$lock  = Lock::acquire( 'storage-migration', 120 );
		if ( null === $lock ) {
			return Response::fail( new \WP_Error( 'f3_google_migration_busy', 'Migração em execução.' ) );
		}
		try {
			$state = self::state();
			if ( 'indexed' === ( $state['phase'] ?? '' ) ) {
				return Response::ok( $state );
			}
			if ( ! $state ) {
				return Response::fail( new \WP_Error( 'f3_google_migration_not_started', 'Inicie a migração.' ) );
			}
			if ( self::draining() ) {
				return Response::ok( $state + array( 'reason' => 'waiting_for_workers' ) );
			}
			$installed = Repository::install();
			if ( is_wp_error( $installed ) ) {
				return self::fail( $state, '', $installed->get_error_message() );
			}
			if ( in_array( $state['phase'], array( 'drain', 'failed' ), true ) ) {
				$state['phase'] = isset( $state['verify_cursor'] ) ? 'verify' : 'copy';
				unset( $state['error'], $state['failed_record'] );
			}
			$verify = 'verify' === $state['phase'];
			$cursor = $verify ? ( $state['verify_cursor'] ?? '' ) : ( $state['cursor'] ?? '' );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
			$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name>%s ORDER BY option_name ASC LIMIT %d", $wpdb->esc_like( Records::PREFIX ) . '%', $cursor, $limit ) );
			if ( $wpdb->last_error ) {
				return self::fail( $state, '', 'Leitura da origem falhou.' );
			}
			foreach ( $names as $name ) {
				if ( ! preg_match( '/^' . preg_quote( Records::PREFIX, '/' ) . '([a-z]+)_(.+)$/D', $name, $parts ) ) {
					return self::fail( $state, $name, 'Identificador inválido.' );
				}
				$source = Options::stored( $name );
				if ( ! $source['success'] || ! $source['exists'] || ! is_array( $source['value'] ) ) {
					return self::fail( $state, $name, 'Registro ilegível; origem preservada.' );
				}
				$kind       = $parts[1];
				$id         = $parts[2];
				$value      = self::transform( $kind, $source['value'] );
				$children   = self::children( $kind, $id, $source['value'] );
				$row_chunks = 'job' === $kind ? Results::externalize( $value ) : array();
				foreach ( $row_chunks as $chunk_id => $chunk ) {
					if ( ! self::copy_verified( 'result', $chunk_id, $chunk, $verify ) ) {
						return self::fail( $state, $name, 'Linhas de relatório não confirmadas.' );
					}
				}
				foreach ( $children as $child_id => $child ) {
					if ( ! self::copy_verified( 'item', $child_id, $child, $verify ) ) {
						return self::fail( $state, $name, 'Resultado de item não confirmado.' );
					}
				}
				if ( ! self::copy_verified( $kind, $id, $value, $verify ) ) {
					return self::fail( $state, $name, 'Integridade divergente; origem preservada.' );
				}
				$state[ $verify ? 'verify_cursor' : 'cursor' ] = $name;
				$counter                                       = $verify ? 'verified' : 'copied';
				$state[ $counter ]                             = (int) ( $state[ $counter ] ?? 0 ) + 1;
				$saved = Options::set( self::OPTION, $state );
				if ( ! $saved['success'] ) {
					return $saved;
				}
			}
			if ( count( $names ) < $limit ) {
				if ( ! $verify ) {
					$state['phase']         = 'verify';
					$state['verify_cursor'] = '';
					$state['verified']      = 0;
				} else {
					if ( $state['verified'] !== $state['copied'] ) {
						return self::fail( $state, '', 'Contagens divergentes.' );
					}
					$legacy = Options::stored( Options::AUDIT );
					if ( ! $legacy['success'] || ( $legacy['exists'] && ! is_array( $legacy['value'] ) ) ) {
						return self::fail( $state, Options::AUDIT, 'Log legado ilegível.' );
					}
					foreach ( $legacy['value'] ?? array() as $index => $entry ) {
						if ( ! is_array( $entry ) ) {
							return self::fail( $state, Options::AUDIT, 'Evento legado inválido.' );
						}
						$id                        = 'legacy_' . hash( 'sha256', (string) $index . '|' . wp_json_encode( $entry ) );
						$entry['migration_origin'] = Options::AUDIT;
						$legacy_time               = strtotime( ( $entry['time'] ?? '' ) . ' UTC' );
						$entry['created_at']       = $entry['created_at'] ?? ( $legacy_time ? $legacy_time : $state['started_at'] );
						if ( ! self::copy_verified( 'audit', $id, $entry, false ) ) {
							return self::fail( $state, Options::AUDIT, 'Evento legado não confirmado.' );
						}
					}
					$state['phase']              = 'indexed';
					$state['completed_at']       = time();
					$state['legacy_audit_count'] = count( $legacy['value'] ?? array() );
				}
			}
			$saved = Options::set( self::OPTION, $state );
			if ( $saved['success'] && 'indexed' === $state['phase'] ) {
				Jobs::schedule_tick();
			}
			return $saved['success'] ? Response::ok( $state ) : $saved;
		} finally {
			Lock::release( $lock );
		}
	}
	private static function copy_verified( string $kind, string $id, array $value, bool $verify ): bool {
		$old = Repository::get( $kind, $id );
		if ( is_wp_error( $old ) ) {
			return false;
		}
		if ( null === $old && ! $verify && ! Repository::insert( $kind, $id, $value ) ) {
			return false;
		}
		return Repository::get( $kind, $id ) === $value;
	}
	private static function children( string $kind, string $id, array $value ): array {
		$out = array();
		if ( 'job' === $kind ) {
			foreach ( $value['results'] ?? array() as $index => $result ) {
				$out[ Results::id( $id, (int) $index ) ] = array(
					'task'       => $id,
					'index'      => (int) $index,
					'result'     => $result,
					'created_at' => $value['created_at'] ?? 0,
				);
			}
		}
		return $out;
	}
	private static function transform( string $kind, array $value ): array {
		if ( 'job' === $kind ) {
			if ( ! isset( $value['context'] ) && in_array( $value['status'] ?? '', array( 'pending', 'running', 'dispatching' ), true ) ) {
				$value['status']         = ! empty( $value['write'] ) && in_array( $value['status'], array( 'running', 'dispatching' ), true ) ? 'unknown' : 'blocked';
				$value['blocked_reason'] = 'legacy_context_required';
			}
			if ( ! empty( $value['results'] ) ) {
				$value['result_count'] = count( $value['results'] );
				unset( $value['results'] );
			}
		}
		if ( 'schedule' === $kind && ! isset( $value['context'] ) ) {
			$value['enabled']        = false;
			$value['blocked_reason'] = 'legacy_context_required';
		}
		return $value;
	}
	private static function fail( array $state, string $record, string $message ): array {
		$state['phase']         = 'failed';
		$state['failed_record'] = $record;
		$state['error']         = $message;
		$saved                  = Options::set( self::OPTION, $state );
		return Response::fail(
			new \WP_Error( 'f3_google_migration_failed', $message ),
			array(
				'storage'                 => $state,
				'failure_state_persisted' => $saved['success'],
			)
		);
	}
}
