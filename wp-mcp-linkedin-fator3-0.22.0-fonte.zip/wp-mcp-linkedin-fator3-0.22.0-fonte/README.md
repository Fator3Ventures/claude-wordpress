# Fonte — Fator3 MCP LinkedIn 0.22.0
Os modelos editáveis ficam em build/common, build/linkedin, build/assets e build/docs/linkedin. O diretório plugin/wp-mcp-linkedin-fator3 reproduz exatamente o instalador testado. O banco de laboratório é descartável. Não utilize credenciais reais nos testes.

## Reproduzir
Use WordPress 7.1.4, PHP 8.3 de 64 bits, MySQL 8 e cliente mysql no PATH. Ajuste os caminhos no manifesto de tools e confira cada hash. Crie um diretório de teste e um banco distintos por execução; o runner cria e descarta o banco. O teste de troca carrega o instalador 0.21.0 como base.
 
```sh
F3_SOCIAL_PHP=/caminho/php8.3 python3 build/build.py
python3 tools/verify-installer022.py build/dist/wp-mcp-linkedin-fator3-0.22.0-instalador.zip plugin/wp-mcp-linkedin-fator3
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li22-core --order linkedin-integrated --tests ad-source022.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li22-upgrade --origin upgrade --order linkedin-integrated --tests migration022.php
```
Para repetir a prova de defeito, aponte --candidate para o instalador 0.21.0 no teste ad-source022.php e utilize outro diretório. Para o teste isolado use --order linkedin-only; para as regressões, suite.php e mcp-docs080.php. O laboratório chama as classes oficiais do Core, WordPress e MCP; apenas a rede do LinkedIn é simulada. O relatório e evidence/release0220 distinguem isso das consultas reais. O patch do Core e os resultados de rodadas anteriores são históricos. Para repetição com o último conjunto do Site-Teste use tools/lab-release0220-site.example.json.
