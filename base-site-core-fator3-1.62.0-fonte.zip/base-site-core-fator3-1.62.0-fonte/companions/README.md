# Acompanhantes considerados — Core 1.62.0

Base canônica Core 1.61.1. Pacotes separados, sem alterações ou redistribuição. Manifesto recebido em inputs/1620/packages.json; MCP/LinkedIn/Pipedrive preservam as identidades de inputs/1610/pacotes-reconferidos.json.

| Pacote | Versão | Prova nesta rodada |
| --- | --- | --- |
| wp-mcp-fator3 | 0.37.0 | Nativo local: autorização, decoração de saída, filtro de segredo, catálogo e documentação integral. |
| wp-mcp-google-fator3 | 0.24.0 | SDK/armazenamento reais, transporte sintético: Google Ads e Search Console. |
| wp-mcp-meta-fator3 | 0.16.0 | SDK/armazenamento reais, grants e acervos sintéticos: desempenho, nome de campanha e monitoramento. |
| wp-mcp-linkedin-fator3 | 0.13.0 | Bootstrap e convivência local, sem troca do cliente. |
| wp-mcp-pipedrive-fator3 | 0.4.0 | Examinado; não ativado no PHP 8.3.6, pois exige 8.3.36. Prévia/journal CRM testados no Core com catálogo sintético. |

Google 0.24.0: 886260 bytes, SHA-256 803fa058182b9f43625352f2b4a1572a3cd4b728f8c07fd58314a9a111d41849.
Meta 0.16.0: 315170 bytes, SHA-256 a49f3e8ae9e60814ab55cf1bd4b3277e859a477347d02f664353c1268fda0b6b.

A consulta inicial do Site-Teste confirmou todos os cinco acompanhantes ativos nessas versões, com Core 1.61.1. Não houve instalação ou execução de bancada remota 1.62.0: a revisão automática bloqueou uma parte do upload; a transferência foi cancelada. O controlador de bancada remota está preparado, mas não executado.

Matriz local: funções no WordPress 7.1.3/PHP 8.3.6; instalação limpa, atualização direta, repetição e reinstalação também no piso WordPress 7.1.2/PHP 8.3.6. MySQL 8.0.46, sem HTTP externo real ou mensagens nos testes. A presença dos produtores não concede acesso aos seus dados. Credenciais ficam nos produtores.
