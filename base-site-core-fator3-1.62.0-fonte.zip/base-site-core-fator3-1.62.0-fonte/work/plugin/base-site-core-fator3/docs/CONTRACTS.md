> Vigente em 1.62.0: contrato 8.27.0; pedidos 348–351 em RELEASE-1.62.0.md e CAMPANHAS-MARCAS-PERFIL-1.62.md. As notas atuais prevalecem nos pontos alterados.

> Atualização vigente: Core 1.60.0, contrato 8.24.0. Leia RELEASE-1.60.0.md e os guias 1.60 para as alterações dos pedidos 322 e 330–334; as regras anteriores incompatíveis são históricas.

# Contratos — Core 1.59.0

Contrato administrativo 8.23.0; perfil canônico `piso-padrao-3.6`. Referências executáveis: `dados/configuracao-schema.json`, `dados/abilities-*.json` e `dados/contrato.json`. Provider, slugs, namespaces e permissões anteriores preservados. Base direta 1.58.0; leia RELEASE-1.59.0.md. Esta versão conserva os schemas administrativos e não cria tabela ou option.

Configuração usa revisão opaca, simulação por padrão e validação do dono. `persisted`, `effect`, `audit` e `verification` são dimensões distintas. Operações por JSON Pointer aplicam-se à revisão lida e validam o candidato inteiro; projeções e hashes excluem segredos. Veja OPERACAO-1.58.md. A retirada histórica de `f3base/config-procedencia-reparar` permanece; não há alias para gravar metadados antigos.

| Fronteira | Contrato / alcance |
| --- | --- |
| MCP | `server-integration/1.0.0`; política/identidade do produtor e capacidades administrativas somadas à autorização do canal. MCP 0.34 é aditivo. |
| Google Search Console e GA4 | `search-console-reader/1.0.0`, `ga4-reader/1.0.0`; concessões, quotas e credenciais do produtor. |
| Conversões de contato | `site-conversion-delivery/1.0.0`; Google, desde 0.21, acrescenta 1.1.0 para user_data opcional e prontidão de conversões otimizadas; 0.22 conserva esses contratos. |
| Retorno de etapa Google/LinkedIn | `site-conversion-delivery/1.2.0`, consumidor `site-core-quality`, propósito `crm_stage`; entregue por Google 0.22 e LinkedIn 0.12, com concessão por ação. Ver QUALIDADE-DESTINOS-1.58.md. |
| Reconciliação comercial Google | `site-stage-conversion-reconcile/1.0.0`; extensão anunciada no mesmo adaptador, método `reconcileBound(event_id,destination_ref)`. Consulta do recibo exato, sem novo envio. Ver RECONCILIACAO-COMERCIAL-1.59.md. |
| Meta Instagram | `instagram-first-message/1.0.0` e `instagram-message-erasure/1.0.0` preservados, com tombstones e recibos próprios. |
| Meta Ads | `meta-ads-reader/1.0.0`; cliente registrado, concessão explícita e leitura local consistente. Ver META-ADS-CORE-1.58.md. |
| Pipedrive | `pipedrive-api-client/1.0.0` preservado; Core mantém segredo, orçamento, consumidor e limites de operação. |

Acompanhantes são descobertos por contrato e capacidades; versão sozinha não concede autorização. Ausência, resposta inválida ou exceção degrada a integração correspondente sem impedir instalação. Nenhuma leitura Core usa armazenamento privado do produtor para suprir contrato ausente. `history_changed`/`revision_conflict` em acervo exigem reiniciar a leitura, preservando a distinção entre observação corrente e anterior.

Prontidão e resumo operacional usam somente consultas locais, sem renovação, concessão ou reparo de fornecedor. Prévia de conversão não cria fila. Mutações administrativas exigem `manage_options` e, nas operações de contatos, a capacidade específica. Recuperação preserva leitura documental e bloqueia efeitos comerciais. Resultado incerto nunca autoriza repetir criação/envio externo.

As filas introduzidas na 1.58 possuem identidade durável, revisão e reserva anteriores ao efeito. Desativar/desinstalar preserva dados e suspende pendentes; não desfaz efeitos externos. O teste do caminho do lead restringe homologação ao seu registro e só limpa objetos comprovadamente próprios. Campos, enumerações e formatos exatos estão no catálogo executável instalado.

A reconciliação Google conserva a revisão e a referência reservadas, confere a configuração antes/depois da consulta e não transforma resultado incerto em nova entrega. O produtor pode exigir cooldown maior que o intervalo local. LinkedIn não anuncia essa extensão; o recibo local é distinto da auditoria central. MCP 0.34 ainda não admite `site-core-quality` nessa auditoria: `service_record_unconfirmed` não autoriza reenvio nem troca do consumidor.

## Códigos de recuperação

A guarda usa `wp-content/f3-core-state/`: `site-N.php` é a sentinela, `site-N-state.php` registra a barreira, `site-N-workers.php` coordena entradas e `site-N-task-<tarefa>.php` reserva cada tarefa. A resposta deve ser interpretada pelo código, estado e precondição atuais. Números de linha são apenas referência histórica da especificação.

| Grupo | Código | Linha | Significado | Ação |
| --- | --- | --- | --- | --- |
| Estado da guarda | `core_operacional` | 20 | Sentinela válida, sem pausa e sem falha de trava | Nenhuma |
| Estado da guarda | `core_pausado` | 20 | Sentinela com `pausado: true`; tarefas e mutações paradas | Reconciliar e chamar `retomar` |
| Estado da guarda | `trava_inacessivel` | 20, 78–79 | `site-N-workers.php` é link ou não abre para escrita | Corrigir dono e permissão; se persistir, `recriar` |
| Estado da guarda | `trava_ocupada` | 20, 80 | Outra operação segura a trava exclusiva | Aguardar e repetir |
| Estado da guarda | `trava_falhou` | 20, 80 | `flock` falhou sem indicar bloqueio | Conferir o sistema de arquivos; depois `recriar` |
| Estado da guarda | `sentinela_ausente` | 16 | `site-N.php` não existe | `recriar` com `precondicao_esperada` e as confirmações |
| Estado da guarda | `sentinela_ilegivel` | 16, 18 | Não é arquivo regular ou a leitura falhou | Corrigir tipo e permissão; depois `recriar` |
| Estado da guarda | `sentinela_invalida` | 18 | Conteúdo sem o cabeçalho ou sem `geracao` e `pausado` | `recriar` |
| Estado da guarda | `sentinela_link_recusado` | 16 | `site-N.php` é link simbólico | Remover o link; depois `recriar` |
| Estado da guarda | `diretorio_sentinela_link_recusado` | 15, 28 | A pasta é link simbólico | Trocar por pasta real |
| Estado da guarda | `diretorio_sentinela_indisponivel` | 15, 29, 43, 67 | Pasta ausente, ilegível ou impossível de criar | Criar a pasta ou corrigir a permissão |
| Estado da guarda | `indice_protetor_link_recusado` | 15, 30, 43 | `index.php` da pasta é link simbólico | Remover o link; a provisão recria o índice |
| Proteção em disco | `indice_protetor_confirmado` | 27 | `index.php` com o conteúdo esperado | Nenhuma |
| Proteção em disco | `indice_protetor_indisponivel` | 31 | `index.php` ausente ou ilegível; não pausa | Corrigir a permissão |
| Proteção em disco | `indice_protetor_divergente` | 32 | Conteúdo diferente; não é sobrescrito e não pausa | Repor o conteúdo esperado |
| Entrada da requisição | `nao_tentada` | 9 | Nenhuma tarefa protegida tentou entrar | Nenhuma |
| Entrada da requisição | `entrada_confirmada` | atual | Entrada aceita com trava compartilhada | Nenhuma |
| Respostas da operação | `core_em_recuperacao` | 85 | Chamada protegida recusada pela guarda | Ler `recuperacao` na resposta |
| Respostas da operação | `sem_permissao` | 87 | Sem `manage_options` e fora do WP-CLI | Usar conta administradora |
| Respostas da operação | `geracao_invalida` | 88 | `geracao_esperada` ausente ou não inteira | Ler o estado e enviar `geracao` |
| Respostas da operação | `geracao_divergente` | 93 | Geração diferente da enviada | Reler e repetir |
| Respostas da operação | `acao_invalida` | 94 | `acao` fora de `preparar`, `retomar`, `recriar` | Corrigir a chamada |
| Respostas da operação | `reconciliacao_externa_nao_confirmada` | 95 | `retomar` sem `reconciliacao_confirmada` | Reconciliar e confirmar |
| Respostas da operação | `barreira_ocupada` | 46, 91 | Outra operação de recuperação em curso | Aguardar e repetir |
| Respostas da operação | `barreira_nao_persistida` | 96 | `preparar` não gravou a pausa | Conferir escrita na pasta |
| Respostas da operação | `aguardando_drenagem` | 40, 49, 97 | Há trabalho em voo | Repetir a mesma chamada até `core_drenado` |
| Respostas da operação | `core_drenado` | 104 | Pausado, sem trabalho em voo | Restaurar preservando a pasta |
| Respostas da operação | `core_retomado` | 104 | Geração incrementada, filas invalidadas | Reconciliar os itens suspensos e incertos |
| Respostas da operação | `ja_retomado` | 100 | O Core já estava sem pausa | Nenhuma |
| Respostas da operação | `trava_link_recusado` | 44, 89 | Arquivo de estado ou de workers é link | Remover o link |
| Respostas da operação | `sentinela_gravacao_falhou` | 51, 58, 104 | A sentinela não foi gravada | Conferir escrita e espaço em disco |
| Respostas da operação | `sentinela_existente` | 40 | `recriar` recusado: a sentinela é válida | Usar `preparar` ou `retomar` |
| Respostas da operação | `confirmacao_recriacao_necessaria` | 41 | Falta `reconciliacao_confirmada` ou `copia_outro_host` | Enviar os dois campos |
| Respostas da operação | `precondicao_divergente` | 42, 48 | A sentinela mudou desde a leitura | Reler `precondicao` e repetir |
| Respostas da operação | `identidade_nao_persistida` | 55 | Identidade nova do Pipedrive não gravou | Repetir `recriar` |
| Respostas da operação | `sentinela_recriada` | 58 | Nova geração gravada; filas suspensas | Reconciliar; com `manter_pausado`, `retomar` depois |
| Invalidação de filas | `inventario_recuperacao_falhou` | 115 | Contagem prévia de uma fila falhou | Corrigir o banco e repetir a ação |
| Invalidação de filas | `fila_nao_suspensa` | 124 | Fila da Meta ou do Pipedrive não foi suspensa | Idem |
| Invalidação de filas | `avisos_nao_suspensos` | 128 | Avisos de contato não foram marcados | Idem |
| Invalidação de filas | `intencoes_nao_suspensas` | 129 | Marca das entregas ao Pipedrive não gravou | Idem |
| Invalidação de filas | `eliminacoes_nao_suspensas` | 131 | Eliminações remotas não foram suspensas | Idem |
| Invalidação de filas | `alertas_nao_suspensos` | 133, 134 | Alertas de entrega não foram marcados | Idem |
| Invalidação de filas | `alerta_conta_nao_suspenso` | 137 | Alerta de conta não foi marcado | Idem |
| Invalidação de filas | `cursor_nao_invalidado` | 138 | Cursor do Search Console não foi invalidado | Idem |
| Invalidação de filas | `reservas_nao_invalidadas` | 139 | Reservas do executor não foram zeradas | Idem |
| Invalidação de filas | `intencoes_nao_invalidadas` | 140 | Intenções pendentes não passaram a `suspensa` | Idem |
| Reserva de tarefa | `reserva_indisponivel` | 142, 145 | Arquivo de tarefa como link simbólico | Conferir o arquivo de tarefa |
| Reserva de tarefa | `trava_arquivo_inacessivel` | 145 | Arquivo de tarefa não abre para escrita | Corrigir a permissão |
| Reserva de tarefa | `reserva_ocupada` | 145 | Outra execução da mesma tarefa em curso | Aguardar |
| Reserva de tarefa | `trava_arquivo_falhou` | 145 | `flock` do arquivo de tarefa falhou | Conferir o sistema de arquivos |
| Marcas nos dados | `restauracao_requer_reconciliacao` | 124–137 | Item suspenso ou incerto por retomada ou recriação | Reconciliar no módulo dono antes de reenviar |
| Marcas nos dados | `copia_requer_verificacao` | 54 | Site copiado de outro host | Verificar a integração |
| Entrada da requisição | `protecao_degradada` | atual | Módulos de atendimento subiram, mas tarefas e gravações protegidas estão bloqueadas | Corrigir dono, permissão e arquivo de coordenação |
| Retirada de URL | `caminho_nao_retirado` | atual | Foi solicitada restauração de um caminho sem retirada prévia; nenhuma escrita ocorreu | Confira a operação desejada e o histórico do caminho |


## Interfaces adicionais

Contexto e catálogo: MEDICAO-SDK-1.33.md, contrato `site-measurement-context/1.0.0`. SDK GSC permanece separado. Não existem versões mínimas numéricas nem recusa de sufixo do acompanhante; conferir contrato e capacidades da função pretendida.

Ponte `f3base/config-ler` / `config-escrever`: `scope:installer_json`, `site_config_applied:false`. O adaptador `F3Base_Implantador_Adaptador` concentra localização, leitura, validação e gravação; ainda depende do validador privado do implantador. Não é aplicação de configuração Core ou tema.

LinkedIn externo: interface `linkedin-lead-reader/1.0.0` aguardando especificação executável e homologação; somente cliente interno disponível. Cinco donos e limites: RELEASE-1.57.1.md.


## Complementos vigentes

Configuração LinkedIn por integração e troca dedicada: LINKEDIN-LEAD-SYNC.md. Correções de operação e retenção: RELEASE-1.57.1.md. Matriz histórica da base: MCP 0.31.0 / Google 0.19.0 / LinkedIn 0.10.1 / Meta 0.10.1. A rodada 1.57.1 integrou MCP 0.33.0. A matriz histórica examinada em 1.58.0 foi MCP 0.34.0 / Google 0.21.0 / LinkedIn 0.11.0 / Meta 0.13.0 / Pipedrive 0.3.0. A 1.59 considera Google 0.22.0 e LinkedIn 0.12.0 com os demais acompanhantes conservados; os limites estão no relatório externo e em RELEASE-1.59.0.md. Leia também RELEASE-1.57.1.md para a base de atualização ou reversão.


## Alterações 1.35.0

Leia CONVERSOES-CONTEUDO-1.35.md. Instalação nova ou base 1.34.0; mínimos WP 7.1.2/PHP 8.3.6 64 bits. Contrato administrativo 8.3.0; SDK 1.0.0 fechado sem material. Reserva editorial adaptativa, equivalência Slack por blocos exibidos, rótulos Meta em texto CRM e tela de conexões corrigida. Migração de reservas e suspensão de Lead legado de material; sem reenvio ou correção retroativa.


## Atualização 1.53.0

Pedidos 299–301 e contrato 8.18.0: EMAIL-SITE-1.53.md documenta caixa, cinco abilities, tabela, retenção e restauração; FORMULARIOS-SINAIS-1.53.md documenta a quarta isca e a política de suspeita/aviso. RELEASE-1.57.1.md reúne as mudanças. A configuração de unidade Pipedrive é obrigatória para reutilizar ou criar oportunidade.

## Atualização 1.54.0

Pedido 302, contrato 8.19.0: CONTATOS-EXTERNOS-1.54.md; duas abilities novas, atribuição manual auditada, filtro em conteúdo/canais e índice f3base_contato_sessoes. Capacidades exatas nas abilities de e-mail publicadas ao MCP. Sem novas conversões, avisos ou e-mails automáticos.

## Atualização 1.57.1

Contrato 8.22.1: f3base_sessao_admin_dias, mx_confiaveis e remetentes_teste; email-caixa-verificar aceita simular (padrão true) e aplicação cria pastas; saúde acrescenta prova_publica e motivos. Nenhuma ability nova. Sem mudança no cliente Pipedrive ou no MCP. OPERACAO-1.55.md descreve entrada, estados, limites e recuperação.
