<?php
/** Proposed consumers on original Core 1.60, real Google archive and native permissions. */
require __DIR__.'/bootstrap.php';
function verifyLab($name,$ok,$detail=null){if(!$ok&&$detail!==null)echo wp_json_encode($detail);check($ok,$name);}
use Fator3\McpGoogle\{Options as O,Connections as C,Settings,Policy,Ads\Archive,Ads\ArchiveStore,Integration\AdsServiceApi as Ads,Integration\QueryServiceApi as Gsc};
wp_get_abilities();get_role('administrator')->add_cap('f3base_ler_leads');wp_set_current_user(0);wp_set_current_user(1);$calls=0;$cost='1000000';$grows=3;$account='1234567890';
$fixture=static function($pre,$args,$url)use(&$calls,&$cost,&$grows,$account){
 if(str_starts_with($url,home_url().'/'))return $pre;$calls++;
 $i=is_string($args['body']??null)?json_decode($args['body'],true):($args['body']??[]);
 if(str_contains($url,'/token'))$r=['access_token'=>'synthetic-core023','expires_in'=>3600];
 elseif(str_contains($url,'googleAds:search')){
  preg_match("/segments.date = '([0-9-]+)'/",$i['query'],$m);$customer=['id'=>$account,'currencyCode'=>'BRL','timeZone'=>'America/Sao_Paulo'];
  if(!$m)$r=['results'=>[['customer'=>$customer]]];
  else{$row=['customer'=>$customer,'segments'=>['date'=>$m[1]],'campaign'=>['id'=>'1','name'=>'Synthetic'],'metrics'=>['costMicros'=>$cost,'clicks'=>'3','impressions'=>'10','conversions'=>1]];
   if(str_contains($i['query'],'click_view'))$row+=['adGroup'=>['id'=>'2','name'=>'Synthetic'],'clickView'=>['resourceName'=>'customers/'.$account.'/clickViews/'.$m[1].'~exact-gclid-023','gclid'=>'exact-gclid-023','keywordInfo'=>['text'=>'keyword fixture','matchType'=>'EXACT']]];
   $r=['results'=>[$row]];}
 }elseif(str_contains($url,'searchAnalytics/query')){$rows=[];for($n=$i['startRow'];$n<min($grows,$i['startRow']+$i['rowLimit']);$n++)$rows[]=['keys'=>[$i['startDate'],home_url('/fixture'),'synthetic query '.$n],'clicks'=>2,'impressions'=>10,'ctr'=>0.2,'position'=>3];$r=['rows'=>$rows,'responseAggregationType'=>'byPage'];}
 else return new WP_Error('fixture_external_denied','External request blocked.');
 return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($r)];
};add_filter('pre_http_request',$fixture,9999,3);
O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::GA_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ads'=>'read','gsc'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic023',O::OAUTH_REFRESH_TOKEN=>'synthetic023',O::ADS_DEVELOPER_TOKEN=>'synthetic023']);
verifyLab('Core proposed options present in actual catalog',isset(F3Base_Options::catalogo()['f3base_google_ads_acervo'],F3Base_Options::catalogo()['f3base_gsc_consultas']));
verifyLab('Core proposed abilities registered',wp_get_ability('f3base/google-ads-acervo-ler')!==null&&wp_get_ability('f3base/gsc-consultas-historico')!==null);
raw(F3Base_Google_Acervo::OPTION,['ativo'=>true,'conexao'=>'default','conta_id'=>$account,'revisao'=>1]);
verifyLab('Core reader configured and SDK discovered',F3Base_Google_Acervo::configuracao()['ready']&&F3Base_Google_Acervo::status()['registrado'],F3Base_Google_Acervo::status());
$end=(new DateTimeImmutable('yesterday',new DateTimeZone('America/Sao_Paulo')))->format('Y-m-d');$start=(new DateTimeImmutable($end))->modify('-29 days')->format('Y-m-d');$query=['de'=>$start,'ate'=>$end,'dataset'=>'campaign'];
$n=$calls;verifyLab('Core ungranted local reader refuses without HTTP',!F3Base_Google_Acervo::consultar($query)['ok']&&$calls===$n);
$r=Archive::configure(['account_id'=>$account,'enabled'=>true,'datasets'=>['campaign','clicks'],'expected_revision'=>Settings::revision()]);verifyLab('Core test explicit collection grant',$r['success'],$r);
$r=Ads::configure(['consumer_id'=>'base-site-core-fator3','account_id'=>$account,'enabled'=>true,'datasets'=>['campaign','clicks'],'expected_revision'=>Settings::revision()]);verifyLab('Core test explicit reader grant',$r['success'],$r);
for($n=0;$n<30;$n++){$d=(new DateTimeImmutable($start))->modify('+'.$n.' days')->format('Y-m-d');$r=Archive::collect(['account_id'=>$account,'dataset'=>'campaign','date'=>$d]);verifyLab('Core day collected '.$n,$r['success']&&$r['state']==='complete',$r);}
$sum=0;$clicks=0;$days=[];$cursor=null;$n=$calls;
do{$r=F3Base_Google_Acervo::consultar($query+($cursor?['cursor'=>$cursor]:[]));verifyLab('Core actual consumer reads daily revision '.count($days),$r['ok']&&$r['moeda']==='BRL'&&$r['cobertura']['archived']&&count($r['linhas'])===1,$r);$days[]=$r['data'];$sum+=(int)$r['linhas'][0]['cost_micros'];$clicks+=(int)$r['linhas'][0]['clicks'];$cursor=$r['proximo_cursor'];}while($cursor&&count($days)<=30);
verifyLab('Core 30 days have correct costs clicks dates and zero supplier calls',count(array_unique($days))===30&&$sum===30000000&&$clicks===90&&$cursor===null&&$calls===$n);
$cost='2500000';$r=Archive::collect(['account_id'=>$account,'dataset'=>'campaign','date'=>$end,'refresh'=>true]);$r=F3Base_Google_Acervo::consultar(['de'=>$end,'ate'=>$end,'dataset'=>'campaign']);verifyLab('Core revisitation replaces rather than adds',count($r['linhas'])===1&&$r['linhas'][0]['cost_micros']==='2500000');
$r=Archive::collect(['account_id'=>$account,'dataset'=>'clicks','date'=>$end]);$r=F3Base_Google_Acervo::consultar(['de'=>$end,'ate'=>$end,'dataset'=>'clicks','gclid'=>'exact-gclid-023']);verifyLab('Core exact GCLID with keyword and no invented term',$r['ok']&&count($r['linhas'])===1&&$r['linhas'][0]['keyword']==='keyword fixture'&&$r['linhas'][0]['search_term']===null);
$r=F3Base_Google_Acervo::consultar(['de'=>$end,'ate'=>$end,'dataset'=>'clicks','gclid'=>'EXACT-gclid-023']);verifyLab('Core does not fuzzy join GCLID',$r['ok']&&$r['linhas']===[]);

// Persist the exact click in both a measured session and a contact. No user identity is sent to Google.
$session=bin2hex(random_bytes(16));$visitor=bin2hex(random_bytes(16));$id=bin2hex(random_bytes(16));$at=strtotime($end.' 12:00:00 UTC');$attr=['gclid'=>'exact-gclid-023','utm_source_platform'=>'google_ads'];
$wpdb->insert(F3Base_Sessoes::tabela(),['classe'=>'nao_marcado','sessao'=>$session,'visitante'=>$visitor,'inicio'=>$at,'primeira'=>$at,'ultima'=>$at,'origem'=>wp_json_encode($attr),'atualizado_em'=>time()]);
$wpdb->insert(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id,'captura'=>'aceito','metodo'=>'formulario','classe_trafego'=>'nao_marcado','criado_em'=>$end.' 12:00:00','atualizado_em'=>$end.' 12:00:00','dados'=>wp_json_encode(['atribuicao'=>$attr]),'anexos'=>'[]']);
for($z=0;$z<3;$z++)F3Base_Google_Acervo::enriquecer();
$ss=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE sessao=%s',F3Base_Sessoes::tabela(),$session),ARRAY_A);$ll=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s',F3Base_Leads_Repositorio::tabela(),$id),ARRAY_A);
$found=F3Base_Google_Acervo::projecao($ss['google_ads']);verifyLab('337 session persisted exact click',($found['codigo']??'')==='encontrado'&&$found['clique']['keyword']==='keyword fixture',$found);verifyLab('337 contact persisted same click',F3Base_Google_Acervo::projecao($ll['google_ads'])['clique']===$found['clique']);
$present=F3Base_Sessao_Contexto::enriquecer([['sessao'=>$session,'classe_trafego'=>'nao_marcado']]);verifyLab('337 session projection',$present[0]['google_ads']['codigo']==='encontrado');
// Actual GSC1.1 grant; the collector stages short pages and publishes only after explicit completion.
raw('f3base_gsc_property',home_url('/'));$base=F3Base_Options::ler('f3base_gsc');$base['ativo']=true;raw('f3base_gsc',$base);F3Base_Gsc::validar_propriedade();
$gd=(new DateTimeImmutable('today',new DateTimeZone('America/Los_Angeles')))->modify('-3 days')->format('Y-m-d');
raw('f3base_gsc_consultas',['ativo'=>true,'horario'=>'05:00','inicio'=>$gd,'revisao'=>1]);raw('f3base_gsc_consultas_estado',[]);
verifyLab('342 query reader ready',F3Base_Gsc_Consultas::configuracao()['ready']);$before=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Gsc_Acervo::tabela());
$r=F3Base_Gsc_Consultas::coletar();verifyLab('342 explicit grant required',empty($r['ok']),$r);raw('f3base_gsc_consultas_estado',[]);$wpdb->query('DELETE FROM '.F3Base_Gsc_Consultas_Acervo::tabela());
$r=Gsc::configure(['contract'=>Gsc::CONTRACT,'consumer_id'=>'base-site-core-fator3','enabled'=>true,'expected_revision'=>Settings::revision()]);verifyLab('342 explicit GSC grant',$r['success'],$r);
$r=F3Base_Gsc_Consultas::coletar();verifyLab('342 short page committed as partial',!empty($r['ok'])&&!empty($r['parcial']),$r);
$r=F3Base_Gsc_Consultas_Acervo::consultar(['de'=>$gd,'ate'=>$gd]);verifyLab('342 partial not visible',$r['ok']&&$r['linhas']===[],$r);
$r=F3Base_Gsc_Consultas::coletar();verifyLab('342 final empty page publishes',!empty($r['ok'])&&$r['codigo']==='dia_publicado',$r);
$r=F3Base_Editorial_Relatorios::consultar(['visao'=>'gsc','gsc_escopo'=>'consultas','de'=>$gd,'ate'=>$gd,'pagina_url'=>home_url('/fixture'),'consulta'=>'synthetic query 1']);verifyLab('342 editorial query filter with metrics',count($r['linhas']??[])===1&&(float)$r['linhas'][0]['cliques']===2.0&&$r['consultas_anonimas']['quantidade']===null,$r);
$hist=wp_get_ability('f3base/gsc-historico')->execute(['escopo'=>'consultas','dia'=>$gd]);verifyLab('342 public history independent',!is_wp_error($hist)&&count($hist['linhas']??[])===1&&$hist['linhas'][0]['escopo']==='consultas',$hist);verifyLab('342 legacy archive unchanged',(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Gsc_Acervo::tabela())===$before);
$last=F3Base_Gsc_Consultas_Acervo::historico(['dia'=>$gd])['linhas'][0];$wpdb->update(F3Base_Gsc_Consultas_Acervo::tabela(),['atualizado_em'=>time()-86400],['id'=>$last['id']]);$grows=1;F3Base_Gsc_Consultas::coletar();F3Base_Gsc_Consultas::coletar();$r=F3Base_Gsc_Consultas_Acervo::consultar(['de'=>$gd,'ate'=>$gd]);verifyLab('342 revisit replaces published slice',count($r['linhas'])===1,$r);
Ads::configure(['consumer_id'=>'base-site-core-fator3','account_id'=>$account,'enabled'=>false,'expected_revision'=>Settings::revision()]);$n=$calls;verifyLab('337 revoked grant hides persisted observation',F3Base_Google_Acervo::projecao($ss['google_ads'])['codigo']!=='encontrado'&&$calls===$n);
wp_set_current_user(0);verifyLab('Google anonymous denied',F3Base_Google_Acervo::consultar($query)['codigo']==='sem_permissao');wp_set_current_user(1);
$wpdb->delete(F3Base_Sessoes::tabela(),['sessao'=>$session]);$wpdb->delete(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id]);remove_filter('pre_http_request',$fixture,9999);evidence('request-337-340-342');
