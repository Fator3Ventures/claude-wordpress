import os,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1]
env=dict(os.environ,F3BASE_LAB_DB='core_1611_dev')
for mode in ['install','migrate','finalize','status']:
 x=subprocess.run([str(r/'build/php'),str(r/'tests/cycle-1370.php'),mode],env=env,capture_output=True,text=True)
 print(mode,x.returncode,x.stdout[-1800:],x.stderr[-2500:],flush=True)
 if x.returncode:raise SystemExit(x.returncode)
