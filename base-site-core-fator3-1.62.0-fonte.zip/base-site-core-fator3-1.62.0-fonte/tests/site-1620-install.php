<?php
define('WP_INSTALLING',true);$_SERVER['HTTP_HOST']='example.invalid';$_SERVER['REQUEST_URI']='/';require getenv('F3BASE_SITE');
global $wpdb;if(!preg_match('/^f3qa1620_[a-f0-9]{12}_$/D',$wpdb->prefix)||WP_HOME!=='https://example.invalid')throw new RuntimeException('unsafe_fixture:prefix='.(int)preg_match('/^f3qa1620_[a-f0-9]{12}_$/D',$wpdb->prefix).':home='.(int)(WP_HOME==='https://example.invalid'));
require_once ABSPATH.'wp-admin/includes/upgrade.php';if(!is_blog_installed())wp_install('Site de teste isolado','admin','qa@example.invalid',true,'',wp_generate_password(40));
wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/plugin.php';$r=activate_plugin('base-site-core-fator3/base-site-core-fator3.php');if(is_wp_error($r))throw new RuntimeException('activation_failed');
foreach(['f3base_ler_leads','f3base_gerir_leads'] as $cap)get_role('administrator')->add_cap($cap);
$expected=['wp-mcp-fator3'=>'0.37.0','wp-mcp-google-fator3'=>'0.24.0','wp-mcp-meta-fator3'=>'0.16.0','wp-mcp-linkedin-fator3'=>'0.13.0','wp-mcp-pipedrive-fator3'=>'0.4.0'];$companions=[];
foreach($expected as $slug=>$version){
 $file=$slug.'/'.$slug.'.php';$headers=get_file_data(WP_PLUGIN_DIR.'/'.$file,['version'=>'Version']);if(($headers['version']??'')!==$version)throw new RuntimeException('companion_version_mismatch_'.$slug);
 if($slug==='wp-mcp-pipedrive-fator3'&&version_compare(PHP_VERSION,'8.3.36','<')){$companions[$slug]=['version'=>$version,'active'=>false,'reason'=>'php_below_8.3.36'];continue;}
 $a=activate_plugin($file);if(is_wp_error($a))throw new RuntimeException('companion_activation_failed_'.$slug);$companions[$slug]=['version'=>$version,'active'=>true];
}
if(F3BASE_PLUGIN_VERSAO!=='1.62.0'||F3Base_Config_Contrato::VERSAO!=='8.27.0')throw new RuntimeException('wrong_core_version');
Fator3\McpFiles\Persistence::put('connections','integration:user:1',['connection_id'=>'integration:user:1','user_id'=>1,'status'=>'active','profile'=>'maintenance','abilities'=>[],'policy_version'=>1,'expires'=>0]);
echo wp_json_encode(['wp'=>get_bloginfo('version'),'php'=>PHP_VERSION,'version'=>F3BASE_PLUGIN_VERSAO,'contract'=>F3Base_Config_Contrato::VERSAO,'cycle'=>F3Base_Instalacao::atualizar(),'ready'=>F3Base_Atualizacao::pronta(),'companions'=>$companions]);
