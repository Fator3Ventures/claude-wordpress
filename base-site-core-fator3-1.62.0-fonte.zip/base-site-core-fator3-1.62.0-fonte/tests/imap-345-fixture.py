import json,socket,sys
spec=json.load(open(sys.argv[1])); server=socket.socket();server.bind(('127.0.0.1',0));server.listen(1);print(server.getsockname()[1],flush=True)
with server.accept()[0] as client:
 client.settimeout(5);reader=client.makefile('rb');commands=[]
 try:
  for expected,response in spec['steps']:
   line=reader.readline().decode().strip();commands.append(line);tag,cmd=line.split(' ',1)
   if cmd!=expected:client.sendall((tag+' NO unexpected command\r\n').encode());break
   client.sendall(response.encode()+(tag+' OK done\r\n').encode())
 finally:json.dump(commands,open(spec['log'],'w'))
server.close()
