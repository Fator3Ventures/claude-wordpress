<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
if(!class_exists('Fator3\McpFiles\Persistence')){activate_plugin('wp-mcp-fator3/wp-mcp-fator3.php');}
Fator3\McpFiles\Persistence::put('connections','integration:user:1',['connection_id'=>'integration:user:1','user_id'=>1,'status'=>'active','profile'=>'maintenance','abilities'=>[],'policy_version'=>1,'expires'=>0]);
foreach(['wp-mcp-fator3','wp-mcp-google-fator3','wp-mcp-meta-fator3','wp-mcp-linkedin-fator3'] as $slug){$r=activate_plugin($slug.'/'.$slug.'.php');check(!is_wp_error($r),'activate_'.$slug);}
// Synthetic disposable database only: explicit CLI profile for public ability tests.
evidence('companions');
