<?php
/** Activate only the immutable current companions in the isolated fixture. */
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
$expected=['wp-mcp-fator3'=>'0.37.0','wp-mcp-google-fator3'=>'0.24.0','wp-mcp-meta-fator3'=>'0.16.0','wp-mcp-linkedin-fator3'=>'0.13.0'];
if(is_file(WP_PLUGIN_DIR.'/wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php'))$expected['wp-mcp-pipedrive-fator3']='0.4.0';
$result=[];foreach($expected as $slug=>$version){
 $file=$slug.'/'.$slug.'.php';$headers=get_file_data(WP_PLUGIN_DIR.'/'.$file,['version'=>'Version']);check(($headers['version']??'')===$version,'version_'.$slug);
 if($slug==='wp-mcp-pipedrive-fator3'&&version_compare(PHP_VERSION,'8.3.36','<')){deactivate_plugins($file,true);$result[$slug]='inactive_php_below_8.3.36';continue;}
 $ok=activate_plugin($file);check(!is_wp_error($ok),'activate_'.$slug);$result[$slug]='active';
}
echo wp_json_encode(['next_request'=>$result,'php'=>PHP_VERSION])."\n";
