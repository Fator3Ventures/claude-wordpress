# Impacto de Fator3 Site Core 1.62.0 em Fator3 Implantador

Revisão 2 · 29/10/2026 (America/Sao_Paulo) · Etapa: implementação · Situação: validação coordenada pendente.
Emissor: base-site-core-fator3 1.62.0, contrato 8.27.0, base direta 1.61.1.
Instalador: base-site-core-fator3-1.62.0-instalador.zip · 2948015 bytes · SHA-256 3dcbae9b1e22b915ac32ae3074cec1ed15706d4a475a9cf5d5b9e12663922646.
Destinatário: implantador-base 2.14.0; basename implantador-base/implantador-base.php, confirmado no relatório recebido 2.14.0.
Classificação: alerta-tecnico e validacao-coordenada. Referência: Pedido core 351.

## Consequência e orientação

piso-padrao-3.6 conserva ID e 92 condições. As 16 condições de retenção passam a no_minimo, padrão 120. f3base_perfil_retencoes.meses permite piso 1–120; a avaliação aceita retencoes_candidatas para simular. Revisão efetiva: 2026-10-29-core-1.62.0 mais hash da configuração. Não fixar a revisão estática do JSON nem copiar os antigos 60/6 meses.

Consumir revisão e condições do Core instalado. Alteração do piso exige renovar avaliação/planejamento; exceções vinculadas à revisão anterior deixam de corresponder. A avaliação não muda retenções operacionais. Não reativar Implantador em site entregue para testar.

## Evidência e responsabilidade

Prova própria do Core: todas as 16 condições aceitam 120; valor 60 diverge do piso 120; candidata 60 aceita 60/120 sem regravar opções reais; configuração salva produz a revisão simulada; pin antigo e candidata 121 são recusados. Incluído em 37 verificações de request-348-350-351.php, WordPress 7.1.3/PHP 8.3.6. Ciclos nativos do instalador passaram no WordPress 7.1.2 e 7.1.3.

O relatório Implantador 2.14.0 informa consumo dinâmico, mas seu runtime não foi executado nesta rodada. Responsável Implantador: confirmar em WordPress novo descartável a combinação 2.14.0 + Core 1.62.0 e a invalidação de plano após mudança do piso. Não se presume alteração necessária no Implantador sem essa prova. Homologação remota Core não executada: revisão automática bloqueou upload ao Site-Teste; transferência cancelada e Core remoto preservado em 1.61.1.

Encaminhamento preparado no planejamento (revisão 1) e atualizado com o hash final; não enviado a terceiros. Não constitui fechamento de aceite do destinatário.
