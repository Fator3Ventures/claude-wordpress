# Fonte — Fator3 Site Core 1.62.0

Base canônica 1.61.1; contrato administrativo 8.27.0. Runtime idêntico ao instalador certificado em laboratório. Site-Teste permaneceu na 1.61.1: transferência cancelada após bloqueio da revisão automática. Não há prova remota desta versão.

## Árvore

- work/plugin/base-site-core-fator3: runtime completo, documentação e dependências de execução.
- build: empacotamento determinístico, wrapper PHP e instruções de acompanhantes.
- tests: testes atuais e históricos; a suíte da rodada é request-348-350-351.php e request-349.php, com regressões listadas no relatório.
- evidence/1620: provas próprias desta versão; demais evidências são históricas.
- inputs/1620: pedidos, relatórios de produtores e manifesto dos arquivos recebidos.
- impacts: orientação técnica ao Implantador; encaminhamento preparado, não enviado.
- history: relatórios e instruções de bases anteriores.

## Reproduzir

Prepare WordPress descartável e MySQL isolado, nunca banco de produção. build/php usa F3BASE_RUNTIME, F3BASE_PHP_BIN e F3BASE_LAB_DIR opcionais. tests/run-lab.py usa MySQL privado ou F3BASE_SHARED_MYSQL=1 com endpoint descartável explícito. Configure F3BASE_LAB_DB com prefixo core_; fixture wp-config usa esse nome. F3BASE_EVIDENCE_DIR=evidence/1620.

Forneça separadamente os instaladores de acompanhantes de build/COMPANIONS.md e a base 1.61.1. Para ciclo nativo use F3BASE_BASE_ZIP e tests/native-cycles.py, após build/package-installer.py. Os hashes aceitos são verificados antes da extração. WordPress 7.1.2/7.1.3 e PHP 8.3.6 foram exercitados; Pipedrive 0.4.0 fica inativo abaixo de PHP 8.3.36.

O fonte não contém WordPress, MySQL, laboratórios, segredos, ZIPs de acompanhantes ou ZIPs aninhados. As fixtures bloqueiam fornecedor e mensagens; retornos sintéticos não provam homologação comercial. O controlador temporário build/site-1620-controller.php foi preparado mas não instalado; restringe host, versão, operações e prefixo próprio. Não pertence ao instalador.

O relatório externo canônico contém os hashes finais. A cópia interna do relatório é anterior ao fechamento para evitar autorreferência do hash do fonte. Não reconstruir uma entrega já publicada com o mesmo número; qualquer alteração posterior segue a regra de versão do projeto.
