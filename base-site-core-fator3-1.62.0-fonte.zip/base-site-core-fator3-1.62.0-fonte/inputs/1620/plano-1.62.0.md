# Plano — Fator3 Site Core 1.62.0

29/10/2026, America/Sao_Paulo. Base 1.61.1, instalador SHA-256 9cfbab0b667c877c3c14b9d6704c827665d20d7b34ff4c9b9d915d6b3c9bd6d3. Alvo previsto 1.62.0, contrato administrativo 8.27.0. Instalador-alvo ainda não gerado.

- 348: casar somente variações/domínios, ignorando caixa mas distinguindo acentos e usando fronteiras Unicode; resolver sobreposições por comprimento, desempate pela ordem da configuração. Rótulo não participa. Revisão do algoritmo invalida fotografias anteriores sem apagar histórico.
- 349: configuração própria permite/desliga conta Meta selecionada e nome do acervo. Enriquecer somente contatos novos elegíveis, com consentimento, identidade e fonte congeladas. Nomes da URL e mapas explícitos têm precedência. SDK Meta público, local e concedido; nenhuma opção privada do produtor. Leitura limitada e completa, sem escolher nome em paginação incompleta ou identidade ambígua. Recibo/journal da campanha preserva fonte/revisão. Simulação administrativa sem gravar contato/CRM.
- 350: projeção pública canal_codigo (canal_chave também é redigido pelo MCP 0.37.0); armazenamento interno chave preservado. Simulador, registros e prévia CRM cobertos pelo transporte MCP real.
- 351: atualizar revisão do perfil piso-padrao-3.6 sem quebrar seu ID. Piso de retenção configurável com simulação; padrão 120 meses e comparação por mínimo. Avaliar perfil não altera retenções operacionais. Revisão efetiva muda com o piso para invalidar planos/exceções antigos.

Matriz: instalação limpa + atualização direta 1.61.1, repetição, mínimos Core; Google 0.24.0/Meta 0.16.0/MCP 0.37.0; contratos, consentimento, grants revogados, dados históricos e inexistência de chamadas reais nos testes. Site-Teste autorizado, fixtures em prefixo/diretório próprios, limpeza ao final. Sem produção, publicação ou mensagens a terceiros.

Impactos: Implantador 2.14.0 consome o perfil público 3.6, conforme relatório examinado; alertar para revisão dinâmica/piso. Não identificado pedido de mudança no runtime dos produtores Google/Meta/MCP/Pipedrive/LinkedIn; novas provas de consumo permanecem próprias do Core, não geram respostas de impacto sem consequência técnica.
