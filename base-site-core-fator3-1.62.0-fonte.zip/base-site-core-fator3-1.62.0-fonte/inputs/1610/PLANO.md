# Plano — Fator3 Site Core 1.61.0

Data: 29/10/2026. Etapa: implementação. Base imutável: 1.60.0, instalador SHA-256 `1dc4e94305ea55394024d6527bc06b46209f0ae51a55f734853763bcb232e27c`; fonte SHA-256 `afdac358331e3894480b59fc8b57cc411909d3c7b399a6f998c996b35e7d25fe`. Instalador alvo ainda não gerado.

Entrada: `pedidos-core-20261029.md`, itens 335–347 e as duas regras do dono de 28/10. A norma revisão 5 de 23/10, já incluída na base, permanece vigente; os avulsos revisão 4 de 16/10 não a substituem por uma revisão anterior.

## Escopo e sequência

1. Corrigir contrato de conversões e diagnóstico de falhas (335); publicar metadados de credenciais e revisão fora do filtro do canal (347).
2. Capturar contexto de sessão no pedido de medição, com permissão de dados pessoais, filtros e retenção máxima (336); acrescentar catálogo configurável de WebViews e classificação de rede com fonte/revisão (339).
3. Contar presença de parâmetros pagos nos logs, sem valores, por dia/caminho/classe (338).
4. Contar respostas fechadas dos catálogos nativos (344); regras orgânicas configuráveis, simulação e catálogo de IA extensível (346).
5. Recibo de entrega ao CRM e atividades, sem reconstruir valores históricos inexistentes (343); recepção parcial de mensagens grandes sem baixar anexos (345).
6. Documentar dependências ainda não publicadas de Google e Meta (337, 340, 341, 342), antes de implementar qualquer consumidor dependente. Não substituir SDK concedido por acesso a opções privadas ou por consulta remota na cota de um agente.
7. Atualizar contrato administrativo, schemas, inventários e ajuda instalada. Testar casos positivos, falhas, permissões, consentimento, retenção, idempotência e preservação de dados. Gerar e validar instalador exato em instalação limpa e atualização direta 1.60.0 → 1.61.0, e no Site-Teste autorizado. Pipedrive real segue restrito a ctooffice.com.br/korvena.com.br; fixtures locais não equivalem a aceite de frota.

## Pacotes e fronteiras

Base disponível: MCP 0.36.0, Google 0.22.0, Meta 0.14.0, LinkedIn 0.12.0, Pipedrive 0.3.0, todos ativos no Site-Teste ao início da rodada. Google 0.22.0 publica SDK de GSC página/dia e GA4; não publica acervo de clique, Ads/histórico ou consulta/página/dia. Meta 0.14.0 publica Ads reader, não histórico de alterações nem qualidade diária do dataset. Encaminhamentos próprios emitidos nesta etapa aos responsáveis Google e Meta. O restante do Core continua autônomo.

O pedido 343 exige prova específica do e-mail no histórico: crescimento de contador de mensagens não prova a mensagem. Se o contrato disponível não permitir correlação confiável, o recibo deve informar `nao_conferido`, com motivo, e a dependência deve ser encaminhada; nunca inventar `confirmado`.

## Guardas

Não alterar pacotes acompanhantes, normas centrais, documentos externos de frota ou produção. Listas/regras novas são configuração revisionada com simulação; efeitos registram revisão. Detecção de mídia paga e validação de identificadores permanecem guardas de código. IP/agente não são retropreenchidos nem expostos sem `f3base_ler_leads`. Classe de rede desconhecida não é automação. Dados indisponíveis não são zero. Falha de contexto não é destino incompleto. Preservar configuração e máximo de retenção do pacote.


Reconferência: Site-Teste com MCP 0.37.0, Google 0.22.0, Meta 0.14.0, LinkedIn 0.13.0 e Pipedrive 0.4.0. Os instaladores/fonte novos foram conferidos e seus hashes estão em pacotes-reconferidos.json. Nenhum pacote acompanhante foi alterado.
