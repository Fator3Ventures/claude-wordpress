# Entrega — Fator3 MCP Google 0.23.0

Revisão 1 — 29/10/2026, America/Sao_Paulo. Implementação dos Pedidos MCP Google 43–46. **Versão corrente: 0.23.0, instalada e ativa no Site-Teste. Apta no escopo testado, com pendências de homologação Ads/GSC e incorporação Core.** Não houve publicação GitHub/feed nem instalação na frota.

## 1. Bases aceitas e entradas

Instalação limpa ou atualização direta da **0.22.0**, sem versão intermediária e sem desinstalar. Preservados slug `wp-mcp-google-fator3`, basename, provider, namespaces, Text Domain e Update URI. A base publicada permaneceu imutável.

| Base Google | Bytes | SHA-256 |
|---|---:|---|
| wp-mcp-google-fator3-0.22.0-instalador.zip | 856534 | `a84754409f89b7b9c7367c1d261c44ef93c2f6039b379c3ec5c6242ec7188ebd` |
| wp-mcp-google-fator3-0.22.0-fonte.zip | 5989075 | `1d9ba106eb9ababad67b964fa4ad44246acc27eeda3e83e7866ea57386d77abf` |

Entrada funcional: `Fator3 MCP Google(20261029-030442).md`, pedidos abertos 43–46. Normas 01/02 revisão 5 presentes no Core 1.60 prevalecem sobre cópias avulsas r4. Plano `docs/PLANO-023.md` e impacto Core emitidos antes da implementação da fronteira. Os relatórios e fontes anexados foram considerados, com CRC e identidade dos ZIPs conferidos; inventário completo em `evidence/023/received.json`.

Durante a execução apareceram o impacto de planejamento Core 1.61→Google e o relatório MCP 0.37, ambos lidos integralmente e preservados em `reproducao/entradas`. Core 1.61 ainda é alvo previsto nesse documento; não foi tratado como instalador recebido. O relatório MCP 0.37 identifica mudança funcional no parser de logs, sem alteração de contrato Google. Sua prova recebida não é somada aos testes próprios.

## 2. Convivência e encaminhamentos

| Instalador original usado na bancada | Bytes | SHA-256 |
|---|---:|---|
| Core 1.60.0 | 2842430 | `1dc4e94305ea55394024d6527bc06b46209f0ae51a55f734853763bcb232e27c` |
| MCP 0.36.0 | 910233 | `97648853e16d7c7fca811c6be22323244c5f2ebc3e296c22564ce7b2739cb98b` |
| Meta 0.14.0 | 286331 | `43e8947ac0ffaf3da52c62b0515db826e6df266553d64f5561c0d3b87b7eb318` |
| LinkedIn 0.12.0 | 304948 | `19748e788190f371809db469a6de052a645e25f39fad1672606dc776234ec54c` |

No Site-Teste, o inventário inicial mostrou **Core 1.60 / MCP 0.37 / Meta 0.14 / LinkedIn 0.13 / Pipedrive 0.4**. No inventário de fechamento, Meta já estava na **0.15.0**, por alteração concorrente externa a esta sessão; os demais acompanhantes mantiveram essas versões e todos estavam ativos. Somente Google 0.22→0.23 foi trocado por esta sessão. A observação de versão/ativação não é inventário byte a byte dos acompanhantes. Não foi obtido um relatório exato Meta 0.15 nesta rodada; seu código não integra a bancada. A matriz local não é atribuída às versões remotas mais novas. Pipedrive fica no inventário, sem ensaio local ou redução de seu mínimo PHP.

Não foi imposto mínimo ou ordem artificial aos acompanhantes. Google pode entrar antes dos novos consumidores: coleta/concessões permanecem desativadas até autorização explícita. Sem o produtor/contrato, o adaptador Core apresenta indisponibilidade. Foram exercitados Google primeiro e Google isolado.

**Encaminhamento desta rodada:** `wp-mcp-google-fator3-0.23.0-impacto-base-site-core-fator3.md`, revisão 1, planejamento, `acao-necessaria`/`validacao-coordenada`, demanda aberta, Core 337/340/342. Define os novos contratos, concessões, preservação, cobertura e responsabilidades. Foi conservado sem revisão meramente para anunciar conclusão ou hash. A identidade final do software está neste relatório.

| Documento/pedido anterior ou recebido | Resultado desta rodada | Responsável e evidência |
|---|---|---|
| Core 1.58→Google, Core 323; Google 0.22→Core | Reconciliação comercial já incorporada na base Core 1.59 e preservada na 1.60; patch histórico não reaplicado. | Código Core 1.60 examinado, relatório recebido e regressão `requests022` com consumidor real/HTTP sintético. `integration/core323` é histórico. |
| `base-site-core-fator3-1.61.0-impacto-wp-mcp-google-fator3.md`, r1 | Produtor/SDK solicitado entregue nesta 0.23. Acrescentada distinção entre ausência de arquivo, coleta incompleta e revisão anterior preservada. Identidade final do consumidor proposto: `base-site-core-fator3`, em vez de presumir o nome ilustrativo `site-core`. | Google 43–46 e 70 verificações por rodada. Dependência técnica do produtor fornecida; incorporação e aceite Core 337/340/342 continuam com o mantenedor Core. |
| Core 1.60, Meta 0.14 e MCP 0.36/0.37 | Alterações pertinentes de autorização, credenciais e auditoria consideradas; nenhum novo contrato obrigatório solicitado a esses pacotes por esta release. | Relatórios/código anexados e convivência descrita. Aceites de terceiros não repetidos nem declarados próprios. |

Conforme autorização do dono para não esperar o Core, foram implementados leitores auxiliares em `integration/core337-340-342`, com registro, configuração inativa, permissões administrativas, consulta Ads local por intervalo/GCLID e leitor GSC 1.1. São três PHP, README e testes sobre Core 1.60 original, carregados por harness próprio da bancada. **Não constituem release oficial Core, não foram instalados remotamente e não encerram todo o enriquecimento de contatos, UI ou histórico Core 337/340/342.** O mantenedor deve incorporá-los e completar seu escopo funcional. Não houve mensagem a terceiros.

## 3. Mudanças por pedido e evidência

**Google 43 — implementado, validado localmente/WordPress e recusa homologada no fornecedor.** Project ID vazio, key ID fora de 40 caracteres hexadecimais, e-mail fora do domínio usual e cabeçalho PEM diferente geram avisos com código/motivo. A troca JWT remota decide, sem substituir a chave salva quando recusada. JSON/tipo inválidos, ausência de campos obrigatórios, URI fora do host HTTPS permitido e chave ilegível pelo OpenSSL permanecem bloqueios locais. Resposta e feedback administrativo contêm somente códigos/motivos. Testes incluem PEM PKCS#1 legível, host malicioso, autenticação fresca e preservação de chave/candidata/revisão.

**Google 44 — implementado e validado em WordPress com fornecedor sintético.** Coleta diária explícita por conta anunciante, ontem/revisitas/backfill, `click_view` e acervo cifrado permanente. Preserva GCLID, conta, campanha, grupo, palavra-chave/correspondência, rede, dispositivo e data. Termo de pesquisa por clique permanece nulo com motivo: a API não fornece essa associação. GCLID não disponibilizado pelo fornecedor permanece nulo e identificado, sem inventar atribuição. SDK `google-ads-reader/1.0.0` lê apenas o acervo, com concessão por consumidor/conexão/conta/datasets, cursor vinculado e zero HTTP.

**Google 45 — implementado e validado em WordPress com fornecedor sintético.** Desempenho por conta/campanha/grupo/anúncio/dia, custo em micros, cliques, impressões, conversões, moeda e fuso; termos agregados; change_event com instante, entidade, operação, campos, valor antigo/novo e autor separado. Revisitas publicam nova fotografia, preservam revisões anteriores e não somam duplicadamente. Limite de 10.000 provoca divisão de intervalos; saturação indivisível de um segundo é parcial. Uma revisão parcial não substitui uma completa e essa preservação é informada ao leitor. O teste consumidor exercita 30 dias e mudança de orçamento sintéticos.

Janelas recuperáveis: cliques de até 90 dias, alterações de até 30 dias corridos (29 dias anteriores completos), métricas diárias de até 37 meses. Backfill configurável de 1 a 1.125 dias, padrão 90; revisita de 1 a 30 dias, padrão 7, sempre limitada pelo fornecedor. Fuso/moeda são confirmados na conta, nunca inferidos. Leitura sem coleta não vira zero. `coverage.archive_state` distingue not_collected/incomplete/published/partial/revisiting; os campos latest_collection e previous_complete_preserved explicam o estado mais recente.

O worker aproveita o evento de minuto existente; até quatro contas e uma página por conta/passagem, sob orçamento cooperativo de 20 s, travas/checkpoints e revalidação de concessões. Erros deferem o recorte de 5 min a 6 h sem bloquear os demais; a próxima passagem retoma. WP-Cron requer tráfego ou disparo pelo servidor. A leitura de status não agenda nem coleta.

**Google 46 — implementado e validado em WordPress com fornecedor sintético.** `search-console-reader/1.1.0`, capability `gsc.query-page-day.read`, dimensões date/page/query, concessão própria vinculada à propriedade/principal/administrador/canal. Contrato 1.0 continua página/dia. Paginação segue até a página vazia observável; cobertura mantém limite de 50.000/dia/tipo e não garante universalmente todas as linhas. Consultas anônimas omitidas são sinalizadas; quantidade/cliques anônimos ficam nulos porque a API não os informa. O resíduo entre totais não é rotulado como contagem exata de anonimização.

**Superfície pública:** 298 habilidades, 114 de leitura e 184 de escrita; 41 opções. Adicionadas ads/archive-status, ads/archive-configure, ads/archive-collect e ads/archive-consumer-grant. Alterações aditivas em google/configure-consumer, google/integration-status e google/configuration-schema; campos obrigatórios existentes preservados. Configuração 4.0.0, execução 2.0.0 e contratos anteriores permanecem. Comparação de runtime: 7 arquivos novos, 14 alterados, nenhum removido; todos descritos em diff-runtime023.json.

## 4. Instalação, testes, documentação e prontidão

**1.279 testes unitários, 15.189 asserções, zero falhas/erros/avisos/pulados.** PHP 8.3.6, PHPUnit 9.6.31 fixado por SHA. **11.293 verificações nativas**, sem somar tentativas preliminares, em WordPress/MySQL reais com HTTP Google sintético:

| Cenário | WordPress | Verificações |
|---|---|---:|
| clean | 7.1.2 | 2899 |
| google-first | 7.1.3 | 1402 |
| isolated | 7.1.2 | 1200 |
| clean-713 | 7.1.3 | 2840 |
| upgrade | 7.1.3 | 2867 |
| core-consumers | 7.1.3 | 85 |

MySQL 8.0.46. Mínimos próprios WP 7.1.2/PHP 8.3.6 comprovados. As 85 verificações Core incluem 4 de montagem do consumidor separado e 81 funcionais. Não confundir checks repetidos em ambientes distintos com integrações comerciais independentes. Há também módulos contratuais isolados, lint dos 168 arquivos PHP / 172 arquivos de runtime e verificação dos geradores/schemas. Evidências finais vinculam candidato, fontes de teste e hashes em `evidence/023/validation023.json`.

Upgrade nativo autenticado pelo MCP, em requisições independentes: 0.22→0.23, preservação de credenciais cifradas, opções/conexões, provas e registros, ausência de concessões automáticas, rollback com recusa de destino editado e reaplicação do mesmo ZIP. Byte inventories dos acompanhantes originais preservados. Autorizações, revogação durante HTTP, GSC 1.0, grants/cursors, calendário/anonimização, cron sem usuário, falha sem impedir outro dataset, revisão parcial e consumo Core passaram. HTML administrativo e DOM/jsdom foram exercitados; não houve revisão visual em navegador.

Na preparação, a suíte antiga que esperava recusa das heurísticas foi atualizada para o novo requisito; corrigiu-se a exposição das operações Ads no catálogo de configuração. A comparação contratual passou a usar a base 0.22 realmente carregada com MCP 0.36, pois o JSON de fonte não inclui a decoração de transporte. Ajustou-se o guia corrente para preservar a orientação de prontidão/stream. Uma tentativa de laboratório falhou por falta de espaço; apenas runtimes descartáveis próprios, parados, foram removidos. Um candidato intermediário foi revalidado após a cobertura pedida pelo impacto Core 1.61. Nenhuma dessas execuções integra os totais finais. Nenhum byte de runtime mudou após a instalação remota.

**Site-Teste:** https://fator3-teste-mcp-1.dreamhosters.com/, via WP MCP fator3-teste. Instalação `plugins/upload-base64`, SHA e slug obrigatórios, activate/overwrite true, chave de idempotência própria. Operação `3581429f38c642e3d90cb002b21be222`, backup `b3d0010f6b9d14970a44c204`, applied/ativo. `/` e `/wp-json/` retornaram 200 antes/depois, com cache bypass verificado. Worker PHP independente confirmou 0.23. Modo silent_reactivation: não se afirma ciclo completo de hook de ativação nem prontidão comercial.

**Pedido 43 no fornecedor:** controlador temporário fixo, só administrador e só Site-Teste/Google 0.23; chave RSA sintética criada em memória, e-mail example.test, nenhuma chave real submetida. O método público de gravação devolveu 3 avisos e `f3_google_credential_rejected/invalid_grant`; o controlador exigiu uma tentativa e HTTP 400 para aprovar. Ausência de private_key: f3_google_sa_invalid e zero HTTP. Estado ativo/candidata/revisão preservados. Nesta instalação a credencial ativa estava ausente; a preservação de uma chave existente também foi testada na bancada. O canal mascarou os campos de telemetria cujo nome contém token; a resposta pública preservou o resultado, avisos e booleanos de conferência. A sonda foi removida por SHA, sem endpoint de execução arbitrária nem chave persistida.

**Documentação instalada:** leitura integral dos 22 documentos pelo MCP, em 83 páginas, total de 4.273.686 bytes UTF-8. Todos os trechos, tamanhos, offsets e revisões SHA-256 coincidiram com a documentação compilada do instalador congelado, inclusive o catálogo de 3.871.540 bytes. Houve falhas transitórias de transporte na leitura paralela do catálogo; foram retomadas apenas as páginas faltantes e concluída a comparação integral. Isso não alterou código ou instalação. Prova: `evidence/023/remote/documents.json`.

**Estado de fechamento remoto:** WordPress 7.1.4, PHP 8.3.36, MCP 0.37.0 e Google 0.23.0 ativo. Armazenamento 2.0.0 pronto, tabelas de registros/cron presentes, manutenção concluída e recuperação sem pausa. Ads continua desabilitado, sem contas concedidas ou credencial Google configurada; status do acervo não fez HTTP. Os quatro contratos de integração foram observados. O arquivo principal tem SHA-256 `745375e4215ccfec7ac77cbfe134e45b3d2b8e322c698a6336ada20763321e19`, idêntico ao instalador. A ausência da sonda foi confirmada. Prévia de rollback: `rollback_ready:true`, `preimage_verified:true`, sem aplicar reversão. Essas provas ficam em `evidence/023/remote`; não equivalem a homologação comercial Ads/GSC.

## 5. Banco, retenção e reversão

Sem DDL ou tabela nova. Três opções por conexão: f3_mcp_google_ads_archive, f3_mcp_google_ads_consumer_grants e f3_mcp_google_query_consumer_grants. Registros cifrados na tabela indexada existente, kinds adsrows/adsjob/adssnapshot/adslatest/adsplan, expiração 0/permanente. Grants não são herdados de conversão nem criados automaticamente. Acervo, revisões anteriores e checkpoints ocupam banco continuamente; dimensionar capacidade e backup.

Faça backup de arquivos, banco e salts. Para voltar à 0.22, pause as novas coletas e consumidores; preserve registros/opções novos, ignorados pela base, e não desinstale. Arquivos antigos não desfazem banco nem efeitos externos anteriores. As coletas novas só leem Google; conversões existentes mantêm recibos/incerteza e não podem ser reenviadas por causa de rollback. O teste local aplicou rollback e reaplicou; remotamente permanece 0.23, com pré-imagem guardada.

## 6. Pendências e limites

- **Operador/frota, Google 44/45/46:** em ctooffice, autorizar as contas e consumidores; comparar GCLIDs de um dia, 30 dias de gasto/cliques por campanha, alteração real de orçamento e consulta/página/dia. Site-Teste não tem credencial Google configurada e não recebeu configuração comercial. Fixtures não encerram esses aceites reais.
- **Mantenedor Core:** incorporar/revisar os consumidores propostos, completar seu histórico/UI/enriquecimento e rodar os gates próprios Core 337/340/342. O produtor oferece o contrato; a homologação Core 1.61 final não foi feita porque nenhum pacote 1.61 foi recebido.
- **Frota:** publicação/distribuição nos demais sites e decisões de concessão. Nenhum push, feed, envio de documento ou mensagem foi executado.
- **Aceites anteriores:** primeira conversão ctooffice aceita com userIdentifiers, próximo incidente real de renovação e credencial real do pedido 36 permanecem conforme a pendência 20 da frota. A atualização não os declara concluídos.
- **Não avaliados:** APIs Ads/GSC com contas reais nesta rodada, navegador visual, multisite, Redis/Memcached, outros runtimes, execução diária prolongada e CDN externo. MCP 0.37, Meta 0.15, LinkedIn 0.13 e Pipedrive 0.4 só convivência/inventário remoto; testes locais pertencem aos pacotes anexados. Não houve gasto Ads, conversão comercial, envio de mensagem ou alteração de dados comerciais.

Não há correção conhecida pendente nos cenários fechados desta versão. Ausência de regressão observada é limitada às provas descritas.

## 7. Credenciais e operação

Tela Ferramentas → Fator3 MCP Google. Service Account: JSON com type/client_email/private_key/token_uri; project_id e private_key_id permanecem metadados e avisos de formato. OAuth continua alternativa, com Client ID/secret/refresh token existentes. Ads requer developer token, conta anunciante e, quando necessário, login_customer_id gerenciador; GSC requer propriedade acessível. Nenhum valor secreto integra a entrega.

Conceda coleta na aba Acervo Ads e leitura separadamente por consumidor/conta/datasets. Autorize GSC 1.1 na aba Search Console; não reutilize implicitamente a concessão 1.0. Consulte google/integration-status compacto para revisão antes de escrever. O guia e ACERVO-ADS-GSC.md contêm exemplos sintéticos, limites, schemas e recuperação. O fonte inclui apenas uma chave de teste gerada para fixtures, sem vínculo com conta real.

## 8. Artefatos finais

| Artefato | Nome exato | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | wp-mcp-google-fator3-0.23.0-instalador.zip | 883618 | `8100b62144f4e368349ed1798c5bd9c84da66028010bc2946281853b982faab8` |
| Fonte | wp-mcp-google-fator3-0.23.0-fonte.zip | 6605227 | `5f043ed6b9435059de4eccdde12e57dc269a70fa771a5cb0b72c03ac157fd4b6` |

Relatório externo canônico: `wp-mcp-google-fator3-0.23.0-relatorio.md`. Complemento: `wp-mcp-google-fator3-0.23.0-impacto-base-site-core-fator3.md`. Instalador é o único ZIP instalável, raiz wp-mcp-google-fator3/, 172 arquivos e 168 PHP. Fonte tem raiz wp-mcp-google-fator3-0.23.0-fonte/, runtime exato, documentos editáveis, build, testes, evidências sanitizadas, reprodução, encaminhamento e consumidores propostos. Nenhum ZIP contém outro ZIP, banco de laboratório ou credenciais reais.

Este é o **relatório externo de fechamento**. O ZIP-fonte contém a cópia anterior ao fechamento do fonte, sem hash circular. Seu tamanho e SHA-256 foram acrescentados somente aqui, sem reabrir ou modificar o ZIP. Após a extração em diretório temporário novo, o build reproduziu o instalador byte a byte e as identidades de runtime/testes permaneceram iguais às validadas. A publicação do fonte permanece decisão do dono.
