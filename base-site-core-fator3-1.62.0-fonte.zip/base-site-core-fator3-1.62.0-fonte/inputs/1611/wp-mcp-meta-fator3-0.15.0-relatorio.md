# Entrega — Fator3 MCP Meta 0.15.0

Revisão 1 — 29/10/2026 — America/Sao_Paulo. Rodada de implementação dos Pedidos MCP Meta 22, 23 e 24. Estado: **apta no escopo testado, com pendências de homologação de dados reais e integração no Core**. Versão corrente do Meta no Site-Teste: **0.15.0**, ativa. Identidade preservada: `wp-mcp-meta-fator3/wp-mcp-meta-fator3.php`.

**Relatório externo canônico.** O fonte contém uma cópia anterior ao seu fechamento. Esta edição externa completa a identidade final do ZIP fonte, sem alterar o arquivo já fechado nem a sua cópia interna.

## 1. Bases aceitas e escopo

Atualização direta suportada e exercitada: **0.14.0 → 0.15.0**. Também foi exercitada instalação limpa, sem depender de passagem por versões anteriores. A base 0.14.0 foi mantida imutável para comparação; suas identidades constam da tabela abaixo. Não há versão intermediária exigida.

Aplicadas as instruções e o padrão comuns **revisão 5, de 23/10/2026**, preservados em `inputs/0.12.0/`, junto da aba de pedidos recebida em 29/10 e dos documentos de Core 1.60.0 e MCP 0.36.0. A regra de impacto da revisão 5 prevalece sobre cópias anteriores reanexadas: respostas e encerramentos ficam neste relatório; o impacto emitido apresenta pedidos técnicos próprios para Core 340/341.

Os Pedidos MCP Meta 20, 23 e 24 autorizam a leitura de anúncios e datasets, complementando a fronteira histórica da regra comum. Escrita em anúncios, Pixel/CAPI, contatos e regras comerciais continuam nos responsáveis existentes. Nenhum pacote alheio ou documento central foi alterado nesta rodada.

### Identidade das bases e entradas

| Arquivo recebido/base | Bytes | SHA-256 |
|---|---:|---|
| `wp-mcp-meta-fator3-0.14.0-instalador.zip` | 286331 | `43e8947ac0ffaf3da52c62b0515db826e6df266553d64f5561c0d3b87b7eb318` |
| `wp-mcp-meta-fator3-0.14.0-fonte.zip` | 2577045 | `917f1f3d4fd0267fcf8b5f160e5b29d2548f67c5a8df9692fe2cbd1eff18c57f` |
| `base-site-core-fator3-1.60.0-fonte(3).zip` | 5106586 | `afdac358331e3894480b59fc8b57cc411909d3c7b399a6f998c996b35e7d25fe` |
| `base-site-core-fator3-1.60.0-instalador(3).zip` | 2842430 | `1dc4e94305ea55394024d6527bc06b46209f0ae51a55f734853763bcb232e27c` |
| `base-site-core-fator3-1.60.0-relatorio(3).md` | 20309 | `311dbc38a929e52c873a73e75c0cb7587fa8799f25b54c279809292ed8fc5fc7` |
| `base-site-core-fator3-1.60.0-impacto-wp-mcp-meta-fator3.md` | 1235 | `a45b93da9e462c358ee9539c72e7da32bc145f8abf11a110dd353aa2709022b6` |
| `wp-mcp-fator3-0.36.0-fonte(4).zip` | 4976576 | `6dab0eeaaab2bb971a17e93bfed150e1af557dae494c1c8940d53bd0ca5d48f6` |
| `wp-mcp-fator3-0.36.0-relatorio(4).md` | 15918 | `8cf5e66d19f0ab239e4d7543e48e1a101603ce074dec7e4a7a33096d002b026f` |
| `wp-mcp-fator3-0.36.0-instalador(4).zip` | 910233 | `97648853e16d7c7fca811c6be22323244c5f2ebc3e296c22564ce7b2739cb98b` |
| `Fator3 MCP Meta(20261029-030549).md` | 7221 | `959fca0ffed1c37b1773d614fb808fe9109852bf85f25dd438c142428fb96b93` |

## 2. Convivência e encaminhamentos

| Contexto efetivamente observado/testado | Core | MCP | Google | LinkedIn | Pipedrive |
|---|---|---|---|---|---|
| Integração isolada com MCP recebido | 1.60.0 | 0.36.0 | 0.22.0 | 0.13.0 | 0.4.0 |
| Integração isolada com MCP então corrente | 1.60.0 | 0.37.0 | 0.22.0 | 0.13.0 | 0.4.0 |
| Imediatamente antes/depois da instalação compartilhada do Meta | 1.60.0 | 0.37.0 | 0.23.0 | 0.13.0 | 0.4.0 |
| Último inventário de arquivos no fechamento | 1.61.0 | 0.37.0 | 0.23.0 | 0.13.0 | 0.4.0 |

O ambiente compartilhado recebeu atualizações independentes durante o trabalho. **Não se atribui ao Meta a troca de Core, MCP, Google, LinkedIn ou Pipedrive.** As árvores de todos os acompanhantes foram idênticas imediatamente antes e depois da instalação do Meta. O Core mudou posteriormente para 1.61.0; essa versão e o Google 0.23.0 têm prova de carregamento/convivência no ambiente compartilhado, sem alegação de execução integral das suítes de integração nessas versões. Os arquivos e os resultados por combinação estão em `evidence/` e nos manifestos `tests/companion-hashes0150-*.json`.

As duas suítes de integração terminaram com 29 verificações aprovadas cada, sem HTTP externo nem e-mail. Exercitaram autorização de leitura/escrita no transporte, revogação, SDK, passagem dos avisos pelo SafeOutput, coordenação de falha sintética sem duplicação e integridade dos acompanhantes. O estado negado do Pipedrive sem autorização no Core foi o resultado esperado; não foi criado acesso automático.

**LinkedIn:** não foi identificado impacto que exija mudança no pacote. A 0.13.0 carregou e respondeu independentemente, com árvore preservada e permissões existentes. Esta é prova de convivência; não é homologação de operações remotas ou Lead Sync no LinkedIn. Não foi gerado arquivo de impacto para ele.

### Tratamento de impacto recebido

Documento: `base-site-core-fator3-1.60.0-impacto-wp-mcp-meta-fator3.md`, Pedido Core 330, emissor Core, destinatários Meta e frota. A revisão de acesso monotônica do consumidor é compatível com `meta-ads-reader/1.0.0`; nenhuma mudança desse contrato foi necessária. A suíte original do Core foi executada com adaptação de bootstrap, versão esperada, destino da evidência e atualização do usuário de teste após mudança de papel: **46/46**, sem fornecedor ou e-mail. O teste de eliminação coordenada com Core 1.60.0 passou em **20/20**.

A primeira atualização do Core que altera a revisão de acesso continua exigindo reconcessão explícita pelo administrador. O documento recebido informa que a frota já fez a reconcessão em korvena; isso é evidência recebida, não ação desta sessão. Não foram criadas concessões reais no Site-Teste nem nos sites de produção. Evidências próprias: `final-current-coreads0150.json` e `final-current-coreprivacy0150.json`.

### Impacto e pedidos emitidos

`wp-mcp-meta-fator3-0.15.0-impacto-base-site-core-fator3.md`, revisão 2, demanda aberta, `acao-necessaria` e `validacao-coordenada`: integrar o novo contrato **meta-ads-monitoring/1.0.0**, com concessão própria, apresentação de atividades/contagens/EMQ e encaminhamento dos avisos pelo Core. A revisão 2 acrescenta orientações técnicas sobre IDs, data de EMQ, atualidade/cobertura dos alertas e revisitas. A revisão 1 está preservada no histórico. O documento foi preparado para entrega ao dono, sem envio a terceiros.

Os Pedidos Core 340/341 não são declarados implementados por esta entrega. No fechamento, `meta/monitoring-consumers` retornou contrato disponível, nenhum consumidor e nenhuma concessão. O leitor de performance antigo permanece independente. Não foi identificado pedido técnico adicional para MCP, Google ou Pipedrive dentro das fronteiras exercitadas; funcionalidades remotas desses pacotes não foram re-homologadas.

## 3. Mudanças por pedido e evidência

### Pedido MCP Meta 22 — avisos e conferência remota

Formatos incomuns passam a avisos em `meta/save-connection`, `meta/rotate-token` e `meta/switch-identity`: token curto, aparência de chave secreta, espaços internos e formato incomum de App ID/Chave Secreta. Espaços ASCII externos são aparados e informados. Cada aviso contém `campo`, `codigo` e `motivo`, sem repetir o valor enviado. Eles aparecem junto do campo no painel e em `avisos` na resposta, inclusive quando a Meta recusa a candidata.

Permanecem validações de entrada indispensável, vazio, controles ASCII/Unicode e limite técnico de 16384 bytes por credencial. Para os tokens ASCII usados pela Graph, bytes e caracteres coincidem. O painel não impõe os antigos padrões de formato. Campo secreto vazio preserva o salvo; remoção explícita mantém seu fluxo. Rascunho sem token continua permitido, mas não constitui conexão validada.

A identidade, o aplicativo, os escopos e os ativos continuam sujeitos a prova remota; avisos não concedem acesso. Troca de identidade exige prévia/confirmação própria, revisão concorrente e atualização atômica das agendas. A recusa mantém a credencial anterior.

Provas: **83/83** no WordPress atual e **83/83** no mínimo, cobrindo formatos nos três caminhos, recusa de aplicativo/identidade/expiração/escopo, concorrência e preservação. Teste DOM: **22/22**. Teste real negativo na Graph: dois valores sintéticos, de 32 hexadecimais e 80 caracteres, chegaram a `/v24.0/debug_token`, receberam HTTP 401/Graph 190 e produziram avisos; as duas verificações passaram, incluindo preservação do registro anterior. A conexão sintética foi removida. Isso comprova o aceite negativo pedido no Site-Teste, não valida uma credencial real.

### Pedido MCP Meta 23 — histórico de atividades

Novo relatório `ads_activity`, canal `ads`, coleta diária no fuso da conta explicitamente selecionada, leitura de `/act_{conta}/activities` incluindo filhos, paginação segura, revisita e carga retroativa. Preserva instante, objeto, evento, autor, aplicativo e detalhe bruto `extra_data`; valores anterior/novo ficam nulos se a origem não os fornecer.

O acervo e as páginas desse relatório são cifrados e sem prazo de expiração, inclusive em conexão com política finita. Como a origem não garante ID único, a identidade local combina os campos do evento e o detalhe canônico. Eventos indistinguíveis compartilham chave; a limitação é declarada. Revisitas não duplicam pelo simples fato de mudar a versão Graph ou metadados monetários da conta. A recuperação retroativa alcança apenas o que a Meta disponibilizar.

Estado: implementado e validado em WordPress com respostas controladas. A alteração real de orçamento da conta solicitada em korvena permanece para homologação pelo dono/frota e pelo consumidor Core 340.

### Pedido MCP Meta 24 — contagens, EMQ e diagnóstico

Novo canal `dataset` e relatório `dataset_quality`. A interface descobre datasets pelos ativos da conta selecionada. A coleta exige dataset e conta autorizados e confere o vínculo remoto. Contagens WEB_ONLY e SERVER_ONLY são lidas separadamente por dia completo; ausência, recusa, limite ou paginação incompleta não viram zero. Não se somam as fontes como conversões únicas.

A janela pública documentada para estatísticas é de sete dias. Dados eventualmente retornados fora dela são preservados, sem afirmar cobertura integral. Limites por aresta: 10 páginas/3000 registros para estatísticas, cinco páginas para vínculos/conjuntos, dentro do orçamento geral de 40 requisições/25 segundos e resposta limitada a 700 KB. Esgotamento gera parcial ou cobertura não confirmada.

EMQ vem da API própria `dataset_quality`, em `emq_snapshot` separado, com instante e data atuais. A coleta do dia completo mais recente também captura essa observação; backfill de dias anteriores não inventa notas históricas. O acervo preserva sucessivas observações sem prazo. Permissões e eventual opt-in dependem da conta e da versão liberada pela Meta.

`meta/health` usa somente dados locais. O incidente `dataset_optimized_event_zero` exige a coleta mais recente de agenda ainda autorizada, o último dia completo da conta, observação recente, cobertura confirmada, zeros explícitos nas duas fontes e evento padrão utilizado por conjunto atualmente ativo. Conversão personalizada sem mapeamento não autoriza inferência de zero. O encaminhamento de notificação ao canal do site pertence ao Core 341.

O contrato adicional `meta-ads-monitoring/1.0.0` exige registro e concessão explícitos por consumidor, conexão, conta, relatórios e datasets. O cliente oferece `status`/`query` sobre o histórico local, sem acesso a tokens ou HTTP. Revogação e alterações na revisão de acesso invalidam leitura e cursores. As três novas operações de concessão elevam o catálogo a **47**, preservando as 44 anteriores e o contrato de performance.

Provas combinadas dos pedidos 23/24: **36/36** no runtime atual, **36/36** no mínimo e **36/36** após atualização; DOM dos seletores e concessões **15/15**. Cobrem paginação, deduplicação, EMQ separada, cobertura/zero, vínculo de dataset, concessões, cursores, retenção e isolamento do histórico. Dados reais das contas indicadas não foram coletados nesta sessão.

### Revisão comparativa e retenção existente

A comparação com 0.14.0 tem três arquivos adicionados, 29 modificados, 30 idênticos e nenhum removido; manifesto em `evidence/diff0140-0150.json`. Foram revisados, antes do congelamento, a estabilidade da identidade histórica diante de mudança de versão Graph, o bloqueio de combinações incompatíveis entre canal/relatório na leitura histórica e respostas assíncronas obsoletas no seletor de datasets.

Permanecem a retenção ampliada anteriormente para histórico, resultados, auditoria, exportações, metadados de conversas e Stories, bem como o controle de eliminação local e supressão de reimportação. Expiração de tokens, cursores e prévias de segurança não foi transformada em retenção ilimitada. Dados já removidos ou indisponíveis no fornecedor não são recuperados por esta atualização.

## 4. Instalação, testes e prontidão

O instalador foi fechado antes da troca compartilhada, reconstruído com o mesmo SHA-256 e instalado por **`plugins/upload-base64`** no Site-Teste, usando verificação de identidade do pacote. Recibo: operação `d437ecb2f957a21f9ecc85e32af2f386`, backup `50878228321bdcb701993d28`, versão 0.14.0 → 0.15.0, recuperação `applied`. Sondas internas de página inicial e REST passaram antes/depois, em PHP novo e com cache evitado. Elas não são prova independente de acesso público externo.

Ambiente compartilhado: WordPress **7.1.4**, PHP **8.3.36**, MySQL **8.0.41**. A árvore instalada de 62 arquivos corresponde ao instalador: SHA-256 da árvore `a401a6174d04015782a2be079aee6e281c6fef7464887f64b9d6f58e81af7e4f`. Os 32 arquivos PHP passaram no lint e o JavaScript passou na verificação sintática.

### Matriz de prova própria

| Verificação final | Ambiente | Resultado |
|---|---|---|
| Credenciais 0150 | WP 7.1.4 / PHP 8.3.36 | 83/83 |
| Atividades, datasets, SDK e histórico 0150 | WP 7.1.4 / PHP 8.3.36 | 36/36 |
| Regressão Ads/SDK 0130 | WP 7.1.4 / PHP 8.3.36 | 44/44 |
| Core 330 original / privacidade coordenada | Core 1.60.0 em laboratório | 46/46 e 20/20 |
| Integração MCP corrente / recebido | Combinações da seção 2 | 29/29 e 29/29 |
| Comportamento anterior do pedido 22 | Base 0.14.0 isolada | 3/3, recusa local reproduzida |
| Preservação em atualização direta | 0.14.0 → 0.15.0 isolada | 10/10 |
| Smoke / novos relatórios após atualização | WP 7.1.4 / PHP 8.3.36 | 34/34 e 36/36 |
| Smoke, credenciais e novos relatórios | WP 6.4 / PHP 8.1.2-1ubuntu2.28 | 34/34, 83/83 e 36/36 |
| Ads/SDK anteriores no mínimo | WP 6.4 / PHP 8.1.2-1ubuntu2.28 | 44/44 |
| Mensagens, Stories e retenção | WP 6.4 / PHP 8.1.2-1ubuntu2.28 | 75/75 |
| Eliminação/supressão e reinício | WP 6.4 / PHP 8.1.2-1ubuntu2.28 | 76/76 e 4/4 |
| Worker/revisão operacional | Runtime mínimo | 11/11 |
| Formulários de credenciais / monitoramento | HTML nativo e jsdom 27.4 | 22/22 e 15/15 |
| Recusa real de candidatas sintéticas | Graph, Site-Teste | 2/2 |
| Documentação integral pelo MCP | Site-Teste já atualizado | 26/26, bytes e hashes iguais |
| Autoteste final | Site-Teste após limpeza | 8/8 |

Os laboratórios usam WordPress e banco reais com prefixos exclusivos, usuário sintético, bloqueio de HTTP não simulado e bloqueio de e-mail. O mínimo foi instalado novamente após habilitar o PHP 8.1.2 exato, obtido de pacotes oficiais com hashes fixados; PHP 8.1.34 usado na preparação não é apresentado como prova do mínimo. A integração carregou os pacotes reais, mas simulou respostas dos fornecedores.

As evidências de tentativas preliminares foram conservadas. Falhas iniciais de bootstrap do teste Core, relógio da fila, contagem antiga do catálogo e redação de nomes de arquivo pelo SafeOutput foram corrigidas nos testes; as suites de mensagens/privacidade foram repetidas em ambiente isolado adequado. Os resultados usados na tabela são os finais. Não se somam execuções repetidas como casos independentes.

### Documentação, interface e estado final

`meta/documentation` devolveu os 26 documentos completos, com revisão esperada, tamanho e SHA-256 conferidos byte a byte contra o instalador. Inclui guia de agentes, configuração, contratos, segurança, operação/recuperação, migração, retenção, esquemas e `MONITORING.md`. Evidência: `site-documentation0150.json`.

A interface foi exercitada via HTML renderizado pelo WordPress e DOM automatizado. A tentativa adicional de inspeção visual no navegador terminou na tela de login, sem sessão autenticada; nenhuma credencial foi inserida. Portanto, **não há aceite visual manual do painel compartilhado nesta rodada**.

Depois da instalação e do teste Graph negativo, os dois registros de negócio, o histórico vazio e as sete opções existentes do Meta mantiveram exatamente os digests anteriores. Auditoria é excluída dessa comparação porque registra as operações de teste. As conexões e agendas reais estavam vazias e assim permaneceram. A atualização isolada, por sua vez, preservou 11 registros e uma linha histórica, incluindo conexão, agenda, job pausado, metadados de mensagens, Story e políticas de retenção explícitas.

Os laboratórios foram removidos por rotina restrita ao prefixo temporário. A consulta final encontrou zero tabelas `f3qa0150_%`, zero opções de controle do laboratório e nenhum dos três arquivos temporários nos MU-plugins. O catálogo final contém somente **47 operações Meta 0.15.0**, sem habilidades QA. `meta/health` terminou `ok`, armazenamento e criptografia prontos, nenhum incidente, nenhuma conexão ou agenda ativa; autoteste local aprovado. Backups nativos de instalação/remoção e a auditoria normal foram preservados.

## 5. Banco, retenção e reversão

Mantidos schema de armazenamento **2** e schema de histórico **1**, sem tabela nova ou migração destrutiva. A concessão adicional usa o bucket `monitoring_grant` no armazenamento existente; os relatórios usam o histórico existente com novas identidades/tipos. Nada amplia uma concessão de performance automaticamente. A instalação não agenda coleta nem habilita contato, anúncio ou mensagem externa.

Antes de reversão operacional, pausar as novas agendas `ads_activity`/`dataset_quality` e desabilitar consumidores do contrato novo. A 0.14.0 não conhece essas funções; voltar os arquivos não oferece leitura dos dados novos e pode reaplicar suas políticas de limpeza. Manter backup de banco/arquivos e preservar os dados do monitoramento fora do alcance de uma manutenção antiga, se a reversão for necessária. A retenção do novo acervo não deve ser presumida sob código anterior.

Preservar salts, chave de privacidade, registros de supressão e recibos durante qualquer restauração. O backup do instalador não desfaz banco, concessões, coletas posteriores ou efeitos externos. Não foi feito rollback destrutivo do ambiente compartilhado; o percurso validado foi a atualização direta e a preservação dos dados.

## 6. Pendências e responsáveis

| Pendência | Responsável e limite |
|---|---|
| Aceite de atividade com alteração real de orçamento na conta 1803436740776667 | Dono/frota e Core 340; não houve escrita em anúncio nem acesso à produção nesta sessão |
| Contagens dos datasets 1088603200283681 e 1062566196616523, EMQ e comparação de 22–26/10 quando disponível | Dono/frota; depende da janela, permissões, opt-in e API efetivamente liberada pela Meta; não há EMQ histórica retroativa |
| Consumidores, concessão explícita e canal de alerta | Responsável Core, pedidos 340/341, conforme impacto emitido |
| Inspeção visual em navegador autenticado | Operador; DOM automatizado passou, mas a sessão do navegador estava desautenticada |
| Integração integral com Core 1.61.0 e Google 0.23.0 | Validação coordenada posterior; versões surgidas durante o fechamento têm observação de carregamento, não a matriz funcional completa |
| Aceites anteriores de Ads, passagem da agenda Instagram e sites sem conexão | Dono/frota; pendências recebidas 20/123/88 permanecem sem confirmação própria nesta rodada |
| Publicação no repositório e distribuição para os demais sites | Frota, após conferência dos hashes; nenhum push ou instalação de produção foi realizado |

A versão padrão de Graph permanece **v24.0**, e cada conexão conserva a sua versão. A documentação pública consultada descreve APIs atuais; a disponibilidade positiva de todos os campos/arestas nessa versão e nos ativos reais ainda requer homologação. `ads_read` e uma ferramenta registrada não bastam para provar acesso à Dataset Quality API. A coleta é somente leitura.

## 7. Credenciais e configuração, sem valores secretos

Em Ferramentas → Fator3 MCP Meta, informar nome da conexão, App ID, Chave Secreta do Aplicativo e token autorizado. Os campos são `client_id`, `client_secret` e `token`; valores secretos não constam dos relatórios/evidências. Token salvo é cifrado e não é retornado ao consumidor.

Para os relatórios novos, selecionar conta de anúncios com `ads_read`, descobrir/selecionar datasets dessa conta e criar a agenda diária explicitamente. A qualidade de correspondência pode exigir `ads_management` ou `business_management` junto de `ads_read`, ou autorização específica/opt-in de qualidade conforme a Meta. Isso não habilita escritas pelo plugin. Quando o Core disponibilizar o consumidor, revisar o recorte e conceder acesso pelo painel ou `meta/save-monitoring-grant`.

Somente valores sintéticos foram usados nos testes de credenciais desta rodada. O teste Graph negativo chamou o fornecedor real sem usar contas ou credenciais reais. Não houve envio de mensagens, publicação, gasto em anúncio ou notificação a clientes.

## 8. Artefatos e identidade final

| Artefato | Bytes | SHA-256 |
|---|---:|---|
| `wp-mcp-meta-fator3-0.15.0-instalador.zip` | 305286 | `521e8f83a8c6fad12497e7c9f40ec6cf8cb129060c6a56e89955257ca22f81f3` |
| `wp-mcp-meta-fator3-0.15.0-fonte.zip` | 3047277 | `9b4caec4772004b11e0789e0f3cb5de954409d5798d198c8f3d403f5c03c97c2` |

Complemento: `wp-mcp-meta-fator3-0.15.0-impacto-base-site-core-fator3.md`, revisão 2. Identidade: 6080 bytes, SHA-256 `f3b88acffcc0d61488ea6afa78175c376137f6aa2a43acc759bd49d6ff008408`. O instalador é o único ZIP instalável. O fonte contém runtime idêntico, build, testes, entradas e evidências sanitizadas; não contém outro ZIP da entrega. A cópia interna deste relatório permanece anterior ao fechamento para evitar circularidade de hash. O relatório externo recebe a identidade final do fonte sem reabrir os ZIPs.
