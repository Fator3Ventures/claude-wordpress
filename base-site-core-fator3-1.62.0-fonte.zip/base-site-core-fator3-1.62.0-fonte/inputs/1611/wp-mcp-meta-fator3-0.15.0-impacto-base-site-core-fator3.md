# Impacto técnico — Meta → Site Core

Emissor: wp-mcp-meta-fator3, base 0.14.0, versão 0.15.0. Destinatário: base-site-core-fator3, base recebida e contrato examinado 1.60.0; 1.61.0 observada carregada no fechamento. Data: 29/10/2026, America/Sao_Paulo. Revisão 2. Etapa: entrega. Situação: demanda-aberta; classificações acao-necessaria e validacao-coordenada. Instalador: wp-mcp-meta-fator3-0.15.0-instalador.zip, 305286 bytes, SHA-256 521e8f83a8c6fad12497e7c9f40ec6cf8cb129060c6a56e89955257ca22f81f3.

## Consequência e pedidos

Os pedidos MCP Meta 23/24 introduzem `ads_activity` e `dataset_quality`, que não pertencem à concessão de performance `meta-ads-reader/1.0.0`. Core 340/341 devem integrar **meta-ads-monitoring/1.0.0** pelo hook `f3_meta_register_monitoring_consumers`, registrar o consumidor com configuração `ready`, `connection_id`, `account_id` (conta de anúncios), `revision` monotônica, `reports` e `dataset_ids`. O callback deve mudar a revisão quando o acesso for alterado; não reviver configuração antiga após desativação/reativação.

A concessão é nova e explícita. O administrador confirma relatórios/datasets anunciados pelo consumidor em Consumidores de anúncios ou `save-monitoring-grant`. Não migrar nem ampliar silenciosamente concessões de performance. `client.query` lê somente histórico local; para dataset recebe `dataset_id`. Ativos retirados, configuração alterada, concedente revogado ou revisão de acesso alterada invalidam o acesso e os cursores.

Core 340: apresentar atividades por conta, horário, entidade, evento, autor e valores anterior/novo quando fornecidos. A chave é uma impressão digital do conteúdo; eventos indistinguíveis retornados pela origem compartilham chave. Página vazia não comprova recuperação de toda a história remota.

Core 341: consumir registros `event_counts` e `emq_snapshot` separadamente. Contagens de navegador e servidor podem se sobrepor: não somar como conversões únicas. EMQ tem `emq_observed_at` e data da observação; não atribuir essa nota à data passada das contagens. Ausência e recusa ficam desconhecidas. O aviso `dataset_optimized_event_zero` em `meta/health` exige zeros explícitos, cobertura confirmada e evento padrão vinculado a conjunto ativo observado. Implementar o encaminhamento ao canal do site e a deduplicação por `incident_key`; o Meta não envia essa notificação.

## Precisões de contrato e orientação de consumo nesta revisão

O consumidor usa `MonitoringReader::register_consumer(id, version, contract, configurationCallback, label)`, que devolve um cliente com `status` e `query`. Em `client.query`, `account_id` é sempre a conta de anúncios; para o relatório `dataset_quality`, acrescentar `dataset_id`. Isso difere da criação de coleta pelo administrador, onde `account_id` identifica o dataset e `ads_account_id` identifica a conta de anúncios. Não reutilizar o payload administrativo como payload do leitor.

A consulta histórica filtra pela data do registro. EMQ capturada hoje pertence a hoje, mesmo quando colhida junto das contagens de ontem. Para apresentar ambas, consultar também a data corrente e distinguir a observação atual do período das contagens. Agregações de eventos de mais de sete dias podem ser conservadas quando devolvidas pela origem, mas não comprovam cobertura integral. As fontes WEB_ONLY e SERVER_ONLY ficam independentes, com valores nulos quando ausentes.

Para notificação do pedido Core 341, usar somente os incidentes emitidos pelo health: ele considera a última coleta concluída ou parcial de agenda ainda autorizada, sua primeira página durável, o dia completo mais recente no fuso da conta e observação de até 36 horas. Um zero exige as duas contagens explícitas, cobertura confirmada e otimização atual por evento padrão. Não reconstruir o alerta a partir de uma página vazia, de contagens antigas, de conversão personalizada sem mapeamento ou de uma coleta anterior quando a mais recente não comprovou cobertura. O Core deve deduplicar `incident_key` e decidir o canal de comunicação; não delegar envio ao Meta.

A identidade do histórico de atividades e contagens independe da versão Graph e da moeda/metadados da conta. Revisitas substituem a observação equivalente; snapshots de EMQ preservam observações distintas. Nenhuma migração de tabelas do Core é solicitada. Na sequência de implantação, disponibilizar o contrato Meta, registrar/configurar o consumidor no Core e só então obter a concessão explícita correspondente. A falta desse consumidor não bloqueia as demais funções dos plugins.

## Responsáveis e aceite necessário

Responsável Core: consumidores, configuração, revisão monotônica de acesso, apresentação e canal de notificação dos pedidos 340/341. Responsável Meta: coleta, retenção cifrada sem prazo, contrato, permissões e documentação. Operador/frota: permissões, opt-in para Dataset Quality quando exigido, seleção explícita de datasets, agendas diárias e homologação com os ativos reais.

Validar: negar antes da concessão; conceder somente o recorte confirmado; consultar atividades/contagens/EMQ localmente sem HTTP; retirar ativo ou revogar concessão e negar continuação; preservar o leitor de performance existente. Em korvena, comprovar alteração real de orçamento da conta 1803436740776667. Datasets 1088603200283681 e 1062566196616523: comprovar contagens e EMQ quando a Meta liberar; não fabricar histórico 22–26/10. Instalação em produção e homologação de dados reais não estão autorizadas nesta rodada.

## Alterações técnicas da revisão 2

Acrescentadas a distinção entre os IDs das coletas e do leitor, a data de consulta dos snapshots de EMQ, as condições de atualidade/cobertura exigidas para notificar e a estabilidade da identidade nas revisitas. Essas orientações delimitam a implementação dos pedidos Core 340/341; não registram resposta ou encerramento de outro pedido. A revisão 1 permanece no histórico do fonte.
