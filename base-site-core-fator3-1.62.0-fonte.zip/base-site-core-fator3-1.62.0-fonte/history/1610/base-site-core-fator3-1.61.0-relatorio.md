> Cópia anterior ao fechamento do fonte. Relatório externo canônico: `base-site-core-fator3-1.61.0-relatorio.md`.

# Fator3 Site Core 1.61.0 — relatório de entrega

29/10/2026 · `base-site-core-fator3` · contrato administrativo **8.25.0**.

## 1. De onde esta versão entra

Base direta canônica: **1.60.0**, instalador de 2842430 bytes, SHA-256 `1dc4e94305ea55394024d6527bc06b46209f0ae51a55f734853763bcb232e27c`. Não exige versões intermediárias. A fonte desta entrega preserva os insumos, a proveniência da base, ferramentas e evidências; o runtime é idêntico ao instalador final.

Escopo: pedidos Core 335–347 do documento de 29/10/2026, regras do dono sobre credenciais, configurações revisionadas e retenção máxima, e convivência dos acompanhantes. Implementados 335, 336, 338, 339, 344, 345, 346 e 347; 343(a,b) entregue parcialmente no recibo; 343(c), 337 e 340–342 permanecem abertos. Não se declara conclusão integral da lista.

## 2. Convivência e encaminhamentos

| Ambiente | MCP | Google | Meta | LinkedIn | Pipedrive |
| --- | --- | --- | --- | --- | --- |
| Bancada local inicial | 0.37.0 | 0.22.0 | 0.14.0 | 0.13.0 | 0.4.0 inativo por exigir PHP 8.3.36 |
| Site-Teste e bancada isolada final | 0.37.0 | 0.23.0 | 0.15.0 | 0.13.0 | 0.4.0 ativo |

Os arquivos novos recebidos de MCP/LinkedIn/Pipedrive foram conferidos e seus hashes estão em `inputs/1610/pacotes-reconferidos.json`. Google 0.23 e Meta 0.15 chegaram ao servidor durante a homologação: a documentação vigente foi lida integralmente pelas abilities públicas, com hash, e preservada em `inputs/1610`. A prova remota usa seus runtimes instalados, sem afirmar que seus instaladores/fonte foram recebidos nesta rodada. Nenhum acompanhante foi alterado ou redistribuído pelo Core.

O impacto recebido do MCP 0.37 foi atendido pelo item 347. Os dois impactos Core emitidos no início foram atualizados com adendo: Google 0.23 já publica `google-ads-reader/1.0.0` e `search-console-reader/1.1.0`; Meta 0.15 já publica `meta-ads-monitoring/1.0.0`. Portanto, a pendência 337/340/341/342 é agora **integração no Core**, e não falta do contrato no produtor. Os impactos originais são histórico, não novos pedidos de implementação duplicados.

## 3. Mudanças e evidência

| Pedido | Entrega e limites |
| --- | --- |
| 335 | Schemas 1.1 aceitam `ambos`; falhas mantêm o contrato pedido e distinguem leitura de saída inválida. Prontidão devolve `leitura_falhou` e o código correspondente. Fixture: 12 verificações junto de 347. |
| 336 | IP/fonte/agente do pedido de medição, cifrados por sessão, visitante legível e filtros IP/visitante. Capability pessoal obrigatória; conflito de identidade oculta os campos; reconstrução do índice conserva o contexto. Não preenche história inexistente. |
| 338 | Presença de gclid, gbraid, wbraid, fbclid e utm_source_platform nos GET de páginas, sem valores/query. Importação e reimportação nativas, classes e contadores: 7 verificações. Histórico não coletado é nulo, não zero. |
| 339 | Aplicativo declarado por pacote/marca de UA e classificação de rede por faixa, com fonte/versão; desconhecido permanece desconhecido. Configuração revisada e simulação, conflitos explícitos. Contato reutiliza contexto da sessão medida. 336/339: 15 verificações. |
| 343(a,b) | Fotografia dos IDs/rótulos das opções de Parceiro, Unidade, Canal e Ponto, fonte do Parceiro e atividades principal/e-mail. Rótulos não são reconstruídos pela configuração atual. Campos livres permanecem em hash. A confirmação de campos depende da releitura já existente; recibos históricos sem fotografia são identificados. |
| 344 | Demanda usa o catálogo nativo fotografado para respostas fechadas Meta/LinkedIn/Google, inclusive CUSTOM com opções valor/rótulo. Deduplica multiseleção e exclui texto livre/valor fora do catálogo. Google depende de catálogo fechado efetivamente recebido. |
| 345 | FETCH parcial de cabeçalho/estrutura/texto para mensagem acima de 2 MiB, sem baixar anexos. Cabeçalho excessivo produz recibo cifrado e avisos Slack/e-mail técnico; movimento só após persistência. Saúde conta mensagens grandes. Fixture TCP IMAP: 13 verificações; coletor com transporte substituído: 5. |
| 346 | Regras orgânicas ordenadas e catálogo IA em options, revisão, simulação de parâmetros e contatos de 30 dias; captura guarda regra/revisão. Identificadores pagos precedem regras. Mapa Pipedrive aceita chaves novas; nota inclui assistente. Junto de 343/344: 20 verificações. |
| 347 | `itens` com metadados e revisão opaca do segredo, alias legado preservado. Pelo MCP real: leitura, candidata de 39 caracteres, aviso de formato, HTTP 401 do Pipedrive e mesma revisão salva depois. Não se leu nem retornou o valor salvo. |
| Regressão 332 | Corrigida a conversão do instante no recibo de renovação: somente os dez dígitos do timestamp entram no inteiro, sem interpretar o nonce hexadecimal como expoente. Novo caso determinístico; suíte 331–334 passa com 32 verificações. |

Limites de e-mail: cabeçalho até 256 KiB, texto transferido até 64 KiB, texto persistido até 20000 caracteres; parser limitado em profundidade e tokens. Tamanho de anexo é octeto codificado do BODYSTRUCTURE, não tamanho binário decodificado. Corpo parcial não prova DKIM local: usa Authentication-Results do servidor confiado ou SPF alinhado; prova insuficiente vai à revisão. Cabeçalho incompleto não vira contato. Aviso reservado/resultado incerto não é repetido automaticamente.

A fixture de 5 MB anuncia esse tamanho pelo protocolo e comprova as requisições parciais, a classificação, o contato, os metadados de anexos, saúde, movimento e retomada; **não é envio de uma mensagem real de 5 MB à caixa do site**. As respostas remotas de testes de negócio são simuladas. Aceite em conta/caixa real permanece separado.

Regressões locais adicionais passaram: caminho do lead (41), MIME (25), coletor (15), transportes (19), IMAP (10), CRM (38), estado (27), Pipedrive (39), documentação completa (1812) e permissões com MCP (16). Cada evidência contém os nomes dos checks; não se soma repetição em ambientes diferentes como cobertura nova.

## 4. Instalação e prova da troca

O instalador final passou lint em 563 arquivos PHP e contém 791 arquivos. Instalado limpo e atualizado diretamente do ZIP canônico 1.60.0, com finalização em outra requisição, migração repetida, preservação dos dados semeados, desinstalação e reativação. Ensaios em WordPress 7.1.3 e no mínimo 7.1.2, PHP 8.3.6, MySQL 8.0.46. Os dois resultados nativos citam o SHA-256 final.

No Site-Teste (WordPress 7.1.4/PHP 8.3.36), a primeira candidata atualizou 1.60.0 para 1.61.0. A regressão 332 e a chegada de Google/Meta foram tratadas antes do fechamento; o pacote final substituiu a candidata ainda não entregue. A operação de aplicação final é `702df3e4799915fcf143c0a2e2c96713`, ZIP SHA-256 `77f914d180bafb9432e6e8dea332bf57ad6839e63670ccd282c3c8469703f4f1`. Sondas HTTP antes/depois passaram. Essa sonda de origem não é prova de acesso público externo nem de operação de contas comerciais.

No Site-Teste, as suítes finais passaram em bancada descartável com prefixo próprio: 32 checks de 331–334; 12 de 335/347; 15 de 336/339; 7 de 338; 20 de 343/344/346; 5 do coletor 345; 41 de 322; 46 do consumidor Meta com 0.15.0; 1812 documentais e 16 de permissões. Os 791 arquivos do runtime coincidem com o ZIP final (manifesto SHA-256 `f4d2b97fe38121dff0e11fcb7df6cc356f05ba1aa971803af87c049ad5288eb0`). Ciclo `edb55719-da1f-4821-a932-ce16c661bb1c` concluído, sem falhas, confirmado no executor. As leituras de UI/resumo/prontidão não alteraram as opções inspecionadas. Limpeza: 98 tabelas da bancada removidas, nenhuma restante; diretório, marcador, controlador temporário e os dois ZIPs de estágio removidos. Backups e auditoria administrativos do MCP são preservados. A revisão do segredo Pipedrive ficou igual antes/depois da recusa real, e `content`/`structuredContent` foram iguais nas leituras públicas verificadas.

Documentação: leitura integral de todos os 157 documentos instalados, 685 páginas, hashes, continuação, autorização e confinamento pela ability pública decorada com o MCP; prova externa adicional dos documentos desta versão pelo executor MCP. Os catálogos operáveis incluem 178 abilities e 93 opções; o inventário estrutural inclui 167 opções, 67 tabelas e 11 transients. Não confundir os inventários técnicos com a seleção editável do contrato.

Apenas o Site-Teste recebeu o Core. Não houve publicação no Git da frota nem instalação nos demais sites; não se declarou aceite comercial em ctooffice/korvena nem se criou CRM real no Site-Teste.

## 5. Banco e volta de versão

Mudanças aditivas: contexto cifrado/hash IP/app/metadados no índice de sessões; máscara de presença paga no acervo de logs e contribuições; marca/tamanho de mensagens grandes na caixa. Parser de logs revisão 8 e coletor revisão 6 reprocessam fontes ainda disponíveis com publicação idempotente. Não houve redução de retenção: medição segue a janela configurada, até 120 meses. Não foi adotado prazo de 90 dias para IP.

Eliminação/esquecimento e retenção removem contexto com a sessão. A política preexistente de desinstalação continua removendo medição; dados comerciais e recibos seguem a política anterior. Não usar desinstalação como atualização. Faça backup do banco, arquivos e salts; a volta do ZIP não desfaz migrações de banco nem efeitos externos. Campos extras são aditivos; a restauração completa exige a cópia coerente anterior. Salts perdidos impedem abrir dados cifrados.

## 6. O que permanece pendente

- **337, 340, 341 e 342:** consumidores e comportamento funcional no Core ainda não implementados. Os novos contratos Google/Meta já existem. Falta integrar enriquecimento gclid, performance/alterações, qualidade/alerta Meta e acervo consulta×página×dia; testar concessões, cobertura, retenção e aceites reais. Ausência de dados não vira zero. Consulta anônima GSC não tem contagem exata exposta pela API; não se deve inventá-la.
- **343(c):** não há conferência automática individual do e-mail no histórico Pipedrive. O recibo explicita `historico.estado=nao_conferido`, `conferido_em=null`. Aceite SMTP não comprova entrada no histórico; contador de mensagens ou coincidência de assunto não foram usados como prova.
- **Aceites externos:** comparação real do contrato 335 em ctooffice, demanda nativa existente, tráfego real após coleta de logs e e-mail real grande. Pipedrive real permanece restrito a ctooffice.com.br/korvena.com.br. A nova versão não remove esses itens do documento de pedidos nem declara aceite da frota.
- **Inspeção visual:** não se afirma revisão visual de navegador nesta entrega; a interface e os fluxos tiveram verificações nativas de HTML/contratos e as provas descritas acima.

## 7. Credenciais e configuração do dono

A atualização não troca credenciais, cria concessões Google/Meta, habilita regras comerciais ou dispara testes reais de CRM. Use `itens[].revisao` como `revisao_esperada` e confira o fornecedor antes de gravar. Formato incomum gera aviso; limites inseguros continuam recusados.

Novas opções: `f3base_contexto_sessao`, `f3base_canais_organicos`, `f3base_origens_ia`. Leia/simule, salve com a revisão atual e confira nova captura. Precedência paga é proteção de código; listas variáveis são configuração. IP/agente/visitante requerem `f3base_ler_leads`. Para e-mails, servidor Authentication-Results confiado e SMTP/avisos continuam configurações próprias do site. Leia `docs/RELEASE-1.61.0.md`, `docs/SESSOES-1.61.md`, `docs/CANAIS-ORGANICOS-1.61.md` e `docs/AGENTES-1.61.0.md` pelo canal.

## 8. Identidade dos arquivos

| Arquivo | Bytes | SHA-256 |
| --- | ---: | --- |
| base-site-core-fator3-1.61.0-instalador.zip | 2879882 | `77f914d180bafb9432e6e8dea332bf57ad6839e63670ccd282c3c8469703f4f1` |
| base-site-core-fator3-1.61.0-fonte.zip | a preencher no relatório externo após empacotamento | `a preencher no relatório externo após empacotamento` |

O fonte contém runtime exatamente igual ao ZIP, ferramentas de build, testes, insumos textuais, evidências, impactos atualizados e histórico. Exclui laboratórios, bancos, logs brutos, dependências instaladas e ZIPs de acompanhantes. O relatório dentro da fonte é a cópia anterior ao fechamento, para evitar hash circular; este relatório externo contém a identidade final da fonte. Verificação de igualdade arquivo a arquivo é executada por `build/package-source.py`.
