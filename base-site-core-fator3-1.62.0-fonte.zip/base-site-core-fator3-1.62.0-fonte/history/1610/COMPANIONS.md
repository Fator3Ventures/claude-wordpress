# Acompanhantes considerados — Core 1.61.0

Pacotes originais fornecidos separadamente, sem alteração pelo build Core. A seleção depende de contratos/capacidades e autorização; a matriz abaixo delimita a combinação examinada, sem homologar toda função dos acompanhantes.

| Pacote | Versão | Fronteira pertinente |
| --- | --- | --- |
| wp-mcp-fator3 | 0.37.0 | Autorização, schemas/documentação, upload privado idempotente, sondas e auditoria comercial vigente; revisar os relatórios 0.35/0.36 recebidos. |
| wp-mcp-google-fator3 | 0.22.0 | Aquisição 1.0/1.1, comercial 1.2, concessão por ação e extensão de consulta assíncrona 1.0; GA4 preservado. |
| wp-mcp-meta-fator3 | 0.14.0 | SDK Meta Ads vigente; formatos de credenciais consultados no produtor 0.14; concessão vinculada ao acesso do consumidor. |
| wp-mcp-linkedin-fator3 | 0.13.0 | Comercial 1.2, concessão/binding, diário local e aquisição preservada; sem extensão assíncrona Google. |
| wp-mcp-pipedrive-fator3 | 0.4.0 | Cliente Core 1.0 preservado; exige PHP 8.3.36. |

| Instalador novo recebido | Bytes | SHA-256 |
| --- | ---: | --- |
| wp-mcp-linkedin-fator3-0.13.0-instalador.zip | 314596 | `1c45738322f4901aeacdc36615789ae961e8b9d521ba321a27de0aea76c13502` |
| wp-mcp-fator3-0.37.0-instalador.zip | 912702 | `cbece53fc479d9fe3963b111e49e789d92609c5462102877244dcaebcf7cf3ec` |
| wp-mcp-pipedrive-fator3-0.4.0-instalador.zip | 84775 | `70100900ebd7b358e96c9778eaa359aeb454203f759136da380adcb853b383fe` |

Fontes novos: Google 0.22, 5989075 bytes, SHA-256 `1d9ba106eb9ababad67b964fa4ad44246acc27eeda3e83e7866ea57386d77abf`; LinkedIn 0.12, 1713239 bytes, SHA-256 `15c182cc89605cb1fc18121d8db81fd9008daa06cb787f7224a973d18f4f65d1`. Nomes importados podem conter `(1)`; esse sufixo local não altera a identidade. Os manifests de `inputs/1590` preservam os nomes e locais de extração originais. Os insumos anteriores permanecem referenciados em `inputs/1580`.

Google entrega um patch de consumidor sobre o arquivo Core 1.58 identificado por SHA-256 `84c429dda8697699357aa219ed028925811f0cfc86101ac3fd0edc7bdb683b20`, diff SHA-256 `a10ef8971a47ac38950e6759aa80b378380021a2e388f8fc1c23e252602d2eaa`. A incorporação Core 1.59 é revista e testada como release própria; não equivale a aprovar automaticamente o patch apenas por ter ensaio no produtor.

No laboratório, use os modos separados `core-only-mode1590.php`, `socials-only1590.php` e `site-1610-companions.php`. Reinicie o processo após mudar a seleção. Não desative pacotes do site compartilhado para reproduzir um caso. Pipedrive permanece inativo no PHP 8.3.6; seu mínimo não é reduzido pelo piso Core.

Os relatos de limitações MCP 0.34 preservados em inputs/1590 são históricos e não descrevem o MCP 0.36. Os relatórios novos e as identidades estão em inputs/1600. A validação Core não substitui os aceites dos emissores.

Testes usam dados/credenciais sintéticos e interceptação de transportes. Não incluir grants reais, logs brutos ou dados de clientes nos artefatos. Relatórios dos emissores, inventário remoto e provas próprias Core são categorias distintas. Contas reais, atribuição e auditoria central corrigida exigem seu aceite específico.

A base canônica Core é 1.59.0; os manifests em `inputs/1600/packages.json` também identificam seus dois ZIPs. Nenhum acompanhante é redistribuído no instalador/fonte. A mudança de revisão do consumidor Meta requer uma nova concessão uma vez após a atualização; veja `history/1600/IMPACTO-META-330.md`.


Reconferência 1.61: fontes/relatórios MCP 0.37, LinkedIn 0.13 e Pipedrive 0.4 em inputs/1610, identidades completas em pacotes-reconferidos.json; a referência de base atual é Core 1.60.0. Textos de transições anteriores acima são históricos. Google/Meta preservam os instaladores e hashes de inputs/1600.


## Reconferência final durante homologação

No Site-Teste também chegaram Google 0.23.0 e Meta 0.15.0. Documentação vigente completa de seus contratos novos foi obtida pelas abilities públicas e preservada em inputs/1610/google0230-* e meta0150-*. Os binários dessas duas versões não foram recebidos nesta fonte: a prova de convivência usa os runtimes copiados para a bancada isolada no próprio Site-Teste. A matriz local permanece Google 0.22/Meta 0.14; a matriz remota é MCP 0.37/Google 0.23/Meta 0.15/LinkedIn 0.13/Pipedrive 0.4. A versão Core não implementa ainda 337/340/341/342: os contratos do produtor agora existem, falta integrar o consumidor Core.
