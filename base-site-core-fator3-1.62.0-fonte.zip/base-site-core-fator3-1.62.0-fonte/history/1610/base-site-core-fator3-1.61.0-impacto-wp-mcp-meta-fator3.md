> **Atualização de 29/10/2026, fechamento da 1.61.0:** este encaminhamento descreve a lacuna da base inicialmente recebida. O produtor 0.15.0 já publicou meta-ads-monitoring/1.0.0 e foi observado no Site-Teste durante a homologação. A pendência agora é incorporar e testar a integração funcional no Core; não continua atribuída à ausência do contrato no produtor. O conteúdo original abaixo é preservado como histórico.

# Impacto — Site Core → Fator3 MCP Meta

Emissor: base-site-core-fator3, base 1.60.0, alvo **1.61.0 previsto**. Destinatário/responsável: wp-mcp-meta-fator3, base disponível 0.14.0. Etapa: planejamento, 29/10/2026. Revisão 1. Situação: **bloqueio** das integrações dependentes. Instalador alvo ainda não gerado.

## Pedido e consequência

Pedidos Core 340 e 341 dependem dos Pedidos MCP Meta 23 e 24. O SDK Ads reader da 0.14.0 não publica histórico de alterações nem qualidade diária do dataset. O Core não pode concluir ausência de recebimento a partir de emissão local, nem representar dado indisponível por zero ou inventar EMQ.

## Ação necessária

Publicar contratos/schemas e cliente PHP concedido para alterações por conta/dia/entidade/campo, com valor anterior/novo quando disponível e autor separado; e qualidade diária por pixel/dataset/evento, recebidos, EMQ e cobertura. Para o alerta, fornecer vínculo de conjunto ativo com evento otimizado e gasto do mesmo dia, preservando fuso e unidade. Proposta: registro explícito `site-core`, concessões desligadas por padrão, revisão e revogação imediata, leitura paginada de acervo, dias completos identificados e estados inequívocos para lacuna/indisponibilidade/zero observado. Os nomes finais de contratos e métodos serão definidos pelo produtor, não presumidos pelo Core.

## Aceite e validação coordenada

Pacote instalável/fonte com SDK documentado, fixtures de dia completo zero, dia normal, dia incompleto e concessão revogada. Uma alteração autorizada aparece no dia seguinte. Um dia completo com evento otimizado zerado e emissão local ou gasto permite exatamente um alerta por pixel/evento/dia; dia incompleto ou indisponível não permite alerta. Janela/regra do consumidor será configuração revisionada e simulável. Os pedidos dependentes permanecem abertos até contrato e testes com o produtor.
