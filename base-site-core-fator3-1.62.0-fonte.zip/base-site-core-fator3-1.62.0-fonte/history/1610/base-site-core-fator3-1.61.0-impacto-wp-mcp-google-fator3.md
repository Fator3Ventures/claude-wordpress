> **Atualização de 29/10/2026, fechamento da 1.61.0:** este encaminhamento descreve a lacuna da base inicialmente recebida. O produtor 0.23.0 já publicou google-ads-reader/1.0.0 e search-console-reader/1.1.0 e foi observado no Site-Teste durante a homologação. A pendência agora é incorporar e testar a integração funcional no Core; não continua atribuída à ausência do contrato no produtor. O conteúdo original abaixo é preservado como histórico.

# Impacto — Site Core → Fator3 MCP Google

Emissor: base-site-core-fator3, base 1.60.0, alvo **1.61.0 previsto**. Destinatário/responsável: wp-mcp-google-fator3, base disponível 0.22.0. Etapa: planejamento, 29/10/2026. Revisão 1. Situação: **bloqueio** das integrações dependentes. Instalador alvo ainda não gerado.

## Pedido e consequência

Pedidos Core 337, 340 e 342 dependem, respectivamente, dos Pedidos MCP Google 44, 45 e 46. A API pública local da 0.22.0 oferece `search-console-reader/1.0.0` (`gsc.page-day.read`) e `ga4-reader/1.0.0`; a consulta administrativa `ads/search` não é uma concessão de acervo ao Core. Sem contrato público concedido, o consumidor automático não pode ser implementado com segurança nem validado contra o produtor.

## Ação necessária

Publicar contratos/schemas e cliente PHP para: (44) clique por conta/dia/gclid e seus atributos; (45) fotografias Ads por dia/entidade e termos, mais alterações de conta; (46) GSC consulta × página × dia. A proposta é manter registro explícito do consumidor `site-core`, concessão desativada por padrão e vinculada à conta/propriedade e revisão, revogação imediata, paginação/cursor estável, limites de lote e identificação/versionamento da fotografia. Nomes finais de capacidades, métodos e schemas pertencem ao produtor; estes nomes não são presumidos pelo Core.

Cada resposta precisa distinguir sem concessão, sem arquivo, coleta incompleta, lacuna, ausência de linha e zero observado. Declarar moeda, fuso/dia da conta, cobertura, anonimização de consultas GSC e política de dados pessoais. Alterações devem separar autor dos demais campos para aplicar permissão no consumidor. Cliques precisam indicar campos indisponíveis, sem inferir termo de busca a partir da palavra-chave.

## Aceite e validação coordenada

Disponibilizar pacote instalável e fonte, contrato documentado, fixtures válidas e de falha; provar revogação, retomada, paginação e reprocessamento sem duplicidade. Comparar um dia de gclid, 30 dias de gasto/cliques e um dia de consulta/página com leituras autorizadas do Google. O Core implementará o consumidor após esse contrato existir. Não declarar concluídos os pedidos 337/340/342 nesta rodada enquanto a dependência estiver ausente.
