# Impacto técnico — Core1.61.1 → MCP Meta0.15.0

29/10/2026. Emissor: Fator3 Site Core, base1.61.0/alvo1.61.1. Destinatário: responsável MCP Meta. Tipo: validacao-coordenada. Etapa: entrega; revisão2. Situação: integração Core implementada; aceite real pendente.

Pedidos340/341, Meta23/24. O consumidor de `meta-ads-monitoring/1.0.0` usa `f3_meta_register_monitoring_consumers`. Seleção explícita de conexão, conta, relatórios e datasets; concessão independente de desempenho. Não consulta opções/tabelas privadas do produtor no runtime. `meta/health` é a fonte pública de incidentes recentes.

Core mostra contagens browser/servidor e EMQ datada em blocos separados; nunca soma contagens como recebidos únicos ou reconstrói EMQ histórica. Atividades mantêm valores operacionais; autoria e metadados históricos com autor são protegidos pela capacidade pessoal.

Core só notifica com zero otimizado comprovado e emissão local por pixel/evento/dia ou gasto positivo concedido. Pixel direto e destino CAPI distintos não são confundidos. Intenção durável precede o transporte, incidente deduplica e incerteza não é repetida automaticamente. O limite de31 páginas para prova fica desconhecido quando insuficiente. Nenhum envio é feito pela mera leitura.

Provas próprias com Meta0.15 real e Graph/avisos sintéticos: orçamento antigo/novo e autoria restrita, contagens e EMQ, dia normal sem aviso, zero sem atividade sem aviso, emissão exata gerando um aviso, repetição sem duplicação e concessão revogada bloqueando leitura/envio. Desempenho0.15 conserva46 verificações de regressão.

Responsável pela frota/dono: habilitar seleção e concessão nas contas reais, validar janela efetivamente devolvida pela Meta em korvena/ctooffice e o próximo incidente natural. Resultado sintético não encerra esse aceite; não forçar zeramento de campanhas. Nenhuma mudança de runtime Meta é requerida. O relatório principal fornece hashes finais e estado do Site-Teste. Documento preparado, não enviado.

## Fechamento da entrega

Instalador emissor: `base-site-core-fator3-1.61.1-instalador.zip`, 2933589 bytes, SHA-256 `9cfbab0b667c877c3c14b9d6704c827665d20d7b34ff4c9b9d915d6b3c9bd6d3`.

Site-Teste: WordPress 7.1.4/PHP 8.3.36, Core 1.61.1 e Meta 0.15.0; 17 verificações de monitoramento passaram na bancada isolada, com transporte de aviso interceptado. Inclui navegador e servidor com pixels distintos, sem falso alerta. Evidência: `evidence/1611/site-request-340-341.json`. Integração concluída no Core; aceite em conta real permanece para o responsável.
