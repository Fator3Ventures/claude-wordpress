# Validação — Core 1.23.0

Ambiente local: PHP 8.3.6, WordPress instalado na bancada e MariaDB. Dados sintéticos, requisições externas e e-mail interceptados. Nenhuma implantação, teste em produção, envio real ao CRM ou e-mail de visitante foi realizado.

## Provas executadas

- Instalação nova e upgrade de cópia sintética real da 1.22.1. Preservação de 130 contatos com diários JSON, escalar, vazio e NULL, aviso pendente e procedência. Repetição em outra requisição. Origem desconhecida recusada sem iniciar migração. Retomada a partir de cada etapa e falha de agenda antes da conclusão.
- 1.205 intenções transferidas em 13 lotes; oito falhas, sete recuos, coalescência e retomada dirigida. Quota não consome tentativas. Concorrência CLI/HTTP/manual em processos separados: um efeito e uma ocorrência, origens separadas.
- Recuperação em processos novos: índice divergente com captura disponível, sentinela ausente/inválida, pausa, symlink e lock ocupado; recriação mantém pausa e documentação administrativa.
- Configuração sem alteração, só GTM, contexto/revisão concorrentes, lista vazia, procedência, Clarity e prova de tokens na aba Técnica. Render PHP das abas sob avisos convertidos em exceções. JavaScript/DOM em jsdom para renovação, segredo sem rascunho e seletor de mapas.
- Pipedrive com API simulada: criação única, releitura por ID, atividade, reconciliação e nota semântica. Phone BR válido/inválido, desligamento que preserva payload, escolha LinkedIn e evidência da seleção. Recuos 503, Retry-After 429, limite de produto 403, resposta inválida, catálogos paginados continuados e orçamento separado. Cem alertas encerrados seguidos de um novo; etiqueta complementar esgota sem duplicar a nota.
- Dois processos PHP de CRM: lease vence enquanto conexão mantém a trava; reenvio concorrente e aquisição por outro processo são recusados. Isto prova coordenação local, não concorrência entre sites ou operadores na API remota.
- Referência de consentimento perdida, negativas/revogação/conflito, índice utilizado pelo SQL, expurgo em lote de 500 que preserva decisão vinculada. Referência inválida em dados históricos mantém pendência; índice incompleto não permite expurgo.
- Redirect: pré-imagem com variantes de barra, repetição, restauração exata e preservação de _wp_old_slug. HTTP local confirmou 404 da rota retirada e 301 da outra rota histórica.
- MIME real construído por PHPMailer sem SMTP externo: multipart/alternative, texto e HTML, cabeçalhos, mensagem comum posterior, envio aninhado e interceptor sem segunda tentativa. HTML sintético gerado contém valores escapados e nenhuma imagem remota.
- Códigos finais recebidos de MCP 0.16.0 e Google 0.7.1 carregados nos dois caminhos e em duas ordens. Registro frio, contratos, diagnóstico efetivo, permissões documentais e guardas independentes. Os arquivos dos outros plugins permaneceram intactos.
- Lint de todos os arquivos PHP. Contratos/ajuda gerados do registro executável. Instalador fechado extraído e conferido byte a byte contra o manifesto, com os dois ciclos de instalação executados a partir dele. Evidências no ZIP fonte.

## Limites explícitos

O navegador Chromium disponível na bancada encerrou antes de carregar páginas. Por isso a validação de interface desta entrega é PHP/DOM e JavaScript em jsdom, **sem afirmar aprovação visual em navegador real**. A prévia HTML acompanha o fonte; conferir Gmail/Outlook e largura móvel na homologação. Uma tentativa de renderização alternativa não reproduziu corretamente as larguras e foi descartada.

SMTP real, chegada à caixa, OAuth/concessão remota Google, campos/limites da conta Pipedrive real, proxy/cache/CDN e proteção HTTP dos diretórios na hospedagem não foram exercitados. Simulação não substitui esses aceites. Pausa/retomada conjunta foi conferida localmente, sem realizar restore destrutivo de snapshot real. A integração de companheiros usou os arquivos dos ZIPs-fonte fornecidos, não os hashes declarados de instaladores indisponíveis.

Os JSON de evidência distinguem testes efetivos de fixtures. A suíte não declara cobertura exaustiva de todos os interleavings de banco/HTTP, falhas de filesystem e clientes de e-mail. Falhas controladas são injetadas apenas na bancada e não fazem parte do plugin instalado.
