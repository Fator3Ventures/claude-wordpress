> Core atual: **1.23.0**. Matriz e mudanças em [RELEASE-1.23.0.md](RELEASE-1.23.0.md); contrato 6.0.0. Referências a outras releases documentam histórico.

# Contratos — Core 1.22.0

A referência gerada está em `dados/configuracao-schema.json`, `dados/abilities-*.json` e `dados/contrato.json`. Configuração 5.2.0, schema de leads 6, política MCP 1 e SDK Google search-console-reader/1.0.0 são dimensões diferentes. Provider `base-site-core-fator3` é preservado.

Configuração: revisão opaca do valor, simulação por padrão, segredo mascarado, mescla parcial tipada quando explicitada. `persisted` confirma gravação; `audit` confirma procedência; `effect` descreve efeitos síncronos; `verification` descreve evidência. Não converter `ok` em prova de HTTP público, recebimento de e-mail ou commit remoto.

`procedencia.composicao`, `complementacoes` e `reparo` seguem PROCEDENCIA-1.22.md. Valor complementado muda revisão; reparo só de metadados não muda. Escrita concorrente exige releitura; falha de auditoria não apaga a prova de que um valor já persistiu.

Simulação de token Pipedrive candidato pode consultar users/me sem persistência local/comercial e devolve `verificacao_remota`. Recusa e indisponibilidade impedem substituir o segredo atual. Campos intocados não provocam essa consulta.

Abilities novas: `config-complementacoes-ler`, `config-procedencia-reparar`, `redirects-historico-ler`, `redirects-historico-escrever`, `pipedrive-reconciliar`, `pipedrive-atividade-reparar`. Consulte parâmetros no registro; não infira pelo rótulo. Reconciliação pode ler dados remotos na prévia e só altera com confirmação/provas atuais. Documentação estável por `documentacao`, mantendo `documentacao_1210` como transição.

Operação: mesma ocorrência nas retomadas, origens separadas e orçamento limitado. Ocupada/já processada não é falha de banco. Resultado incerto exige releitura antes de repetir criação/envio. Core pausado mantém documentação administrativa sem liberar negócio. `manter_pausado` na recriação não significa pronto para restore.

Permissões de leitura de jornada: f3base_ler_leads OU manage_options; gestão isolada não concede leitura. Configuração/CRM administrativo/redirects continuam exigindo administração, e redirects também edição do post. Conector soma sua política à autorização nativa.

Os exemplos das documentações são ilustrativos. Domínios, hashes, IDs e referências devem vir de leitura atual; não copiar IDs comerciais de outro site nem gravar diretamente no banco para contornar validação.

Clarity: cadastro humano no wp-admin, teste POST com nonce/permissão, revisão de projeto/token e cota compartilhada. GET da tela nunca chama o fornecedor. O vínculo local não é verificação independente da identidade do projeto. Consulte CLARITY-1.22.md. Não há nova ability ou mudança de schema de tabelas.

Google: `effective_status` é opcional. Sem anúncio em `capabilities.client_methods`, usar `status()` da conexão corrente. Se anunciado mas não chamável, retornar diagnóstico `unreadable/diagnostico_sdk_indisponivel`, sem fallback silencioso. Retorno inválido e exceção também degradam o diagnóstico. Nenhum desses estados concede acesso ou veta globalmente a consulta; `query()` revalida seus controles.
