# Fator3 Site Core 1.23.0

Instale o ZIP instalador em WordPress novo ou atualize exclusivamente a partir da **1.22.1 concluída**. Compatibilidade de integração: **MCP 0.16.0 e MCP Google 0.7.1**. Não há downgrade nem migração a partir de outras versões. O ZIP fonte é para desenvolvimento.

[Documentação instalada](DOCUMENTACAO.md) · [Mudanças e operação](RELEASE-1.23.0.md) · [Agentes e dados](AGENTES-1.23.0.md) · [Entrega e rastreabilidade](ENTREGA-1.23.0.md) · [Validação](VALIDACAO.md).

Avisos internos de contatos agora usam HTML com títulos, seções e espaçamento, além de alternativa MIME em texto. Pipedrive tem escolha explícita do campo LinkedIn, identificação opcional por telefone, verificações com recuo/cota separados, proteção das reservas e pendências complementares. O executor conserva ocorrências e exige retomada dirigida após oito falhas reais.

Leia a documentação no diretório docs do plugin instalado ou em `f3base/documentacao-ler`, com permissão administrativa, inclusive em recuperação. Segredos devem ser colados pelo dono na tela. O campo Clarity continua em Configurações → Clarity, vinculado ao projeto.

Os documentos com versões anteriores no nome são históricos. Tema, implantador e plugins companheiros não são alterados por esta entrega.
