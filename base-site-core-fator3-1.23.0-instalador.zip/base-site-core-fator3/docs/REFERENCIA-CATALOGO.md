# Referência do catálogo — 1.23.0

Gerada do registro executável. Chaves de configuração e schemas estão em dados/configuracao-schema.json; arquivos abilities-*.json contêm todas as abilities registradas na instalação ativa, com schemas e metadados. A disponibilidade em recuperação é reduzida.

## Módulos

### leads-whatsapp

Registra CTAs válidos pelo destino, inclusive links internos, telefone e e-mail, sem exigir WhatsApp configurado. O número de contato permite o WhatsApp flutuante opcional. Envia por fetch com confirmação e sendBeacon como reserva. Use f3base/ctas-inventariar para listar destinos rejeitados em lotes de conteúdo salvo, com cobertura explícita.

### endpoint-leads

Rota REST pública endurecida que recebe o beacon do clique: schema fechado com rejeição de campo desconhecido, limites por campo, token efêmero assinado, honeypot, rate limit e deduplicação atômica por chave única. Grava no repositório privado f3base_leads, com sessão quando permitida, correlação e contexto de origem.

### integracoes-contatos

Preserva contatos localmente e entrega ao CRM por fila. Importa Meta autorizada e recebe Google por webhook/chave ou reconciliação autenticada. Configuração em Contatos → Integrações; documentação em docs/PIPEDRIVE.md e docs/ORIGENS-ANUNCIOS.md. Integrações desligadas por padrão; nenhuma tag pública adicionada.

### cache-publico

Atualiza o índice de caminhos e os textos llms quando conteúdo, visibilidade ou configuração mudam.

### consentimento

Preserva a política legada e oferece modo opcional por categorias. O controle permite revisar e revogar medição e publicidade; decisões de publicidade são verificadas no servidor antes de enviar pela fila.

### tracking

Emite as tags de GA4, Google Ads, Meta e LinkedIn a partir dos IDs gravados, sob um único portão de consentimento, e instrumenta o COMPORTAMENTO do visitante pelo mesmo portão: marcos de rolagem, seção vista, clique em link externo, fricção, erro de JavaScript do próprio site e Core Web Vitals de campo, todos com nome, parâmetro e teto por página declarados num arquivo só. O contêiner GTM soma-se aos slots diretos; não repita no contêiner os IDs já configurados nos slots. f3base/tracking-verificar-gtm ajuda a diagnosticar duplicidades. Cada destino respeita sua categoria de consentimento; slot vazio é inerte e nada é emitido.

### comportamento

Recebe, ao fim de cada visita, os totais agregados daquela página e os soma numa tabela própria — uma linha por dia, caminho, evento e detalhe. É a leitura que o site tem por conta própria, sem depender de conta de fornecedor.

### acessos-servidor

Soma requisições de arquivos datados do servidor por página, família declarada, método e status. Não guarda IP, referer nem User-Agent bruto. Caminhos públicos ainda podem conter dados pessoais; exclua as rotas privadas.

### sessao-de-login

Define o prazo das novas sessões e mantém o login ao fechar o navegador no formulário nativo.

### meta-capi

Envia o evento Lead de SERVIDOR para a Conversions API da Meta depois da persistência confirmada do lead, com o MESMO event_id que o navegador já manda no Pixel — é ele que deduplica os dois caminhos. E-mail e telefone saem em SHA-256 sobre o valor normalizado; nada de dado pessoal em claro. O token é option do site e nunca viaja no arquivo de configuração.

### verificacao-dominio

Emite no <head> a metatag de verificação de posse do domínio de cada token gravado — google-site-verification e facebook-domain-verification. Option vazia é inerte: nenhuma tag é emitida por ela. Valor fora da forma esperada é preservado e avisado, nunca apagado.

### rota-origem

Requisita um caminho do próprio site a partir do servidor e devolve status, cabeçalhos e corpo carimbados com a fase origem. Aceita apenas caminho do próprio home_url, valida o host e não segue redirecionamento para fora.

### llms-txt-reserva

Serve /llms.txt por rota virtual quando ela é a responsável pelo endereço: arquivo físico na raiz vence, emissor concorrente medido vem depois, e só então esta rota. A lista junta a seleção curada da configuração com a enumeração do conteúdo publicado, conforme o modo declarado, e exclui o que está em noindex. Registrada em template_redirect prioridade 0 para não receber a barra final de redirect_canonical.

### llms-full-txt

Serve /llms-full.txt com o conteúdo integral em Markdown de cada item que o llms.txt lista — mesma seleção, mesmas exclusões e mesma precedência de emissor. Ativado por padrão. Reúne os textos completos dos itens selecionados, sem o corte de palavras usado no índice.

### llms-markdown

Publica alternativas Markdown apenas para conteúdos públicos selecionados no llms.txt e anuncia os endereços no HTML e no cabeçalho Link.

### robots-txt

Publica as regras do WordPress e dos plugins, confirma a resposta HTTP e mantém um arquivo gerenciado quando a hospedagem intercepta a rota virtual. Guarda o original e restaura ao desligar.

### redirects

Redireciona slugs antigos de páginas e posts lendo _f3base_old_slug, tratando as query vars pagename e name, e aplica os pares declarados em f3base_redirects antes do 404.

### noindex-honrado

Lê o noindex gravado nas chaves do plugin de SEO — meta por conteúdo, padrões por tipo e taxonomia, noindex por termo — e o aplica pelo filtro wp_robots mesmo com o plugin desativado. Arquivo de categoria raso recebe noindex, follow.

### schema-extensao

Acrescenta ao grafo do plugin de SEO os nós Service e as propriedades de entidade declaradas na configuração, pelos filtros do próprio plugin. Lê o FAQ dos blocos core/details da página; sameAs sai só com URL declarada.

### retencao-e-eliminacao

Limpa registros de lead pelo prazo declarado em WP-Cron, medindo o próprio atraso e se recuperando no carregamento seguinte; registra exportador e eraser do core; e expõe a rota de eliminação com journal que separa limpeza operacional reversível de eliminação irreversível a pedido do titular.

### cabecalhos

Emite no front-end os cabeçalhos de segurança declarados na configuração, cada um com o valor gravado. COOP sai como está gravado, e o estado nomeia a consequência quando não for same-origin-allow-popups; HSTS sai apenas quando ligado por decisão e sobre HTTPS.

### cadencia-relatorio

Mantém um registro local da última execução: mede módulos, relê configurações e faz censo demonstrativo. Não envia mensagens, não corrige configurações e não guarda histórico completo. Executa pela periodicidade configurada ou ao atingir o número de ajustes; informa horários, duração, erros e próxima execução.
