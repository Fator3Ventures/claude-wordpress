<?php
/** Matriz explícita. Diagnóstico local não inicializa o canal nem concede permissões. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Companheiros {
    public static function mcp(): array {
        $r=array('requerida'=>'0.16.0','observada'=>defined('F3_MCP_FILES_VERSION')?F3_MCP_FILES_VERSION:null,'compativel'=>false,'codigo'=>'mcp_ausente');
        if(!$r['observada']){return $r;}if($r['observada']!=='0.16.0'){$r['codigo']='versao_mcp_incompativel';return $r;}
        try {if(!is_callable(array('Fator3\\McpFiles\\ServerContract','capabilities'))){$r['codigo']='contrato_mcp_indisponivel';return $r;}$c=\Fator3\McpFiles\ServerContract::capabilities();$r['compativel']=($c['contract']??'')==='server-integration/1.0.0'&&($c['policy_contract']??null)===1&&($c['version']??'')==='0.16.0';$r['codigo']=$r['compativel']?'compativel':'contrato_mcp_incompativel';}catch(Throwable $e){$r['codigo']='contrato_mcp_indisponivel';}return $r;
    }
    public static function google(): array {$v=defined('F3_MCP_GOOGLE_VERSION')?F3_MCP_GOOGLE_VERSION:null;return array('requerida'=>'0.7.1','observada'=>$v,'compativel'=>$v==='0.7.1','codigo'=>$v===null?'google_ausente':($v==='0.7.1'?'compativel':'versao_google_incompativel'));}
}
