<?php
/** Private inbox, definitions, operational abilities and WordPress privacy integration. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Leads_Admin {
	public static function pode( string $cap = 'f3base_ler_leads' ): bool {
		return current_user_can( 'manage_options' ) || current_user_can( $cap ); }
	public static function iniciar(): void {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 9 );
        add_action('admin_init',array(__CLASS__,'salvar_formulario_prg'));
		add_action( 'wp_abilities_api_init', array( __CLASS__, 'abilities' ) );
		add_action( 'admin_post_f3base_exportar_registro', array( __CLASS__, 'exportar_zip' ) );
		add_action( 'admin_post_f3base_anexo', array( __CLASS__, 'anexo' ) );
        add_action('admin_enqueue_scripts',static function(){if(str_starts_with((string)($_GET['page']??''),'f3base-')){wp_enqueue_style('f3base-contatos',F3BASE_PLUGIN_URL.'assets/f3base-contatos.css',array(),F3BASE_PLUGIN_VERSAO);}});
		add_action( 'admin_post_f3base_csv', array( __CLASS__, 'csv' ) );
		add_filter(
			'wp_privacy_personal_data_exporters',
			static function ( $a ) {
				$a['f3base-contatos-proprios'] = array(
					'exporter_friendly_name' => 'Contatos Core',
					'callback'               => array( __CLASS__, 'exportar' ),
				);
				return $a;
			}
		);
		add_filter(
			'wp_privacy_personal_data_erasers',
			static function ( $a ) {
				$a['f3base-contatos-proprios'] = array(
					'eraser_friendly_name' => 'Contatos Core',
					'callback'             => array( __CLASS__, 'apagar' ),
				);
				return $a;
			}
		);
		add_action( F3Base_Leads_Notificacoes::EVENTO, array( __CLASS__, 'reter' ) );
		add_action(
			'admin_init',
			static function (): void {
				$role = get_role( 'administrator' );
				if ( $role ) {
					foreach ( array( 'f3base_ler_leads', 'f3base_gerir_leads', 'f3base_gerir_formularios', 'f3base_exportar_leads', 'f3base_baixar_anexos' ) as $c ) {
						if ( ! $role->has_cap( $c ) ) {
								$role->add_cap( $c );
						}
					}
				} }
		);
		add_action(
			'enqueue_block_editor_assets',
			static function (): void {
				wp_enqueue_script( 'f3base-formulario-bloco', F3BASE_PLUGIN_URL . 'assets/f3base-formulario-bloco.js', array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor' ), F3BASE_PLUGIN_VERSAO, true );
			}
		);
	}
	public static function abilities(): void {
		$p = array(
            'segmento'=>array('type'=>'string','enum'=>F3Base_Testes::SEGMENTOS),
			'record_id' => array(
				'type'    => 'string',
				'pattern' => '^[a-f0-9]{32}$',
			),
			'cursor'    => array( 'type' => 'string' ),
			'limite'    => array(
				'type'    => 'integer',
				'minimum' => 1,
				'maximum' => 100,
			),
			'lixeira'   => array( 'type' => 'boolean' ),
		);
		foreach ( array( 'aparelho', 'metodo', 'formulario', 'captura', 'atendimento', 'email', 'sessao', 'correlacao', 'post_id', 'busca', 'de', 'ate', 'plataforma', 'conta_id', 'campanha_id', 'grupo_id', 'anuncio_id' ) as $k ) {
			$p[ $k ] = array( 'type' => 'string' ); }
		$p['aparelho']=array('type'=>'string','enum'=>array('celular','tablet','computador','nao_identificado'));
        F3Base_Servicos::ability( 'leads-registros-ler', 'Ler registros privados de contatos; escolha explícita, sem efeitos', array( __CLASS__, 'ler' ), $p, array(), true, 'f3base_ler_leads' );
		F3Base_Servicos::ability(
			'leads-atualizar',
			'Simular ou atualizar atendimento, suspeita e lixeira com revisão',
			static function ( $e ) {
				return self::pode( 'f3base_gerir_leads' ) ? F3Base_Leads_Repositorio::atualizar( $e ) : array(
					'ok'     => false,
					'codigo' => 'sem_permissao',
				);
			},
			array(
				'record_id'        => $p['record_id'],
				'revisao_esperada' => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
				'simular'          => array(
					'type'    => 'boolean',
					'default' => true,
				),
				'alteracoes'       => array(
					'type'                 => 'object',
					'additionalProperties' => false,
					'properties'           => array(
						'atendimento' => array(
							'type' => 'string',
							'enum' => array( 'novo', 'respondido', 'spam' ),
						),
						'captura'     => array(
							'type' => 'string',
							'enum' => array( 'aceito', 'suspeito' ),
						),
						'lixeira'     => array( 'type' => 'boolean' ),
					),
				),
			),
			array( 'record_id', 'revisao_esperada', 'alteracoes' ),
			false,
			'f3base_gerir_leads'
		);
		F3Base_Servicos::ability(
			'leads-avisos-reenviar',
			'Reconciliar ou reenviar aviso interno explicitamente',
			array( F3Base_Leads_Notificacoes::class, 'reenviar' ),
			array(
				'record_id'                   => $p['record_id'],
				'simular'                     => array(
					'type'    => 'boolean',
					'default' => true,
				),
				'revisao_esperada'            => array( 'type' => 'string' ),
				'aceitar_possivel_duplicacao' => array(
					'type'    => 'boolean',
					'default' => false,
				),
			),
			array( 'record_id' ),
			false,
			'f3base_gerir_leads'
		);
		F3Base_Servicos::ability(
			'leads-eliminar-registro',
			'Eliminar registro privado com journal, anexos e concessões',
			static function ( $e ) {
				if ( ! self::pode( 'f3base_gerir_leads' ) ) {
					return array(
						'ok'     => false,
						'codigo' => 'sem_permissao',
					); }
				$r = F3Base_Leads_Repositorio::obter( $e['record_id'] ?? '' );
				if ( ! $r || (int) $r['revisao'] !== (int) ( $e['revisao_esperada'] ?? 0 ) ) { // phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Comparison of runtime expressions; neither side is an assignable literal.
					return array(
						'ok'     => false,
						'codigo' => 'conflito',
					); }
				if ( $e['simular'] ?? true ) {
					return array(
						'ok'            => true,
						'simulado'      => true,
						'anexos'        => count( $r['anexos'] ),
						'origem_legada' => (bool) $r['origem_chave'],
						'reversivel'    => false,
					); }
				$ok = F3Base_Leads_Repositorio::eliminar( $r['record_id'] );
				return array(
					'ok'        => $ok,
					'eliminado' => $ok,
					'pendente'  => ! $ok,
				);
			},
			array(
				'record_id'        => $p['record_id'],
				'revisao_esperada' => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
				'simular'          => array(
					'type'    => 'boolean',
					'default' => true,
				),
			),
			array( 'record_id', 'revisao_esperada' ),
			false,
			'f3base_gerir_leads'
		);
		F3Base_Servicos::ability(
			'formularios-diagnosticar',
			'Estado de armazenamento e definições de formulário',
			static fn()=>array(
				'ok'         => true,
				'arquivos'   => F3Base_Arquivos_Privados::diagnostico(),
				'quantidade' => count( F3Base_Options::ler( 'f3base_formularios' ) ),
				'revisao'    => F3Base_Options::revisao( 'f3base_formularios' ),
			)
		);
	}
	public static function ler( $e = array() ): array {
		if ( ! self::pode() ) {
			return array(
				'ok'     => false,
				'codigo' => 'sem_permissao',
			); }
		if ( ! empty( $e['record_id'] ) ) {
			$r = F3Base_Leads_Repositorio::obter( $e['record_id'] );
			if ( $r ) {
				unset( $r['idempotencia'], $r['payload_hash'], $r['importado_hash'] );$r['crm']['pipedrive']=F3Base_Pipedrive_Fila::registro($r['record_id']);
			} return array(
				'ok'       => (bool) $r,
				'registro' => $r,
			); }
		unset($e['record_id']);return F3Base_Leads_Repositorio::consultar( $e );
	}
	public static function menu(): void {
		add_menu_page( 'Contatos', 'Contatos', current_user_can('manage_options')?'manage_options':'f3base_ler_leads', 'f3base-leads', array( __CLASS__, 'tela' ), 'dashicons-email-alt2', 26 ); // phpcs:ignore WordPress.WP.Capabilities.Unknown -- Custom capabilities are registered on the administrator role in iniciar(); callbacks independently enforce them.
		add_submenu_page('f3base-leads', 'Contatos', 'Todos os contatos', current_user_can('manage_options')?'manage_options':'f3base_ler_leads', 'f3base-leads', array(__CLASS__, 'tela'));
		add_submenu_page( 'f3base-leads', 'Formulários', 'Formulários', current_user_can('manage_options')?'manage_options':'f3base_gerir_formularios', 'f3base-formularios', array( __CLASS__, 'formularios' ) ); // phpcs:ignore WordPress.WP.Capabilities.Unknown -- Custom capabilities are registered on the administrator role in iniciar(); callbacks independently enforce them.
		add_submenu_page( 'f3base-leads', 'Conteúdo privado', 'Conteúdo privado', current_user_can('manage_options')?'manage_options':'f3base_gerir_formularios', 'f3base-conteudos', array( __CLASS__, 'conteudos' ) ); // phpcs:ignore WordPress.WP.Capabilities.Unknown -- Custom capabilities are registered on the administrator role in iniciar(); callbacks independently enforce them.
	}
	public static function tela(): void {
		if ( ! self::pode() ) {
			return;
		} echo '<div class="wrap"><h1>Contatos</h1>';
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			check_admin_referer( 'f3base-leads' );
			if ( self::pode( 'f3base_gerir_leads' ) ) {
				$d = array(
					'atendimento' => sanitize_key( $_POST['atendimento'] ?? 'novo' ),
					'lixeira'     => isset( $_POST['lixeira'] ),
				);
				if ( isset( $_POST['aprovar'] ) ) {
					$d['captura'] = 'aceito'; }
				$r = F3Base_Leads_Repositorio::atualizar(
					array(
						'record_id'        => sanitize_key( $_POST['record_id'] ?? '' ),
						'revisao_esperada' => (int) ( $_POST['revisao'] ?? 0 ),
						'alteracoes'       => $d,
						'simular'          => false,
					)
				);
				echo '<p>' . esc_html( $r['codigo'] ?? 'Atualizado' ) . '</p>';
			}
		}
		$id = sanitize_key( $_GET['record_id'] ?? '' );
		if ( $id ) {
			$r = F3Base_Leads_Repositorio::obter( $id );
			if ( ! $r ) {
				echo '<p>Registro indisponível.</p></div>';
				return; }
            $retorno=array('page'=>'f3base-leads');foreach(array('aparelho','metodo','formulario','captura','atendimento','de','ate','busca','segmento','cursor','email','lixeira','plataforma','conta_id','campanha_id','grupo_id','anuncio_id') as $k){if(isset($_GET[$k])&&is_string($_GET[$k])){$retorno[$k]=sanitize_text_field(wp_unslash($_GET[$k]));}}
            echo '<p><a href="'.esc_url(add_query_arg($retorno,admin_url('admin.php'))).'">Voltar à lista filtrada</a></p><h2>'.esc_html($r['nome']?:($r['email']?:'Clique de contato')).($r['classe_trafego']==='teste'?' <strong class="f3base-teste">TESTE</strong>':'').'</h2>';
            echo '<p>'.esc_html($r['email']).' · '.esc_html(F3Base_Relatorios::rotulo($r['metodo'])).' · '.esc_html(F3Base_Relatorios::rotulo($r['captura'])).' · '.esc_html(F3Base_Relatorios::rotulo($r['atendimento'])).'</p>';
            echo '<p><strong>'.esc_html(implode(' · ',array_filter(array(F3Base_Contato_Apresentacao::rotulo_aparelho($r['aparelho']??'nao_identificado'),$r['dados']['contexto']['aparelho']['sistema']??'',$r['dados']['contexto']['aparelho']['navegador']??'')))).'</strong> '.'</p>'; $horario=strtotime($r['criado_em'].' UTC');echo '<p>Recebido '.esc_html(wp_date('d/m/Y H:i:s',$horario)).' ('.esc_html(wp_timezone_string()).') · Tráfego: '.esc_html($r['classe_trafego']==='teste'?'Teste':'Não marcado').'</p>';
            F3Base_Contato_Apresentacao::html_contato(F3Base_Contato_Apresentacao::montar($r,false));
            echo '<h3>Pipedrive</h3><p>'.esc_html(($crm=F3Base_Pipedrive_Fila::registro($id))['estado'].' — '.($crm['codigo']??'Não há solicitação de entrega elegível.')).'</p>';if(current_user_can('manage_options')){echo '<a href="'.esc_url(admin_url('admin.php?page=f3base-integracoes&integracao=entregas')).'">Consultar entregas e reenvios</a>';}echo '<details><summary>Vínculos do CRM</summary><pre>'.esc_html(wp_json_encode($crm,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details>';
            echo '<h3>Entrega de avisos</h3><p>Equipe: '.esc_html(F3Base_Relatorios::rotulo($r['aviso'])).' · Visitante: '.esc_html(F3Base_Relatorios::rotulo($r['resposta'])).'. Processado indica aceite pelo transporte, sem comprovar recebimento.</p>';
            echo '<details><summary>Detalhes técnicos do contato</summary><p>Sessão: '.esc_html($r['sessao']?:'Indisponível').' · Correlação: '.esc_html($r['correlacao']?:'Indisponível').'</p><pre style="white-space:pre-wrap">'.esc_html(wp_json_encode($r['dados'],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details>';

			foreach ( $r['anexos'] as $a ) {
				echo '<p><a href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=f3base_anexo&id=' . $a['id'] ), 'f3base-anexo' ) ) . '">' . esc_html( $a['nome'] ) . '</a> — ' . esc_html( (string) $a['bytes'] ) . ' bytes</p>';if(!empty($a['mime_alerta'])){echo '<p><strong>Confira o anexo: extensão e MIME detectado divergentes.</strong></p>';} }
			if ( self::pode( 'f3base_gerir_leads' ) ) {
				echo '<form method="post">';
				wp_nonce_field( 'f3base-leads' );
				echo '<input type="hidden" name="record_id" value="' . esc_attr( $id ) . '"><input type="hidden" name="revisao" value="' . (int) $r['revisao'] . '"><select name="atendimento">';
				foreach ( array( 'novo', 'respondido', 'spam' ) as $v ) {
					echo '<option' . selected( $v, $r['atendimento'], false ) . '>' . esc_html( $v ) . '</option>'; }
				echo '</select><label><input type="checkbox" name="lixeira"' . checked( (bool) $r['lixeira'], true, false ) . '> Lixeira</label><label><input type="checkbox" name="aprovar"> Aprovar suspeito (sem conversão retroativa)</label><button class="button">Salvar</button></form>';
			}
			if ( self::pode( 'f3base_exportar_leads' ) && self::pode( 'f3base_baixar_anexos' ) ) {
				echo '<p><a href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=f3base_exportar_registro&record_id=' . $id ), 'f3base-exportar-registro' ) ) . '">Exportar registro e anexos em ZIP privado</a></p>'; }
			if ( $r['email'] ) {
				echo '<a href="' . esc_url( admin_url( 'admin.php?page=f3base-leads&email=' . rawurlencode( $r['email'] ) ) ) . '">Agrupar por e-mail</a>'; }
		} else {
			$f = array();
			foreach ( array( 'aparelho', 'metodo', 'formulario', 'captura', 'atendimento', 'email', 'sessao', 'correlacao', 'post_id', 'busca', 'de', 'ate', 'segmento', 'cursor', 'plataforma', 'conta_id', 'campanha_id', 'grupo_id', 'anuncio_id' ) as $k ) {
				if ( isset( $_GET[ $k ] ) ) {
					$f[ $k ] = sanitize_text_field( wp_unslash( (string) $_GET[ $k ] ) );
				}
			} $f['lixeira'] = ! empty( $_GET['lixeira'] );
			echo '<form method="get"><input type="hidden" name="page" value="f3base-leads"><label>Aparelho <select name="aparelho"><option value="">Todos</option>';foreach(array('celular','tablet','computador','nao_identificado') as $tipo){echo '<option value="'.$tipo.'" '.selected($f['aparelho']??'',$tipo,false).'>'.esc_html(F3Base_Contato_Apresentacao::rotulo_aparelho($tipo)).'</option>';}echo '</select></label> ';
			foreach ( array(
				'busca'       => 'Nome/e-mail',
				'metodo'      => 'Método',
				'formulario'  => 'Formulário',
				'captura'     => 'Captura',
				'atendimento' => 'Atendimento',
				'de'          => 'De (AAAA-MM-DD)',
				'ate'         => 'Até (AAAA-MM-DD)',
                'plataforma'=>'Plataforma','conta_id'=>'Conta ID','campanha_id'=>'Campanha ID','grupo_id'=>'Grupo ID','anuncio_id'=>'Anúncio ID',
			) as $k => $label ) {
				$opcoes=array('plataforma'=>array('meta_ads','google_ads','linkedin_ads','openai_ads','nao_identificada'),'metodo'=>array('formulario','whatsapp_formulario','conteudo','whatsapp_cta','contato_cta','legado_desconhecido'),'captura'=>array('aceito','clique','suspeito'),'atendimento'=>array('novo','respondido','spam'));
                if($k==='formulario'){echo '<label>Formulário <select name="formulario"><option value="">Todos</option>';foreach((array)F3Base_Options::ler('f3base_formularios') as $form){echo '<option value="'.esc_attr($form['id']).'" '.selected($f[$k]??'',$form['id'],false).'>'.esc_html($form['titulo'].' ('.$form['id'].')').'</option>';}if(!empty($f[$k])&&!in_array($f[$k],array_column((array)F3Base_Options::ler('f3base_formularios'),'id'),true)){echo '<option selected value="'.esc_attr($f[$k]).'">'.esc_html($f[$k].' (histórico)').'</option>';}echo '</select></label> ';}elseif(isset($opcoes[$k])){echo '<label>'.esc_html($label).' <select name="'.esc_attr($k).'"><option value="">Todos</option>';foreach($opcoes[$k] as $v){echo '<option value="'.esc_attr($v).'" '.selected($f[$k]??'',$v,false).'>'.esc_html(F3Base_Relatorios::rotulo($v)).'</option>';}echo '</select></label> ';}else{echo '<label>'.esc_html($label).' <input type="'.(in_array($k,array('de','ate'),true)?'date':'text').'" name="'.esc_attr($k).'" value="'.esc_attr($f[$k]??'').'"></label> ';} }
			F3Base_Testes::seletor($f['segmento']??F3Base_Testes::segmento());echo '<label><input type="checkbox" name="lixeira" value="1"' . checked( $f['lixeira'], true, false ) . '>Lixeira</label><button class="button">Filtrar</button></form>';
			$r = F3Base_Leads_Repositorio::consultar( $f );
            if(empty($r['ok'])){echo '<p role="alert">'.esc_html($r['codigo']??'Consulta indisponível').'</p></div>';return;}if(empty($r['registros'])){echo '<p>Nenhum contato com estes filtros.</p>';}
			echo '<table class="widefat striped"><thead><tr><th>Data (fuso do site)</th><th>Contato</th><th>Método</th><th>Estado</th><th>Aparelho / tráfego</th><th>Aviso</th></tr></thead><tbody>';
			foreach ( $r['registros'] ?? array() as $l ) {
				echo '<tr><td>' . esc_html( wp_date('d/m/Y H:i:s',strtotime($l['criado_em'].' UTC')) ) . '</td><td><a href="' . esc_url( add_query_arg(array_merge($f,array('page'=>'f3base-leads','record_id'=>$l['record_id'])),admin_url('admin.php')) ) . '">' . esc_html( $l['nome'] ? $l['nome'] : ( $l['email'] ? $l['email'] : 'Clique de contato' ) ) . '</a>'.($l['classe_trafego']==='teste'?' <strong class="f3base-teste">TESTE</strong>':'').'</td><td>' . esc_html( F3Base_Relatorios::rotulo($l['metodo']) ) . '</td><td>' . esc_html( F3Base_Relatorios::rotulo($l['captura']) . ' / ' . F3Base_Relatorios::rotulo($l['atendimento']) ) . '</td><td>'.esc_html(F3Base_Contato_Apresentacao::rotulo_aparelho($l['aparelho']??'nao_identificado')).'</td><td>' . esc_html( $l['aviso'] . ' / visitante: ' . $l['resposta'] ) . '</td></tr>'; }
			echo '</tbody></table>';
			if ( ! empty( $r['proximo_cursor'] ) ) {
				echo '<a class="button" href="' . esc_url( add_query_arg( 'cursor', $r['proximo_cursor'] ) ) . '">Próxima página</a>'; }
			if ( self::pode( 'f3base_exportar_leads' ) ) {
				echo '<p><a href="' . esc_url( wp_nonce_url( add_query_arg(array_merge($f,array('action'=>'f3base_csv','cursor'=>false)),admin_url('admin-post.php')), 'f3base-csv' ) ) . '">Exportar CSV</a></p>'; }
		}
		echo '</div>';
	}
    public static function salvar_formulario_prg(): void {
        if(($_SERVER['REQUEST_METHOD']??'')!=='POST'||($_GET['page']??'')!=='f3base-formularios'||!isset($_POST['aplicar'],$_POST['definicoes'])||!self::pode('f3base_gerir_formularios')){return;}
        check_admin_referer('f3base-formularios');$v=json_decode(wp_unslash((string)$_POST['definicoes']),true);$rev=sanitize_text_field($_POST['revisao']??'');
        if(F3Base_Formularios::recusar($v)||!F3Base_Options::operavel('f3base_formularios')||!hash_equals(F3Base_Options::revisao('f3base_formularios'),$rev)){return;}
        $r=F3Base_Options::gravar('f3base_formularios',$v,F3Base_Options::ORIGEM_MANUAL,$rev);
        if(!empty($r['persisted'])){wp_safe_redirect(add_query_arg(array('page'=>'f3base-formularios','formulario'=>sanitize_key($_POST['selecionado']??''),'salvo'=>1),admin_url('admin.php')),303);exit;}
    }
	public static function formularios(): void {
		if ( ! self::pode( 'f3base_gerir_formularios' ) ) {
			return; }
		wp_enqueue_script( 'f3base-formularios-editor', F3BASE_PLUGIN_URL . 'assets/f3base-formularios-editor.js', array(), F3BASE_PLUGIN_VERSAO, true );
        if(isset($_GET['salvo'])){echo '<div class="notice notice-success"><p>Formulário salvo.</p></div>';}
		$definicoes = F3Base_Options::ler( 'f3base_formularios' );$revisao_editor=F3Base_Options::revisao('f3base_formularios');
		echo '<div class="wrap"><h1>Formulários próprios</h1><p>Use o bloco Formulário Core ou <code>[f3base_formulario id="contato"]</code>. Ordem dos campos é a ordem da lista. A resposta ao visitante é opcional e vem desligada por padrão em cada formulário.</p>';
		if ( isset( $_POST['definicoes'] ) ) {
			check_admin_referer( 'f3base-formularios' );
			$v      = json_decode( wp_unslash( (string) $_POST['definicoes'] ), true );
			$rev    = sanitize_text_field( $_POST['revisao'] ?? '' );$revisao_editor=$rev;
			$motivo = F3Base_Formularios::recusar( $v );
			if ( $motivo ) {
				$r = array(
					'ok'     => false,
					'motivo' => $motivo,
				); } elseif ( ! F3Base_Options::operavel( 'f3base_formularios' ) ) {
				$r = array(
					'ok'     => false,
					'motivo' => 'Habilite f3base_formularios em F3 Base → Operação.',
				); } elseif ( ! hash_equals( F3Base_Options::revisao( 'f3base_formularios' ), $rev ) ) {
					$r = array(
						'ok'     => false,
						'motivo' => 'Conflito de revisão. Recarregue e compare.',
					); } elseif ( isset( $_POST['aplicar'] ) ) {
					$r = F3Base_Options::gravar( 'f3base_formularios', $v, F3Base_Options::ORIGEM_MANUAL, $rev ); } else {
						$r = array(
							'ok'       => true,
							'simulado' => true,
							'depois'   => $v,
						); }
					if(!empty($r['persisted'])){$revisao_editor=F3Base_Options::revisao('f3base_formularios');}
                    if ( is_array( $v ) ) {
						$definicoes = $v; }
                    if(!empty($r['simulado'])&&!empty($r['ok'])){foreach($v as $def){$method=array('registro'=>'formulario','whatsapp'=>'whatsapp_formulario','conteudo'=>'conteudo')[$def['regime']??'registro'];echo '<p><strong>Assunto do aviso — '.esc_html($def['titulo']).':</strong> '.esc_html(F3Base_Leads_Notificacoes::assunto($def['assunto']??$def['titulo'],$method,false,'Nome de exemplo')).'</p>';}}
					echo '<p role="status">'.esc_html(!empty($r['persisted'])?'Definições salvas.':(!empty($r['simulado'])?'Validação concluída; confira a prévia.':($r['motivo']??'Não foi possível salvar.'))).'</p><details><summary>Resultado técnico</summary><pre>'.esc_html(wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details>';
		}
        $usos=array();foreach($definicoes as $d){if(!is_array($d)||!is_string($d['id']??null)){continue;}$usos[$d['id']]=array_map(static fn($p)=>array('id'=>(int)$p['ID'],'titulo'=>$p['post_title'],'editar'=>!empty($p['ID'])&&current_user_can('edit_post',(int)$p['ID'])?get_edit_post_link((int)$p['ID'],'raw'):''),F3Base_Formularios::referencias($d['id']));}
        wp_localize_script('f3base-formularios-editor','f3baseEditorDados',array('usos'=>$usos,'contatos'=>admin_url('admin.php?page=f3base-leads'),'selecionado'=>sanitize_key($_POST['selecionado']??$_GET['formulario']??'')));
		echo '<noscript><p>O editor visual exige JavaScript. O editor JSON abaixo permite configurar e validar as mesmas definições.</p></noscript><form method="post">';
		wp_nonce_field( 'f3base-formularios' );
		echo '<input type="hidden" name="revisao" value="' . esc_attr( $revisao_editor ) . '"><input type="hidden" name="selecionado" value=""><details><summary>Editor avançado JSON</summary><textarea id="f3base-definicoes" name="definicoes" rows="28" style="width:100%;font-family:monospace">' . esc_textarea( wp_json_encode( $definicoes, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) . '</textarea></details><p><button class="button" name="simular">Validar e simular</button> <button class="button button-primary" name="aplicar">Salvar definições</button></p></form>';
		if ( isset( $_POST['simular'] ) && empty( $motivo ) ) {
			foreach ( $definicoes as $def ) {
                if(($def['id']??'')!==sanitize_key($_POST['selecionado']??'')){continue;}
				echo '<h2>Prévia: ' . esc_html( $def['titulo'] ) . '</h2><fieldset disabled>' . F3Base_Formularios::renderizar_definicao( $def ) . '</fieldset><p>Referências afetadas: ' . esc_html( wp_json_encode( F3Base_Formularios::referencias( $def['id'] ), JSON_UNESCAPED_UNICODE ) ) . '</p>'; } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Own renderer escapes text/attributes and filters static HTML; this is a disabled preview of a validated definition.
		}
		echo '<details><summary>Modelo de formulário</summary><pre>' . esc_html(
			wp_json_encode(
				array(
					array(
						'id'          => 'contato',
						'titulo'      => 'Contato',
						'regime'      => 'registro',
						'campos'      => array(
							array(
								'nome'        => 'nome',
								'tipo'        => 'text',
								'rotulo'      => 'Nome',
								'papel'       => 'nome',
								'obrigatorio' => true,
							),
							array(
								'nome'        => 'email',
								'tipo'        => 'email',
								'rotulo'      => 'E-mail',
								'papel'       => 'email',
								'obrigatorio' => true,
							),
							array(
								'nome'        => 'mensagem',
								'tipo'        => 'textarea',
								'rotulo'      => 'Mensagem',
								'papel'       => 'mensagem',
								'obrigatorio' => true,
							),
						),
						'confirmacao' => 'Obrigado. Seu contato foi registrado.',
					),
				),
				JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
			)
		) . '</pre></details>';
        $diag=F3Base_Arquivos_Privados::diagnostico();echo '<h2>Anexos e armazenamento</h2><p>'.esc_html(!empty($diag['disponivel'])?'Pasta privada disponível.':(!empty($diag['criavel'])?'Pasta ainda não criada, mas pode ser preparada.':'Pasta indisponível; confira o diagnóstico técnico.')).'</p><p>Sem teto de tamanho ou extensão pelo plugin quando o campo não define restrições. PHP: '.esc_html($diag['upload_max_filesize']).' por arquivo e '.esc_html($diag['post_max_size']).' para o envio completo. O limite do proxy não é informado pelo PHP.</p><details><summary>Diagnóstico técnico dos anexos</summary><pre style="white-space:pre-wrap">'.esc_html(wp_json_encode($diag,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details></div>';
	}
	public static function conteudos(): void {
		if ( ! self::pode( 'f3base_gerir_formularios' ) ) {
			return;
		} echo '<div class="wrap"><h1>Conteúdo privado</h1><p>O ID do arquivo entra no campo ativo do formulário com regime conteudo.</p>';
		if ( ! empty( $_FILES['arquivo'] ) ) {
			check_admin_referer( 'f3base-conteudo' );
			$r = F3Base_Arquivos_Privados::receber( $_FILES['arquivo'], 'conteudo' );
			if ( $r['ok'] ) {
				global $wpdb;
				$wpdb->update( F3Base_Leads_Repositorio::tabela( 'arquivos_leads' ), array( 'estado' => 'ativo' ), array( 'id' => $r['arquivo']['id'] ) ); }
			echo '<p role="status">'.esc_html(!empty($r['ok'])?'Arquivo privado guardado.':($r['motivo']??$r['codigo']??'Não foi possível salvar.')).'</p><details><summary>Resultado técnico</summary><pre>'.esc_html(wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details>';
		}
		echo '<form method="post" enctype="multipart/form-data">';
		wp_nonce_field( 'f3base-conteudo' );
		echo '<input type="file" name="arquivo" required><button class="button">Guardar arquivo privado</button></form>';
        $pagina=max(1,(int)($_GET['pagina']??1));$lista=F3Base_Arquivos_Servico::listar(array('pagina'=>$pagina));
        echo '<h2>Materiais disponíveis</h2><p>Substituições por canal mantêm os links vigentes e seus limites; links vencidos continuam vencidos.</p><table class="widefat striped"><thead><tr><th>Material / ID</th><th>Tamanho e tipo</th><th>Formulários</th><th>Atualização</th></tr></thead><tbody>';
        foreach($lista['arquivos']??array() as $a){echo '<tr><td>'.esc_html($a['nome']).'<br><code>'.esc_html($a['id']).'</code></td><td>'.esc_html(size_format($a['bytes']).' · '.$a['mime']).(!empty($a['mime_alerta'])?'<br><strong>Confira: extensão e MIME divergentes.</strong>':'').'</td><td>'.esc_html(implode(', ',$a['formularios'])?:'Nenhum').'</td><td>'.esc_html(wp_date('d/m/Y H:i',$a['atualizado_em']?:$a['criado_em'])).'</td></tr>';}
        echo '</tbody></table>';if(!empty($lista['proxima_pagina'])){echo '<p><a class="button" href="'.esc_url(add_query_arg('pagina',$lista['proxima_pagina'])).'">Próxima página</a></p>';}echo '</div>';
	}
	public static function anexo(): void {
		if ( ! self::pode( 'f3base_baixar_anexos' ) ) {
			wp_die( 'Sem permissão.', '', array( 'response' => 403 ) );
		} check_admin_referer( 'f3base-anexo' );
		$a = F3Base_Arquivos_Privados::obter( sanitize_key( $_GET['id'] ?? '' ) );
		$r = $a ? F3Base_Leads_Repositorio::obter( $a['dono'] ) : null;
		if ( ! $a || ! $r || $r['eliminacao_pendente'] || $r['lixeira'] ) {
			wp_die( 'Arquivo indisponível.', '', array( 'response' => 404 ) );
		} F3Base_Arquivos_Privados::entregar( $a, 'HEAD' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) ); // phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Comparison of runtime expressions; neither side is an assignable literal.
	}
    public static function preparar_csv(array $f,$h): array {
        global $wpdb;$cursor=null;$total=0;$fim=microtime(true)+20;
        if(!is_resource($h)){return array('ok'=>false,'codigo'=>'arquivo_indisponivel');}
        fputcsv($h,array('record_id','data_utc','nome','email','metodo','formulario','captura','atendimento','sessao','correlacao','post_id','ip','user_agent','resposta','campos','classe_trafego','atribuicao','segmento_consulta','de','ate','fuso_filtros','aparelho','teste_origem'));
        if(false===$wpdb->query('START TRANSACTION WITH CONSISTENT SNAPSHOT')){return array('ok'=>false,'codigo'=>'leitura_exportacao_falhou');}
        try{do{
            $r=F3Base_Leads_Repositorio::consultar(array_merge($f,array('cursor'=>$cursor,'limite'=>100)));
            if(empty($r['ok'])){return $r;}
            foreach($r['registros'] as $l){
                if(++$total>100000||microtime(true)>$fim){return array('ok'=>false,'codigo'=>'reduza_periodo_exportacao');}
                $val=array($l['record_id'],$l['criado_em'],$l['nome'],$l['email'],$l['metodo'],$l['formulario'],$l['captura'],$l['atendimento'],$l['sessao'],$l['correlacao'],$l['post_id'],$l['dados']['contexto']['ip']??'',$l['dados']['contexto']['user_agent']??'',$l['resposta'],wp_json_encode($l['dados']['campos']??array()),$l['classe_trafego'],wp_json_encode(F3Base_Atribuicao::normalizar($l['dados']['atribuicao']??array())),F3Base_Testes::segmento($f['segmento']??null),$f['de']??'',$f['ate']??'',wp_timezone_string(),$l['aparelho']??'nao_identificado',$l['dados']['teste_origem']??'desconhecida');
                if(fputcsv($h,array_map(array(F3Base_Acessos_Relatorio::class,'celula_csv'),$val))===false){return array('ok'=>false,'codigo'=>'escrita_exportacao_falhou');}
            }$cursor=$r['proximo_cursor'];
        }while($cursor);return array('ok'=>true,'registros'=>$total);
        }finally{$wpdb->query('ROLLBACK');}
    }
    public static function csv(): void {
        if(!self::pode('f3base_exportar_leads')){wp_die('Sem permissão.','',array('response'=>403));}check_admin_referer('f3base-csv');
        $f=F3Base_Medicao_Interface::filtros($_GET);unset($f['caminho'],$f['pagina'],$f['limite'],$f['comparar']);foreach(array('aparelho','captura','atendimento','email','sessao','correlacao','post_id','busca') as $k){if(isset($_GET[$k])&&is_string($_GET[$k])){$f[$k]=sanitize_text_field(wp_unslash($_GET[$k]));}}$f['lixeira']=!empty($_GET['lixeira']);
        $root=F3Base_Arquivos_Privados::raiz(true);$path=$root?tempnam($root,'.exportar-'):false;
        if(!$path||dirname($path)!==$root||!chmod($path,0600)){if($path){@unlink($path);}wp_die('Exportação indisponível.','',array('response'=>503));}
        $h=fopen($path,'w+b');try{$r=self::preparar_csv($f,$h);if(!$r['ok']){fclose($h);unlink($path);wp_die(esc_html($r['codigo']),'',array('response'=>400));}
            rewind($h);nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="contatos.csv"');header('X-Content-Type-Options: nosniff');fpassthru($h);
        }finally{if(is_resource($h)){fclose($h);}if(is_file($path)){unlink($path);}}exit;
    }

	public static function exportar_zip(): void {
		if ( ! self::pode( 'f3base_exportar_leads' ) || ! self::pode( 'f3base_baixar_anexos' ) ) {
			wp_die( 'Sem permissão.', '', array( 'response' => 403 ) ); }
		check_admin_referer( 'f3base-exportar-registro' );
		$r    = F3Base_Leads_Repositorio::obter( sanitize_key( $_GET['record_id'] ?? '' ) );
		$root = F3Base_Arquivos_Privados::raiz( true );
		if ( ! $r || $r['eliminacao_pendente'] || ! $root || ! class_exists( 'ZipArchive' ) ) {
			wp_die( 'Exportação indisponível.', '', array( 'response' => 503 ) ); }
		$id   = bin2hex( random_bytes( 16 ) );
		$path = $root . '/' . $id;
		$zip  = new ZipArchive();
		if ( true !== $zip->open( $path, ZipArchive::CREATE | ZipArchive::EXCL ) ) {
			wp_die( 'Exportação indisponível.', '', array( 'response' => 503 ) ); }
		unset( $r['idempotencia'], $r['payload_hash'] );
		$zip->addFromString( 'registro.json', wp_json_encode( $r, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) );
		foreach ( $r['anexos'] as $a ) {
			$arq = F3Base_Arquivos_Privados::obter( $a['id'] );
			$p   = F3Base_Arquivos_Privados::caminho( $a['id'] );
			if ( ! $arq || $arq['dono'] !== $r['record_id'] || ! is_file( $p ) || ! $zip->addFile( $p, 'anexos/' . $a['id'] . '-' . sanitize_file_name( $a['nome'] ) ) ) {
				$zip->close();
				@unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics. // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
				wp_die( 'Anexo ausente; exportação não concluída.', '', array( 'response' => 503 ) ); }
		}
		if ( ! $zip->close() ) {
			@unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
			wp_die( 'Falha na exportação.', '', array( 'response' => 503 ) );
		} @chmod( $path, 0600 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_chmod -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
		register_shutdown_function(
			static function () use ( $path ): void {
				@unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics. // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
			}
		);
		F3Base_Arquivos_Privados::entregar(
			array(
				'id'     => $id,
				'estado' => 'ativo',
				'nome'   => 'registro-e-anexos.zip',
			),
			'HEAD' === ( $_SERVER['REQUEST_METHOD'] ?? '' )
		);
	}
	public static function exportar( string $email, int $page = 1 ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT record_id,dados,anexos FROM %i WHERE email=%s AND eliminacao_pendente=0 ORDER BY id LIMIT 100 OFFSET %d', F3Base_Leads_Repositorio::tabela(), strtolower( $email ), max( 0, $page - 1 ) * 100 ), ARRAY_A );
		$data = array();
		foreach ( $rows as $r ) {
			$data[] = array(
				'group_id'    => 'f3base-contatos',
				'group_label' => 'Contatos Core',
				'item_id'     => 'f3base-' . $r['record_id'],
				'data'        => array(
					array(
						'name'  => 'Registro',
						'value' => $r['record_id'],
					),
					array(
						'name'  => 'Dados',
						'value' => $r['dados'],
					),
					array(
						'name'  => 'Anexos (solicite cópia privada ao controlador)',
						'value' => $r['anexos'],
					),
				),
			); }
		$contacts = $wpdb->get_results( $wpdb->prepare( 'SELECT id,dados FROM %i WHERE email=%s AND eliminado=0 ORDER BY id LIMIT 100 OFFSET %d', F3Base_Leads_Repositorio::tabela( 'contatos_legados' ), strtolower( $email ), max( 0, $page - 1 ) * 100 ), ARRAY_A );
		foreach ( $contacts as $c ) {
			$data[] = array(
				'group_id'    => 'f3base-contatos-legados',
				'group_label' => 'Acervo independente de contatos',
				'item_id'     => 'f3base-contato-' . $c['id'],
				'data'        => array(
					array(
						'name'  => 'Dados originais',
						'value' => $c['dados'],
					),
				),
			); }
		return array(
			'data' => $data,
			'done' => count( $rows ) < 100 && count( $contacts ) < 100,
		);
	}
	public static function apagar( string $email, int $page = 1 ): array {
		unset( $page ); // Always take the first remaining page while deleting.
		global $wpdb;
		$ids    = $wpdb->get_col( $wpdb->prepare( 'SELECT record_id FROM %i WHERE email=%s ORDER BY id LIMIT 100', F3Base_Leads_Repositorio::tabela(), strtolower( $email ) ) );
		$retido = false;
		foreach ( $ids as $id ) {
			if ( ! F3Base_Leads_Repositorio::eliminar( $id ) ) {
				$retido = true; }
		}
		$contacts = $wpdb->get_results( $wpdb->prepare( 'SELECT id,origem_chave FROM %i WHERE email=%s', F3Base_Leads_Repositorio::tabela( 'contatos_legados' ), strtolower( $email ) ), ARRAY_A );
		foreach ( $contacts as $contact ) {
			if ( ! F3Base_Leads_Repositorio::journal( $contact['origem_chave'], 'contato_solicitado' ) ) {
				$retido = true;
				continue; }
			if ( preg_match( '/^wp:flamingo_contact:(\d+)$/D', $contact['origem_chave'], $m ) && get_post( (int) $m[1] ) && ! wp_delete_post( (int) $m[1], true ) ) {
				$retido = true;
				continue; }
			$ok = $wpdb->update(
				F3Base_Leads_Repositorio::tabela( 'contatos_legados' ),
				array(
					'dados'       => '{}',
					'email'       => '',
					'origem_hash' => '',
					'eliminado'   => 1,
				),
				array( 'id' => $contact['id'] )
			);
			if ( false === $ok || ! F3Base_Leads_Repositorio::journal( $contact['origem_chave'], 'contato_concluido' ) ) {
				$retido = true; }
		}
		return array(
			'items_removed'  => ! empty( $ids ) || ! empty( $contacts ),
			'items_retained' => $retido,
			'messages'       => $retido ? array( 'Há remoção física pendente; tente novamente.' ) : array(),
			'done'           => count( $ids ) < 100 && ! $retido,
		);
	}
	public static function reter(): void {
		global $wpdb;
		$meses  = (int) F3Base_Options::ler( 'f3base_retencao_meses' );
		$limite = F3Base_Modulo_Retencao_Eliminacao::corte_de_retencao( $meses );
		$dias   = defined( 'EMPTY_TRASH_DAYS' ) ? max( 0, (int) EMPTY_TRASH_DAYS ) : 30;
		$rows   = $wpdb->get_results( $wpdb->prepare( 'SELECT record_id,lixeira,atualizado_em,revisao FROM %i WHERE criado_em<%s AND captura<>%s ORDER BY criado_em LIMIT 100', F3Base_Leads_Repositorio::tabela(), $limite, 'eliminado' ), ARRAY_A );
		foreach ( $rows as $r ) {
			if ( ! $r['lixeira'] && $dias > 0 ) {
				if ( F3Base_Leads_Repositorio::journal( $r['record_id'], 'lixeira', 'operacional' ) ) {
					F3Base_Leads_Repositorio::atualizar(
						array(
							'record_id'        => $r['record_id'],
							'revisao_esperada' => (int) $r['revisao'],
							'simular'          => false,
							'alteracoes'       => array( 'lixeira' => true ),
						)
					); }
			} elseif ( ! $dias || strtotime( $r['atualizado_em'] . ' UTC' ) < time() - $dias * DAY_IN_SECONDS ) {
				F3Base_Leads_Repositorio::eliminar( $r['record_id'], 'operacional' ); }
		}
	}
}
