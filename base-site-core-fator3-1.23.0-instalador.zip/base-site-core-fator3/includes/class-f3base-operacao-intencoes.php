<?php
/** Intenções duráveis e pagináveis. Ocorrência original e recuo não mudam por uma leitura. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Operacao_Intencoes {
    const SCHEMA=1;
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_operacao_intencoes';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();
        dbDelta("CREATE TABLE {$t} (
            chave char(64) NOT NULL,
escopo char(64) NOT NULL,
tarefa varchar(64) NOT NULL,
hook varchar(100) NOT NULL,
            argumentos longtext NOT NULL,
ocorrencia_em bigint NOT NULL,
recorrencia varchar(64) NOT NULL DEFAULT '',
            estado varchar(24) NOT NULL DEFAULT 'pendente',
falhas tinyint unsigned NOT NULL DEFAULT 0,
            tentar_em bigint NOT NULL DEFAULT 0,
cobertura_ate bigint NOT NULL DEFAULT 0,
codigo varchar(64) NOT NULL DEFAULT '',
            criada_em bigint NOT NULL,
atualizada_em bigint NOT NULL,
reserva char(36) NOT NULL DEFAULT '',
reserva_ate bigint NOT NULL DEFAULT 0,
reativada_por bigint NOT NULL DEFAULT 0,
reativada_origem varchar(24) NOT NULL DEFAULT '',
            PRIMARY KEY  (chave),
KEY vencidas (estado,tentar_em),
KEY escopo (escopo,estado),
KEY tarefa (tarefa,estado)
        ) {$wpdb->get_charset_collate()};");
        return !$wpdb->last_error&&$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;
    }
    public static function chave(array $e): string {return hash('sha256',$e['hook'].'|'.serialize($e['args']).'|'.($e['timestamp']??''));}
    private static function escopo(array $e): string {return hash('sha256',$e['hook'].'|'.serialize($e['args']));}
    private static function evento(array $r): array {return array('id'=>$r['tarefa'],'hook'=>$r['hook'],'args'=>json_decode($r['argumentos'],true)?:array(),'timestamp'=>(int)$r['ocorrencia_em'],'schedule'=>$r['recorrencia']?:false,'tentar_em'=>(int)$r['tentar_em'],'intencao'=>$r['chave'],'estado'=>$r['estado'],'falhas'=>(int)$r['falhas'],'reserva_ate'=>(int)$r['reserva_ate'],'em_execucao'=>(int)$r['reserva_ate']>time(),'cobertura_ate'=>(int)$r['cobertura_ate']);}
    public static function obter(array $e): array {
        global $wpdb;$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE escopo=%s AND estado IN ('pendente','esgotada','suspensa') ORDER BY ocorrencia_em LIMIT 1",self::tabela(),self::escopo($e)),ARRAY_A);
        if($wpdb->last_error){throw new RuntimeException('intencoes_leitura_falhou');}return $r?self::evento($r):array();
    }
    public static function listar(int $pagina=1,bool $vencidas=false): array {
        global $wpdb;$where=$vencidas?"estado='pendente' AND tentar_em<=".time():"estado<>'concluida'";
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$where} ORDER BY tentar_em,ocorrencia_em,chave LIMIT 100 OFFSET %d",self::tabela(),max(0,$pagina-1)*100),ARRAY_A);if($wpdb->last_error){return array();}return array_map(array(__CLASS__,'evento'),$rows);
    }
    public static function resumo(int $pagina=1): array {global $wpdb;$counts=$wpdb->get_results($wpdb->prepare('SELECT estado,COUNT(*) AS quantidade FROM %i GROUP BY estado',self::tabela()),ARRAY_A);$ok=!$wpdb->last_error;return array('ok'=>$ok,'schema'=>self::SCHEMA,'contagens'=>$counts,'por_tarefa'=>$wpdb->get_results($wpdb->prepare("SELECT tarefa,estado,COUNT(*) AS quantidade FROM %i WHERE estado<>'concluida' GROUP BY tarefa,estado",self::tabela()),ARRAY_A),'pagina'=>max(1,$pagina),'por_pagina'=>100,'itens'=>$ok?self::listar($pagina):array());}
    public static function registrar(array $e,int $quando=0): bool {
        global $wpdb;if(!F3Base_Operacao::identificar_hook($e['hook'])||!is_array($e['args'])){return false;}
        $e['timestamp']=$e['timestamp']??time();$t=self::tabela();$n=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO %i (chave,escopo,tarefa,hook,argumentos,ocorrencia_em,recorrencia,tentar_em,cobertura_ate,criada_em,atualizada_em) VALUES (%s,%s,%s,%s,%s,%d,%s,%d,%d,%d,%d)",$t,self::chave($e),self::escopo($e),$e['id'],$e['hook'],wp_json_encode($e['args'],JSON_PRESERVE_ZERO_FRACTION),$e['timestamp'],$e['schedule']??'', $quando?:time(),$e['timestamp'],time(),time()));return $n!==false;
    }
    public static function adiar(array $e,string $codigo,bool $falha=false,int $minimo=0): array {
        global $wpdb;$old=self::obter($e);if($old){if((int)($e['timestamp']??0)>$old['timestamp']){self::cobrir($old,(int)$e['timestamp']);}$e=array_merge($e,$old);}
        if(!self::registrar($e,$minimo)){return array('ok'=>false,'codigo'=>'intencao_nao_persistida');}
        if($old&&($old['estado']!=='pendente'||$old['tentar_em']>time()||!empty($old['em_execucao']))){return array('ok'=>true,'codigo'=>'retomada_preservada','status'=>$old['estado'],'intencao'=>$old['intencao'],'tentar_em'=>$old['tentar_em']);}
        $fails=($old['falhas']??0)+($falha?1:0);$state=$fails>=8?'esgotada':'pendente';$delay=$falha?min(3600,60*2**max(0,$fails-1)):60;$next=max($minimo,time()+$delay);
        $n=$wpdb->update(self::tabela(),array('estado'=>$state,'falhas'=>$fails,'tentar_em'=>$next,'codigo'=>sanitize_key($codigo),'reserva'=>'','reserva_ate'=>0,'atualizada_em'=>time()),array('chave'=>self::chave($e),'estado'=>'pendente'));
        if($n===false){return array('ok'=>false,'codigo'=>'intencao_nao_persistida');}
        $scheduled=$state==='pendente'?self::agendar($next):false;
        return array('id'=>$e['id'],'ok'=>!$falha,'status'=>$state==='pendente'?'aguardando':$state,'codigo'=>$codigo,'intencao_persistida'=>true,'intencao'=>self::chave($e),'falhas'=>$fails,'tentar_em'=>$next,'reagendado'=>$scheduled,'ocorrencia_original_em'=>$e['timestamp']);
    }
    public static function agendar(int $at): bool { $next=wp_next_scheduled('f3base_operacao_retomar');if($next!==false&&$next<=$at){return true;}return (bool)wp_schedule_single_event(max(time()+1,$at),'f3base_operacao_retomar'); }
    public static function reservar(array $e,string $token): bool {global $wpdb;return $wpdb->query($wpdb->prepare("UPDATE %i SET reserva=%s,reserva_ate=%d,atualizada_em=%d WHERE chave=%s AND estado='pendente' AND (reserva='' OR reserva_ate<=%d)",self::tabela(),$token,time()+180,time(),self::chave($e),time()))===1;}
    public static function liberar_reserva(array $e,string $token): bool {global $wpdb;return $wpdb->update(self::tabela(),array('reserva'=>'','reserva_ate'=>0),array('chave'=>self::chave($e),'reserva'=>$token))!==false;}
    public static function cobrir(array $original,int $ate): void {global $wpdb;$wpdb->query($wpdb->prepare('UPDATE %i SET cobertura_ate=GREATEST(cobertura_ate,%d) WHERE chave=%s',self::tabela(),$ate,self::chave($original)));}
    public static function concluir(array $e): bool {global $wpdb;return $wpdb->update(self::tabela(),array('estado'=>'concluida','codigo'=>'concluida','reserva'=>'','reserva_ate'=>0,'atualizada_em'=>time()),array('chave'=>self::chave($e),'estado'=>'pendente'))!==false;}
    public static function reativar(string $chave,string $tarefa): array {
        global $wpdb;if(!preg_match('/^[a-f0-9]{64}$/D',$chave)||!isset(F3Base_Operacao::tarefas()[$tarefa])){return array('ok'=>false,'codigo'=>'intencao_invalida');}
        $n=$wpdb->query($wpdb->prepare("UPDATE %i SET estado='pendente',falhas=0,tentar_em=%d,atualizada_em=%d,reativada_por=%d,reativada_origem=%s,codigo='reativada_explicitamente' WHERE chave=%s AND tarefa=%s AND estado='esgotada'",self::tabela(),time(),time(),get_current_user_id(),F3Base_Execucoes::origem(),$chave,$tarefa));
        return array('ok'=>$n===1,'persisted'=>$n===1,'codigo'=>$n===1?'intencao_reativada':'intencao_nao_esgotada','reagendado'=>$n===1&&self::agendar(time()+1));
    }
    public static function suspender(): bool {global $wpdb;return $wpdb->query($wpdb->prepare("UPDATE %i SET estado='suspensa',codigo='restauracao_pendente',atualizada_em=%d WHERE estado='pendente'",self::tabela(),time()))!==false;}
    public static function importar(): array {
        global $wpdb;$raw=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,'f3base_operacao_intencoes'));if($wpdb->last_error){return array('ok'=>false,'codigo'=>'intencoes_origem_ilegivel');}
        if($raw===null){return array('ok'=>true,'concluido'=>true);}$rows=maybe_unserialize($raw);if(!is_array($rows)){return array('ok'=>false,'codigo'=>'intencoes_origem_invalida');}
        $hash=hash('sha256',$raw);$release=get_option(F3Base_Instalacao::OPTION,array());$transfer=$release['transferencia_intencoes']??array();
        $offset=($transfer['origem_sha256']??'')===$hash?(int)($transfer['cursor']??0):0;$slice=array_slice($rows,$offset,100);$n=0;
        foreach($slice as $e){
            if(!is_array($e)||!isset($e['hook'],$e['args'],$e['timestamp'])||!F3Base_Operacao::identificar_hook($e['hook'])){return array('ok'=>false,'codigo'=>'intencao_legada_invalida');}
            $e['id']=F3Base_Operacao::identificar_hook($e['hook']);if(!self::registrar($e,(int)($e['tentar_em']??0))){return array('ok'=>false,'codigo'=>'intencao_nao_persistida');}
            $saved=$wpdb->get_row($wpdb->prepare('SELECT hook,argumentos,ocorrencia_em FROM %i WHERE chave=%s',self::tabela(),self::chave($e)),ARRAY_A);
            if(!$saved||$saved['hook']!==$e['hook']||json_decode($saved['argumentos'],true)!==$e['args']||(int)$saved['ocorrencia_em']!==(int)$e['timestamp']){return array('ok'=>false,'codigo'=>'intencao_importacao_divergente');}$n++;
        }
        $again=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,'f3base_operacao_intencoes'));if($wpdb->last_error||$again!==$raw){return array('ok'=>false,'codigo'=>'intencoes_origem_alterada');}
        $cursor=$offset+$n;$save=F3Base_Options::atualizar_estado(F3Base_Instalacao::OPTION,static function($v)use($cursor,$hash,$rows){$v['transferencia_intencoes']=array('cursor'=>$cursor,'total'=>count($rows),'origem_sha256'=>$hash);return $v;});
        if(empty($save['persisted'])){return array('ok'=>false,'codigo'=>'intencoes_checkpoint_falhou');}if($cursor<count($rows)){return array('ok'=>true,'concluido'=>false,'cursor'=>$cursor);}
        // Retain the source as historical evidence. No unresolved intention is removed.
        return array('ok'=>true,'concluido'=>true,'importadas'=>count($rows),'origem_sha256'=>hash('sha256',$raw));
    }
}
