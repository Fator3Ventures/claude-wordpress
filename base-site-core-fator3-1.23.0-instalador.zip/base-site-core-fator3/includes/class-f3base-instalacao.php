<?php
/** Instalação nova ou atualização exclusiva da 1.22.1, com checkpoints e recuo. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Instalacao {
    const OPTION='f3base_release_1230';
    public static function origem(): string {
        global $wpdb;
        $raw=$wpdb->get_results($wpdb->prepare('SELECT option_name,option_value FROM %i WHERE option_name IN (%s,%s)',$wpdb->options,self::OPTION,'f3base_release_1221'),ARRAY_A);
        if($wpdb->last_error){return 'leitura_indisponivel';}$states=array();foreach($raw as $r){$states[$r['option_name']]=maybe_unserialize($r['option_value']);}
        $s=$states[self::OPTION]??array();if(is_array($s)&&($s['versao']??'')==='1.23.0'&&in_array($s['origem']??'',array('nova','1.22.1'),true)){return !empty($s['concluido_em'])?'atual':$s['origem'];}
        $base=$states['f3base_release_1221']??array();if(is_array($base)&&($base['versao']??'')==='1.22.1'&&!empty($base['concluido_em'])){return '1.22.1';}
        $n=$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE option_name LIKE %s',$wpdb->options,$wpdb->esc_like('f3base_').'%'));if($wpdb->last_error){return 'leitura_indisponivel';}
        $tables=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($wpdb->prefix.'f3base_').'%'));if($wpdb->last_error){return 'leitura_indisponivel';}
        return (int)$n===0&&!$tables?'nova':'indefinida';
    }
    public static function permitida(): bool {return in_array(self::origem(),array('atual','nova','1.22.1'),true);}
    public static function aviso(): void {if(current_user_can('manage_options')){echo '<div class="notice notice-error"><p>Fator3 Site Core: origem não suportada ou leitura indisponível. Use WordPress sem Core ou Core 1.22.1 com checkpoint concluído. Nenhum dado foi convertido.</p></div>';}}
    public static function resumo(): array {$s=get_option(self::OPTION,array());return (is_array($s)?$s:array())+array('versao'=>'1.23.0','concluido_em'=>0,'proxima_tentativa'=>0,'origem'=>self::origem());}
    private static function salvar(array $s): bool {$r=F3Base_Options::atualizar_estado(self::OPTION,static fn()=>$s);return !empty($r['persisted']);}
    public static function documentos_obsoletos(): array {return array('removidos'=>array(),'divergentes'=>array(),'falhas'=>array());}
    public static function atualizar(): array {
        $origem=self::origem();if($origem==='atual'){return array('ok'=>true,'codigo'=>'atual');}if(!self::permitida()){return array('ok'=>false,'codigo'=>'origem_nao_suportada');}
        $s=get_option(self::OPTION,array());if((int)($s['proxima_tentativa']??0)>time()){return array('ok'=>true,'status'=>'aguardando','codigo'=>'atualizacao_em_recuo','proxima_tentativa'=>$s['proxima_tentativa']);}
        if(!F3Base_Recuperacao::provisionar()||!F3Base_Recuperacao::entrar()){$guard=F3Base_Recuperacao::ler();return array('ok'=>false,'codigo'=>'core_em_recuperacao','ultima_falha'=>array('etapa'=>'recuperacao','codigo'=>$guard['codigo']??'recuperacao_indisponivel'),'recuperacao'=>$guard);}
        $lock=F3Base_Trava::adquirir('atualizacao-1230',180);if(!$lock){F3Base_Recuperacao::sair();return array('ok'=>false,'codigo'=>'atualizacao_em_execucao');}
        $etapa='inicio';try{
            if(empty($s['versao'])){$s=array('versao'=>'1.23.0','origem'=>$origem,'iniciado_em'=>time(),'etapas'=>array(),'falhas'=>0);if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}}
            $steps=array(
                'padroes'=>static function()use($origem){
                    if($origem==='nova'){
                        foreach(array(F3Base_Options::OPTION_OPERAVEIS=>array('schema'=>1,'modo'=>'todas','lista'=>array()),'f3base_politica_canal'=>true,'f3base_contato'=>array('email_leads'=>is_email(get_option('admin_email'))?array(get_option('admin_email')):array())) as $n=>$v){if(!F3Base_Options::fotografia_bruta($n)['existe']){$r=F3Base_Options::gravar($n,$v,F3Base_Options::ORIGEM_PADRAO,F3Base_Options::revisao($n));if(empty($r['persisted'])){return false;}}}
                    }
                    $defaults=F3Base_Configuracao_Medicao::materializar_padroes();if(!empty($defaults['preservadas_com_diagnostico'])){$state=get_option(self::OPTION,array());$state['avisos_padroes']=$defaults['preservadas_com_diagnostico'];if(!self::salvar($state)){return false;}}return !empty($defaults['ok']);
                },
                'consentimento_capi'=>static function(){F3Base_Consentimento_Decisoes::instalar();F3Base_Modulo_Endpoint_Leads::instalar_recusas();return F3Base_Capi_Fila::instalar()&&F3Base_Atualizacao::verificar_estrutura();},
                'leads_analise'=>static function(){F3Base_Modulo_Comportamento::criar_tabela();F3Base_Vitais::instalar();return F3Base_Leads_Repositorio::instalar()&&F3Base_Analise::instalar()&&F3Base_Clarity_Acervo::instalar()&&F3Base_Meta_Transporte::instalar();},
                'integracoes'=>static fn()=>F3Base_Pipedrive_Fila::instalar()&&F3Base_Anuncios::instalar(),
                'editorial'=>static function(){F3Base_Acessos_Coleta::instalar();F3Base_Agentes::instalar();return F3Base_Acessos_Legado::instalar()&&F3Base_Editorial::instalar()&&F3Base_Inteligencia::instalar();},
                'acervos_1200'=>static fn()=>F3Base_Execucoes::instalar()&&F3Base_Gsc::instalar(),
                'intencoes_estrutura'=>static fn()=>F3Base_Operacao_Intencoes::instalar()&&F3Base_Leads_Consentimento::instalar(),
                'diagnosticos_anteriores'=>static fn()=>F3Base_Configuracao_Medicao::importar_avisos(),
                'intencoes_transferencia'=>static fn()=>F3Base_Operacao_Intencoes::importar(),
                'manutencao_local'=>static function(){ $r=F3Base_Leads_Consentimento::lote();return !empty($r['ok']);},
                'pasta_privada'=>static fn()=>!empty(F3Base_Arquivos_Privados::provisionar()['ok']),
                'verificacao'=>static fn()=>self::verificar(),
                'agendas'=>static fn()=>self::agendas(),
            );
            $order=array('intencoes_estrutura','consentimento_capi','leads_analise','integracoes','editorial','acervos_1200','padroes','diagnosticos_anteriores','intencoes_transferencia','manutencao_local','pasta_privada','verificacao','agendas');$steps=array_replace(array_fill_keys($order,null),$steps);
            foreach($steps as $etapa=>$callback){if(!empty($s['etapas'][$etapa]['concluido_em'])){continue;}$s['etapa_atual']=$etapa;$s['tentativa_em']=time();if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}
                $result=$callback();$saved=get_option(self::OPTION,array());foreach(array('avisos_padroes','transferencia_intencoes') as $extra){if(isset($saved[$extra])){$s[$extra]=$saved[$extra];}}if(is_array($result)&&isset($result['cursor'])){$s['cursores'][$etapa]=$result['cursor'];if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}}
                if($result===false||(is_array($result)&&empty($result['ok']))){throw new RuntimeException(is_array($result)?($result['codigo']??'etapa_nao_confirmada'):'etapa_nao_confirmada');}
                if(is_array($result)&&empty($result['concluido'])){$s['proxima_tentativa']=time()+5;$s['ultima_falha']=null;if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}return array('ok'=>true,'parcial'=>true,'codigo'=>'atualizacao_em_lotes','etapa'=>$etapa,'proxima_tentativa'=>$s['proxima_tentativa']);}
                $s['etapas'][$etapa]=array('concluido_em'=>time());if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}}
            $structure=F3Base_Options::atualizar_estado(F3Base_Atualizacao::OPTION,static fn($v)=>array_merge($v,array('versao'=>F3Base_Atualizacao::VERSAO,'confirmada_em'=>time(),'codigo'=>'estrutura_confirmada')));if(empty($structure['persisted'])||(F3Base_Options::ler(F3Base_Atualizacao::OPTION)['versao']??'')!==F3Base_Atualizacao::VERSAO){throw new RuntimeException('estrutura_nao_persistida');}
            $s['concluido_em']=time();$s['proxima_tentativa']=0;$s['ultima_falha']=null;$s['etapa_atual']='concluida';if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}
            wp_clear_scheduled_hook(F3Base_Atualizacao::EVENTO);
            return array('ok'=>true,'persisted'=>true,'codigo'=>'atualizacao_concluida');
        }catch(Throwable $e){$s['falhas']=(int)($s['falhas']??0)+1;$s['ultima_falha']=array('etapa'=>$etapa,'codigo'=>sanitize_key($e->getMessage()),'em'=>time());$s['proxima_tentativa']=time()+min(3600,300*2**min(4,$s['falhas']-1));self::salvar($s);return array('ok'=>false,'codigo'=>'atualizacao_pendente','etapa'=>$etapa,'proxima_tentativa'=>$s['proxima_tentativa']);}
        finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    private static function agendas(): bool {
        foreach(array('f3base_consentimento_indexar','f3base_aparelhos_historico') as $hook){if(!wp_next_scheduled($hook)){if(!wp_schedule_single_event(time()+60,$hook)){return false;}}if(!wp_next_scheduled($hook)){return false;}}
        F3Base_Navegacao::agendar();F3Base_Editorial::agendar();F3Base_Llms_Cobertura::agendar();foreach(array(F3Base_Navegacao::EVENTO,F3Base_Editorial::EVENTO) as $hook){if(!wp_next_scheduled($hook)){return false;}}return true;
    }
    public static function verificar(): bool {
        global $wpdb;if(!F3Base_Atualizacao::verificar_estrutura()){return false;}
        $required=array('f3base_operacao_intencoes'=>array('chave','escopo','estado','falhas','tentar_em','reserva','reserva_ate'),'f3base_consentimento_reparos'=>array('lead_id','tentativas','codigo'),'f3base_leads'=>array('decisao_ref'),'f3base_eventos'=>array('recebido_em'),'f3base_gsc_lacunas'=>array('universo','dia','estado'),'f3base_analise'=>array('oferta_id','oferta_tipo','oferta_instancia'),'f3base_execucoes'=>array('run_id','origem','parent_run_id','ocorrencia'),'f3base_gsc_coletas'=>array('id','propriedade','dia','estado','cursor','revision'),'f3base_gsc_linhas'=>array('coleta_id','chave','url'),'f3base_clarity_coletas'=>array('id','estado','recebido_em'),'f3base_clarity'=>array('coleta','metrica'),'f3base_meta_eventos'=>array('evento','rota','classe_trafego'));
        foreach($required as $suffix=>$cols){$t=$wpdb->prefix.$suffix;$actual=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$t));if($wpdb->last_error||array_diff($cols,$actual)){return false;}}return true;
    }
}
