/**
 * Base Site Core Fator3 — carregador único das tags de medição.
 *
 * Este arquivo só chega ao HTML quando as duas condições fecham no servidor: há
 * DESTINO — pelo menos um ID de medição gravado OU o resumo de comportamento do
 * próprio site ligado — E o consentimento permite. A conferência de
 * consentimento é REFEITA aqui porque página em cache congela a decisão do
 * primeiro visitante: o servidor decide se o carregador entra, o navegador
 * decide se a tag carrega.
 *
 * SÃO DOIS DESTINOS, e eles são independentes. A conta de medição recebe evento
 * a evento, pelo `dataLayer`, e só existe com ID gravado. O site recebe o
 * RESUMO da sessão, agregado, uma vez, ao sair da página — e é dele que sai o
 * quadro da tela do plugin. Sem ID nenhum, nada vai para conta nenhuma; o
 * resumo continua sendo somado no próprio site, que era a metade que faltava
 * até a 1.1.3.
 *
 * UM CAMINHO, E UM SÓ. Com container do GTM preenchido, este arquivo emite o
 * contêiner e mais nada: as tags moram lá dentro, e emitir também a tag direta
 * contaria a mesma conversão duas vezes. Sem container, ele emite as tags
 * diretas dos IDs presentes — `gtag.js` servindo GA4 e Google Ads no mesmo
 * `gtag`, o Pixel da Meta e o Insight Tag do LinkedIn.
 *
 * O QUE ELE NÃO FAZ: disparar conversão. A conversão do clique é do
 * `f3base-leads.js`, que é onde o clique acontece — um lugar só, para que
 * acrescentar um canal não vire quatro edições.
 *
 * Pixel e Insight Tag NÃO TÊM modo de consentimento: para eles, negativa é
 * ausência. O `gtag` tem Consent Mode v2, e o estado default já foi empurrado
 * pelo `f3base-consentimento.js` antes deste arquivo rodar.
 */
(function (window, document) {
	'use strict';

	var dados = window.f3baseTrackingDados;

	if (!dados || typeof dados !== 'object') {
		return;
	}

	var CAMINHO = String(dados.caminho || 'nenhum');
	var carregado = false;

	window.dataLayer = window.dataLayer || [];

	/**
	 * O portão, do lado do navegador.
	 *
	 * Sem o objeto do consentimento na página não há o que consultar, e a
	 * ausência dele não pode virar bloqueio silencioso: o servidor já decidiu
	 * uma vez, e ele é a decisão de reserva.
	 */
	function permiteTags() {
		if (window.f3baseConsentimento && typeof window.f3baseConsentimento.permiteTags === 'function') {
			return window.f3baseConsentimento.permiteTags();
		}

		return true;
	}

	/**
	 * Insere um <script> externo uma vez só, pelo id declarado.
	 */
	function inserir(id, src) {
		if (document.getElementById(id)) {
			return;
		}

		var tag = document.createElement('script');

		tag.id = id;
		tag.async = true;
		tag.src = src;

		var primeiro = document.getElementsByTagName('script')[0];

		if (primeiro && primeiro.parentNode) {
			primeiro.parentNode.insertBefore(tag, primeiro);
		} else {
			document.head.appendChild(tag);
		}
	}

	function gtag() {
		window.dataLayer.push(arguments);
	}

	if (typeof window.gtag !== 'function') {
		window.gtag = gtag;
	}

	/**
	 * Caminho do contêiner: o GTM entra, e nada mais.
	 */
	function carregarGtm() {
		window.dataLayer.push({
			event: 'gtm.js',
			'gtm.start': new Date().getTime()
		});

		inserir('f3base-gtm', String(dados.origemGoogle) + 'gtm.js?id=' + encodeURIComponent(String(dados.gtm)));
	}

	/**
	 * gtag.js de verdade — GA4 e Google Ads na MESMA instância.
	 *
	 * O carregador é pedido com o primeiro ID presente; os `config` seguintes
	 * registram o resto. É assim que o fornecedor documenta duas contas no mesmo
	 * gtag, e é o que evita dois carregadores brigando pelo mesmo dataLayer.
	 */
	function carregarGoogleDireto() {
		var ga4 = String(dados.ga4 || '');
		var ads = dados.ads && typeof dados.ads === 'object' ? String(dados.ads.id || '') : '';
		var primeiro = ga4 || ads;

		if (!primeiro) {
			return;
		}

		inserir('f3base-gtag', String(dados.origemGoogle) + 'gtag/js?id=' + encodeURIComponent(primeiro));

		window.gtag('js', new Date());

		if (ga4) {
			window.gtag('config', ga4);
		}

		if (ads) {
			window.gtag('config', ads);
		}
	}

	/**
	 * Pixel da Meta, com o `fbq` na forma que o fornecedor consome.
	 */
	function carregarMeta() {
		var pixel = dados.meta && typeof dados.meta === 'object' ? String(dados.meta.pixelId || '') : '';

		if (!pixel) {
			return;
		}

		if (!window.fbq) {
			var fila = function () {
				if (fila.callMethod) {
					fila.callMethod.apply(fila, arguments);
				} else {
					fila.queue.push(arguments);
				}
			};

			fila.push = fila;
			fila.loaded = true;
			fila.version = '2.0';
			fila.queue = [];

			window.fbq = fila;
			window._fbq = window._fbq || fila;
		}

		inserir('f3base-meta-pixel', String(dados.meta.origem));

		window.fbq('init', pixel);
		window.fbq('track', 'PageView');
	}

	/**
	 * Insight Tag do LinkedIn — page view; a conversão é do clique.
	 */
	function carregarLinkedin() {
		var parceiro = dados.linkedin && typeof dados.linkedin === 'object' ? String(dados.linkedin.partnerId || '') : '';

		if (!parceiro) {
			return;
		}

		window._linkedin_partner_id = parceiro;
		window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];

		if (window._linkedin_data_partner_ids.indexOf(parceiro) === -1) {
			window._linkedin_data_partner_ids.push(parceiro);
		}

		inserir('f3base-linkedin-insight', String(dados.linkedin.origem));
	}


	/* =====================================================================
	 * INSTRUMENTAÇÃO DE COMPORTAMENTO
	 *
	 * A premissa da 1.1.3, nas palavras de quem a definiu: *"o site no
	 * WordPress já deve nascer instrumentado para validar e avaliar o
	 * comportamento dos usuários no site."* Até a 1.1.2 este pacote emitia
	 * `generate_lead`, `form_start` e `select_content` — tudo em torno da
	 * conversão. Nada dizia se a página era lida, onde o visitante parava, o
	 * que ele tentava clicar nem qual era a experiência real de carregamento.
	 *
	 * QUATRO REGRAS VALEM PARA TUDO O QUE ESTÁ AQUI:
	 *
	 * 1. **Mesmo portão das quatro tags.** Nada disto é instalado fora de
	 *    `carregar()`, que só roda com slot preenchido e consentimento vigente.
	 *    Sem `ga4_measurement_id` nem container, este arquivo nem chega ao HTML.
	 * 2. **Nenhum evento carrega dado pessoal.** Nem texto digitado, nem
	 *    seletor com valor, nem URL com query. As recusas estão nomeadas em
	 *    cada coletor, e quem varre o payload é `js.comportamento_instrumentado`.
	 * 3. **Teto por página, declarado.** Cada evento tem o seu na declaração, e
	 *    `podeEmitir()` é o único caminho até o `dataLayer`. Sem teto, uma
	 *    página faz o volume de um dia e a conta de medição amostra o excesso
	 *    em silêncio — o descarte é nosso e é declarado.
	 * 4. **Nenhum nome e nenhum número mora aqui.** Evento, parâmetro, marco,
	 *    janela, raio e teto saem todos de `dados.comportamento`, que o
	 *    servidor lê de `dados/eventos-comportamento.tsv`. Quem lê a série
	 *    histórica é um agente comparando períodos: nome que muda entre
	 *    releases é medição que sumiu sem erro nenhum.
	 * ================================================================== */

	var COMPORTAMENTO = dados.comportamento && typeof dados.comportamento === 'object'
		? dados.comportamento
		: { eventos: {}, prefixoSecao: '' };

	var EVENTOS = COMPORTAMENTO.eventos && typeof COMPORTAMENTO.eventos === 'object'
		? COMPORTAMENTO.eventos
		: {};

	var emitidos = {};
	var instrumentado = false;

	/* ==================================================================
	 * O RESUMO DA SESSÃO — o segundo destino, e o que ele NÃO carrega.
	 *
	 * A pergunta que ele responde: *"o site nasce instrumentado, onde posso
	 * ver os dados desta instrumentação."* Até a 1.1.3 a resposta era "na
	 * conta de medição, quando ela existir" — e com o slot vazio, em lugar
	 * nenhum. O resumo é a resposta de dentro do site.
	 *
	 * QUATRO RECUSAS, e nenhuma delas é boa vontade:
	 *
	 * 1. Nada além do apelido sorteado e do estado da visita é gravado no
	 *    navegador, e nunca em cookie: o acumulado do lote vive na memória
	 *    desta aba e morre com ela.
	 * 2. O caminho vai SEM QUERY e SEM FRAGMENTO — `location.pathname`, e
	 *    não `location.href`. É na query que a campanha de outra pessoa cola
	 *    o identificador do lead.
	 * 3. O detalhe passa por um ALFABETO FECHADO. Host de destino, nome de
	 *    seção, marco e nome de métrica passam; caminho de arquivo, endereço
	 *    de e-mail e texto livre não têm como passar, porque barra, arroba,
	 *    dois-pontos e espaço não estão no alfabeto. É por isso que o erro
	 *    de JavaScript entra como CONTAGEM e sem o arquivo: a página já é a
	 *    chave, e o arquivo interpolado é onde mora o valor do titular.
	 * 4. O cliente manda o GATILHO, nunca o nome do evento. Quem resolve o
	 *    nome é o servidor, contra a mesma declaração de sempre.
	 *
	 * O ENVIO É POR LOTE, e esta frase substitui a que estava aqui — *"o envio
	 * é um só, no primeiro ocultamento da página"* —, que documentava um
	 * defeito como se fosse desenho.
	 *
	 * `visibilitychange` para `hidden` não dispara só na saída: dispara toda
	 * vez que a aba perde o foco. Com um envio só, o primeiro desses instantes
	 * despachava o que existia e deixava a página SURDA pelo resto da visita —
	 * medido em produção, cada carregamento registrava o primeiro segundo e
	 * mais nada, sem uma única rolagem. Agora cada ocultamento despacha o
	 * acumulado DESDE O ÚLTIMO ENVIO e esvazia o acumulado; a atividade
	 * seguinte forma o lote seguinte. O mesmo acionamento nunca viaja duas
	 * vezes, porque o que já viajou não está mais lá.
	 *
	 * O ENVIO CONFIRMA A ENTREGA, e não o ENFILEIRAMENTO — e esta frase
	 * substitui a que estava aqui, que dizia que sem `sendBeacon` a sessão se
	 * perde e tratava isso como o pior caso.
	 *
	 * O DEFEITO MEDIDO. `sendBeacon` devolvendo `true` significa que o agente
	 * de usuário ACEITOU a carga para transferência — nunca que ela chegou. Se
	 * a requisição morre depois disso (rede caindo, servidor em 503, aba
	 * encerrada antes de o envio sair), nada avisa a página, e o acumulado já
	 * foi jogado fora. Medido no site `fator3-teste-mcp-1`, tabela
	 * `wp_2zsugm_f3base_eventos`, visita `8cac18da62ed056004242bee737457db`,
	 * UM único carregamento de `/`: `comando-unico` saiu com as ocorrências 1 e
	 * 3, e a 2 não existe em lugar nenhum. Entre os lotes, o visitante SUBIU a
	 * página — a subida faz o bloco reentrar em vista e não dispara marco
	 * nenhum, porque marco só conta na descida —, e o lote despachado naquele
	 * instante tinha UMA linha só. Ele não chegou. O contador tinha avançado.
	 *
	 * O INVARIANTE QUEBRADO, e ele é o nome do conserto: O CONTADOR E A LINHA
	 * PRECISAM TER A MESMA DURABILIDADE. Na 1.3.4 o contador virou durável
	 * (`localStorage`, na hora) e a linha ficou volátil (memória do
	 * carregamento, descartada no primeiro `true` do beacon). Qualquer lote que
	 * não chega avança o contador sem produzir linha — antes da 1.3.4 isso
	 * perdia linhas em silêncio; depois dela o buraco na sequência de
	 * `ocorrencia` tornou a perda VISÍVEL, que é o que o operador relatou.
	 *
	 * AS DUAS METADES DO CONSERTO, e nenhuma delas fecha o invariante sozinha:
	 *
	 * 1. CONFIRMAR EM VEZ DE CONFIAR. O despacho é `fetch` com `keepalive`, que
	 *    sobrevive ao descarregamento da página como o beacon e, ao contrário
	 *    dele, DEVOLVE resposta. O lote só é esquecido com resposta 2xx.
	 * 2. TORNAR A LINHA TÃO DURÁVEL QUANTO O CONTADOR. Os lotes pendentes moram
	 *    no `localStorage`, ao lado do contador, dentro do estado da visita. Um
	 *    carregamento que morre entre contar e enviar não leva o lote junto: o
	 *    carregamento seguinte da mesma visita o encontra e o despacha ANTES
	 *    dos novos.
	 *
	 * A metade 1 sozinha não fecha, porque a página pode morrer entre contar e
	 * enviar; a metade 2 sozinha não fecha, porque o beacon aceito-e-perdido
	 * limparia o pendente do mesmo jeito.
	 *
	 * O LOTE É SELADO, E O SELO É UM IDENTIFICADOR SORTEADO. Reenviar é a
	 * consequência direta de confirmar, e sem selo o reenvio de um lote cuja
	 * RESPOSTA se perdeu no caminho de volta contaria duas vezes. O servidor
	 * recusa um selo que já gravou para a mesma visita e responde 2xx assim
	 * mesmo: para quem envia, "já tenho isto" e "acabei de gravar" são a mesma
	 * coisa boa. Selado significa IMUTÁVEL — atividade nova forma um lote novo,
	 * porque um lote que crescesse mantendo o selo teria o crescimento recusado
	 * como repetição e descartado pelo próprio 2xx.
	 *
	 * SEM `fetch` COM `keepalive`, O ENVIO CONTINUA ACONTECENDO por
	 * `sendBeacon` — degradado e declarado. Nesse caminho o lote enfileirado e
	 * perdido continua sendo perda, porque não há como saber; o que ele ganha
	 * de qualquer forma são as outras duas metades: o pendente é gravado ANTES
	 * do despacho, então a página que morre antes de o beacon sair não perde
	 * nada, e o selo impede que a retentativa conte duas vezes. Um conserto que
	 * só funcionasse no navegador moderno e emudecesse o antigo seria pior que
	 * o defeito.
	 * ================================================================== */

	var RESUMO = dados.resumo && typeof dados.resumo === 'object'
		? dados.resumo
		: { ativo: false, endpoint: '', token: '', maximo: 0 };

	var resumoDaSessao = {};
	var linhasDoResumo = 0;
	var resumoEnviado = false;

	/* ==================================================================
	 * O REGISTRO DE EVENTOS, e a mudança de natureza do dado.
	 *
	 * Até aqui o cliente mandava um AGREGADO: totais por evento, sem quem e
	 * sem quando. A partir desta versão ele manda também um REGISTRO — cada
	 * acontecimento com o apelido do visitante, o da visita e o carimbo em
	 * milissegundos desde o carregamento. É o que responde as duas perguntas
	 * que o agregado não responde: quanto tempo a pessoa levou para descer a
	 * página, e se ela voltou e leu de novo.
	 *
	 * O APELIDO É SORTEADO, DE PRIMEIRA PARTE E APAGÁVEL, e as três coisas
	 * importam juntas:
	 *
	 * - SORTEADO: `crypto.getRandomValues`, 32 hexadecimais. Não é derivado de
	 *   nada do aparelho — sem fingerprint, sem tela, sem fontes, sem canvas.
	 *   Dois visitantes idênticos recebem apelidos diferentes, e o mesmo
	 *   visitante em outro navegador é outra pessoa para este site.
	 * - DE PRIMEIRA PARTE: mora no `localStorage` DESTE domínio. Ele não
	 *   atravessa sites, não é lido por terceiro e não vale em lugar nenhum
	 *   além daqui.
	 * - APAGÁVEL: quem recusa a medição no controle do rodapé tem o apelido
	 *   apagado do navegador E o registro apagado do servidor, pela rota de
	 *   exclusão. Sem esse segundo passo, "apagável" seria só uma palavra.
	 *
	 * SEM ARMAZENAMENTO, SEM REGISTRO. Navegador com o armazenamento local
	 * bloqueado continua somando no agregado e não produz registro nenhum —
	 * medição parcial é melhor que medição nenhuma, e inventar um apelido de
	 * memória que muda a cada página produziria uma contagem de visitantes
	 * inflada, que é pior que não contar.
	 * ================================================================== */

	var CHAVE_VISITANTE = 'f3base_visitante';
	var CHAVE_SESSAO = 'f3base_sessao';

	/*
	 * A EXCLUSÃO PENDENTE, e ela existe porque apagar o apelido local antes da
	 * confirmação é apagar a PROVA do pedido.
	 *
	 * O DEFEITO. `esquecerVisitante()` despachava por `sendBeacon` — que não
	 * confirma nada — e removia o apelido do navegador na linha seguinte. Se o
	 * pedido não chegasse (rede caindo, 429 de balde cheio, 503 de migração em
	 * curso, aba encerrada antes de o envio sair), o registro continuava inteiro
	 * no servidor e o navegador não tinha mais o apelido: ninguém, nem o
	 * visitante nem o operador, conseguiria pedir aquela exclusão de novo. O
	 * direito virava um beacon disparado no escuro.
	 *
	 * O CONSERTO tem duas metades. O pedido passa pelo MESMO caminho confirmado
	 * dos lotes — `fetch` com `keepalive`, que sobrevive à saída da página e
	 * DEVOLVE resposta —, e as chaves locais só somem com 2xx. Enquanto não vem,
	 * esta chave guarda o apelido pedido, e o carregamento seguinte reenvia. O
	 * `sendBeacon` continua sendo a reserva do navegador que não tem `fetch`
	 * com `keepalive`: lá o pedido fica pendente e é reenviado até confirmar.
	 */
	var CHAVE_EXCLUSAO = 'f3base_exclusao_pendente';

	var registroDaSessao = [];
	var visitante = '';
	var sessao = '';
	var gastasNaVisita = 0;
	var cortadasNaVisita = 0;

	/*
	 * A FILA DE LOTES PENDENTES, e ela é a metade durável da linha.
	 *
	 * Cada entrada é um lote SELADO — `{id, nascido, caminho, metricas,
	 * eventos, cortados}` — que já saiu do acumulado e ainda não teve entrega
	 * confirmada. Ela é gravada no registro da visita, ao lado do contador, e
	 * é lida de volta pelo carregamento seguinte da mesma visita.
	 *
	 * A ORDEM É A DO SELAMENTO, e o despacho a respeita: o pendente sai antes
	 * do novo. É o que faz a sequência de `ocorrencia` fechar sem buraco
	 * mesmo quando um carregamento inteiro morre no meio.
	 *
	 * O ORÇAMENTO DA FILA NÃO É UM NÚMERO NOVO. Toda linha que entra num lote
	 * passou por `registrar()`, e `registrar()` já gasta o orçamento de
	 * `maximoVisita` da VISITA inteira — que atravessa carregamentos desde a
	 * 1.3.0. A fila é, por construção, um subconjunto desse orçamento: uma
	 * visita não consegue deixar pendente mais do que ela podia registrar.
	 * Escrever um segundo teto aqui seria um número para revisar onde já há
	 * um, e ele divergiria do primeiro na primeira vez que alguém mexesse
	 * num só.
	 */
	var pendentes = [];

	/*
	 * A FILA JÁ EM TEXTO, e ela é reserializada só quando a fila MUDA.
	 *
	 * O DEFEITO MEDIDO NO CUSTO. `guardarVisita()` roda a cada acionamento — é o
	 * que torna o contador durável — e serializava a FILA INTEIRA junto: numa
	 * visita com lotes retidos (servidor em 503, balde cheio, rede ruim), cada
	 * rolagem de marco passava um `JSON.stringify` sobre até oito quilobytes por
	 * lote pendente. O trabalho é do aparelho do visitante, acontece na thread
	 * que desenha a página, e nada dele muda entre um acionamento e outro: a fila
	 * só se altera ao SELAR e ao concluir um despacho.
	 *
	 * Quem escreve aqui é `serializarFila()`, chamada exatamente nesses dois
	 * pontos e na leitura do registro guardado.
	 */
	var filaSerializada = '[]';

	/*
	 * OS LOTES EM VOO, por identidade — e é esta lista que impede o despacho
	 * duplo.
	 *
	 * O DEFEITO. Uma saída de página normal emite `visibilitychange` para hidden
	 * E `pagehide`, nesta ordem, no mesmo carregamento. Os dois chamam
	 * `enviarResumo()`, e a guarda de reentrância dele sobe e desce dentro da
	 * MESMA execução — quando o segundo evento chega, ela já baixou. O primeiro
	 * despacho ainda não teve resposta (o `fetch` é assíncrono), o lote continua
	 * na fila, e o segundo evento o despacha de novo: o MESMO corpo sai duas
	 * vezes.
	 *
	 * COM SELO isso é inofensivo — o servidor reconhece a repetição e responde
	 * 2xx sem gravar de novo. SEM SELO não é: sem `crypto.getRandomValues` o
	 * lote sai com o selo vazio, o servidor não tem o que deduplicar, e o
	 * agregado daquele carregamento entra DOBRADO na tabela. A tela mostra o
	 * dobro do que aconteceu, sem erro em lugar nenhum.
	 *
	 * A guarda certa não é uma trava de tempo: é não despachar de novo um lote
	 * cujo despacho ainda não terminou. Recusa transitória e rede caindo tiram o
	 * lote daqui e ele volta a ser despachável na tentativa seguinte.
	 */
	var despachando = [];

	/* ==================================================================
	 * O CONTADOR DE TRAVESSIAS É DA VISITA, E NÃO DO CARREGAMENTO.
	 *
	 * O DEFEITO MEDIDO. Até aqui `travessias`, `travessiasDaSecao` e
	 * `cortadasNaVisita` eram variáveis do CARREGAMENTO: nasciam zeradas a cada
	 * página e morriam na navegação. O rearme DENTRO do carregamento estava
	 * certo — quem descia, subia e descia de novo na MESMA página produzia a
	 * segunda ocorrência —, mas quem passava pelo bloco, ia para outra página e
	 * voltava era registrado como se fosse a primeira vez, sempre. Medido em
	 * produção na visita `8bb0a2d5` de `fator3-teste-mcp-1`, tabela
	 * `wp_2zsugm_f3base_eventos`: dois carregamentos de `/` na MESMA visita,
	 * com 34 segundos entre eles, e o bloco `pecas` saindo com as ocorrências 1
	 * e 2 no primeiro e voltando a 1 no segundo.
	 *
	 * E o limiar se chama `travessias_por_SESSAO`. O nome prometia visita e a
	 * implementação entregava carregamento — uma declaração que mente sobre o
	 * que mede é pior que um número errado, porque ninguém vai conferir.
	 *
	 * A CHAVE INCLUI O CAMINHO: `caminho | gatilho | detalhe`. `pecas` em `/` e
	 * `pecas` em `/arquitetura/` são seções DIFERENTES com o mesmo nome —
	 * somá-las responderia uma pergunta que ninguém fez ("quantas vezes este
	 * NOME de bloco foi visto no site inteiro?") e esconderia as duas, porque
	 * nenhuma das duas páginas teria mais a própria contagem.
	 *
	 * O QUE NÃO ATRAVESSA É O ESTADO ARMADO. `dentro` (marcos) e
	 * `dentroDaVista` (seções) continuam sendo do CARREGAMENTO, e isso é
	 * decisão e não esquecimento: uma página nova começa com nada em vista e
	 * nada rolado. Persistir "já estou dentro" faria a primeira entrada do
	 * carregamento seguinte ser engolida, e o visitante que trocou de página
	 * perderia justamente a passagem que ele acabou de fazer. Persiste o
	 * CONTADOR; o estado armado nasce zerado a cada carregamento.
	 *
	 * O TETO DO MAPA É O MESMO `maximoVisita`, e não um número novo: o mapa
	 * existe para servir o registro, e o registro tem orçamento de
	 * `maximoVisita` linhas na visita inteira. Uma chave além desse orçamento é
	 * armazenamento gasto no aparelho de alguém para contar uma passagem que
	 * nunca virará linha. Passando do teto, a passagem conta em CORTADAS e não
	 * cria chave nova — o corte continua sendo nosso e nomeado.
	 *
	 * SEM ARMAZENAMENTO, TUDO DEGRADA PARA O COMPORTAMENTO DE HOJE. Navegador
	 * com o `localStorage` bloqueado não tem apelido nem visita, não produz
	 * registro nenhum e continua somando o agregado, como sempre. Navegador em
	 * que só a ESCRITA falha — cota cheia, modo restrito — mantém o mapa na
	 * memória do carregamento: a contagem volta a ser por carregamento, que é
	 * exatamente o que este bloco conserta. É a degradação certa, porque contar
	 * de menos é um número menor e não medir nada é uma tela vazia.
	 * ================================================================== */

	var travessiasDaVisita = {};
	var chavesDeTravessia = 0;

	/*
	 * A ORIGEM TEMPORAL DESTE CARREGAMENTO, e ela deixou de ser só um
	 * subtraendo local na 1.0.1 do plugin.
	 *
	 * O QUE ELA É. `timeOrigin` é o instante, no relógio do aparelho, em que
	 * este documento começou a existir. Todo `ms` do registro é a distância
	 * daqui até o acionamento, e é por isso que ele nasce exato mesmo quando o
	 * lote só parte minutos depois.
	 *
	 * POR QUE ELA PASSOU A VIAJAR. O servidor carimbava cada linha com a hora
	 * em que o LOTE CHEGOU, e um lote carrega dezenas de acionamentos
	 * acumulados ao longo de segundos ou minutos de navegação: trinta e três
	 * acionamentos espalhados por dez segundos de leitura saíam todos gravados
	 * no mesmo segundo, e na tela as vinte e cinco linhas da primeira página
	 * traziam o mesmo `09:22:25`. Indistinguíveis no tempo, elas pareciam a
	 * mesma linha sendo reescrita. Com a origem no corpo, o servidor grava
	 * `origem + ms` e o carimbo volta a ser o do ACIONAMENTO.
	 *
	 * `Date.now()` É A RESERVA, e ela é pior de propósito: sem `timeOrigin` a
	 * origem passa a ser o instante em que ESTE script rodou, e não o do
	 * documento. O erro é o tempo de parse do head — dezenas de milissegundos —
	 * e ele é o mesmo para todas as linhas do carregamento, então não move nem
	 * a ordem nem o espaçamento entre elas.
	 */
	var nascimento = (window.performance && window.performance.timeOrigin)
		? window.performance.timeOrigin
		: Date.now();

	/**
	 * Um identificador sorteado de 32 hexadecimais.
	 */
	function sorteado() {
		var bytes;
		var i;
		var saida = '';

		try {
			if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
				bytes = new window.Uint8Array(16);
				window.crypto.getRandomValues(bytes);

				for (i = 0; i < bytes.length; i++) {
					saida += ('0' + bytes[i].toString(16)).slice(-2);
				}

				return saida;
			}
		} catch (erro) {
			// Sem gerador criptográfico, o registro não existe — ver abaixo.
		}

		return '';
	}

	/**
	 * O apelido JÁ GRAVADO neste navegador, sem sortear nenhum.
	 *
	 * Ele existe porque o apelido ATRAVESSA a visita: quem volta amanhã continua
	 * sendo a mesma pessoa para o registro, e sortear outro a cada carregamento
	 * faria "pessoas diferentes" contar carregamentos.
	 *
	 * @return {string} Apelido guardado, ou string vazia.
	 */
	function apelidoGuardado() {
		var guardado;

		try {
			guardado = window.localStorage.getItem(CHAVE_VISITANTE);
		} catch (erro) {
			return '';
		}

		return (guardado && /^[a-f0-9]{32}$/.test(guardado)) ? guardado : '';
	}

	/**
	 * O VISITANTE PODE SER IDENTIFICADO NESTE CARREGAMENTO?
	 *
	 * QUEM RESPONDE É O PORTÃO, E SÓ ELE. O apelido nasce onde a medição é
	 * permitida e não nasce onde ela não é: sob a política PRÉ-APROVADA, no
	 * primeiro carregamento; sob a política de NEGATIVA POR PADRÃO, só depois do
	 * aceite; e quem recusa no controle do rodapé tem o apelido apagado aqui e o
	 * registro apagado no servidor.
	 *
	 * POR QUE ELE NÃO PERGUNTA MAIS PELO AVISO DE PRIMEIRA VISITA. Houve uma
	 * versão desta função que exigia, no modo pré-aprovado, o banner ligado — a
	 * ideia era não criar o identificador de quem "não foi perguntado". A decisão
	 * de projeto é outra, e ela é a que este pacote sustenta: a política
	 * pré-aprovada é declarada por quem implanta o site, o controle de recusa
	 * existe no rodapé de TODA página publicada e a política de privacidade
	 * descreve a coleta. Amarrar o apelido ao banner deixava o site cego por
	 * omissão — agregado somando e registro detalhado inexistente — sem que a
	 * política tivesse mudado. O que estava mesmo errado era uma FRASE da tela
	 * Medição, que afirmava consentimento onde havia política; ela foi corrigida
	 * no lugar dela.
	 *
	 * ELA CONTINUA EXISTINDO COM ESTE NOME porque o documento do plugin a nomeia
	 * como o ponto onde a decisão é tomada, e `suite/afirmacoes.tsv` amarra a
	 * frase a ela: um ponto único é o que impede a regra de ser reescrita em três
	 * lugares e divergir em dois.
	 *
	 * SEM APELIDO O AGREGADO CONTINUA INTEIRO. É a mesma degradação já declarada
	 * para o navegador com o armazenamento bloqueado: medição parcial e anônima é
	 * melhor que medição nenhuma.
	 *
	 * @return {boolean}
	 */
	function podeIdentificar() {
		return permiteTags();
	}

	/**
	 * O apelido persistente deste navegador, sorteado na primeira visita.
	 */
	function apelidoDoVisitante() {
		var guardado = apelidoGuardado();

		if ('' !== guardado) {
			return guardado;
		}

		if (!podeIdentificar()) {
			return '';
		}

		guardado = sorteado();

		if ('' === guardado) {
			return '';
		}

		try {
			window.localStorage.setItem(CHAVE_VISITANTE, guardado);
		} catch (erro) {
			/*
			 * Armazenamento bloqueado é resposta, e não falha: o agregado
			 * continua, o registro não acontece, e nada é inventado.
			 */
			return '';
		}

		return guardado;
	}

	/**
	 * A VISITA, e ela ATRAVESSA PÁGINAS.
	 *
	 * POR QUE MUDOU. Até aqui a "sessão" era sorteada a cada carregamento: um
	 * visitante que abrisse sete páginas aparecia com sete sessões, e a coluna
	 * prometia responder "quantas páginas ele viu nesta visita" entregando
	 * sempre uma. A palavra dizia mais do que o dado.
	 *
	 * Agora ela é o que a palavra promete: um episódio contínuo de navegação,
	 * que termina por INATIVIDADE. A janela é declarada no limiar do evento de
	 * página; trinta minutos é a convenção do setor, e ela existe porque quem
	 * volta depois de meia hora voltou por outro motivo — o que estava lendo
	 * antes já não é a mesma visita.
	 *
	 * O ORÇAMENTO VIAJA COM ELA. O teto de linhas é da visita inteira, e não do
	 * carregamento: uma visita que percorre seis páginas relendo blocos gasta o
	 * mesmo orçamento que uma que fica numa só, e é a visita que precisa caber
	 * na tabela.
	 *
	 * @return {Object} `{id, gastas, travessias, cortadas, pendentes}` da visita.
	 */
	function visitaCorrente() {
		var janela = janelaDaVisita();
		var agora = Date.now();
		var guardada;
		var fila;

		try {
			guardada = JSON.parse(String(window.localStorage.getItem(CHAVE_SESSAO) || 'null'));
		} catch (erro) {
			guardada = null;
		}

		if (guardada && /^[a-f0-9]{32}$/.test(String(guardada.id)) && (agora - Number(guardada.visto || 0)) < janela) {
			fila = pendentesGuardados(guardada.pendentes, agora, janela);

			return {
				id: String(guardada.id),
				gastas: Math.max(0, Number(guardada.gastas || 0)),
				travessias: contadoresGuardados(guardada.travessias),
				acumulado: acumuladoGuardado(guardada.acumulado),
				/*
				 * O QUE VENCEU CONTA EM CORTADAS. Lote vencido é linha que foi
				 * contada e não vai virar registro: some-lo em silêncio faria o
				 * painel deixar de bater com a tabela sem nada dizendo por quê,
				 * que é exatamente o corte silencioso que este pacote não faz.
				 */
				cortadas: Math.max(0, Number(guardada.cortadas || 0)) + fila.vencidas,
				pendentes: fila.lotes
			};
		}

		/*
		 * VISITA NOVA COMEÇA DO ZERO, e o contador vai junto. Herdar o mapa da
		 * visita anterior faria a primeira passagem de quem volta no dia
		 * seguinte sair como décima segunda, e a coluna "vez" — que existe para
		 * dizer se a pessoa releu NESTA visita — passaria a contar história
		 * antiga sem nada dizendo de onde ela veio.
		 *
		 * E O PENDENTE MORRE COM ELA, pelo mesmo motivo do lado do servidor: o
		 * selo do lote é guardado lá pela MESMA janela que define a visita, e
		 * um lote reenviado depois dela encontraria o selo já expirado e seria
		 * gravado de novo. Descartar aqui é o que mantém as duas pontas
		 * concordando sobre até quando uma retentativa ainda é a mesma coisa.
		 */
		return { id: sorteado(), gastas: 0, travessias: {}, cortadas: 0, pendentes: [], acumulado: null };
	}

	/**
	 * O ACUMULADO AINDA NÃO SELADO que o carregamento anterior deixou.
	 *
	 * ELE EXISTE PORQUE O `pagehide` NÃO É PROMESSA. A aba encerrada pelo
	 * sistema, o aparelho sem memória, o navegador descartando a página: nesses
	 * casos não chega evento de saída nenhum, e um lote que só é selado na
	 * saída nunca chega a ser selado. Sem este campo, a linha continuaria menos
	 * durável que o contador — que é gravado na hora, a cada travessia — e o
	 * invariante desta release ("o contador e a linha têm a MESMA
	 * durabilidade") ficaria valendo só para quem sai pela porta.
	 *
	 * O CAMINHO VIAJA COM ELE, e é obrigatório: o carregamento seguinte pode
	 * ser de OUTRA página, e selar linhas de `/` sob o caminho de
	 * `/arquitetura/` gravaria a passagem numa página e a atribuiria a outra —
	 * sem erro nenhum, e com a tabela parecendo certa.
	 *
	 * @param {*} bruto Valor lido do registro guardado.
	 * @return {Object|null} `{caminho, eventos, metricas}` ou nulo.
	 */
	function acumuladoGuardado(bruto) {
		var eventos;
		var metricas;

		if (!bruto || 'object' !== typeof bruto || !/^\/[A-Za-z0-9\/_\-.~%]*$/.test(String(bruto.caminho || ''))) {
			return null;
		}

		eventos = linhasGuardadas(bruto.eventos);
		metricas = totaisGuardados(bruto.metricas);

		if (!eventos.length && !metricas.length) {
			return null;
		}

		return { caminho: String(bruto.caminho), eventos: eventos, metricas: metricas };
	}

	/**
	 * A JANELA DA VISITA, em milissegundos, e ela tem um produtor só.
	 *
	 * Ela responde a três perguntas que precisam da MESMA resposta: até quando
	 * dois carregamentos são a mesma visita, até quando um lote pendente ainda
	 * é retentativa, e até quando o servidor lembra o selo daquele lote. Três
	 * números seriam três respostas divergindo na primeira vez que alguém
	 * mexesse num só, e a divergência apareceria como linha contada duas vezes.
	 *
	 * @return {number} Janela em milissegundos.
	 */
	function janelaDaVisita() {
		return numeroDoLimiar('pagina', 'inatividade_min', 30) * 60 * 1000;
	}

	/**
	 * A fila de lotes pendentes lida do armazenamento, conferida lote a lote.
	 *
	 * O QUE ESTÁ NO `localStorage` NÃO É NOSSO — a mesma razão de
	 * `contadoresGuardados()`. Aqui ela pesa mais: um lote corrompido não vira
	 * um número torto na tela, vira um CORPO despachado para a rota. Cada
	 * campo é reconstruído a partir do que passou na conferência, e o que não
	 * passa não entra.
	 *
	 * @param {*}      bruto  Valor lido do registro guardado.
	 * @param {number} agora  Instante corrente.
	 * @param {number} janela Janela da visita, em milissegundos.
	 * @return {Object} `{lotes, vencidas}` — a fila válida e as linhas vencidas.
	 */
	function pendentesGuardados(bruto, agora, janela) {
		var lotes = [];
		var vencidas = 0;
		var i;
		var lote;
		var eventos;
		var metricas;

		if (!bruto || !bruto.length) {
			return { lotes: lotes, vencidas: vencidas };
		}

		for (i = 0; i < bruto.length; i++) {
			lote = bruto[i];

			if (!lote || 'object' !== typeof lote || !/^[a-f0-9]{32}$/.test(String(lote.id))) {
				continue;
			}

			eventos = linhasGuardadas(lote.eventos);
			metricas = totaisGuardados(lote.metricas);

			if ((agora - Number(lote.nascido || 0)) >= janela) {
				vencidas = vencidas + eventos.length;

				continue;
			}

			if (!eventos.length && !metricas.length) {
				continue;
			}

			lotes.push({
				id: String(lote.id),
				nascido: Number(lote.nascido),
				/*
				 * A ORIGEM É RECONSTRUÍDA COMO TUDO O MAIS, e o que não é
				 * número finito não positivo vira ZERO — o valor que o
				 * servidor lê como "não mandou origem" e responde caindo na
				 * âncora dele. Reconstruí-la com a origem DESTE carregamento
				 * seria a saída pior: o lote retomado sairia carimbado com a
				 * hora da página que o encontrou, e o erro pareceria certo.
				 */
				origem: origemGuardada(lote.origem),
				caminho: String(lote.caminho || '/'),
				metricas: metricas,
				eventos: eventos,
				cortados: Math.max(0, Math.floor(Number(lote.cortados || 0)) || 0)
			});
		}

		return { lotes: lotes, vencidas: vencidas };
	}

	/**
	 * A ORIGEM TEMPORAL de um lote guardado, conferida.
	 *
	 * O QUE ESTÁ NO `localStorage` NÃO É NOSSO, e aqui isso decide um carimbo:
	 * uma origem corrompida não vira um número torto na tela, vira a HORA de
	 * cada linha daquele lote. O que não é número finito e positivo sai como
	 * zero, e zero é o valor que o servidor lê como "este lote não trouxe
	 * origem" — ele cai na âncora derivada dele, que não confia em relógio
	 * nenhum. Degradar para a âncora do servidor é sempre melhor que carimbar
	 * com um número que sobreviveu à conferência por acidente.
	 *
	 * @param {*} bruto Valor lido do registro guardado.
	 * @return {number} Origem em milissegundos, ou zero.
	 */
	function origemGuardada(bruto) {
		var origem = Number(bruto);

		if (!isFinite(origem) || origem <= 0) {
			return 0;
		}

		return Math.round(origem);
	}

	/**
	 * As linhas de registro de um lote guardado, conferidas uma a uma.
	 *
	 * @param {*} bruto Lista lida do registro guardado.
	 * @return {Array<Object>} Linhas na forma que a rota aceita.
	 */
	function linhasGuardadas(bruto) {
		var saida = [];
		var i;
		var linha;

		if (!bruto || !bruto.length) {
			return saida;
		}

		for (i = 0; i < bruto.length && saida.length < Number(RESUMO.maximoLog || 0); i++) {
			linha = bruto[i];

			if (!linha || 'object' !== typeof linha || !/^[a-z-]+$/.test(String(linha.gatilho))) {
				continue;
			}

			saida.push({
				gatilho: String(linha.gatilho),
				detalhe: detalheDe(linha.detalhe),
				valor: isFinite(Number(linha.valor)) ? Number(linha.valor) : 0,
				ocorrencia: Math.max(0, Math.floor(Number(linha.ocorrencia)) || 0),
				ms: Math.max(0, Math.floor(Number(linha.ms)) || 0)
			});
		}

		return saida;
	}

	/**
	 * Os totais agregados de um lote guardado, conferidos um a um.
	 *
	 * @param {*} bruto Lista lida do registro guardado.
	 * @return {Array<Object>} Totais na forma que a rota aceita.
	 */
	function totaisGuardados(bruto) {
		var saida = [];
		var i;
		var total;

		if (!bruto || !bruto.length) {
			return saida;
		}

		for (i = 0; i < bruto.length && saida.length < Number(RESUMO.maximo || 0); i++) {
			total = bruto[i];

			if (!total || 'object' !== typeof total || !/^[a-z-]+$/.test(String(total.gatilho))) {
				continue;
			}

			saida.push({
				gatilho: String(total.gatilho),
				detalhe: detalheDe(total.detalhe),
				contagem: Math.max(1, Math.floor(Number(total.contagem)) || 1),
				soma: isFinite(Number(total.soma)) ? Number(total.soma) : 0
			});
			if (total.amostra && /^[A-Za-z0-9_-]{8,80}$/.test(String(total.amostra.id)) && ['movel', 'desktop'].indexOf(total.amostra.dispositivo) >= 0 && Number.isInteger(total.amostra.sequencia) && total.amostra.sequencia >= 1 && total.amostra.sequencia <= Number(dados.vitaisMaxAtualizacoes || 0)) {
				saida[saida.length - 1].amostra = { id: total.amostra.id, dispositivo: total.amostra.dispositivo, sequencia: total.amostra.sequencia };
			}

		}

		return saida;
	}

	/**
	 * O mapa de contadores lido do armazenamento, conferido chave a chave.
	 *
	 * O QUE ESTÁ NO `localStorage` NÃO É NOSSO. Qualquer script desta origem
	 * escreve ali, e um registro corrompido — um valor que não é número, um
	 * mapa que virou lista, um objeto com dez mil chaves — sairia daqui direto
	 * para a coluna `ocorrencia` da tabela. Conferir na leitura é mais barato
	 * que descobrir depois por que uma linha diz "NaNª vez".
	 *
	 * @param {*} bruto Valor lido do registro guardado.
	 * @return {Object} Mapa de chave para contagem, com os inválidos fora.
	 */
	function contadoresGuardados(bruto) {
		var limpos = {};
		var quantas = 0;
		var teto = Number(RESUMO.maximoVisita || 0);
		var chave;
		var valor;

		if (!bruto || 'object' !== typeof bruto) {
			return limpos;
		}

		for (chave in bruto) {
			if (Object.prototype.hasOwnProperty.call(bruto, chave)) {
				valor = Math.floor(Number(bruto[chave]));

				if (isFinite(valor) && valor > 0 && quantas < teto) {
					limpos[chave] = valor;
					quantas = quantas + 1;
				}
			}
		}

		return limpos;
	}

	/**
	 * O CAMINHO DESTA PÁGINA, com um produtor só.
	 *
	 * Ele responde em dois lugares — o corpo que viaja ao servidor e a chave do
	 * contador de travessias —, e os dois precisam da MESMA resposta: uma chave
	 * de contador que discordasse do caminho enviado contaria a passagem numa
	 * página e a gravaria em outra, sem erro nenhum.
	 *
	 * @return {string} Caminho da página corrente, sem query e sem âncora.
	 */
	function caminhoDaPagina() {
		return String(window.location.pathname || '/');
	}

	/**
	 * Guarda o estado da visita: o gasto, o contador de travessias, o que foi
	 * cortado, os lotes ainda não confirmados e quando ela foi vista.
	 *
	 * O PENDENTE É GRAVADO ANTES DE O LOTE SER DESPACHADO, e essa ordem é a
	 * metade que fecha o invariante. Gravando depois, o carregamento que morre
	 * entre selar e enviar levaria o lote junto — que é o caso medido na visita
	 * `8cac18da`, em que a ocorrência 2 de `comando-unico` foi contada e a
	 * linha nunca chegou.
	 *
	 * SEM ARMAZENAMENTO, TUDO DEGRADA PARA O COMPORTAMENTO DE HOJE: o pendente
	 * vale por este carregamento, e um carregamento que morre o perde. É a
	 * mesma degradação declarada do contador, e pelo mesmo motivo — medição
	 * parcial é melhor que medição nenhuma.
	 */
	function guardarVisita() {
		if ('' === sessao) {
			return;
		}

		try {
			/*
			 * O REGISTRO É COMPOSTO COM A FILA JÁ EM TEXTO, e cada valor escalar
			 * passa por `JSON.stringify` sozinho — o que sai daqui é o mesmo JSON
			 * de antes, byte a byte, e `pendentesGuardados()` continua lendo cada
			 * campo do jeito que sempre leu. O que mudou é o CUSTO: a fila, que é
			 * a parte grande e a única que não muda entre dois acionamentos, não é
			 * mais reserializada a cada rolagem de marco no aparelho de quem está
			 * lendo a página.
			 */
			window.localStorage.setItem(
				CHAVE_SESSAO,
				'{"id":' + JSON.stringify(sessao)
					+ ',"gastas":' + JSON.stringify(gastasNaVisita)
					+ ',"travessias":' + JSON.stringify(travessiasDaVisita)
					+ ',"cortadas":' + JSON.stringify(cortadasNaVisita)
					/*
					 * O ACUMULADO VAI JUNTO, e é ele que sobrevive ao
					 * carregamento que morre sem evento de saída nenhum. Ele é
					 * gravado a cada linha e a cada total, na hora, pela mesma
					 * razão que o contador é: o instante da saída não é
					 * confiável, e o que a página seguinte lê é o que está
					 * gravado.
					 */
					+ ',"acumulado":' + JSON.stringify({
						caminho: caminhoDaPagina(),
						eventos: registroDaSessao,
						metricas: totaisAcumulados()
					})
					+ ',"pendentes":' + filaSerializada
					+ ',"visto":' + JSON.stringify(Date.now())
					+ '}'
			);
		} catch (erro) {
			// Sem armazenamento, a visita vale por este carregamento e nada é guardado.
		}
	}

	/**
	 * Reserializa a fila de pendentes — só quando ela MUDA.
	 *
	 * @return {void}
	 */
	function serializarFila() {
		try {
			filaSerializada = JSON.stringify(pendentes);
		} catch (erro) {
			filaSerializada = '[]';
		}
	}

	/**
	 * APARA A FILA NO TETO DECLARADO, descartando os lotes MAIS ANTIGOS.
	 *
	 * O TETO NÃO É UM NÚMERO NOVO: é o orçamento da VISITA, o mesmo
	 * `maximoVisita` que já limita quantas linhas ela pode registrar e quantas
	 * chaves o contador pode ter. Uma visita não produz mais lotes úteis que
	 * isso; acima do teto é fila que nunca drenou — servidor em 503 desde
	 * ontem, balde cheio, aparelho sem rede — e ela cresce dentro do
	 * armazenamento do aparelho de quem está só lendo o site.
	 *
	 * OS MAIS ANTIGOS SAEM PRIMEIRO, e a escolha tem motivo: o lote antigo é o
	 * que está mais perto de vencer pela janela da visita, e o novo é o que ainda
	 * pode chegar. Descartar o novo seria jogar fora a medição de agora para
	 * guardar a que já não cabe.
	 *
	 * E O DESCARTE É NOSSO E DECLARADO: cada linha que sai da fila conta em
	 * CORTADAS, viaja nomeada no lote seguinte e aparece na tela — do mesmo jeito
	 * que a travessia que estoura o teto e a linha que não cabe no corpo.
	 *
	 * @return {void}
	 */
	function apararFila() {
		var teto = Math.max(1, Number(RESUMO.maximoVisita || 0));

		while (pendentes.length > teto) {
			cortadasNaVisita = cortadasNaVisita + pendentes[0].eventos.length;
			pendentes.shift();
		}
	}

	/**
	 * Conta MAIS UMA passagem por um ponto da visita, e devolve a vez.
	 *
	 * A CHAVE É `caminho | gatilho | detalhe`, e o caminho está ali porque
	 * `pecas` em `/` e `pecas` em `/arquitetura/` são seções diferentes com o
	 * mesmo nome. Somá-las responderia uma pergunta que ninguém fez e
	 * esconderia as duas.
	 *
	 * ZERO É RESPOSTA, e significa "não coube": o mapa chegou ao teto de chaves
	 * e a passagem conta em cortadas, sem criar chave nova. Quem chama trata o
	 * zero como corte, e é por isso que ele não é uma vez válida — a primeira
	 * passagem por um ponto é sempre a 1ª.
	 *
	 * @param {string} gatilho Gatilho do coletor.
	 * @param {string} detalhe Detalhe do acionamento.
	 * @return {number} A vez desta passagem na visita, ou 0 quando não coube.
	 */
	function contarTravessia(gatilho, detalhe) {
		var chave = caminhoDaPagina() + '|' + gatilho + '|' + detalheDe(detalhe);

		if (!Object.prototype.hasOwnProperty.call(travessiasDaVisita, chave)) {
			if (chavesDeTravessia >= Number(RESUMO.maximoVisita || 0)) {
				return 0;
			}

			travessiasDaVisita[chave] = 0;
			chavesDeTravessia = chavesDeTravessia + 1;
		}

		travessiasDaVisita[chave] = travessiasDaVisita[chave] + 1;

		/*
		 * A CONTAGEM É GRAVADA NA HORA, e não no fim do carregamento: a saída
		 * de página não é um instante confiável — a aba é fechada, o navegador
		 * é morto, o `pagehide` não chega. O que a próxima página lê é o que
		 * está gravado, e travessia contada só na memória é travessia perdida
		 * na navegação, que é justamente o defeito que este contador conserta.
		 */
		guardarVisita();

		return travessiasDaVisita[chave];
	}

	/**
	 * O apelido cuja exclusão foi pedida e ainda não foi confirmada.
	 *
	 * @return {string} Apelido pendente, ou string vazia.
	 */
	function exclusaoPendente() {
		var guardado;

		try {
			guardado = window.localStorage.getItem(CHAVE_EXCLUSAO);
		} catch (erro) {
			return '';
		}

		return (guardado && /^[a-f0-9]{32}$/.test(guardado)) ? guardado : '';
	}

	/**
	 * Apaga do navegador tudo o que identifica este visitante.
	 *
	 * @return {void}
	 */
	function apagarChavesLocais() {
		try {
			window.localStorage.removeItem(CHAVE_VISITANTE);
			window.localStorage.removeItem(CHAVE_SESSAO);
			window.localStorage.removeItem(CHAVE_EXCLUSAO);
		} catch (erro) {
			// Sem armazenamento não havia o que apagar aqui.
		}
	}

	/**
	 * PEDE AO SERVIDOR QUE APAGUE O REGISTRO de um apelido, e CONFIRMA.
	 *
	 * O CAMINHO É O MESMO DOS LOTES, e essa é a correção: `fetch` com
	 * `keepalive` sobrevive à saída da página como o beacon e, ao contrário
	 * dele, DEVOLVE resposta. `sendBeacon` fica como reserva do navegador que
	 * não tem a combinação — lá o pedido segue pendente e é reenviado no
	 * carregamento seguinte, porque enfileirar não é entregar.
	 *
	 * AS CHAVES LOCAIS SÓ SOMEM COM 2XX. Apagá-las antes apaga a PROVA do
	 * pedido: o registro continua no servidor e o navegador não tem mais o
	 * apelido para pedir de novo. O direito vira um beacon disparado no escuro.
	 *
	 * @param {string} apelido Apelido a esquecer.
	 * @return {void}
	 */
	function pedirExclusao(apelido) {
		var alvo = String(RESUMO.esquecer || '');
		var corpo;

		if ('' === apelido || '' === alvo) {
			return;
		}

		corpo = JSON.stringify({ token: String(RESUMO.token || ''), visitante: apelido });

		/*
		 * O PENDENTE É GRAVADO ANTES DO DESPACHO, pela mesma razão que o lote é:
		 * a página pode morrer entre pedir e receber, e o que o carregamento
		 * seguinte lê é o que está gravado.
		 */
		try {
			window.localStorage.setItem(CHAVE_EXCLUSAO, apelido);
		} catch (erro) {
			// Sem armazenamento não há pendente a guardar: o pedido vale por este carregamento.
		}

		if (confirmaEntrega()) {
			try {
				window.fetch(alvo, {
					method: 'POST',
					keepalive: true,
					credentials: 'omit',
					headers: { 'Content-Type': 'application/json' },
					body: corpo
				}).then(function (resposta) {
					var status = Number((resposta && resposta.status) || 0);

					if (status >= 200 && status < 300) {
						apagarChavesLocais();
					}
				})['catch'](function () {
					/*
					 * A REDE CAIU. O pendente fica gravado e o carregamento
					 * seguinte reenvia — exatamente como o lote recusado.
					 */
				});

				return;
			} catch (erro) {
				// Medição nunca interrompe o fluxo do visitante: cai para o beacon.
			}
		}

		try {
			if (window.navigator && typeof window.navigator.sendBeacon === 'function') {
				window.navigator.sendBeacon(alvo, new window.Blob([ corpo ], { type: 'application/json' }));
			}
		} catch (erro) {
			// Sem beacon e sem fetch o pedido fica pendente para o carregamento seguinte.
		}
	}

	/**
	 * Pede a exclusão e esquece, na memória, tudo o que identifica a visita.
	 *
	 * O APELIDO VEM DA MEMÓRIA, e ela é o apelido EM USO neste carregamento.
	 * Quem chama isto é a RECUSA no controle do rodapé — uma ação do visitante,
	 * numa página em que o carregador rodou —, e ali `visitante` está preenchido.
	 *
	 * POR QUE ELE NÃO É LIDO DO ARMAZENAMENTO. Houve uma versão que o lia de lá e
	 * disparava a exclusão também no CARREGAMENTO com o portão negado. Isso
	 * transformava três coisas que não são pedido de ninguém — o cookie de
	 * consentimento vencido, a política trocada por quem opera o site, a recusa
	 * dada noutra aba — em apagamento definitivo do registro no servidor. A
	 * consequência aceita da regra atual está declarada: quando o consentimento
	 * voltar a permitir, o mesmo apelido religa a navegação nova ao histórico
	 * anterior. Só a recusa apaga, e ela apaga dos dois lados.
	 *
	 * O QUE PERMANECE É O CAMINHO CONFIRMADO: `pedirExclusao()` despacha por
	 * `fetch` com `keepalive`, as chaves locais só somem com 2xx, e o pedido que
	 * não chegou fica em `f3base_exclusao_pendente` e parte de novo no
	 * carregamento seguinte.
	 */
	function esquecerVisitante() {
		pedirExclusao(visitante);

		visitante = '';
		sessao = '';
		registroDaSessao = [];

		/*
		 * O PENDENTE VAI JUNTO. Ele é registro do visitante como a linha do log
		 * é: mantê-lo faria o próximo despacho mandar ao servidor as linhas de
		 * uma visita que acabou de ser apagada do aparelho E do servidor, pela
		 * rota de exclusão — a exclusão desfeita pelo próprio cliente que a
		 * pediu.
		 */
		pendentes = [];

		/*
		 * O CONTADOR VAI JUNTO. Ele é estado da visita como o apelido é: deixá-lo
		 * na memória faria o próximo aceite, na mesma página, continuar a contagem
		 * de uma visita que acabou de ser apagada do aparelho e do servidor.
		 */
		travessiasDaVisita = {};
		chavesDeTravessia = 0;
		cortadasNaVisita = 0;
		resumoDaSessao = {};
		linhasDoResumo = 0;
		despachando = [];

		serializarFila();
	}

	/**
	 * Registra um acontecimento com carimbo de tempo.
	 *
	 * O CARIMBO É RELATIVO AO CARREGAMENTO, e não um relógio de parede: o que
	 * a pergunta do usuário pede é "quanto tempo levou para percorrer a
	 * página", e essa é uma distância, não uma hora. Guardar a hora absoluta
	 * daria a mesma resposta com um dado a mais sobre a pessoa, e dado a mais
	 * sem pergunta a mais é o que a retenção curta existe para evitar.
	 */
	function registrar(gatilho, detalhe, valor, ocorrencia) {
		if (!RESUMO.ativo || '' === visitante || '' === sessao) {
			return;
		}

		/*
		 * DOIS TETOS, E ELES DEIXARAM DE TER A MESMA RESPOSTA — esta separação
		 * é da 1.3.5, e ela é a última rota pela qual o contador andava sem a
		 * linha chegar.
		 *
		 * O da VISITA é o orçamento do episódio inteiro de navegação: passado
		 * ele, a visita não grava mais nada, e a série de cada gatilho
		 * simplesmente PARA. Truncar o fim de uma série não é o mesmo que
		 * abrir buraco no meio dela — quem lê vê onde a contagem terminou, e o
		 * excedente sai nomeado em cortadas.
		 *
		 * O do CORPO é outra coisa inteiramente, e tratá-lo como o primeiro era
		 * o defeito. Ele limita quantas linhas cabem em UM lote, e depois do
		 * selamento o registro volta a aceitar — então a linha cortada por ele
		 * ficava no MEIO da série, com o contador já avançado e as linhas
		 * seguintes chegando normalmente. É exatamente o buraco que esta
		 * release existe para eliminar, sobrevivendo por outro caminho. E ele é
		 * alcançável sem nada de anormal: cento e vinte acionamentos entre dois
		 * ocultamentos é um leitor inquieto numa página longa que não troca de
		 * aba. O caso de rajada — o erro de JavaScript em laço de render — tem
		 * teto próprio de 3 na declaração do evento, e nunca foi este.
		 *
		 * ENTÃO O TETO DO CORPO SELA O LOTE, EM VEZ DE CORTAR A LINHA. O lote
		 * cheio vira um lote pendente na hora, a linha entra no lote seguinte e
		 * a série não abre buraco. Cortar continua existindo onde não há
		 * alternativa — o orçamento da visita acima, e a linha que sozinha não
		 * cabe no corpo, em `selar()` —, mas deixou de ser a resposta normal a
		 * um leitor atento.
		 */
		if (gastasNaVisita >= Number(RESUMO.maximoVisita || 0)) {
			cortadasNaVisita = cortadasNaVisita + 1;

			return;
		}

		if (registroDaSessao.length >= Number(RESUMO.maximoLog || 0)) {
			selarLote();
		}

		gastasNaVisita = gastasNaVisita + 1;

		registroDaSessao.push({
			gatilho: gatilho,
			detalhe: detalhe,
			valor: valor,
			ocorrencia: ocorrencia,
			ms: Math.max(0, Math.round(Date.now() - nascimento))
		});

		guardarVisita();
	}

	/**
	 * O detalhe de uma linha, ou string vazia quando o valor não é detalhe.
	 *
	 * A porta é a FORMA, e não uma lista de eventos: o mesmo teste recusa o
	 * caminho de arquivo do erro e aceita o host, a seção, o marco e o nome da
	 * métrica, sem que o cliente precise saber de qual coletor o valor veio.
	 */
	function detalheDe(valor) {
		var texto = (undefined === valor || null === valor) ? '' : String(valor);

		return /^[A-Za-z0-9][A-Za-z0-9._-]{0,59}$/.test(texto) ? texto : '';
	}

	/**
	 * Soma um disparo no resumo da sessão, sob o mesmo teto do dataLayer.
	 */
	function acumular(gatilho, valores, amostra) {
		var detalhe;
		var soma;
		var chave;

		if (!RESUMO.ativo) {
			return;
		}

		detalhe = detalheDe(valores[0]);
		soma = ('' !== detalhe && valores.length > 1 && 'number' === typeof valores[1] && isFinite(valores[1]))
			? valores[1]
			: 0;

		chave = gatilho + '|' + detalhe + (amostra ? '|' + amostra.id : '');

		if (!Object.prototype.hasOwnProperty.call(resumoDaSessao, chave)) {
			if (linhasDoResumo >= Number(RESUMO.maximo || 0)) {
				return;
			}

			resumoDaSessao[chave] = { gatilho: gatilho, detalhe: detalhe, contagem: 0, soma: 0 };
			linhasDoResumo = linhasDoResumo + 1;
		}

		if (amostra) {
			resumoDaSessao[chave].contagem = 1;
			resumoDaSessao[chave].soma = soma;
			resumoDaSessao[chave].amostra = amostra;
		} else {
			resumoDaSessao[chave].contagem += 1;
			resumoDaSessao[chave].soma += soma;
		}

		/*
		 * O TOTAL É GRAVADO NA HORA, pela mesma razão que a linha e o contador:
		 * um carregamento que morre sem evento de saída levaria junto o
		 * agregado, e o painel passaria a mostrar menos visitas do que a tabela
		 * mostra acionamentos — as duas leituras discordando sem que nada
		 * dissesse por quê.
		 */
		guardarVisita();
	}

	/**
	 * Os totais acumulados desde o último selamento, como lista.
	 *
	 * @return {Array<Object>} Totais na forma que a rota aceita.
	 */
	function totaisAcumulados() {
		var lista = [];
		var chave;

		for (chave in resumoDaSessao) {
			if (Object.prototype.hasOwnProperty.call(resumoDaSessao, chave)) {
				lista.push(resumoDaSessao[chave]);
			}
		}

		return lista;
	}

	/**
	 * O CORPO de um lote, na forma fechada que a rota aceita.
	 *
	 * O SELO VIAJA COM ELE. É pelo selo que o servidor reconhece uma
	 * retentativa: um lote que ele já gravou para esta visita é recusado como
	 * repetição e respondido 2xx assim mesmo, e é isso que permite reenviar sem
	 * contar duas vezes quando a resposta se perde no caminho de volta.
	 *
	 * O TOKEN NÃO VIAJA NO LOTE, e sai daqui de propósito: ele é efêmero e vem
	 * da página que está despachando AGORA. Selado dentro do lote, uma
	 * retentativa feita no carregamento seguinte levaria o token da página que
	 * morreu — expirado — e a rota responderia 403 para sempre sobre um lote
	 * que só precisava de uma credencial fresca.
	 *
	 * @param {Object} lote Lote selado.
	 * @return {Object} Corpo a despachar.
	 */
	function corpoDoLote(lote) {
		return {
			token: String(RESUMO.token || ''),
			lote: lote.id,
			/*
			 * A ORIGEM VAI UMA VEZ POR LOTE, e não uma vez por linha. Ela é a
			 * mesma para todas as linhas do lote por construção — todas nasceram
			 * do mesmo carregamento —, e repeti-la em cada uma seria pagar
			 * bytes de corpo, num corpo que tem teto, para transportar o mesmo
			 * número dezenas de vezes.
			 */
			origem: lote.origem,
			caminho: lote.caminho,
			metricas: lote.metricas,
			/*
			 * OS APELIDOS VÃO VAZIOS quando o armazenamento está bloqueado, e o
			 * servidor aceita o corpo assim mesmo: some o registro detalhado, e
			 * o agregado — que é o que a tela soma — continua inteiro.
			 */
			visitante: visitante,
			sessao: sessao,
			eventos: lote.eventos,
			cortados: lote.cortados
		};
	}

	/**
	 * Quantos BYTES um texto ocupa em UTF-8.
	 *
	 * O teto do endpoint é medido em bytes (`strlen` do corpo recebido), e o
	 * caminho de uma página pode ter acento: `/servicos/` e `/serviços/` têm o
	 * mesmo comprimento em caracteres e tamanhos diferentes em bytes. Contar
	 * caracteres deixaria passar um corpo que o servidor recusa com 413 —
	 * e um lote recusado por tamanho é um lote que a retentativa nunca conserta.
	 *
	 * @param {string} texto Texto a medir.
	 * @return {number} Bytes em UTF-8.
	 */
	function bytesDe(texto) {
		var total = 0;
		var i;
		var codigo;

		for (i = 0; i < texto.length; i++) {
			codigo = texto.charCodeAt(i);

			if (codigo < 0x80) {
				total = total + 1;
			} else if (codigo < 0x800) {
				total = total + 2;
			} else if (codigo >= 0xD800 && codigo <= 0xDBFF) {
				total = total + 4;
				i = i + 1;
			} else {
				total = total + 3;
			}
		}

		return total;
	}

	/**
	 * O lote cabe no teto de corpo que o SERVIDOR publicou?
	 *
	 * O TETO É DELE, e por isso ele é publicado em vez de escrito aqui: um
	 * número no cliente seria uma segunda verdade sobre o mesmo limite,
	 * divergindo no dia em que alguém mexesse no do endpoint. Teto não
	 * publicado devolve `true` — o cliente não inventa limite —, e o corpo
	 * grande que escapar é recusado com 413, que este cliente trata como
	 * recusa PERMANENTE justamente para que ele não fique preso na fila.
	 *
	 * @param {Object} lote Lote selado.
	 * @return {boolean}
	 */
	function cabeNoCorpo(lote) {
		var teto = Number(RESUMO.maximoBytes || 0);

		if (teto < 1) {
			return true;
		}

		return bytesDe(JSON.stringify(corpoDoLote(lote))) <= teto;
	}

	/**
	 * SELA o acumulado desde o último envio em um ou mais lotes imutáveis.
	 *
	 * POR QUE SELAR EM VEZ DE DESPACHAR DIRETO. O lote leva um identificador
	 * sorteado que o servidor usa para recusar repetição. Se o conteúdo do lote
	 * pudesse crescer depois de o selo existir, a retentativa levaria um
	 * conteúdo diferente sob um selo já conhecido — o servidor responderia "já
	 * tenho isto", o cliente esqueceria o lote, e as linhas acrescentadas
	 * sumiriam sem que nada acusasse. Selado é imutável: atividade nova forma
	 * o lote seguinte.
	 *
	 * POR QUE ELE PODE VIRAR MAIS DE UM. O corpo tem teto de bytes no endpoint.
	 * Um lote que não cabe seria recusado com 413 em toda tentativa e ficaria
	 * na fila para sempre, bloqueando atrás dele tudo o que veio depois — o
	 * pendente eterno é a forma que a perda assume quando se retém sem critério.
	 * A partição acontece AQUI, no selamento, e nunca no despacho: partir um
	 * lote já selado mudaria o conteúdo sob o mesmo selo.
	 *
	 * @return {void}
	 */
	function selarLote() {
		var acumulado = registroDaSessao;
		var totais = totaisAcumulados();

		/*
		 * LOTE VAZIO NÃO VIAJA. A aba que perde e recupera o foco sem nada ter
		 * acontecido no meio não produz requisição nenhuma — e é esta guarda,
		 * e não uma trava permanente, que impede o mesmo conteúdo de ser
		 * enviado duas vezes pelos dois eventos de saída, que disparam juntos.
		 */
		if (!totais.length && !acumulado.length) {
			return;
		}

		registroDaSessao = [];
		resumoDaSessao = {};
		linhasDoResumo = 0;

		selar(caminhoDaPagina(), totais, acumulado);
	}

	/**
	 * Sela um acumulado — o desta página ou o herdado — em lotes imutáveis.
	 *
	 * @param {string}        caminho   Caminho a que o acumulado pertence.
	 * @param {Array<Object>} metricas  Totais agregados.
	 * @param {Array<Object>} restantes Linhas do registro.
	 * @return {void}
	 */
	function selar(caminho, metricas, restantes) {
		var lote;

		do {
			lote = {
				id: sorteado(),
				nascido: Date.now(),
				/*
				 * A ORIGEM VIAJA DENTRO DO SELO, uma vez por lote, e é aqui
				 * que ela entra por dois motivos que a fila pendente torna
				 * inseparáveis.
				 *
				 * PRIMEIRO, ELA PRECISA SOBREVIVER AO CARREGAMENTO. Um lote
				 * que não conseguiu ser entregue fica no armazenamento e parte
				 * no carregamento SEGUINTE, que tem outra origem — a dele. Lida
				 * na hora do despacho, a origem seria a da página errada, e as
				 * linhas do lote retomado sairiam carimbadas no futuro delas.
				 *
				 * SEGUNDO, SELADO É IMUTÁVEL. É o mesmo motivo pelo qual as
				 * linhas não podem crescer depois do selo: a retentativa leva o
				 * mesmo corpo sob o mesmo selo, e um corpo que mudasse entre
				 * uma tentativa e outra faria o servidor responder "já tenho
				 * isto" sobre um conteúdo que ele não tem.
				 *
				 * `nascido` NÃO SERVE PARA ISTO e continua existindo ao lado:
				 * ele é o instante do SELAMENTO, e é dele que sai o
				 * vencimento do pendente. A origem é o instante do
				 * CARREGAMENTO, e é dela que sai o carimbo de cada linha.
				 */
				origem: Math.round(nascimento),
				caminho: caminho,
				metricas: metricas,
				eventos: [],
				cortados: cortadasNaVisita
			};

			/*
			 * OS TOTAIS E AS CORTADAS VÃO NO PRIMEIRO LOTE, e só nele: eles são
			 * do período desde o último envio, e repeti-los em cada partição
			 * somaria o mesmo total tantas vezes quantas o registro precisou
			 * ser partido.
			 */
			metricas = [];
			cortadasNaVisita = 0;

			while (restantes.length > 0) {
				lote.eventos.push(restantes[0]);

				if (!cabeNoCorpo(lote)) {
					lote.eventos.pop();

					break;
				}

				restantes.shift();
			}

			/*
			 * UMA LINHA SOZINHA QUE NÃO CABE É CORTADA NOMEADA. Sem esta saída
			 * o laço não avançaria: o lote sairia vazio, a linha continuaria na
			 * frente da fila, e o selamento repetiria para sempre. Cortada é
			 * pior que gravada e muito melhor que travar a fila inteira atrás
			 * de uma linha que nenhum servidor vai aceitar.
			 */
			if (!lote.eventos.length && restantes.length > 0) {
				restantes.shift();
				lote.cortados = lote.cortados + 1;
			}

			if (lote.eventos.length > 0 || lote.metricas.length > 0 || lote.cortados > 0) {
				pendentes.push(lote);
			}
		} while (restantes.length > 0);

		apararFila();
		serializarFila();

		guardarVisita();
	}

	/**
	 * Este navegador sabe CONFIRMAR a entrega de um envio que sobrevive à saída?
	 *
	 * `fetch` com `keepalive` é a única combinação que dá as duas coisas: a
	 * requisição continua depois de a página ser descarregada, como no beacon,
	 * e a resposta volta. `keepalive` é o discriminante, e não `fetch`: um
	 * navegador com `fetch` e sem `keepalive` cancelaria a requisição na saída,
	 * que é pior que o beacon.
	 *
	 * @return {boolean}
	 */
	function confirmaEntrega() {
		try {
			return 'function' === typeof window.fetch
				&& 'function' === typeof window.Request
				&& ('keepalive' in window.Request.prototype);
		} catch (erro) {
			return false;
		}
	}

	/**
	 * Esquece um lote: ele não será despachado de novo.
	 *
	 * A REMOÇÃO É POR IDENTIDADE, e não pelo selo. Sem gerador criptográfico o
	 * selo sai vazio, e dois lotes vazios seriam o mesmo lote para uma busca
	 * por selo — um deles sumiria da fila sem nunca ter sido despachado.
	 *
	 * @param {Object} lote Lote selado.
	 * @return {void}
	 */
	function esquecerLote(lote) {
		var restam = [];
		var i;

		for (i = 0; i < pendentes.length; i++) {
			if (pendentes[i] !== lote) {
				restam.push(pendentes[i]);
			}
		}

		pendentes = restam;

		serializarFila();

		guardarVisita();
	}

	/**
	 * Este lote já está sendo despachado, com a resposta ainda por vir?
	 *
	 * @param {Object} lote Lote selado.
	 * @return {boolean}
	 */
	function emVoo(lote) {
		var i;

		for (i = 0; i < despachando.length; i++) {
			if (despachando[i] === lote) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Tira um lote da lista dos que estão em voo.
	 *
	 * @param {Object} lote Lote selado.
	 * @return {void}
	 */
	function pousar(lote) {
		var restam = [];
		var i;

		for (i = 0; i < despachando.length; i++) {
			if (despachando[i] !== lote) {
				restam.push(despachando[i]);
			}
		}

		despachando = restam;
	}

	/**
	 * A recusa é PERMANENTE — isto é, a retentativa nunca vai mudar de resposta?
	 *
	 * A LISTA É CURTA E É SOBRE O CORPO. 400 é o schema fechado dizendo que
	 * este corpo não entra (campo desconhecido, detalhe fora do alfabeto,
	 * caminho com query, gatilho não declarado); 413 é o teto de tamanho do
	 * endpoint. Nenhum dos dois muda por esperar, e um lote assim retido é uma
	 * fila que nunca drena — o pendente eterno bloqueia atrás dele tudo o que
	 * veio depois, e a perda volta pela porta dos fundos, agora com atraso.
	 *
	 * TUDO O MAIS É TRANSITÓRIO e o lote fica: rede caindo, 403 de token
	 * expirado (o carregamento seguinte leva um fresco), 409 de medição
	 * desligada, 429 de balde cheio, 503 de migração em curso, 5xx do servidor.
	 *
	 * @param {number} status Código de resposta.
	 * @return {boolean}
	 */
	function recusaPermanente(status) {
		return 400 === status || 413 === status;
	}

	/**
	 * Fecha o destino de um lote a partir do código de resposta.
	 *
	 * @param {Object} lote   Lote selado.
	 * @param {number} status Código de resposta.
	 * @return {void}
	 */
	function concluirLote(lote, status) {
		if (status >= 200 && status < 300) {
			esquecerLote(lote);

			return;
		}

		if (recusaPermanente(status)) {
			/*
			 * O CORTE É NOSSO E SAI NOMEADO. As linhas deste lote foram
			 * contadas e não vão virar registro: somá-las em cortadas é o que
			 * impede o total do painel de discordar da tabela sem nada dizendo
			 * por quê. Elas viajam no lote seguinte.
			 */
			cortadasNaVisita = cortadasNaVisita + lote.eventos.length;

			esquecerLote(lote);

			return;
		}

		/*
		 * RECUSA TRANSITÓRIA NÃO MEXE EM NADA. O lote continua exatamente onde
		 * está — gravado, com o mesmo selo — e parte de novo no ocultamento
		 * seguinte ou no carregamento seguinte da mesma visita.
		 */
	}

	/**
	 * Despacha UM lote selado.
	 *
	 * @param {Object} lote Lote selado.
	 * @return {void}
	 */
	function despacharLote(lote) {
		var corpo;
		var alvo = String(RESUMO.endpoint);
		var aceito;

		/*
		 * O LOTE EM VOO NÃO PARTE DE NOVO. Numa saída de página o navegador emite
		 * `visibilitychange` para hidden E `pagehide`, um atrás do outro, e os
		 * dois chamam o mesmo despachante: o primeiro envio ainda não teve
		 * resposta, o lote continua na fila, e o segundo evento o manda outra vez.
		 * Com selo o servidor reconhece a repetição; SEM selo — o navegador sem
		 * gerador criptográfico — ele não tem o que deduplicar, e o agregado
		 * daquele carregamento entra DOBRADO na tabela.
		 */
		if (emVoo(lote)) {
			return;
		}

		corpo = JSON.stringify(corpoDoLote(lote));

		if (confirmaEntrega()) {
			try {
				despachando.push(lote);

				/*
				 * `credentials: 'omit'` porque esta rota não autentica por
				 * cookie: ela valida um token efêmero assinado. Mandar o cookie
				 * de sessão do WordPress numa requisição de medição o entregaria
				 * também ao CDN que estiver na frente, sem que ele sirva para
				 * nada aqui.
				 */
				window.fetch(alvo, {
					method: 'POST',
					keepalive: true,
					credentials: 'omit',
					headers: { 'Content-Type': 'application/json' },
					body: corpo
				}).then(function (resposta) {
					pousar(lote);
					concluirLote(lote, Number((resposta && resposta.status) || 0));
				})['catch'](function () {
					/*
					 * A REDE CAIU, e isso é recusa transitória: o lote fica
					 * pendente, com o mesmo selo, e parte na tentativa seguinte —
					 * por isso ele sai da lista dos que estão em voo.
					 */
					pousar(lote);
				});

				return;
			} catch (erro) {
				/*
				 * Medição nunca interrompe o fluxo do visitante: cai para o
				 * beacon, e o lote deixa de estar em voo pelo caminho que falhou.
				 */
				pousar(lote);
			}
		}

		if (!window.navigator || typeof window.navigator.sendBeacon !== 'function') {
			return;
		}

		try {
			aceito = window.navigator.sendBeacon(alvo, new window.Blob([corpo], { type: 'application/json' }));
		} catch (erro) {
			// Medição nunca interrompe o fluxo do visitante.
			aceito = false;
		}

		/*
		 * O CAMINHO DE RESERVA, E A PERDA QUE ELE MANTÉM, DECLARADA.
		 *
		 * `sendBeacon` devolvendo `true` diz que o navegador ACEITOU a carga
		 * para transferência — não que ela chegou. Aqui não há como saber, e
		 * por isso o lote é esquecido sobre o enfileiramento: neste caminho o
		 * lote enfileirado-e-perdido continua sendo perda. É a degradação
		 * declarada, e ela é estritamente menor que a de antes — o pendente já
		 * foi GRAVADO antes deste despacho, então a página que morre antes de o
		 * envio sair não perde nada, e o selo impede que a retentativa do
		 * carregamento seguinte conte duas vezes.
		 *
		 * `false` é recusa do próprio navegador — fila cheia, corpo grande — e
		 * é transitória: o lote fica inteiro para a próxima tentativa.
		 */
		if (aceito) {
			esquecerLote(lote);
		}
	}

	/**
	 * Despacha a fila de pendentes, na ordem em que os lotes foram selados.
	 *
	 * A ORDEM É O CONTRATO: o pendente sai antes do novo. A fila é copiada
	 * antes do laço porque `esquecerLote()` a reescreve — no caminho do beacon
	 * isso acontece DENTRO da própria iteração.
	 *
	 * @return {void}
	 */
	function despacharPendentes() {
		var fila = pendentes.slice();
		var i;

		if (!RESUMO.ativo || !RESUMO.endpoint) {
			return;
		}

		for (i = 0; i < fila.length; i++) {
			despacharLote(fila[i]);
		}
	}

	/**
	 * Sela o acumulado desde o último envio e despacha o que estiver pendente.
	 */
	function enviarResumo() {
		/*
		 * ENVIAR-E-LIMPAR, e não enviar-uma-vez. A diferença consertou o defeito
		 * que apagava metade de toda visita deste pacote.
		 *
		 * O QUE ACONTECIA. `visibilitychange` para `hidden` NÃO dispara só
		 * quando a pessoa sai da página: dispara quando a aba perde o foco —
		 * outra janela, outra aba, o próprio navegador saindo de foco. No
		 * primeiro desses instantes o beacon partia com o que existia,
		 * `resumoEnviado` travava em `true` e a página ficava SURDA pelo resto
		 * da visita: tudo o que o visitante rolasse depois era acumulado na
		 * memória e morria ali. Numa visita real medida em produção, cada
		 * carregamento registrou só o primeiro segundo — a abertura da página e
		 * o bloco que já estava no topo —, e nenhuma rolagem, nunca.
		 *
		 * POR QUE ISTO NÃO REABRE A CONTAGEM DOBRADA. A trava existia para
		 * impedir o reenvio do MESMO conteúdo, e o lote resolve o mesmo
		 * problema por construção: cada selamento leva só o que foi acumulado
		 * desde o anterior, e o acumulado é esvaziado ao selar. O mesmo
		 * acionamento não tem como entrar em dois lotes.
		 *
		 * O QUE NÃO REARMA. As vitais usam identidade própria de amostra:
		 * atualizar seu valor não cria outro carregamento no relatório. O rearme é do LOTE.
		 */
		if (resumoEnviado || !RESUMO.ativo || !RESUMO.endpoint) {
			return;
		}

		/* Guarda de reentrância enquanto este envio está em curso. */
		resumoEnviado = true;

		selarLote();
		despacharPendentes();

		/*
		 * O REARME. É esta linha que devolve o ouvido à página: a atividade
		 * seguinte forma um lote novo, que parte no próximo ocultamento ou na
		 * saída.
		 */
		resumoEnviado = false;
	}

	/**
	 * A declaração de um coletor, encontrada pelo GATILHO dele.
	 *
	 * O gatilho é a chave de junção entre o cliente e a declaração, e é por
	 * isso que ele é único no arquivo. O cliente NÃO conhece nome de evento:
	 * ele pede `rolagem` e recebe de volta o nome, os parâmetros e o teto. É
	 * isso que torna o nome do evento renomeável num lugar só, sem tocar em uma
	 * linha de JavaScript — e é isso que a série histórica precisa para
	 * sobreviver a uma release.
	 */
	function declaracao(gatilho) {
		var nome;

		for (nome in EVENTOS) {
			if (Object.prototype.hasOwnProperty.call(EVENTOS, nome) && EVENTOS[nome].gatilho === gatilho) {
				return { nome: nome, dados: EVENTOS[nome] };
			}
		}

		return null;
	}

	/**
	 * Um valor de limiar declarado, com o padrão de reserva.
	 *
	 * O padrão só existe para o caso de a declaração chegar truncada; ele nunca
	 * é o caminho normal, e por isso é o valor mais conservador possível —
	 * aquele que NÃO emite.
	 */
	function limiar(gatilho, chave, reserva) {
		var d = declaracao(gatilho);
		var lista = d && d.dados.limiar && d.dados.limiar[chave];

		return (lista && lista.length) ? lista : reserva;
	}

	function numeroDoLimiar(gatilho, chave, reserva) {
		var lista = limiar(gatilho, chave, null);
		var valor = lista ? parseFloat(lista[0]) : NaN;

		return isNaN(valor) ? reserva : valor;
	}

	/**
	 * O TETO, e ele é o único caminho até o `dataLayer`.
	 */
	function podeEmitir(nome, teto) {
		emitidos[nome] = (emitidos[nome] || 0) + 1;

		return emitidos[nome] <= teto;
	}

	/**
	 * O evento nos DOIS formatos, sempre — a mesma regra do `f3base-leads.js`.
	 *
	 * Objeto `{event: …}` é o que um container do GTM lê como gatilho; array de
	 * comando é o que o `gtag.js` consome. Emitir os dois faz a troca de
	 * caminho não perder nada.
	 *
	 * OS PARÂMETROS CHEGAM POSICIONALMENTE, e o nome de cada um vem da
	 * declaração. Duas consequências, e as duas são o ponto:
	 *
	 * - O coletor não escreve nome de parâmetro. Um valor a mais do que a
	 *   declaração prevê é DESCARTADO aqui, e não vaza para o `dataLayer`: a
	 *   porta é a lista declarada, não a boa intenção de quem escreve o
	 *   coletor. É essa porta que impede um payload novo de nascer sem que
	 *   ninguém tenha decidido que ele podia existir.
	 * - A ORDEM da coluna `parametros` no TSV é carregada. Trocar a ordem de
	 *   dois parâmetros lá troca o significado dos dois no relatório, e o
	 *   arquivo diz isso em voz alta. É o preço de o cliente não escrever nome
	 *   nenhum, e ele está declarado nos dois lugares.
	 */
	function emitir(gatilho, valores, amostra) {
		var d = declaracao(gatilho);
		var objeto;
		var limpos = {};
		var i;
		var chave;

		if (!d || !podeEmitir(d.nome, d.dados.teto)) {
			return false;
		}

		for (i = 0; i < d.dados.parametros.length && i < valores.length; i++) {
			if (undefined !== valores[i] && null !== valores[i]) {
				limpos[d.dados.parametros[i]] = valores[i];
			}
		}

		objeto = { event: d.nome };

		for (chave in limpos) {
			if (Object.prototype.hasOwnProperty.call(limpos, chave)) {
				objeto[chave] = limpos[chave];
			}
		}

		acumular(gatilho, valores, amostra);

		/*
		 * TODO COLETOR ENTRA NO REGISTRO, e não só a rolagem: é o carimbo de
		 * tempo que responde "quanto tempo levou até acontecer", e a pergunta
		 * vale para a seção vista e para o clique de fricção tanto quanto para
		 * o marco. A rolagem registra por conta própria, com a ocorrência da
		 * travessia; os demais entram aqui, na primeira vez que acontecem.
		 */
		if ('rolagem' !== gatilho && 'interseccao' !== gatilho) {
			registrar(
				gatilho,
				detalheDe(valores[0]),
				(valores.length > 1 && 'number' === typeof valores[1] && isFinite(valores[1])) ? valores[1] : 0,
				1
			);
		}

		/*
		 * O SLOT VAZIO CONTINUA INERTE PARA A CONTA DE MEDIÇÃO. O resumo local
		 * é um destino; a conta de medição é outro, e sem ID nenhum ela não
		 * existe. Empurrar o evento no `dataLayer` aqui seria alimentar um
		 * container que ninguém carregou — e, no dia em que alguém carregasse
		 * um por fora, o site passaria a mandar dados para uma conta que este
		 * pacote nunca soube que existia.
		 */
		if (CAMINHO === 'nenhum') {
			return true;
		}

		try {
			window.dataLayer.push(objeto);
		} catch (erro) {
			// Medição nunca interrompe o fluxo do visitante.
		}

		if (typeof window.gtag === 'function') {
			try {
				window.gtag('event', d.nome, limpos);
			} catch (erro) {
				// Medição nunca interrompe o fluxo do visitante.
			}
		}

		return true;
	}

	/**
	 * O host de uma URL, ou string vazia quando ela não resolve.
	 *
	 * `new URL` com base: um `href` relativo resolve contra a página, que é
	 * exatamente o que faz um link interno ser reconhecido como interno.
	 */
	function hostDe(url) {
		try {
			return new window.URL(String(url), window.location.href).hostname || '';
		} catch (erro) {
			return '';
		}
	}

	/**
	 * MARCOS DE ROLAGEM — um evento por marco, nunca em rajada.
	 *
	 * A profundidade é medida sobre o documento inteiro, e o marco só dispara
	 * uma vez: o conjunto `vistos` é o que impede a rolagem para cima e para
	 * baixo de gerar uma sequência inteira a cada gesto. O ouvinte é passivo
	 * porque um ouvinte de rolagem que possa cancelar o evento trava a rolagem
	 * do visitante enquanto o coletor pensa.
	 */
	function instrumentarRolagem() {
		var GATILHO = 'rolagem';
		var marcos = limiar(GATILHO, 'marcos', []).map(Number).filter(function (n) {
			return !isNaN(n);
		});
		var vistos = {};
		/*
		 * `dentro` É DO CARREGAMENTO, e continua sendo. A página nova começa no
		 * topo, com nada rolado: persistir "já passei por 50%" faria a primeira
		 * descida do carregamento seguinte ser engolida, e quem trocou de página
		 * perderia justamente a passagem que acabou de fazer. O que atravessa é
		 * o CONTADOR, em `travessiasDaVisita`.
		 */
		var dentro = {};
		/*
		 * O PADRÃO DE RESERVA É O MESMO NÚMERO DA DECLARAÇÃO. Ele valia 6
		 * enquanto a declaração dizia 20, e um TSV corrompido — ou uma linha de
		 * limiar editada errado — apertava o teto para menos de um terço em
		 * silêncio: o registro parava na sexta travessia sem nada em lugar
		 * nenhum dizendo que tinha parado.
		 */
		var tetoDeTravessias = numeroDoLimiar(GATILHO, 'travessias_por_sessao', 30);
		/*
		 * A BANDA DA FRONTEIRA, e ela existe porque a fronteira sem banda
		 * transforma TREMOR em leitura. Rearmando no instante em que o
		 * percentual cai abaixo do marco, um pixel de oscilação na linha dos
		 * 50% — o dedo que segura a página, o cabeçalho que recolhe, a imagem
		 * que entra e empurra a altura — fabrica uma travessia que ninguém fez,
		 * e ela chega ao relatório com cara de releitura. O número da banda
		 * mora na declaração, ao lado dos marcos que ele protege, e não aqui:
		 * um limiar escrito no JavaScript é um número que ninguém revisa junto
		 * com a declaração que ele contradiz.
		 *
		 * A RESERVA É O NÚMERO DA DECLARAÇÃO, e ela valia ZERO — que é a reserva
		 * menos conservadora possível para esta chave: zero REMOVE a banda. Um
		 * TSV truncado, ou uma célula de limiar editada errado, fazia o marco
		 * rearmar na própria linha, e o tremor de um pixel em 50% passava a
		 * fabricar travessia que ninguém fez. É a mesma regra do teto de
		 * travessias logo acima: reserva diferente da declaração é a divergência
		 * acontecendo justamente no dia em que o arquivo se corrompe.
		 */
		var histerese = numeroDoLimiar(GATILHO, 'histerese_pp', 5);

		if (!declaracao(GATILHO) || !marcos.length) {
			return;
		}

		/*
		 * A ALTURA É DESTA PÁGINA, E É RELIDA A CADA MEDIÇÃO. Nada aqui é
		 * global e nada é memoizado: `scrollHeight` é lido do documento no
		 * instante da medição, e por isso a imagem que carrega depois, o
		 * acordeão que abre e o bloco que expande entram na conta na medição
		 * seguinte. Duas páginas do mesmo site têm marcos diferentes porque
		 * têm alturas diferentes, que é a pergunta que o operador faz.
		 */
		function medir() {
			var doc = document.documentElement;
			var corpo = document.body;
			var altura = Math.max(
				(doc && doc.scrollHeight) || 0,
				(corpo && corpo.scrollHeight) || 0
			);
			var visivel = window.innerHeight || (doc && doc.clientHeight) || 0;
			var rolado = window.pageYOffset || (doc && doc.scrollTop) || 0;
			var util = altura - visivel;
			var percentual;
			var vez;
			var i;

			/*
			 * PÁGINA QUE CABE NA TELA É 100% LIDA — mas só depois de a página
			 * TERMINAR DE CARREGAR, e essa espera é o conserto. Medindo na
			 * instalação do coletor, uma página longa cujas imagens ainda não
			 * tinham altura media `util <= 0`, emitia os QUATRO marcos de uma
			 * vez e os queimava em `vistos`: quando a página crescia, não havia
			 * mais marco para emitir. O relatório saía com 25, 50, 75 e 90
			 * empatados em toda página — que é a assinatura de "disparou tudo
			 * junto", e não de "leram até o fim".
			 */
			if (util > 0) {
				percentual = (rolado / util) * 100;
			} else if ('complete' === document.readyState) {
				percentual = 100;
			} else {
				return;
			}

			/*
			 * CADA TRAVESSIA É UMA TRAVESSIA. Até aqui um marco alcançado ficava
			 * marcado para sempre e quem subisse e descesse de novo não produzia
			 * nada — o desenho respondia "esta pessoa chegou a 75%?" e o que se
			 * quer saber é outra coisa: se ela VOLTOU E LEU DE NOVO. Agora o
			 * marco é rearmado quando o visitante sobe abaixo dele, e a descida
			 * seguinte conta como segunda ocorrência.
			 *
			 * A CONTAGEM É DA VISITA E A CHAVE INCLUI O CAMINHO: quem passa por
			 * 50% desta página, navega e volta continua de onde parou, e 50% de
			 * outra página é outro contador. O que NÃO atravessa é `dentro` — o
			 * carregamento novo começa no topo, e é assim que a primeira descida
			 * dele conta.
			 *
			 * O AGREGADO CONTINUA CONTANDO UMA VEZ POR CARREGAMENTO. As duas
			 * leituras convivem de propósito: o total do painel responde
			 * "quantas visitas chegaram até aqui", e o registro responde "quantas
			 * vezes cada uma passou". Somar a releitura no total transformaria
			 * uma pessoa inquieta em audiência que não existe.
			 */
			for (i = 0; i < marcos.length; i++) {
				if (percentual >= marcos[i]) {
					if (!dentro[marcos[i]]) {
						dentro[marcos[i]] = true;
						vez = contarTravessia(GATILHO, String(marcos[i]));

						if (vez > 0 && vez <= tetoDeTravessias) {
							registrar(GATILHO, String(marcos[i]), 0, vez);
						} else {
							/*
							 * ACIMA DO TETO A PASSAGEM VIRA CORTADA, e sai
							 * NOMEADA no corpo. Até a 1.3.3 ela era somada num
							 * mapa `excedentes` que ninguém lia e que não
							 * viajava para lugar nenhum: o comentário prometia
							 * que "a última linha registrada carrega quantas
							 * travessias houve", e a última linha registrada
							 * carregava o TETO, nunca o total. Era corte
							 * silencioso com cara de contabilidade — e o
							 * coletor de seções, ao lado, já contava certo. As
							 * duas travessias que estouram teto agora contam no
							 * mesmo lugar.
							 */
							cortadasNaVisita = cortadasNaVisita + 1;
						}
					}

					if (!vistos[marcos[i]]) {
						vistos[marcos[i]] = true;
						emitir(GATILHO, [ marcos[i] ]);
					}

					continue;
				}

				/*
				 * O REARME, E ELE ACONTECE ABAIXO DA BANDA — nunca na linha.
				 * Sem rearme nenhum, "voltar ao topo e descer de novo" seria
				 * indistinguível de "ficar parado embaixo"; sem a banda, ficar
				 * parado EM CIMA da linha viraria uma sequência de idas e
				 * voltas que não houve.
				 */
				if (percentual < marcos[i] - histerese) {
					dentro[marcos[i]] = false;
				}
			}
		}

		window.addEventListener('scroll', medir, { passive: true });

		/*
		 * A PÁGINA MUDA DE ALTURA SEM NINGUÉM ROLAR, e três coisas avisam:
		 * o fim do carregamento, o redimensionamento da janela e o próprio
		 * documento crescendo. Sem estes três, uma página que só é medida no
		 * `scroll` nunca reavalia o marco de quem abriu, esperou a imagem
		 * entrar e leu sem rolar.
		 */
		window.addEventListener('load', medir);
		window.addEventListener('resize', medir, { passive: true });

		if (typeof window.ResizeObserver === 'function') {
			try {
				new window.ResizeObserver(medir).observe(document.documentElement);
			} catch (erro) {
				// Sem observador de tamanho, o `load` e o `resize` continuam medindo.
			}
		}

		medir();
	}

	/**
	 * A PÁGINA FOI CARREGADA — o denominador de todo o resto.
	 *
	 * POR QUE ESTE EVENTO EXISTE. "2 pessoas chegaram a 90%" não significa nada
	 * sozinho: pode ser 2 de 2 ou 2 de 200. A profundidade de leitura só é
	 * legível como PROPORÇÃO, e proporção precisa de denominador. Sem ele, a
	 * tela teria de inferir o número de carregamentos de outra métrica — o TTFB
	 * é o candidato óbvio —, e inferir seria criar uma segunda verdade sobre
	 * uma contagem, que diverge no primeiro navegador que não reporte a
	 * primeira. Um evento declarado, com teto 1, é a resposta barata e honesta.
	 */
	function instrumentarPaginaVista() {
		var GATILHO = 'pagina';

		if (!declaracao(GATILHO)) {
			return;
		}

		emitir(GATILHO, []);
	}

	/**
	 * SEÇÃO VISTA — o nome sai do markup, e só dele.
	 *
	 * A seção é nomeada por uma classe declarada (`prefixoSecao` + nome), que o
	 * tema carimba nos patterns. NÃO existe nome derivado de texto: um nome
	 * tirado do título mudaria sozinho na primeira revisão de copy, e a série
	 * histórica que um agente compara entre períodos passaria a ter uma seção
	 * nova e uma seção que sumiu, sem que nada tivesse mudado na página.
	 *
	 * Uma vez por NOME, e não por elemento: a mesma seção repetida na página é
	 * a mesma seção.
	 */
	function instrumentarSecoes() {
		var GATILHO = 'interseccao';
		var prefixo = String(COMPORTAMENTO.prefixoSecao || '');
		var visivel = numeroDoLimiar(GATILHO, 'visivel', 0.5);
		/*
		 * A LINHA DE SAÍDA, e ela é DECLARADA — nunca derivada. A reserva é a
		 * própria linha de entrada, de modo que uma declaração sem `saida` cai no
		 * comportamento simétrico de antes desta linha, e não num número inventado
		 * aqui dentro.
		 */
		var saida = numeroDoLimiar(GATILHO, 'saida', visivel);
		var faixas;
		var vistas = {};
		/*
		 * `dentroDaVista` É DO CARREGAMENTO, e continua sendo. A página nova
		 * começa com nada em vista: persistir "este bloco já está na tela" faria
		 * a primeira entrada do carregamento seguinte ser engolida, e o
		 * visitante que trocou de página perderia justamente a passagem que ele
		 * acabou de fazer. O que atravessa é o CONTADOR, em `travessiasDaVisita`.
		 *
		 * E ELE É POR ELEMENTO, e não por NOME — esta é a correção. O observador
		 * é armado por ELEMENTO: uma página com dois blocos da mesma seção
		 * declarada produz dois alvos, e cada um cruza as linhas de entrada e de
		 * saída na hora dele. Com o estado armado guardado sob o NOME, o segundo
		 * bloco entrando derrubava o estado do primeiro: descer uma página com a
		 * mesma seção repetida três vezes fabricava três travessias onde houve
		 * uma leitura contínua, e a tabela chamava isso de releitura.
		 *
		 * O QUE CONTINUA POR NOME é o que a declaração manda ser por nome: o
		 * `vistas`, que emite o evento uma vez por NOME (a mesma seção repetida é
		 * a mesma seção), e o CONTADOR da visita, chaveado por caminho, gatilho e
		 * nome — porque a pergunta que ele responde é "quantas vezes esta pessoa
		 * passou por ESTE bloco", e não por este pedaço de markup.
		 */
		var observados = [];
		var dentroDaVista = [];
		var tetoPorSecao = numeroDoLimiar(GATILHO, 'travessias_por_sessao', 30);
		var observador;
		var alvos;
		var i;

		/**
		 * O índice de um alvo entre os observados, ou -1 quando ele não é um.
		 *
		 * Varredura linear porque a lista é a das seções marcadas de UMA página —
		 * a mais longa desta base tem cinco, e o teto declarado é doze.
		 */
		function indiceDoAlvo(alvo) {
			var k;

			for (k = 0; k < observados.length; k++) {
				if (observados[k] === alvo) {
					return k;
				}
			}

			return -1;
		}

		if (!declaracao(GATILHO) || '' === prefixo || typeof window.IntersectionObserver !== 'function') {
			return;
		}

		/*
		 * DECLARAÇÃO INCOERENTE CAI NO COMPORTAMENTO SIMÉTRICO, e a recusa é do
		 * cliente porque é ele quem paga o preço de uma banda impossível.
		 *
		 * `saida` ausente, não numérica ou negativa não descreve linha nenhuma. E
		 * `saida >= visivel` é a BANDA INVERTIDA, que não é exagero de zelo: com a
		 * saída ACIMA da entrada, a seção rearma enquanto ainda está MAIS visível
		 * do que a entrada exige. Toda razão entre as duas linhas rearma, e toda
		 * razão acima de `saida` conta de novo — de modo que um bloco parado na
		 * vizinhança de `saida`, com o tremor de um cabeçalho que recolhe, produz
		 * uma ocorrência por oscilação. Quem para isso é o teto por visita, e ele
		 * para depois de gravar vinte travessias que ninguém fez, com o corte
		 * saindo NOMEADO como se a culpa fosse do visitante. Uma banda com a
		 * ordem invertida não é uma banda mais larga: é o oposto de uma banda.
		 *
		 * `saida = visivel` é a MESMA LINHA NOS DOIS SENTIDOS: exatamente o que o
		 * pacote fazia antes de a linha de saída existir, e o lugar certo para
		 * cair quando a declaração não diz coisa com coisa.
		 */
		if (!(saida >= 0) || saida >= visivel) {
			saida = visivel;
		}

		/*
		 * AS FAIXAS DO OBSERVADOR SAEM DAS DUAS LINHAS, sem repetir nenhuma. Com
		 * `saida === visivel` — declaração ausente ou incoerente — a lista volta a
		 * ser `[0, visivel]`, que é a de antes: threshold repetido faria o
		 * navegador entregar o mesmo retorno duas vezes na mesma travessia.
		 */
		faixas = saida < visivel ? [ 0, saida, visivel ] : [ 0, visivel ];

		function nomeDaSecao(elemento) {
			var tokens = String(elemento.className || '').split(/\s+/);
			var j;

			for (j = 0; j < tokens.length; j++) {
				if (tokens[j].indexOf(prefixo) === 0 && tokens[j].length > prefixo.length) {
					return tokens[j].slice(prefixo.length);
				}
			}

			return '';
		}

		/*
		 * A SEÇÃO É REARMADA QUANDO SAI DO CAMPO DE VISÃO, e é essa a mudança.
		 *
		 * Até aqui o bloco visto era `unobserve`d na primeira aparição: uma
		 * sessão registrava cada bloco UMA vez e nunca duas, e a pergunta "ele
		 * voltou e releu este bloco?" não tinha como ser respondida — o dado não
		 * existia. Agora o observador continua olhando, e a reentrada conta como
		 * nova ocorrência, exatamente como a travessia de marco já contava.
		 *
		 * O AGREGADO CONTINUA CONTANDO UMA VEZ POR CARREGAMENTO, e as duas
		 * leituras convivem: o total do painel responde "quantas visitas viram
		 * este bloco" e a tabela responde "quantas vezes cada uma o viu".
		 *
		 * E A CONTAGEM DA TABELA É DA VISITA. Quem vê o bloco, navega para outra
		 * página e volta continua de onde parou — a chave do contador inclui o
		 * CAMINHO, de modo que o mesmo nome de bloco em duas páginas são dois
		 * contadores. Até a 1.3.3 esse contador vivia no carregamento, e o
		 * visitante que ia e voltava era registrado três vezes como se fosse a
		 * primeira.
		 */
		/*
		 * TRÊS FAIXAS, E A BANDA ENTRE `saida` E `visivel` É A HISTERESE DA SEÇÃO.
		 *
		 * O `0` faz o navegador avisar quando o alvo entra e sai da tela por
		 * completo; `visivel` faz ele avisar em cada travessia da linha de
		 * ENTRADA; `saida` faz ele avisar na travessia da linha de SAÍDA — e sem
		 * essa terceira faixa a queda abaixo de `saida` chegaria tarde ou não
		 * chegaria, porque o navegador só avisa quem cruza uma linha declarada.
		 *
		 * ATÉ A 1.3.5 NÃO HAVIA SEGUNDO NÚMERO, e a decisão está registrada:
		 * a folga entre a razão zero e o `visivel` declarado era tratada como a
		 * histerese, e um limiar próprio seria um número que ninguém revisaria
		 * junto com o `visivel` que ele protege. O que mudou não foi o
		 * argumento — foi o LUGAR do número. Ele passou a morar na MESMA célula
		 * de limiar do `visivel`, no TSV, e quem revisa um lê o outro na mesma
		 * linha. É isso que separa esta banda do defeito da 1.3.3: lá a saída
		 * era a razão ZERO que a especificação de `isIntersecting` produzia de
		 * lambuja, não estava escrita em lugar nenhum e ninguém podia
		 * discordar dela; aqui ela é declarada, revisável e defendida por
		 * motivo escrito ao lado.
		 */
		observador = new window.IntersectionObserver(function (entradas) {
			var j;
			var secao;
			var razao;
			var vez;
			var qual;

			for (j = 0; j < entradas.length; j++) {
				secao = nomeDaSecao(entradas[j].target);
				qual = indiceDoAlvo(entradas[j].target);

				if ('' === secao || qual < 0) {
					continue;
				}

				/*
				 * A RAZÃO PODE NÃO VIR, e a ausência não pode virar saída.
				 * Entrada sintética — a de uma bancada, a de um polyfill —
				 * chega sem `intersectionRatio`. Tratar a ausência como zero
				 * rearmaria a seção a cada retorno e faria contar duas vezes
				 * quem hoje conta uma; por isso, sem a razão, quem responde é
				 * `isIntersecting`, exatamente como antes.
				 */
				razao = ('number' === typeof entradas[j].intersectionRatio && isFinite(entradas[j].intersectionRatio))
					? entradas[j].intersectionRatio
					: (entradas[j].isIntersecting ? visivel : 0);

				/*
				 * DUAS LINHAS DECLARADAS, E A BANDA ENTRE ELAS. Entra-se em
				 * `visivel`, rearma-se abaixo de `saida`, e entre as duas o estado
				 * não muda. Até a 1.3.3 a entrada e a saída usavam linhas
				 * diferentes SEM QUE UMA DELAS FOSSE DECLARADA: entrava-se quando a
				 * razão cruzava o limiar declarado para cima, e só se saía quando
				 * `isIntersecting` virava falso — e, com o `0` NA LISTA DE
				 * FAIXAS, isso é a razão ZERO.
				 *
				 * E AQUI ESTÁ O DETALHE QUE SÓ O NAVEGADOR ENSINA, medido em
				 * Chromium 1194 pela sonda de `suite/sonda-navegador/`:
				 * `isIntersecting` NÃO é "há sobreposição". Ele sai do ÍNDICE DE
				 * FAIXA — é verdadeiro quando a razão alcançou pelo menos a menor
				 * linha declarada. Com `threshold: 0.5` sozinho, a razão 0,2 chega
				 * com `isIntersecting: false`, apesar de 20% do bloco estar na
				 * tela. É por isso que o defeito depende do `0`: sem ele, decidir
				 * a saída por `isIntersecting` dá o MESMO resultado de decidir
				 * pela linha declarada; com ele, qualquer sobreposição mantém o
				 * bloco "dentro", a linha de saída vira a razão ZERO, e a seção só
				 * volta a contar se sair INTEIRA da tela — que é o que quase nunca
				 * acontece numa página rolada.
				 *
				 * Medido em produção em `wp_2zsugm_f3base_eventos`: 80 linhas,
				 * todas com `ocorrencia = 1`, nenhuma reentrada em nenhuma visita
				 * — o bloco era gravado uma vez só por carregamento.
				 *
				 * `isIntersecting === false` continua valendo como saída porque
				 * é assim que chega o alvo removido da árvore: razão zero, sem
				 * retorno de geometria.
				 */
				if (!entradas[j].isIntersecting || razao < saida) {
					dentroDaVista[qual] = false;

					continue;
				}

				/*
				 * DENTRO DA BANDA NADA MUDA DE ESTADO, e este ramo é a banda.
				 *
				 * A razão está acima da linha de saída e abaixo da de entrada: não
				 * é entrada, porque o bloco não alcançou `visivel`; e não é saída,
				 * porque ele não caiu abaixo de `saida`. Sem este `continue`, a
				 * banda seria só a linha de saída mais baixa — a razão de 0,3
				 * entraria como se fosse leitura, e a seção passaria a contar de
				 * uma faixa de borda que ninguém leu.
				 */
				if (razao < visivel) {
					continue;
				}

				if (dentroDaVista[qual]) {
					continue;
				}

				dentroDaVista[qual] = true;
				vez = contarTravessia(GATILHO, secao);

				if (vez > 0 && vez <= tetoPorSecao) {
					registrar(GATILHO, secao, 0, vez);
				} else {
					cortadasNaVisita = cortadasNaVisita + 1;
				}

				if (!vistas[secao]) {
					vistas[secao] = true;
					emitir(GATILHO, [ secao ]);
				}
			}
		}, { threshold: faixas });

		alvos = document.querySelectorAll('[class*="' + prefixo + '"]');

		for (i = 0; i < alvos.length; i++) {
			if ('' !== nomeDaSecao(alvos[i])) {
				observados.push(alvos[i]);
				dentroDaVista.push(false);
				observador.observe(alvos[i]);
			}
		}
	}

	/**
	 * CLIQUE EM LINK EXTERNO — o HOST de destino, e nunca a URL.
	 *
	 * A recusa é declarada e é a metade que importa: caminho e query são onde
	 * mora o identificador. `/perfil/joao-silva` no caminho; `?email=`,
	 * `?token=` ou `?id=` na query; e um `utm_content` que a campanha de outra
	 * pessoa preencheu com o id do lead. O host responde à pergunta que se faz
	 * — para onde o tráfego sai — sem carregar nada disso, e é a única parte da
	 * URL que não pode ser personalizada por visitante.
	 */
	function instrumentarLinksExternos() {
		var GATILHO = 'clique-externo';

		if (!declaracao(GATILHO)) {
			return;
		}

		document.addEventListener('click', function (evento) {
			var alvo = evento.target;
			var destino;

			while (alvo && alvo !== document.body) {
				if (alvo.nodeType === 1 && 'A' === alvo.tagName && alvo.getAttribute('href')) {
					break;
				}

				alvo = alvo.parentNode;
			}

			if (!alvo || alvo === document.body || 'A' !== alvo.tagName) {
				return;
			}

			destino = hostDe(alvo.getAttribute('href'));

			if ('' === destino || destino === window.location.hostname) {
				return;
			}

			emitir(GATILHO, [ destino ]);
		}, true);
	}

	/**
	 * FRICÇÃO — cliques repetidos no mesmo ponto, e o falso positivo recusado.
	 *
	 * O LIMIAR É DECLARADO e cada número dele tem motivo. Quatro cliques, e não
	 * dois nem três: duplo clique é gesto normal de sistema e triplo clique é o
	 * gesto normal de selecionar um parágrafo — um limiar em 2 ou 3 marcaria
	 * como frustração o uso comum de qualquer página de texto. Janela curta,
	 * porque um reclique deliberado segundos depois é nova tentativa, não
	 * raiva. Raio pequeno, porque o mesmo ponto precisa ser o mesmo ponto: sem
	 * ele, percorrer uma lista de links acumularia cliques de lugares
	 * diferentes. E alvo INTERATIVO, porque o gesto de seleção de texto pousa
	 * em texto e não em controle.
	 *
	 * A RECUSA DECLARADA: o outro sinal de fricção — clique em elemento NÃO
	 * interativo, o "dead click" — não é implementado aqui, e não por
	 * esquecimento. Numa página de texto, todo triplo clique para selecionar um
	 * parágrafo, todo duplo clique acidental num título e todo toque para
	 * fechar o teclado no celular pousam em elemento não interativo. Separar
	 * isso de frustração exigiria um modelo de intenção que este pacote não
	 * tem, e um falso positivo ali polui exatamente o relatório que a medição
	 * existe para produzir. Sinal que não se sabe medir sem falso positivo é
	 * recusa declarada, nunca implementação torta.
	 */
	function instrumentarFriccao() {
		var GATILHO = 'clique-repetido';
		/*
		 * AS TRÊS RESERVAS SÃO OS NÚMEROS DA DECLARAÇÃO, e valiam ZERO. Zero aqui
		 * não é conservador nem agressivo: é DESLIGADO — a guarda logo abaixo
		 * recusa `alvoCliques < 1`, e um TSV truncado apagava o coletor de
		 * fricção inteiro em silêncio, sem nada em lugar nenhum dizendo que
		 * aquele quadro tinha parado de ser alimentado. A regra desta base é
		 * reserva = declaração, e ela vale para os quatro limiares desta linha
		 * pelo mesmo motivo: o dia em que a reserva é usada é o dia em que o
		 * arquivo se corrompeu, e é exatamente quando os dois lados precisam
		 * continuar concordando.
		 */
		var alvoCliques = numeroDoLimiar(GATILHO, 'cliques', 4);
		var janela = numeroDoLimiar(GATILHO, 'janela_ms', 1200);
		var raio = numeroDoLimiar(GATILHO, 'raio_px', 24);
		var interativo = 'interativo' === String(limiar(GATILHO, 'alvo', [''])[0]);
		var ultimo = null;

		if (!declaracao(GATILHO) || alvoCliques < 1 || janela <= 0 || raio <= 0) {
			return;
		}

		function controle(elemento) {
			if (!elemento || typeof elemento.closest !== 'function') {
				return null;
			}

			return elemento.closest('a[href],button,input,select,textarea,summary,[role="button"],[role="link"],[tabindex]');
		}

		document.addEventListener('click', function (evento) {
			var alvo = interativo ? controle(evento.target) : evento.target;
			var agora = Date.now();
			var x = evento.clientX || 0;
			var y = evento.clientY || 0;

			if (!alvo) {
				ultimo = null;
				return;
			}

			if (
				ultimo &&
				ultimo.alvo === alvo &&
				(agora - ultimo.quando) <= janela &&
				Math.abs(x - ultimo.x) <= raio &&
				Math.abs(y - ultimo.y) <= raio
			) {
				ultimo.contagem += 1;
				ultimo.quando = agora;
			} else {
				ultimo = { alvo: alvo, x: x, y: y, quando: agora, contagem: 1 };
			}

			if (ultimo.contagem >= alvoCliques) {
				emitir(GATILHO, [ ultimo.contagem ]);
				ultimo = null;
			}
		}, true);
	}

	/**
	 * ORIGEM de um erro: `site`, `terceiro` ou `ambiente`.
	 *
	 * O vocabulário é o mesmo que o documento mestre exige das sondas, e a
	 * regra é a do arquivo que falhou. Sem arquivo, ou com esquema de extensão
	 * do navegador, ou com a mensagem opaca que o navegador entrega para script
	 * de outra origem sem CORS: `ambiente`, porque a falha é do que o visitante
	 * carregou junto com a página. Host diferente do da página: `terceiro`.
	 * Mesma origem: `site`.
	 */
	function origemDoErro(arquivo) {
		var texto = String(arquivo || '');
		var host;

		if ('' === texto || /^[a-z-]+-extension:/i.test(texto) || 0 === texto.indexOf('about:')) {
			return 'ambiente';
		}

		host = hostDe(texto);

		if ('' === host) {
			return 'ambiente';
		}

		return host === window.location.hostname ? 'site' : 'terceiro';
	}

	/**
	 * ERRO DE JAVASCRIPT DO PRÓPRIO SITE — e a origem é o PORTÃO, não parâmetro.
	 *
	 * Só o que classifica como `site` vira evento. Terceiro e ambiente ficam
	 * de fora, e é por isso que um bloqueador de anúncio não enche o relatório:
	 * ele quebra o script do fornecedor, não o nosso. Um parâmetro de origem
	 * seria peso morto — ele só poderia dizer `site`, e chave que nunca pode
	 * discordar do próprio dado é a mesma doença que a 1.1.2 tirou do regime de
	 * tracking.
	 *
	 * A MENSAGEM NÃO ENTRA, e essa é a recusa que protege o titular: ela
	 * carrega o valor interpolado que produziu o erro, e esse valor pode ser o
	 * e-mail digitado no formulário. O que entra é o caminho de mesma origem —
	 * sem query e sem fragmento, pelo mesmo motivo do link externo — e a linha.
	 *
	 * `unhandledrejection` NÃO é ouvido, e a recusa é declarada: promessa
	 * rejeitada não carrega arquivo nem linha em navegador nenhum, então a
	 * origem dela não é decidível — e evento cuja origem não é decidível é
	 * exatamente o que enche o relatório de erro que não é nosso.
	 */
	function instrumentarErros() {
		var GATILHO = 'erro';
		var vistos = {};

		if (!declaracao(GATILHO) || 'site' !== String(limiar(GATILHO, 'origem', [''])[0])) {
			return;
		}

		window.addEventListener('error', function (evento) {
			var arquivo = evento && evento.filename ? String(evento.filename) : '';
			var linha = evento && evento.lineno ? parseInt(evento.lineno, 10) : 0;
			var caminho;
			var chave;

			if ('site' !== origemDoErro(arquivo)) {
				return;
			}

			try {
				caminho = new window.URL(arquivo, window.location.href).pathname;
			} catch (erro) {
				return;
			}

			chave = caminho + ':' + linha;

			if (vistos[chave]) {
				return;
			}

			vistos[chave] = true;

			emitir(GATILHO, [ caminho.slice(0, 100), linha ]);
		});
	}

	/** A biblioteca oficial local calcula janelas de CLS e percentis de interação de INP.
	 * Cada callback atualiza a mesma amostra; valores ausentes não viram zero.
	 */
	function instrumentarVitais() {
		var GATILHO = 'desempenho';
		var vitais = limiar(GATILHO, 'vitais', []);
		var biblioteca = window.webVitals;
		var sequencias = {};
		var anteriores = {};
		var flushPendente = false;
		var dispositivo = window.matchMedia && window.matchMedia('(max-width: 767px)').matches ? 'movel' : 'desktop';
		if (!declaracao(GATILHO) || !biblioteca) { return; }
		function relatar(metrica) {
			if (vitais.indexOf(metrica.name) < 0 || !isFinite(metrica.value) || metrica.value < 0 || !/^[A-Za-z0-9_-]{8,80}$/.test(metrica.id)) { return; }
			if (anteriores[metrica.id] === metrica.value) { return; }
			var n = (sequencias[metrica.id] || 0) + 1;
			if (n > Number(dados.vitaisMaxAtualizacoes || 0)) { return; }
			var valores = [metrica.name, metrica.name === 'CLS' ? Math.round(metrica.value * 1000) / 1000 : Math.round(metrica.value)];
			var amostra = { id: metrica.id, dispositivo: dispositivo, sequencia: n };
			if (n === 1) {
				if (!emitir(GATILHO, valores, amostra)) { return; }
			} else {
				// Revisão local da mesma amostra: não repete eventos de terceiros.
				acumular(GATILHO, valores, amostra);
			}
			sequencias[metrica.id] = n;
			anteriores[metrica.id] = metrica.value;
			// Alguns observadores concluem depois do ouvinte de saída do resumo.
			if (document.visibilityState === 'hidden' && !flushPendente) {
				flushPendente = true;
				var agendarFlush = window.queueMicrotask || function (fn) { Promise.resolve().then(fn); };
				agendarFlush(function () { flushPendente = false; if (linhasDoResumo > 0 || registroDaSessao.length > 0) { enviarResumo(); } });
			}
		}
		vitais.forEach(function (nome) {
			var coletor = biblioteca['on' + nome];
			if (typeof coletor === 'function') {
				try { coletor(relatar, nome === 'INP' ? { durationThreshold: numeroDoLimiar(GATILHO, 'duracao_minima_ms', 16) } : {}); } catch (erro) { /* Métrica indisponível neste navegador. */ }
			}
		});
	}

	/**
	 * Instala os coletores, uma vez, DEPOIS do portão.
	 */
	function instrumentar() {
		if (instrumentado) {
			return;
		}

		instrumentado = true;

		instrumentarPaginaVista();
		instrumentarRolagem();
		instrumentarSecoes();
		instrumentarLinksExternos();
		instrumentarFriccao();
		instrumentarErros();
		instrumentarVitais();
		instrumentarResumo();
	}

	/**
	 * O ENVIO DO RESUMO, e ele é o ÚLTIMO ouvinte instalado de propósito.
	 *
	 * Os vitais são relatados no primeiro ocultamento da página, e o relato
	 * deles PASSA por `emitir()` — que é onde o resumo soma. Um ouvinte
	 * instalado antes do deles despacharia a sessão sem LCP, CLS, INP e TTFB,
	 * e o quadro da tela mostraria "sem amostra" para as quatro métricas que
	 * mais interessam, para sempre e sem erro nenhum.
	 */
	function instrumentarResumo() {
		if (!RESUMO.ativo) {
			return;
		}

		document.addEventListener('visibilitychange', function () {
			if ('hidden' === document.visibilityState) {
				enviarResumo();
			}
		});

		window.addEventListener('pagehide', enviarResumo);
	}

	/**
	 * LIGA O RESUMO DO PRÓPRIO SITE: apelido, visita, fila pendente e retentativa.
	 *
	 * FUNÇÃO SEPARADA, e a separação é o que faz o RE-ACEITE religar o registro
	 * na mesma navegação. O defeito: quem chegava com a medição permitida tinha
	 * `carregado` levantado; se recusasse no controle do rodapé e mudasse de
	 * ideia em seguida, `carregar()` saía na primeira linha — as tags continuavam
	 * lá, porque nunca foram removidas, e o apelido e a visita não voltavam a
	 * existir. A partir dali, a página inteira era medida no agregado e nada
	 * entrava no registro.
	 *
	 * ELA NÃO REFAZ O QUE JÁ ESTÁ FEITO. Com a visita já ligada, sair aqui é o
	 * certo: reiniciá-la sortearia uma visita nova sobre uma que está em curso e
	 * jogaria fora a fila pendente dela.
	 *
	 * E ELA NÃO TOCA NAS TAGS. Religar o carregador inteiro empurraria `gtm.js` e
	 * `config` uma segunda vez no mesmo carregamento, e o fornecedor contaria dois
	 * page_view onde houve um.
	 *
	 * @return {void}
	 */
	function iniciarResumo() {
		var visita;

		/*
		 * OS APELIDOS NASCEM DEPOIS DO PORTÃO DO CONSENTIMENTO, e essa ordem é
		 * a garantia inteira: quem recusou não tem apelido sorteado, não tem
		 * nada gravado no navegador e não tem linha nenhuma no servidor. Nascer
		 * antes seria criar o identificador de alguém que disse não.
		 */
		if (!RESUMO.ativo) {
			return;
		}

		/*
		 * A VISITA JÁ EM CURSO NÃO É REINICIADA — sortear outra por cima dela
		 * jogaria fora a fila pendente e recomeçaria o contador de travessias no
		 * meio da navegação. O que pode ter faltado é só o APELIDO: quem recusou e
		 * mudou de ideia na mesma página teve o apelido apagado pela recusa, e é
		 * este ramo que faz o aceite religar o registro sem mexer em mais nada.
		 */
		if ('' !== sessao) {
			if ('' === visitante) {
				visitante = apelidoDoVisitante();
			}

			return;
		}

		visitante = apelidoDoVisitante();

		visita = visitaCorrente();

		sessao = visita.id;
		gastasNaVisita = visita.gastas;

		/*
		 * O CONTADOR CHEGA DE ONDE PAROU, e o estado ARMADO não chega de
		 * lugar nenhum: os coletores nascem com `dentro` e `dentroDaVista`
		 * vazios em `instrumentar()`. É esta assimetria que faz a primeira
		 * passagem DESTE carregamento ser registrada — com a vez certa, que é a
		 * da visita.
		 */
		travessiasDaVisita = visita.travessias;
		chavesDeTravessia = Object.keys(travessiasDaVisita).length;
		cortadasNaVisita = visita.cortadas;

		/*
		 * O PENDENTE CHEGA DE ONDE PAROU, e é ele que fecha o buraco.
		 * Um carregamento que morreu entre contar e enviar deixou o lote
		 * gravado aqui; este carregamento o encontra inteiro, com o mesmo
		 * selo, e o despacha ANTES de qualquer coisa que ele mesmo produza.
		 */
		pendentes = visita.pendentes;

		apararFila();
		serializarFila();

		/*
		 * O ACUMULADO HERDADO É SELADO AQUI, e não continuado. Ele pertence
		 * ao caminho da página que morreu, e o carregamento corrente pode
		 * ser de outra: continuá-lo faria linhas de `/` serem gravadas como
		 * se tivessem acontecido em `/arquitetura/`, sem erro nenhum. Selado
		 * com o caminho dele, ele entra na fila como qualquer outro lote e
		 * esta página começa com o acumulado vazio.
		 */
		if (visita.acumulado) {
			selar(visita.acumulado.caminho, visita.acumulado.metricas, visita.acumulado.eventos);
		}

		guardarVisita();

		/*
		 * A RETENTATIVA ACONTECE NA CARGA, e não no próximo ocultamento.
		 * Esperar pelo ocultamento faria a recuperação depender de o
		 * visitante produzir mais uma saída de página — e o carregamento
		 * que acabou de morrer é justamente a prova de que a saída é o que
		 * não se pode contar. Sem pendente, isto não produz requisição
		 * nenhuma: a fila vazia não despacha.
		 */
		despacharPendentes();
	}

	function carregar() {
		/*
		 * A EXCLUSÃO PENDENTE É REENVIADA ANTES DE QUALQUER PORTÃO, e por isso
		 * ela está aqui em cima: o pedido é do VISITANTE, e ele não depende de a
		 * medição estar permitida — depende do contrário. Um pedido que não
		 * chegou fica gravado e parte de novo a cada carregamento, até o servidor
		 * confirmar; sem isto, a exclusão que falhou uma vez falhou para sempre.
		 */
		if ('' !== exclusaoPendente()) {
			pedirExclusao(exclusaoPendente());
		}

		/*
		 * O PORTÃO NEGADO NÃO APAGA NADA AQUI, e a ausência é a regra. Chegar com
		 * a medição negada não é pedir exclusão: o portão fecha por cookie
		 * vencido, por política trocada por quem opera o site e por recusa dada
		 * noutra aba, e nenhuma dessas três coisas é uma pessoa pedindo para
		 * apagar o registro dela. Quem apaga é a RECUSA no controle do rodapé,
		 * pelo ouvinte do evento de consentimento, e ela apaga dos dois lados.
		 */

		/*
		 * O SLOT VAZIO É INERTE TAMBÉM AQUI, e a redundância é deliberada — a
		 * mesma razão pela qual `permiteTags()` é reconferido no navegador. O
		 * servidor já não enfileira este arquivo com o caminho `nenhum`, mas a
		 * instrumentação de comportamento não depende de ID nenhum para
		 * funcionar: sem esta guarda, um dia em que o arquivo chegasse à página
		 * por outro caminho — cache, concatenador, um plugin que enfileira
		 * assets de terceiro — o site passaria a emitir comportamento sem ter
		 * uma conta de medição para recebê-lo. A regra é a mesma das tags:
		 * slot vazio, nada acontece.
		 */
		if (carregado || !permiteTags()) {
			return;
		}

		/*
		 * SEM DESTINO NENHUM, TUDO CONTINUA INERTE. A guarda da 1.1.3 valia
		 * quando o único destino era a conta de medição: com o slot vazio, o
		 * site emitiria comportamento sem ninguém para recebê-lo. Na 1.1.4 o
		 * próprio site é um destino, com tabela e prazo — então a pergunta
		 * deixou de ser "há ID?" e passou a ser "há destino?". Sem os dois,
		 * nada é instalado e nada é emitido, exatamente como antes.
		 */
		if (CAMINHO === 'nenhum' && !RESUMO.ativo) {
			return;
		}

		carregado = true;

		iniciarResumo();

		/*
		 * A INSTRUMENTAÇÃO ENTRA ANTES DA BIFURCAÇÃO, e de propósito: o
		 * caminho do container termina em `return`, e instalá-la depois dele
		 * deixaria todo site com GTM sem medição de comportamento — um ramo
		 * esquecido que nada acusaria, porque a página continuaria emitindo as
		 * tags normalmente.
		 */
		instrumentar();

		if (CAMINHO === 'gtm') {
			carregarGtm();
			return;
		}

		if (CAMINHO === 'direto') {
			carregarGoogleDireto();
			carregarMeta();
			carregarLinkedin();
		}
	}

	/*
	 * O re-aceite religa NESTA navegação. Sem este ouvinte, quem negava, mudava
	 * de ideia no controle do rodapé e ficava na mesma página não era medido até
	 * navegar — e a decisão que o visitante acabou de tomar é a que vale.
	 */
	document.addEventListener('f3base-consentimento', function () {
		/*
		 * A RECUSA APAGA. Quem muda de ideia no controle do rodapé tem o
		 * apelido removido do navegador E o registro removido do servidor, na
		 * mesma ação — sem esse segundo passo, "apagável" seria uma palavra na
		 * política e um dado que continua lá.
		 */
		if (!permiteTags()) {
			esquecerVisitante();

			return;
		}

		/*
		 * O RE-ACEITE RELIGA O REGISTRO, e não só as tags. Com o carregador já
		 * rodado, `carregar()` sai na primeira linha — e era ali que o registro
		 * ficava desligado pelo resto da navegação, com a página continuando a
		 * somar no agregado como se nada tivesse acontecido.
		 */
		if (carregado) {
			iniciarResumo();

			return;
		}

		carregar();
	});

	window.f3baseTracking = {
		caminho: function () {
			return CAMINHO;
		},
		carregar: carregar,
		permiteTags: permiteTags,
		eventos: function () {
			return EVENTOS;
		},
		emitidos: function () {
			return emitidos;
		},
		resumo: function () {
			return resumoDaSessao;
		}
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', carregar);
	} else {
		carregar();
	}
}(window, document));
