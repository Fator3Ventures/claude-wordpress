# Base Site Core Fator3 1.6.0

Esta versão aplica as seis melhorias de funcionamento da revisão e as duas mudanças adicionais solicitadas. Preserva as configurações existentes e acrescenta o controle explícito do WhatsApp flutuante.

## Alterações

- **Procedência confiável:** `F3Base_Options::gravar()` só altera a origem depois de confirmar a persistência. Recusas ficam em um registro separado, limitado a 100 entradas, sem os valores enviados. A aba Informações técnicas mostra esse registro.
- **WhatsApp optativo:** o campo “Ativar WhatsApp flutuante” nasce desligado. Ligado, com número válido, publica um ícone fixo no canto inferior direito das páginas públicas. O link tem nome acessível, foco visível, área de toque e funciona sem JavaScript. O plugin deixa de promover ou suprimir botões do tema; menus e botões já definidos pelo layout continuam sob responsabilidade do tema.
- **Web Vitals:** biblioteca local, sem CDN, com métricas por carregamento e revisões ordenadas. A tabela mostra percentil 75 e quantidade de amostras, com filtros por caminho e tela móvel/desktop. A classificação de tela usa largura, não identifica o aparelho. As médias do coletor anterior ficam identificadas separadamente, porque não permitem reconstruir percentis.
- **Conversões Meta:** fila persistente com reserva atômica, espera progressiva, até 6 tentativas e expiração. Falhas temporárias e de rede preservam a conversão; confirmação e encerramento removem o payload. O mesmo identificador e horário do evento original são mantidos. O token não integra o payload armazenado. Estados aparecem na aba técnica.
- **Configuração nativa pelo MCP:** `f3base/config-core-ler` e `f3base/config-core-escrever` independem do implantador. Oferecem schema, simulação por padrão e escrita condicional por revisão. Exigem permissão administrativa; segredos são mascarados na resposta. Aplique com `simular=false`, enviando a revisão lida e o valor completo da option.
- **Acessos de hoje:** leitura incremental do trecho acrescentado, fotografia temporária, detecção de rotação/truncamento e aviso de bytes pendentes. Cada atualização lê até 8 MiB, dentro do limite de tempo. Linhas incompletas aguardam conclusão. O histórico e a coleta diária continuam usando apenas logs datados encerrados.
- **llms e caminhos publicados:** cache invalidado por alterações de conteúdo, visibilidade, metadados e configuração. `llms.txt` continua sendo o índice e `llms-full.txt` mantém o conteúdo integral selecionado. Ambos exigem revalidação HTTP e usam ETag/304. A visibilidade é conferida antes de servir conteúdo do cache.
- **Navegador obrigatório:** ausência do Chromium bloqueia a validação da entrega.

## Correção local da biblioteca de métricas

A distribuição parte de web-vitals 6.2.1 e inclui um patch pequeno de CLS. O teste entrega, no mesmo lote, duas janelas com valores 0,5 e 0,4. O original retorna 0,4; o patch preserva o máximo esperado de 0,5. Entradas com interação recente continuam excluídas. Um segundo vetor verifica INP com 50 interações e descarte da maior duração.

O pacote de fontes contém o código original, a licença Apache, a proveniência com hashes, `cls-janelas.patch` e `build.cjs`. O build usa esbuild 0.25.12. A dependência não é baixada em tempo de execução no site.

Referências: [biblioteca web-vitals](https://github.com/GoogleChrome/web-vitals), [definição de CLS](https://web.dev/articles/cls), [definição de INP](https://web.dev/articles/inp), [proposta llms.txt](https://llmstxt.org/).

## Validação e reprodução

A suíte usa WordPress real com SQLite e PHP, além de Chromium. Os casos novos verificam falha de filtro e de SQL, procedência, schemas, permissões, preview, concorrência entre leitura e escrita, retentativas CAPI, leases, expiração, leitura incremental, ETag, retirada de conteúdo privado, percentis, retransmissão REST e WhatsApp em desktop/móvel.

```bash
# PHP e Node no PATH; Playwright instalado; Chromium disponível.
export F3BASE_CHROMIUM=/caminho/do/chromium
export F3BASE_BANCADA_CACHE=/caminho/do/cache-wordpress
bash suite/verificar.sh "$PWD"
bash suite/bancada-wp/piso-160.sh "$PWD"
```

Os resultados ficam em `suite/rodada.json` e nas evidências da entrega. O pacote completo inclui o instalador, os fontes comentados, a suíte, as referências da biblioteca e o histórico Git em bundle.

A rodada final terminou com **167 checagens OK, nenhuma FALHA e nenhum BLOCKED**. As 12 checagens N/A são condições específicas do site implantado e estão nominadas no registro; não equivalem a aprovação de integrações externas. Os cinco testes novos com reintrodução proposital de defeitos detectaram as cinco regressões.

A versão 1.6.0 foi instalada e ativada no WordPress fator3-teste. A conferência por MCP confirmou a versão, os hashes de três arquivos, a leitura nativa da configuração e a simulação sem alteração da revisão. O WhatsApp flutuante permaneceu desativado. A ferramenta de consulta pública não abriu as URLs desse host; a verificação visual foi realizada no WordPress local com Chromium, em páginas inicial e interna, nas larguras de celular e desktop. A evidência remota registra esse limite.

## Uso após atualização

Em Configurações, preencha o número internacional e marque **Ativar WhatsApp flutuante** se desejar o ícone. Salve a configuração. Não é necessário reativar o plugin para essa mudança.

A execução dos jobs continua sujeita ao WP-Cron: sites sem tráfego podem atrasar tarefas; quando o WP-Cron estiver desativado, o agendador do servidor precisa acioná-lo. O painel mostra estados e perdas declaradas; a fila não garante entrega caso as credenciais, o fornecedor ou o servidor permaneçam indisponíveis até a expiração.

Cache de página externo pode exigir limpeza após mudar a opção do ícone. Integrações que alteram conteúdo diretamente no banco, fora dos hooks do WordPress, devem invalidar o cache público do Core. A medição continua respeitando consentimento, retenção e orçamento.

A validação de CAPI usa respostas sintéticas controladas, sem conversões enviadas à Meta. O ambiente automatizado utiliza SQLite; a conferência no WordPress conectado complementa essa cobertura no ambiente de teste.
