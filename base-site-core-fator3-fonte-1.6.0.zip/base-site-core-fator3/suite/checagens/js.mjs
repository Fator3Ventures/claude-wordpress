/**
 * Sonda de JavaScript. Roda sob o Node de verdade e devolve JSON.
 *
 * Dois modos:
 *
 * - `lint <raiz>`: `node --check` em todo `.js`/`.mjs` da raiz. Analisar
 *   JavaScript com expressão regular de PHP seria inferência disfarçada de
 *   medição; quem analisa é o próprio motor.
 * - `extrator <raiz>`: exercita as funções PURAS de
 *   `includes/assets/implantador.js` — as mesmas do arquivo servido, extraídas
 *   dele em tempo de execução, nunca copiadas. A armadilha medida é que a
 *   resposta real de um erro fatal é "HTML + JSON": a página de erro do
 *   WordPress já saiu quando o `shutdown` roda, e o objeto está no FIM do corpo.
 *
 * Esta sonda nunca imprime estado nem conta: quem imprime e conta é `estado()`,
 * no PHP, em um lugar só.
 */

import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative, extname } from 'node:path';
import { execFileSync } from 'node:child_process';

const EXCLUIDOS = [ 'suite/fixtures/', 'dist/' ];

function arquivos( raiz, extensoes ) {
	const saida = [];

	function andar( dir ) {
		let itens;

		try {
			itens = readdirSync( dir );
		} catch {
			return;
		}

		for ( const item of itens.sort() ) {
			const caminho = join( dir, item );
			const rel = relative( raiz, caminho ).split( '\\' ).join( '/' );

			if ( EXCLUIDOS.some( ( p ) => rel.startsWith( p ) ) ) {
				continue;
			}

			const st = statSync( caminho );

			if ( st.isDirectory() ) {
				andar( caminho );
				continue;
			}

			if ( extensoes.includes( extname( item ).toLowerCase() ) ) {
				saida.push( rel );
			}
		}
	}

	andar( raiz );

	return saida.sort();
}

/**
 * O ARQUIVO ENTREGUE, e é contra ele que as bancadas de COMPORTAMENTO rodam.
 *
 * A partir da 1.3.6 o zip do plugin leva os `.js` de `assets/` sem comentário —
 * dois terços do peso de `f3base-tracking.js` eram comentário, e são vinte e
 * dois quilobytes comprimidos que o visitante baixava a cada carregamento. O
 * corte é feito no empacotamento, por tokenizador, e a cópia do que entrou no
 * zip fica em `dist/entregue/`.
 *
 * A CONSEQUÊNCIA PARA ESTA SONDA É A REGRA INTEIRA: um corte que corrompesse o
 * cliente e ninguém medisse é pior do que os vinte e dois quilobytes. Por isso
 * a checagem de FORMA — comentário, declaração, lint da árvore — continua
 * olhando a FONTE, que é onde a forma mora; e a checagem de COMPORTAMENTO passa
 * a olhar o ENTREGUE, que é o que o navegador executa.
 *
 * Sem a cópia entregue — uma rodada de piso contra uma fixture, um clone que
 * ainda não empacotou — ela cai na fonte. Cair na fonte não é silêncio: quem
 * cobra a existência do entregue é `pacote.js_entregue_sem_comentario`, e ela
 * fecha achado quando o arquivo não está lá.
 *
 * @param {string} raiz Raiz do pacote.
 * @param {string} rel  Caminho relativo à raiz, na FONTE.
 * @return {string} Caminho do arquivo a exercitar.
 */
function entregue( raiz, rel ) {
	const noPlugin = rel.replace( /^fontes\/site-core\//, '' );
	const servido = join( raiz, 'dist/entregue/base-site-core-fator3', noPlugin );

	try {
		statSync( servido );

		return servido;
	} catch {
		return join( raiz, rel );
	}
}

function lint( raiz ) {
	const achados = [];
	const alvos = arquivos( raiz, [ '.js', '.mjs' ] );

	for ( const rel of alvos ) {
		try {
			execFileSync( process.execPath, [ '--check', join( raiz, rel ) ], { stdio: [ 'ignore', 'ignore', 'pipe' ] } );
		} catch ( e ) {
			const detalhe = String( e.stderr || e.message ).split( '\n' ).filter( Boolean ).slice( 0, 3 ).join( ' | ' );
			achados.push( rel + ': ' + detalhe );
		}
	}

	return { achados, medidas: alvos.length };
}

/**
 * Extrai UMA função pura do arquivo real, pelo contrato de fatiamento.
 *
 * O contrato é o mesmo do extrator: a função mora a um nível de indentação e é
 * seguida por um bloco `/**`. Copiar o corpo para dentro desta sonda provaria
 * que a cópia funciona, não que o cliente funciona.
 */
function fatiar( fonte, nome ) {
	const inicio = fonte.indexOf( '\tfunction ' + nome + '(' );

	if ( inicio < 0 ) {
		return null;
	}

	/*
	 * O FIM DA FUNÇÃO É O FECHAMENTO NA INDENTAÇÃO DELA, e não o docblock
	 * seguinte. Até a 1.3.5 o corte ia de `\tfunction nome(` até o próximo
	 * `\t/**`, e isso amarrava a EXTRAÇÃO a um COMENTÁRIO. A partir da 1.3.6 o
	 * arquivo que estas bancadas exercitam é o ENTREGUE, que não tem comentário
	 * nenhum: o corte ia até o fim do arquivo e a função não avaliava. Um
	 * contrato de extração que depende de comentário não sobrevive a um pacote
	 * que entrega sem eles — e a chave é a indentação, que o corte de
	 * comentários preserva byte a byte, de propósito.
	 */
	const fim = fonte.indexOf( '\n\t}\n', inicio );

	return fonte.slice( inicio, fim < 0 ? fonte.length : fim + 4 );
}

/**
 * O CORTE DO CLIENTE DE LEADS, na unidade que o servidor publica.
 *
 * Alimenta a checagem `js.limite_do_cliente`, cujo piso mora AQUI: o caso
 * negativo é um mutante do próprio cliente — o corte por unidade UTF-16 —, e
 * não uma árvore de arquivos. Declarada em `suite/pisos-em-sonda.tsv`.
 *
 * O defeito medido na 1.0.17: o servidor contava BYTES (`strlen`) e o cliente
 * contava unidades UTF-16 (`texto.length`), com o MESMO número publicado por
 * `limites_publicos()`. Em português, com acentuação, o navegador aprovava e o
 * servidor devolvia 400 — e a recusa é dura, nunca truncamento em silêncio.
 * Os dois lados agora contam CARACTERES, e é isso que esta sonda mede.
 */
function limiteDoCliente( raiz ) {
	const alvo = entregue( raiz, 'fontes/plugin/assets/f3base-leads.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'fontes/plugin/assets/f3base-leads.js ausente na raiz varrida' ] };
	}

	const nomes = [ 'caracteres', 'limitar' ];
	const pedacos = [];

	for ( const nome of nomes ) {
		const corpo = fatiar( fonte, nome );

		if ( ! corpo ) {
			return { achados: [ 'a função pura ' + nome + '() não foi encontrada no arquivo real (contrato de extração quebrado)' ] };
		}

		pedacos.push( corpo );
	}

	let api;

	try {
		api = new Function( 'LIMITES', pedacos.join( '\n' ) + '\nreturn { ' + nomes.join( ', ' ) + ' };' )( { nome: 120, mensagem: 2000 } );
	} catch ( e ) {
		return { achados: [ 'as funções puras não avaliaram: ' + String( e.message ) ] };
	}

	function afirmar( ok, nome ) {
		if ( ! ok ) {
			achados.push( nome );
		}
	}

	/* Um nome de 120 CARACTERES acentuados: o caso que o servidor recusava. */
	const acentuado = 'ção'.repeat( 40 );

	/* PISO: a sonda reproduz o defeito? Em bytes o mesmo texto EXCEDE o limite. */
	afirmar(
		Buffer.byteLength( acentuado, 'utf8' ) > 120,
		'piso: o texto acentuado no limite não excede 120 bytes, e sem isso a divergência de unidade não é reproduzível aqui'
	);

	afirmar(
		api.caracteres( acentuado ).length === 120,
		'piso: o texto de bancada não tem 120 caracteres — ele tem ' + String( api.caracteres( acentuado ).length )
	);

	/* TETO: o cliente NÃO corta o que o servidor aceita. */
	afirmar(
		api.limitar( 'nome', acentuado ) === acentuado,
		'teto: o cliente CORTOU um nome de 120 caracteres que o servidor aceita — corte de um lado e recusa do outro, com o mesmo número publicado'
	);

	/* PISO da regra: um caractere acima do limite ainda é cortado, em caracteres. */
	afirmar(
		api.caracteres( api.limitar( 'nome', acentuado + 'ç' ) ).length === 120,
		'piso: o corte de 121 caracteres não devolveu 120 caracteres — o corte é por caractere, e nunca por unidade UTF-16'
	);

	/*
	 * PISO do par substituto: cortar por unidade UTF-16 no meio de um emoji
	 * devolveria metade de um caractere, e o servidor receberia texto que
	 * ninguém escreveu.
	 */
	const comEmoji = 'a'.repeat( 119 ) + '🙂';

	afirmar(
		comEmoji.length === 121 && api.caracteres( comEmoji ).length === 120,
		'piso do par substituto: o texto de bancada não tem 121 unidades UTF-16 e 120 caracteres, e sem isso a diferença entre as unidades não é reproduzível'
	);

	afirmar(
		api.limitar( 'nome', comEmoji ) === comEmoji,
		'teto do par substituto: o cliente cortou um texto de 120 caracteres porque ele tem 121 unidades UTF-16'
	);

	afirmar(
		! api.limitar( 'nome', comEmoji + 'b' ).includes( '\uFFFD' ) && api.caracteres( api.limitar( 'nome', comEmoji + 'b' ) ).length === 120,
		'piso do par substituto: o corte partiu um caractere ao meio'
	);

	/* Campo sem limite publicado sai intacto: limite ausente não é limite zero. */
	afirmar(
		api.limitar( 'inexistente', acentuado ) === acentuado,
		'piso do limite ausente: campo sem limite publicado foi cortado — limite ausente não é limite zero'
	);

	return { achados };
}

/**
 * BANCADA DO CLIQUE: o `f3base-leads.js` REAL, rodado de ponta a ponta.
 *
 * Não é recorte nem cópia: o arquivo servido é avaliado inteiro contra um DOM de
 * mentira — o mínimo que ele toca —, e o clique é disparado no ouvinte que ele
 * mesmo registrou. O que sai daqui é o que o navegador teria feito: o `href` que
 * ficou no link, o corpo que foi para o beacon e as chamadas que cada canal
 * recebeu.
 *
 * @param {string} fonte  Código do cliente, como ele viaja no pacote.
 * @param {Object} dados  O objeto que o servidor localiza na página.
 * @param {string} href   O `href` que o link tem quando o clique acontece.
 * @return {Object} O estado depois do clique.
 */
function bancadaDoClique( fonte, dados, href, extras ) {
	const opcoesDoClique = extras || {};
	const ouvintes = {};
	const chamadas = { gtag: [], fbq: [], lintrk: [], beacon: [], fetch: [], hash: [] };
	let sementeDoClique = 0;

	const gatilho = {
		nodeType: 1,
		attrs: Object.assign({ 'data-f3base-lead': 'cta', href }, opcoesDoClique.numeroExplicito ? { 'data-f3base-numero': opcoesDoClique.numeroExplicito } : {}),
		getAttribute( nome ) {
			return Object.prototype.hasOwnProperty.call( this.attrs, nome ) ? this.attrs[ nome ] : null;
		},
		setAttribute( nome, valor ) {
			this.attrs[ nome ] = String( valor );
		},
		matches() {
			return true;
		},
		closest() {
			return null;
		},
		querySelector() {
			return null;
		}
	};

	const doc = {
		readyState: 'complete',
		cookie: '',
		referrer: '',
		body: {},
		addEventListener( tipo, fn ) {
			( ouvintes[ tipo ] = ouvintes[ tipo ] || [] ).push( fn );
		},
		querySelectorAll() {
			return [];
		},
		querySelector() {
			return null;
		},
		dispatchEvent() {
			return true;
		}
	};

	/*
	 * O FORMULÁRIO ASSOCIADO, quando o caso o pede. O template desta base não
	 * tem formulário — e é por isso que o ramo das Enhanced Conversions nasceu
	 * sem uso —, mas o projeto que acrescentar um passa a mandar e-mail e
	 * telefone por aqui, e é esse o payload cujo portão se quer medir.
	 */
	if ( opcoesDoClique.campos ) {
		gatilho.attrs[ 'data-f3base-form' ] = '#formulario-de-bancada';

		doc.querySelector = function () {
			return {
				querySelector( seletor ) {
					const achado = /\[(?:data-f3base-campo|name)="([^"]+)"\]/.exec( seletor );
					const campo = achado ? achado[ 1 ] : '';

					return Object.prototype.hasOwnProperty.call( opcoesDoClique.campos, campo )
						? { value: String( opcoesDoClique.campos[ campo ] ) }
						: null;
				}
			};
		};
	}

	const win = {
		f3baseLeadsDados: dados,
		dataLayer: [],
		location: {
			search: '?utm_source=google&gclid=BANCADA_GCLID&fbclid=BANCADA_FBCLID&li_fat_id=BANCADA_LI',
			pathname: '/lp/',
			origin: 'https://exemplo.test',
			protocol: 'https:'
		},
		crypto: {
			/*
			 * BYTES QUE MUDAM A CADA CHAMADA. Enquanto eles eram `i + 1` fixos,
			 * TODA correlação nascia com o mesmo valor: a bancada não conseguia
			 * distinguir "reaproveitou a chave" de "gerou outra igual", e a
			 * janela da correlação era inmensurável aqui.
			 */
			getRandomValues( bytes ) {
				for ( let i = 0; i < bytes.length; i++ ) {
					bytes[ i ] = ( i + 1 + sementeDoClique ) % 256;
				}

				sementeDoClique++;

				return bytes;
			},
			/*
			 * O ESPIÃO DO HASH registra a CHAMADA, que acontece de forma
			 * síncrona — a promessa que ela devolve é outra história. É por ele
			 * que se mede se o `user_data` das Enhanced Conversions chegou a ser
			 * PREPARADO: o portão do consentimento tem de decidir antes de o
			 * e-mail e o telefone do visitante virarem hash a caminho do Google.
			 */
			subtle: {
				digest( algoritmo, bytes ) {
					chamadas.hash.push( { algoritmo: String( algoritmo ), bytes: bytes.length } );

					return Promise.resolve( new Uint8Array( 32 ).buffer );
				}
			}
		},
		localStorage: {
			guardado: {},
			getItem( chave ) {
				return Object.prototype.hasOwnProperty.call( this.guardado, chave ) ? this.guardado[ chave ] : null;
			},
			setItem( chave, valor ) {
				this.guardado[ chave ] = String( valor );
			},
			removeItem( chave ) {
				delete this.guardado[ chave ];
			}
		},
		gtag( ...args ) {
			chamadas.gtag.push( args );
		},
		fbq( ...args ) {
			chamadas.fbq.push( args );
		},
		lintrk( ...args ) {
			chamadas.lintrk.push( args );
		},
		addEventListener() {}
	};

	/*
	 * O OBJETO DO CONSENTIMENTO SÓ EXISTE QUANDO O CASO O PEDE, e a ausência é
	 * um caso medido: sem ele o cliente cai na decisão de reserva do servidor,
	 * que é a mesma semântica de `f3base-tracking.js`. Com ele, o caso da
	 * NEGATIVA TARDIA — aceitou, as tags carregaram, recusou depois.
	 */
	if ( undefined !== opcoesDoClique.consentimento ) {
		win.f3baseConsentimento = {
			permiteTags: () => ( false !== opcoesDoClique.consentimento )
		};
	}

	/*
	 * O STUB DO CONSENT MODE COMO `gtag`, que é o que existe numa página real.
	 * `f3base-consentimento.js` define `window.gtag` empurrando os próprios
	 * argumentos no `dataLayer` — é por isso que `typeof gtag === 'function'` é
	 * verdadeiro em TODA página, com ou sem `gtag.js`, e é por isso que um
	 * `gtag('event', …)` é OUTRO push. Sem este modo, um espião que só registra
	 * a chamada esconderia o segundo push do mesmo evento.
	 */
	if ( opcoesDoClique.gtagStub ) {
		win.gtag = function ( ...args ) {
			chamadas.gtag.push( args );
			win.dataLayer.push( args );
		};
	}

	const nav = {
		sendBeacon( url, corpo ) {
			/*
			 * O NAVEGADOR RECUSA A FILA quando o corpo passa do orçamento ou a
			 * fila está cheia, e `sendBeacon` devolve FALSO. É o caso em que o
			 * registro precisa cair no `fetch` com `keepalive`.
			 */
			if ( opcoesDoClique.beaconRecusa ) {
				return false;
			}

			chamadas.beacon.push( { url, corpo: corpo && corpo.partes ? String( corpo.partes[ 0 ] ) : '' } );
			return true;
		}
	};

	/*
	 * O `fetch` DE MENTIRA: registra o que foi pedido e responde na ordem
	 * declarada pelo caso. É ele que torna mensurável o 403 do token vencido —
	 * o pedido do token novo e o REENVIO, uma vez só.
	 */
	if ( opcoesDoClique.respostas ) {
		const fila = opcoesDoClique.respostas.slice();

		win.fetch = function ( url, opcoes ) {
			const proxima = fila.length ? fila.shift() : { status: 200 };

			chamadas.fetch.push( { url: String( url ), opcoes: opcoes || {}, status: proxima.status } );

			return Promise.resolve( {
				status: proxima.status,
				ok: proxima.status >= 200 && proxima.status < 300,
				json: () => Promise.resolve( proxima.corpo || {} )
			} );
		};
	}

	function BlobDeBancada( partes ) {
		this.partes = partes;
	}

	/*
	 * O ESTADO QUE O NAVEGADOR JÁ TINHA quando o cliente carregou. É ele que
	 * torna mensurável a diferença entre "a recusa impede o que vem depois" e
	 * "a recusa apaga o que já estava lá" — que são duas coisas, e só a segunda
	 * é o que o titular pediu ao desligar a medição.
	 */
	if ( 'function' === typeof opcoesDoClique.antes ) {
		opcoesDoClique.antes( win, doc );
	}

	// eslint-disable-next-line no-new-func
	new Function( 'window', 'document', 'navigator', 'Blob', fonte )( win, doc, nav, BlobDeBancada );

	function clicar() {
		for ( const ouvinte of ouvintes.click || [] ) {
			ouvinte( { target: gatilho } );
		}
	}

	clicar();

	/*
	 * `clicar` volta para quem mede a JANELA DA CORRELAÇÃO: o segundo clique
	 * precisa acontecer depois de o caso ter recuado o carimbo do gatilho, que é
	 * como esta bancada faz o tempo passar sem mexer no relógio do processo.
	 */
	return { win, doc, gatilho, chamadas, clicar, ouvintes };
}

/**
 * `js.conversao_multicanal` — a CONVERSÃO DO CLIQUE, nos quatro canais e nos
 * dois caminhos.
 *
 * O que ela mede, e por que cada coisa: até a 1.0.19 o CTA disparava
 * `select_content` e nunca `generate_lead` — o evento de conversão exigia
 * formulário e o template não tem nenhum —, nada carregava o `gtag.js`, e o
 * clique reescrevia o `href` sem olhar o que havia ali.
 *
 * @param {string} raiz Raiz do pacote.
 * @return {Object} Achados.
 */
async function conversaoDoClique( raiz ) {
	const alvo = entregue( raiz, 'fontes/plugin/assets/f3base-leads.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'fontes/plugin/assets/f3base-leads.js ausente na raiz varrida' ] };
	}

	function afirmar( ok, texto ) {
		if ( ! ok ) {
			achados.push( texto );
		}
	}

	const medicaoDireta = {
		caminho: 'direto',
		gtm: '',
		ga4: 'G-ABCDEF1234',
		ads: { id: 'AW-123456789', label: 'AbC-D_efGhIjKlM' },
		meta: { pixelId: '123456789012345', origem: 'https://connect.facebook.net/en_US/fbevents.js' },
		linkedin: { partnerId: '1234567', conversionId: '7654321', origem: 'https://snap.licdn.com/li.lms-analytics/insight.min.js' },
		origemGoogle: 'https://www.googletagmanager.com/'
	};

	const base = {
		endpoint: 'https://exemplo.test/wp-json/f3base/v1/lead',
		/*
		 * O TOKEN DE BANCADA CARREGA UM PRAZO DE VERDADE, porque o cliente lê o
		 * prazo antes de enviar: `<expiração>.<assinatura>` é a forma que o
		 * servidor emite, e um valor sem prazo legível cairia sempre no caminho
		 * de renovação — que é o caso que se quer medir isolado, e não o padrão.
		 */
		token: String( Math.floor( Date.now() / 1000 ) + 3600 ) + '.assinatura-de-bancada',
		rotaToken: 'https://exemplo.test/wp-json/f3base/v1/token',
		janelaCorrelacao: 60,
		numero: '5511999999999',
		mensagem: 'Olá',
		seletor: '[data-f3base-lead]',
		atributoNumero: 'data-f3base-numero',
		hrefsDoModelo: [ '', '#', '/contato' ],
		atribuicao: { modelo: 'first-touch', ttlDias: 30, chave: 'f3base_atribuicao' },
		limites: { nome: 120, mensagem: 2000, formulario: 60, pagina: 300 },
		medicao: medicaoDireta
	};

	/* TETO: href do modelo, caminho direto. */
	const doModelo = bancadaDoClique( fonte, base, '/contato/', {numeroExplicito:base.numero} );
	for (const href of ['/contato/', '#', 'https://campanha.exemplo.test/']) {
		const tema = bancadaDoClique(fonte, base, href);
		afirmar(tema.gatilho.attrs.href === href, 'Piso: número global promoveu link do tema sem marcação explícita.');
	}
	const nomesGtag = doModelo.chamadas.gtag.map( ( c ) => String( c[ 1 ] ) );

	afirmar(
		String( doModelo.gatilho.attrs.href ).indexOf( 'https://wa.me/5511999999999' ) === 0,
		'teto do destino: o href do modelo não virou o link do WhatsApp com a referência do clique'
	);

	afirmar(
		nomesGtag.indexOf( 'generate_lead' ) !== -1,
		'teto do GA4: generate_lead NÃO foi disparado no clique — até a 1.0.19 ele exigia formulário preenchido, e como o template não tem formulário o evento de conversão nunca saía; o que saía era um select_content, que campanha nenhuma otimiza'
	);

	afirmar(
		doModelo.chamadas.gtag.some( ( c ) => 'conversion' === c[ 1 ] && 'AW-123456789/AbC-D_efGhIjKlM' === c[ 2 ].send_to ),
		'teto do Google Ads: a conversão não saiu com send_to montado das duas metades declaradas'
	);

	afirmar(
		doModelo.chamadas.fbq.some( ( c ) => 'track' === c[ 0 ] && 'Lead' === c[ 1 ] && c[ 3 ] && c[ 3 ].eventID ),
		'teto da Meta: o Lead não saiu com eventID — sem ele a deduplicação da Conversions API não tem como acontecer'
	);

	afirmar(
		doModelo.chamadas.lintrk.some( ( c ) => 'track' === c[ 0 ] && 7654321 === c[ 1 ].conversion_id ),
		'teto do LinkedIn: a conversão declarada não foi disparada'
	);

	/*
	 * A FORMA DO EVENTO SAI DO CAMINHO, e essa é a correção. Ela saía nos DOIS
	 * formatos sempre — objeto no `dataLayer` E `gtag('event', …)` —, e
	 * `gtag()` é OUTRO push: o stub do Consent Mode empurra os argumentos no
	 * mesmo `dataLayer`. O mesmo clique aparecia duas vezes na fila, e um
	 * container que dispare por nome de evento conta a conversão em dobro. No
	 * caminho DIRETO o evento é o COMANDO do `gtag`, que é o que o `gtag.js`
	 * consome — e o objeto não é empurrado, porque ele seria a segunda cópia que
	 * um container futuro leria. A contagem está medida logo abaixo, contra o
	 * stub de verdade.
	 */
	afirmar(
		! doModelo.win.dataLayer.some( ( e ) => e && 'generate_lead' === e.event ),
		'piso do push em dobro: no caminho DIRETO o objeto do evento foi empurrado no dataLayer ao lado do comando gtag — são dois registros do mesmo clique na mesma fila'
	);

	const corpo = doModelo.chamadas.beacon.length ? JSON.parse( doModelo.chamadas.beacon[ 0 ].corpo ) : {};
	const atribuido = corpo.atribuicao || {};

	afirmar(
		'BANCADA_GCLID' === atribuido.gclid && 'BANCADA_FBCLID' === atribuido.fbclid && 'BANCADA_LI' === atribuido.li_fat_id,
		'teto dos identificadores de clique: gclid, fbclid e li_fat_id não chegaram ao lead — sem eles o lead chega sem a campanha que o comprou'
	);

	afirmar(
		'string' === typeof atribuido.fbc && 0 === atribuido.fbc.indexOf( 'fb.1.' ) && atribuido.fbc.endsWith( 'BANCADA_FBCLID' ),
		'teto do _fbc: o cookie não foi montado a partir do fbclid no formato que a Meta declara'
	);

	afirmar(
		'google' === atribuido.fonte,
		'teto da campanha: os cinco UTMs pararam de viajar quando os identificadores de clique entraram'
	);

	/* PISO do destino: o href do agente sobrevive ao clique, e a conversão sai igual. */
	const doAgente = bancadaDoClique( fonte, base, 'https://campanha.exemplo.test/lp-outubro' );

	afirmar(
		'https://campanha.exemplo.test/lp-outubro' === doAgente.gatilho.attrs.href,
		'piso do destino: o clique REESCREVEU o href do agente — até a 1.0.19 ele fazia isso a cada clique, e a landing que a campanha aponta virava o wa.me'
	);

	afirmar(
		doAgente.chamadas.gtag.map( ( c ) => String( c[ 1 ] ) ).indexOf( 'generate_lead' ) !== -1,
		'piso do destino: com destino próprio o clique deixou de ser medido — medir não exige mandar no destino'
	);

	/* PISO do caminho: com container, NENHUM disparo direto acontece. */
	const comContainer = bancadaDoClique(
		fonte,
		Object.assign( {}, base, {
			medicao: {
				caminho: 'gtm',
				gtm: 'GTM-ABC1234',
				ga4: '',
				ads: { id: '', label: '' },
				meta: { pixelId: '', origem: '' },
				linkedin: { partnerId: '', conversionId: '', origem: '' },
				origemGoogle: 'https://www.googletagmanager.com/'
			}
		} ),
		'/contato/'
	);

	afirmar(
		0 === comContainer.chamadas.fbq.length && 0 === comContainer.chamadas.lintrk.length,
		'piso do disparo em dobro: no caminho do container o cliente disparou tag direta — o container também dispara, e a mesma conversão sai duas vezes'
	);

	afirmar(
		! comContainer.chamadas.gtag.some( ( c ) => 'conversion' === c[ 1 ] ),
		'piso do disparo em dobro: a conversão do Ads saiu direto mesmo no caminho do container'
	);

	afirmar(
		comContainer.win.dataLayer.some( ( e ) => e && 'generate_lead' === e.event ),
		'piso do caminho: no caminho do container o objeto do evento não foi empurrado, e é ele o gatilho que o container lê'
	);

	/*
	 * PISO da SEGUNDA trava. São duas para o mesmo disparo em dobro: a
	 * estrutural, no servidor, que não deixa o ID direto chegar ao navegador
	 * (medida em `tracking.caminho_unico`), e a do cliente, medida aqui. Esta
	 * bancada entrega os IDs diretos DE PROPÓSITO junto do container — um
	 * servidor que os deixasse passar — para que a trava do cliente seja o único
	 * motivo pelo qual nada dispara.
	 */
	const containerComIdsVazados = bancadaDoClique(
		fonte,
		Object.assign( {}, base, {
			medicao: Object.assign( {}, medicaoDireta, { caminho: 'gtm', gtm: 'GTM-ABC1234' } )
		} ),
		'/contato/'
	);

	afirmar(
		0 === containerComIdsVazados.chamadas.fbq.length
			&& 0 === containerComIdsVazados.chamadas.lintrk.length
			&& ! containerComIdsVazados.chamadas.gtag.some( ( c ) => 'conversion' === c[ 1 ] ),
		'piso da segunda trava: com o container declarado e os IDs diretos presentes, o cliente disparou tag direta — é o caminho do container decidindo, e não a presença do ID'
	);

	afirmar(
		containerComIdsVazados.win.dataLayer.some( ( e ) => e && 'generate_lead' === e.event ),
		'piso da segunda trava: o objeto do evento deixou de ser empurrado quando o disparo direto foi travado — travar o direto não pode calar o container'
	);

	/* PISO do slot vazio: sem ID nenhum, nada é disparado — e o lead continua registrado. */
	const semSlot = bancadaDoClique(
		fonte,
		Object.assign( {}, base, {
			medicao: {
				caminho: 'nenhum',
				gtm: '',
				ga4: '',
				ads: { id: '', label: '' },
				meta: { pixelId: '', origem: '' },
				linkedin: { partnerId: '', conversionId: '', origem: '' },
				origemGoogle: 'https://www.googletagmanager.com/'
			}
		} ),
		'/contato/'
	);

	afirmar(
		0 === semSlot.chamadas.fbq.length && 0 === semSlot.chamadas.lintrk.length && ! semSlot.chamadas.gtag.some( ( c ) => 'conversion' === c[ 1 ] ),
		'piso do slot vazio: sem ID gravado alguma conversão foi disparada — slot vazio é inerte, e disparar sem destino é inventar medição'
	);

	afirmar(
		1 === semSlot.chamadas.beacon.length,
		'piso do slot vazio: o lead deixou de ser registrado no endpoint quando não há canal declarado — o registro é do site, não da campanha'
	);

	/*
	 * A NEGATIVA TARDIA, e a assimetria que ela expõe. Até a 1.1.4 a condição
	 * dos dois disparos sem Consent Mode era `typeof window.fbq === 'function'`
	 * e `typeof window.lintrk === 'function'` — a PRESENÇA DA FUNÇÃO. Sob a
	 * política pré-aprovada isso significa: quem chegou, foi medido, abriu o
	 * controle do rodapé e recusou continuava mandando `Lead` para a Meta e
	 * `track` para o LinkedIn a cada clique no CTA, porque o script deles já
	 * estava carregado e negar não descarrega script nenhum.
	 *
	 * O Google não precisa deste portão: ele recebe a negativa como
	 * `consent update` e decide sozinho. Por isso o teto abaixo exige que o
	 * `generate_lead` CONTINUE saindo — calar o dataLayer aqui seria decidir
	 * pelo Consent Mode em cima dele — e o piso exige que Meta e LinkedIn parem.
	 */
	const negouDepois = bancadaDoClique( fonte, base, '/contato/', { consentimento: false } );

	afirmar(
		0 === negouDepois.chamadas.fbq.length && 0 === negouDepois.chamadas.lintrk.length,
		'piso da negativa tardia: com o consentimento NEGADO depois de as tags terem carregado, o clique ainda mandou ' + negouDepois.chamadas.fbq.length + ' evento(s) ao Pixel da Meta e ' + negouDepois.chamadas.lintrk.length + ' ao Insight Tag do LinkedIn. Nenhum dos dois tem equivalente de consent update: para eles a negativa só pode ser AUSÊNCIA DE ENVIO, e a condição do disparo era a presença da função, que continua verdadeira depois da recusa'
	);

	afirmar(
		1 === negouDepois.chamadas.beacon.length,
		'piso da negativa tardia: o lead deixou de ser registrado no próprio site quando o visitante recusou a medição — recusar medição não é recusar o contato, e o registro é primeira parte'
	);

	afirmar(
		negouDepois.chamadas.gtag.some( ( c ) => 'event' === c[ 0 ] && 'generate_lead' === c[ 1 ] ),
		'teto da negativa tardia: o evento parou de ser emitido ao gtag — quem decide o que o Google faz com ele depois do denied é o Consent Mode, e calar aqui seria decidir duas vezes a mesma coisa, uma delas sem mecanismo'
	);

	const semObjetoDeConsentimento = bancadaDoClique( fonte, base, '/contato/', {} );

	afirmar(
		semObjetoDeConsentimento.chamadas.fbq.length === doModelo.chamadas.fbq.length
			&& semObjetoDeConsentimento.chamadas.lintrk.length === doModelo.chamadas.lintrk.length,
		'piso da decisão de reserva: sem o objeto do consentimento na página o cliente parou de disparar — ausência não pode virar bloqueio silencioso, porque o servidor já decidiu uma vez e é ele a reserva'
	);

	/*
	 * =====================================================================
	 * UM PUSH POR CLIQUE, contado contra o STUB DE VERDADE.
	 *
	 * `f3base-consentimento.js` define `window.gtag` empurrando os próprios
	 * argumentos no `dataLayer` — é o stub do Consent Mode, e ele existe em
	 * TODA página. Com ele no lugar, `dataLayer.push({event})` seguido de
	 * `gtag('event', …)` põe o MESMO clique duas vezes na mesma fila, e um
	 * container que dispare por nome de evento conta a conversão em dobro.
	 * Contar contra um espião que só registra a chamada esconderia isso.
	 * =====================================================================
	 */
	function pushesDoEvento( pilha, evento ) {
		let total = 0;

		for ( const entrada of pilha ) {
			if ( entrada && evento === entrada.event ) {
				total++;
				continue;
			}

			/* O stub empurra o `arguments` do gtag: ['event', nome, params]. */
			if ( entrada && 'event' === entrada[ 0 ] && evento === entrada[ 1 ] ) {
				total++;
			}
		}

		return total;
	}

	const comStub = bancadaDoClique( fonte, base, '/contato/', { gtagStub: true } );

	afirmar(
		1 === pushesDoEvento( comStub.win.dataLayer, 'generate_lead' ),
		'piso do push em dobro: o clique produziu ' + pushesDoEvento( comStub.win.dataLayer, 'generate_lead' ) +
			' push(es) de generate_lead no dataLayer, contra o stub do Consent Mode que existe em toda página. Dois registros do mesmo clique na mesma fila é a mesma conversão contada duas vezes por qualquer gatilho por nome de evento'
	);

	const comStubNoContainer = bancadaDoClique(
		fonte,
		Object.assign( {}, base, {
			medicao: Object.assign( {}, medicaoDireta, { caminho: 'gtm', gtm: 'GTM-ABC1234' } )
		} ),
		'/contato/',
		{ gtagStub: true }
	);

	afirmar(
		1 === pushesDoEvento( comStubNoContainer.win.dataLayer, 'generate_lead' ),
		'piso do push em dobro no container: o clique produziu ' + pushesDoEvento( comStubNoContainer.win.dataLayer, 'generate_lead' ) + ' push(es) do mesmo evento'
	);

	afirmar(
		! comStubNoContainer.chamadas.gtag.some( ( c ) => 'event' === c[ 0 ] ),
		'piso da tag direta no container: o cliente chamou gtag() no caminho do container — o `return` do modo GTM vinha DEPOIS do disparo, e "nenhuma tag direta é emitida" era falso justamente no caminho em que ela é a regra'
	);

	/*
	 * =====================================================================
	 * A ATRIBUIÇÃO E OS COOKIES DE FORNECEDOR ATRÁS DO PORTÃO.
	 *
	 * `localStorage` com a campanha e o cookie `_fbc` com o identificador de
	 * clique de anúncio eram gravados sem que ninguém perguntasse pelo
	 * consentimento, e a recusa não apagava nem um nem outro: quem desligava a
	 * medição ficava com os dois no navegador pelo prazo inteiro.
	 * =====================================================================
	 */
	afirmar(
		'string' === typeof doModelo.win.localStorage.guardado.f3base_atribuicao
			&& doModelo.doc.cookie.indexOf( '_fbc=' ) !== -1,
		'teto do portão aberto: com a medição permitida a atribuição não foi guardada, ou o _fbc não foi gravado — o portão não pode desligar o que ele existe para condicionar'
	);

	const recusou = bancadaDoClique( fonte, base, '/contato/', { consentimento: false } );

	afirmar(
		undefined === recusou.win.localStorage.guardado.f3base_atribuicao,
		'piso do portão: com a medição RECUSADA a atribuição foi guardada no localStorage assim mesmo'
	);

	afirmar(
		recusou.doc.cookie.indexOf( '_fbc=fb.' ) === -1,
		'piso do portão: com a medição RECUSADA o cookie _fbc foi gravado — é o identificador de clique de anúncio da Meta, gravado por nós, com prazo nosso, para quem disse que não queria medição'
	);

	/* A RECUSA APAGA O QUE JÁ ESTAVA GUARDADO, e não só impede o que vem depois. */
	const jaGuardado = bancadaDoClique( fonte, base, '/contato/', {
		consentimento: false,
		antes( win, documento ) {
			win.localStorage.guardado.f3base_atribuicao = JSON.stringify( {
				expira: Math.floor( Date.now() / 1000 ) + 86400,
				valor: { fonte: 'google' }
			} );
			documento.cookie = '_fbc=fb.1.1700000000000.ANTIGO';
		}
	} );

	afirmar(
		undefined === jaGuardado.win.localStorage.guardado.f3base_atribuicao,
		'piso da recusa que não desfaz: a atribuição gravada ANTES da recusa continuou no localStorage depois dela'
	);

	afirmar(
		jaGuardado.doc.cookie.indexOf( 'ANTIGO' ) === -1,
		'piso da recusa que não desfaz: o _fbc gravado antes da recusa continuou no navegador — negar medição e ficar com o identificador de clique de anúncio guardado é a pior das duas posições'
	);

	/*
	 * =====================================================================
	 * O `user_data` DAS ENHANCED CONVERSIONS ATRÁS DO PORTÃO.
	 *
	 * Ele mandava ao Google o SHA-256 do e-mail e do telefone do visitante, e a
	 * única guarda era `typeof window.gtag !== 'function'` — que o stub do
	 * Consent Mode torna verdadeira em toda página. O espião do hash mede se o
	 * dado chegou a ser PREPARADO, que é onde a decisão precisa acontecer.
	 * =====================================================================
	 */
	const comCampos = { email: 'Jose.Da.Silva@Exemplo.TEST', telefone: '+5511999990000' };

	const comContato = bancadaDoClique( fonte, base, '/contato/', { campos: comCampos } );

	afirmar(
		2 === comContato.chamadas.hash.length,
		'teto das Enhanced Conversions: com medição permitida e formulário associado, o e-mail e o telefone não viraram hash (' +
			comContato.chamadas.hash.length + ' chamada(s)) — o ramo existe para o projeto que acrescentar um formulário'
	);

	const recusouComContato = bancadaDoClique( fonte, base, '/contato/', { campos: comCampos, consentimento: false } );

	afirmar(
		0 === recusouComContato.chamadas.hash.length,
		'piso do portão do user_data: com a medição RECUSADA o e-mail e o telefone do visitante foram preparados para o Google assim mesmo (' +
			recusouComContato.chamadas.hash.length + ' chamada(s) de hash). A guarda `typeof gtag` nunca protegeu disso: o stub do Consent Mode a torna verdadeira em toda página'
	);

	/*
	 * =====================================================================
	 * O RETORNO DO `sendBeacon` É LIDO, e o `fetch` é alcançável.
	 *
	 * `sendBeacon` devolve FALSO quando o navegador recusa a fila — corpo acima
	 * do orçamento, ou fila cheia. O retorno era descartado e o ramo do `fetch`
	 * vinha depois de um `return`: ele nunca rodava, e nesse caso o registro
	 * simplesmente não acontecia, em silêncio.
	 * =====================================================================
	 */
	const beaconRecusado = bancadaDoClique( fonte, base, '/contato/', {
		beaconRecusa: true,
		respostas: [ { status: 201 } ]
	} );

	afirmar(
		0 === beaconRecusado.chamadas.beacon.length && 1 === beaconRecusado.chamadas.fetch.length,
		'piso do beacon recusado: o navegador recusou a fila do sendBeacon e o registro não caiu no fetch (' +
			beaconRecusado.chamadas.fetch.length + ' chamada(s)). O ramo do keepalive vinha depois de um return e nunca era alcançado: o lead se perdia sem erro nenhum'
	);

	afirmar(
		beaconRecusado.chamadas.fetch.length > 0 && String( beaconRecusado.chamadas.fetch[ 0 ].url ) === String( base.endpoint )
			&& 'POST' === String( ( beaconRecusado.chamadas.fetch[ 0 ].opcoes || {} ).method ),
		'teto do beacon recusado: o fetch de reserva não foi um POST para o endpoint do registro'
	);

	/*
	 * =====================================================================
	 * A PÁGINA EM CACHE: token vencido, token novo, e UM reenvio.
	 *
	 * O token era assinado só com a expiração e valia doze horas. Uma página
	 * servida de cache mais velho que o prazo fazia TODO beacon voltar 403, sem
	 * sinal nenhum — e nada no cliente pedia um token novo.
	 * =====================================================================
	 */
	const vencido = Object.assign( {}, base, {
		token: String( Math.floor( Date.now() / 1000 ) - 60 ) + '.assinatura-vencida'
	} );

	const doCache = bancadaDoClique( fonte, vencido, '/contato/', {
		beaconRecusa: true,
		respostas: [
			{ status: 200, corpo: { ok: true, token: '9999999999.assinatura-nova' } },
			{ status: 201 }
		]
	} );

	await new Promise( ( pronto ) => setTimeout( pronto, 0 ) );

	afirmar(
		doCache.chamadas.fetch.length >= 1 && String( doCache.chamadas.fetch[ 0 ].url ).indexOf( String( base.rotaToken ) ) === 0,
		'piso da página em cache: com o token já vencido o cliente mandou o registro assim mesmo, em vez de pedir um token novo na rota de emissão — o beacon volta 403 e nada na tela diz isso'
	);

	afirmar(
		2 === doCache.chamadas.fetch.length
			&& String( doCache.chamadas.fetch[ 1 ].url ) === String( base.endpoint )
			&& JSON.parse( String( doCache.chamadas.fetch[ 1 ].opcoes.body ) ).token === '9999999999.assinatura-nova',
		'teto da página em cache: o registro não foi reenviado com o token novo — trocar o token e não reenviar perde o lead do mesmo jeito'
	);

	/* O 403 do servidor produz UMA renovação e UM reenvio, nunca um laço. */
	const trezentosETres = bancadaDoClique( fonte, base, '/contato/', {
		beaconRecusa: true,
		respostas: [
			{ status: 403, corpo: { codigo: 'f3base_token_invalido' } },
			{ status: 200, corpo: { ok: true, token: '9999999999.assinatura-nova' } },
			{ status: 403, corpo: { codigo: 'f3base_token_invalido' } }
		]
	} );

	await new Promise( ( pronto ) => setTimeout( pronto, 0 ) );
	await new Promise( ( pronto ) => setTimeout( pronto, 0 ) );

	afirmar(
		3 === trezentosETres.chamadas.fetch.length,
		'piso do reenvio único: o 403 produziu ' + trezentosETres.chamadas.fetch.length +
			' chamada(s) — o esperado é registro, pedido de token e UM reenvio. Um segundo 403 não é de prazo, e repetir viraria laço'
	);

	/*
	 * =====================================================================
	 * A JANELA DA CORRELAÇÃO, declarada pelo servidor.
	 *
	 * Ela valia cinco segundos escritos dentro do cliente. Dois cliques com seis
	 * segundos de intervalo — clicar, ver o que abriu, voltar, clicar de novo —
	 * viravam dois leads, duas reservas e a mesma conversão contada de novo em
	 * todos os fornecedores, com `eventID` que a Meta não pode casar.
	 * =====================================================================
	 */
	const naJanela = bancadaDoClique( fonte, base, '/contato/' );
	const primeiraChave = String( naJanela.gatilho.attrs[ 'data-f3base-correlation' ] );

	/* Trinta segundos passados: dentro da janela declarada de sessenta. */
	naJanela.gatilho.attrs[ 'data-f3base-correlation-em' ] =
		String( parseInt( naJanela.gatilho.attrs[ 'data-f3base-correlation-em' ], 10 ) - 30 );
	naJanela.clicar();

	afirmar(
		primeiraChave === String( naJanela.gatilho.attrs[ 'data-f3base-correlation' ] ),
		'piso da janela: dois cliques com trinta segundos de intervalo nasceram com correlações DIFERENTES — a janela de cinco segundos que morava no cliente é menor que o gesto de clicar, ver o que abriu e clicar de novo, e cada um deles virava um lead'
	);

	/* Passada a janela sem clique nenhum, o clique seguinte é outra interação. */
	naJanela.gatilho.attrs[ 'data-f3base-correlation-em' ] =
		String( parseInt( naJanela.gatilho.attrs[ 'data-f3base-correlation-em' ], 10 ) - 3600 );
	naJanela.clicar();

	afirmar(
		primeiraChave !== String( naJanela.gatilho.attrs[ 'data-f3base-correlation' ] ),
		'teto da janela: passada a janela declarada, o clique seguinte continuou com a MESMA correlação — o servidor a recusaria como duplicata e a segunda interação sumiria'
	);

	afirmar(
		60 === parseInt( base.janelaCorrelacao, 10 ),
		'piso da declaração: a bancada deixou de publicar a janela ao cliente, e sem ela o número volta a ser escrito dentro do JavaScript'
	);

	return { achados };
}

/**
 * A DECLARAÇÃO de eventos de comportamento, lida do TSV do pacote.
 *
 * A sonda lê a MESMA declaração que o servidor publica ao navegador. Escrever
 * os nomes aqui dentro faria a bancada aprovar a si mesma: ela mediria a cópia,
 * e não o que o site emite.
 *
 * @param {string} raiz Raiz do pacote.
 * @return {Object} Eventos por nome, no formato que o cliente recebe.
 */
function declaracaoDeComportamento( raiz ) {
	const alvo = join( raiz, 'fontes/plugin/dados/eventos-comportamento.tsv' );
	const eventos = {};
	let bruto;

	try {
		bruto = readFileSync( alvo, 'utf8' );
	} catch {
		return eventos;
	}

	for ( const linha of bruto.split( /\r?\n/ ) ) {
		const texto = linha.trim();

		if ( '' === texto || texto.startsWith( '#' ) ) {
			continue;
		}

		const colunas = linha.split( '\t' );

		if ( colunas.length < 5 ) {
			continue;
		}

		const nome = colunas[ 0 ].trim();
		const teto = parseInt( colunas[ 2 ].trim(), 10 );

		if ( '' === nome || ! ( teto > 0 ) ) {
			continue;
		}

		const limiar = {};

		if ( '—' !== colunas[ 4 ].trim() && '' !== colunas[ 4 ].trim() ) {
			for ( const par of colunas[ 4 ].split( ';' ) ) {
				const partes = par.split( '=' );

				if ( partes.length < 2 ) {
					continue;
				}

				limiar[ partes[ 0 ].trim() ] = partes.slice( 1 ).join( '=' ).split( ',' )
					.map( ( v ) => v.trim() ).filter( Boolean );
			}
		}

		eventos[ nome ] = {
			parametros: colunas[ 1 ].split( ',' ).map( ( v ) => v.trim() ).filter( Boolean ),
			teto,
			gatilho: colunas[ 3 ].trim(),
			limiar
		};
	}

	return eventos;
}

/**
 * BANCADA DO COMPORTAMENTO: o carregador REAL, com os coletores instalados.
 *
 * O que ela oferece é o mínimo de plataforma que os coletores tocam —
 * `IntersectionObserver`, `PerformanceObserver`, `performance`, rolagem, clique,
 * erro e ocultamento de página — e o que ela devolve é o `dataLayer` e as
 * chamadas de `gtag`: exatamente o que a conta de medição receberia.
 *
 * @param {string} fonte  Código do carregador, como ele viaja no pacote.
 * @param {Object} dados  `f3baseTrackingDados`, como o servidor o publica.
 * @param {Object} extras Ajustes do caso (documento alto, seções, consentimento).
 * @return {Object} A bancada e os gestos que agem sobre ela.
 */
function bancadaDeComportamento( fonte, dados, extras ) {
	const opcoes = extras || {};
	const ouvintesDoc = {};
	const ouvintesWin = {};
	const gtagChamadas = [];
	const observados = [];
	const observadosDeTamanho = [];
	const desempenho = [];
	const microtarefas = [];

	function elemento( tag, classe, atributos ) {
		const el = {
			nodeType: 1,
			tagName: String( tag ).toUpperCase(),
			className: classe || '',
			attrs: Object.assign( {}, atributos || {} ),
			filhos: [],
			pai: null,
			getAttribute( nome ) {
				return Object.prototype.hasOwnProperty.call( this.attrs, nome ) ? this.attrs[ nome ] : null;
			},
			closest( seletor ) {
				const interativo = [ 'A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'SUMMARY' ];

				if ( ! seletor.includes( 'button' ) ) {
					return null;
				}

				let atual = this;

				while ( atual ) {
					if ( interativo.includes( atual.tagName ) || atual.attrs.role || atual.attrs.tabindex ) {
						return atual;
					}

					atual = atual.pai;
				}

				return null;
			}
		};

		return el;
	}

	const secoes = ( opcoes.secoes || [] ).map( ( classe ) => elemento( 'section', classe ) );

	/*
	 * A JANELA TEM ALTURA, E ELA É UM NÚMERO SÓ. Ela aparecia três vezes como
	 * literal — `innerHeight`, `clientHeight` e a conta da rolagem —, e a
	 * geometria das seções precisa da mesma altura que a rolagem usa: duas
	 * respostas para "de que tamanho é a tela" fariam a razão de interseção
	 * discordar do percentual rolado sem que nada acusasse.
	 */
	const alturaDaJanela = 800;
	const alturaDoDocumento = opcoes.alturaDocumento || 4000;

	/*
	 * CADA SEÇÃO TEM LUGAR NO DOCUMENTO, e é isso que faltava.
	 *
	 * A bancada anterior expunha `verSecao` e `esconderSecao`, que disparavam
	 * `{ isIntersecting: true|false }` À MÃO — sem razão de interseção e sem
	 * nenhuma relação com a posição de rolagem. `rolarAte(95)` não movia seção
	 * nenhuma. O retorno intermediário que o navegador dá de verdade — o alvo
	 * ainda sobreposto, com a razão ABAIXO do limiar declarado — nunca era
	 * produzido, e por isso a bancada aprovou um rearme de seção que o
	 * navegador quase nunca alcança: o bloco só rearmava saindo INTEIRO da
	 * tela. Sem geometria, a bancada era mais fácil que o mundo.
	 *
	 * O PADRÃO É FAIXAS IGUAIS ao longo do documento, com a seção nunca mais
	 * alta que a janela — uma seção de duas telas de altura jamais alcançaria
	 * meia seção visível, e a bancada padrão passaria a medir o caso em que
	 * nada dispara. Quem precisa de layout específico declara `geometria`.
	 */
	const geometriaDeclarada = Array.isArray( opcoes.geometria ) ? opcoes.geometria : null;
	const faixaDaSecao = secoes.length > 0 ? alturaDoDocumento / secoes.length : 0;

	for ( let i = 0; i < secoes.length; i++ ) {
		const declarada = ( geometriaDeclarada && geometriaDeclarada[ i ] ) ? geometriaDeclarada[ i ] : {};

		secoes[ i ].topo = undefined !== declarada.topo ? Number( declarada.topo ) : Math.round( i * faixaDaSecao );
		secoes[ i ].altura = undefined !== declarada.altura ? Number( declarada.altura ) : Math.round( Math.min( faixaDaSecao, alturaDaJanela ) );
	}

	const documento = {
		readyState: opcoes.readyState || 'complete',
		visibilityState: 'visible',
		get cookie() {
			return '';
		},
		set cookie( valor ) {
			gravacoes.push( { onde: 'cookie', chave: String( valor ).split( '=' )[ 0 ], valor: String( valor ) } );
		},
		documentElement: { scrollHeight: alturaDoDocumento, clientHeight: alturaDaJanela, scrollTop: 0 },
		body: { scrollHeight: alturaDoDocumento },
		head: { appendChild() {} },
		addEventListener( tipo, fn ) {
			( ouvintesDoc[ tipo ] = ouvintesDoc[ tipo ] || [] ).push( fn );
		},
		getElementById: () => null,
		getElementsByTagName: () => [],
		createElement: ( tag ) => elemento( tag ),
		querySelectorAll( seletor ) {
			const achou = /\[class\*="([^"]+)"\]/.exec( seletor );

			return achou ? secoes.filter( ( s ) => s.className.includes( achou[ 1 ] ) ) : [];
		}
	};

	/*
	 * O OBSERVADOR GUARDA, POR ALVO, A ÚLTIMA FAIXA DE THRESHOLD E SE HAVIA
	 * SOBREPOSIÇÃO — que é o par que a especificação compara para decidir se
	 * entrega um retorno. O navegador entrega quando QUALQUER um dos dois muda:
	 * é por isso que a razão caindo de 0,6 para 0,4 chega ao coletor com
	 * `isIntersecting` ainda VERDADEIRO, e é esse retorno que a bancada nunca
	 * produziu.
	 */
	class ObservadorDeInterseccao {
		constructor( retorno, config ) {
			this.retorno = retorno;
			this.config = config;
			this.alvos = [];
			this.faixas = [];
			observados.push( this );
		}

		observe( alvo ) {
			this.alvos.push( alvo );
			this.faixas.push( null );
		}

		unobserve( alvo ) {
			const restam = [];
			const faixas = [];

			for ( let i = 0; i < this.alvos.length; i++ ) {
				if ( this.alvos[ i ] === alvo ) {
					continue;
				}

				restam.push( this.alvos[ i ] );
				faixas.push( this.faixas[ i ] );
			}

			this.alvos = restam;
			this.faixas = faixas;
		}

		/**
		 * A faixa de threshold de uma razão, como a especificação a calcula.
		 *
		 * @param {number} razao Razão de interseção.
		 * @return {number} Índice da faixa.
		 */
		faixaDe( razao ) {
			/*
			 * SEM SOBREPOSIÇÃO, A FAIXA É ZERO — inclusive com `0` declarado na
			 * lista. Contando `razao >= 0` como faixa alcançada, o alvo FORA da
			 * tela sairia com faixa 1 e, portanto, com `isIntersecting`
			 * verdadeiro: o bloco que saiu inteiro nunca rearmaria. Medido em
			 * Chromium 1194 com `threshold: 0.5`: razão 0,000 chega com
			 * `isIntersecting: false`.
			 */
			if ( ! ( razao > 0 ) ) {
				return 0;
			}

			const bruto = ( this.config && undefined !== this.config.threshold ) ? this.config.threshold : 0;
			const lista = ( Array.isArray( bruto ) ? bruto : [ bruto ] )
				.map( Number )
				.filter( ( n ) => ! isNaN( n ) )
				.sort( ( a, b ) => a - b );

			let faixa = 0;

			for ( const corte of lista ) {
				if ( razao >= corte ) {
					faixa = faixa + 1;
				}
			}

			return faixa;
		}
	}

	/*
	 * O OBSERVADOR DE TAMANHO existe na plataforma porque o coletor de rolagem
	 * o usa para reavaliar o marco quando a página cresce sem ninguém rolar.
	 * Sem ele aqui, o ramo da reavaliação não seria exercitado.
	 */
	class ObservadorDeTamanho {
		constructor( retorno ) {
			this.retorno = retorno;
			this.alvos = [];
			observadosDeTamanho.push( this );
		}

		observe( alvo ) {
			this.alvos.push( alvo );
		}

		disconnect() {
			this.alvos = [];
		}
	}

	class ObservadorDeDesempenho {
		constructor( retorno ) {
			this.retorno = retorno;
		}

		observe( config ) {
			desempenho.push( { tipo: config.type, config, retorno: this.retorno } );
		}
	}

	const beacons = [];
	const gravacoes = [];
	let sorteios = 0;
	const removidas = [];
	const armazenado = Object.assign( {}, opcoes.armazenado || {} );
	let recusandoBeacon = true === opcoes.beaconRecusa;
	let permite = false !== opcoes.consentimento;

	/*
	 * O SERVIDOR PODE RECUSAR, E COM CÓDIGO — e é isto que a bancada não sabia
	 * fazer. Enquanto o despacho era `sendBeacon`, o único desfecho observável
	 * era "o navegador aceitou a carga", e a bancada não tinha como exercitar
	 * a diferença entre um lote ENFILEIRADO e um lote ENTREGUE. Ela é a
	 * diferença inteira desta release: um servidor em 503, em 429 ou uma rede
	 * caindo precisam manter o lote, e nenhum desses casos existia aqui.
	 *
	 * `resposta` aceita um número (todo envio responde assim), uma função
	 * (índice do envio e corpo, para a bancada que recusa os primeiros e aceita
	 * o resto) ou `'rede'` (a requisição não chega a ter resposta).
	 */
	const respostaDeclarada = undefined === opcoes.resposta ? 201 : opcoes.resposta;
	let envios = 0;

	/**
	 * O código de resposta deste envio, como o servidor o devolveria.
	 *
	 * @param {string} corpo Corpo despachado.
	 * @return {number|string} Código, ou `'rede'` quando não há resposta.
	 */
	function respostaDoEnvio( corpo ) {
		const bruta = 'function' === typeof respostaDeclarada
			? respostaDeclarada( envios, corpo )
			: respostaDeclarada;

		envios = envios + 1;

		return bruta;
	}

	/**
	 * UMA PROMESSA QUE RESOLVE NA HORA, e a razão de ela não ser uma de verdade.
	 *
	 * A bancada é síncrona: ela roda os gestos e lê o resultado na linha
	 * seguinte. Uma `Promise` de verdade só entrega o retorno quando a pilha
	 * esvazia — depois de a checagem inteira ter terminado —, e toda asserção
	 * sobre o que o cliente faz COM a resposta mediria o estado de antes dela.
	 * O que o cliente usa da promessa é `.then().catch()`, e é exatamente isso
	 * que esta entrega, na ordem certa e sem esperar.
	 *
	 * @param {Object} valor Valor de resolução.
	 * @param {*}      falha Motivo da rejeição, quando há.
	 * @return {Object} Encadeável com `then` e `catch`.
	 */
	function promessaImediata( valor, falha ) {
		return {
			then( aoResolver ) {
				if ( undefined !== falha ) {
					return this;
				}

				try {
					aoResolver( valor );
				} catch ( erro ) {
					return promessaImediata( undefined, erro );
				}

				return this;
			},
			catch( aoFalhar ) {
				if ( undefined !== falha ) {
					aoFalhar( falha );
				}

				return this;
			}
		};
	}

	/*
	 * A PÁGINA TEM ENDEREÇO, e ele passou a importar. Enquanto o contador de
	 * travessias vivia no carregamento, o caminho só aparecia no corpo
	 * despachado; agora ele é parte da CHAVE do contador, e uma bancada com um
	 * caminho só não consegue medir a coisa que a chave existe para separar —
	 * o mesmo nome de bloco em duas páginas diferentes. O padrão continua sendo
	 * `/pagina/`, de modo que toda bancada escrita antes disto mede o mesmo.
	 */
	const enderecoDaPagina = opcoes.caminho ? String( opcoes.caminho ) : '/pagina/';
	const buscaDaPagina = '?utm_content=lead-8813&email=joao%40exemplo.test';

	const janela = {
		f3baseTrackingDados: dados,
		dataLayer: [],
		innerHeight: alturaDaJanela,
		pageYOffset: 0,
		location: {
			href: 'https://exemplo.test' + enderecoDaPagina + buscaDaPagina,
			pathname: enderecoDaPagina,
			search: buscaDaPagina,
			hostname: 'exemplo.test',
			protocol: 'https:'
		},
		Blob: class {
			constructor( partes, opcoes ) {
				this.partes = partes;
				this.type = ( opcoes || {} ).type || '';
			}
		},
		navigator: false === opcoes.beacon ? {} : {
			/*
			 * O NAVEGADOR PODE RECUSAR, e devolve `false` sem lançar: fila
			 * cheia, corpo grande. A bancada precisa saber recusar, senão o
			 * ramo que preserva o acumulado nunca é exercitado.
			 */
			sendBeacon( url, corpo ) {
				if ( recusandoBeacon ) {
					return false;
				}

				beacons.push( { url: String( url ), corpo: String( ( corpo && corpo.partes ) ? corpo.partes[ 0 ] : corpo ), via: 'beacon', status: 202 } );

				return true;
			}
		},
		/*
		 * `fetch` COM `keepalive` É O CAMINHO NOVO, e ele é o único que devolve
		 * resposta. A bancada o entrega por padrão porque ele é o caminho de
		 * todo navegador que este pacote suporta; `fetch: false` mede o
		 * navegador sem ele, e `keepalive: false` mede o pior caso real — um
		 * `fetch` que existe e que seria CANCELADO na saída da página, e por
		 * isso não pode ser usado.
		 */
		fetch: false === opcoes.fetch ? undefined : function ( url, init ) {
			const corpo = String( ( init || {} ).body || '' );
			const codigo = respostaDoEnvio( corpo );

			beacons.push( { url: String( url ), corpo, via: 'fetch', init: init || {}, status: codigo } );

			if ( 'rede' === codigo ) {
				return promessaImediata( undefined, new Error( 'rede' ) );
			}

			/*
			 * A RESPOSTA QUE AINDA NÃO CHEGOU, e ela é o estado normal de um
			 * `fetch` durante a saída da página: a requisição partiu e a promessa
			 * não resolveu. Sem este caso a bancada era SÍNCRONA demais — todo
			 * despacho concluía antes do evento seguinte, e o segundo evento de
			 * saída nunca encontrava o lote ainda na fila. Era por isso que o
			 * despacho duplo não aparecia aqui e aparecia no navegador.
			 */
			if ( 'pendente' === codigo ) {
				return { then() { return this; }, catch() { return this; } };
			}

			return promessaImediata( { status: Number( codigo ), ok: Number( codigo ) >= 200 && Number( codigo ) < 300 } );
		},
		Request: ( false === opcoes.fetch || false === opcoes.keepalive )
			? ( false === opcoes.fetch ? undefined : class { } )
			: ( function () {
				class RequisicaoDeBancada {}

				/*
				 * `keepalive` PRECISA ESTAR NO PROTÓTIPO, porque é ali que o
				 * cliente o procura: é a detecção que separa o navegador que
				 * sobrevive à saída daquele que teria a requisição cancelada.
				 */
				Object.defineProperty( RequisicaoDeBancada.prototype, 'keepalive', { get: () => false } );

				return RequisicaoDeBancada;
			}() ),
		localStorage: {
			setItem( chave, valor ) {
				/*
				 * O ARMAZENAMENTO PODE RECUSAR A ESCRITA, e a 1.3.4 declarou
				 * essa lacuna: cota cheia e modo restrito lançam em
				 * `setItem()`, e a bancada nunca lançava. Sem isto, o ramo em
				 * que o pendente NÃO chega a ser gravado — e a visita degrada
				 * para o comportamento de antes — nunca era exercitado, e a
				 * degradação declarada era só uma frase de comentário.
				 */
				if ( true === opcoes.armazenamentoRecusa ) {
					throw new Error( 'QuotaExceededError' );
				}

				armazenado[ String( chave ) ] = String( valor );
				gravacoes.push( { onde: 'localStorage', chave: String( chave ), valor: String( valor ) } );
			},
			/*
			 * O NAVEGADOR CHEGA COM O QUE JÁ TINHA. Sem isto, toda bancada
			 * mediria a primeira visita de um navegador limpo — e a visita que
			 * atravessa páginas, que é a mudança desta release, seria
			 * impossível de exercitar.
			 */
			getItem: ( chave ) => ( Object.prototype.hasOwnProperty.call( armazenado, String( chave ) ) ? armazenado[ String( chave ) ] : null ),
			/*
			 * REMOVER APAGA DE VERDADE, e antes só anotava. Com o registro
			 * continuando legível depois de `removeItem`, a bancada não conseguia
			 * medir o que acontece DEPOIS de uma exclusão — o re-aceite lia o
			 * apelido que acabara de ser apagado e a bancada aprovava a
			 * ressurreição do identificador.
			 */
			removeItem( chave ) {
				removidas.push( { onde: 'localStorage', chave: String( chave ) } );
				delete armazenado[ String( chave ) ];
			}
		},
		sessionStorage: {
			setItem( chave, valor ) {
				gravacoes.push( { onde: 'sessionStorage', chave: String( chave ), valor: String( valor ) } );
			},
			getItem: () => null,
			removeItem() {}
		},
		URL: globalThis.URL,
		/*
		 * O GERADOR CRIPTOGRÁFICO E O ARRAY DE BYTES existem em todo navegador
		 * que este pacote suporta, e o apelido do visitante sai deles. Sem eles
		 * aqui, a bancada mediria um cliente que não consegue sortear
		 * identificador nenhum — e aprovaria o silêncio.
		 */
		crypto: false === opcoes.crypto ? undefined : {
			getRandomValues( bytes ) {
				/*
				 * CADA CHAMADA DEVOLVE COISA DIFERENTE, como o gerador de
				 * verdade: um gerador determinístico faria o apelido do
				 * visitante e o da visita saírem iguais, e a bancada aprovaria
				 * um cliente que confunde as duas coisas.
				 */
				for ( let i = 0; i < bytes.length; i++ ) {
					bytes[ i ] = ( i * 37 + sorteios * 91 + ( opcoes.semente || 1 ) ) % 256;
				}

				sorteios = sorteios + 1;

				return bytes;
			}
		},
		Uint8Array: globalThis.Uint8Array,
		IntersectionObserver: ObservadorDeInterseccao,
		ResizeObserver: ObservadorDeTamanho,
		PerformanceObserver: ObservadorDeDesempenho,
		performance: {
			getEntriesByType: ( tipo ) => ( 'navigation' === tipo ? [ { responseStart: 412.7 } ] : [] )
		},
		gtag( ...args ) {
			gtagChamadas.push( args );
		},
		addEventListener( tipo, fn ) {
			( ouvintesWin[ tipo ] = ouvintesWin[ tipo ] || [] ).push( fn );
		},
		f3baseConsentimento: {
			permiteTags: () => permite
		}
	};

	// Duplo da API web-vitals: estas sondas medem integração/entrega, não o algoritmo.
	// Janelas de CLS e descarte do INP são medidos separadamente com o arquivo oficial.
	janela.f3baseTrackingDados = Object.assign({vitaisMaxAtualizacoes: 60}, dados);
	janela.queueMicrotask = fn => microtarefas.push(fn);
	janela.webVitals = {};
	for (const [nome, tipo] of [['LCP','largest-contentful-paint'], ['CLS','layout-shift'], ['INP','event'], ['TTFB','navigation']]) {
		janela.webVitals['on'+nome] = (callback) => {
			let valor = nome === 'TTFB' ? 412.7 : null;
			if (nome !== 'TTFB') {
				new ObservadorDeDesempenho((lista) => {
					for (const e of lista.getEntries()) {
						if (nome === 'LCP') valor = e.startTime;
						if (nome === 'CLS' && !e.hadRecentInput) valor = (valor || 0) + e.value;
						if (nome === 'INP' && e.interactionId) valor = Math.max(valor || 0, e.duration);
					}
				}).observe({type:tipo, buffered:true, durationThreshold:16});
			}
			const relatar = () => { if (valor !== null) callback({name:nome, value:valor, id:'v4-bancada-'+nome}); };
			documento.addEventListener('visibilitychange',relatar);
			janela.addEventListener('pagehide',relatar);
		};
	}
	// eslint-disable-next-line no-new-func
	new Function( 'window', 'document', fonte )( janela, documento );

	for ( const fn of ouvintesDoc.DOMContentLoaded || [] ) {
		fn();
	}

	function disparar( mapa, tipo, evento ) {
		for ( const fn of mapa[ tipo ] || [] ) {
			fn( evento );
		}
		while (microtarefas.length) microtarefas.shift()();
	}

	/*
	 * A GEOMETRIA VIRA RETORNO DE OBSERVADOR, e é assim que o navegador se
	 * comporta: para cada alvo observado, a razão é a sobreposição com a janela
	 * dividida pela área do ALVO, e o retorno sai para quem mudou de faixa de
	 * threshold OU de estado de sobreposição desde a medição anterior. As duas
	 * condições são as da especificação, e é a primeira delas que produz o caso
	 * que interessa: razão abaixo da linha de ENTRADA com o alvo ainda
	 * sobreposto, e com `isIntersecting` verdadeiro por causa do `0` na lista de
	 * faixas.
	 */
	function medirInterseccoes() {
		const topoDaJanela = janela.pageYOffset;
		const baseDaJanela = topoDaJanela + janela.innerHeight;

		for ( const obs of observados ) {
			const entradas = [];

			for ( let i = 0; i < obs.alvos.length; i++ ) {
				const alvo = obs.alvos[ i ];
				const altura = Number( alvo.altura ) || 0;
				const topo = Number( alvo.topo ) || 0;
				const sobreposicao = Math.max( 0, Math.min( topo + altura, baseDaJanela ) - Math.max( topo, topoDaJanela ) );
				const razao = altura > 0 ? sobreposicao / altura : 0;
				const faixa = obs.faixaDe( razao );
				const anterior = obs.faixas[ i ];
				const mudou = null === anterior || anterior.faixa !== faixa || anterior.tocando !== ( razao > 0 );

				if ( ! mudou ) {
					continue;
				}

				obs.faixas[ i ] = { faixa, tocando: razao > 0 };

				/*
				 * `isIntersecting` SAI DO ÍNDICE DE FAIXA, e não da sobreposição
				 * geométrica. É a correção que a sonda de navegador achou nesta
				 * bancada, e ela vale a pena narrar porque é o defeito que esta
				 * release existe para tornar impossível.
				 *
				 * Até aqui a bancada entregava `isIntersecting: razao > 0` —
				 * "há sobreposição, logo está intersectando". É a leitura
				 * intuitiva, é o texto antigo da especificação, e NÃO é o que o
				 * navegador faz. Medido em Chromium 1194, alvo de uma tela,
				 * observador com `threshold: 0.5`: razão 0,2 chega com
				 * `isIntersecting: FALSE`, apesar de haver 20% do alvo na tela.
				 * A especificação atual deriva `isIntersecting` do ÍNDICE DE
				 * FAIXA — verdadeiro quando a razão alcançou pelo menos a menor
				 * linha declarada —, e com `0` na lista qualquer sobreposição
				 * basta para ele ser verdadeiro.
				 *
				 * A CONSEQUÊNCIA É GRANDE, e ela muda o que os pisos abaixo
				 * podem afirmar: com `threshold: visivel` sozinho,
				 * `isIntersecting` É a linha declarada, e decidir a saída por
				 * ele dá o MESMO resultado de decidir por `razao < visivel`. O
				 * defeito de verdade aparece quando o `0` entra na lista de
				 * faixas e a saída continua sendo decidida por `isIntersecting`:
				 * aí a linha de saída vira a razão ZERO, e o bloco que nunca sai
				 * inteiro da tela não rearma nunca. É esse mutante que os pisos
				 * plantam, na bancada e no navegador.
				 */
				entradas.push( { isIntersecting: faixa > 0, intersectionRatio: razao, target: alvo } );
			}

			if ( entradas.length > 0 ) {
				obs.retorno( entradas );
			}
		}
	}

	return {
		janela,
		documento,
		gtagChamadas,
		secoes,
		beacons() {
			return beacons;
		},
		gravacoes() {
			return gravacoes;
		},
		cargas() {
			return beacons.map( ( b ) => {
				try {
					return JSON.parse( b.corpo );
				} catch {
					return null;
				}
			} );
		},
		/*
		 * O QUE O SERVIDOR RECEBEU DE VERDADE, e a distinção passou a existir
		 * nesta release: `cargas()` é tudo o que SAIU, inclusive o que a rota
		 * recusou. Medir a sequência de ocorrências sobre o que saiu aprovaria
		 * um cliente que despacha e perde — que é exatamente o defeito.
		 */
		recebidas() {
			return beacons
				.filter( ( b ) => Number( b.status ) >= 200 && Number( b.status ) < 300 )
				.map( ( b ) => {
					try {
						return JSON.parse( b.corpo );
					} catch {
						return null;
					}
				} )
				.filter( Boolean );
		},
		eventos() {
			return janela.dataLayer.filter( ( e ) => e && 'object' === typeof e && e.event );
		},
		doNome( nome ) {
			return this.eventos().filter( ( e ) => e.event === nome );
		},
		/*
		 * ROLAR MOVE AS SEÇÕES, e é essa a mudança. Antes, `rolarAte(95)` não
		 * movia seção nenhuma: a profundidade e a interseção viviam em mundos
		 * separados, e o teste de releitura dirigia os blocos à mão. Agora a
		 * rolagem despacha o ouvinte de rolagem — síncrono, como no navegador —
		 * e só então entrega os retornos de interseção, que no navegador chegam
		 * depois.
		 */
		rolarAte( percentual ) {
			const util = documento.documentElement.scrollHeight - janela.innerHeight;

			janela.pageYOffset = Math.round( ( percentual / 100 ) * util );
			documento.documentElement.scrollTop = janela.pageYOffset;
			disparar( ouvintesWin, 'scroll', {} );
			medirInterseccoes();
		},
		/*
		 * VER E ESCONDER À MÃO CONTINUAM EXISTINDO para os testes que só
		 * precisam do bloco entrando e saindo — e eles seguem entregando o
		 * retorno SEM razão, que é o caso da entrada sintética. O que não pode
		 * mais acontecer é um teste de RELEITURA ser dirigido por eles: ali a
		 * pergunta é justamente o que o navegador entrega, e a mão é mais
		 * generosa que o navegador.
		 */
		verSecao( indice ) {
			for ( const obs of observados ) {
				const alvo = obs.alvos.find( ( a ) => a === secoes[ indice ] );

				if ( alvo ) {
					obs.retorno( [ { isIntersecting: true, target: alvo } ] );
				}
			}
		},
		/* O BLOCO SAI DO CAMPO DE VISÃO — é o que rearma a seção. */
		esconderSecao( indice ) {
			for ( const obs of observados ) {
				const alvo = obs.alvos.find( ( a ) => a === secoes[ indice ] );

				if ( alvo ) {
					obs.retorno( [ { isIntersecting: false, target: alvo } ] );
				}
			}
		},
		clicar( alvo, posicao ) {
			const ponto = posicao || {};

			disparar( ouvintesDoc, 'click', {
				target: alvo,
				clientX: ponto.x || 0,
				clientY: ponto.y || 0
			} );
		},
		erro( arquivo, linha ) {
			disparar( ouvintesWin, 'error', { filename: arquivo, lineno: linha } );
		},
		desempenhoEntrada( tipo, entradas ) {
			for ( const alvo of desempenho ) {
				if ( alvo.tipo === tipo ) {
					alvo.retorno( { getEntries: () => entradas } );
				}
			}
		},
		observadoresDeDesempenho() {
			return desempenho.map( ( d ) => d.tipo );
		},
		configDe( tipo ) {
			const achou = desempenho.find( ( d ) => d.tipo === tipo );

			return achou ? achou.config : null;
		},
		ocultar() {
			documento.visibilityState = 'hidden';
			disparar( ouvintesDoc, 'visibilitychange', {} );
		},
		/*
		 * O CICLO DE VIDA REAL DE UMA SAÍDA DE PÁGINA, e ele é DOIS eventos, não
		 * um. Numa navegação normal o navegador emite `visibilitychange` para
		 * hidden E `pagehide`, nesta ordem, no mesmo carregamento. A bancada só
		 * sabia ocultar — e por isso todo emissor ligado aos dois nunca foi
		 * exercitado no caso em que os dois acontecem, que é o caso comum.
		 */
		sair() {
			documento.visibilityState = 'hidden';
			disparar( ouvintesDoc, 'visibilitychange', {} );
			disparar( ouvintesWin, 'pagehide', {} );
		},
		soPagehide() {
			documento.visibilityState = 'hidden';
			disparar( ouvintesWin, 'pagehide', {} );
		},
		/*
		 * O CARREGAMENTO QUE MORRE — e a 1.3.4 declarou que a bancada não sabia
		 * fazer isto, porque ali `pagehide` sempre chegava. A aba encerrada
		 * pelo sistema, o aparelho sem memória, o navegador descartando a
		 * página: nenhum desses emite evento de saída nenhum. É o caso em que a
		 * única coisa que sobrevive é o que já estava GRAVADO, e sem ele o
		 * piso do pendente durável não teria contra o que falhar.
		 */
		morrer() {
			documento.visibilityState = 'hidden';
		},
		/* Quantos envios saíram por cada caminho de despacho. */
		envios( via ) {
			return beacons.filter( ( b ) => ! via || via === b.via );
		},
		/*
		 * A PÁGINA CRESCE DEPOIS DE CARREGAR — a imagem que entra, o bloco que
		 * expande. O navegador avisa pelo fim do carregamento e pelo observador
		 * de tamanho; a bancada dispara os dois, que é o que acontece de fato.
		 */
		crescerPara( altura ) {
			documento.documentElement.scrollHeight = altura;
			documento.body.scrollHeight = altura;
			documento.readyState = 'complete';

			for ( const obs of observadosDeTamanho ) {
				obs.retorno( [] );
			}

			disparar( ouvintesWin, 'load', {} );
		},
		/*
		 * A DECISÃO DO VISITANTE MUDOU no controle do rodapé, e ela muda de
		 * verdade: o portão passa a responder o contrário a partir daqui. Um
		 * portão fixo faria a bancada medir a recusa de quem nunca foi medido,
		 * que é o caso em que não há nada a apagar.
		 */
		recusar() {
			permite = false;
			disparar( ouvintesDoc, 'f3base-consentimento', {} );
		},
		aceitar() {
			permite = true;
			disparar( ouvintesDoc, 'f3base-consentimento', {} );
		},
		removidas() {
			return removidas;
		},
		aceitarBeacon() {
			recusandoBeacon = false;
		},
		voltarAVer() {
			documento.visibilityState = 'visible';
			disparar( ouvintesDoc, 'visibilitychange', {} );
		},
		elemento
	};
}

/**
 * `js.comportamento_instrumentado` — o SITE NASCE INSTRUMENTADO, medido.
 *
 * A premissa da 1.1.3, nas palavras de quem a definiu: *"o site no WordPress já
 * deve nascer instrumentado para validar e avaliar o comportamento dos usuários
 * no site."* Até a 1.1.2 este pacote emitia `generate_lead`, `form_start` e
 * `select_content` — tudo em torno da conversão. Nada dizia se a página era
 * lida, onde o visitante parava, o que ele tentava clicar nem qual era a
 * experiência real de carregamento.
 *
 * A bancada roda o carregador REAL contra a plataforma de mentira e lê o
 * `dataLayer` — exatamente o que a conta de medição receberia. As quatro
 * asserções que valem para tudo: o portão do consentimento, a ausência de dado
 * pessoal no payload, o teto por página e o slot vazio inerte.
 *
 * O PISO É O FALSO POSITIVO, e ele é o que separa esta medição de um relatório
 * poluído: duplo clique, triplo clique — o gesto de selecionar um parágrafo —,
 * cliques espalhados e cliques lentos NÃO podem produzir fricção; erro de
 * terceiro e de extensão NÃO podem produzir erro do site; e a rajada tem de
 * bater no teto declarado em vez de passar.
 *
 * @param {string} raiz Raiz do pacote.
 * @return {Object} Achados.
 */
function comportamentoInstrumentado( raiz ) {
	const alvo = entregue( raiz, 'fontes/plugin/assets/f3base-tracking.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'fontes/plugin/assets/f3base-tracking.js ausente na raiz varrida' ] };
	}

	function afirmar( ok, texto ) {
		if ( ! ok ) {
			achados.push( texto );
		}
	}

	const eventos = declaracaoDeComportamento( raiz );
	const nomes = Object.keys( eventos );

	afirmar(
		nomes.length > 0,
		'teto: fontes/plugin/dados/eventos-comportamento.tsv não declarou evento nenhum, e uma bancada sem declaração aprovaria o silêncio'
	);

	if ( 0 === nomes.length ) {
		return { achados };
	}

	function porGatilho( gatilho ) {
		const nome = nomes.find( ( n ) => eventos[ n ].gatilho === gatilho );

		return nome ? { nome, dados: eventos[ nome ] } : null;
	}

	const rolagem = porGatilho( 'rolagem' );
	const secao = porGatilho( 'interseccao' );
	const externo = porGatilho( 'clique-externo' );
	const friccao = porGatilho( 'clique-repetido' );
	const erro = porGatilho( 'erro' );
	const vital = porGatilho( 'desempenho' );

	for ( const [ rotulo, achado ] of [
		[ 'rolagem', rolagem ], [ 'interseccao', secao ], [ 'clique-externo', externo ],
		[ 'clique-repetido', friccao ], [ 'erro', erro ], [ 'desempenho', vital ]
	] ) {
		afirmar( null !== achado, 'teto: nenhum evento declarado com o gatilho "' + rotulo + '" — o coletor correspondente não tem nome e não emite nada' );
	}

	if ( ! rolagem || ! secao || ! externo || ! friccao || ! erro || ! vital ) {
		return { achados };
	}

	const comportamento = { eventos, prefixoSecao: 'f3base-secao-' };

	const dadosDiretos = {
		caminho: 'direto',
		gtm: '',
		ga4: 'G-ABCDEF1234',
		ads: { id: '', label: '' },
		meta: { pixelId: '', origem: 'https://connect.facebook.net/en_US/fbevents.js' },
		linkedin: { partnerId: '', conversionId: '', origem: 'https://snap.licdn.com/li.lms-analytics/insight.min.js' },
		origemGoogle: 'https://www.googletagmanager.com/',
		comportamento
	};

	/* TETO 1: MARCOS DE ROLAGEM — um por marco, uma vez cada, nunca em rajada. */
	const marcos = ( rolagem.dados.limiar.marcos || [] ).map( Number );
	const b1 = bancadaDeComportamento( fonte, dadosDiretos, {} );

	for ( const percentual of [ 10, 30, 55, 80, 95, 100, 100, 100 ] ) {
		b1.rolarAte( percentual );
	}

	const rolados = b1.doNome( rolagem.nome );

	afirmar(
		rolados.length === marcos.length,
		'teto: a rolagem até o fim precisa emitir exatamente ' + marcos.length + ' evento(s) — um por marco declarado, uma vez cada. Observado: ' + rolados.length
	);

	afirmar(
		JSON.stringify( rolados.map( ( e ) => Number( e[ rolagem.dados.parametros[ 0 ] ] ) ) ) === JSON.stringify( marcos ),
		'teto: os marcos emitidos não são os declarados, na ordem em que foram cruzados. Declarado: ' + marcos.join( ',' ) + '. Observado: ' + rolados.map( ( e ) => e[ rolagem.dados.parametros[ 0 ] ] ).join( ',' )
	);

	/* PISO 1: rolar de novo NÃO repete o marco. */
	const antes = b1.doNome( rolagem.nome ).length;

	b1.rolarAte( 20 );
	b1.rolarAte( 100 );

	afirmar(
		b1.doNome( rolagem.nome ).length === antes,
		'piso: rolar para cima e voltar ao fim REPETIU os marcos. Um gesto de rolagem passa por todos eles de novo, e sem a marca de visto cada ida e volta emitiria a série inteira'
	);

	/* TETO 2: SEÇÃO VISTA — nome do markup, uma vez por nome, e sem nome não mede. */
	const b2 = bancadaDeComportamento( fonte, dadosDiretos, {
		secoes: [
			'wp-block-group f3base-secao-abertura',
			'wp-block-group f3base-secao-abertura',
			'wp-block-group f3base-secao-faq',
			'wp-block-group'
		]
	} );

	b2.verSecao( 0 );
	b2.verSecao( 2 );

	const vistas = b2.doNome( secao.nome );

	afirmar(
		2 === vistas.length,
		'teto: duas seções nomeadas vistas precisam emitir dois eventos. Observado: ' + vistas.length
	);

	afirmar(
		'abertura' === vistas[ 0 ][ secao.dados.parametros[ 0 ] ] && 'faq' === vistas[ 1 ][ secao.dados.parametros[ 0 ] ],
		'teto: o nome da seção não saiu da classe declarada no markup. Observado: ' + vistas.map( ( e ) => e[ secao.dados.parametros[ 0 ] ] ).join( ',' )
	);

	b2.verSecao( 1 );

	afirmar(
		2 === b2.doNome( secao.nome ).length,
		'piso: a MESMA seção repetida na página emitiu duas vezes. A série conta seções, não elementos'
	);

	b2.verSecao( 3 );

	afirmar(
		2 === b2.doNome( secao.nome ).length,
		'piso: uma seção SEM a classe declarada foi medida. Sem nome, a seção não é medida — derivar nome de texto produziria uma série que muda sozinha na primeira revisão de copy'
	);

	/* TETO 3: LINK EXTERNO — só o host, e nunca a URL. */
	const b3 = bancadaDeComportamento( fonte, dadosDiretos, {} );
	const externoAlvo = b3.elemento( 'a', '', { href: 'https://parceiro.test/perfil/joao-silva?email=joao%40exemplo.test&token=abc123' } );
	const internoAlvo = b3.elemento( 'a', '', { href: '/contato/' } );

	b3.clicar( externoAlvo );
	b3.clicar( internoAlvo );

	const externos = b3.doNome( externo.nome );

	afirmar(
		1 === externos.length,
		'teto: o clique no link externo precisa emitir uma vez, e o interno nenhuma. Observado: ' + externos.length
	);

	afirmar(
		externos.length > 0 && 'parceiro.test' === externos[ 0 ][ externo.dados.parametros[ 0 ] ],
		'teto: o parâmetro do link externo precisa ser o HOST de destino. Observado: ' + ( externos.length ? externos[ 0 ][ externo.dados.parametros[ 0 ] ] : '(nada)' )
	);

	const cargaExterna = JSON.stringify( externos );

	for ( const proibido of [ 'joao', 'token', 'abc123', 'perfil', '@', '?' ] ) {
		afirmar(
			! cargaExterna.includes( proibido ),
			'teto: o payload do link externo carrega "' + proibido + '". Caminho e query são onde mora o identificador — /perfil/joao-silva no caminho, ?email= e ?token= na query —, e só o host responde à pergunta sem carregar nada disso. Payload: ' + cargaExterna
		);
	}

	/* TETO 4: FRICÇÃO — o limiar declarado dispara, e o uso normal NÃO. */
	const cliquesNecessarios = parseInt( friccao.dados.limiar.cliques[ 0 ], 10 );
	const janelaMs = parseInt( friccao.dados.limiar.janela_ms[ 0 ], 10 );
	const raioPx = parseInt( friccao.dados.limiar.raio_px[ 0 ], 10 );

	const b4 = bancadaDeComportamento( fonte, dadosDiretos, {} );
	const botao = b4.elemento( 'button', '' );

	for ( let i = 0; i < cliquesNecessarios; i++ ) {
		b4.clicar( botao, { x: 100, y: 200 } );
	}

	afirmar(
		1 === b4.doNome( friccao.nome ).length,
		'teto: ' + cliquesNecessarios + ' cliques no mesmo controle, no mesmo ponto e dentro da janela precisam emitir fricção uma vez. Observado: ' + b4.doNome( friccao.nome ).length
	);

	/* PISO 2: DUPLO CLIQUE — gesto normal de sistema. NÃO dispara. */
	const b5 = bancadaDeComportamento( fonte, dadosDiretos, {} );
	const botao5 = b5.elemento( 'button', '' );

	b5.clicar( botao5, { x: 10, y: 10 } );
	b5.clicar( botao5, { x: 10, y: 10 } );

	afirmar(
		0 === b5.doNome( friccao.nome ).length,
		'piso: o DUPLO CLIQUE disparou fricção. Duplo clique é gesto normal de sistema, e marcá-lo como frustração polui o relatório com o uso comum de qualquer página'
	);

	/* PISO 3: TRIPLO CLIQUE — o gesto de selecionar um parágrafo. NÃO dispara. */
	const b6 = bancadaDeComportamento( fonte, dadosDiretos, {} );
	const botao6 = b6.elemento( 'button', '' );

	b6.clicar( botao6, { x: 10, y: 10 } );
	b6.clicar( botao6, { x: 10, y: 10 } );
	b6.clicar( botao6, { x: 10, y: 10 } );

	afirmar(
		cliquesNecessarios <= 3 || 0 === b6.doNome( friccao.nome ).length,
		'piso: o TRIPLO CLIQUE disparou fricção. Triplo clique é o gesto de selecionar um parágrafo, e é o falso positivo mais comum de qualquer detector de rage click'
	);

	/* PISO 4: cliques em PONTOS DIFERENTES — percorrer uma lista. NÃO dispara. */
	const b7 = bancadaDeComportamento( fonte, dadosDiretos, {} );
	const botao7 = b7.elemento( 'button', '' );

	for ( let i = 0; i < cliquesNecessarios + 2; i++ ) {
		b7.clicar( botao7, { x: 10, y: 10 + ( i * ( raioPx + 10 ) ) } );
	}

	afirmar(
		0 === b7.doNome( friccao.nome ).length,
		'piso: cliques espalhados além do raio de ' + raioPx + 'px dispararam fricção. O mesmo ponto precisa ser o mesmo ponto, senão percorrer uma lista de links acumula cliques de lugares diferentes'
	);

	/* PISO 5: cliques em ALVOS DIFERENTES. NÃO dispara. */
	const b8 = bancadaDeComportamento( fonte, dadosDiretos, {} );

	for ( let i = 0; i < cliquesNecessarios + 2; i++ ) {
		b8.clicar( b8.elemento( 'button', '' ), { x: 10, y: 10 } );
	}

	afirmar(
		0 === b8.doNome( friccao.nome ).length,
		'piso: cliques em controles DIFERENTES no mesmo ponto dispararam fricção. Frustração é insistir no mesmo controle, e não usar a página'
	);

	/* PISO 6: clique em TEXTO — alvo não interativo. NÃO dispara. */
	const b9 = bancadaDeComportamento( fonte, dadosDiretos, {} );
	const paragrafo = b9.elemento( 'p', '' );

	for ( let i = 0; i < cliquesNecessarios + 3; i++ ) {
		b9.clicar( paragrafo, { x: 10, y: 10 } );
	}

	afirmar(
		0 === b9.doNome( friccao.nome ).length,
		'piso: cliques repetidos em um PARÁGRAFO dispararam fricção. O gesto de seleção de texto pousa em texto e não em controle, e é a recusa declarada do sinal de clique em elemento não interativo — sinal que não se sabe medir sem falso positivo é recusa declarada, nunca implementação torta'
	);

	afirmar(
		janelaMs > 0,
		'teto: a janela da fricção precisa ser um número positivo declarado. Observado: ' + janelaMs
	);

	/* TETO 5: ERRO DO SITE — e a origem é o portão. */
	const b10 = bancadaDeComportamento( fonte, dadosDiretos, {} );

	b10.erro( 'https://exemplo.test/wp-content/plugins/base-site-core-fator3/assets/f3base-leads.js?ver=1.1.3#linha', 42 );

	const erros = b10.doNome( erro.nome );

	afirmar(
		1 === erros.length,
		'teto: um erro de script de MESMA ORIGEM precisa emitir uma vez. Observado: ' + erros.length
	);

	afirmar(
		erros.length > 0 && ! String( erros[ 0 ][ erro.dados.parametros[ 0 ] ] ).includes( '?' ) &&
			! String( erros[ 0 ][ erro.dados.parametros[ 0 ] ] ).includes( '#' ),
		'teto: o arquivo do erro precisa sair como caminho, sem query e sem fragmento. Observado: ' + ( erros.length ? erros[ 0 ][ erro.dados.parametros[ 0 ] ] : '(nada)' )
	);

	/* PISO 7: erro de TERCEIRO e de AMBIENTE não viram erro do site. */
	const b11 = bancadaDeComportamento( fonte, dadosDiretos, {} );

	b11.erro( 'https://www.googletagmanager.com/gtag/js', 1 );
	b11.erro( 'chrome-extension://abcdefghijklmnop/bloqueador.js', 1 );
	b11.erro( '', 0 );

	afirmar(
		0 === b11.doNome( erro.nome ).length,
		'piso: erro de terceiro, de extensão do navegador ou sem arquivo virou erro do site. Sem a classificação de origem, um bloqueador de anúncio enche o relatório de defeito que nenhuma release nossa conserta. Observado: ' + b11.doNome( erro.nome ).length
	);

	/* PISO 8: o mesmo erro em laço bate no TETO declarado. */
	const b12 = bancadaDeComportamento( fonte, dadosDiretos, {} );

	for ( let i = 0; i < erro.dados.teto + 20; i++ ) {
		b12.erro( 'https://exemplo.test/js/app.js', 100 + i );
	}

	afirmar(
		b12.doNome( erro.nome ).length === erro.dados.teto,
		'piso: o teto de ' + erro.dados.teto + ' por página não segurou a rajada de erros. Erro em laço de render dispara milhares de vezes, e sem teto a conta de medição amostra o excesso em silêncio. Observado: ' + b12.doNome( erro.nome ).length
	);

	/* TETO 6: CORE WEB VITALS por observador NATIVO, relatados no ocultamento. */
	const b13 = bancadaDeComportamento( fonte, dadosDiretos, {} );
	const tipos = b13.observadoresDeDesempenho();

	for ( const tipo of [ 'largest-contentful-paint', 'layout-shift', 'event' ] ) {
		afirmar(
			tipos.includes( tipo ),
			'teto: o coletor não registrou PerformanceObserver para "' + tipo + '" — sem ele a métrica correspondente nunca tem valor'
		);
	}

	const configEvento = b13.configDe( 'event' );

	afirmar(
		configEvento && parseInt( vital.dados.limiar.duracao_minima_ms[ 0 ], 10 ) === configEvento.durationThreshold,
		'teto: o durationThreshold do observador de interação não é o declarado (' + vital.dados.limiar.duracao_minima_ms[ 0 ] + '). Um limiar escrito no cliente é um número que ninguém revisa junto com a declaração que ele contradiz'
	);

	afirmar(
		0 === b13.doNome( vital.nome ).length,
		'teto: um vital foi relatado ANTES do ocultamento da página. LCP, CLS e INP só têm valor final quando o visitante para de interagir, e relatar antes manda um número que ainda ia mudar'
	);

	b13.desempenhoEntrada( 'largest-contentful-paint', [ { startTime: 1834.6 } ] );
	b13.desempenhoEntrada( 'layout-shift', [ { value: 0.0723, hadRecentInput: false }, { value: 0.5, hadRecentInput: true } ] );
	b13.desempenhoEntrada( 'event', [ { interactionId: 7, duration: 148 }, { interactionId: 0, duration: 999 } ] );
	b13.ocultar();

	const vitais = b13.doNome( vital.nome );
	const declaradosVitais = vital.dados.limiar.vitais;
	const medidosPorNome = {};

	for ( const linha of vitais ) {
		medidosPorNome[ linha[ vital.dados.parametros[ 0 ] ] ] = linha[ vital.dados.parametros[ 1 ] ];
	}

	afirmar(
		vitais.length === declaradosVitais.length,
		'teto: precisam sair ' + declaradosVitais.length + ' vitais no ocultamento, um por métrica declarada. Observado: ' + vitais.length + ' (' + Object.keys( medidosPorNome ).join( ',' ) + ')'
	);

	afirmar(
		1835 === medidosPorNome.LCP,
		'teto: o LCP precisa sair como o startTime da ÚLTIMA entrada, arredondado em ms. Observado: ' + medidosPorNome.LCP
	);

	afirmar(
		0.072 === medidosPorNome.CLS,
		'teto: o CLS precisa somar só as entradas SEM hadRecentInput — deslocamento causado pelo próprio visitante não é instabilidade de layout. Esperado 0.072 (a de 0,5 tem hadRecentInput). Observado: ' + medidosPorNome.CLS
	);

	afirmar(
		148 === medidosPorNome.INP,
		'teto: o INP precisa ser a maior duração entre as entradas COM interactionId — entrada sem interactionId não é interação do visitante. Observado: ' + medidosPorNome.INP
	);

	afirmar(
		413 === medidosPorNome.TTFB,
		'teto: o TTFB precisa sair do responseStart do Navigation Timing, arredondado. Observado: ' + medidosPorNome.TTFB
	);

	b13.ocultar();

	afirmar(
		b13.doNome( vital.nome ).length === declaradosVitais.length,
		'piso: um segundo ocultamento da página relatou os vitais de novo. Uma aba que vai e volta emitiria a série inteira a cada ida'
	);

	afirmar(
		! fonte.includes( 'web-vitals' ) && ! /https:\/\/unpkg\.com|https:\/\/cdn\.jsdelivr\.net/.test( fonte ),
		'teto: o coletor de vitais carrega biblioteca externa. A política de origem declarada não admite CDN de terceiro, e o peso do carregamento é pago pelo visitante em toda página'
	);

	/* TETO 7: O PORTÃO — sem consentimento, NADA é emitido. */
	const b14 = bancadaDeComportamento( fonte, dadosDiretos, { consentimento: false, secoes: [ 'f3base-secao-abertura' ] } );

	b14.rolarAte( 100 );
	b14.verSecao( 0 );
	b14.clicar( b14.elemento( 'a', '', { href: 'https://parceiro.test/' } ) );
	b14.erro( 'https://exemplo.test/js/app.js', 1 );
	b14.ocultar();

	afirmar(
		0 === b14.eventos().length && 0 === b14.gtagChamadas.length,
		'piso: com o consentimento NEGADO a instrumentação emitiu ' + b14.eventos().length + ' evento(s). A porta é a mesma das quatro tags, e ela não tem exceção para medição de comportamento'
	);

	/* TETO 8: SLOT VAZIO — sem ID e sem container, nada é instalado. */
	const b15 = bancadaDeComportamento(
		fonte,
		Object.assign( {}, dadosDiretos, { caminho: 'nenhum', ga4: '' } ),
		{ secoes: [ 'f3base-secao-abertura' ] }
	);

	b15.rolarAte( 100 );
	b15.verSecao( 0 );
	b15.erro( 'https://exemplo.test/js/app.js', 1 );
	b15.ocultar();

	afirmar(
		0 === b15.eventos().length,
		'piso: com o caminho "nenhum" — nenhum slot de medição preenchido — a instrumentação emitiu ' + b15.eventos().length + ' evento(s). Slot vazio é inerte, e a instrumentação segue a mesma regra das tags'
	);

	/* TETO 9: o caminho do CONTAINER também instrumenta. */
	const b16 = bancadaDeComportamento(
		fonte,
		Object.assign( {}, dadosDiretos, { caminho: 'gtm', gtm: 'GTM-ABCD123', ga4: '' } ),
		{}
	);

	b16.rolarAte( 100 );

	afirmar(
		b16.doNome( rolagem.nome ).length === marcos.length,
		'teto: no caminho do CONTAINER a instrumentação não foi instalada. Aquele ramo termina em return, e instalá-la depois dele deixaria todo site com GTM sem medição de comportamento — um ramo esquecido que nada acusaria'
	);

	/* TETO 10: TETO SOMADO e payload sem chave fora da declaração. */
	let tetoSomado = 0;

	for ( const nome of nomes ) {
		tetoSomado += eventos[ nome ].teto;
	}

	afirmar(
		tetoSomado > 0 && tetoSomado <= 100,
		'teto: o teto somado de eventos de comportamento por página é ' + tetoSomado + '. Ele precisa ser um número declarado e modesto — sem teto, uma única página faz o volume de um dia e a conta de medição amostra o excesso sem dizer o que perdeu'
	);

	const todosOsEventos = []
		.concat( b1.eventos(), b2.eventos(), b3.eventos(), b4.eventos(), b10.eventos(), b13.eventos() );

	for ( const linha of todosOsEventos ) {
		const declarado = eventos[ linha.event ];

		afirmar(
			undefined !== declarado,
			'teto: o evento "' + linha.event + '" chegou ao dataLayer e não está na declaração. Nome fora do arquivo único é uma série histórica que ninguém sabe ler'
		);

		if ( ! declarado ) {
			continue;
		}

		for ( const chave of Object.keys( linha ) ) {
			afirmar(
				'event' === chave || declarado.parametros.includes( chave ),
				'teto: o evento "' + linha.event + '" carrega o parâmetro "' + chave + '", que não está declarado. A porta é a lista declarada, e não a boa intenção de quem escreve o coletor'
			);
		}
	}

	return { achados };
}

/**
 * `js.resumo_da_sessao` — o SEGUNDO DESTINO, medido no que sai da aba.
 *
 * A pergunta da release: *"o site nasce instrumentado, onde posso ver os dados
 * desta instrumentação."* A resposta é uma tabela dentro do WordPress, e o que
 * a alimenta é UM envio por sessão, ao sair da página. O que esta bancada mede
 * é exatamente o que o servidor receberia.
 *
 * OS PISOS SÃO AS QUATRO RECUSAS: sem consentimento nada sai; nenhum
 * identificador de visitante é gravado em lugar nenhum do navegador; o caminho
 * vai sem query mesmo quando a URL tem uma; e nenhum nome de evento declarado
 * viaja no payload — o cliente manda o gatilho, e quem resolve o nome é o
 * servidor. O quinto é o do envio duplo: a aba que vai e volta manda uma vez.
 *
 * @param {string} raiz Raiz do pacote.
 * @return {Object} Achados.
 */
function resumoDaSessao( raiz ) {
	const alvo = entregue( raiz, 'fontes/plugin/assets/f3base-tracking.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'fontes/plugin/assets/f3base-tracking.js ausente na raiz varrida' ] };
	}

	function afirmar( ok, texto ) {
		if ( ! ok ) {
			achados.push( texto );
		}
	}

	const eventos = declaracaoDeComportamento( raiz );
	const nomes = Object.keys( eventos );

	afirmar(
		nomes.length > 0,
		'teto: a declaração de eventos de comportamento está vazia, e sem ela esta bancada aprovaria o silêncio'
	);

	if ( 0 === nomes.length ) {
		return { achados };
	}

	let tetoSomado = 0;

	for ( const nome of nomes ) {
		tetoSomado += eventos[ nome ].teto;
	}

	const comportamento = {
		eventos: {},
		prefixoSecao: 'f3base-secao-'
	};

	for ( const nome of nomes ) {
		comportamento.eventos[ nome ] = eventos[ nome ];
	}

	function dadosCom( extra, resumo ) {
		return Object.assign(
			{
				caminho: 'direto',
				gtm: '',
				ga4: 'G-BANCADA01',
				ads: { id: '', label: '' },
				meta: { pixelId: '', origem: 'https://connect.facebook.net/en_US/fbevents.js' },
				linkedin: { partnerId: '', conversionId: '', origem: 'https://snap.licdn.com/li.lms-analytics/insight.min.js' },
				origemGoogle: 'https://www.googletagmanager.com/',
				comportamento,
				resumo: Object.assign(
					{ ativo: true, endpoint: 'https://exemplo.test/wp-json/f3base/v1/comportamento', esquecer: 'https://exemplo.test/wp-json/f3base/v1/comportamento/esquecer', token: '1700000000.assinatura', maximo: tetoSomado, maximoLog: 180, maximoVisita: 300, politica: 'pre-aprovado' },
					resumo || {}
				)
			},
			extra || {}
		);
	}

	const secoes = [ 'f3base-secao-abertura' ];

	/* TETO 1: uma sessão, um envio, e o payload é o que o servidor recebe. */
	const b1 = bancadaDeComportamento( fonte, dadosCom(), { secoes } );

	b1.rolarAte( 100 );
	b1.verSecao( 0 );
	b1.clicar( b1.elemento( 'a', '', { href: 'https://parceiro.test/caminho/?u=joao@exemplo.test' } ) );
	b1.erro( 'https://exemplo.test/js/app.js', 42 );
	b1.desempenhoEntrada( 'largest-contentful-paint', [ { startTime: 1834.6 } ] );
	b1.ocultar();

	afirmar(
		1 === b1.beacons().length,
		'teto: a sessão precisa produzir EXATAMENTE um envio ao sair da página. Observado: ' + b1.beacons().length
	);

	const carga = b1.cargas()[ 0 ];

	afirmar(
		carga && 'object' === typeof carga,
		'teto: o corpo enviado não é um objeto analisável'
	);

	if ( ! carga ) {
		return { achados };
	}

	/*
	 * O CORPO É FECHADO, e o conjunto cresceu na 1.2.0 do site-core: entraram o
	 * apelido do visitante, o da visita e o REGISTRO com carimbo de tempo. A
	 * asserção continua sendo de conjunto exato — é ela que impede um campo
	 * novo, e portanto um dado novo, de viajar sem que ninguém tenha decidido
	 * que podia. Trocá-la por "contém pelo menos" seria abrir a porta que ela
	 * existe para fechar.
	 */
	const camposDoCorpo = Object.keys( carga ).sort().join( ',' );

	afirmar(
		'caminho,cortados,eventos,lote,metricas,origem,sessao,token,visitante' === camposDoCorpo,
		'teto: o corpo precisa ter exatamente token, o SELO do lote, a ORIGEM temporal do carregamento, caminho, a lista de totais, os dois apelidos, o registro e a contagem do que o cliente cortou — e nada mais. Observado: ' + camposDoCorpo
	);

	/*
	 * A ORIGEM É O QUE CONSERTA O CARIMBO, e ela precisa ser um instante
	 * plausível — não zero, não a hora do despacho.
	 *
	 * O DEFEITO QUE ELA FECHA: o servidor gravava cada linha com a hora em que
	 * o LOTE CHEGOU, e um lote carrega dezenas de acionamentos acumulados ao
	 * longo de segundos ou minutos de navegação. Medido no banco de um site
	 * real: 33 acionamentos com `ms` de 724 a 10816 gravados no mesmo segundo,
	 * e na tela 25 linhas seguidas com o mesmo `09:22:25`. Com a origem no
	 * corpo, o carimbo passa a ser `origem + ms`.
	 *
	 * ELA VAI UMA VEZ POR LOTE e nunca dentro de cada linha: o corpo tem teto
	 * de bytes, e repetir o mesmo número em cada acionamento gastaria esse teto
	 * para transportar o mesmo valor dezenas de vezes.
	 */
	afirmar(
		'number' === typeof carga.origem && isFinite( carga.origem ) && carga.origem > 0 && Number.isInteger( carga.origem ),
		'teto: a origem temporal precisa viajar no corpo como inteiro positivo de milissegundos — é dela que sai o carimbo de cada linha. Observado: ' + JSON.stringify( carga.origem )
	);

	afirmar(
		carga.eventos.every( ( linha ) => ! Object.prototype.hasOwnProperty.call( linha, 'origem' ) ),
		'piso: a origem viajou DENTRO de cada linha do registro. Ela é do lote inteiro, e repeti-la por linha gasta o teto de bytes do corpo para mandar o mesmo número dezenas de vezes'
	);

	/*
	 * O SELO DO LOTE É SORTEADO E TEM A FORMA FECHADA DO PSEUDÔNIMO. Ele entrou
	 * na 1.3.5 do site-core porque o cliente passou a CONFIRMAR a entrega em
	 * vez de confiar no enfileiramento do beacon — e confirmar implica
	 * reenviar. Sem o selo, uma resposta perdida no caminho de volta faria o
	 * mesmo lote ser gravado duas vezes; com ele, o servidor reconhece a
	 * repetição e responde 2xx sem somar de novo.
	 *
	 * ELE NÃO É DERIVADO DE NADA, como os outros dois: derivado de qualquer
	 * coisa do aparelho seria fingerprint entrando por um campo novo.
	 */
	afirmar(
		/^[a-f0-9]{32}$/.test( String( carga.lote ) ),
		'teto do selo: o lote saiu com o selo "' + carga.lote + '", que não é um hexadecimal sorteado de 32 caracteres'
	);

	afirmar(
		carga.lote !== carga.sessao && carga.lote !== carga.visitante,
		'piso do selo: o selo do lote repetiu o apelido do visitante ou o da visita. São coisas diferentes — o selo identifica UM lote dentro de uma visita, e igualá-lo à visita faria o servidor recusar o segundo lote dela como repetição, apagando tudo o que veio depois do primeiro'
	);

	/*
	 * O APELIDO É SORTEADO E TEM FORMA FECHADA. Um valor fora dela seria
	 * derivado de alguma coisa — e derivado de alguma coisa é fingerprint.
	 */
	afirmar(
		/^[a-f0-9]{32}$/.test( String( carga.visitante ) ) && /^[a-f0-9]{32}$/.test( String( carga.sessao ) ),
		'teto do apelido: o visitante ("' + carga.visitante + '") ou a visita ("' + carga.sessao + '") não são hexadecimais sorteados de 32 caracteres'
	);

	afirmar(
		carga.visitante !== carga.sessao,
		'piso do apelido: o apelido do visitante e o da visita são o MESMO valor. São coisas diferentes — um atravessa visitas e o outro não —, e igualá-los faria toda visita parecer um visitante novo, ou todo visitante parecer uma visita só'
	);

	afirmar(
		'/pagina/' === carga.caminho,
		'piso do dado pessoal: o caminho enviado foi "' + carga.caminho + '". A URL da bancada tem query com utm_content e e-mail de propósito: é ali que a campanha de outra pessoa cola o identificador do lead, e por isso o que viaja é o pathname'
	);

	/* PISO: nenhum nome declarado de evento viaja no cliente. */
	const bruto = JSON.stringify( carga );

	for ( const nome of nomes ) {
		afirmar(
			! bruto.includes( nome ),
			'piso da declaração: o nome de evento "' + nome + '" viajou no payload. O cliente manda o GATILHO e quem resolve o nome é o servidor — é isso que permite renomear num lugar só sem quebrar a série histórica'
		);
	}

	for ( const linha of carga.metricas ) {
		afirmar(
			['gatilho','detalhe','contagem','soma','amostra'].every(k => Object.keys(linha).includes(k) || k === 'amostra') && Object.keys(linha).every(k => ['gatilho','detalhe','contagem','soma','amostra'].includes(k)),
			'teto: cada total precisa trazer gatilho, detalhe, contagem e soma. Observado: ' + Object.keys( linha ).join( ',' )
		);

		afirmar(
			nomes.some( ( n ) => eventos[ n ].gatilho === linha.gatilho ),
			'teto: o total chegou com o gatilho "' + linha.gatilho + '", que não está na declaração'
		);

		afirmar(
			'' === linha.detalhe || /^[A-Za-z0-9][A-Za-z0-9._-]{0,59}$/.test( linha.detalhe ),
			'piso do dado pessoal: o detalhe "' + linha.detalhe + '" está fora do alfabeto fechado. Barra, arroba, dois-pontos e espaço ficam de fora porque é por eles que entram caminho de arquivo, endereço e texto livre'
		);
	}

	/* PISO: o erro entra como CONTAGEM, e o arquivo dele não viaja. */
	afirmar(
		! bruto.includes( 'app.js' ) && ! bruto.includes( '/js/' ),
		'piso do dado pessoal: o arquivo do erro de JavaScript viajou no resumo. A página já é a chave; o arquivo interpolado é onde mora o valor que o titular digitou'
	);

	afirmar(
		! bruto.includes( '@' ) && ! bruto.includes( 'parceiro.test/' ),
		'piso do dado pessoal: o payload carrega caminho ou endereço. Do link externo sai o HOST e nada mais'
	);

	/* TETO: o host do link externo entra, e entra inteiro. */
	afirmar(
		carga.metricas.some( ( m ) => 'parceiro.test' === m.detalhe ),
		'teto: o host do link externo não entrou no resumo, e sem ele não há como responder para onde o tráfego sai'
	);

	/* TETO: o vital entrou COM valor — o resumo é despachado DEPOIS do relato. */
	const vital = carga.metricas.find( ( m ) => 'LCP' === m.detalhe );

	afirmar(
		vital && 1835 === vital.soma && 1 === vital.contagem,
		'teto da ordem: o vital não entrou no resumo com o valor medido. Os vitais são relatados no primeiro ocultamento da página, e um ouvinte de envio instalado antes do deles despacharia a sessão sem LCP, CLS, INP e TTFB — para sempre e sem erro nenhum'
	);

	/*
	 * PISO DO ARMAZENAMENTO — a regra MUDOU na 1.2.0 do site-core, e a mudança
	 * está declarada aqui em vez de a asserção ter sido apagada.
	 *
	 * Até a 1.1.1 a regra era ZERO gravação: a sessão vivia na memória da aba e
	 * nada do visitante tocava o navegador. Com "mantenha os dados separados
	 * por visitante" essa regra deixou de ser possível — separar por visitante
	 * exige um apelido que sobreviva à visita, e sobreviver à visita é ser
	 * gravado. O que a asserção protegia continua protegido, e agora ela é
	 * ESPECÍFICA em vez de absoluta:
	 *
	 * - UMA gravação, e uma só;
	 * - sob a chave declarada, e nenhuma outra;
	 * - no armazenamento local, nunca em COOKIE — cookie viaja em toda
	 *   requisição, inclusive para o CDN, e um identificador que viaja é um
	 *   identificador que vaza;
	 * - com valor hexadecimal sorteado, e nada que se pareça com dado de
	 *   pessoa.
	 *
	 * É a diferença entre "não guardamos nada" e "guardamos exatamente isto".
	 */
	/*
	 * O CONJUNTO DE CHAVES É DECLARADO, e cresceu na 1.3.0 do site-core: a
	 * VISITA passou a atravessar páginas, e atravessar páginas é ser gravada.
	 * A regra não afrouxou — ela continua sendo um conjunto EXATO, agora de
	 * duas chaves, cada uma com a forma do valor conferida. É a diferença entre
	 * "guardamos exatamente isto" e "guardamos o que for preciso".
	 */
	const chavesAutorizadas = [ 'f3base_sessao', 'f3base_visitante' ];
	const gravadas = b1.gravacoes();
	const chavesGravadas = [ ...new Set( gravadas.map( ( g ) => g.chave ) ) ].sort();

	afirmar(
		JSON.stringify( chavesGravadas ) === JSON.stringify( chavesAutorizadas ),
		'piso do identificador: o cliente gravou ' + JSON.stringify( chavesGravadas ) + ' no navegador, e as chaves autorizadas são ' +
			JSON.stringify( chavesAutorizadas ) + '. Toda outra é dado do visitante deixado no aparelho dele sem que ninguém tenha decidido que podia'
	);

	afirmar(
		gravadas.every( ( g ) => 'localStorage' === g.onde ),
		'piso do identificador: alguma gravação foi para fora do localStorage. Cookie viaja em toda requisição, inclusive para o CDN e para todo subdomínio: um identificador em cookie é um identificador que vaza sem ninguém pedir'
	);

	const doVisitante = gravadas.find( ( g ) => 'f3base_visitante' === g.chave );
	/*
	 * A ÚLTIMA GRAVAÇÃO DA VISITA, e não a primeira. O registro é reescrito a
	 * cada travessia contada, e a primeira gravação é a do instante em que a
	 * visita nasce — com o contador ainda vazio. Medir por ela aprovaria um
	 * contador que nunca contasse nada.
	 */
	const daVisita = gravadas.filter( ( g ) => 'f3base_sessao' === g.chave ).pop();

	afirmar(
		doVisitante && /^[a-f0-9]{32}$/.test( String( doVisitante.valor ) ),
		'piso do identificador: o apelido do visitante gravado não é um hexadecimal sorteado de 32 caracteres. Valor derivado de qualquer coisa do aparelho é fingerprint, e fingerprint é exatamente o que o apelido sorteado existe para não ser'
	);

	/*
	 * O REGISTRO DA VISITA guarda o apelido, o quanto ela já gastou do teto, o
	 * CONTADOR de travessias, o que já foi CORTADO e quando ela foi vista — e
	 * NADA MAIS. Um campo a mais aqui seria dado do visitante guardado no
	 * aparelho dele sem passar por decisão nenhuma.
	 *
	 * OS DOIS CAMPOS NOVOS SÃO DA 1.3.4, e cada um está aqui por um motivo
	 * escrito: `travessias` é o contador por `caminho|gatilho|detalhe` que faz
	 * a segunda passagem pelo mesmo bloco sair como 2ª depois de o visitante
	 * trocar de página — sem ele, a contagem morre em toda navegação e o
	 * relatório diz "primeira vez" três vezes seguidas. `cortadas` é o
	 * excedente ainda não despachado, e ele acompanha o contador porque o teto
	 * que ele conta é o da VISITA.
	 *
	 * E NENHUM DOS DOIS É DADO NOVO SOBRE A PESSOA: a chave é o caminho de uma
	 * página deste site — que o histórico do próprio navegador já tem —, o
	 * gatilho declarado e um detalhe que passa pelo alfabeto fechado de
	 * `detalheDe`; texto livre, query e mensagem não entram. O registro inteiro
	 * é removido do aparelho na recusa, com o apelido, pela mesma chamada.
	 */
	let campoDaVisita = [];

	try {
		campoDaVisita = Object.keys( JSON.parse( String( ( daVisita || {} ).valor || '{}' ) ) ).sort();
	} catch {
		campoDaVisita = [ 'ilegível' ];
	}

	afirmar(
		JSON.stringify( campoDaVisita ) === JSON.stringify( [ 'acumulado', 'cortadas', 'gastas', 'id', 'pendentes', 'travessias', 'visto' ] ),
		'piso do identificador: o registro da visita guarda ' + JSON.stringify( campoDaVisita ) +
			', e o declarado é o apelido, o quanto ela já gastou do teto, o contador de travessias, o que já foi cortado, o acumulado ainda não selado, os lotes ainda não confirmados e quando ela foi vista. Campo a mais é dado guardado no aparelho de alguém sem decisão nenhuma por trás'
	);

	/*
	 * OS DOIS CAMPOS NOVOS SÃO DA 1.3.5, e cada um está aqui por um motivo
	 * escrito. Na 1.3.4 o CONTADOR virou durável — gravado na hora, a cada
	 * travessia — e a LINHA ficou volátil, descartada no primeiro `true` do
	 * beacon. Todo lote que não chegava avançava o contador sem produzir linha:
	 * medido na visita `8cac18da`, `comando-unico` saiu com as ocorrências 1 e
	 * 3, e a 2 não existe em lugar nenhum. Estes dois campos são a metade que
	 * dá à linha a MESMA durabilidade do contador:
	 *
	 * - `acumulado` é o que ainda não foi selado, com o caminho a que pertence.
	 *   Ele sobrevive ao carregamento que morre SEM evento de saída nenhum — a
	 *   aba encerrada, o aparelho sem memória, o navegador descartando a
	 *   página —, que é exatamente o caso em que um lote selado só na saída
	 *   nunca chega a ser selado.
	 * - `pendentes` é a fila de lotes já selados e ainda não confirmados. Ele
	 *   sobrevive ao despacho que não chega.
	 *
	 * E NENHUM DOS DOIS É DADO NOVO SOBRE A PESSOA. O que eles guardam é
	 * exatamente o que já viajava no corpo despachado — gatilho declarado,
	 * detalhe pelo alfabeto fechado, caminho de uma página deste site, carimbo
	 * relativo ao carregamento —, agora esperando confirmação em vez de
	 * esperando o ocultamento. Os dois são removidos do aparelho na recusa,
	 * com o apelido, pela mesma chamada.
	 */
	let acumuladoDaVisita = {};

	try {
		acumuladoDaVisita = JSON.parse( String( ( daVisita || {} ).valor || '{}' ) ).acumulado || {};
	} catch {
		acumuladoDaVisita = {};
	}

	afirmar(
		JSON.stringify( Object.keys( acumuladoDaVisita ).sort() ) === JSON.stringify( [ 'caminho', 'eventos', 'metricas' ] ),
		'piso do acumulado guardado: ele traz ' + JSON.stringify( Object.keys( acumuladoDaVisita ).sort() ) +
			', e o declarado é o caminho a que ele pertence, o registro e os totais. O CAMINHO é obrigatório: o carregamento seguinte pode ser de outra página, e selar linhas de uma sob o caminho de outra grava a passagem numa página e a atribui a outra, sem erro nenhum e com a tabela parecendo certa'
	);
	let filaDaVisita = [];

	try {
		filaDaVisita = JSON.parse( String( ( daVisita || {} ).valor || '{}' ) ).pendentes || [];
	} catch {
		filaDaVisita = [];
	}

	const campoDoLote = filaDaVisita.length > 0 ? Object.keys( filaDaVisita[ 0 ] ).sort() : [];

	afirmar(
		0 === filaDaVisita.length ||
			JSON.stringify( campoDoLote ) === JSON.stringify( [ 'caminho', 'cortados', 'eventos', 'id', 'metricas', 'nascido', 'origem' ] ),
		'piso do pendente guardado: o lote guardado no aparelho traz ' + JSON.stringify( campoDoLote ) +
			', e o declarado é o selo, o instante em que ele nasceu, a ORIGEM temporal do carregamento que o produziu, o caminho, os totais, o registro e o que já foi cortado. Campo a mais aqui é dado do visitante deixado no navegador dele sem decisão nenhuma por trás'
	);

	/*
	 * A ORIGEM ESTÁ DENTRO DO SELO, e é isso que a faz sobreviver à fila.
	 *
	 * Um lote que não conseguiu ser entregue parte no carregamento SEGUINTE,
	 * que tem outra origem — a dele. Lida na hora do despacho, a origem seria a
	 * da página errada, e as linhas do lote retomado sairiam carimbadas no
	 * futuro delas. Gravada aqui, ela é a do carregamento que produziu aquelas
	 * linhas, e continua sendo depois de qualquer número de retentativas.
	 *
	 * ELA É DIFERENTE DE `nascido`, e os dois convivem: `nascido` é o instante
	 * do SELAMENTO, e é dele que sai o vencimento do pendente; a origem é o
	 * instante do CARREGAMENTO, e é dela que sai o carimbo de cada linha.
	 */
	afirmar(
		0 === filaDaVisita.length ||
			( 'number' === typeof filaDaVisita[ 0 ].origem && filaDaVisita[ 0 ].origem > 0 && filaDaVisita[ 0 ].origem <= filaDaVisita[ 0 ].nascido ),
		'piso da origem selada: o lote pendente guardou origem ' + JSON.stringify( filaDaVisita.length > 0 ? filaDaVisita[ 0 ].origem : null ) +
			' contra selamento ' + JSON.stringify( filaDaVisita.length > 0 ? filaDaVisita[ 0 ].nascido : null ) +
			'. A origem é o instante do CARREGAMENTO e o selamento é sempre igual ou posterior a ele — se ela vier zerada ou depois do selo, o lote retomado será carimbado pela página que o encontrou'
	);

	/*
	 * O CONTADOR NÃO GUARDA TEXTO LIVRE. A chave é `caminho|gatilho|detalhe`, e
	 * o detalhe passa pelo mesmo alfabeto fechado do payload. Sem esta
	 * asserção, o dia em que alguém montasse a chave com o texto de um título
	 * ou com a URL inteira deixaria dado do visitante no aparelho dele sem que
	 * nada acusasse — e o piso do payload, que varre o corpo despachado, não
	 * enxerga o que fica gravado no navegador.
	 */
	let contadorDaVisita = {};

	try {
		contadorDaVisita = JSON.parse( String( ( daVisita || {} ).valor || '{}' ) ).travessias || {};
	} catch {
		contadorDaVisita = {};
	}

	const chaveTorta = Object.keys( contadorDaVisita ).filter(
		( chave ) => ! /^\/[A-Za-z0-9/_\-.~%]*\|[a-z-]+\|[A-Za-z0-9._-]*$/.test( chave )
	);

	afirmar(
		0 === chaveTorta.length,
		'piso do contador guardado: ' + JSON.stringify( chaveTorta ) + ' não tem a forma caminho|gatilho|detalhe com o alfabeto fechado. ' +
			'A chave fica GRAVADA no aparelho do visitante, e o piso que varre o corpo despachado não a enxerga: texto livre, query ou mensagem de erro entrando aqui é dado do titular deixado no navegador dele sem decisão nenhuma por trás'
	);

	afirmar(
		Object.keys( contadorDaVisita ).length > 0 &&
			Object.values( contadorDaVisita ).every( ( n ) => Number.isInteger( n ) && n > 0 ),
		'piso do contador guardado: o contador saiu ' + JSON.stringify( contadorDaVisita ) +
			' — ele precisa existir e ser inteiro positivo. É dele que sai a coluna "vez" da tabela, e um valor que não é contagem chega à tela como "NaNª"'
	);

	/* PISO: a aba que vai e volta manda UMA vez. */
	b1.ocultar();

	afirmar(
		1 === b1.beacons().length,
		'piso do envio duplo: um segundo ocultamento da página mandou o resumo de novo. Observado: ' + b1.beacons().length + ' envio(s)'
	);

	/* PISO DO CONSENTIMENTO: negado, nada sai — nem para a conta, nem para cá. */
	const b2 = bancadaDeComportamento( fonte, dadosCom(), { secoes, consentimento: false } );

	b2.rolarAte( 100 );
	b2.verSecao( 0 );
	b2.ocultar();

	afirmar(
		0 === b2.beacons().length && 0 === b2.eventos().length,
		'piso do consentimento: com o consentimento NEGADO saíram ' + b2.beacons().length + ' envio(s) e ' + b2.eventos().length + ' evento(s). A porta do resumo é a mesma das quatro tags, e ela não tem exceção'
	);

	/* PISO DO RESUMO DESLIGADO: nada é acumulado e nada é enviado. */
	const b3 = bancadaDeComportamento( fonte, dadosCom( {}, { ativo: false, endpoint: '' } ), { secoes } );

	b3.rolarAte( 100 );
	b3.ocultar();

	afirmar(
		0 === b3.beacons().length,
		'piso do desligado: com o resumo desligado no servidor o cliente enviou assim mesmo'
	);

	afirmar(
		b3.eventos().length > 0,
		'teto da independência: com o resumo desligado a conta de medição parou de receber. Os dois destinos são independentes — desligar o quadro do site não pode desligar o Google Analytics'
	);

	/* TETO DO SEGUNDO DESTINO: sem ID nenhum, o dataLayer fica vazio e o resumo sai. */
	const b4 = bancadaDeComportamento( fonte, dadosCom( { caminho: 'nenhum', ga4: '' } ), { secoes } );

	b4.rolarAte( 100 );
	b4.verSecao( 0 );
	b4.ocultar();

	afirmar(
		0 === b4.eventos().length && 0 === b4.gtagChamadas.length,
		'piso do slot vazio: sem ID de medição a instrumentação empurrou ' + b4.eventos().length + ' evento(s) no dataLayer. Slot vazio continua inerte para a conta de medição — alimentar um container que ninguém carregou é mandar dados para uma conta que este pacote nunca soube que existia'
	);

	afirmar(
		1 === b4.beacons().length && b4.cargas()[ 0 ].metricas.length > 0,
		'teto do segundo destino: sem ID de medição o resumo do próprio site não foi enviado. Era exatamente este o buraco da 1.1.3 — com o slot vazio os eventos não existiam em lugar nenhum'
	);

	/*
	 * O CAMINHO DE RESERVA CONTINUA ENVIANDO — e este é o piso 5 desta release.
	 *
	 * Um conserto que só funcionasse no navegador moderno e emudecesse o antigo
	 * seria pior que o defeito: o site pararia de medir uma fatia inteira do
	 * público sem que nada acusasse, porque tela vazia e tela sem visitante são
	 * a mesma tela. Sem `fetch` com `keepalive`, o despacho acontece por
	 * `sendBeacon` — degradado e declarado, mas acontece.
	 *
	 * SÃO DOIS CENÁRIOS, e os dois precisam existir: o navegador sem `fetch`, e
	 * o navegador que TEM `fetch` sem `keepalive` — que é o pior, porque ali a
	 * requisição seria CANCELADA na saída da página. É `keepalive`, e não
	 * `fetch`, que o cliente procura.
	 */
	for ( const semConfirmacao of [ { fetch: false }, { keepalive: false } ] ) {
		const b5a = bancadaDeComportamento( fonte, dadosCom(), Object.assign( { secoes }, semConfirmacao ) );

		b5a.rolarAte( 100 );
		b5a.verSecao( 0 );
		b5a.sair();

		const rotulo = false === semConfirmacao.fetch ? 'sem fetch' : 'com fetch e sem keepalive';

		afirmar(
			1 === b5a.envios( 'beacon' ).length && 0 === b5a.envios( 'fetch' ).length,
			'PISO do caminho de reserva (' + rotulo + '): o navegador que não sabe confirmar entrega despachou ' +
				b5a.envios( 'beacon' ).length + ' envio(s) por beacon e ' + b5a.envios( 'fetch' ).length +
				' por fetch. Sem confirmação o envio continua acontecendo pelo beacon: um conserto que emudece o navegador antigo é pior que o defeito, porque tela vazia e tela sem visitante são a mesma tela'
		);

		const cargaDeReserva = b5a.cargas().filter( Boolean )[ 0 ] || {};

		afirmar(
			( cargaDeReserva.eventos || [] ).length > 0 && /^[a-f0-9]{32}$/.test( String( cargaDeReserva.lote ) ),
			'PISO do caminho de reserva (' + rotulo + '): o lote despachado pelo beacon saiu sem registro ou sem selo. ' +
				'Ele não sabe se chegou — essa é a perda declarada deste caminho —, mas as outras duas metades valem aqui do mesmo jeito: ' +
				'o pendente é GRAVADO antes do despacho, e o selo impede que a retentativa conte duas vezes'
		);

		/*
		 * E A PERDA DESTE CAMINHO É DECLARADA, não escondida: aceito significa
		 * ENFILEIRADO, e o lote é esquecido sobre isso. Medir que ele foi
		 * esquecido é medir a declaração — se um dia alguém a trocar por
		 * "guarda até confirmar", este caminho passaria a reenviar para sempre
		 * um lote que ninguém pode confirmar.
		 */
		let filaDeReserva = [];

		try {
			filaDeReserva = JSON.parse(
				String( ( b5a.gravacoes().filter( ( g ) => 'f3base_sessao' === g.chave ).pop() || {} ).valor || '{}' )
			).pendentes || [];
		} catch {
			filaDeReserva = [];
		}

		afirmar(
			0 === filaDeReserva.length,
			'PISO da perda declarada (' + rotulo + '): o lote aceito pelo beacon continuou pendente — sobraram ' + filaDeReserva.length +
				'. Neste caminho não há como saber se ele chegou, e reter o que não se pode confirmar é uma fila que nunca drena'
		);
	}

	/* PISO DA MUDEZ TOTAL: sem NENHUM dos dois caminhos, nada sai e nada quebra. */
	const b5 = bancadaDeComportamento( fonte, dadosCom(), { secoes, beacon: false, fetch: false } );

	b5.rolarAte( 100 );
	b5.ocultar();

	afirmar(
		0 === b5.beacons().length,
		'piso da perda declarada: sem fetch e sem sendBeacon alguma coisa foi enviada assim mesmo'
	);

	afirmar(
		b5.eventos().length > 0,
		'teto da perda declarada: sem caminho de envio nenhum a instrumentação inteira parou. A perda é do resumo da sessão, e só dele'
	);

	/* TETO DO TETO: a sessão não manda mais linhas que o teto somado declarado. */
	const b6 = bancadaDeComportamento( fonte, dadosCom( {}, { maximo: 2 } ), { secoes } );

	b6.rolarAte( 100 );
	b6.verSecao( 0 );
	b6.clicar( b6.elemento( 'a', '', { href: 'https://parceiro.test/' } ) );
	b6.ocultar();

	afirmar(
		b6.cargas()[ 0 ] && b6.cargas()[ 0 ].metricas.length <= 2,
		'teto do teto: a sessão mandou mais linhas que o máximo publicado pelo servidor. O teto é o mesmo somatório declarado, e ele existe para que o descarte seja nosso'
	);


	/*
	 * O APELIDO NASCE COM A POLÍTICA, e os quatro casos abaixo são a regra
	 * inteira. Ela é a da 1.0.1, e esta release a restaurou por decisão de quem
	 * opera o produto: houve uma versão que exigia, no modo pré-aprovado, o
	 * banner de primeira visita ligado para o apelido poder nascer, e ela deixava
	 * o site cego POR OMISSÃO — agregado somando, registro detalhado inexistente
	 * — sem que a política do site tivesse mudado.
	 *
	 * POR QUE A POLÍTICA BASTA. Ela é decisão de projeto declarada por quem
	 * implanta o site, o controle de recusa existe no rodapé de TODA página
	 * publicada, e a política de privacidade descreve a coleta. O que estava
	 * mesmo errado era uma FRASE da tela Medição, que afirmava consentimento onde
	 * havia política; quem mede a frase é `medicao.menu_proprio`.
	 *
	 * OS QUATRO CASOS:
	 *
	 * 1. PRÉ-APROVADO e ninguém decidiu nada: o portão permite, e o apelido nasce
	 *    já no primeiro carregamento.
	 * 2. NEGATIVA POR PADRÃO e ninguém decidiu nada: o portão nega, e não nasce
	 *    apelido nenhum. O que se perde ali é a medição inteira, e não só o
	 *    registro detalhado — a porta do resumo é a mesma das quatro tags.
	 * 3. RECUSA no controle do rodapé: o apelido é apagado do navegador E a
	 *    exclusão do registro é pedida ao servidor, na mesma ação.
	 * 4. ACEITE depois da negativa: o apelido nasce no instante da decisão, sem
	 *    esperar a navegação seguinte.
	 */
	const apelidoAntigo = '0123456789abcdef0123456789abcdef';

	/* CASO 1: pré-aprovado, sem decisão nenhuma — o apelido nasce na chegada. */
	const bPreAprovado = bancadaDeComportamento( fonte, dadosCom( {}, { politica: 'pre-aprovado' } ), { secoes } );

	bPreAprovado.sair();

	const cargaPreAprovada = bPreAprovado.cargas().filter( Boolean )[ 0 ] || {};

	afirmar(
		bPreAprovado.gravacoes().some( ( g ) => 'f3base_visitante' === g.chave ) &&
			/^[a-f0-9]{32}$/.test( String( cargaPreAprovada.visitante || '' ) ),
		'TETO do caso pré-aprovado: com a política pré-aprovada e ninguém tendo decidido nada, o apelido não nasceu no primeiro carregamento — o corpo levou visitante "' +
			String( cargaPreAprovada.visitante || '' ) + '". A política pré-aprovada É a autorização declarada do projeto, e amarrar o apelido a um banner deixa o site sem registro detalhado sem que a política tenha mudado'
	);

	afirmar(
		Array.isArray( cargaPreAprovada.metricas ) && cargaPreAprovada.metricas.length > 0,
		'PISO do agregado (pré-aprovado): o corpo despachado não levou totais nenhum. O agregado é o que sobrevive a toda degradação deste cliente, e mediar o apelido sem ele mediria a metade errada'
	);

	/* CASO 2: negativa por padrão, sem decisão — o portão nega, e nada nasce. */
	const bNegativaPorPadrao = bancadaDeComportamento(
		fonte,
		dadosCom( {}, { politica: 'negado' } ),
		{ secoes, consentimento: false }
	);

	bNegativaPorPadrao.sair();

	afirmar(
		! bNegativaPorPadrao.gravacoes().some( ( g ) => 'f3base_visitante' === g.chave ) &&
			0 === bNegativaPorPadrao.beacons().length,
		'TETO do caso negativa por padrão: com o portão NEGADO e nenhuma decisão do visitante, o cliente gravou apelido ou despachou ' +
			bNegativaPorPadrao.beacons().length + ' envio(s). Sob negativa por padrão só o aceite muda o portão, e antes dele não há apelido, não há visita e não há linha'
	);

	/*
	 * E CHEGAR COM O PORTÃO FECHADO NÃO É PEDIR EXCLUSÃO. O portão fecha por
	 * cookie de consentimento vencido, por política trocada por quem opera o site
	 * e por recusa dada noutra aba, e nenhuma das três é uma pessoa pedindo para
	 * apagar o registro dela. Houve uma versão em que o carregamento com o portão
	 * negado disparava a exclusão, e ela transformava as três em apagamento
	 * definitivo no servidor.
	 */
	const bChegouNegado = bancadaDeComportamento( fonte, dadosCom(), {
		secoes,
		consentimento: false,
		armazenado: { f3base_visitante: apelidoAntigo },
		resposta: 200
	} );

	afirmar(
		0 === bChegouNegado.envios().filter( ( e ) => e.url.includes( 'esquecer' ) ).length &&
			! bChegouNegado.removidas().some( ( r ) => 'f3base_visitante' === r.chave ),
		'TETO da chegada com o portão fechado: o carregamento pediu exclusão do apelido guardado sem ninguém ter recusado nada. Cookie vencido, política trocada e recusa noutra aba fecham o portão do mesmo jeito, e nenhum dos três é pedido do titular — só a recusa no controle do rodapé apaga'
	);

	/* CASO 3: a recusa no controle do rodapé apaga e PEDE a exclusão. */
	const bRecusa = bancadaDeComportamento( fonte, dadosCom(), {
		secoes,
		armazenado: { f3base_visitante: apelidoAntigo },
		resposta: 200
	} );

	bRecusa.recusar();

	const exclusaoPelaRecusa = bRecusa.envios().filter( ( e ) => e.url.includes( 'esquecer' ) );

	afirmar(
		1 === exclusaoPelaRecusa.length &&
			apelidoAntigo === String( ( JSON.parse( exclusaoPelaRecusa[ 0 ].corpo ) || {} ).visitante || '' ),
		'TETO da recusa: quem recusou no controle do rodapé produziu ' + exclusaoPelaRecusa.length +
			' pedido(s) de exclusão do apelido que estava em uso. Sem esse segundo passo, "apagável" é uma palavra na política e um dado que continua no servidor'
	);

	afirmar(
		bRecusa.removidas().some( ( r ) => 'f3base_visitante' === r.chave ),
		'TETO da recusa: o servidor confirmou com 2xx e o apelido continuou gravado no navegador. A recusa apaga dos DOIS lados, e é a mesma ação'
	);

	/* CASO 4: o aceite depois da negativa faz o apelido nascer na hora. */
	const bAceite = bancadaDeComportamento(
		fonte,
		dadosCom( {}, { politica: 'negado' } ),
		{ secoes, consentimento: false }
	);

	bAceite.aceitar();
	bAceite.sair();

	const cargaDoAceite = bAceite.cargas().filter( Boolean )[ 0 ] || {};

	afirmar(
		bAceite.gravacoes().some( ( g ) => 'f3base_visitante' === g.chave ) &&
			/^[a-f0-9]{32}$/.test( String( cargaDoAceite.visitante || '' ) ),
		'TETO do aceite: o visitante usou o controle de privacidade e ACEITOU, e o apelido não nasceu — o corpo levou visitante "' +
			String( cargaDoAceite.visitante || '' ) + '". A decisão que ele acabou de tomar vale nesta navegação, e não só na seguinte'
	);

	/*
	 * PISO DOS QUATRO CASOS: o apelido NASCENDO SOB O PORTÃO NEGADO, plantado no
	 * cliente real. Sem ele, os quatro tetos acima seriam quatro afirmações sobre
	 * um caminho que ninguém provou saber reprovar.
	 *
	 * O MUTANTE TEM DUAS METADES, e as duas são necessárias porque o portão
	 * guarda o nascimento DUAS vezes — de propósito. `carregar()` sai antes de
	 * qualquer coisa quando o consentimento nega, e `podeIdentificar()` volta a
	 * perguntar ao portão no instante de sortear. Remover só uma das duas não
	 * produz apelido nenhum, e um mutante que não planta o defeito não é piso: é
	 * a redundância que ele documenta.
	 */
	const semPortaoNoCarregador = fonte.replace( 'if (carregado || !permiteTags()) {', 'if (carregado) {' );
	const semPortaoNoApelido = semPortaoNoCarregador.replace(
		'\tfunction podeIdentificar() {\n\t\treturn permiteTags();\n\t}',
		'\tfunction podeIdentificar() {\n\t\treturn true;\n\t}'
	);

	afirmar(
		semPortaoNoCarregador !== fonte && semPortaoNoApelido !== semPortaoNoCarregador,
		'PISO do portão do apelido: a bancada não encontrou as duas guardas para removê-las. Ou o portão mudou de forma, e o piso deixou de provar o que promete, ou ele sumiu — e nesse caso os tetos acima é que deveriam ter acusado'
	);

	if ( semPortaoNoApelido !== semPortaoNoCarregador ) {
		const bMutante = bancadaDeComportamento(
			semPortaoNoApelido,
			dadosCom( {}, { politica: 'negado' } ),
			{ secoes, consentimento: false }
		);

		bMutante.sair();

		afirmar(
			bMutante.gravacoes().some( ( g ) => 'f3base_visitante' === g.chave ),
			'PISO do portão do apelido: removidas as duas guardas, o apelido continuou não nascendo sob o portão NEGADO. A bancada não reproduz o defeito, e um teto que não sabe falhar não mede nada'
		);
	}

	/*
	 * O RE-ACEITE RELIGA O REGISTRO na mesma navegação. Com o carregador já
	 * rodado, `carregar()` sai na primeira linha porque `carregado` continua
	 * levantado — e era ali que o registro ficava desligado pelo resto da
	 * navegação, com a página seguindo a somar no agregado como se nada tivesse
	 * acontecido. As tags nunca foram removidas; o registro é que não voltava.
	 */
	const bReaceite = bancadaDeComportamento( fonte, dadosCom(), { secoes, resposta: 200 } );

	bReaceite.recusar();
	bReaceite.aceitar();
	bReaceite.rolarAte( 100 );
	bReaceite.sair();

	const depoisDoReaceite = bReaceite.cargas().filter( Boolean ).filter(
		( c ) => Array.isArray( c.eventos ) && c.eventos.length > 0
	);

	afirmar(
		depoisDoReaceite.length > 0,
		'TETO do re-aceite: depois de recusar e aceitar de novo na mesma página, nenhum acionamento voltou ao registro. As tags religavam e o registro não, e a diferença ficava invisível porque o agregado continuava sendo somado'
	);

	/*
	 * AS CHAVES LOCAIS SÓ SOMEM COM 2XX, e antes elas sumiam na linha seguinte ao
	 * `sendBeacon`. Se o pedido não chegasse — rede caindo, balde cheio, migração
	 * em curso, aba encerrada antes de o envio sair —, o registro continuava
	 * inteiro no servidor e o navegador não tinha mais o apelido: ninguém
	 * conseguiria pedir aquela exclusão de novo. O direito virava um beacon
	 * disparado no escuro.
	 *
	 * QUEM PEDE É A RECUSA, e é por ela que este caso entra: o pedido de exclusão
	 * parte do controle do rodapé, e não do carregamento com o portão fechado.
	 */
	const bSemResposta = bancadaDeComportamento( fonte, dadosCom(), {
		secoes,
		armazenado: { f3base_visitante: apelidoAntigo },
		resposta: 'pendente'
	} );

	bSemResposta.recusar();

	afirmar(
		! bSemResposta.removidas().some( ( r ) => 'f3base_visitante' === r.chave ),
		'TETO da exclusão confirmada: o apelido local foi apagado ANTES de o servidor confirmar. Apagá-lo antes apaga a PROVA do pedido — o registro continua lá e ninguém consegue pedir de novo'
	);

	afirmar(
		bSemResposta.gravacoes().some( ( g ) => 'f3base_exclusao_pendente' === g.chave && apelidoAntigo === g.valor ),
		'TETO da exclusão pendente: o pedido que não foi confirmado não ficou gravado, e o carregamento seguinte não tem como reenviá-lo'
	);

	const bReenvio = bancadaDeComportamento( fonte, dadosCom(), {
		secoes,
		consentimento: false,
		armazenado: { f3base_exclusao_pendente: apelidoAntigo },
		resposta: 200
	} );

	afirmar(
		bReenvio.envios().filter( ( e ) => e.url.includes( 'esquecer' ) ).length > 0,
		'PISO da exclusão pendente: o carregamento seguinte encontrou o pedido gravado e não o reenviou. Pedido que falhou uma vez falharia para sempre'
	);

	/*
	 * A FILA DE PENDENTES TEM TETO DECLARADO, e ele é o orçamento da VISITA — o
	 * mesmo `maximoVisita` que já limita quantas linhas ela pode registrar. Sem
	 * teto, um servidor em 503 desde ontem faz a fila crescer dentro do
	 * armazenamento do aparelho de quem está só lendo o site.
	 *
	 * OS MAIS ANTIGOS SAEM PRIMEIRO — são os que estão mais perto de vencer pela
	 * janela da visita — e cada linha que sai conta em CORTADAS, viaja nomeada no
	 * lote seguinte e aparece na tela. O corte continua sendo nosso e declarado.
	 */
	const filaGuardada = [];

	for ( let i = 0; i < 9; i++ ) {
		filaGuardada.push( {
			id: String( i ).repeat( 32 ).slice( 0, 32 ).replace( /[^0-9a-f]/g, 'a' ),
			nascido: Date.now(),
			origem: Date.now(),
			caminho: '/pagina/',
			metricas: [],
			eventos: [ { gatilho: 'rolagem', detalhe: '25', valor: 0, ocorrencia: 1, ms: 10 } ],
			cortados: 0
		} );
	}

	const bFila = bancadaDeComportamento( fonte, dadosCom( {}, { maximoVisita: 3 } ), {
		secoes,
		resposta: 503,
		armazenado: {
			f3base_visitante: apelidoAntigo,
			f3base_sessao: JSON.stringify( {
				id: 'fedcba9876543210fedcba9876543210',
				gastas: 0,
				travessias: {},
				cortadas: 0,
				acumulado: null,
				pendentes: filaGuardada,
				visto: Date.now()
			} )
		}
	} );

	const registroDaFila = bFila.gravacoes().filter( ( g ) => 'f3base_sessao' === g.chave );
	const filaFinal = registroDaFila.length > 0 ? ( JSON.parse( registroDaFila[ registroDaFila.length - 1 ].valor ).pendentes || [] ) : [];

	afirmar(
		filaFinal.length <= 3,
		'TETO da fila pendente: a fila guardada ficou com ' + filaFinal.length +
			' lote(s) e o orçamento da visita é 3. Sem teto, um servidor em 503 desde ontem faz a fila crescer sem limite dentro do armazenamento do aparelho de quem está só lendo o site'
	);

	bFila.rolarAte( 100 );
	bFila.sair();

	const cortadosNoCorpo = bFila.cargas().filter( Boolean ).reduce(
		( maior, c ) => Math.max( maior, Number( c.cortados || 0 ) ),
		0
	);

	afirmar(
		cortadosNoCorpo > 0,
		'TETO do corte nomeado: os lotes descartados por teto de fila não contaram em cortadas — observado ' + cortadosNoCorpo +
			'. Corte silencioso faz o total do painel não bater com a tabela sem nada em lugar nenhum dizendo por quê'
	);

	/*
	 * PISO: sem a aparadora, a mesma fila tem de ficar inteira. Um teto que não
	 * sabe falhar não protege nada.
	 */
	const semAparar = fonte.replace( /\t\tapararFila\(\);\n\t\tserializarFila\(\);/g, '\t\tserializarFila();' );

	afirmar(
		semAparar !== fonte,
		'PISO da fila pendente: a bancada não encontrou a aparadora da fila para removê-la. Ou ela mudou de forma, e o piso deixou de provar o que promete, ou ela sumiu'
	);

	if ( semAparar !== fonte ) {
		const bSemAparar = bancadaDeComportamento( semAparar, dadosCom( {}, { maximoVisita: 3 } ), {
			secoes,
			resposta: 503,
			armazenado: {
				f3base_visitante: apelidoAntigo,
				f3base_sessao: JSON.stringify( {
					id: 'fedcba9876543210fedcba9876543210',
					gastas: 0,
					travessias: {},
					cortadas: 0,
					acumulado: null,
					pendentes: filaGuardada,
					visto: Date.now()
				} )
			}
		} );

		const gravadasSemAparar = bSemAparar.gravacoes().filter( ( g ) => 'f3base_sessao' === g.chave );
		const filaSemAparar = gravadasSemAparar.length > 0
			? ( JSON.parse( gravadasSemAparar[ gravadasSemAparar.length - 1 ].valor ).pendentes || [] )
			: [];

		afirmar(
			filaSemAparar.length > 3,
			'PISO da fila pendente: removida a aparadora, a fila guardada ficou com ' + filaSemAparar.length +
				' lote(s) e devia ter passado do orçamento de 3. A bancada não reproduz o defeito'
		);
	}

	return { achados };
}

/**
 * BANCADA DA ORDEM: os DOIS clientes REAIS, na ordem em que a página os roda.
 *
 * POR QUE ELA EXISTE, e por que medir a string do atributo não bastaria. A
 * pergunta desta release não é "o script saiu com `defer`?" — é "o `consent
 * default` chegou ao `dataLayer` ANTES de o `gtag.js` ser pedido?". As duas
 * respostas coincidem no caminho feliz e divergem exatamente onde a decisão
 * importa, e é por isso que a bancada roda os arquivos e lê uma LINHA DO TEMPO,
 * em vez de conferir um atributo.
 *
 * O ESCALONADOR É O MODELO DA ESPECIFICAÇÃO, e ele é a única coisa aqui que não
 * sai de um arquivo do pacote. Três regras, e nenhuma é escolha nossa:
 *
 * 1. Script BLOQUEANTE executa na posição do parser, no momento em que o parser
 *    chega nele.
 * 2. Script `defer` executa DEPOIS do parse e NA ORDEM DO DOCUMENTO, antes do
 *    `DOMContentLoaded`. É essa regra que faz o consentimento no `<head>`
 *    continuar rodando antes do carregador de tags no rodapé quando os dois são
 *    `defer`.
 * 3. Script `async` não tem ordem com NADA — nem com os outros `async`, nem com
 *    os `defer`. O arquivo de um fornecedor é pequeno e costuma chegar antes de
 *    o parser terminar, então o caso que a bancada roda é o pior e o mais
 *    comum: o `async` executa antes de qualquer `defer` da página.
 *
 * A regra 3 é a que carrega esta release. `defer` ordena `defer`; ele não
 * ordena o `gtag.js` de um plugin de console, nem um snippet colado no
 * cabeçalho. Em pré-aprovado isso não custa nada, porque o `default` que
 * chegaria é `granted` — e ausência de `default` é, para o gtag, o mesmo
 * `granted`. Em negado por padrão custa o primeiro `page_view`.
 *
 * @param {Object} fontes  { consentimento, tracking } — o código real de cada um.
 * @param {Object} opcoes  Cenário: política, estratégias, cookie e emissor concorrente.
 * @return {Object} Linha do tempo e acessores.
 */
function bancadaDeOrdem( fontes, opcoes ) {
	const o = opcoes || {};
	const linha = [];
	const ouvintesDoc = {};
	const ouvintesWin = {};
	let cookie = String( o.cookie || '' );

	function marcar( tipo, detalhe ) {
		linha.push( Object.assign( { tipo }, detalhe || {} ) );
	}

	/**
	 * O consentimento que uma tag VÊ se executar agora.
	 *
	 * É a leitura que o `gtag.js` faz: ele processa o `dataLayer` na ordem, e o
	 * `default` só vale para ele se já estiver lá. Sem nenhum, o resultado é
	 * `ausente` — que o fornecedor trata como consentimento pleno.
	 */
	function consentimentoVisto() {
		for ( let i = linha.length - 1; i >= 0; i-- ) {
			if ( 'consent-default' === linha[ i ].tipo || 'consent-update' === linha[ i ].tipo ) {
				return String( linha[ i ].analytics || '' );
			}
		}

		return 'ausente';
	}

	function elemento( tag ) {
		return {
			nodeType: 1,
			tagName: String( tag ).toUpperCase(),
			className: '',
			id: '',
			src: '',
			href: '',
			type: '',
			async: false,
			hidden: false,
			textContent: '',
			offsetHeight: 0,
			style: { setProperty() {}, removeProperty() {} },
			attrs: {},
			filhos: [],
			pai: null,
			setAttribute( nome, valor ) {
				this.attrs[ nome ] = String( valor );
			},
			getAttribute( nome ) {
				return Object.prototype.hasOwnProperty.call( this.attrs, nome ) ? this.attrs[ nome ] : null;
			},
			removeAttribute( nome ) {
				delete this.attrs[ nome ];
			},
			addEventListener() {},
			appendChild( filho ) {
				filho.pai = this;
				this.filhos.push( filho );

				return filho;
			},
			removeChild( filho ) {
				this.filhos = this.filhos.filter( ( f ) => f !== filho );

				return filho;
			},
			focus() {},
			matches() {
				return false;
			},
			querySelector() {
				return null;
			},
			querySelectorAll() {
				return [];
			}
		};
	}

	const corpo = elemento( 'body' );
	const cabeca = elemento( 'head' );

	/* Toda inserção de <script> externo entra na linha do tempo, com o id e a origem. */
	cabeca.appendChild = function ( filho ) {
		if ( 'SCRIPT' === filho.tagName ) {
			marcar( 'script-externo', {
				id: String( filho.id || '' ),
				src: String( filho.src || '' ),
				consentimentoVisto: consentimentoVisto()
			} );
		}

		this.filhos.push( filho );

		return filho;
	};

	const documento = {
		readyState: 'loading',
		visibilityState: 'visible',
		documentElement: {
			style: { setProperty() {}, removeProperty() {} },
			scrollHeight: 4000,
			clientHeight: 800,
			scrollTop: 0
		},
		body: corpo,
		head: cabeca,
		activeElement: null,
		get cookie() {
			return cookie;
		},
		set cookie( valor ) {
			cookie = String( valor ).split( ';' )[ 0 ];
		},
		addEventListener( tipo, fn ) {
			( ouvintesDoc[ tipo ] = ouvintesDoc[ tipo ] || [] ).push( fn );
		},
		removeEventListener() {},
		createElement: ( tag ) => elemento( tag ),
		getElementById: () => null,
		getElementsByTagName: () => [],
		querySelectorAll: () => [],
		dispatchEvent() {
			return true;
		}
	};

	const dataLayer = [];

	dataLayer.push = function ( ...itens ) {
		for ( const item of itens ) {
			Array.prototype.push.call( this, item );

			if ( item && 'consent' === item[ 0 ] ) {
				const mapa = item[ 2 ] || {};

				marcar( 'consent-' + String( item[ 1 ] ), {
					analytics: String( mapa.analytics_storage || '' ),
					anuncios: String( mapa.ad_storage || '' )
				} );
			}
		}

		return this.length;
	};

	const janela = {
		f3baseConsentimentoDados: o.dadosDoConsentimento,
		f3baseTrackingDados: o.dadosDoTracking,
		dataLayer,
		innerHeight: 800,
		pageYOffset: 0,
		location: {
			protocol: 'https:',
			href: 'https://exemplo.test/',
			pathname: '/',
			search: '',
			hostname: 'exemplo.test'
		},
		navigator: {
			sendBeacon: () => true
		},
		localStorage: { getItem: () => null, setItem() {}, removeItem() {} },
		sessionStorage: { getItem: () => null, setItem() {}, removeItem() {} },
		URL: globalThis.URL,
		IntersectionObserver: class {
			constructor( retorno ) {
				this.retorno = retorno;
			}
			observe() {}
			unobserve() {}
		},
		PerformanceObserver: class {
			constructor( retorno ) {
				this.retorno = retorno;
			}
			observe() {}
		},
		performance: {
			getEntriesByType: ( tipo ) => ( 'navigation' === tipo ? [ { responseStart: 412.7 } ] : [] )
		},
		addEventListener( tipo, fn ) {
			( ouvintesWin[ tipo ] = ouvintesWin[ tipo ] || [] ).push( fn );
		},
		removeEventListener() {}
	};

	/**
	 * O EMISSOR CONCORRENTE: o `gtag.js` que não é nosso.
	 *
	 * Não é hipótese — é a classe que o pacote já mede em
	 * `plugins.emissor_concorrente` e em `tracking.emissor_unico` desde a 1.1.1.
	 * Ele executa, pede o carregador do fornecedor e produz o primeiro
	 * `page_view` com o consentimento que estiver no `dataLayer` naquele
	 * instante — que é exatamente o que o `gtag.js` real faz.
	 */
	function emissorConcorrente() {
		marcar( 'script-externo', {
			id: 'emissor-concorrente',
			src: 'https://www.googletagmanager.com/gtag/js?id=G-FORASTEIRO',
			consentimentoVisto: consentimentoVisto()
		} );

		janela.dataLayer.push( [ 'js', new Date() ] );
		janela.dataLayer.push( [ 'config', 'G-FORASTEIRO' ] );

		marcar( 'page_view', {
			origem: 'emissor-concorrente',
			consentimentoVisto: consentimentoVisto()
		} );
	}

	function rodar( entrada ) {
		marcar( 'execucao', { nome: entrada.nome } );

		if ( entrada.executar ) {
			entrada.executar();

			return;
		}

		// eslint-disable-next-line no-new-func
		new Function( 'window', 'document', entrada.fonte )( janela, documento );
	}

	const documentoDaPagina = [];

	if ( false !== o.consentimentoNaPagina ) {
		documentoDaPagina.push( {
			nome: 'f3base-consentimento',
			fonte: fontes.consentimento,
			estrategia: String( o.estrategiaDoConsentimento || '' )
		} );
	}

	if ( o.emissorConcorrente ) {
		documentoDaPagina.push( {
			nome: 'emissor-concorrente',
			executar: emissorConcorrente,
			estrategia: 'async'
		} );
	}

	if ( false !== o.trackingNaPagina ) {
		documentoDaPagina.push( {
			nome: 'f3base-tracking',
			fonte: fontes.tracking,
			estrategia: 'defer'
		} );
	}

	if ( o.ordemDoDocumento ) {
		documentoDaPagina.sort(
			( a, b ) => o.ordemDoDocumento.indexOf( a.nome ) - o.ordemDoDocumento.indexOf( b.nome )
		);
	}

	const adiados = [];
	const assincronos = [];

	for ( const entrada of documentoDaPagina ) {
		if ( 'defer' === entrada.estrategia ) {
			adiados.push( entrada );
			continue;
		}

		if ( 'async' === entrada.estrategia ) {
			assincronos.push( entrada );
			continue;
		}

		rodar( entrada );
	}

	for ( const entrada of assincronos ) {
		rodar( entrada );
	}

	documento.readyState = 'interactive';

	for ( const entrada of adiados ) {
		rodar( entrada );
	}

	for ( const fn of ouvintesDoc.DOMContentLoaded || [] ) {
		fn();
	}

	documento.readyState = 'complete';

	return {
		linha,
		janela,
		documento,
		forma() {
			return linha.map( ( m ) => m.tipo + ( m.nome ? ':' + m.nome : '' ) + ( m.id ? ':' + m.id : '' ) ).join( ' > ' );
		},
		indiceDe( teste ) {
			return linha.findIndex( teste );
		},
		primeiro( teste ) {
			return linha.find( teste ) || null;
		}
	};
}

/**
 * `js.ordem_do_consentimento` — a ORDEM DE EXECUÇÃO, medida, não deduzida.
 *
 * A hipótese que esta bancada existe para confirmar ou refutar: com `defer` nos
 * dois scripts, a ordem continua garantida pela especificação, e o `default`
 * continua chegando antes do `gtag.js` — logo, não há visita inicial rastreada
 * sem consentimento no caminho padrão.
 *
 * O veredito medido está nas asserções abaixo, e ele tem duas metades:
 *
 * - **Confirmada para os scripts DESTE pacote.** Entre `defer` e `defer` a
 *   ordem do documento vale, e a linha do tempo com o consentimento bloqueante
 *   é a MESMA que com o consentimento adiado. É o teto 1 contra o teto 2.
 * - **Insuficiente contra quem não é nosso.** `defer` não ordena `async`. Com um
 *   emissor concorrente na página — a classe que `plugins.emissor_concorrente`
 *   já mede —, o `gtag.js` do outro plugin executa antes do `default` adiado.
 *   Em pré-aprovado isso é inócuo e a bancada mede por quê: o `default` que
 *   chegaria é `granted`, e ausência de `default` é `granted` para o
 *   fornecedor. Em negado por padrão é o primeiro `page_view` saindo antes do
 *   `denied`, e é esse o piso desta checagem.
 *
 * @param {string} raiz Raiz do pacote.
 * @return {Object} Achados.
 */
function ordemDoConsentimento( raiz ) {
	const achados = [];
	let fonteConsentimento;
	let fonteTracking;

	try {
		fonteConsentimento = readFileSync( entregue( raiz, 'fontes/plugin/assets/f3base-consentimento.js' ), 'utf8' );
		fonteTracking = readFileSync( entregue( raiz, 'fontes/plugin/assets/f3base-tracking.js' ), 'utf8' );
	} catch {
		return { achados: [ 'f3base-consentimento.js ou f3base-tracking.js ausente na raiz varrida: sem os dois clientes não há ordem a medir' ] };
	}

	function afirmar( ok, texto ) {
		if ( ! ok ) {
			achados.push( texto );
		}
	}

	const eventos = declaracaoDeComportamento( raiz );

	if ( 0 === Object.keys( eventos ).length ) {
		return { achados: [ 'fontes/plugin/dados/eventos-comportamento.tsv não declarou evento nenhum: o carregador não roda sem a declaração, e uma bancada sem ela aprovaria o silêncio' ] };
	}

	const dadosDoTracking = {
		caminho: 'direto',
		gtm: '',
		ga4: 'G-ABCDEF1234',
		ads: { id: '', label: '' },
		meta: { pixelId: '', origem: 'https://connect.facebook.net/en_US/fbevents.js' },
		linkedin: { partnerId: '', conversionId: '', origem: 'https://snap.licdn.com/li.lms-analytics/insight.min.js' },
		origemGoogle: 'https://www.googletagmanager.com/',
		resumo: { ativo: false, endpoint: '', token: '', maximo: 0 },
		comportamento: { eventos, prefixoSecao: 'f3base-secao-' }
	};

	function dadosDoConsentimento( padrao ) {
		return {
			padrao,
			ttlDias: 180,
			controleRodape: true,
			avisoPrimeiraVisita: false,
			cookie: 'f3base_consentimento',
			seletorControle: '[data-f3base-consentimento]',
			idBanner: 'f3base-consentimento-banner',
			categorias: [ 'analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization' ],
			textos: {
				titulo: 'Política de Cookie',
				explicacao: 'texto da bancada',
				aceitar: 'Permitir medição',
				recusar: 'Desligar medição',
				fechar: 'Fechar',
				estadoAtivo: 'Medição ligada neste navegador.',
				estadoNegado: 'Medição desligada neste navegador.',
				aviso: 'aviso da bancada',
				avisoOk: 'Entendi',
				politica: 'Política de Privacidade'
			},
			politicaUrl: 'https://exemplo.test/privacidade/'
		};
	}

	function cenario( extras ) {
		return bancadaDeOrdem(
			{ consentimento: fonteConsentimento, tracking: fonteTracking },
			Object.assign(
				{
					dadosDoConsentimento: dadosDoConsentimento( 'pre-aprovado' ),
					dadosDoTracking,
					estrategiaDoConsentimento: 'defer'
				},
				extras || {}
			)
		);
	}

	const nossoGtag = ( m ) => 'script-externo' === m.tipo && 'f3base-gtag' === m.id;
	const defaultDoConsentimento = ( m ) => 'consent-default' === m.tipo;

	/* ==================================================================
	 * TETO 1 — pré-aprovado com o script ADIADO: a ordem continua de pé.
	 * ================================================================== */
	const adiado = cenario( {} );

	afirmar(
		adiado.indiceDe( defaultDoConsentimento ) !== -1,
		'teto do adiado: o consent default não chegou ao dataLayer com o script adiado — sem ele não há Consent Mode nenhum, e a release inteira estaria trocando 5 KB por uma garantia'
	);

	afirmar(
		adiado.indiceDe( nossoGtag ) !== -1,
		'teto do adiado: o carregador não pediu o gtag.js — sem a tag na linha do tempo não há ordem a medir, e a bancada aprovaria o silêncio'
	);

	afirmar(
		adiado.indiceDe( defaultDoConsentimento ) !== -1
			&& adiado.indiceDe( nossoGtag ) !== -1
			&& adiado.indiceDe( defaultDoConsentimento ) < adiado.indiceDe( nossoGtag ),
		'teto do adiado: o gtag.js foi pedido ANTES de o consent default entrar no dataLayer. É a hipótese desta release refutada: defer não preservou a ordem do documento entre o consentimento no head e o carregador no rodapé. Linha do tempo: ' + adiado.forma()
	);

	afirmar(
		'granted' === String( ( adiado.primeiro( defaultDoConsentimento ) || {} ).analytics ),
		'teto do adiado: em pré-aprovado o default precisa ser granted — é o que torna o atraso inócuo, e um default diferente mudaria a conta desta decisão'
	);

	/* ==================================================================
	 * TETO 2 — o MESMO cenário com o script BLOQUEANTE, que é a 1.1.4.
	 *
	 * A comparação é o veredito: se as duas linhas do tempo forem iguais,
	 * o bloqueio não estava comprando ordem nenhuma para os nossos dois
	 * scripts — estava comprando 5.085 bytes gzip no caminho crítico.
	 * ================================================================== */
	const bloqueante = cenario( { estrategiaDoConsentimento: '' } );

	afirmar(
		bloqueante.forma() === adiado.forma(),
		'teto da equivalência: com os dois scripts do pacote na página, a linha do tempo do consentimento BLOQUEANTE difere da do ADIADO — e é essa igualdade que autoriza tirar o script do caminho crítico. Bloqueante: ' + bloqueante.forma() + '. Adiado: ' + adiado.forma()
	);

	/* ==================================================================
	 * TETO 3 — negado por padrão, script BLOQUEANTE, emissor concorrente.
	 *
	 * Aqui a ordem é a garantia inteira, e o bloqueio é o que a compra: o
	 * `denied` está no dataLayer antes de o gtag.js do outro plugin rodar.
	 * ================================================================== */
	const optInBloqueante = cenario( {
		dadosDoConsentimento: dadosDoConsentimento( 'negado' ),
		estrategiaDoConsentimento: '',
		emissorConcorrente: true,
		trackingNaPagina: false
	} );

	const pageViewBloqueante = optInBloqueante.primeiro( ( m ) => 'page_view' === m.tipo );

	afirmar(
		null !== pageViewBloqueante && 'denied' === String( pageViewBloqueante.consentimentoVisto ),
		'teto do opt-in bloqueante: o primeiro page_view do emissor concorrente NÃO viu o denied. Consentimento visto: "' + String( ( pageViewBloqueante || {} ).consentimentoVisto ) + '". Linha do tempo: ' + optInBloqueante.forma()
	);

	/* ==================================================================
	 * PISO 1 — INVERTER A DECISÃO: defer no modo opt-in.
	 *
	 * É o piso do defeito que esta release existe para não cometer, e ele
	 * precisa sair NOMEANDO o que se perde.
	 * ================================================================== */
	const optInAdiado = cenario( {
		dadosDoConsentimento: dadosDoConsentimento( 'negado' ),
		estrategiaDoConsentimento: 'defer',
		emissorConcorrente: true,
		trackingNaPagina: false
	} );

	const pageViewAdiado = optInAdiado.primeiro( ( m ) => 'page_view' === m.tipo );
	const defaultAdiado = optInAdiado.indiceDe( defaultDoConsentimento );
	const indicePageView = optInAdiado.indiceDe( ( m ) => 'page_view' === m.tipo );

	afirmar(
		null !== pageViewAdiado && 'ausente' === String( pageViewAdiado.consentimentoVisto ) && indicePageView < defaultAdiado,
		'piso da inversão: com o consentimento ADIADO no modo de negativa por padrão, a bancada precisa ver o PRIMEIRO page_view sair antes do denied — é o que se perde ao aplicar aqui a permissividade autorizada para a pré-aprovação, e é por isso que este modo mantém o script bloqueante. A bancada não viu: consentimento visto pelo page_view "' + String( ( pageViewAdiado || {} ).consentimentoVisto ) + '", page_view no índice ' + indicePageView + ', denied no índice ' + defaultAdiado
	);

	/* ==================================================================
	 * PISO 2 — a ORDEM QUEBRADA, com os nossos dois scripts.
	 *
	 * O carregador roda antes do consentimento. Sem o objeto na página,
	 * `permiteTags()` cai na decisão de reserva do servidor e devolve
	 * verdadeiro — e numa página servida de cache para quem não decidiu
	 * nada, no modo opt-in, isso é o gtag.js carregando sem o denied.
	 * ================================================================== */
	const invertido = cenario( {
		dadosDoConsentimento: dadosDoConsentimento( 'negado' ),
		estrategiaDoConsentimento: 'defer',
		ordemDoDocumento: [ 'f3base-tracking', 'f3base-consentimento' ]
	} );

	const gtagInvertido = invertido.primeiro( nossoGtag );

	afirmar(
		null !== gtagInvertido && 'ausente' === String( gtagInvertido.consentimentoVisto ),
		'piso da ordem quebrada: com o carregador rodando antes do consentimento, a bancada precisa ver o gtag.js pedido sem nenhum consent default no dataLayer — é a decisão de reserva do servidor virando permissão no navegador. A bancada não viu: ' + invertido.forma()
	);

	/* ==================================================================
	 * TETO 4 — por que o atraso é inócuo em PRÉ-APROVADO, medido.
	 *
	 * O emissor concorrente executa antes do default adiado nos dois modos.
	 * A diferença não está na ordem: está no VALOR que se perde. Em
	 * pré-aprovado o default é `granted`, e ausência de default é `granted`
	 * para o fornecedor — nada do que foi enviado muda.
	 * ================================================================== */
	const preAprovadoComConcorrente = cenario( {
		emissorConcorrente: true,
		trackingNaPagina: false
	} );

	const pageViewPreAprovado = preAprovadoComConcorrente.primeiro( ( m ) => 'page_view' === m.tipo );
	const defaultPreAprovado = preAprovadoComConcorrente.primeiro( defaultDoConsentimento );

	afirmar(
		null !== pageViewPreAprovado && 'ausente' === String( pageViewPreAprovado.consentimentoVisto ),
		'teto da equivalência material: em pré-aprovado o emissor concorrente precisa mesmo chegar antes do default adiado — se a bancada não vir isso, ela não está medindo o caso que decide, e o teto abaixo aprovaria por acaso'
	);

	afirmar(
		null !== defaultPreAprovado && 'granted' === String( defaultPreAprovado.analytics ),
		'teto da equivalência material: o default que chegou tarde em pré-aprovado não é granted. Se ele fosse outro valor, chegar tarde passaria a custar alguma coisa, e a decisão desta release mudaria com ele'
	);

	return { achados };
}

/**
 * `js.ciclo_de_vida_da_pagina` — cada métrica contada UMA vez, na saída REAL.
 *
 * O QUE ESTA CHECAGEM EXISTE PARA IMPEDIR. Sair de uma página não é um evento:
 * numa navegação normal o navegador emite `visibilitychange` para hidden E
 * `pagehide`, nesta ordem, no mesmo carregamento. Os dois ouvintes existem de
 * propósito — há navegador em que só um dispara, e tirar um perde a sessão
 * inteira ali —, e por isso todo emissor ligado a eles precisa da disciplina de
 * UMA VEZ POR CARREGAMENTO. Sem ela, cada métrica entra duas vezes no resumo, o
 * resumo é enviado uma vez só, e o número no relatório é o dobro do que
 * aconteceu, sem erro nenhum em lugar nenhum.
 *
 * A BANCADA SÓ SABIA OCULTAR até esta release: `ocultar()` disparava
 * `visibilitychange` e nada mais. O caso comum — os dois eventos no mesmo
 * carregamento — nunca foi exercitado, e é exatamente o caso que produz o
 * defeito. As quatro formas de saída estão aqui: os dois eventos, só
 * `pagehide`, só `visibilitychange`, e a aba que volta a ficar visível e é
 * ocultada de novo — essa última não pode ressuscitar nada.
 *
 * @param {string} raiz Raiz do pacote.
 * @return {Object} Achados.
 */
function cicloDeVidaDaPagina( raiz ) {
	const alvo = entregue( raiz, 'fontes/plugin/assets/f3base-tracking.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'fontes/plugin/assets/f3base-tracking.js ausente na raiz varrida' ] };
	}

	function afirmar( ok, texto ) {
		if ( ! ok ) {
			achados.push( texto );
		}
	}

	const eventos = declaracaoDeComportamento( raiz );
	const nomes = Object.keys( eventos );

	if ( 0 === nomes.length ) {
		return { achados: [ 'teto: a declaração de eventos veio vazia, e uma bancada sem declaração aprova o silêncio' ] };
	}

	function porGatilho( gatilho ) {
		const nome = nomes.find( ( n ) => eventos[ n ].gatilho === gatilho );

		return nome ? { nome, dados: eventos[ nome ] } : null;
	}

	const vital = porGatilho( 'desempenho' );
	const rolagem = porGatilho( 'rolagem' );
	const pagina = porGatilho( 'pagina' );
	const secao = porGatilho( 'interseccao' );

	afirmar( null !== vital, 'teto: nenhum evento com o gatilho "desempenho" — sem ele não há o que contar duas vezes' );
	afirmar( null !== rolagem, 'teto: nenhum evento com o gatilho "rolagem"' );
	afirmar( null !== pagina, 'teto: nenhum evento com o gatilho "pagina" declarado. Sem o contador de carregamentos, a profundidade de leitura não tem denominador e "2 chegaram a 90%" fica ilegível — pode ser 2 de 2 ou 2 de 200' );
	afirmar( null !== secao, 'teto: nenhum evento com o gatilho "interseccao"' );

	if ( ! vital || ! rolagem || ! pagina || ! secao ) {
		return { achados };
	}

	/*
	 * O CAMINHO É `direto` COM ID GRAVADO porque parte desta bancada lê o
	 * `dataLayer`, e com o slot vazio o cliente — corretamente — não empurra
	 * nada para lá. O que se mede aqui é a CONTAGEM, e ela é a mesma nos dois
	 * caminhos: quem soma é `acumular()`, antes da bifurcação.
	 */
	const dados = {
		caminho: 'direto',
		gtm: '',
		ga4: 'G-ABCDEF1234',
		ads: { id: '', label: '' },
		meta: { pixelId: '', origem: '' },
		linkedin: { partnerId: '', conversionId: '', origem: '' },
		origemGoogle: 'https://www.googletagmanager.com/',
		comportamento: { eventos, prefixoSecao: 'f3base-secao-' },
		resumo: {
			ativo: true,
			endpoint: 'https://exemplo.test/wp-json/f3base/v1/comportamento',
			token: 'token-da-bancada',
			maximo: 60,
			maximoLog: 180,
			maximoVisita: 300,
			/*
			 * A POLÍTICA CHEGA DO SERVIDOR, e o AVISO de primeira visita não: o
			 * apelido do visitante segue o PORTÃO, e não o banner. Uma bancada que
			 * publicasse o aviso estaria publicando um campo que o servidor não
			 * publica mais, com a aparência de que ele decide alguma coisa.
			 */
			politica: 'pre-aprovado'
		}
	};

	/**
	 * Um carregamento de página, com os vitais medidos, saindo do jeito pedido.
	 *
	 * @param {Function} sair    Como a página é abandonada.
	 * @param {Object}   extras  Opções da plataforma.
	 * @return {Object} Bancada já exercitada.
	 */
	function carregamento( sair, extras, comInteracao, origem ) {
		const b = bancadaDeComportamento( origem || fonte, dados, Object.assign( { alturaDocumento: 4000 }, extras || {} ) );

		b.desempenhoEntrada( 'largest-contentful-paint', [ { startTime: 1834.6 } ] );
		b.desempenhoEntrada( 'layout-shift', [ { value: 0.0723, hadRecentInput: false } ] );

		/*
		 * A INTERAÇÃO É OPCIONAL DE PROPÓSITO. Sem ela não há INP, e o
		 * carregamento reporta TRÊS métricas em vez de quatro — que é a maioria
		 * dos carregamentos reais, porque muita visita lê e sai sem clicar em
		 * nada. É essa folga sob o teto por página que torna a repetição
		 * VISÍVEL: com as quatro métricas, o próprio teto absorve o segundo
		 * relato e uma trava removida passaria despercebida.
		 */
		if ( false !== comInteracao ) {
			b.desempenhoEntrada( 'event', [ { interactionId: 7, duration: 148 } ] );
		}

		sair( b );

		return b;
	}

	/**
	 * Os totais que o servidor receberia, por gatilho e detalhe.
	 *
	 * @param {Object} b Bancada exercitada.
	 * @return {Object} Mapa `gatilho|detalhe` para contagem.
	 */
	function totais( b ) {
		const mapa = {};
		const amostras = new Set();

		for ( const carga of b.cargas().filter( Boolean ) ) {
			for ( const linha of carga.metricas || [] ) {
				if (linha.amostra) { if (amostras.has(linha.amostra.id)) continue; amostras.add(linha.amostra.id); }
				const chave = String( linha.gatilho ) + '|' + String( linha.detalhe || '' );

				mapa[ chave ] = ( mapa[ chave ] || 0 ) + Number( linha.contagem || 0 );
			}
		}

		return mapa;
	}

	const formas = [
		[ 'o ciclo REAL: visibilitychange para hidden E pagehide, no mesmo carregamento', ( b ) => b.sair() ],
		[ 'só pagehide, o navegador que não emite o outro', ( b ) => b.soPagehide() ],
		[ 'só visibilitychange', ( b ) => b.ocultar() ],
		[ 'oculta, volta a ficar visível e é ocultada de novo', ( b ) => {
			b.ocultar();
			b.voltarAVer();
			b.sair();
		} ]
	];

	for ( const [ rotulo, sair ] of formas ) {
		for ( const comInteracao of [ true, false ] ) {
			const bDoLayer = carregamento( sair, {}, comInteracao );
			const esperados = ( vital.dados.limiar.vitais || [] ).length - ( comInteracao ? 0 : 1 );
			const relatados = bDoLayer.doNome( vital.nome ).length;

			afirmar(
				relatados === esperados,
				'TETO da contagem única no dataLayer (' + rotulo + ', ' + ( comInteracao ? 'com interação' : 'SEM interação' ) +
					'): saíram ' + relatados + ' relato(s) de vital para ' + esperados +
					' métrica(s) medida(s). Os dois eventos de saída chamam o MESMO relator, e sem a disciplina de uma-vez cada métrica é relatada duas vezes. O carregamento sem interação é o que expõe isso: com as quatro métricas o teto por página absorve o segundo relato sozinho, e a trava removida passa despercebida'
			);
		}

		const b = carregamento( sair, {} );
		const mapa = totais( b );

		afirmar(
			1 === b.beacons().length,
			'TETO do envio único (' + rotulo + '): a aba mandou ' + b.beacons().length + ' resumo(s). Um por carregamento, sempre'
		);

		for ( const metrica of vital.dados.limiar.vitais || [] ) {
			const conta = mapa[ 'desempenho|' + metrica ] || 0;

			afirmar(
				1 === conta,
				'TETO da contagem única (' + rotulo + '): ' + metrica + ' foi contada ' + conta +
					' vez(es) num único carregamento. É o defeito medido em produção: os dois eventos de saída disparam o mesmo relator, cada métrica entra duas vezes no resumo, o resumo é enviado uma vez só, e o relatório mostra o dobro do que aconteceu — sem erro em lugar nenhum'
			);
		}

		afirmar(
			1 === ( mapa[ 'pagina|' ] || 0 ),
			'TETO do denominador (' + rotulo + '): o carregamento da página foi contado ' + ( mapa[ 'pagina|' ] || 0 ) +
				' vez(es). Ele é o denominador de toda proporção da tela, e um denominador dobrado corta toda profundidade de leitura pela metade'
		);
	}

	/*
	 * PISO DO PISO: o relator SEM a trava tem de ser acusado por este teto.
	 * Sem esta mutação, as asserções acima passariam de graça no dia em que
	 * alguém removesse a trava — que é exatamente o que aconteceria.
	 */
	const semTrava = fonte.replace('var n = (sequencias[metrica.id] || 0) + 1;', 'var n = 1;').replace('if (anteriores[metrica.id] === metrica.value) { return; }', '');

	afirmar(
		semTrava !== fonte,
		'PISO: a bancada não encontrou a trava de uma-vez do relator de vitais para removê-la. Ou ela mudou de forma, e o piso deixou de provar o que promete, ou ela sumiu — e nesse caso o teto acima é que deveria ter acusado'
	);

	if ( semTrava !== fonte ) {
		/*
		 * O MUTANTE RODA COM TRÊS DAS QUATRO MÉTRICAS de propósito. Com as
		 * quatro, o TETO POR PÁGINA — que é quatro — absorveria sozinho o
		 * segundo relato, e o piso passaria sem provar nada sobre a trava. Com
		 * três, sobra folga no teto e a repetição aparece, que é exatamente o
		 * que acontece no site real: nem todo carregamento resolve o LCP e nem
		 * todo visitante interage, então quase sempre há folga.
		 */
		const bMutante = bancadaDeComportamento( semTrava, dados, { alturaDocumento: 4000 } );

		bMutante.desempenhoEntrada( 'largest-contentful-paint', [ { startTime: 1834.6 } ] );
		bMutante.desempenhoEntrada( 'layout-shift', [ { value: 0.0723, hadRecentInput: false } ] );
		bMutante.sair();

		/*
		 * O MUTANTE É LIDO NO `dataLayer`, e não no beacon, e a razão é uma
		 * descoberta desta medição: o resumo é DESPACHADO no primeiro evento de
		 * saída, e tudo o que for emitido depois dele é acumulado numa sessão
		 * que já partiu. O beacon, portanto, esconde o segundo relato — é uma
		 * segunda linha de defesa, e ela é frágil justamente porque depende da
		 * ordem em que os ouvintes foram instalados. O `dataLayer` recebe cada
		 * emissão na hora, e é onde a repetição aparece.
		 */
		const relatosDoMutante = bMutante.doNome( vital.nome ).length;
		const relatosSaos = carregamento( ( b ) => b.sair(), {}, false ).doNome( vital.nome ).length;

		afirmar(
			relatosDoMutante > 3,
			'PISO: removida a trava de uma-vez do relator, o ciclo real de saída produziu ' + relatosDoMutante +
				' relato(s) de vital para 3 métricas medidas — nenhuma foi contada duas vezes. A bancada não reproduz o defeito, e um teto que não sabe falhar não protege nada'
		);

		afirmar(
			3 === relatosSaos,
			'TETO no dataLayer: com a trava no lugar, o ciclo real de saída produziu ' + relatosSaos +
				' relato(s) de vital para 3 métricas medidas. É no dataLayer que a repetição aparece na hora — o beacon a esconde, porque ele já partiu no primeiro evento de saída'
		);
	}

	/*
	 * A PROFUNDIDADE É SOBRE A ALTURA DAQUELA PÁGINA. Duas páginas, dois
	 * comportamentos: a curta cabe na tela e conta como lida até o fim; a longa
	 * só emite o marco que foi alcançado de verdade.
	 */
	const marcos = ( rolagem.dados.limiar.marcos || [] ).map( Number ).sort( ( a, b ) => a - b );

	const curta = bancadaDeComportamento( fonte, dados, { alturaDocumento: 700 } );

	afirmar(
		curta.doNome( rolagem.nome ).length === marcos.length,
		'TETO da página curta: uma página que cabe inteira na tela emitiu ' + curta.doNome( rolagem.nome ).length +
			' marco(s) de ' + marcos.length + '. Nada a rolar é conteúdo inteiro visto, e não conteúdo não lido'
	);

	const longa = bancadaDeComportamento( fonte, dados, { alturaDocumento: 12000 } );

	afirmar(
		0 === longa.doNome( rolagem.nome ).length,
		'TETO da página longa: sem ninguém rolar, uma página de 12000px emitiu ' + longa.doNome( rolagem.nome ).length +
			' marco(s). O marco tem de sair da altura DAQUELA página — emitir sem rolagem é o defeito que empata 25, 50, 75 e 90 em toda página do relatório'
	);

	longa.rolarAte( 60 );

	const apos60 = longa.doNome( rolagem.nome ).map( ( e ) => Number( e[ rolagem.dados.parametros[ 0 ] ] ) ).sort( ( a, b ) => a - b );

	afirmar(
		JSON.stringify( apos60 ) === JSON.stringify( marcos.filter( ( m ) => m <= 60 ) ),
		'TETO da página longa: rolando a 60% dela saíram os marcos ' + JSON.stringify( apos60 ) +
			', e os esperados eram ' + JSON.stringify( marcos.filter( ( m ) => m <= 60 ) )
	);

	/*
	 * PISO DA REAVALIAÇÃO: a página que CRESCE depois de carregar. Uma página
	 * medida como curta na instalação do coletor não pode ter queimado os
	 * quatro marcos antes de as imagens entrarem — foi assim que o relatório do
	 * usuário saiu com 25, 50, 75 e 90 empatados na home.
	 */
	const cresceu = bancadaDeComportamento( fonte, dados, { alturaDocumento: 700, readyState: 'loading' } );

	afirmar(
		0 === cresceu.doNome( rolagem.nome ).length,
		'PISO da reavaliação: a página ainda CARREGANDO, medida como curta, já emitiu ' + cresceu.doNome( rolagem.nome ).length +
			' marco(s). Uma página longa cujas imagens ainda não têm altura mede "cabe na tela", queima os quatro marcos e nunca mais tem marco para emitir quando cresce'
	);

	cresceu.crescerPara( 12000 );

	afirmar(
		0 === cresceu.doNome( rolagem.nome ).length,
		'PISO da reavaliação: a página cresceu para 12000px e emitiu marco sem ninguém rolar'
	);

	cresceu.rolarAte( 100 );

	afirmar(
		cresceu.doNome( rolagem.nome ).length === marcos.length,
		'PISO da reavaliação: depois de crescer e ser rolada até o fim, a página emitiu ' + cresceu.doNome( rolagem.nome ).length +
			' marco(s) de ' + marcos.length + '. Os marcos precisavam continuar disponíveis — se tivessem sido queimados na medição da página curta, a leitura real não teria como ser registrada'
	);

	/*
	 * A SEÇÃO VISTA, e é a razão de ela ter ficado com ZERO linha no site do
	 * usuário: o coletor só observa elemento que carrega a classe declarada, e
	 * nenhuma página entregue a carregava — a classe existia só nos patterns do
	 * editor, que são modelos para inserir à mão.
	 */
	const comSecoes = bancadaDeComportamento( fonte, dados, {
		alturaDocumento: 4000,
		secoes: [ 'wp-block-group f3base-secao-abertura', 'wp-block-group f3base-secao-faq' ]
	} );

	comSecoes.verSecao( 0 );
	comSecoes.verSecao( 1 );

	afirmar(
		2 === comSecoes.doNome( secao.nome ).length,
		'TETO da seção vista: duas seções marcadas entraram no viewport e saíram ' + comSecoes.doNome( secao.nome ).length +
			' evento(s). O coletor observa quem carrega a classe declarada, e só'
	);

	const semSecoes = bancadaDeComportamento( fonte, dados, { alturaDocumento: 4000, secoes: [] } );

	afirmar(
		0 === semSecoes.doNome( secao.nome ).length,
		'PISO da seção vista: uma página SEM nenhuma seção marcada emitiu evento de seção. O nome sai do markup e de nenhum outro lugar — derivá-lo do título faria a série histórica mudar sozinha na primeira revisão de copy'
	);


	/*
	 * O DESPACHO DUPLO NA SAÍDA, e ele é a metade do ciclo de vida que faltava.
	 *
	 * `visibilitychange` para hidden e `pagehide` chegam um atrás do outro no
	 * mesmo carregamento, e os dois chamam `enviarResumo()`. A guarda de
	 * reentrância dele sobe e desce DENTRO da mesma execução: quando o segundo
	 * evento chega, ela já baixou. O `fetch` do primeiro despacho ainda não
	 * respondeu — é assim que ele funciona numa saída de página —, o lote
	 * continua na fila, e o segundo evento o manda de novo.
	 *
	 * COM SELO ISSO É INOFENSIVO: o servidor reconhece a repetição e responde 2xx
	 * sem gravar de novo. SEM SELO não é, e o navegador sem `crypto.getRandomValues`
	 * é exatamente esse caso: o lote sai com o selo vazio, o servidor não tem o que
	 * deduplicar, e o agregado daquele carregamento entra DOBRADO na tabela.
	 *
	 * A BANCADA PRECISA DA RESPOSTA QUE NÃO CHEGA para medir isto. Com resposta
	 * imediata, o primeiro despacho conclui e tira o lote da fila antes de o
	 * segundo evento existir — que é por que este defeito atravessou a suíte
	 * inteira sem ser visto.
	 */
	const semGerador = bancadaDeComportamento( fonte, dados, {
		alturaDocumento: 4000,
		crypto: false,
		resposta: 'pendente'
	} );

	semGerador.sair();

	const despachosSemSelo = semGerador.envios( 'fetch' );

	afirmar(
		1 === despachosSemSelo.length,
		'TETO do despacho único por lote: a saída de página despachou o MESMO lote ' + despachosSemSelo.length +
			' vez(es) com a resposta ainda pendente. Os dois eventos de saída chamam o mesmo despachante, e sem gerador criptográfico o lote vai com o selo VAZIO — o servidor não tem o que deduplicar, e o agregado daquele carregamento entra dobrado na tabela'
	);

	afirmar(
		despachosSemSelo.length > 0 && '' === String( ( JSON.parse( despachosSemSelo[ 0 ].corpo ) || {} ).lote || '' ),
		'PISO da bancada: sem gerador criptográfico o lote devia sair com o selo VAZIO, e é isso que torna o despacho duplo uma contagem dobrada em vez de uma repetição reconhecida. O corpo saiu com selo — a bancada não reproduz o caso'
	);

	const comSelo = bancadaDeComportamento( fonte, dados, { alturaDocumento: 4000, resposta: 'pendente' } );

	comSelo.sair();

	afirmar(
		1 === comSelo.envios( 'fetch' ).length,
		'TETO do despacho único por lote, COM selo: o mesmo lote saiu ' + comSelo.envios( 'fetch' ).length +
			' vez(es). O selo salva a contagem no servidor, e não o tráfego: um corpo de oito quilobytes despachado duas vezes por saída de página é do aparelho de quem está lendo'
	);

	/*
	 * PISO: sem a guarda do lote em voo, a mesma bancada tem de acusar. Sem esta
	 * mutação o teto acima passaria de graça no dia em que alguém removesse a
	 * guarda — que é exatamente o que aconteceria.
	 */
	const semGuardaDeVoo = fonte.replace( /\t\tif \(emVoo\(lote\)\) \{\n\t\t\treturn;\n\t\t\}\n\n/, '' );

	afirmar(
		semGuardaDeVoo !== fonte,
		'PISO do despacho único: a bancada não encontrou a guarda do lote em voo para removê-la. Ou ela mudou de forma, e o piso deixou de provar o que promete, ou ela sumiu — e nesse caso o teto acima é que deveria ter acusado'
	);

	if ( semGuardaDeVoo !== fonte ) {
		const mutanteDeVoo = bancadaDeComportamento( semGuardaDeVoo, dados, {
			alturaDocumento: 4000,
			crypto: false,
			resposta: 'pendente'
		} );

		mutanteDeVoo.sair();

		afirmar(
			mutanteDeVoo.envios( 'fetch' ).length > 1,
			'PISO do despacho único: removida a guarda do lote em voo, a saída de página despachou o mesmo lote ' +
				mutanteDeVoo.envios( 'fetch' ).length + ' vez(es) — e devia ter despachado mais de uma. A bancada não reproduz o defeito, e um teto que não sabe falhar não protege nada'
		);
	}

	/*
	 * O CLS NASCE `null`, e não zero — e o zero era uma medida que ninguém fez.
	 *
	 * Num navegador sem `layout-shift` (todo WebKit de iOS, até hoje) o
	 * acumulador nascia em `0`, o relator via um número e emitia `CLS = 0`: a
	 * nota máxima de estabilidade, atribuída a toda visita de iPhone. A média do
	 * site inteiro caía por conta dos navegadores que não medem, com a amostra ao
	 * lado dizendo que o número veio de muita gente.
	 */
	const semLayoutShift = bancadaDeComportamento( fonte, dados, { alturaDocumento: 4000 } );

	semLayoutShift.desempenhoEntrada( 'largest-contentful-paint', [ { startTime: 1834.6 } ] );
	semLayoutShift.sair();

	const clsRelatado = semLayoutShift.doNome( vital.nome ).filter(
		( e ) => 'CLS' === String( e[ vital.dados.parametros[ 0 ] ] )
	);

	afirmar(
		0 === clsRelatado.length,
		'TETO do CLS não medido: um navegador que não implementa layout-shift relatou CLS assim mesmo, ' +
			JSON.stringify( clsRelatado.map( ( e ) => e[ vital.dados.parametros[ 1 ] ] ) ) +
			'. Zero é a nota máxima de estabilidade, e atribuí-la a quem não mediu nada derruba a média do site com as visitas dos navegadores que não medem'
	);

	const comLayoutShift = bancadaDeComportamento( fonte, dados, { alturaDocumento: 4000 } );

	comLayoutShift.desempenhoEntrada( 'layout-shift', [ { value: 0, hadRecentInput: false } ] );
	comLayoutShift.sair();

	afirmar(
		1 === comLayoutShift.doNome( vital.nome ).filter(
			( e ) => 'CLS' === String( e[ vital.dados.parametros[ 0 ] ] )
		).length,
		'PISO do CLS não medido: a página FIRME num navegador que mede deixou de relatar CLS. O zero autorizado é o que o navegador entrega; o proibido é o que nasce no acumulador'
	);

	return { achados };
}

/**
 * `js.sessao_com_releitura` — o ciclo que o usuário descreveu, medido.
 *
 * "Se o visitante rolar e voltar a página várias vezes, disparar o trigger da
 * profundidade de leitura várias vezes. Para entendermos o comportamento se ele
 * está voltando e lendo novamente."
 *
 * Até aqui o marco alcançado ficava marcado para o resto do carregamento: quem
 * subisse e descesse de novo não produzia nada, e a pergunta "ela releu?" não
 * tinha como ser respondida — o dado não existia. Esta bancada roda o ciclo
 * inteiro contra o cliente REAL: carrega, desce até 90, volta ao topo, desce de
 * novo, sai. E prova as quatro coisas que o registro precisa entregar: a
 * segunda travessia existe, a ocorrência distingue as duas, o carimbo permite
 * calcular o tempo até cada marco, e o teto por sessão corta o excesso.
 *
 * @param {string} raiz Raiz do pacote.
 * @return {Object} Achados.
 */
function sessaoComReleitura( raiz ) {
	const alvo = entregue( raiz, 'fontes/plugin/assets/f3base-tracking.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'fontes/plugin/assets/f3base-tracking.js ausente na raiz varrida' ] };
	}

	function afirmar( ok, texto ) {
		if ( ! ok ) {
			achados.push( texto );
		}
	}

	const eventos = declaracaoDeComportamento( raiz );
	const nomes = Object.keys( eventos );

	if ( 0 === nomes.length ) {
		return { achados: [ 'teto: a declaração de eventos veio vazia' ] };
	}

	const nomeDaRolagem = nomes.find( ( n ) => 'rolagem' === eventos[ n ].gatilho );

	if ( ! nomeDaRolagem ) {
		return { achados: [ 'teto: nenhum evento com o gatilho "rolagem"' ] };
	}

	const marcos = ( eventos[ nomeDaRolagem ].limiar.marcos || [] ).map( Number ).sort( ( a, b ) => a - b );
	const tetoDeTravessias = Number( eventos[ nomeDaRolagem ].limiar.travessias_por_sessao || 0 );

	afirmar(
		tetoDeTravessias > 0,
		'teto da declaração: travessias_por_sessao não está declarado no limiar da rolagem. Sem teto, uma rolagem inquieta produz registro infinito — e o corte tem de ser nosso e escrito, nunca uma amostragem silenciosa'
	);

	const dados = {
		caminho: 'direto',
		gtm: '',
		ga4: 'G-ABCDEF1234',
		ads: { id: '', label: '' },
		meta: { pixelId: '', origem: '' },
		linkedin: { partnerId: '', conversionId: '', origem: '' },
		origemGoogle: 'https://www.googletagmanager.com/',
		comportamento: { eventos, prefixoSecao: 'f3base-secao-' },
		resumo: {
			ativo: true,
			endpoint: 'https://exemplo.test/wp-json/f3base/v1/comportamento',
			esquecer: 'https://exemplo.test/wp-json/f3base/v1/comportamento/esquecer',
			token: 'token-da-bancada',
			maximo: 60,
			maximoLog: 180,
			maximoVisita: 300,
			/*
			 * A POLÍTICA CHEGA DO SERVIDOR, e o AVISO de primeira visita não: o
			 * apelido do visitante segue o PORTÃO, e não o banner. Uma bancada que
			 * publicasse o aviso estaria publicando um campo que o servidor não
			 * publica mais, com a aparência de que ele decide alguma coisa.
			 */
			politica: 'pre-aprovado'
		}
	};

	/* O CICLO QUE O USUÁRIO DESCREVEU, e ele é um só carregamento. */
	const b = bancadaDeComportamento( fonte, dados, { alturaDocumento: 8000, semente: 3 } );

	b.rolarAte( 30 );
	b.rolarAte( 60 );
	b.rolarAte( 95 );
	b.rolarAte( 0 );
	b.rolarAte( 95 );
	b.sair();

	const carga = b.cargas().filter( Boolean )[ 0 ];

	afirmar( !! carga, 'teto: a sessão não despachou corpo nenhum ao sair' );

	if ( ! carga ) {
		return { achados };
	}

	const registro = ( carga.eventos || [] ).filter( ( e ) => 'rolagem' === e.gatilho );

	/* TETO 1: A SEGUNDA TRAVESSIA EXISTE. */
	for ( const marco of marcos ) {
		const doMarco = registro.filter( ( e ) => String( marco ) === String( e.detalhe ) );

		afirmar(
			2 === doMarco.length,
			'TETO da releitura: o marco de ' + marco + '% foi registrado ' + doMarco.length +
				' vez(es) numa sessão que desceu, voltou ao topo e desceu de novo. A segunda travessia é a releitura, e é a pergunta inteira do usuário: sem ela o dado não existe e a tela não tem o que mostrar'
		);

		/* TETO 2: A OCORRÊNCIA DISTINGUE AS DUAS. */
		const ocorrencias = doMarco.map( ( e ) => Number( e.ocorrencia ) ).sort( ( a, b ) => a - b );

		afirmar(
			JSON.stringify( ocorrencias ) === JSON.stringify( [ 1, 2 ] ),
			'TETO da ocorrência: as travessias do marco de ' + marco + '% saíram como ' + JSON.stringify( ocorrencias ) +
				' em vez de [1,2]. Sem a ocorrência as duas linhas são indistinguíveis, e "voltou e leu de novo" fica igual a "leu duas páginas"'
		);
	}

	/* TETO 3: O CARIMBO PERMITE CALCULAR O TEMPO ATÉ CADA MARCO. */
	const primeiras = registro.filter( ( e ) => 1 === Number( e.ocorrencia ) );

	afirmar(
		primeiras.every( ( e ) => 'number' === typeof e.ms && e.ms >= 0 ),
		'TETO do carimbo: alguma travessia saiu sem carimbo de tempo em milissegundos, e é ele que responde quanto tempo o visitante levou para chegar ali'
	);

	const porMarco = {};

	for ( const linha of primeiras ) {
		porMarco[ String( linha.detalhe ) ] = Number( linha.ms );
	}

	const emOrdem = marcos.map( ( m ) => porMarco[ String( m ) ] );

	afirmar(
		emOrdem.every( ( v, i ) => undefined !== v && ( 0 === i || v >= emOrdem[ i - 1 ] ) ),
		'TETO do carimbo: os tempos da primeira descida não são crescentes do marco menor para o maior (' + JSON.stringify( emOrdem ) +
			'). O visitante passa por 25% antes de 50%, e um carimbo que não respeite isso não mede tempo de percurso'
	);

	/* TETO 4: O AGREGADO NÃO DOBRA — releitura não vira audiência. */
	const totalDoMarco = ( carga.metricas || [] ).filter( ( m ) => 'rolagem' === m.gatilho );

	afirmar(
		totalDoMarco.every( ( m ) => 1 === Number( m.contagem ) ),
		'TETO do agregado: a releitura foi somada no total do painel. As duas leituras convivem de propósito — o total responde "quantas visitas chegaram até aqui" e o registro responde "quantas vezes cada uma passou" —, e somar a releitura no total transforma uma pessoa inquieta em audiência que não existe'
	);

	/* PISO: O TETO POR SESSÃO CORTA O EXCESSO. */
	const inquieto = bancadaDeComportamento( fonte, dados, { alturaDocumento: 8000, semente: 5 } );

	for ( let volta = 0; volta < tetoDeTravessias + 4; volta++ ) {
		inquieto.rolarAte( 95 );
		inquieto.rolarAte( 0 );
	}

	inquieto.sair();

	const cargaInquieta = inquieto.cargas().filter( Boolean )[ 0 ];
	const registroInquieto = ( ( cargaInquieta || {} ).eventos || [] ).filter( ( e ) => 'rolagem' === e.gatilho && '90' === String( e.detalhe ) );

	afirmar(
		registroInquieto.length === tetoDeTravessias,
		'PISO do teto por sessão: uma sessão com ' + ( tetoDeTravessias + 4 ) + ' travessias do mesmo marco registrou ' +
			registroInquieto.length + ' linha(s), e o teto declarado é ' + tetoDeTravessias +
			'. Registro sem teto é tabela que cresce com rolagem inquieta sem responder nada melhor'
	);

	afirmar(
		registroInquieto.every( ( e ) => Number( e.ocorrencia ) <= tetoDeTravessias ),
		'PISO do teto por sessão: uma linha passou com ocorrência acima do teto declarado'
	);

	/*
	 * O BLOCO VISTO TRÊS VEZES NA MESMA VISITA — o pedido literal do usuário:
	 * *"todas as vezes que ela for acionada mesmo que seja pelo mesmo visitante
	 * e durante a mesma sessão."*
	 *
	 * Até a 1.2.1 o observador fazia `unobserve` na primeira aparição: cada
	 * bloco era registrado UMA vez por visita e nunca duas, e "ele voltou e
	 * releu este bloco?" não tinha resposta porque o dado não existia.
	 */
	const relendo = bancadaDeComportamento( fonte, dados, {
		alturaDocumento: 8000,
		semente: 61,
		secoes: [ 'wp-block-group f3base-secao-abertura' ]
	} );

	relendo.verSecao( 0 );
	relendo.esconderSecao( 0 );
	relendo.verSecao( 0 );
	relendo.esconderSecao( 0 );
	relendo.verSecao( 0 );
	relendo.sair();

	const cargaRelendo = relendo.cargas().filter( Boolean )[ 0 ] || {};
	const doBloco = ( cargaRelendo.eventos || [] ).filter( ( e ) => 'interseccao' === e.gatilho && 'abertura' === e.detalhe );

	afirmar(
		3 === doBloco.length,
		'TETO do bloco relido: uma visita que viu o mesmo bloco três vezes gravou ' + doBloco.length +
			' linha(s). O usuário pediu TODAS as vezes, inclusive na mesma visita: sem o rearme, o observador larga o bloco na primeira aparição e a releitura não existe como dado'
	);

	afirmar(
		JSON.stringify( doBloco.map( ( e ) => Number( e.ocorrencia ) ).sort( ( a, b ) => a - b ) ) === JSON.stringify( [ 1, 2, 3 ] ),
		'TETO da vez: as três passagens pelo bloco saíram como ' +
			JSON.stringify( doBloco.map( ( e ) => e.ocorrencia ) ) + ' em vez de 1ª, 2ª e 3ª. É a vez que distingue a leitura da releitura na tabela'
	);

	const horarios = doBloco.map( ( e ) => Number( e.ms ) );

	afirmar(
		horarios.length === new Set( horarios ).size || horarios.every( ( v, i ) => 0 === i || v >= horarios[ i - 1 ] ),
		'TETO do horário: as três passagens saíram com carimbos ' + JSON.stringify( horarios ) +
			' — eles precisam ser crescentes, porque é deles que sai a hora de cada linha da tabela'
	);

	afirmar(
		( cargaRelendo.metricas || [] ).filter( ( m ) => 'interseccao' === m.gatilho ).every( ( m ) => 1 === Number( m.contagem ) ),
		'TETO do agregado: a releitura do bloco foi somada no total do painel. O total responde "quantas visitas viram este bloco" e a tabela responde "quantas vezes cada uma o viu"'
	);

	/*
	 * PISO DO TETO DA VISITA: o orçamento é da VISITA inteira e o excedente sai
	 * NOMEADO. Um teto que corta em silêncio faz o total do painel não bater com
	 * a tabela sem nada em lugar nenhum dizendo por quê.
	 */
	const apertado = Object.assign( {}, dados, {
		resumo: Object.assign( {}, dados.resumo, { maximoVisita: 4 } )
	} );

	const estourou = bancadaDeComportamento( fonte, apertado, {
		alturaDocumento: 8000,
		semente: 71,
		secoes: [ 'wp-block-group f3base-secao-abertura' ]
	} );

	for ( let volta = 0; volta < 10; volta++ ) {
		estourou.verSecao( 0 );
		estourou.esconderSecao( 0 );
	}

	estourou.sair();

	const cargaEstourada = estourou.cargas().filter( Boolean )[ 0 ] || {};

	afirmar(
		4 === ( cargaEstourada.eventos || [] ).length,
		'PISO do teto da visita: com o teto em 4, a visita gravou ' + ( cargaEstourada.eventos || [] ).length +
			' linha(s). O teto existe porque um erro de JavaScript em laço de render dispara milhares de vezes em segundos e encheria a tabela sozinho'
	);

	afirmar(
		Number( cargaEstourada.cortados ) > 0,
		'PISO do corte nomeado: o excedente do teto da visita saiu como ' + cargaEstourada.cortados +
			'. Corte silencioso faz o total do painel não bater com a tabela, sem nada em lugar nenhum dizendo por quê'
	);

	/*
	 * A VISITA ATRAVESSA PÁGINAS, e é isto que faz a palavra "visita" valer o
	 * que ela promete. Um segundo carregamento dentro da janela de inatividade
	 * continua a MESMA visita, e o orçamento dela continua de onde parou.
	 */
	const primeiraPagina = bancadaDeComportamento( fonte, dados, { alturaDocumento: 8000, semente: 83 } );

	primeiraPagina.rolarAte( 95 );
	primeiraPagina.sair();

	const cargaPrimeira = primeiraPagina.cargas().filter( Boolean )[ 0 ] || {};
	const guardado = primeiraPagina.gravacoes().filter( ( g ) => 'f3base_sessao' === g.chave ).pop();

	const segundaPagina = bancadaDeComportamento( fonte, dados, {
		alturaDocumento: 8000,
		semente: 97,
		armazenado: {
			f3base_visitante: ( primeiraPagina.gravacoes().find( ( g ) => 'f3base_visitante' === g.chave ) || {} ).valor,
			f3base_sessao: ( guardado || {} ).valor
		}
	} );

	segundaPagina.rolarAte( 95 );
	segundaPagina.sair();

	const cargaSegunda = segundaPagina.cargas().filter( Boolean )[ 0 ] || {};

	afirmar(
		cargaPrimeira.sessao === cargaSegunda.sessao && '' !== String( cargaSegunda.sessao || '' ),
		'TETO da visita que atravessa páginas: o segundo carregamento começou uma visita nova ("' + cargaSegunda.sessao +
			'" contra "' + cargaPrimeira.sessao + '"). A coluna se chama VISITA e precisa responder "quantas páginas ele viu nesta visita" — sorteando por carregamento, ela responde sempre uma'
	);

	afirmar(
		cargaPrimeira.visitante === cargaSegunda.visitante,
		'TETO da visita que atravessa páginas: o apelido do visitante mudou entre duas páginas da mesma navegação'
	);

	/* PISO: passada a janela de inatividade, a visita seguinte é OUTRA. */
	let visitaVelha = {};

	try {
		visitaVelha = JSON.parse( String( ( guardado || {} ).valor || '{}' ) );
	} catch {
		visitaVelha = {};
	}

	const depoisDaJanela = bancadaDeComportamento( fonte, dados, {
		alturaDocumento: 8000,
		semente: 101,
		armazenado: {
			f3base_visitante: ( primeiraPagina.gravacoes().find( ( g ) => 'f3base_visitante' === g.chave ) || {} ).valor,
			f3base_sessao: JSON.stringify( Object.assign( {}, visitaVelha, { visto: Date.now() - ( 31 * 60 * 1000 ) } ) )
		}
	} );

	depoisDaJanela.rolarAte( 95 );
	depoisDaJanela.sair();

	const cargaDepois = depoisDaJanela.cargas().filter( Boolean )[ 0 ] || {};

	afirmar(
		cargaDepois.sessao !== cargaPrimeira.sessao,
		'PISO da janela de inatividade: uma volta depois de trinta e um minutos continuou a MESMA visita. Quem volta depois de meia hora voltou por outro motivo, e juntar as duas faria a visita crescer para sempre'
	);

	afirmar(
		cargaDepois.visitante === cargaPrimeira.visitante,
		'PISO da janela de inatividade: o apelido do VISITANTE também mudou. Ele atravessa visitas de propósito — é a diferença entre ele e a visita, e sem ela não há como contar quem volta'
	);

	/*
	 * O CICLO REAL DA VISITA, e é o que a bancada nunca exercitou.
	 *
	 * A bancada sempre simulou ocultar-e-voltar com toda a atividade ANTES do
	 * primeiro ocultamento. O ciclo do visitante de verdade é outro:
	 *
	 *   carrega → o bloco do topo entra em vista → a aba PERDE O FOCO (e o
	 *   primeiro lote parte) → a aba volta → a pessoa rola até o fim, cruzando
	 *   os quatro marcos e todos os blocos → sai (e o segundo lote parte).
	 *
	 * Com um envio só, tudo depois do primeiro ocultamento morria na memória.
	 * Numa visita medida em produção, cada carregamento registrou o primeiro
	 * segundo — a abertura da página e o bloco que já estava no topo — e nenhuma
	 * rolagem, nunca. `visibilitychange` para `hidden` dispara quando a aba
	 * perde o foco, e não só quando a pessoa sai.
	 */
	const doisLotes = bancadaDeComportamento( fonte, dados, {
		alturaDocumento: 8000,
		semente: 131,
		secoes: [ 'wp-block-group f3base-secao-abertura', 'wp-block-group f3base-secao-final' ]
	} );

	doisLotes.verSecao( 0 );
	doisLotes.ocultar();
	doisLotes.voltarAVer();
	doisLotes.rolarAte( 30 );
	doisLotes.rolarAte( 60 );
	doisLotes.rolarAte( 95 );
	doisLotes.verSecao( 1 );
	doisLotes.sair();

	const lotes = doisLotes.cargas().filter( Boolean );

	afirmar(
		2 === lotes.length,
		'TETO dos dois lotes: a visita produziu ' + lotes.length +
			' lote(s). A aba que perde o foco no meio da leitura despacha o que houve até ali e precisa continuar ouvindo: com um envio só, tudo o que a pessoa rolar depois morre na memória — foi assim que uma visita inteira registrou só o primeiro segundo de cada página'
	);

	if ( 2 === lotes.length ) {
		const gatilhosDoLote = ( lote ) => ( lote.eventos || [] ).map( ( e ) => String( e.gatilho ) + '|' + String( e.detalhe || '' ) + '|' + String( e.ocorrencia ) );

		const primeiros = gatilhosDoLote( lotes[ 0 ] );
		const segundos = gatilhosDoLote( lotes[ 1 ] );

		afirmar(
			segundos.some( ( g ) => g.startsWith( 'rolagem|' ) ),
			'TETO do segundo lote: a rolagem feita DEPOIS do primeiro ocultamento não chegou ao servidor. É exatamente o que o usuário relatou — ele rolou até o fim e nenhuma rolagem foi gravada'
		);

		afirmar(
			segundos.some( ( g ) => g.startsWith( 'interseccao|final|' ) ),
			'TETO do segundo lote: o bloco visto DEPOIS do primeiro ocultamento não chegou ao servidor. Um bloco por carregamento, sempre o que já estava no topo, era a assinatura do defeito'
		);

		const repetidos = primeiros.filter( ( g ) => segundos.includes( g ) );

		afirmar(
			0 === repetidos.length,
			'PISO da contagem dobrada: ' + JSON.stringify( repetidos ) +
				' viajou nos DOIS lotes. Cada lote leva só o que foi acumulado desde o anterior — enviar-e-limpar resolve o reenvio por construção, e não com uma trava que deixa a página surda'
		);

		afirmar(
			primeiros.some( ( g ) => g.startsWith( 'interseccao|abertura|' ) ),
			'TETO do primeiro lote: o bloco visto ANTES do ocultamento não foi despachado no primeiro lote'
		);

		const vitaisPorLote = lotes.map( ( lote ) => ( lote.eventos || [] ).filter( ( e ) => 'desempenho' === e.gatilho ).length );

		afirmar(
			1 >= vitaisPorLote.filter( ( n ) => n > 0 ).length,
			'PISO das vitais: as medidas de carregamento apareceram em mais de um lote (' + JSON.stringify( vitaisPorLote ) +
				'). Elas têm valor final único por carregamento e trava própria: o rearme é do LOTE, e não do relator de vitais'
		);
	}

	/*
	 * PISO DO LOTE VAZIO: ocultar sem nada ter acontecido desde o último envio
	 * não produz requisição nenhuma. É esta guarda — e não uma trava permanente
	 * — que impede o mesmo conteúdo de ir duas vezes pelos dois eventos de
	 * saída, que disparam juntos.
	 */
	const semNovidade = bancadaDeComportamento( fonte, dados, { alturaDocumento: 8000, semente: 137 } );

	semNovidade.rolarAte( 95 );
	semNovidade.sair();

	const antesDaEspera = semNovidade.beacons().length;

	semNovidade.voltarAVer();
	semNovidade.ocultar();
	semNovidade.voltarAVer();
	semNovidade.sair();

	afirmar(
		antesDaEspera === semNovidade.beacons().length,
		'PISO do lote vazio: ocultar sem nada novo produziu ' + ( semNovidade.beacons().length - antesDaEspera ) +
			' requisição(ões) a mais. Lote vazio é requisição sem conteúdo, e a aba que vai e volta produz muitas'
	);

	/*
	 * PISO DA RECUSA: `sendBeacon` devolve `false` quando a fila do navegador
	 * está cheia ou o corpo passa do limite. Esvaziar o acumulado sobre uma
	 * recusa perderia o lote em silêncio.
	 */
	const recusado = bancadaDeComportamento( fonte, dados, {
		alturaDocumento: 8000,
		semente: 139,
		beaconRecusa: true
	} );

	recusado.rolarAte( 95 );
	recusado.ocultar();
	recusado.voltarAVer();
	recusado.aceitarBeacon();
	recusado.sair();

	const depoisDaRecusa = recusado.cargas().filter( Boolean );
	const rolagensRecuperadas = depoisDaRecusa.length > 0
		? ( depoisDaRecusa[ depoisDaRecusa.length - 1 ].eventos || [] ).filter( ( e ) => 'rolagem' === e.gatilho ).length
		: 0;

	afirmar(
		rolagensRecuperadas > 0,
		'PISO da recusa: o lote recusado pelo navegador foi descartado — a tentativa seguinte levou ' + rolagensRecuperadas +
			' rolagem(ns). Só se limpa o que foi ACEITO, senão o lote se perde calado'
	);

	/*
	 * O CICLO REAL, DIRIGIDO SÓ POR ROLAGEM — e é ele que separa esta bancada
	 * do mundo que ela promete medir.
	 *
	 * Tudo acima usa `verSecao`/`esconderSecao`, que entregam
	 * `{ isIntersecting: true|false }` À MÃO, sem razão de interseção. O
	 * navegador não faz isso: ele entrega uma RAZÃO, e entrega um retorno toda
	 * vez que ela cruza uma linha declarada — inclusive quando ela CAI abaixo
	 * da linha com o alvo ainda sobreposto. Este caso não toca em seção
	 * nenhuma: ele rola, e as seções se movem porque o documento tem geometria.
	 *
	 * A GEOMETRIA É DECLARADA AQUI porque a página deste caso é a página do
	 * defeito: curta o bastante para que abertura e meio NUNCA saiam inteiros
	 * da tela. É a página real mais comum — uma landing de duas telas —, e é
	 * nela que a assimetria de entrada e saída aparece inteira: com a saída
	 * decidida por `isIntersecting`, os dois blocos são gravados UMA vez por
	 * carregamento e a releitura simplesmente não existe como dado. `final`
	 * sai inteiro da tela de propósito, para que o caso fácil — o único que o
	 * código antigo acertava — continue coberto ao lado do difícil.
	 */
	const paginaCurta = {
		alturaDocumento: 2200,
		semente: 149,
		secoes: [
			'wp-block-group f3base-secao-abertura',
			'wp-block-group f3base-secao-meio',
			'wp-block-group f3base-secao-final',
			'wp-block-group f3base-secao-banda'
		],
		/*
		 * A GEOMETRIA MUDOU NA 1.3.6, E A MUDANÇA É O PREÇO DA BANDA ESCRITO EM
		 * NÚMEROS.
		 *
		 * `meio` ficava em `topo: 500`, e ali a razão dele descia até 0,4 e
		 * voltava. Com a saída na MESMA linha da entrada isso rearmava; com a
		 * linha de saída declarada em 0,2, não rearma mais — e essa é
		 * exatamente a reentrada que a banda descarta de propósito. O bloco foi
		 * movido para `topo: 600`, onde a razão dele CRUZA a linha declarada
		 * (0,133 no topo do documento), porque o que este caso mede é a
		 * travessia de verdade.
		 *
		 * O caso que ele deixou de medir não sumiu: ele virou `banda`, o quarto
		 * bloco, que oscila entre 0,233 e 0,533 sem nunca cruzar 0,2 e por isso
		 * tem de sair com UMA ocorrência só. Trocar a geometria sem deixar o
		 * caso antigo medido em algum lugar seria ajustar a bancada ao código,
		 * que é o contrário do que ela serve.
		 *
		 * `abertura` e `meio` NUNCA saem inteiros da tela (razão sempre maior
		 * que zero) — é isso que faz o mutante da 1.3.3 prendê-los em uma
		 * ocorrência. `final` sai inteiro de propósito: é o caso fácil, o único
		 * que o código antigo acertava, e ele fica aqui para separar a
		 * assimetria de um defeito qualquer.
		 */
		geometria: [
			{ topo: 0, altura: 1500 },
			{ topo: 600, altura: 1500 },
			{ topo: 900, altura: 1300 },
			{ topo: 450, altura: 1500 }
		]
	};

	/* Desce até o fim, volta ao topo e desce de novo. Nada além de rolagem. */
	const descidaEVolta = [ 0, 25, 50, 75, 100, 0, 25, 50, 75, 100 ];

	/**
	 * O ciclo inteiro contra uma fonte, e o registro que chegou ao servidor.
	 *
	 * @param {string} codigo Fonte do cliente a exercitar.
	 * @return {Array<Object>} Linhas do registro despachado.
	 */
	function registroDoCiclo( codigo ) {
		const bancada = bancadaDeComportamento( codigo, dados, paginaCurta );

		for ( const parada of descidaEVolta ) {
			bancada.rolarAte( parada );
		}

		bancada.sair();

		const despachado = bancada.cargas().filter( Boolean );
		const linhas = [];

		for ( const lote of despachado ) {
			for ( const linha of lote.eventos || [] ) {
				linhas.push( linha );
			}
		}

		return linhas;
	}

	/**
	 * As ocorrências de um gatilho e detalhe, em ordem.
	 *
	 * @param {Array<Object>} linhas  Registro despachado.
	 * @param {string}        gatilho Gatilho procurado.
	 * @param {string}        detalhe Detalhe procurado.
	 * @return {Array<number>} Ocorrências.
	 */
	function ocorrenciasDe( linhas, gatilho, detalhe ) {
		return linhas
			.filter( ( e ) => gatilho === e.gatilho && String( detalhe ) === String( e.detalhe || '' ) )
			.map( ( e ) => Number( e.ocorrencia ) )
			.sort( ( a, b ) => a - b );
	}

	const doCiclo = registroDoCiclo( fonte );

	for ( const bloco of [ 'abertura', 'meio', 'final' ] ) {
		const vezes = ocorrenciasDe( doCiclo, 'interseccao', bloco );

		afirmar(
			JSON.stringify( vezes ) === JSON.stringify( [ 1, 2 ] ),
			'TETO do ciclo rolado: o bloco "' + bloco + '" saiu com as ocorrências ' + JSON.stringify( vezes ) +
				' em vez de [1,2] numa visita que rolou até o fim e voltou ao topo. É o caso real medido em produção em ' +
				'wp_2zsugm_f3base_eventos: o visitante rolou até o fim e voltou ao topo, e o bloco foi gravado uma vez só — ' +
				'ocorrencia nunca passou de 1 em nenhuma das 80 linhas medidas em produção'
		);
	}

	for ( const marco of marcos ) {
		const vezes = ocorrenciasDe( doCiclo, 'rolagem', marco );

		afirmar(
			JSON.stringify( vezes ) === JSON.stringify( [ 1, 2 ] ),
			'TETO do ciclo rolado: o marco de ' + marco + '% saiu com as ocorrências ' + JSON.stringify( vezes ) +
				' em vez de [1,2]. A segunda descida é a releitura, e ela precisa aparecer com a própria ocorrência'
		);
	}

	/*
	 * A BANDA DA SEÇÃO, e ela é medida nos DOIS sentidos.
	 *
	 * `visivel` é a linha de ENTRADA e `saida` é a de SAÍDA, as duas declaradas
	 * na mesma célula de limiar do TSV. Entre elas o estado não muda: nem entra,
	 * porque não alcançou `visivel`; nem rearma, porque não caiu abaixo de
	 * `saida`. Um teste que só medisse a travessia aprovaria um código sem banda
	 * nenhuma, porque a travessia acontece nos dois.
	 *
	 * O bloco `banda` oscila entre 0,233 e 0,533 nesta página — sobe acima da
	 * linha de entrada, desce até o meio da banda e volta — e por isso tem de
	 * sair com UMA ocorrência: ele nunca cruzou a linha de saída. É o caso que
	 * `meio` media antes de a banda existir, e é o único lugar da bancada em que
	 * a diferença entre as duas linhas aparece.
	 */
	const secaoDeclarada = nomes.find( ( n ) => 'interseccao' === eventos[ n ].gatilho );

	afirmar(
		!! secaoDeclarada,
		'teto da declaração: nenhum evento com o gatilho "interseccao" na declaração lida do TSV'
	);

	const linhaDeEntrada = Number( ( eventos[ secaoDeclarada ] || { limiar: {} } ).limiar.visivel || 0 );
	const linhaDeSaida = Number( ( eventos[ secaoDeclarada ] || { limiar: {} } ).limiar.saida || 0 );

	afirmar(
		linhaDeSaida > 0 && linhaDeSaida < linhaDeEntrada,
		'TETO da declaração: a linha de saída da seção saiu como ' + JSON.stringify( ( eventos[ secaoDeclarada ] || { limiar: {} } ).limiar.saida ) +
			' contra a entrada em ' + JSON.stringify( ( eventos[ secaoDeclarada ] || { limiar: {} } ).limiar.visivel ) +
			'. A banda precisa ser DECLARADA e menor que a entrada: sem `saida` no TSV o cliente cai no comportamento simétrico, ' +
			'e a folga entre a razão zero e o `visivel` volta a ser a única histerese que a seção tem — que foi o defeito da 1.3.3'
	);

	afirmar(
		JSON.stringify( ocorrenciasDe( doCiclo, 'interseccao', 'banda' ) ) === JSON.stringify( [ 1 ] ),
		'TETO da banda: o bloco "banda" saiu com ' + JSON.stringify( ocorrenciasDe( doCiclo, 'interseccao', 'banda' ) ) +
			' e o esperado é [1]. A razão dele oscila entre 0,233 e 0,533 e NUNCA cai abaixo da linha de saída declarada: ' +
			'sem banda, a queda a 0,367 rearmaria o bloco e a subida seguinte contaria como releitura que ninguém fez'
	);

	/*
	 * MUTAÇÃO DA BANDA: rearmar na linha de ENTRADA, que é o código da 1.3.5.
	 *
	 * É a mutação que o pedido nomeia — trocar `razao < saida` por
	 * `razao < visivel` —, e ela precisa ser acusada nos DOIS lados: o bloco da
	 * banda passa a contar duas vezes, e os blocos que cruzam a linha ganham uma
	 * ocorrência a mais no meio do percurso. Sem esta mutação a linha de saída
	 * poderia ser qualquer número, porque nada mediria a diferença.
	 */
	const rearmaNaEntrada = fonte.replace( 'if (!entradas[j].isIntersecting || razao < saida) {', 'if (!entradas[j].isIntersecting || razao < visivel) {' );

	afirmar(
		rearmaNaEntrada !== fonte,
		'PISO da banda: a bancada não encontrou a saída pela linha declarada para trocá-la pela linha de entrada. ' +
			'Ou ela mudou de forma e o piso deixou de provar o que promete, ou sumiu — e nesse caso o teto acima é que deveria ter acusado'
	);

	if ( rearmaNaEntrada !== fonte ) {
		const doMutanteDaBanda = registroDoCiclo( rearmaNaEntrada );

		afirmar(
			ocorrenciasDe( doMutanteDaBanda, 'interseccao', 'banda' ).length > 1,
			'PISO da banda: rearmando na linha de ENTRADA, o bloco "banda" saiu com ' +
				JSON.stringify( ocorrenciasDe( doMutanteDaBanda, 'interseccao', 'banda' ) ) +
				' e ele deveria ter contado mais de uma vez. A bancada não reproduz o comportamento sem banda, ' +
				'e um piso que não sabe falhar não prova que a linha de saída está fazendo alguma coisa'
		);

		afirmar(
			doMutanteDaBanda.filter( ( e ) => 'interseccao' === e.gatilho ).length >
				doCiclo.filter( ( e ) => 'interseccao' === e.gatilho ).length,
			'PISO da banda: rearmando na linha de entrada, o percurso gravou ' +
				doMutanteDaBanda.filter( ( e ) => 'interseccao' === e.gatilho ).length +
				' linha(s) de interseção contra ' + doCiclo.filter( ( e ) => 'interseccao' === e.gatilho ).length +
				' do pacote. Sem banda, toda passagem pela faixa entre as duas linhas vira uma ocorrência a mais — ' +
				'e se a bancada não vê essa diferença, ela não está medindo a banda, está medindo a travessia, que os dois códigos acertam'
		);
	}

	/*
	 * PISO DA DECLARAÇÃO INCOERENTE: a banda impossível volta ao SIMÉTRICO.
	 *
	 * `saida` ausente, não numérica, negativa ou maior/igual a `visivel` não
	 * descreve banda nenhuma. A banda INVERTIDA é a pior das quatro: com a saída
	 * acima da entrada, o bloco rearma enquanto ainda está mais visível do que a
	 * entrada exige, e cada oscilação vira ocorrência até o teto por visita
	 * cortar — gravando travessias que ninguém fez. O cliente cai em
	 * `saida = visivel`, que é o comportamento de antes desta linha, e o piso
	 * mede as quatro declarações contra ESSE comportamento.
	 */

	/**
	 * A declaração com outra linha de saída, sem tocar no resto.
	 *
	 * @param {*} valor Valor declarado para `saida`, como o TSV o entrega.
	 * @return {Object} Dados publicados ao cliente.
	 */
	function comSaidaDeclarada( valor ) {
		const copia = JSON.parse( JSON.stringify( eventos ) );

		if ( null === valor ) {
			delete copia[ secaoDeclarada ].limiar.saida;
		} else {
			copia[ secaoDeclarada ].limiar.saida = [ String( valor ) ];
		}

		return Object.assign( {}, dados, {
			comportamento: Object.assign( {}, dados.comportamento, { eventos: copia } )
		} );
	}

	/**
	 * O mesmo percurso, com a declaração trocada.
	 *
	 * @param {*} valor Valor declarado para `saida`.
	 * @return {Array<Object>} Linhas do registro despachado.
	 */
	function cicloComSaida( valor ) {
		const bancada = bancadaDeComportamento( fonte, comSaidaDeclarada( valor ), paginaCurta );

		for ( const parada of descidaEVolta ) {
			bancada.rolarAte( parada );
		}

		bancada.sair();

		const linhas = [];

		for ( const lote of bancada.cargas().filter( Boolean ) ) {
			for ( const linha of lote.eventos || [] ) {
				linhas.push( linha );
			}
		}

		return linhas;
	}

	/*
	 * O COMPORTAMENTO SIMÉTRICO é medido uma vez, com a saída declarada IGUAL à
	 * entrada, e é contra ele que as quatro declarações incoerentes são
	 * comparadas. Escrever a sequência esperada à mão aqui seria uma segunda
	 * fonte para o mesmo fato — e ela divergiria na primeira vez que alguém
	 * mexesse na geometria desta página.
	 */
	const simetrico = JSON.stringify( [ 'abertura', 'meio', 'final', 'banda' ].map(
		( bloco ) => ocorrenciasDe( cicloComSaida( linhaDeEntrada ), 'interseccao', bloco )
	) );

	for ( const incoerente of [ null, 'nao-e-numero', '-1', String( linhaDeEntrada ), '0.9' ] ) {
		const doIncoerente = cicloComSaida( incoerente );
		const sequencias = JSON.stringify( [ 'abertura', 'meio', 'final', 'banda' ].map(
			( bloco ) => ocorrenciasDe( doIncoerente, 'interseccao', bloco )
		) );

		afirmar(
			sequencias === simetrico,
			'PISO da declaração incoerente: com `saida` declarada como ' + JSON.stringify( incoerente ) +
				' o percurso entregou ' + sequencias + ' e o comportamento simétrico entrega ' + simetrico +
				'. Declaração que não descreve uma banda tem de cair na MESMA linha nos dois sentidos — que é o comportamento de antes desta release —, ' +
				'e nunca numa banda invertida: com a saída acima da entrada o bloco rearma mais visível do que entrou, e cada oscilação vira ocorrência'
		);

		afirmar(
			doIncoerente.filter( ( e ) => 'interseccao' === e.gatilho ).length <= 12,
			'PISO da declaração incoerente: com `saida` declarada como ' + JSON.stringify( incoerente ) +
				' o percurso gravou ' + doIncoerente.filter( ( e ) => 'interseccao' === e.gatilho ).length +
				' linha(s) de interseção. Uma banda invertida conta a cada oscilação até o teto por visita cortar, ' +
				'e o corte sai nomeado como se a culpa fosse do visitante'
		);
	}

	/*
	 * PISO DA ASSIMETRIA: o código de HOJE tem de ser acusado por este teto.
	 *
	 * O mutante é exatamente o que o pacote fazia — observar com
	 * `threshold: visivel` e decidir a saída por `isIntersecting`. As duas
	 * linhas eram DIFERENTES: entrava-se na razão declarada e só se saía na
	 * razão ZERO. Sem esta mutação o piso não prova nada, porque foi
	 * precisamente esse código que passou na bancada anterior.
	 */
	const bandaDoObservador = '\t\t\t\tif (razao < visivel) {\n\t\t\t\t\tcontinue;\n\t\t\t\t}\n\n';

	/*
	 * O MUTANTE É A SAÍDA POR `isIntersecting` COM O `0` NA LISTA DE FAIXAS, e a
	 * lista NÃO é trocada de propósito. Medido em Chromium: com `threshold`
	 * contendo `0`, qualquer sobreposição faz `isIntersecting` verdadeiro, e a
	 * linha de saída vira a razão ZERO — o bloco que nunca sai inteiro da tela
	 * não rearma nunca. É exatamente o defeito da 1.3.3, e é o que a sonda de
	 * navegador planta também.
	 *
	 * Trocar TAMBÉM o `threshold` por `visivel` sozinho não produziria defeito
	 * nenhum: sem o `0` na lista, `isIntersecting` PASSA A SER a linha declarada
	 * — razão 0,4 chega com `isIntersecting: false` —, e decidir a saída por ele
	 * dá o mesmo resultado de decidir por `razao < visivel`. A bancada afirmava o
	 * contrário até esta release porque modelava `isIntersecting` como
	 * sobreposição geométrica, e foi a sonda de navegador que mostrou a
	 * diferença.
	 */
	const assimetrico = fonte
		.replace( 'if (!entradas[j].isIntersecting || razao < saida) {', 'if (!entradas[j].isIntersecting) {' )
		.replace( bandaDoObservador, '' );

	afirmar(
		assimetrico !== fonte &&
			! assimetrico.includes( 'razao < saida' ) &&
			! assimetrico.includes( 'razao < visivel' ),
		'PISO da assimetria: a bancada não encontrou as duas peças da decisão do observador de seções para desfazê-las — ' +
			'a saída pela linha declarada e o ramo inerte da banda. ' +
			'Ou elas mudaram de forma e o piso deixou de provar o que promete, ou sumiram — e nesse caso o teto acima é que deveria ter acusado'
	);

	if ( assimetrico !== fonte ) {
		const doMutante = registroDoCiclo( assimetrico );
		const presos = [ 'abertura', 'meio' ].filter(
			( bloco ) => 1 === ocorrenciasDe( doMutante, 'interseccao', bloco ).length
		);

		afirmar(
			2 === presos.length,
			'PISO da assimetria: com a saída decidida por isIntersecting e o observador armado só com o limiar declarado, ' +
				'o ciclo rolado registrou releitura em ' + JSON.stringify( presos ) +
				' — e os dois blocos que nunca saem inteiros da tela deveriam ter ficado presos em uma ocorrência só. ' +
				'A bancada não reproduz o defeito medido, e um teto que não sabe falhar não protege nada'
		);

		afirmar(
			2 === ocorrenciasDe( doMutante, 'interseccao', 'final' ).length,
			'PISO da assimetria: o bloco que SAI inteiro da tela também deixou de ser registrado duas vezes no mutante. ' +
				'Esse caso o código antigo acertava, e um piso que acusasse os três não estaria separando a assimetria de um defeito qualquer'
		);
	}

	/*
	 * PISO DA HISTERESE DO MARCO: tremer na fronteira NÃO é travessia.
	 *
	 * A fronteira sem banda transforma tremor em leitura: um pixel de
	 * oscilação em 50% — o dedo que segura a página, o cabeçalho que recolhe, a
	 * imagem que entra e empurra a altura — rearmava o marco e a descida
	 * seguinte contava como releitura que não houve.
	 */
	const bandaDeclarada = Number( eventos[ nomeDaRolagem ].limiar.histerese_pp || 0 );

	afirmar(
		bandaDeclarada > 0,
		'TETO da declaração: histerese_pp não está declarado no limiar da rolagem. O número da banda mora na declaração, ' +
			'ao lado dos marcos que ele protege — escrito no JavaScript, ele é um número que ninguém revisa junto com a declaração que contradiz'
	);

	const marcoDoTremor = marcos[ Math.floor( marcos.length / 2 ) ];

	/**
	 * O marco alcançado e um tremor na fronteira, sem sair da banda.
	 *
	 * @param {string} codigo Fonte do cliente a exercitar.
	 * @return {Array<number>} Ocorrências registradas naquele marco.
	 */
	function tremorNaFronteira( codigo ) {
		const bancada = bancadaDeComportamento( codigo, dados, { alturaDocumento: 8000, semente: 151 } );

		bancada.rolarAte( marcoDoTremor );

		for ( let vez = 0; vez < 6; vez++ ) {
			bancada.rolarAte( marcoDoTremor - 1 );
			bancada.rolarAte( marcoDoTremor );
		}

		bancada.sair();

		const lote = bancada.cargas().filter( Boolean )[ 0 ] || {};

		return ocorrenciasDe( lote.eventos || [], 'rolagem', marcoDoTremor );
	}

	const comBanda = tremorNaFronteira( fonte );

	afirmar(
		JSON.stringify( comBanda ) === JSON.stringify( [ 1 ] ),
		'PISO da histerese: um tremor de um ponto percentual na fronteira do marco de ' + marcoDoTremor +
			'% produziu as travessias ' + JSON.stringify( comBanda ) + ' em vez de [1]. Fronteira sem banda transforma tremor em leitura, ' +
			'e a travessia fabricada chega ao relatório com cara de releitura'
	);

	const semBanda = fonte.replace(
		'\t\t\t\tif (percentual < marcos[i] - histerese) {\n\t\t\t\t\tdentro[marcos[i]] = false;\n\t\t\t\t}',
		'\t\t\t\tdentro[marcos[i]] = false;'
	);

	afirmar(
		semBanda !== fonte,
		'PISO da histerese: a bancada não encontrou o rearme com banda para removê-lo. Ou ele mudou de forma, ou sumiu — e aí o teto acima é que deveria ter acusado'
	);

	if ( semBanda !== fonte ) {
		afirmar(
			tremorNaFronteira( semBanda ).length > 1,
			'PISO da histerese: removida a banda, o mesmo tremor continuou registrando uma travessia só. A bancada não reproduz o defeito, ' +
				'e um piso que não sabe falhar não prova que a banda está fazendo alguma coisa'
		);
	}

	/* PISO: DOIS VISITANTES NÃO SE MISTURAM. */
	const primeiro = bancadaDeComportamento( fonte, dados, { alturaDocumento: 8000, semente: 11 } );
	const segundo = bancadaDeComportamento( fonte, dados, { alturaDocumento: 8000, semente: 29 } );

	primeiro.rolarAte( 95 );
	primeiro.sair();
	segundo.rolarAte( 95 );
	segundo.sair();

	const cargaA = primeiro.cargas().filter( Boolean )[ 0 ] || {};
	const cargaB = segundo.cargas().filter( Boolean )[ 0 ] || {};

	afirmar(
		cargaA.visitante && cargaB.visitante && cargaA.visitante !== cargaB.visitante,
		'PISO dos dois visitantes: dois navegadores diferentes na mesma página no mesmo dia receberam o MESMO apelido ("' +
			cargaA.visitante + '"). Apelidos iguais fundem duas pessoas numa só, e a contagem de pessoas diferentes passa a medir outra coisa'
	);

	afirmar(
		cargaA.sessao !== cargaB.sessao,
		'PISO dos dois visitantes: as duas visitas receberam o mesmo identificador de visita'
	);

	/* PISO: A RECUSA APAGA — no navegador e no servidor. */
	/*
	 * A SEQUÊNCIA REAL: o visitante chega sob a política pré-aprovada, é
	 * medido, e SÓ ENTÃO recusa no rodapé. Recusar antes de existir apelido
	 * mediria o caso em que não há nada a apagar, que é o caso fácil.
	 */
	const recusou = bancadaDeComportamento( fonte, dados, { alturaDocumento: 8000, semente: 41 } );

	recusou.rolarAte( 95 );
	recusou.recusar();

	const pedidos = recusou.beacons().filter( ( bc ) => bc.url.includes( 'esquecer' ) );

	afirmar(
		1 === pedidos.length,
		'PISO da recusa: quem recusa a medição no rodapé não teve o registro apagado do servidor — saíram ' + pedidos.length +
			' pedido(s) de exclusão. Sem essa chamada, "apagável" é uma palavra na política e um dado que continua lá'
	);

	const apagou = recusou.removidas().some( ( r ) => 'f3base_visitante' === r.chave );

	afirmar(
		apagou,
		'PISO da recusa: o apelido continuou no navegador depois da recusa. Apagar no servidor e deixar no aparelho faz o próximo aceite ressuscitar o mesmo identificador'
	);

	/*
	 * ==================================================================
	 * A TRAVESSIA ATRAVESSA O CARREGAMENTO — o defeito que sobrou.
	 *
	 * O QUE O USUÁRIO RELATOU: *"as triggers só estão sendo gravadas na primeira
	 * vez que eu passo. É possível gravar todas as vezes que eu passo por um
	 * bloco na mesma visita?"*
	 *
	 * O QUE FOI MEDIDO EM PRODUÇÃO, e é ele que estas asserções reproduzem.
	 * Site `fator3-teste-mcp-1`, tabela `wp_2zsugm_f3base_eventos`, visita
	 * `8bb0a2d5`, já com o conserto da 1.3.3 aplicado. Dois carregamentos de `/`
	 * na MESMA visita, 34 segundos entre eles:
	 *
	 *   carregamento A   pecas oc 1 (ms 10378)   pecas oc 2 (ms 24911)
	 *   carregamento B   pecas oc 1 (ms  8329)   <- voltou para 1
	 *
	 * O rearme DENTRO do carregamento funcionava. O que estava errado era o
	 * CONTADOR: `travessiasDaSecao`, `travessias`, `dentro`, `dentroDaVista` e
	 * `cortadasNaVisita` eram variáveis do carregamento e morriam na navegação.
	 * O visitante que passava pelo bloco, ia para `/arquitetura/` e voltava era
	 * registrado três vezes como se fosse a primeira. E o limiar se chama
	 * `travessias_por_SESSAO`: o nome prometia visita e a implementação
	 * entregava carregamento.
	 *
	 * A BANCADA DIRIGE POR ROLAGEM E HERDA O ARMAZENAMENTO, que é como o
	 * navegador atravessa uma navegação: a página seguinte lê o `localStorage`
	 * que a anterior deixou. Nada aqui toca em seção à mão.
	 * ================================================================== */

	/*
	 * A PÁGINA DOS DOIS BLOCOS, com geometria declarada: `abertura` no topo,
	 * visível em rolagem 0 e fora de vista no fim; `pecas` no fim, o contrário.
	 * Uma descida completa cruza cada um dos dois UMA vez, e cruza os quatro
	 * marcos uma vez — que é o que torna a ocorrência de cada carregamento
	 * legível sem aritmética.
	 */
	const paginaDaVisita = {
		alturaDocumento: 2200,
		secoes: [
			'wp-block-group f3base-secao-abertura',
			'wp-block-group f3base-secao-pecas'
		],
		geometria: [
			{ topo: 0, altura: 700 },
			{ topo: 1400, altura: 700 }
		]
	};

	/**
	 * UM CARREGAMENTO da visita: herda o armazenamento, desce, e sai.
	 *
	 * @param {string} codigo   Fonte do cliente a exercitar.
	 * @param {Object} herdado  O `localStorage` que a página anterior deixou.
	 * @param {Object} extras   Opções da bancada (semente, caminho).
	 * @return {Object} `{lotes, linhas, armazenado}` deste carregamento.
	 */
	function carregamentoDaVisita( codigo, herdado, extras ) {
		const bancada = bancadaDeComportamento(
			codigo,
			dados,
			Object.assign( {}, paginaDaVisita, { armazenado: herdado }, extras || {} )
		);

		/* Topo e fim: uma passagem por cada bloco e por cada marco. */
		bancada.rolarAte( 0 );
		bancada.rolarAte( 100 );
		bancada.sair();

		const lotes = bancada.cargas().filter( Boolean );
		const linhas = [];
		const gravado = bancada.gravacoes();

		for ( const lote of lotes ) {
			for ( const linha of lote.eventos || [] ) {
				linhas.push( linha );
			}
		}

		return {
			lotes,
			linhas,
			/*
			 * O QUE O NAVEGADOR LEVA PARA A PÁGINA SEGUINTE é a ÚLTIMA gravação
			 * de cada chave, e não a primeira: o registro da visita é reescrito
			 * a cada travessia contada, e herdar a primeira seria herdar o
			 * estado do instante em que a página abriu.
			 */
			armazenado: {
				f3base_visitante: ( gravado.filter( ( g ) => 'f3base_visitante' === g.chave ).pop() || {} ).valor,
				f3base_sessao: ( gravado.filter( ( g ) => 'f3base_sessao' === g.chave ).pop() || {} ).valor
			}
		};
	}

	/**
	 * A visita de dois carregamentos da MESMA página, contra uma fonte.
	 *
	 * @param {string} codigo Fonte do cliente a exercitar.
	 * @return {Object} `{a, b}`, um por carregamento.
	 */
	function visitaDeDoisCarregamentos( codigo ) {
		const a = carregamentoDaVisita( codigo, {}, { semente: 211 } );
		const b = carregamentoDaVisita( codigo, a.armazenado, { semente: 223 } );

		return { a, b };
	}

	const doisCarregamentos = visitaDeDoisCarregamentos( fonte );
	const noPrimeiro = doisCarregamentos.a;
	const noSegundo = doisCarregamentos.b;

	/* A visita precisa ser a MESMA, senão tudo abaixo mede outra coisa. */
	afirmar(
		( noPrimeiro.lotes[ 0 ] || {} ).sessao === ( noSegundo.lotes[ 0 ] || {} ).sessao &&
			'' !== String( ( noSegundo.lotes[ 0 ] || {} ).sessao || '' ),
		'teto da bancada: os dois carregamentos não ficaram na mesma visita, e sem isso nenhuma das asserções abaixo mede o que promete'
	);

	/* PISO 1: A TRAVESSIA ATRAVESSA O CARREGAMENTO. */
	afirmar(
		JSON.stringify( ocorrenciasDe( noPrimeiro.linhas, 'interseccao', 'pecas' ) ) === JSON.stringify( [ 1 ] ) &&
			JSON.stringify( ocorrenciasDe( noSegundo.linhas, 'interseccao', 'pecas' ) ) === JSON.stringify( [ 2 ] ),
		'TETO da travessia entre carregamentos: o bloco "pecas" saiu com ' +
			JSON.stringify( ocorrenciasDe( noPrimeiro.linhas, 'interseccao', 'pecas' ) ) + ' no primeiro carregamento e ' +
			JSON.stringify( ocorrenciasDe( noSegundo.linhas, 'interseccao', 'pecas' ) ) + ' no segundo, e o esperado é [1] e [2]. ' +
			'O visitante passou pelo bloco, navegou e voltou, e a segunda passagem foi gravada como se fosse a primeira — ' +
			'medido na visita 8bb0a2d5 em produção, `pecas` saiu com ocorrência 1 nos dois carregamentos'
	);

	/* O MARCO ATRAVESSA PELA MESMA RAZÃO, e pelo mesmo contador. */
	for ( const marco of marcos ) {
		afirmar(
			JSON.stringify( ocorrenciasDe( noSegundo.linhas, 'rolagem', marco ) ) === JSON.stringify( [ 2 ] ),
			'TETO da travessia entre carregamentos: o marco de ' + marco + '% saiu com ' +
				JSON.stringify( ocorrenciasDe( noSegundo.linhas, 'rolagem', marco ) ) +
				' no segundo carregamento da mesma visita, e o esperado é [2]. O contador de travessias é da VISITA: quem desce até o marco, navega e volta continua de onde parou'
		);
	}

	/* PISO 2: O CAMINHO SEPARA — mesmo NOME de bloco, outra página. */
	const outraPagina = carregamentoDaVisita( fonte, noPrimeiro.armazenado, { semente: 227, caminho: '/arquitetura/' } );

	afirmar(
		( outraPagina.lotes[ 0 ] || {} ).sessao === ( noPrimeiro.lotes[ 0 ] || {} ).sessao,
		'teto da bancada: o carregamento em outro caminho começou uma visita nova, e sem a mesma visita a asserção do caminho não mede nada'
	);

	afirmar(
		JSON.stringify( ocorrenciasDe( outraPagina.linhas, 'interseccao', 'pecas' ) ) === JSON.stringify( [ 1 ] ),
		'PISO do caminho na chave: o bloco "pecas" em /arquitetura/ saiu com ' +
			JSON.stringify( ocorrenciasDe( outraPagina.linhas, 'interseccao', 'pecas' ) ) +
			' na mesma visita em que ele já tinha sido visto em /pagina/, e o esperado é [1]. ' +
			'`pecas` em duas páginas são seções DIFERENTES com o mesmo nome: somá-las responderia uma pergunta que ninguém fez — ' +
			'"quantas vezes este NOME foi visto no site inteiro?" — e esconderia as duas, porque nenhuma das páginas teria mais a própria contagem'
	);

	/* PISO 3: A VISITA NOVA RECOMEÇA — o contador zera junto com ela. */
	let visitaDoPrimeiro = {};

	try {
		visitaDoPrimeiro = JSON.parse( String( noPrimeiro.armazenado.f3base_sessao || '{}' ) );
	} catch {
		visitaDoPrimeiro = {};
	}

	const depoisDaInatividade = carregamentoDaVisita(
		fonte,
		{
			f3base_visitante: noPrimeiro.armazenado.f3base_visitante,
			f3base_sessao: JSON.stringify( Object.assign( {}, visitaDoPrimeiro, { visto: Date.now() - ( 31 * 60 * 1000 ) } ) )
		},
		{ semente: 229 }
	);

	afirmar(
		( depoisDaInatividade.lotes[ 0 ] || {} ).sessao !== ( noPrimeiro.lotes[ 0 ] || {} ).sessao &&
			JSON.stringify( ocorrenciasDe( depoisDaInatividade.linhas, 'interseccao', 'pecas' ) ) === JSON.stringify( [ 1 ] ),
		'PISO da visita nova: passada a janela de inatividade, "pecas" saiu com ' +
			JSON.stringify( ocorrenciasDe( depoisDaInatividade.linhas, 'interseccao', 'pecas' ) ) + ' e o esperado é [1]. ' +
			'O contador é da VISITA e morre com ela: herdar o mapa da visita anterior faria a primeira passagem de quem volta no dia seguinte sair como décima segunda, ' +
			'e a coluna "vez" passaria a contar história antiga sem nada dizendo de onde ela veio'
	);

	/*
	 * PISO 4: O ESTADO ARMADO NÃO PERSISTE — e é ele que impede o conserto de
	 * trocar um defeito por outro.
	 *
	 * ESTE PISO MEDE A EXISTÊNCIA DA LINHA, e não a vez dela. A vez é do teto
	 * acima, que já cobre o contador em todos os pontos da página; aqui a
	 * pergunta é outra e mais crua — o bloco que já está no topo do
	 * carregamento seguinte chega a ser REGISTRADO? Medir a vez nos dois
	 * lugares faria os dois pisos acusarem os dois mutantes, e dois pisos que
	 * acusam o mesmo par de defeitos não separam coisa nenhuma.
	 */
	afirmar(
		ocorrenciasDe( noSegundo.linhas, 'interseccao', 'abertura' ).length > 0,
		'PISO do estado armado: no segundo carregamento o bloco que JÁ ESTÁ NO TOPO da página não foi registrado — saiu com ' +
			JSON.stringify( ocorrenciasDe( noSegundo.linhas, 'interseccao', 'abertura' ) ) + '. ' +
			'Persistir "já estou dentro" junto com o contador engole a primeira entrada do carregamento seguinte, e o visitante que trocou de página perde justamente a passagem que ele acabou de fazer. ' +
			'Persiste o CONTADOR; o estado armado nasce zerado a cada carregamento'
	);

	/* E a VEZ dele também atravessa: é a segunda passagem da visita. */
	afirmar(
		JSON.stringify( ocorrenciasDe( noSegundo.linhas, 'interseccao', 'abertura' ) ) === JSON.stringify( [ 2 ] ),
		'TETO da travessia entre carregamentos: o bloco do topo saiu com ' +
			JSON.stringify( ocorrenciasDe( noSegundo.linhas, 'interseccao', 'abertura' ) ) +
			' no segundo carregamento da mesma visita, e o esperado é [2] — a segunda passagem da visita pelo bloco do topo'
	);

	/* PISO 5: O TETO É DA VISITA — distribuído entre carregamentos. */
	const daVisitaInteira = [];
	let ultimoLoteDaVisita = {};
	let heranca = {};

	for ( let carga = 0; carga < tetoDeTravessias + 2; carga++ ) {
		const passo = carregamentoDaVisita( fonte, heranca, { semente: 251 + carga } );

		heranca = passo.armazenado;
		ultimoLoteDaVisita = passo.lotes[ 0 ] || {};

		for ( const linha of passo.linhas ) {
			daVisitaInteira.push( linha );
		}
	}

	const pecasDaVisita = ocorrenciasDe( daVisitaInteira, 'interseccao', 'pecas' );

	afirmar(
		pecasDaVisita.length === tetoDeTravessias,
		'PISO do teto da visita: ' + ( tetoDeTravessias + 2 ) + ' carregamentos da mesma visita, com uma passagem por "pecas" cada, gravaram ' +
			pecasDaVisita.length + ' linha(s), e o teto declarado é ' + tetoDeTravessias +
			'. O teto é da VISITA e não do carregamento: contando por carregamento, uma visita de quarenta páginas grava quarenta primeiras vezes e o teto declarado nunca chega a valer'
	);

	afirmar(
		JSON.stringify( pecasDaVisita ) === JSON.stringify( pecasDaVisita.map( ( v, i ) => i + 1 ) ),
		'PISO do teto da visita: as ocorrências de "pecas" ao longo da visita saíram ' + JSON.stringify( pecasDaVisita ) +
			' em vez de 1, 2, 3… até o teto. A vez é contínua na visita, e um salto ou uma repetição dela é a contagem recomeçando onde não devia'
	);

	afirmar(
		Number( ultimoLoteDaVisita.cortados ) > 0,
		'PISO do corte nomeado na visita: passado o teto, o carregamento seguinte despachou ' + ultimoLoteDaVisita.cortados +
			' cortada(s). A travessia além do teto vira CORTADA nomeada, e não linha — corte silencioso faz o total do painel não bater com a tabela sem nada em lugar nenhum dizendo por quê'
	);

	/* PISO 6: O AGREGADO NÃO DOBRA — releitura não vira audiência. */
	for ( const carregamento of [ noPrimeiro, noSegundo ] ) {
		const agregado = ( ( carregamento.lotes[ 0 ] || {} ).metricas || [] ).filter( ( m ) => 'interseccao' === m.gatilho || 'rolagem' === m.gatilho );

		afirmar(
			agregado.length > 0 && agregado.every( ( m ) => 1 === Number( m.contagem ) ),
			'PISO do agregado por carregamento: os totais saíram ' + JSON.stringify( agregado.map( ( m ) => m.detalhe + '=' + m.contagem ) ) +
				', e cada um precisa contar UMA vez por carregamento. O total do painel responde "quantas visitas viram este bloco" e a tabela responde "quantas vezes cada uma passou": ' +
				'somar a releitura no total transforma uma pessoa inquieta em audiência que não existe'
		);
	}

	/*
	 * MUTAÇÃO 1 — O CONTADOR EM MEMÓRIA DO CARREGAMENTO, que é o código de
	 * hoje. Sem ela o piso não prova nada: foi exatamente esse código que
	 * passou em toda a bancada anterior, porque toda ela media UM carregamento.
	 */
	const contadorDoCarregamento = fonte.replace(
		'travessiasDaVisita = visita.travessias;',
		'travessiasDaVisita = {};'
	);

	afirmar(
		contadorDoCarregamento !== fonte,
		'PISO do contador da visita: a bancada não encontrou a linha que semeia o contador a partir da visita para desfazê-la. ' +
			'Ou ela mudou de forma e o piso deixou de provar o que promete, ou ela sumiu — e nesse caso o teto acima é que deveria ter acusado'
	);

	if ( contadorDoCarregamento !== fonte ) {
		const mutado = visitaDeDoisCarregamentos( contadorDoCarregamento );

		afirmar(
			JSON.stringify( ocorrenciasDe( mutado.b.linhas, 'interseccao', 'pecas' ) ) === JSON.stringify( [ 1 ] ),
			'PISO do contador da visita: com o contador nascendo vazio a cada carregamento, o segundo carregamento da mesma visita registrou "pecas" com ' +
				JSON.stringify( ocorrenciasDe( mutado.b.linhas, 'interseccao', 'pecas' ) ) +
				' — e ele deveria ter voltado para [1], que é o defeito medido na visita 8bb0a2d5. A bancada não reproduz o defeito, e um teto que não sabe falhar não protege nada'
		);

		afirmar(
			JSON.stringify( ocorrenciasDe( mutado.b.linhas, 'interseccao', 'abertura' ) ) === JSON.stringify( [ 1 ] ),
			'PISO do contador da visita: o bloco do topo deixou de ser REGISTRADO no mutante do contador. ' +
				'Este mutante erra a VEZ, não a existência da linha: se ele apagasse a linha também, o piso do estado armado estaria acusando o mesmo defeito que este, e os dois deixariam de separar coisa nenhuma'
		);
	}

	/*
	 * MUTAÇÃO 2 — O ESTADO ARMADO PERSISTIDO JUNTO COM O CONTADOR. É o erro
	 * natural de quem faz o conserto pela metade: "persisti a contagem, então
	 * persisto também o que já estava em vista". O resultado troca um defeito
	 * por outro — a primeira entrada do carregamento seguinte é engolida.
	 */
	const armadoPersistido = fonte.replace(
		'\t\t\t\tdentroDaVista.push(false);',
		'\t\t\t\tdentroDaVista.push(Object.prototype.hasOwnProperty.call(travessiasDaVisita, caminhoDaPagina() + \'|\' + GATILHO + \'|\' + nomeDaSecao(alvos[i])));'
	);

	afirmar(
		armadoPersistido !== fonte,
		'PISO do estado armado: a bancada não encontrou a declaração de `dentroDaVista` para persisti-la. ' +
			'Ou ela mudou de forma e o piso deixou de provar o que promete, ou ela sumiu — e nesse caso o teto acima é que deveria ter acusado'
	);

	if ( armadoPersistido !== fonte ) {
		const mutado = visitaDeDoisCarregamentos( armadoPersistido );

		afirmar(
			0 === ocorrenciasDe( mutado.b.linhas, 'interseccao', 'abertura' ).length,
			'PISO do estado armado: com o estado armado herdado da visita, o bloco que já está no topo do segundo carregamento saiu com ' +
				JSON.stringify( ocorrenciasDe( mutado.b.linhas, 'interseccao', 'abertura' ) ) +
				' — e ele deveria ter sido ENGOLIDO, que é o defeito que este piso existe para impedir. A bancada não reproduz a troca de um defeito por outro'
		);

		afirmar(
			JSON.stringify( ocorrenciasDe( mutado.b.linhas, 'interseccao', 'pecas' ) ) === JSON.stringify( [ 2 ] ),
			'PISO do estado armado: o bloco do FIM da página também parou de ser registrado no mutante do estado armado. ' +
				'Ele sai do campo de visão na descida e rearma sozinho: se ele sumisse aqui, este piso estaria acusando o mesmo defeito do contador, e os dois deixariam de separar coisa nenhuma'
		);
	}

	/*
	 * ==================================================================
	 * O CONTADOR E A LINHA TÊM A MESMA DURABILIDADE — o defeito da 1.3.4.
	 *
	 * O QUE O USUÁRIO RELATOU: *"os gatilhos estão aparecendo mais de uma vez,
	 * mas alguns estão sendo perdidos."*
	 *
	 * O QUE FOI MEDIDO EM PRODUÇÃO. Site `fator3-teste-mcp-1`, tabela
	 * `wp_2zsugm_f3base_eventos`, visita `8cac18da62ed056004242bee737457db`, UM
	 * único carregamento de `/` (um só `f3base_pagina_vista`, em ms 984). Por
	 * lote, na ordem em que chegaram:
	 *
	 *   lote 1   984 pagina_vista · 1746 abertura oc1 · 2658 LCP,CLS,TTFB
	 *   lote 2   10087 pecas oc1 · 10504 rolagem25 oc1
	 *   lote 3   24780 pecas oc2 · 24813 rolagem25 oc2 · 25080 comando-unico oc1
	 *            25113 rolagem50 oc1 · 26063 rolagem75 oc1 · 26080 faq oc1
	 *   lote 4   79925 comando-unico oc3   <- a ocorrência 2 NUNCA CHEGOU
	 *            79958 rolagem50 oc2 · 81525 rolagem75 oc2 · 81542 faq oc2
	 *            81592 rolagem90 oc1
	 *
	 * `comando-unico` pula de 1 para 3; todos os outros gatilhos são contínuos.
	 * Entre os ms 26080 e 79925 o visitante SUBIU a página: a subida faz
	 * `comando-unico` reentrar em vista (uma ocorrência) e não dispara marco
	 * nenhum, porque marco só conta na descida. O lote despachado naquele
	 * instante tinha UMA linha só, e é essa que sumiu.
	 *
	 * A CAUSA. Na 1.3.4 o CONTADOR virou durável — `contarTravessia()` grava no
	 * `localStorage` na hora — e a LINHA ficou volátil: ela ia para
	 * `registroDaSessao`, que é memória do carregamento, e `enviarResumo()`
	 * limpava esse registro quando `sendBeacon` devolvia `true`. E `true`
	 * significa ENFILEIRADO, nunca ENTREGUE: a especificação diz que o retorno
	 * afirma apenas que o agente de usuário aceitou a carga para transferência.
	 * Qualquer lote que não chega avança o contador sem produzir linha.
	 *
	 * O INVARIANTE QUE ESTE BLOCO MEDE, e ele é o piso que importa: NUMA
	 * VISITA, AS OCORRÊNCIAS DE UM MESMO GATILHO NO MESMO CAMINHO FORMAM UMA
	 * SEQUÊNCIA SEM BURACOS. Qualquer mecanismo que avance o contador sem
	 * produzir linha reprova.
	 * ================================================================== */

	/**
	 * A sequência de ocorrências de um par gatilho/detalhe TEM BURACO?
	 *
	 * Ela precisa ser 1, 2, 3… sem salto e sem repetição. Um salto é linha
	 * perdida; uma repetição é linha contada duas vezes. As duas reprovam, e
	 * por isso a mesma função mede as duas.
	 *
	 * @param {Array<number>} vezes Ocorrências em ordem.
	 * @return {boolean}
	 */
	function temBuraco( vezes ) {
		return JSON.stringify( vezes ) !== JSON.stringify( vezes.map( ( v, i ) => i + 1 ) );
	}

	/**
	 * As linhas que o SERVIDOR recebeu, de todos os lotes que ele aceitou.
	 *
	 * @param {Array<Object>} bancadas Bancadas da visita, em ordem.
	 * @return {Array<Object>} Linhas do registro efetivamente entregues.
	 */
	function entregues( bancadas ) {
		const linhas = [];

		for ( const bancada of bancadas ) {
			for ( const lote of bancada.recebidas() ) {
				for ( const linha of lote.eventos || [] ) {
					linhas.push( linha );
				}
			}
		}

		return linhas;
	}

	/**
	 * O `localStorage` que esta bancada deixa para o carregamento seguinte.
	 *
	 * @param {Object} bancada Bancada do carregamento.
	 * @return {Object} Armazenamento herdado.
	 */
	function herancaDe( bancada ) {
		const gravado = bancada.gravacoes();

		return {
			f3base_visitante: ( gravado.filter( ( g ) => 'f3base_visitante' === g.chave ).pop() || {} ).valor,
			f3base_sessao: ( gravado.filter( ( g ) => 'f3base_sessao' === g.chave ).pop() || {} ).valor
		};
	}

	/**
	 * Uma bancada da página de dois blocos, com resposta de servidor declarada.
	 *
	 * @param {string} codigo  Fonte do cliente a exercitar.
	 * @param {Object} herdado Armazenamento herdado.
	 * @param {Object} extras  Semente, resposta e o que mais o caso precisar.
	 * @return {Object} Bancada.
	 */
	function bancadaDaVisita( codigo, herdado, extras ) {
		return bancadaDeComportamento(
			codigo,
			dados,
			Object.assign( {}, paginaDaVisita, { armazenado: herdado || {} }, extras || {} )
		);
	}

	/**
	 * O CICLO MEDIDO EM PRODUÇÃO, num só carregamento: desce, sobe, desce.
	 *
	 * A subida é o gesto que produz o lote de UMA LINHA — o bloco do topo
	 * reentrando em vista, sem marco nenhum —, e é ele que sumiu na visita
	 * `8cac18da`. `aoSubir` decide o que o servidor responde naquele instante.
	 *
	 * @param {Object}   bancada  Bancada do carregamento.
	 * @param {Function} noMeio   Executado entre a subida e a descida final.
	 * @return {void}
	 */
	function desceSobeDesce( bancada, noMeio ) {
		bancada.rolarAte( 0 );
		bancada.rolarAte( 100 );
		bancada.ocultar();

		bancada.voltarAVer();
		bancada.rolarAte( 0 );
		bancada.ocultar();

		bancada.voltarAVer();
		bancada.rolarAte( 100 );

		if ( noMeio ) {
			noMeio();
		}

		bancada.sair();
	}

	/*
	 * PISO 1: ENVIO RECUSADO NÃO PERDE LINHA.
	 *
	 * O servidor recusa os dois primeiros instantes de despacho e volta a
	 * aceitar no último. Nada pode se perder, e a sequência de ocorrências não
	 * pode ter buraco.
	 */
	let servidorRecusando = true;

	const comRecusa = bancadaDaVisita( fonte, {}, {
		semente: 307,
		resposta: () => ( servidorRecusando ? 503 : 201 )
	} );

	desceSobeDesce( comRecusa, () => {
		servidorRecusando = false;
	} );

	const apesarDaRecusa = entregues( [ comRecusa ] );

	for ( const bloco of [ 'abertura', 'pecas' ] ) {
		const vezes = ocorrenciasDe( apesarDaRecusa, 'interseccao', bloco );

		afirmar(
			! temBuraco( vezes ) && vezes.length > 1,
			'PISO do envio recusado: o bloco "' + bloco + '" chegou ao servidor com as ocorrências ' + JSON.stringify( vezes ) +
				' depois de o servidor ter recusado dois lotes. A sequência precisa ser 1, 2, 3… sem buraco: ' +
				'medido na visita 8cac18da, `comando-unico` saiu com as ocorrências 1 e 3 — a 2 foi contada e a linha morreu junto com o lote. ' +
				'`sendBeacon` devolvendo `true` diz que o navegador ACEITOU a carga, nunca que ela chegou'
		);
	}

	for ( const marco of marcos ) {
		afirmar(
			! temBuraco( ocorrenciasDe( apesarDaRecusa, 'rolagem', marco ) ),
			'PISO do envio recusado: o marco de ' + marco + '% chegou com ' +
				JSON.stringify( ocorrenciasDe( apesarDaRecusa, 'rolagem', marco ) ) + ', e a sequência tem buraco'
		);
	}

	/*
	 * MUTAÇÃO (a) — LIMPAR O ACUMULADO SEM CONFERIR A RESPOSTA.
	 *
	 * É o código da 1.3.4 traduzido para o despacho novo: despachar e esquecer,
	 * como quem confia no enfileiramento. Sem esta mutação o piso acima não
	 * prova nada, porque foi exatamente esse comportamento que passou em toda a
	 * bancada anterior — ali o servidor nunca recusava.
	 */
	const semConferir = fonte.replace(
		'concluirLote(lote, Number((resposta && resposta.status) || 0));',
		'concluirLote(lote, 200);'
	);

	afirmar(
		semConferir !== fonte,
		'PISO do envio recusado: a bancada não encontrou a linha que confere o código de resposta para desfazê-la. ' +
			'Ou ela mudou de forma e o piso deixou de provar o que promete, ou ela sumiu — e nesse caso o teto acima é que deveria ter acusado'
	);

	if ( semConferir !== fonte ) {
		servidorRecusando = true;

		const mutanteSemConferir = bancadaDaVisita( semConferir, {}, {
			semente: 307,
			resposta: () => ( servidorRecusando ? 503 : 201 )
		} );

		desceSobeDesce( mutanteSemConferir, () => {
			servidorRecusando = false;
		} );

		const doMutante = entregues( [ mutanteSemConferir ] );

		afirmar(
			ocorrenciasDe( doMutante, 'interseccao', 'abertura' ).length <
				ocorrenciasDe( apesarDaRecusa, 'interseccao', 'abertura' ).length,
			'PISO do envio recusado: com o lote esquecido sobre uma resposta que ninguém leu, o bloco do topo chegou com ' +
				JSON.stringify( ocorrenciasDe( doMutante, 'interseccao', 'abertura' ) ) +
				' — e ele deveria ter PERDIDO linhas, que é o defeito medido na visita 8cac18da. ' +
				'A bancada não reproduz o defeito, e um teto que não sabe falhar não protege nada'
		);
	}

	/*
	 * PISO 4: O 503 DA MIGRAÇÃO É RETENTATIVA, E NÃO PERDA.
	 *
	 * `garantir_estrutura()` põe um transiente e responde 503 na rota enquanto
	 * a estrutura não estiver pronta — e o transiente foi medido VIVO neste
	 * site. Enquanto o cliente descartava cada lote recusado, isso era perda
	 * garantida com o contador andando o tempo todo.
	 */
	let emMigracao = true;

	const durante = bancadaDaVisita( fonte, {}, {
		semente: 331,
		resposta: () => ( emMigracao ? 503 : 201 )
	} );

	for ( let volta = 0; volta < 4; volta++ ) {
		durante.rolarAte( 0 );
		durante.rolarAte( 100 );
		durante.ocultar();
		durante.voltarAVer();
	}

	afirmar(
		0 === durante.recebidas().length && durante.beacons().length > 0,
		'teto da bancada da migração: com a rota em 503 o servidor recebeu ' + durante.recebidas().length +
			' lote(s) — a bancada precisa recusar de verdade, senão ela mede o caminho feliz'
	);

	emMigracao = false;
	durante.rolarAte( 0 );
	durante.sair();

	const passadaAMigracao = entregues( [ durante ] );

	for ( const bloco of [ 'abertura', 'pecas' ] ) {
		const vezes = ocorrenciasDe( passadaAMigracao, 'interseccao', bloco );

		afirmar(
			! temBuraco( vezes ) && vezes.length >= 4,
			'PISO do 503 da migração: passada a migração, "' + bloco + '" chegou com ' + JSON.stringify( vezes ) +
				'. Com a rota em 503 nada pode se perder, e quando ela volta tudo tem de chegar — quinze minutos de 503 com o cliente descartando cada lote eram perda garantida, e o contador andava o tempo todo'
		);
	}

	/*
	 * PISO 2: CARREGAMENTO QUE MORRE NÃO PERDE LINHA.
	 *
	 * São DOIS casos, e cada um é segurado por um campo DIFERENTE do registro
	 * da visita. Medir só um deles prova só um campo — e, pior, um piso que
	 * acusasse apenas quando os dois campos somem juntos não provaria nenhum
	 * dos dois:
	 *
	 * - MORRE SEM TER SELADO. A página acumula e acaba sem evento de saída
	 *   nenhum — a aba encerrada pelo sistema, o aparelho sem memória, o
	 *   navegador descartando a página. Nada chegou a ser selado, e quem segura
	 *   as linhas é o `acumulado`.
	 * - MORRE DEPOIS DE SELAR E SER RECUSADO. A página oculta, o lote é selado
	 *   e despachado, o servidor recusa de forma transitória, e só então ela
	 *   morre. Neste instante o `acumulado` está VAZIO — ele foi selado —, e
	 *   quem segura as linhas é a FILA de pendentes, e só ela.
	 *
	 * Os dois cenários abaixo existem em função separada porque as mutações
	 * precisam rodar os DOIS contra cada mutante: é a comparação cruzada que
	 * mostra que cada campo responde por um caso, e não que dois defeitos
	 * juntos produzem um sintoma.
	 */

	/**
	 * A visita em que a página morre SEM ter selado nada.
	 *
	 * @param {string} codigo Fonte do cliente a exercitar.
	 * @return {Object} `{primeira, segunda, linhas}` da visita.
	 */
	function morteSemSelar( codigo ) {
		const primeira = bancadaDaVisita( codigo, {}, { semente: 337 } );

		primeira.rolarAte( 0 );
		primeira.rolarAte( 100 );
		primeira.morrer();

		const segunda = bancadaDaVisita( codigo, herancaDe( primeira ), { semente: 347 } );

		segunda.rolarAte( 0 );
		segunda.rolarAte( 100 );
		segunda.sair();

		return { primeira, segunda, linhas: entregues( [ primeira, segunda ] ) };
	}

	/**
	 * A visita em que a página SELA, é recusada, e só então morre.
	 *
	 * @param {string} codigo Fonte do cliente a exercitar.
	 * @return {Object} `{primeira, segunda, linhas}` da visita.
	 */
	function morteDepoisDeSelar( codigo ) {
		const primeira = bancadaDaVisita( codigo, {}, { semente: 359, resposta: 503 } );

		primeira.rolarAte( 0 );
		primeira.rolarAte( 100 );
		/* Oculta: o lote é SELADO e despachado — e o servidor recusa. */
		primeira.ocultar();
		primeira.voltarAVer();
		/* E aqui a aba é encerrada, sem `pagehide` e sem nada novo acumulado. */
		primeira.morrer();

		const segunda = bancadaDaVisita( codigo, herancaDe( primeira ), { semente: 367 } );

		segunda.rolarAte( 0 );
		segunda.rolarAte( 100 );
		segunda.sair();

		return { primeira, segunda, linhas: entregues( [ primeira, segunda ] ) };
	}

	const semSelar = morteSemSelar( fonte );

	afirmar(
		0 === semSelar.primeira.beacons().length,
		'teto da bancada da morte: o carregamento que morre sem evento de saída despachou ' + semSelar.primeira.beacons().length +
			' envio(s). Se ele despachasse, a bancada estaria medindo uma saída limpa com outro nome'
	);

	for ( const bloco of [ 'abertura', 'pecas' ] ) {
		const vezes = ocorrenciasDe( semSelar.linhas, 'interseccao', bloco );

		afirmar(
			JSON.stringify( vezes ) === JSON.stringify( [ 1, 2 ] ),
			'PISO do carregamento que morre SEM SELAR: o bloco "' + bloco + '" chegou com ' + JSON.stringify( vezes ) +
				' e o esperado é [1,2]. O carregamento anterior morreu sem `pagehide`, sem `visibilitychange` e sem despachar nada: ' +
				'nada chegou a ser selado, e o que ele CONTOU tem de estar gravado no acumulado para o carregamento seguinte encontrar'
		);
	}

	afirmar(
		( ( semSelar.segunda.recebidas()[ 0 ] || {} ).eventos || [] ).some( ( e ) => 1 === Number( e.ocorrencia ) ),
		'PISO da ordem: o primeiro lote despachado pelo carregamento seguinte não trouxe as linhas herdadas. ' +
			'O pendente sai ANTES do novo — a fila é despachada na ordem em que os lotes foram selados, e o herdado é selado na carga'
	);

	const depoisDeSelar = morteDepoisDeSelar( fonte );

	afirmar(
		depoisDeSelar.primeira.beacons().length > 0 && 0 === depoisDeSelar.primeira.recebidas().length,
		'teto da bancada da morte após selar: o carregamento despachou ' + depoisDeSelar.primeira.beacons().length +
			' envio(s), dos quais ' + depoisDeSelar.primeira.recebidas().length + ' foram aceitos. Ele precisa ter selado e sido RECUSADO: ' +
			'sem o despacho, este cenário seria o anterior com outro nome; com o despacho aceito, não haveria fila a segurar nada'
	);

	let acumuladoNaMorte = null;

	try {
		acumuladoNaMorte = JSON.parse(
			String( ( depoisDeSelar.primeira.gravacoes().filter( ( g ) => 'f3base_sessao' === g.chave ).pop() || {} ).valor || '{}' )
		).acumulado;
	} catch {
		acumuladoNaMorte = null;
	}

	/*
	 * O ACUMULADO ESTÁ VAZIO NO INSTANTE DA MORTE — ausente conta como vazio,
	 * porque as duas coisas dizem o mesmo: ele não está segurando linha
	 * nenhuma. É isto que faz do cenário abaixo a prova da FILA e não do
	 * acumulado; se ele ainda segurasse as linhas, socorreria a visita sozinho
	 * e o piso passaria mesmo com a fila só na memória.
	 */
	afirmar(
		0 === ( ( acumuladoNaMorte || {} ).eventos || [] ).length,
		'teto da bancada da morte após selar: o acumulado gravado no instante da morte tinha ' +
			( ( acumuladoNaMorte || {} ).eventos || [] ).length +
			' linha(s), e ele precisa estar VAZIO — o lote já foi selado. Com linhas ali, este cenário mediria o acumulado de novo em vez de medir a fila'
	);

	for ( const bloco of [ 'abertura', 'pecas' ] ) {
		const vezes = ocorrenciasDe( depoisDeSelar.linhas, 'interseccao', bloco );

		afirmar(
			JSON.stringify( vezes ) === JSON.stringify( [ 1, 2 ] ),
			'PISO do carregamento que morre DEPOIS DE SELAR: o bloco "' + bloco + '" chegou com ' + JSON.stringify( vezes ) +
				' e o esperado é [1,2]. O lote foi selado, despachado e RECUSADO de forma transitória, e só então a aba foi encerrada: ' +
				'o acumulado já estava vazio, e quem segura essas linhas é a FILA de pendentes — ela precisa estar GRAVADA, e não só na memória do carregamento'
		);
	}

	/*
	 * AS DUAS MUTAÇÕES DA DURABILIDADE, ISOLADAS — e é o isolamento que prova
	 * cada campo. Uma mutação que apagasse os dois de uma vez acusaria os dois
	 * cenários e não diria qual campo responde por qual: seria um piso que só
	 * sabe falhar quando dois defeitos acontecem juntos, e um piso assim não
	 * prova nenhum dos dois.
	 *
	 * A mutação é do lado da ESCRITA — o campo deixa de ser gravado —, porque é
	 * ali que "durável" acontece. Cada uma tem de acusar o SEU cenário e deixar
	 * o outro passar.
	 */
	const escritaDoAcumulado = '+ \',"acumulado":\' + JSON.stringify({';
	const escritaDaFila = '+ \',"pendentes":\' + filaSerializada';

	const semGravarAcumulado = fonte.replace( escritaDoAcumulado, '+ \',"acumulado":null,"ignorado":\' + JSON.stringify({' );
	const semGravarFila = fonte.replace( escritaDaFila, '+ \',"pendentes":[]\'' );

	afirmar(
		semGravarAcumulado !== fonte && semGravarFila !== fonte,
		'PISO do pendente durável: a bancada não encontrou a gravação do acumulado e/ou da fila para desfazê-las. ' +
			'Ou elas mudaram de forma e o piso deixou de provar o que promete, ou sumiram — e nesse caso os tetos acima é que deveriam ter acusado'
	);

	if ( semGravarAcumulado !== fonte && semGravarFila !== fonte ) {
		const semAcumulado = {
			semSelar: morteSemSelar( semGravarAcumulado ),
			depoisDeSelar: morteDepoisDeSelar( semGravarAcumulado )
		};

		const semFila = {
			semSelar: morteSemSelar( semGravarFila ),
			depoisDeSelar: morteDepoisDeSelar( semGravarFila )
		};

		/**
		 * A sequência do bloco do topo numa visita já rodada.
		 *
		 * @param {Object} visita Resultado de um dos dois cenários.
		 * @return {Array<number>} Ocorrências entregues.
		 */
		function doTopo( visita ) {
			return ocorrenciasDe( visita.linhas, 'interseccao', 'abertura' );
		}

		afirmar(
			temBuraco( doTopo( semAcumulado.semSelar ) ),
			'PISO do acumulado durável: sem gravar o acumulado, a página que morre SEM ter selado entregou ' +
				JSON.stringify( doTopo( semAcumulado.semSelar ) ) + ' — e ela deveria ter BURACO. ' +
				'A bancada não reproduz o defeito, e um piso que não sabe falhar não prova que o acumulado gravado está fazendo alguma coisa'
		);

		afirmar(
			! temBuraco( doTopo( semAcumulado.depoisDeSelar ) ),
			'PISO da separação: sem gravar o acumulado, o cenário da morte DEPOIS DE SELAR também quebrou (' +
				JSON.stringify( doTopo( semAcumulado.depoisDeSelar ) ) + '). Ali o acumulado já estava vazio e quem segura é a fila: ' +
				'se esta mutação derruba os dois cenários, os dois pisos estão acusando o mesmo campo e nenhum deles prova o outro'
		);

		afirmar(
			temBuraco( doTopo( semFila.depoisDeSelar ) ),
			'PISO da fila durável: sem gravar a fila de pendentes, a página que morre DEPOIS de selar e ser recusada entregou ' +
				JSON.stringify( doTopo( semFila.depoisDeSelar ) ) + ' — e ela deveria ter BURACO. ' +
				'É o caso em que o acumulado já foi selado e não socorre ninguém: sem a fila gravada, o lote selado morre com o carregamento'
		);

		afirmar(
			! temBuraco( doTopo( semFila.semSelar ) ),
			'PISO da separação: sem gravar a fila, o cenário da morte SEM SELAR também quebrou (' +
				JSON.stringify( doTopo( semFila.semSelar ) ) + '). Ali nada tinha sido selado e quem segura é o acumulado: ' +
				'se esta mutação derruba os dois cenários, os dois pisos estão acusando o mesmo campo e nenhum deles prova o outro'
		);
	}

	/*
	 * PISO 3: REENVIO NÃO DUPLICA.
	 *
	 * Confirmar a entrega implica reenviar, e reenviar sem selo conta duas
	 * vezes: uma resposta perdida no caminho de volta faria o mesmo lote ser
	 * gravado de novo. O lote é SELADO — imutável, com identificador sorteado —
	 * e a retentativa leva o MESMO selo e o MESMO conteúdo.
	 */
	let recusandoUmaVez = true;

	const reenviado = bancadaDaVisita( fonte, {}, {
		semente: 349,
		resposta: () => ( recusandoUmaVez ? 503 : 201 )
	} );

	reenviado.rolarAte( 0 );
	reenviado.rolarAte( 100 );
	reenviado.ocultar();

	recusandoUmaVez = false;
	reenviado.voltarAVer();
	reenviado.sair();

	const tentativas = reenviado.cargas().filter( Boolean );

	afirmar(
		2 === tentativas.length,
		'teto do reenvio: o lote recusado saiu ' + tentativas.length + ' vez(es), e o esperado são duas — a recusada e a retentativa'
	);

	if ( 2 === tentativas.length ) {
		afirmar(
			tentativas[ 0 ].lote === tentativas[ 1 ].lote && /^[a-f0-9]{32}$/.test( String( tentativas[ 0 ].lote ) ),
			'PISO do reenvio: a retentativa levou o selo "' + tentativas[ 1 ].lote + '" e a tentativa recusada levava "' +
				tentativas[ 0 ].lote + '". Selo novo a cada tentativa faz o servidor gravar o mesmo lote de novo, e o relatório contar duas vezes'
		);

		afirmar(
			JSON.stringify( tentativas[ 0 ].eventos ) === JSON.stringify( tentativas[ 1 ].eventos ),
			'PISO do reenvio: a retentativa levou conteúdo DIFERENTE sob o mesmo selo. Selado é imutável: ' +
				'um lote que crescesse mantendo o selo teria o crescimento recusado como repetição e descartado pelo próprio 2xx, e as linhas novas sumiriam sem que nada acusasse'
		);
	}

	/*
	 * MUTAÇÃO (c) — SELO SORTEADO A CADA DESPACHO.
	 *
	 * É o erro natural de quem põe o identificador no corpo em vez de no lote:
	 * cada tentativa vira um lote novo para o servidor, e a retentativa de um
	 * lote que ele já gravou passa a contar duas vezes. A outra metade desta
	 * mutação — o servidor aceitando o mesmo selo duas vezes — mora na sonda do
	 * site-core, em `comportamento.lote_idempotente`.
	 */
	const seloPorDespacho = fonte.replace( 'lote: lote.id,', 'lote: sorteado(),' );

	afirmar(
		seloPorDespacho !== fonte,
		'PISO do reenvio: a bancada não encontrou o selo do lote no corpo para trocá-lo por um sorteio a cada despacho'
	);

	if ( seloPorDespacho !== fonte ) {
		let recusaNoMutante = true;

		const mutanteDoSelo = bancadaDaVisita( seloPorDespacho, {}, {
			semente: 349,
			resposta: () => ( recusaNoMutante ? 503 : 201 )
		} );

		mutanteDoSelo.rolarAte( 0 );
		mutanteDoSelo.rolarAte( 100 );
		mutanteDoSelo.ocultar();

		recusaNoMutante = false;
		mutanteDoSelo.voltarAVer();
		mutanteDoSelo.sair();

		const doMutante = mutanteDoSelo.cargas().filter( Boolean );

		afirmar(
			2 === doMutante.length && doMutante[ 0 ].lote !== doMutante[ 1 ].lote,
			'PISO do reenvio: com o selo sorteado a cada despacho, as duas tentativas saíram com o mesmo selo. ' +
				'A bancada não reproduz o defeito, e um piso que não sabe falhar não prova que o selo do LOTE está fazendo alguma coisa'
		);
	}

	/*
	 * PISO 7: O TETO DO CORPO SELA O LOTE, E NÃO CORTA A LINHA.
	 *
	 * A ÚLTIMA ROTA pela qual o contador andava sem a linha chegar, e ela
	 * sobreviveu ao conserto principal. `registrar()` recusava a linha quando o
	 * acumulado atingia `maximoLog` — o teto de linhas de UM corpo — e somava
	 * em cortadas; mas `contarTravessia()` já tinha andado, e depois do
	 * selamento o registro voltava a aceitar. O resultado não é a série
	 * terminando: é BURACO NO MEIO dela, com as linhas seguintes chegando
	 * normalmente.
	 *
	 * E ELE É ALCANÇÁVEL SEM NADA DE ANORMAL: cento e vinte acionamentos entre
	 * dois ocultamentos é um leitor inquieto numa página longa que não troca de
	 * aba. O caso de rajada — o erro de JavaScript em laço de render — nunca
	 * foi este: ele tem teto próprio de 3 na declaração do evento.
	 *
	 * O teto passou a ser o GATILHO de um selamento. O lote cheio vira lote
	 * pendente na hora, a linha entra no lote seguinte, e a série não abre
	 * buraco. A bancada aperta `maximoLog` para que o caso caiba num teste, e
	 * deixa `maximoVisita` folgado — apertar os dois mediria o orçamento da
	 * visita, que é outro teto e tem outro desfecho legítimo.
	 */
	const loteApertado = Object.assign( {}, dados, {
		resumo: Object.assign( {}, dados.resumo, { maximoLog: 4, maximoVisita: 300 } )
	} );

	/**
	 * O leitor que produz MUITO acionamento ENTRE DOIS OCULTAMENTOS.
	 *
	 * A geometria do caso importa, e é a do defeito: um trecho longo sem trocar
	 * de aba — todo o registro se acumulando no MESMO corpo —, depois um
	 * ocultamento, depois outro trecho longo. O ocultamento é o que separa
	 * TRUNCAR de ABRIR BURACO: cortando a linha, o primeiro trecho para na
	 * quarta e o segundo volta a registrar do zero, e é aí que a série fica com
	 * buraco no meio em vez de simplesmente terminar. Sem o ocultamento, o
	 * mutante que corta produziria uma série truncada — que é um defeito
	 * diferente, e este piso não estaria medindo o que promete.
	 *
	 * @param {string} codigo Fonte do cliente a exercitar.
	 * @return {Object} `{bancada, linhas}` do carregamento.
	 */
	function leitorSemTrocarDeAba( codigo ) {
		const bancada = bancadaDeComportamento( codigo, loteApertado, Object.assign( {}, paginaDaVisita, { semente: 379 } ) );

		for ( let volta = 0; volta < 3; volta++ ) {
			bancada.rolarAte( 0 );
			bancada.rolarAte( 100 );
		}

		bancada.ocultar();
		bancada.voltarAVer();

		for ( let volta = 0; volta < 3; volta++ ) {
			bancada.rolarAte( 0 );
			bancada.rolarAte( 100 );
		}

		bancada.sair();

		return { bancada, linhas: entregues( [ bancada ] ) };
	}

	const semTrocarDeAba = leitorSemTrocarDeAba( fonte );

	afirmar(
		semTrocarDeAba.bancada.recebidas().length > 1,
		'teto da bancada do lote cheio: o carregamento produziu ' + semTrocarDeAba.bancada.recebidas().length +
			' lote(s) com o teto de corpo em 4. Ele precisa passar do teto VÁRIAS vezes, senão a bancada não chega a exercitar o que mede'
	);

	for ( const bloco of [ 'abertura', 'pecas' ] ) {
		const vezes = ocorrenciasDe( semTrocarDeAba.linhas, 'interseccao', bloco );

		afirmar(
			! temBuraco( vezes ) && vezes.length >= 6,
			'PISO do teto do corpo: o bloco "' + bloco + '" chegou com ' + JSON.stringify( vezes ) +
				' num carregamento que passou do teto de corpo várias vezes. O teto do CORPO é do lote, não do registro: ' +
				'ele tem de SELAR o lote e deixar a linha entrar no seguinte. Cortando a linha, o contador anda, a série volta a aceitar depois do selamento, e o buraco fica no MEIO dela'
		);
	}

	for ( const marco of marcos ) {
		afirmar(
			! temBuraco( ocorrenciasDe( semTrocarDeAba.linhas, 'rolagem', marco ) ),
			'PISO do teto do corpo: o marco de ' + marco + '% chegou com ' +
				JSON.stringify( ocorrenciasDe( semTrocarDeAba.linhas, 'rolagem', marco ) ) + ', e a sequência tem buraco'
		);
	}

	afirmar(
		semTrocarDeAba.bancada.recebidas().every( ( lote ) => ( lote.eventos || [] ).length <= 4 ),
		'teto do corpo: algum lote saiu com mais linhas que o teto declarado de corpo. Selar em vez de cortar não pode virar não ter teto nenhum — ' +
			'o teto é do endpoint, e endpoint sem teto de tamanho é endpoint aberto'
	);

	afirmar(
		0 === Number( ( semTrocarDeAba.bancada.recebidas().pop() || {} ).cortados || 0 ),
		'PISO do teto do corpo: o carregamento cortou ' + Number( ( semTrocarDeAba.bancada.recebidas().pop() || {} ).cortados || 0 ) +
			' acionamento(s) por causa do teto de CORPO. Corte é a resposta certa para o orçamento da visita, que é o fim da série; ' +
			'para o teto do corpo ele é buraco no meio, e um leitor atento não pode ser a condição normal de perda'
	);

	/*
	 * MUTAÇÃO — CORTAR EM VEZ DE SELAR. É o código de antes desta correção, e
	 * sem ela o piso não prova nada: foi exatamente esse comportamento que
	 * passou em toda a bancada anterior, porque nenhum caso dela chegava ao
	 * teto do corpo.
	 */
	const cortaNoTeto = fonte.replace(
		'\t\tif (registroDaSessao.length >= Number(RESUMO.maximoLog || 0)) {\n\t\t\tselarLote();\n\t\t}',
		'\t\tif (registroDaSessao.length >= Number(RESUMO.maximoLog || 0)) {\n\t\t\tcortadasNaVisita = cortadasNaVisita + 1;\n\n\t\t\treturn;\n\t\t}'
	);

	afirmar(
		cortaNoTeto !== fonte,
		'PISO do teto do corpo: a bancada não encontrou o selamento no teto de corpo para trocá-lo pelo corte. ' +
			'Ou ele mudou de forma e o piso deixou de provar o que promete, ou sumiu — e nesse caso o teto acima é que deveria ter acusado'
	);

	if ( cortaNoTeto !== fonte ) {
		const doMutante = leitorSemTrocarDeAba( cortaNoTeto );

		afirmar(
			temBuraco( ocorrenciasDe( doMutante.linhas, 'interseccao', 'abertura' ) ),
			'PISO do teto do corpo: cortando a linha no teto de corpo, o bloco do topo chegou com ' +
				JSON.stringify( ocorrenciasDe( doMutante.linhas, 'interseccao', 'abertura' ) ) +
				' — e ele deveria ter BURACO. A bancada não reproduz o defeito, e um piso que não sabe falhar não prova que o selamento está fazendo alguma coisa'
		);

		afirmar(
			doMutante.linhas.length < semTrocarDeAba.linhas.length,
			'PISO do teto do corpo: o mutante que corta entregou ' + doMutante.linhas.length +
				' linha(s) e o pacote entrega ' + semTrocarDeAba.linhas.length + '. Cortando, o leitor atento perde acionamento; selando, ele não perde nenhum'
		);
	}

	/*
	 * PISO 6: O PENDENTE RESPEITA O ORÇAMENTO, E O EXCEDENTE SAI NOMEADO.
	 *
	 * O orçamento não é número novo: toda linha que entra num lote passou por
	 * `registrar()`, que já gasta o teto de `maximoVisita` da VISITA inteira. A
	 * fila é, por construção, um subconjunto dele — mesmo com o servidor
	 * recusando tudo, ela não pode crescer além do que a visita podia registrar.
	 */
	const orcamentoApertado = Object.assign( {}, dados, {
		resumo: Object.assign( {}, dados.resumo, { maximoVisita: 6 } )
	} );

	const semDrenar = bancadaDeComportamento( fonte, orcamentoApertado, Object.assign( {}, paginaDaVisita, {
		semente: 353,
		resposta: 503
	} ) );

	for ( let volta = 0; volta < 8; volta++ ) {
		semDrenar.rolarAte( 0 );
		semDrenar.rolarAte( 100 );
		semDrenar.ocultar();
		semDrenar.voltarAVer();
	}

	const naFila = semDrenar.cargas().filter( Boolean ).pop() || {};
	let linhasNaFila = 0;

	try {
		const guardadoNaFila = JSON.parse(
			String( ( semDrenar.gravacoes().filter( ( g ) => 'f3base_sessao' === g.chave ).pop() || {} ).valor || '{}' )
		);

		for ( const lote of guardadoNaFila.pendentes || [] ) {
			linhasNaFila += ( lote.eventos || [] ).length;
		}

		linhasNaFila += ( ( guardadoNaFila.acumulado || {} ).eventos || [] ).length;
	} catch {
		linhasNaFila = -1;
	}

	afirmar(
		linhasNaFila >= 0 && linhasNaFila <= 6,
		'PISO do orçamento do pendente: com o servidor recusando tudo, a fila guardou ' + linhasNaFila +
			' linha(s) e o orçamento da visita é 6. O pendente não ganha teto próprio: ele é limitado pelo MESMO `maximoVisita` que já governa o registro, ' +
			'e um segundo número aqui divergiria do primeiro na primeira vez que alguém mexesse num só'
	);

	afirmar(
		Number( naFila.cortados ) > 0,
		'PISO do corte nomeado: passado o orçamento, o lote seguinte despachou ' + naFila.cortados +
			' cortada(s). O excedente sai NOMEADO — corte silencioso faz o total do painel não bater com a tabela sem nada em lugar nenhum dizendo por quê'
	);


	/*
	 * O ESTADO ARMADO DA SEÇÃO É POR ELEMENTO, e o observador sempre foi por
	 * ELEMENTO — era o estado que estava chaveado por NOME.
	 *
	 * O QUE ACONTECIA. Uma página com DOIS blocos da mesma seção declarada
	 * produz dois alvos observados. Entrando o primeiro, o estado sob aquele
	 * NOME subia; entrando o segundo na mesma passagem, ele encontrava o estado
	 * já levantado e era ENGOLIDO — a travessia daquele bloco não existia. E a
	 * saída do primeiro derrubava o estado do segundo, que ainda estava na tela:
	 * o retorno seguinte dele contava como travessia nova. O mesmo defeito
	 * perdia passagem real e fabricava passagem que não houve, dependendo só da
	 * ordem em que os retornos chegavam.
	 *
	 * A GEOMETRIA DESTE CASO é a que separa os dois desenhos: os dois blocos
	 * ficam visíveis ACIMA da linha de entrada na MESMA posição de rolagem. Com o
	 * estado por elemento, cada um conta a passagem dele; com o estado por nome,
	 * o segundo é engolido pelo primeiro.
	 */
	const doisBlocosIguais = bancadaDeComportamento( fonte, dados, {
		alturaDocumento: 4000,
		secoes: [ 'f3base-secao-pecas', 'f3base-secao-pecas' ],
		geometria: [ { topo: 900, altura: 400 }, { topo: 1300, altura: 400 } ],
		semente: 11
	} );

	doisBlocosIguais.rolarAte( 25 );
	doisBlocosIguais.sair();

	const cargaDosDois = doisBlocosIguais.cargas().filter( Boolean )[ 0 ] || { eventos: [] };
	const vezesDosDois = ocorrenciasDe( cargaDosDois.eventos || [], 'interseccao', 'pecas' );

	afirmar(
		JSON.stringify( vezesDosDois ) === JSON.stringify( [ 1, 2 ] ),
		'TETO do estado por elemento: dois blocos com a MESMA seção declarada, os dois acima da linha de entrada na mesma posição de rolagem, saíram com as ocorrências ' +
			JSON.stringify( vezesDosDois ) + ' em vez de [1,2]. O observador é por elemento e o estado armado precisa ser também: guardado sob o nome, o segundo bloco é engolido pelo primeiro'
	);

	/*
	 * PISO: com o estado chaveado por NOME — o código de ontem — a mesma bancada
	 * tem de dar outro número. Um teto que não sabe falhar não protege nada.
	 */
	const armadoPorNome = fonte
		.replace( /dentroDaVista\[qual\]/g, 'dentroDaVista[secao]' )
		.replace( /\t\t\t\tdentroDaVista\.push\(false\);\n/, '' )
		.replace( 'var dentroDaVista = [];', 'var dentroDaVista = {};' );

	afirmar(
		armadoPorNome !== fonte,
		'PISO do estado por elemento: a bancada não encontrou o estado armado da seção para chaveá-lo por nome. Ou ele mudou de forma, e o piso deixou de provar o que promete, ou ele sumiu'
	);

	if ( armadoPorNome !== fonte ) {
		const mutantePorNome = bancadaDeComportamento( armadoPorNome, dados, {
			alturaDocumento: 4000,
			secoes: [ 'f3base-secao-pecas', 'f3base-secao-pecas' ],
			geometria: [ { topo: 900, altura: 400 }, { topo: 1300, altura: 400 } ],
			semente: 11
		} );

		mutantePorNome.rolarAte( 25 );
		mutantePorNome.sair();

		const cargaMutante = mutantePorNome.cargas().filter( Boolean )[ 0 ] || { eventos: [] };
		const vezesMutante = ocorrenciasDe( cargaMutante.eventos || [], 'interseccao', 'pecas' );

		afirmar(
			JSON.stringify( vezesMutante ) !== JSON.stringify( [ 1, 2 ] ),
			'PISO do estado por elemento: com o estado armado chaveado por NOME, os dois blocos iguais saíram com ' +
				JSON.stringify( vezesMutante ) + ' — o mesmo resultado do código correto. A bancada não reproduz o defeito'
		);
	}

	return { achados };
}

const modo = process.argv[ 2 ] || '';
const raiz = process.argv[ 3 ] || '';

if ( 'lint' === modo ) {
	process.stdout.write( JSON.stringify( lint( raiz ) ) );
} else if ( 'leads' === modo ) {
	process.stdout.write( JSON.stringify( limiteDoCliente( raiz ) ) );
} else if ( 'conversao' === modo ) {
	/*
	 * O ÚNICO MODO ASSÍNCRONO, e a razão é o REENVIO: o cliente troca o token
	 * vencido e manda de novo dentro de uma promessa, e medir isso exige deixar
	 * a fila de microtarefas correr antes de ler o resultado.
	 */
	conversaoDoClique( raiz ).then( ( veredito ) => process.stdout.write( JSON.stringify( veredito ) ) );
} else if ( 'comportamento' === modo ) {
	process.stdout.write( JSON.stringify( comportamentoInstrumentado( raiz ) ) );
} else if ( 'resumo' === modo ) {
	process.stdout.write( JSON.stringify( resumoDaSessao( raiz ) ) );
} else if ( 'ciclo' === modo ) {
	process.stdout.write( JSON.stringify( cicloDeVidaDaPagina( raiz ) ) );
} else if ( 'releitura' === modo ) {
	process.stdout.write( JSON.stringify( sessaoComReleitura( raiz ) ) );
} else if ( 'ordem' === modo ) {
	process.stdout.write( JSON.stringify( ordemDoConsentimento( raiz ) ) );
} else if ( 'eventos' === modo ) {
	/*
	 * A DECLARAÇÃO, LIDA DO TSV E IMPRESSA — para a sonda de navegador, que
	 * precisa publicá-la ao navegador exatamente como o servidor a publica.
	 *
	 * Ela sai por AQUI, e não por um `eventos.json` versionado, porque uma cópia
	 * congelada da declaração diverge dela na primeira edição do TSV: a sonda
	 * passaria a medir um limiar que o site não usa mais, e a rodada seguinte
	 * aprovaria o que o navegador reprova. O leitor é o MESMO que as bancadas
	 * usam — `declaracaoDeComportamento()` —, e não um segundo analisador.
	 */
	process.stdout.write( JSON.stringify( declaracaoDeComportamento( raiz ) ) );
} else {
	process.stdout.write( JSON.stringify( { achados: [ 'modo desconhecido: ' + modo ] } ) );
}
