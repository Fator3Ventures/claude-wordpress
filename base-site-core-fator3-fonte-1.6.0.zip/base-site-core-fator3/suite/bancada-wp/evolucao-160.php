<?php
/** Casos de falha com WordPress, SQLite, HTTP e navegador reais. */
declare( strict_types = 1 );
function f3b_160_options(): array {
	global $wpdb; wp_set_current_user( 1 );
	$n = 'f3base_contato';
	F3Base_Options::gravar( $n, array( 'whatsapp_e164'=>'5511999999999' ), F3Base_Options::ORIGEM_IMPLANTADOR );
	$antes = F3Base_Options::ler( $n ); $origem = F3Base_Options::proveniencia( $n );
	$recusar = static fn( $novo, $velho ) => $velho;
	add_filter( 'pre_update_option_' . $n, $recusar, 10, 2 );
	try { $r = F3Base_Options::gravar( $n, array( 'whatsapp_e164'=>'5521999999999' ), F3Base_Options::ORIGEM_MANUAL ); }
	finally { remove_filter( 'pre_update_option_' . $n, $recusar ); }
	f3b_e_exige( ! $r['ok'] && F3Base_Options::ler( $n ) === $antes && F3Base_Options::proveniencia( $n ) === $origem, 'Recusa mudou valor ou procedência.' );
	$auditoria = get_option( F3Base_Options::OPTION_TENTATIVAS );
	f3b_e_exige( end( $auditoria )['codigo'] === 'persistencia_divergente' && ! str_contains( wp_json_encode( $auditoria ), '5521999999999' ), 'Tentativa sem registro separado ou com valor sensível.' );
	// Falha física de SQL também deve preservar origem.
	$quebrar = static fn( $sql ) => str_starts_with( $sql, 'UPDATE `' . $wpdb->options . '`' ) && str_contains( $sql, "'f3base_contato'" ) ? str_replace( $wpdb->options, 'tabela_que_nao_existe', $sql ) : $sql;
	add_filter( 'query', $quebrar ); $silencio = $wpdb->suppress_errors();
	try { $r = F3Base_Options::gravar( $n, array( 'whatsapp_e164'=>'5531999999999' ) ); }
	finally { remove_filter( 'query', $quebrar ); $wpdb->suppress_errors( $silencio ); }
	f3b_e_exige( ! $r['ok'] && F3Base_Options::proveniencia( $n ) === $origem, 'Falha física carimbou procedência.' );
	foreach ( F3Base_Core_Config_Mcp::ler()['opcoes'] as $nome => $d ) {
		if ( F3Base_Options::e_segredo( $nome ) ) { continue; }
		$p = F3Base_Core_Config_Mcp::escrever( array( 'nome'=>$nome, 'valor'=>$d['valor'], 'revisao_esperada'=>$d['revisao'] ) );
		f3b_e_exige( ! empty( $p['ok'] ) && ! empty( $p['simulado'] ), 'Schema não aceita o próprio valor: ' . $nome . wp_json_encode( $p ) );
	}
	$habilidade = wp_get_ability( 'f3base/config-core-escrever' );
	f3b_e_exige( is_object( $habilidade ), 'Habilidade nativa ausente.' );
	$d = F3Base_Core_Config_Mcp::ler( array( 'nome'=>$n ) )['opcoes'][$n];
	$entrada = array( 'nome'=>$n, 'valor'=>array_merge( $d['valor'], array( 'flutuante'=>true ) ), 'revisao_esperada'=>$d['revisao'] );
	$r = $habilidade->execute( $entrada ); f3b_e_exige( ! is_wp_error( $r ) && $r['simulado'] && F3Base_Options::ler( $n ) === $antes, 'Preview gravou dados.' );
	$r = $habilidade->execute( $entrada + array( 'simular'=>false ) ); f3b_e_exige( ! is_wp_error( $r ) && $r['ok'] && F3Base_Options::ler( $n )['flutuante'], 'Aplicação condicional falhou: ' . wp_json_encode( $r ) );
	$r = $habilidade->execute( $entrada + array( 'simular'=>false ) ); f3b_e_exige( ! $r['ok'] && 'conflito' === $r['codigo'], 'Revisão antiga sobrescreveu valor.' );
	// Concorrente escreve entre a leitura da revisão e o UPDATE condicional.
	$d = F3Base_Core_Config_Mcp::ler( array( 'nome'=>$n ) )['opcoes'][$n];
	$intruso = static function( $sql ) use ( $wpdb, $n, &$intruso ) {
		if ( str_starts_with( $sql, 'UPDATE ' . $wpdb->options . ' SET option_value=' ) && str_contains( $sql, 'HEX(option_value)' ) ) {
			remove_filter( 'query', $intruso ); F3Base_Options::gravar( $n, array( 'whatsapp_e164'=>'5541999999999' ), F3Base_Options::ORIGEM_IMPLANTADOR );
		}
		return $sql;
	};
	add_filter( 'query', $intruso );
	try { $r = F3Base_Core_Config_Mcp::escrever( array( 'nome'=>$n, 'valor'=>$antes, 'revisao_esperada'=>$d['revisao'], 'simular'=>false ) ); }
	finally { remove_filter( 'query', $intruso ); }
	f3b_e_exige( ! $r['ok'] && '5541999999999' === F3Base_Options::ler( $n )['whatsapp_e164'], 'Compare-and-swap perdeu atualização concorrente.' );
	wp_set_current_user( 0 ); f3b_e_exige( is_wp_error( $habilidade->execute( $entrada ) ) && ! F3Base_Core_Config_Mcp::ler()['ok'], 'Configuração acessível sem autorização.' );
	return array( 'OK', 'Filtro e erro SQL preservam origem; auditoria sem valores; schemas, preview, aplicação, conflito real e permissão conferidos.' );
}
function f3b_160_capi(): array {
	global $wpdb; $m = 'F3Base_Modulo_Meta_Capi';
	f3b_e_exige( F3Base_Capi_Fila::instalar(), 'Fila não criada.' ); $t = F3Base_Capi_Fila::tabela(); $wpdb->query( "DELETE FROM {$t}" );
	F3Base_Options::gravar( 'f3base_meta_capi_token', 'TOKEN-SINTETICO-BANCADA' ); F3Base_Options::gravar( 'f3base_meta_pixel_id', '123456789012345' );
	$dados = array( 'correlation_id'=>'evento-bancada', 'email'=>'Jose@Exemplo.test', 'telefone'=>'+55 (11) 99999-0000', 'pagina'=>'/contato/' );
	f3b_e_exige( empty( $m::agendar( $dados, 'recusado', '192.0.2.1', false )['agendado'] ) && ! F3Base_Capi_Fila::ler( 'recusado' ), 'Consentimento recusado criou conversão.' );
	$r = $m::agendar( $dados, 'registro-160', '192.0.2.1', true );
	f3b_e_exige( $r['persistido'] && $r['agendado'], 'Evento não persistido/agendado: ' . wp_json_encode( $r ) );
	$p = json_decode( F3Base_Capi_Fila::ler( 'registro-160' )['payload'], true );
	f3b_e_exige( $p['data'][0]['event_id'] === 'evento-bancada' && $p['data'][0]['user_data']['em'][0] === hash( 'sha256', 'jose@exemplo.test' ) && ! isset( $p['access_token'] ), 'Identidade/hash/segredo do payload incorretos.' );
	$envios = array(); $codigo = 503; $erro_rede = false;
	$http = static function( $pre, $args, $url ) use ( &$envios, &$codigo, &$erro_rede ) {
		$envios[] = json_decode( $args['body'], true );
		return $erro_rede ? new WP_Error( 'http_request_failed', 'timeout sintético' ) : array( 'headers'=>array(), 'response'=>array( 'code'=>$codigo ), 'body'=>wp_json_encode( $codigo === 200 ? array( 'events_received'=>1, 'fbtrace_id'=>'TRACE-SINTETICO' ) : array( 'error'=>array( 'message'=>'erro sintético' ) ) ) );
	};
	add_filter( 'pre_http_request', $http, 10, 3 );
	try {
		$m::enviar( 'registro-160' ); $r = F3Base_Capi_Fila::ler( 'registro-160' );
		f3b_e_exige( $r['estado'] === 'pendente' && $r['payload'] !== '' && (int) $r['tentativas'] === 1 && (int) $r['proxima'] > time(), 'Falha temporária perdeu evento ou não adiou tentativa.' );
		$m::enviar( 'registro-160' ); f3b_e_exige( count( $envios ) === 1, 'Lease/backoff não impediu envio duplicado.' );
		$wpdb->update( $t, array( 'proxima'=>time()-1 ), array( 'record_id'=>'registro-160' ) ); $codigo = 200;
		$r = $m::enviar( 'registro-160' ); $fila = F3Base_Capi_Fila::ler( 'registro-160' );
		f3b_e_exige( $r['ok'] && $fila['estado'] === 'entregue' && $fila['payload'] === '' && $envios[0]['data'] === $envios[1]['data'], 'Confirmação perdeu identidade/timestamp ou reteve dados pessoais.' );
		$m::enviar( 'registro-160' ); f3b_e_exige( count( $envios ) === 2, 'Confirmação reenviada.' );
		foreach ( array( 'permanente'=>400, 'retentativas'=>503, 'rede'=>0 ) as $id=>$status ) {
			F3Base_Capi_Fila::inserir( $id, $p, 3600 ); $codigo=$status; $erro_rede=$status===0;
			for ( $i=0; $i< F3Base_Capi_Fila::MAX_TENTATIVAS + 1; ++$i ) { $wpdb->update( $t, array( 'proxima'=>time()-1 ), array( 'record_id'=>$id ) ); $m::enviar( $id ); }
			$r = F3Base_Capi_Fila::ler( $id ); f3b_e_exige( $r['estado'] === 'falhou' && $r['payload'] === '' && (int) $r['tentativas'] === ( $status === 400 ? 1 : F3Base_Capi_Fila::MAX_TENTATIVAS ), 'Limite/erro permanente incorreto: ' . $id );
		}
	} finally { remove_filter( 'pre_http_request', $http ); }
	F3Base_Capi_Fila::inserir( 'interrompido', $p, 3600 ); $a=F3Base_Capi_Fila::reservar( 'interrompido' ); f3b_e_exige( $a && ! F3Base_Capi_Fila::reservar( 'interrompido' ), 'Dois consumidores obtiveram a mesma reserva.' );
	$wpdb->update( $t, array( 'proxima'=>time()-1 ), array( 'record_id'=>'interrompido' ) ); $b=F3Base_Capi_Fila::reservar( 'interrompido' );
	F3Base_Capi_Fila::concluir( $a,200,true,false ); f3b_e_exige( F3Base_Capi_Fila::ler( 'interrompido' )['reserva'] === $b['reserva'], 'Consumidor antigo concluiu a nova reserva.' );
	$wpdb->update( $t, array( 'expira'=>time()-1 ), array( 'record_id'=>'interrompido' ) ); F3Base_Capi_Fila::recuperar();
	f3b_e_exige( F3Base_Capi_Fila::ler( 'interrompido' )['payload'] === '' && wp_next_scheduled( F3Base_Capi_Fila::EVENTO ), 'Expiração/recuperação automática falhou.' );
	return array( 'OK', 'Consentimento, payload, persistência, 503/rede, backoff, teto, 400, confirmação, identidade, lease e expiração medidos sem envio externo.' );
}
function f3b_160_cache(): array {
	global $wpdb;
	[ , , , , $dir ] = f3b_e_fixture(); $f=$dir.'/access.log'; file_put_contents( $f, f3b_a_log( '/um/' ) );
	$a=F3Base_Acessos_Atuais::ler(); $b=F3Base_Acessos_Atuais::ler();
	f3b_e_exige( ! $a['erro'] && ! $b['erro'] && $b['bytes_lidos']===0 && $b['incremental'], 'Log inalterado foi relido.' );
	$linha=f3b_a_log( '/dois/' ); file_put_contents( $f, $linha, FILE_APPEND ); $b=F3Base_Acessos_Atuais::ler();
	f3b_e_exige( ! $b['erro'] && $b['bytes_lidos']===strlen( $linha ) && array_sum( array_column( $b['linhas'],'contagem' ) )===2, 'Append duplicou contagem ou releu arquivo.' );
	file_put_contents( $f, f3b_a_log( '/rotacao/' ) ); $b=F3Base_Acessos_Atuais::ler();
	f3b_e_exige( ! $b['erro'] && ! $b['incremental'] && count( $b['linhas'] )===1 && $b['linhas'][0]['caminho']==='/rotacao/', 'Copy-truncate manteve fotografia antiga.' );
	$c=F3Base_Options::declaracao( 'f3base_llms' )['padrao']; $c['ligado']=true; $c['full']=true; F3Base_Options::gravar( 'f3base_llms',$c );
	$id=wp_insert_post( array( 'post_type'=>'page','post_title'=>'Cache revisão inicial','post_content'=>'ConteudoInicialDeBancada','post_status'=>'publish' ) );
	$etags=array();
	foreach ( array( '/llms.txt','/llms-full.txt' ) as $rota ) {
		$a=f3b_bancada_get( $rota ); $b=f3b_bancada_get( $rota );
		f3b_e_exige( $a['codigo']===200 && $a['corpo']===$b['corpo'] && str_contains( $a['corpo'],'Cache revisão inicial' ), 'Cache público não entregou texto estável: '.$rota.' '.wp_json_encode(array('codigoA'=>$a['codigo'],'codigoB'=>$b['codigo'],'igual'=>$a['corpo']===$b['corpo'],'corpo'=>substr($a['corpo'],0,1400))) );
		$http=wp_remote_get( home_url('').$rota ); $etag=wp_remote_retrieve_header( $http,'etag' ); $etags[$rota]=$etag;
		$r=wp_remote_get( home_url('').$rota,array( 'headers'=>array( 'If-None-Match'=>$etag ) ) );
		f3b_e_exige( $etag && wp_remote_retrieve_response_code( $r )===304 && wp_remote_retrieve_body( $r )==='', 'ETag/304 incorreto: '.$rota.' '.wp_json_encode(array('etag'=>$etag,'codigo'=>wp_remote_retrieve_response_code($r),'corpo'=>substr(wp_remote_retrieve_body($r),0,400))) );
	}
	wp_update_post( array( 'ID'=>$id,'post_title'=>'Cache revisão atualizada','post_content'=>'ConteudoAtualizadoDeBancada' ) );
	foreach ( array_keys($etags) as $rota ) { $r=wp_remote_get( home_url('').$rota,array('headers'=>array('If-None-Match'=>$etags[$rota])) ); f3b_e_exige( wp_remote_retrieve_response_code($r)===200 && str_contains(wp_remote_retrieve_body($r),'Cache revisão atualizada'), 'Publicação não invalidou '.$rota ); }
	wp_update_post( array( 'ID'=>$id,'post_status'=>'private' ) );
	foreach ( array_keys($etags) as $rota ) { f3b_e_exige( ! str_contains( f3b_bancada_get($rota)['corpo'],'Cache revisão atualizada' ), 'Cache divulgou conteúdo privado: '.$rota ); }
	return array( 'OK','Append e rotação sem dupla contagem; cache HTTP, ETag, atualização e retirada imediata de conteúdo privado em ambos os llms.' );
}
function f3b_160_vitais(): array {
	global $wpdb; F3Base_Vitais::instalar(); $t=F3Base_Vitais::tabela(); $wpdb->query( 'DELETE FROM '.$t ); $dia=gmdate('Y-m-d');
	foreach ( array(100,200,300,400) as $i=>$valor ) {
		$linha=array('metrica'=>'desempenho','detalhe'=>'LCP','soma'=>$valor,'amostra'=>array('id'=>'vital-bancada-'.$i,'dispositivo'=>'movel','sequencia'=>1));
		f3b_e_exige( F3Base_Vitais::gravar($dia,'/teste/',$linha), 'Amostra não gravada.' ); F3Base_Vitais::gravar($dia,'/teste/',$linha);
	}
	$r=F3Base_Vitais::estatisticas(7,'/teste/','movel'); f3b_e_exige($r[0]['amostras']===4 && $r[0]['p75']===300.0,'p75 ou deduplicação incorretos.');
	$linha['soma']=250; $linha['amostra']['sequencia']=2; F3Base_Vitais::gravar($dia,'/teste/',$linha);
	$linha['soma']=900; $linha['amostra']['sequencia']=1; F3Base_Vitais::gravar($dia,'/teste/',$linha);
	$r=F3Base_Vitais::estatisticas(7,'/teste/','movel'); f3b_e_exige($r[0]['amostras']===4 && $r[0]['p75']===250.0 && ! F3Base_Vitais::estatisticas(7,'/teste/','desktop'),'Última revisão, ordem ou filtro incorretos.');
	$boa=array('gatilho'=>'desempenho','detalhe'=>'CLS','contagem'=>1,'soma'=>0.1,'amostra'=>array('id'=>'vital-valida','dispositivo'=>'desktop','sequencia'=>1));
	f3b_e_exige(!isset(F3Base_Modulo_Comportamento::validar_metricas(array($boa))['erro']),'Schema recusou amostra válida.');
	foreach(array(array('email'=>'privado'),array('sequencia'=>61),array('dispositivo'=>'tablet'),array('id'=>'/privado/')) as $erro){$ruim=$boa;$ruim['amostra']=array_merge($boa['amostra'],$erro);f3b_e_exige(isset(F3Base_Modulo_Comportamento::validar_metricas(array($ruim))['erro']),'Schema aceitou amostra inválida.');}
	F3Base_Options::gravar('f3base_comportamento',array('ligado'=>true));
	$lote=f3b_bancada_lote(f3b_bancada_apelido('vitais-http'),array($boa));
	$r=f3b_bancada_post(f3b_bancada_rest('/f3base/v1/comportamento'),$lote);
	f3b_e_exige($r['codigo']===201,'Endpoint recusou amostra: '.$r['corpo']);
	$r=f3b_bancada_post(f3b_bancada_rest('/f3base/v1/comportamento'),$lote);
	f3b_e_exige($r['codigo']===200,'Lote não deduplicado.');
	$estatistica=F3Base_Vitais::estatisticas(7,'/','desktop');
	f3b_e_exige($estatistica[0]['amostras']===1 && abs($estatistica[0]['p75']-0.1)<0.00001,'Amostra REST não persistida corretamente.');
	return array('OK','p75 por página/tela, deduplicação, atualização fora de ordem e schema fechado conferidos no banco real.');
}
function f3b_160_whatsapp(): array {
	$m=new F3Base_Modulo_Leads_Whatsapp(); $html='<a class="f3base-cta" href="/contato/">Contato do tema</a>';
	foreach(array(false,true) as $on){F3Base_Options::gravar('f3base_contato',array('whatsapp_e164'=>'5511999999999','flutuante'=>$on));f3b_e_exige($m->promover_cta($html,array())===$html,'Core alterou botão do layout.');$r=f3b_bancada_get('/');f3b_e_exige(str_contains($r['corpo'],'id="f3base-whatsapp-flutuante"')===$on,'Ativação do ícone não corresponde à opção.');}
	$id=wp_insert_post(array('post_type'=>'page','post_status'=>'publish','post_title'=>'Página ícone flutuante','post_content'=>'Conteúdo para rolar '.str_repeat('<p>Rolagem de bancada.</p>',90)));
	$url=get_permalink($id);
	$r=wp_remote_get($url); f3b_e_exige(str_contains(wp_remote_retrieve_body($r),'id="f3base-whatsapp-flutuante"'),'Ícone ausente em página interna.');
	$saida=array();$codigo=0;exec('node '.escapeshellarg(__DIR__.'/evolucao-160.cjs').' '.escapeshellarg(home_url('/')).' '.escapeshellarg($url).' '.escapeshellarg(getenv('F3BASE_BANCADA_TMP').'/browser-160.json').' 2>&1',$saida,$codigo);
	f3b_e_exige($codigo===0,'Navegador: '.implode("\n",$saida));
	F3Base_Options::gravar('f3base_contato',array('whatsapp_e164'=>'','flutuante'=>true));f3b_e_exige(!str_contains(f3b_bancada_get('/')['corpo'],'id="f3base-whatsapp-flutuante"'),'Ícone publicado sem destino.');
	return array('OK','Tema preservado, opção ligada/desligada, páginas internas e navegador desktop/móvel com ícone fixo e biblioteca oficial verificados.');
}
