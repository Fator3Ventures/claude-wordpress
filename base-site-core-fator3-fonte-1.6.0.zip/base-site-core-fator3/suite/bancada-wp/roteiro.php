<?php
/**
 * ROTEIRO DA BANCADA WORDPRESS REAL — um passo por processo, um veredito por passo.
 *
 * Este arquivo é executado por `php`, carregando o `wp-load.php` do WordPress
 * de verdade que `bancada.sh` acabou de montar num diretório descartável:
 * núcleo real, banco real pelo drop-in de SQLite, plugin instalado A PARTIR DO
 * ZIP desta rodada e ativado por wp-cli, servidor HTTP embutido no ar.
 *
 * TRÊS REGRAS DURAS, e elas são o motivo de o arquivo existir separado da suíte:
 *
 * 1. **Um veredito por execução.** Cada passo roda no próprio processo e grava
 *    UMA linha. Passo que reprova não impede o seguinte, e nenhum passo herda o
 *    estado que outro deixou: quem precisa de uma página publicada, de uma
 *    option gravada ou de um lote no banco reergue isso antes de medir.
 * 2. **Quem não pôde medir fecha BLOCKED, com o recurso nomeado.** Núcleo sem a
 *    Abilities API, wp-cli que não roda, servidor que não responde — nenhum
 *    deles é um pacote aprovado. Silêncio nunca vira OK aqui.
 * 3. **A linha carrega a FRASE DO CASO REAL no ramo adverso.** "reprovou" não
 *    ensina nada; o que ensina é o número que voltou, a tabela que ficou, o
 *    salto que se repetiu. É o teto e o piso do passo escritos na mesma linha.
 *
 * O TETO de cada passo é o comportamento que o documento do plugin promete; o
 * PISO é o defeito concreto que já foi observado no produto e que o passo tem de
 * acusar. `suite/bancada-wp/pisos.tsv` declara, para cada passo, qual mutante
 * planta o defeito — ou que o defeito ainda mora na própria fonte.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/*
 * O VEREDITO VAI PARA UM ARQUIVO, e não para a saída padrão. A saída padrão
 * deste processo é compartilhada com o que o núcleo, o plugin e o PHP
 * imprimirem — e um passo desta bancada existe justamente para provocar erro
 * fatal. Arquivo próprio é o que separa o veredito do rastro.
 */
$f3b_saida  = (string) ( $argv[1] ?? '' );
$f3b_passo  = (string) ( $argv[2] ?? '' );
$f3b_gravou = false;

define( 'WP_USE_THEMES', false );

$f3b_site = (string) getenv( 'F3BASE_SITE' );

if ( '' === $f3b_site || ! is_file( $f3b_site . '/wp-load.php' ) ) {
	file_put_contents(
		'' === $f3b_saida ? 'php://stderr' : $f3b_saida,
		'{"estado":"BLOCKED","nome":"wp.' . $f3b_passo . '","mensagem":"o roteiro não encontrou o WordPress da bancada. Recurso ausente: wp-load.php em F3BASE_SITE."}' . "\n"
	);
	exit( 2 );
}

require $f3b_site . '/wp-load.php';

/**
 * Grava o veredito do passo. Ponto único de saída deste arquivo.
 *
 * @param string $estado   Estado do contrato fechado da suíte.
 * @param string $nome     Nome do passo, sem o prefixo.
 * @param string $mensagem O que foi observado.
 * @return void
 */
function f3b_bancada_veredito( string $estado, string $nome, string $mensagem ): void {
	global $f3b_saida, $f3b_gravou;

	if ( $f3b_gravou ) {
		return;
	}

	$f3b_gravou = true;

	file_put_contents(
		$f3b_saida,
		(string) wp_json_encode(
			array(
				'estado'   => $estado,
				'nome'     => 'wp.' . $nome,
				'mensagem' => $mensagem,
			)
		) . "\n"
	);
}

/**
 * Endereço absoluto na bancada, a partir de um caminho.
 *
 * @param string $caminho Caminho começando por barra.
 * @return string
 */
function f3b_bancada_url( string $caminho ): string {
	return 'http://127.0.0.1:' . (int) getenv( 'F3BASE_BANCADA_PORTA' ) . $caminho;
}

/**
 * Endereço de uma rota REST, no formato que a bancada usa (permalink simples).
 *
 * @param string $rota Rota, começando por barra.
 * @return string
 */
function f3b_bancada_rest( string $rota ): string {
	return f3b_bancada_url( '/index.php?rest_route=' . rawurlencode( $rota ) );
}

/**
 * GET na bancada, SEM seguir redirecionamento.
 *
 * Não seguir é deliberado: o passo do redirect precisa CONTAR os saltos, e um
 * cliente que segue sozinho devolveria "deu certo" para um laço infinito depois
 * de bater no limite interno dele.
 *
 * @param string $caminho Caminho.
 * @return array{codigo:int,corpo:string,cabecalhos:array<string,string>}
 */
function f3b_bancada_get( string $caminho ): array {
	$r = wp_remote_get(
		f3b_bancada_url( $caminho ),
		array(
			'timeout'     => 20,
			'redirection' => 0,
			'sslverify'   => false,
		)
	);

	if ( is_wp_error( $r ) ) {
		return array(
			'codigo'     => 0,
			'corpo'      => 'erro de transporte: ' . $r->get_error_message(),
			'cabecalhos' => array(),
		);
	}

	$cabecalhos = array();

	foreach ( wp_remote_retrieve_headers( $r )->getAll() as $nome => $valor ) {
		$cabecalhos[ strtolower( (string) $nome ) ] = is_array( $valor ) ? implode( ', ', $valor ) : (string) $valor;
	}

	return array(
		'codigo'     => (int) wp_remote_retrieve_response_code( $r ),
		'corpo'      => (string) wp_remote_retrieve_body( $r ),
		'cabecalhos' => $cabecalhos,
	);
}

/**
 * POST de JSON na bancada.
 *
 * @param string              $url   Endereço completo.
 * @param array<string,mixed> $corpo Corpo a serializar.
 * @return array{codigo:int,corpo:string,json:array<string,mixed>}
 */
function f3b_bancada_post( string $url, array $corpo ): array {
	$r = wp_remote_post(
		$url,
		array(
			'timeout'     => 20,
			'redirection' => 0,
			'sslverify'   => false,
			'headers'     => array( 'Content-Type' => 'application/json' ),
			'body'        => (string) wp_json_encode( $corpo ),
		)
	);

	if ( is_wp_error( $r ) ) {
		return array(
			'codigo' => 0,
			'corpo'  => 'erro de transporte: ' . $r->get_error_message(),
			'json'   => array(),
		);
	}

	$texto = (string) wp_remote_retrieve_body( $r );
	$json  = json_decode( $texto, true );

	return array(
		'codigo' => (int) wp_remote_retrieve_response_code( $r ),
		'corpo'  => $texto,
		'json'   => is_array( $json ) ? $json : array(),
	);
}

/**
 * Apelido de visitante novo — trinta e dois hexadecimais, como o cliente emite.
 *
 * @param string $semente Semente que identifica o passo.
 * @return string
 */
function f3b_bancada_apelido( string $semente ): string {
	return substr( hash( 'sha256', $semente . '|' . microtime( true ) . '|' . wp_rand( 0, PHP_INT_MAX ) ), 0, 32 );
}

/**
 * Lote de comportamento, no formato que o cliente entregue despacha.
 *
 * @param string                          $apelido  Apelido do visitante.
 * @param array<int,array<string,mixed>>  $metricas Totais agregados.
 * @return array<string,mixed>
 */
function f3b_bancada_lote( string $apelido, array $metricas ): array {
	return array(
		'token'     => F3Base_Modulo_Endpoint_Leads::emitir_token(),
		'caminho'   => '/',
		'visitante' => $apelido,
		'sessao'    => f3b_bancada_apelido( 'sessao' ),
		'lote'      => f3b_bancada_apelido( 'lote' ),
		'origem'    => time() * 1000,
		'cortados'  => 0,
		'metricas'  => $metricas,
		'eventos'   => array(
			array(
				'gatilho'    => 'rolagem',
				'detalhe'    => '50',
				'valor'      => 0,
				'ocorrencia' => 2,
				'ms'         => 9000,
			),
		),
	);
}

/**
 * Quantas linhas o registro detalhado guarda para um apelido.
 *
 * A consulta é direta porque a tabela é do plugin e a pergunta é do medidor:
 * "o que ficou gravado?". Nenhuma função do plugin responde isso sem passar
 * pela agregação, que é justamente o que o passo não quer medir.
 *
 * @param string $apelido Apelido do visitante.
 * @return int
 */
function f3b_bancada_linhas_do_apelido( string $apelido ): int {
	global $wpdb;

	$tabela = $wpdb->prefix . 'f3base_eventos';

	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- nome de tabela do próprio plugin.
	return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . $tabela . ' WHERE visitante = %s', $apelido ) );
}

/**
 * As tabelas do banco cujo nome carrega a marca do plugin.
 *
 * @return array<int,string>
 */
function f3b_bancada_tabelas(): array {
	global $wpdb;

	$nomes = $wpdb->get_col( "SELECT name FROM sqlite_master WHERE type = 'table' AND name LIKE '%f3base%'" );

	if ( ! is_array( $nomes ) || array() === $nomes ) {
		$nomes = $wpdb->get_col( "SHOW TABLES LIKE '%f3base%'" );
	}

	return is_array( $nomes ) ? array_map( 'strval', $nomes ) : array();
}

/**
 * Linhas de diagnóstico do PHP no log, restritas às que falam deste plugin.
 *
 * @param string $texto Conteúdo do log.
 * @return array<int,string>
 */
function f3b_bancada_linhas_de_erro( string $texto ): array {
	$saida = array();

	foreach ( preg_split( '/\R/', $texto ) ?: array() as $linha ) {
		$linha = trim( (string) $linha );

		if ( '' === $linha ) {
			continue;
		}

		if ( 1 !== preg_match( '/(Notice|Warning|Deprecated|Fatal error|Parse error|Uncaught|called incorrectly|doing_it_wrong)/i', $linha ) ) {
			continue;
		}

		if ( 1 !== preg_match( '/(base-site-core-fator3|f3base|F3Base)/', $linha ) ) {
			continue;
		}

		$saida[] = mb_substr( $linha, 0, 300 );
	}

	return $saida;
}

/**
 * Recorta uma lista para caber na linha sem esconder o total.
 *
 * @param array<int,string> $itens  Itens.
 * @param int               $limite Quantos mostrar.
 * @return string
 */
function f3b_bancada_amostra( array $itens, int $limite = 3 ): string {
	$total = count( $itens );
	$texto = implode( ' | ', array_slice( $itens, 0, $limite ) );

	if ( $total > $limite ) {
		$texto .= sprintf( ' (+%d)', $total - $limite );
	}

	return $texto;
}

/**
 * O CONTRATO DE CADA PASSO, escrito: o teto que ele exige e o piso que ele sabe
 * acusar.
 *
 * Existe como dado, e não só como prosa nos docblocks, porque é ele que
 * `estatica.piso_em_sonda_declarado` confere: a declaração de que o piso desta
 * sonda mora dentro dela só vale quando a sonda traz, para cada checagem
 * declarada, um ramo de teto e um ramo de piso escritos. Sonda cega não os
 * teria, e é isso que separa uma declaração honesta de uma linha de tabela.
 *
 * @return array<string,array<string,string>> Nome da checagem => teto e piso.
 */
function f3b_bancada_contrato(): array {
	return array(
		'wp.configuracao_confirmada' => array( 'teto' => 'Procedência confirmada e revisão atômica; a recusa preserva origem.', 'piso' => 'Mutante reintroduz perda ou comportamento indevido.' ),
		'wp.capi_fila_persistente' => array( 'teto' => 'Conversão preservada entre falhas com retentativas e reservas.', 'piso' => 'Mutante reintroduz perda ou comportamento indevido.' ),
		'wp.cache_incremental' => array( 'teto' => 'Cache reutiliza leitura e invalida publicação privada.', 'piso' => 'Mutante reintroduz perda ou comportamento indevido.' ),
		'wp.vitais_percentil' => array( 'teto' => 'Última amostra única e percentil real por página e tela.', 'piso' => 'Mutante reintroduz perda ou comportamento indevido.' ),
		'wp.whatsapp_flutuante' => array( 'teto' => 'Botões do tema preservados e ícone optativo em navegador real.', 'piso' => 'Mutante reintroduz perda ou comportamento indevido.' ),

		'wp.interface_configuracoes' => array( 'teto' => 'Interface e medição conferidas no WordPress real.', 'piso' => 'Ignora a aba técnica e sempre apresenta o formulário.' ),
		'wp.medicao_intervalos' => array( 'teto' => 'Interface e medição conferidas no WordPress real.', 'piso' => 'Mistura visitantes que compartilham o mesmo identificador de visita.' ),
		'wp.medicao_orcamentos' => array( 'teto' => 'Interface e medição conferidas no WordPress real.', 'piso' => 'Mantém o teto anterior e corta o lote ampliado.' ),
		'wp.robots_entrega' => array( 'teto' => 'Entrega HTTP confirma rota virtual ou arquivo gerenciado com filtros tardios e restauração exata.', 'piso' => 'Regressão isolada reintroduzida por patch.' ),
		'wp.robots_entrega_falhas' => array( 'teto' => 'Falhas de entrega, jobs antigos e publicações interrompidas preservam arquivos e diagnóstico.', 'piso' => 'Regressão isolada reintroduzida por patch.' ),
		'wp.robots_troca' => array( 'teto' => 'Troca do robots físico pelo formulário e restauração exata sem sobrescrever terceiros.', 'piso' => 'Regressão isolada reintroduzida por patch.' ),
		'wp.robots_falhas' => array( 'teto' => 'Falhas e interrupções da troca preservam original e backup.', 'piso' => 'Regressão isolada reintroduzida por patch.' ),
		'wp.robots_ciclo' => array( 'teto' => 'Concorrência, desativação e reativação preservam o ciclo do robots.', 'piso' => 'Regressão isolada reintroduzida por patch.' ),
		'wp.llms_full_estruturado' => array( 'teto' => 'Full preserva conteúdo integral e estrutura com as regras públicas do índice.', 'piso' => 'Regressão isolada reintroduzida por patch.' ),
		'wp.publicacao_llms' => array( 'teto' => 'Índice Markdown válido e seleção pública segura também na curadoria.', 'piso' => 'Regressão isolada reintroduzida por patch.' ),
		'wp.publicacao_markdown' => array( 'teto' => 'Alternativas Markdown e descoberta com exclusões e HTTP corretos.', 'piso' => 'Regressão isolada reintroduzida por patch.' ),
		'wp.publicacao_robots' => array( 'teto' => 'Robots virtual com sitemap real e preservação de regras e arquivos físicos.', 'piso' => 'Regressão isolada reintroduzida por patch.' ),
		'wp.acessos_somados' => array( 'teto' => 'acessos somados conferido no WordPress real.', 'piso' => 'Regressões de acessos somados plantadas por patches individuais.' ),
		'wp.acessos_dia_substituido' => array( 'teto' => 'acessos dia substituido conferido no WordPress real.', 'piso' => 'Regressões de acessos dia substituido plantadas por patches individuais.' ),
		'wp.acessos_sem_log_degradado' => array( 'teto' => 'acessos sem log degradado conferido no WordPress real.', 'piso' => 'Regressões de acessos sem log degradado plantadas por patches individuais.' ),
		'wp.acessos_formato_desconhecido' => array( 'teto' => 'acessos formato desconhecido conferido no WordPress real.', 'piso' => 'Regressões de acessos formato desconhecido plantadas por patches individuais.' ),
		'wp.acessos_limites' => array( 'teto' => 'acessos limites conferido no WordPress real.', 'piso' => 'Regressões de acessos limites plantadas por patches individuais.' ),
		'wp.acessos_atualizacao_sem_reativar' => array( 'teto' => 'acessos atualizacao sem reativar conferido no WordPress real.', 'piso' => 'Regressões de acessos atualizacao sem reativar plantadas por patches individuais.' ),
		'wp.acessos_lidos_pela_habilidade' => array( 'teto' => 'acessos lidos pela habilidade conferido no WordPress real.', 'piso' => 'Regressões de acessos lidos pela habilidade plantadas por patches individuais.' ),
		'wp.configuracao_independente' => array( 'teto' => 'Configuração acessível sem implantador e sem Flamingo.', 'piso' => 'Reintroduz o defeito e exige falha no mesmo roteiro.' ),
		'wp.acessos_atuais' => array( 'teto' => 'Hoje parcial sem persistência, filtros e ranking combinados.', 'piso' => 'Regressão isolada reintroduzida por patch.' ),
		'wp.acessos_filtro_conteudo' => array( 'teto' => 'Conteúdo real e descoberta filtrados antes do ranking; Mostrar todos restaura caminhos sem alterar coleta.', 'piso' => 'Omitir o filtro na consulta histórica deixa caminhos desconhecidos ocuparem o ranking.' ),
		'wp.acessos_cron_diario' => array( 'teto' => 'Coleta diária executada somente sobre logs datados anteriores.', 'piso' => 'Regressão isolada reintroduzida por patch.' ),
		'wp.home_generico' => array( 'teto' => 'Logs resolvidos sem HOME ou POSIX, com ambiguidade recusada.', 'piso' => 'Remove a busca nos ascendentes ou a recusa de ambiguidade.' ),
		'wp.log_sem_www' => array( 'teto' => 'Diretório de log sem alias www e migração do padrão salvo.', 'piso' => 'Reintroduz o defeito e exige falha no mesmo roteiro.' ),
		'wp.tela_acessos_por_pagina' => array( 'teto' => 'tela acessos por pagina conferido no WordPress real.', 'piso' => 'Regressões de tela acessos por pagina plantadas por patches individuais.' ),
		'wp.sessao_dura_o_declarado' => array( 'teto' => 'sessao dura o declarado conferido no WordPress real.', 'piso' => 'Regressões de sessao dura o declarado plantadas por patches individuais.' ),
		'wp.sessao_diz_quem_venceu' => array( 'teto' => 'sessao diz quem venceu conferido no WordPress real.', 'piso' => 'Regressões de sessao diz quem venceu plantadas por patches individuais.' ),
		'wp.llms_indice_aponta_texto_integral' => array( 'teto' => 'llms indice aponta texto integral conferido no WordPress real.', 'piso' => 'Regressões de llms indice aponta texto integral plantadas por patches individuais.' ),
		'wp.ativacao_sem_aviso'         => array(
			'teto' => 'ativar o plugin a partir do zip não escreve Notice, Warning, Deprecated nem Fatal no debug.log',
			'piso' => 'um trigger_error plantado no caminho da ativação sai no log e é acusado',
		),
		'wp.home_servida'               => array(
			'teto' => 'a home responde 200 com f3base-consentimento, f3base-tracking e data-f3base-consentimento, e com os cabeçalhos de segurança do módulo',
			'piso' => 'um cabeçalho de segurança retirado da lista emitida é acusado pelo nome',
		),
		'wp.habilidades_registradas'    => array(
			'teto' => 'as quatro habilidades existem no registro do núcleo, sob a categoria própria do plugin, e como-usar executa como administrador devolvendo o slug do plugin',
			'piso' => 'gancho sem o prefixo wp_ e category ausente deixam as três fora do registro, e a execução sem usuário nenhum tem de ser recusada — cada um dos três é acusado pelo seu nome',
		),
		'wp.habilidades_de_config_executam' => array(
			'teto' => 'config-ler e config-escrever atravessam a validação de entrada do núcleo com a entrada que o próprio schema pede, recusam sem usuário e respondem estruturado; como-usar recusa pelo schema o campo que não declara',
			'piso' => 'properties moldado como objeto PHP nos três schemas de entrada derruba a chamada em Error antes do callback, e cada habilidade é acusada pelo seu nome com o erro do núcleo',
		),
		'wp.lote_sem_metricas_gravado'  => array(
			'teto' => 'lote com eventos e metricas vazia responde 201 e grava o registro detalhado',
			'piso' => 'responder 200 sem gravar é acusado com o código e com a contagem de linhas',
		),
		'wp.esquecer_apaga_sem_oraculo' => array(
			'teto' => 'as linhas do apelido somem e a resposta não conta o que apagou',
			'piso' => 'linha remanescente ou contagem devolvida é acusada, cada uma pelo seu nome',
		),
		'wp.llms_full_responde'         => array(
			'teto' => 'com a chave full ligada, /llms-full.txt responde 200 com o texto da página publicada',
			'piso' => 'resposta fora de 200, ou 200 sem o texto, é acusada',
		),
		'wp.redirect_nao_gira'          => array(
			'teto' => 'ou o sanitizador recusa o par que difere só pela barra, ou o endereço para de saltar',
			'piso' => 'quatro respostas seguidas em 3xx são acusadas com os saltos listados',
		),
		'wp.cron_na_ativacao'           => array(
			'teto' => 'a ativação num processo em que o plugin nasce inativo agenda a cadência e a limpeza de retenção',
			'piso' => 'agendamento que devolve falso é acusado junto com as periodicidades conhecidas naquele processo',
		),
		'wp.token_capi_mascarado'       => array(
			'teto' => 'o token gravado não aparece no HTML da tela nem no JSON do relatório',
			'piso' => 'o valor em claro em qualquer um dos dois é acusado, dizendo em qual',
		),
		'wp.debug_log_limpo'            => array(
			'teto' => 'a operação normal do site não escreve linha de PHP do plugin no debug.log',
			'piso' => 'um trigger_error no carregamento da página é acusado com a linha do log',
		),
		'wp.desinstalacao_limpa'        => array(
			'teto' => 'uninstall.php roda sem fatal e não deixa tabela com a marca do plugin nem as options declaradas',
			'piso' => 'fatal capturado, tabela remanescente e option sobrevivente são acusados, cada um pelo nome',
		),
		'wp.llms_nao_publica_protegido' => array(
			'teto' => 'a página publicada com senha fica fora do índice curto e do texto integral',
			'piso' => 'o título no /llms.txt ou o corpo no /llms-full.txt são acusados, cada um pelo seu nome',
		),
		'wp.redirect_410_termina'       => array(
			'teto' => 'o par declarado com 410 termina a requisição com corpo mínimo de texto puro',
			'piso' => 'status diferente de 410, ou a página renderizada no corpo, é acusado com o tamanho em bytes',
		),
		'wp.retencao_sem_lixeira'       => array(
			'teto' => 'sem lixeira a rota elimina em definitivo e diz isso: 200 com reversivel false e sem reversivel_ate, registro fora do banco, journal com a janela zerada e o motivo, e o módulo ativo nomeando EMPTY_TRASH_DAYS',
			'piso' => 'reversivel true sem lixeira, recusa que não elimina nada, journal sem a entrada definitiva e módulo degradado são acusados, cada um pelo nome',
		),
		'wp.retencao_definitiva_no_journal' => array(
			'teto' => 'a eliminação definitiva em lote deixa entrada no journal com contagem e reversivel_ate zerado',
			'piso' => 'journal sem a entrada, contagem zerada ou janela prometida sobre o que já foi apagado são acusados',
		),
		'wp.retencao_declara_o_backlog' => array(
			'teto' => 'o carimbo da limpeza registra os restantes e o módulo degrada enquanto houver fila',
			'piso' => 'carimbo sem restantes, restantes zerado com fila no banco ou módulo ativo com backlog são acusados',
		),
		'wp.privacidade_pagina_o_titular' => array(
			'teto' => 'exportador e eraser paginam e só devolvem done na página incompleta',
			'piso' => 'página cheia declarada como fim, contagem errada por página e registro do titular remanescente são acusados',
		),
	);
}

/* =========================================================================
 * OS PASSOS. Um por função, e cada função devolve estado e mensagem.
 * ====================================================================== */

/**
 * TETO: a ativação não escreve diagnóstico do PHP no log.
 * PISO: um `trigger_error` plantado na ativação sai no log e o passo o acusa.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_ativacao_sem_aviso(): array {
	$arquivo = (string) getenv( 'F3BASE_BANCADA_TMP' ) . '/ativacao.log';

	if ( ! is_file( $arquivo ) ) {
		return array( 'BLOCKED', 'a ativação não pôde ser lida. Recurso ausente: o retrato do debug.log tirado logo depois de `wp plugin install --activate`.' );
	}

	$linhas = f3b_bancada_linhas_de_erro( (string) file_get_contents( $arquivo ) );

	if ( array() === $linhas ) {
		return array( 'OK', 'a ativação do plugin a partir do zip não escreveu Notice, Warning, Deprecated nem Fatal no debug.log com WP_DEBUG_LOG ligado.' );
	}

	return array( 'FALHA', 'a ativação sujou o debug.log com ' . count( $linhas ) . ' linha(s) de diagnóstico do PHP: ' . f3b_bancada_amostra( $linhas ) . '.' );
}

/**
 * TETO: a home responde 200 com o consentimento, o tracking e os cabeçalhos.
 * PISO: sem o enfileiramento do consentimento, o passo acusa a marca ausente.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_home_servida(): array {
	$r = f3b_bancada_get( '/' );

	if ( 0 === $r['codigo'] ) {
		return array( 'BLOCKED', 'a home não pôde ser buscada. Recurso ausente: servidor HTTP embutido respondendo — ' . $r['corpo'] . '.' );
	}

	$faltam = array();

	if ( 200 !== $r['codigo'] ) {
		$faltam[] = 'a home devolveu ' . $r['codigo'] . ' e não 200';
	}

	foreach ( array( 'f3base-consentimento', 'f3base-tracking', 'data-f3base-consentimento' ) as $marca ) {
		if ( ! str_contains( $r['corpo'], $marca ) ) {
			$faltam[] = 'a marca ' . $marca . ' não está no HTML servido';
		}
	}

	$cabecalhos = array( 'x-content-type-options', 'x-frame-options', 'referrer-policy', 'cross-origin-opener-policy' );

	foreach ( $cabecalhos as $cabecalho ) {
		if ( ! isset( $r['cabecalhos'][ $cabecalho ] ) ) {
			$faltam[] = 'o cabeçalho ' . $cabecalho . ' não foi emitido';
		}
	}

	if ( array() === $faltam ) {
		return array( 'OK', 'a home respondeu 200 carregando f3base-consentimento, f3base-tracking e data-f3base-consentimento, com os quatro cabeçalhos de segurança do módulo emitidos pelo servidor real.' );
	}

	return array( 'FALHA', 'a home servida por um WordPress real não entrega o que o módulo promete: ' . f3b_bancada_amostra( $faltam, 5 ) . '.' );
}

/**
 * TETO: as quatro habilidades existem e `como-usar` devolve o slug do plugin.
 * PISO: o gancho sem prefixo e a `category` ausente as deixam fora do registro.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_habilidades_registradas(): array {
	if ( ! function_exists( 'wp_has_ability' ) || ! function_exists( 'wp_get_ability' ) ) {
		return array( 'BLOCKED', 'as habilidades não puderam ser consultadas. Recurso ausente: a Abilities API do núcleo (wp_has_ability/wp_get_ability).' );
	}

	$esperadas = array( 'f3base/como-usar', 'f3base/config-ler', 'f3base/config-escrever', 'f3base/acessos-ler' );
	$ausentes  = array();

	foreach ( $esperadas as $nome ) {
		if ( ! wp_has_ability( $nome ) ) {
			$ausentes[] = $nome;
		}
	}

	if ( array() !== $ausentes ) {
		return array(
			'FALHA',
			'o núcleo não conhece ' . count( $ausentes ) . ' das ' . count( $esperadas ) . ' habilidades que o plugin promete registrar: '
				. implode( ', ', $ausentes ) . '. Num WordPress real elas não existem, e o caminho documentado para um agente ler e gravar a configuração do site não está no ar.',
		);
	}

	$habilidade = wp_get_ability( 'f3base/como-usar' );

	if ( ! is_object( $habilidade ) || ! method_exists( $habilidade, 'execute' ) ) {
		return array( 'FALHA', 'f3base/como-usar está no registro mas não é executável: o núcleo devolveu ' . gettype( $habilidade ) . '.' );
	}

	/*
	 * O PORTÃO É MEDIDO ANTES DA EXECUÇÃO, e ele é metade do que esta linha
	 * prova. As três habilidades leem e ESCREVEM a configuração do site; sem
	 * usuário nenhum, o `permission_callback` tem de recusar. Uma habilidade que
	 * executa para qualquer um é pior que uma que não existe.
	 */
	wp_set_current_user( 0 );

	if ( ! is_wp_error( $habilidade->execute( array() ) ) ) {
		return array( 'FALHA', 'f3base/como-usar executou SEM usuário nenhum: o permission_callback dela não barra quem não tem manage_options, e as três habilidades leem e escrevem a configuração do site.' );
	}

	/* A execução acontece como ADMINISTRADOR, que é quem o portão autoriza. */
	wp_set_current_user( 1 );

	$resultado = $habilidade->execute( array() );

	if ( is_wp_error( $resultado ) ) {
		return array( 'FALHA', 'f3base/como-usar existe e falhou ao executar como administrador: ' . $resultado->get_error_message() . '.' );
	}

	$plugin = is_array( $resultado ) ? (string) ( $resultado['plugin'] ?? '' ) : '';

	if ( 'base-site-core-fator3' !== $plugin ) {
		return array( 'FALHA', 'f3base/como-usar executou e não se identificou: devolveu plugin = "' . $plugin . '" em vez de base-site-core-fator3.' );
	}

	/*
	 * A CATEGORIA É PARTE DO QUE FALTAVA, e ela é medida pelo nome: o núcleo
	 * recusa habilidade cuja `category` não esteja registrada, e as três nasciam
	 * sem nenhuma. Ler a categoria de volta do registro prova que ela existe E
	 * que é a do plugin, e não uma gaveta genérica ao lado das do núcleo.
	 */
	$categoria = method_exists( $habilidade, 'get_category' ) ? $habilidade->get_category() : null;
	$categoria = is_object( $categoria ) && method_exists( $categoria, 'get_name' ) ? (string) $categoria->get_name() : (string) $categoria;

	if ( '' !== $categoria && 'f3base' !== $categoria ) {
		return array( 'FALHA', 'f3base/como-usar está registrada sob a categoria "' . $categoria . '", e não sob a categoria própria do plugin: um agente que procure por onde mudar a medição deste site não a encontra entre as do núcleo.' );
	}

	return array( 'OK', 'as quatro habilidades existem no registro do núcleo real, sob a categoria própria do plugin, recusam quem não tem manage_options, e f3base/como-usar executa como administrador devolvendo plugin = base-site-core-fator3.' );
}

/**
 * TETO: lote com eventos e `metricas` vazia grava o registro detalhado.
 * PISO: o produto responde 200 e descarta o lote, e o cliente o apaga.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_lote_sem_metricas_gravado(): array {
	if ( ! class_exists( 'F3Base_Modulo_Endpoint_Leads' ) ) {
		return array( 'BLOCKED', 'o lote não pôde ser enviado. Recurso ausente: F3Base_Modulo_Endpoint_Leads carregada — o plugin não está ativo nesta bancada.' );
	}

	$apelido = f3b_bancada_apelido( 'lote-sem-metricas' );
	$antes   = f3b_bancada_linhas_do_apelido( $apelido );

	$r = f3b_bancada_post( f3b_bancada_rest( '/f3base/v1/comportamento' ), f3b_bancada_lote( $apelido, array() ) );

	if ( 0 === $r['codigo'] ) {
		return array( 'BLOCKED', 'o lote não pôde ser enviado. Recurso ausente: servidor HTTP embutido respondendo — ' . $r['corpo'] . '.' );
	}

	$depois  = f3b_bancada_linhas_do_apelido( $apelido );
	$gravou  = $depois - $antes;
	$achados = array();

	if ( 201 !== $r['codigo'] ) {
		$achados[] = 'a rota respondeu ' . $r['codigo'] . ' e não 201';
	}

	if ( $gravou < 1 ) {
		$achados[] = 'nada foi gravado em ' . $GLOBALS['wpdb']->prefix . 'f3base_eventos para o apelido do lote';
	}

	if ( array() === $achados ) {
		return array( 'OK', 'lote com eventos e metricas vazia respondeu 201 e gravou ' . $gravou . ' linha(s) no registro detalhado — a segunda partição de um carregamento não é descartada.' );
	}

	return array(
		'FALHA',
		'lote com eventos e metricas vazia — o que o cliente despacha em toda partição depois da primeira — não sobreviveu: '
			. implode( '; ', $achados ) . '. O corpo devolvido foi ' . mb_substr( $r['corpo'], 0, 160 )
			. '. Com 2xx o cliente apaga o lote, e as ocorrências que a série existe para medir somem sem erro nenhum.',
	);
}

/**
 * TETO: `esquecer` apaga as linhas do apelido e não conta o que apagou.
 * PISO: a resposta devolve `linhas`, que é o oráculo de existência que o
 *       próprio comentário do módulo diz evitar.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_esquecer_apaga_sem_oraculo(): array {
	if ( ! class_exists( 'F3Base_Modulo_Endpoint_Leads' ) ) {
		return array( 'BLOCKED', 'o apagamento não pôde ser exercitado. Recurso ausente: F3Base_Modulo_Endpoint_Leads carregada.' );
	}

	$apelido = f3b_bancada_apelido( 'esquecer' );
	$metrica = array(
		array(
			'gatilho'  => 'rolagem',
			'detalhe'  => '50',
			'contagem' => 1,
			'soma'     => 0,
		),
	);

	$gravacao = f3b_bancada_post( f3b_bancada_rest( '/f3base/v1/comportamento' ), f3b_bancada_lote( $apelido, $metrica ) );

	if ( 0 === $gravacao['codigo'] ) {
		return array( 'BLOCKED', 'o lote de partida não pôde ser gravado. Recurso ausente: servidor HTTP embutido respondendo — ' . $gravacao['corpo'] . '.' );
	}

	$plantadas = f3b_bancada_linhas_do_apelido( $apelido );

	if ( $plantadas < 1 ) {
		return array( 'BLOCKED', 'o apagamento não pôde ser medido: o lote válido de partida não gravou linha nenhuma (a rota respondeu ' . $gravacao['codigo'] . '), e apagar o que não existe não prova nada.' );
	}

	$r = f3b_bancada_post(
		f3b_bancada_rest( '/f3base/v1/comportamento/esquecer' ),
		array(
			'token'     => F3Base_Modulo_Endpoint_Leads::emitir_token(),
			'visitante' => $apelido,
		)
	);

	$restantes = f3b_bancada_linhas_do_apelido( $apelido );
	$achados   = array();

	if ( $restantes > 0 ) {
		$achados[] = $restantes . ' linha(s) do apelido continuam no registro detalhado depois do pedido de apagamento';
	}

	if ( array_key_exists( 'linhas', $r['json'] ) ) {
		$achados[] = 'a resposta devolveu linhas = ' . (string) $r['json']['linhas'] . ', que é um oráculo de existência: quem tem o apelido descobre pela contagem se aquele visitante existia';
	}

	if ( array() === $achados ) {
		return array( 'OK', 'as ' . $plantadas . ' linha(s) do apelido foram apagadas e a resposta não conta o que apagou — sem oráculo de existência.' );
	}

	return array( 'FALHA', 'o apagamento por apelido não cumpre as duas metades do que promete: ' . implode( '; ', $achados ) . '. Corpo: ' . mb_substr( $r['corpo'], 0, 160 ) . '.' );
}

/**
 * TETO: com `full` ligado, `/llms-full.txt` responde 200 com o texto da página.
 * PISO: a rota responde 500 assim que é ligada.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_llms_full_responde(): array {
	if ( ! class_exists( 'F3Base_Options' ) ) {
		return array( 'BLOCKED', 'a rota não pôde ser exercitada. Recurso ausente: F3Base_Options carregada.' );
	}

	$marca = 'Texto da bancada com palavras suficientes para o resumo longo do arquivo completo';

	$pagina = wp_insert_post(
		array(
			'post_type'    => 'page',
			'post_title'   => 'Pagina da bancada',
			'post_status'  => 'publish',
			'post_content' => $marca . '. Segundo paragrafo com mais texto para o corpo nao ficar curto.',
		),
		true
	);

	if ( is_wp_error( $pagina ) ) {
		return array( 'BLOCKED', 'a rota não pôde ser exercitada: a página de apoio não foi publicada — ' . $pagina->get_error_message() . '.' );
	}

	$llms         = (array) get_option( 'f3base_llms', array() );
	$llms['full'] = true;

	$gravado = F3Base_Options::gravar( 'f3base_llms', $llms );

	if ( empty( $gravado['ok'] ) ) {
		return array( 'BLOCKED', 'a rota não pôde ser exercitada: f3base_llms.full não pôde ser ligada pelo gravador único.' );
	}

	$r = f3b_bancada_get( '/llms-full.txt' );

	if ( 0 === $r['codigo'] ) {
		return array( 'BLOCKED', 'a rota não pôde ser buscada. Recurso ausente: servidor HTTP embutido respondendo — ' . $r['corpo'] . '.' );
	}

	if ( 200 !== $r['codigo'] ) {
		return array(
			'FALHA',
			'/llms-full.txt respondeu ' . $r['codigo'] . ' com a chave full ligada e uma página publicada com conteúdo. '
				. 'A rota é pública: ligar a chave que a tela oferece derruba o endereço para todo leitor automático.',
		);
	}

	if ( ! str_contains( $r['corpo'], $marca ) ) {
		return array( 'FALHA', '/llms-full.txt respondeu 200 e não trouxe o texto da página publicada — o arquivo completo saiu sem o conteúdo que ele existe para carregar.' );
	}

	return array( 'OK', '/llms-full.txt respondeu 200 com o texto da página publicada, com a chave full ligada pelo gravador único.' );
}

/**
 * TETO: ou o sanitizador recusa o par que gira, ou o endereço para de saltar.
 * PISO: o par `/servicos/ → /servicos` passa e gira para sempre.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_redirect_nao_gira(): array {
	if ( ! class_exists( 'F3Base_Options' ) ) {
		return array( 'BLOCKED', 'o redirect não pôde ser exercitado. Recurso ausente: F3Base_Options carregada.' );
	}

	$par = array(
		'de'     => '/servicos/',
		'para'   => '/servicos',
		'status' => 301,
	);

	F3Base_Options::gravar( 'f3base_redirects', array( $par ) );

	$gravado = (array) get_option( 'f3base_redirects', array() );
	$aceito  = false;

	foreach ( $gravado as $regra ) {
		if ( is_array( $regra ) && '/servicos/' === ( $regra['de'] ?? '' ) && '/servicos' === ( $regra['para'] ?? '' ) ) {
			$aceito = true;
		}
	}

	if ( ! $aceito ) {
		return array( 'OK', 'o sanitizador recusou o par que difere só pela barra final: ele não chegou a ser gravado, e o laço não pode existir.' );
	}

	$caminho = '/servicos/';
	$saltos  = array();

	for ( $n = 0; $n < 4; $n++ ) {
		$r = f3b_bancada_get( $caminho );

		if ( 0 === $r['codigo'] ) {
			return array( 'BLOCKED', 'os saltos não puderam ser contados. Recurso ausente: servidor HTTP embutido respondendo — ' . $r['corpo'] . '.' );
		}

		if ( $r['codigo'] < 300 || $r['codigo'] > 399 ) {
			return array( 'OK', 'o par foi aceito pelo sanitizador e o endereço para de saltar: depois de ' . count( $saltos ) . ' salto(s) a resposta foi ' . $r['codigo'] . '.' );
		}

		$destino  = (string) ( $r['cabecalhos']['location'] ?? '' );
		$saltos[] = $r['codigo'] . ' → ' . $destino;
		$rota     = (string) parse_url( $destino, PHP_URL_PATH );
		$caminho  = '' === $rota ? $caminho : $rota;
	}

	return array(
		'FALHA',
		'o sanitizador aceitou o par /servicos/ → /servicos e o endereço gira: ' . f3b_bancada_amostra( $saltos, 4 )
			. '. Quatro respostas seguidas em 3xx é o laço que o navegador do visitante corta com ERR_TOO_MANY_REDIRECTS.',
	);
}

/**
 * TETO: a ativação agenda a cadência declarada e a limpeza de retenção.
 * PISO: a periodicidade própria só é registrada em `init`, que já passou quando
 *       o WordPress ativa o plugin — e o agendamento devolve `false`.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_cron_na_ativacao(): array {
	if ( ! class_exists( 'F3Base_Options' ) ) {
		return array( 'BLOCKED', 'a ativação não pôde ser exercitada. Recurso ausente: F3Base_Options carregada.' );
	}

	$ativador = __DIR__ . '/ativador.php';

	if ( ! is_file( $ativador ) ) {
		return array( 'BLOCKED', 'a ativação não pôde ser exercitada num processo próprio. Recurso ausente: ' . $ativador . '.' );
	}

	$cadencia                  = (array) get_option( 'f3base_cadencia', array() );
	$cadencia['periodicidade'] = 'mensal';

	F3Base_Options::gravar( 'f3base_cadencia', $cadencia );

	$lido = (array) get_option( 'f3base_cadencia', array() );

	if ( 'mensal' !== ( $lido['periodicidade'] ?? '' ) ) {
		return array( 'BLOCKED', 'a ativação não pôde ser exercitada: f3base_cadencia.periodicidade não ficou em mensal depois da gravação.' );
	}

	/*
	 * O ESTADO ANTERIOR É LIMPO ANTES, e isso é o que separa esta medição de uma
	 * que se engana sozinha: com o agendamento de uma ativação anterior ainda no
	 * banco, `wp_next_scheduled()` devolveria um carimbo que ESTA ativação não
	 * produziu, e a linha fecharia OK sobre um agendamento que ninguém fez agora.
	 */
	wp_clear_scheduled_hook( 'f3base_cadencia_relatorio' );
	wp_clear_scheduled_hook( 'f3base_retencao_limpeza' );

	if ( ! function_exists( 'deactivate_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	deactivate_plugins( 'base-site-core-fator3/base-site-core-fator3.php' );

	/*
	 * O PROCESSO NOVO É O PONTO DO PASSO. Com o plugin INATIVO no arranque, o
	 * núcleo carrega sem ele, `init` dispara sem ele, e só então a ativação
	 * acontece — que é exatamente a ordem de um site real. Reativar dentro DESTE
	 * processo mediria outra coisa: o filtro de periodicidades já estaria
	 * registrado pelo carregamento anterior e o agendamento passaria.
	 */
	$comando = escapeshellarg( PHP_BINARY ) . ' ' . escapeshellarg( $ativador ) . ' 2>/dev/null';

	$bruto = (string) shell_exec( $comando );
	$json  = json_decode( trim( $bruto ), true );

	if ( ! is_array( $json ) ) {
		return array( 'BLOCKED', 'a ativação num processo novo não devolveu veredito analisável. Recurso ausente: wp-cli operante sobre a bancada — saída: ' . mb_substr( $bruto, 0, 200 ) . '.' );
	}

	$achados = array();

	if ( '' !== (string) $json['erro'] ) {
		$achados[] = 'a ativação devolveu erro: ' . (string) $json['erro'];
	}

	if ( empty( $json['cadencia'] ) ) {
		$achados[] = 'f3base_cadencia_relatorio NÃO ficou agendado no processo da ativação, com periodicidade mensal gravada (as periodicidades conhecidas ali eram '
			. implode( ', ', array_map( 'strval', (array) $json['periodicidades'] ) ) . ')';
	}

	if ( empty( $json['acessos'] ) ) { $achados[] = 'f3base_acessos_somar não foi agendado na ativação.'; }

	if ( empty( $json['retencao'] ) ) {
		$achados[] = 'f3base_retencao_limpeza NÃO ficou agendado no processo da ativação';
	}

	if ( array() === $achados ) {
		return array( 'OK', 'a ativação num processo novo, com o plugin inativo no arranque, agendou f3base_cadencia_relatorio e f3base_retencao_limpeza no MESMO processo.' );
	}

	return array(
		'FALHA',
		'a ativação como o WordPress a executa — plugin inativo no arranque, `init` já disparado — não agenda o que promete: ' . implode( '; ', $achados )
			. '. O site fica com a cadência gravada e sem evento no cron até que alguma requisição posterior conserte por acaso.',
	);
}

/**
 * TETO: o token da Conversions API não aparece na tela nem no relatório.
 * PISO: ele é declarado como campo de texto e a máscara só cobre `segredo`.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_token_capi_mascarado(): array {
	if ( ! class_exists( 'F3Base_Options' ) || ! class_exists( 'F3Base_Registro' ) || ! class_exists( 'F3Base_Admin_Tela' ) ) {
		return array( 'BLOCKED', 'a máscara não pôde ser medida. Recurso ausente: F3Base_Options, F3Base_Registro e F3Base_Admin_Tela carregadas.' );
	}

	$token   = 'EAAG' . str_repeat( 'z', 24 ) . 'TOKENDEEXEMPLO';
	$gravado = F3Base_Options::gravar( 'f3base_meta_capi_token', $token );

	if ( empty( $gravado['ok'] ) ) {
		return array( 'BLOCKED', 'a máscara não pôde ser medida: o token de exemplo não foi aceito pelo gravador único.' );
	}

	$vazamentos = array();

	$relatorio = (string) wp_json_encode( F3Base_Registro::relatorio() );

	if ( str_contains( $relatorio, $token ) ) {
		$vazamentos[] = 'o JSON de F3Base_Registro::relatorio() — servido pela rota de relatório — carrega o valor em claro';
	}

	wp_set_current_user( 1 );

	/*
	 * A TELA É RENDERIZADA COM O QUE O WP-ADMIN CARREGA, e não com um recorte
	 * escolhido aqui: `render()` usa funções de formulário do painel, e faltar
	 * uma delas derrubaria o passo por defeito da bancada — que é o pior jeito
	 * de acusar um vazamento de credencial.
	 */
	if ( ! function_exists( 'submit_button' ) ) {
		require_once ABSPATH . 'wp-admin/includes/admin.php';
	}

	ob_start();
	F3Base_Admin_Tela::render();
	$html = (string) ob_get_clean();

	if ( '' === $html ) {
		return array( 'BLOCKED', 'a máscara não pôde ser medida na tela: F3Base_Admin_Tela::render() não produziu HTML como administrador.' );
	}

	if ( str_contains( $html, $token ) ) {
		$vazamentos[] = 'o HTML da tela renderizada como administrador carrega o valor em claro';
	}

	if ( array() === $vazamentos ) {
		return array( 'OK', 'o token gravado em f3base_meta_capi_token não aparece no HTML da tela nem no JSON do relatório: a máscara alcança os dois.' );
	}

	return array(
		'FALHA',
		'o token da Conversions API gravado aparece em claro: ' . implode( '; ', $vazamentos )
			. '. Quem abre a tela, quem lê o relatório e qualquer captura de tela levam junto a credencial de servidor da Meta.',
	);
}

/**
 * TETO: a operação normal do site não escreve diagnóstico do plugin no log.
 * PISO: um `trigger_error` no caminho da home aparece e é acusado.
 *
 * As chaves que os passos anteriores ligaram DE PROPÓSITO para provocar erro são
 * desligadas antes da varredura: este passo mede o log da operação normal, e não
 * o rastro dos passos que existem para reprovar.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_debug_log_limpo(): array {
	if ( ! class_exists( 'F3Base_Options' ) ) {
		return array( 'BLOCKED', 'o log não pôde ser medido. Recurso ausente: F3Base_Options carregada.' );
	}

	$llms         = (array) get_option( 'f3base_llms', array() );
	$llms['full'] = false;

	F3Base_Options::gravar( 'f3base_llms', $llms );
	F3Base_Options::gravar( 'f3base_redirects', array() );

	$arquivo = WP_CONTENT_DIR . '/debug.log';

	file_put_contents( $arquivo, '' );

	f3b_bancada_get( '/' );
	f3b_bancada_get( '/llms.txt' );
	f3b_bancada_get( '/?p=1' );

	$apelido = f3b_bancada_apelido( 'log-limpo' );
	$metrica = array(
		array(
			'gatilho'  => 'rolagem',
			'detalhe'  => '50',
			'contagem' => 1,
			'soma'     => 0,
		),
	);

	f3b_bancada_post( f3b_bancada_rest( '/f3base/v1/comportamento' ), f3b_bancada_lote( $apelido, $metrica ) );

	$linhas = f3b_bancada_linhas_de_erro( (string) file_get_contents( $arquivo ) );

	if ( array() === $linhas ) {
		return array( 'OK', 'a operação normal — home, llms.txt, um artigo e um lote válido de comportamento — não escreveu nenhuma linha de PHP do plugin no debug.log.' );
	}

	return array( 'FALHA', 'a operação normal escreveu ' . count( $linhas ) . ' linha(s) de PHP do plugin no debug.log: ' . f3b_bancada_amostra( $linhas ) . '.' );
}

/**
 * TETO: `uninstall.php` roda sem fatal e não deixa tabela nem option para trás.
 * PISO: ele morre em fatal por classe não carregada e a tabela do registro
 *       detalhado — a que guarda apelido, sessão e carimbo — sobrevive.
 *
 * A execução acontece FORA deste processo, em `desinstalador.php`, porque é
 * assim que o WordPress a faz: plugin inativo, processo novo, `WP_UNINSTALL_PLUGIN`
 * definida e o arquivo incluído. Este passo lê o que aquele processo produziu e
 * confere o banco depois.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_desinstalacao_limpa(): array {
	$tmp     = (string) getenv( 'F3BASE_BANCADA_TMP' );
	$arquivo = $tmp . '/uninstall.txt';

	if ( ! is_file( $arquivo ) ) {
		return array( 'BLOCKED', 'a desinstalação não pôde ser lida. Recurso ausente: a saída do processo que incluiu uninstall.php com WP_UNINSTALL_PLUGIN definida.' );
	}

	$saida   = (string) file_get_contents( $arquivo );
	$achados = array();

	if ( str_contains( $saida, 'BANCADA-SEM-WORDPRESS' ) || str_contains( $saida, 'BANCADA-SEM-UNINSTALL' ) ) {
		return array( 'BLOCKED', 'a desinstalação não pôde ser executada. Recurso ausente: WordPress carregável e uninstall.php dentro do plugin instalado.' );
	}

	if ( ! str_contains( $saida, 'BANCADA-SEM-FATAL' ) ) {
		$linha_fatal = 'sem marca de encerramento';

		if ( preg_match( '/BANCADA-FATAL: (.+)/', $saida, $m ) ) {
			$linha_fatal = mb_substr( trim( (string) $m[1] ), 0, 260 );
		}

		$achados[] = 'o processo morreu em fatal: ' . $linha_fatal;
	}

	$tabelas = f3b_bancada_tabelas();

	if ( array() !== $tabelas ) {
		$achados[] = count( $tabelas ) . ' tabela(s) com a marca do plugin continuam no banco: ' . implode( ', ', $tabelas );
	}

	$sobreviventes = array();

	foreach ( array( 'f3base_atividade', 'f3base_endpoint_segredo', 'f3base_cadencia_estado', 'f3base_acessos_estado' ) as $option ) {
		if ( false !== get_option( $option, false ) ) {
			$sobreviventes[] = $option;
		}
	}

	if ( array() !== $sobreviventes ) {
		$achados[] = 'options que a desinstalação promete remover continuam gravadas: ' . implode( ', ', $sobreviventes );
	}

	if ( array() === $achados ) {
		return array( 'OK', 'uninstall.php rodou como o WordPress o roda — plugin inativo, processo novo, WP_UNINSTALL_PLUGIN definida — sem fatal, e não sobrou tabela com a marca do plugin nem as options descartáveis declaradas.' );
	}

	return array(
		'FALHA',
		'a desinstalação não limpa o que promete: ' . f3b_bancada_amostra( $achados, 3 )
			. '. Quem apaga o plugin pela tela do WordPress vê o erro crítico e fica com dado pessoal pseudonimizado no banco.',
	);
}


/**
 * Publica um lead de bancada e devolve o id.
 *
 * O tipo sai da constante do módulo, nunca de literal: quem decide qual é a
 * caixa de leads é o plugin, e escrever o nome aqui faria este roteiro medir
 * outro tipo no dia em que ele mudasse.
 *
 * @param string              $titulo Título do registro.
 * @param array<string,mixed> $extra  Campos extras de `wp_insert_post`.
 * @return int Identificador, ou 0 quando não foi possível publicar.
 */
function f3b_bancada_lead( string $titulo, array $extra = array() ): int {
	$id = wp_insert_post(
		array_merge(
			array(
				'post_type'    => F3Base_Modulo_Endpoint_Leads::CPT,
				'post_title'   => $titulo,
				'post_status'  => 'publish',
				'post_content' => 'Registro de bancada.',
			),
			$extra
		),
		true
	);

	return is_wp_error( $id ) ? 0 : (int) $id;
}

/**
 * Apaga em definitivo todo lead da bancada, para o passo medir o que ele criou.
 *
 * @return void
 */
function f3b_bancada_limpar_leads(): void {
	$ids = get_posts(
		array(
			'post_type'   => F3Base_Modulo_Endpoint_Leads::CPT,
			'post_status' => 'any',
			'numberposts' => 500,
			'fields'      => 'ids',
		)
	);

	foreach ( is_array( $ids ) ? $ids : array() as $id ) {
		wp_delete_post( (int) $id, true );
	}
}

/**
 * TETO: página protegida por senha não entra em nenhum dos dois arquivos.
 * PISO: `publish` inclui o conteúdo protegido, e o corpo dele sai em texto puro
 *       no `/llms-full.txt` — a senha que alguém pôs na página é contornada por
 *       um arquivo que este plugin publica.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_llms_nao_publica_protegido(): array {
	if ( ! class_exists( 'F3Base_Options' ) ) {
		return array( 'BLOCKED', 'as rotas não puderam ser exercitadas. Recurso ausente: F3Base_Options carregada.' );
	}

	$marca  = 'Corpo reservado que so quem tem a senha deveria ler';
	$titulo = 'Pagina protegida da bancada';

	$pagina = wp_insert_post(
		array(
			'post_type'     => 'page',
			'post_title'    => $titulo,
			'post_status'   => 'publish',
			'post_password' => 'segredo-da-bancada',
			'post_content'  => $marca . '. Segundo paragrafo do conteudo reservado.',
		),
		true
	);

	if ( is_wp_error( $pagina ) ) {
		return array( 'BLOCKED', 'as rotas não puderam ser exercitadas: a página protegida não foi publicada — ' . $pagina->get_error_message() . '.' );
	}

	$llms           = (array) get_option( 'f3base_llms', array() );
	$llms['ligado'] = true;
	$llms['full']   = true;

	$gravado = F3Base_Options::gravar( 'f3base_llms', $llms );

	if ( empty( $gravado['ok'] ) ) {
		return array( 'BLOCKED', 'as rotas não puderam ser exercitadas: f3base_llms não pôde ser ligada pelo gravador único.' );
	}

	$curto    = f3b_bancada_get( '/llms.txt' );
	$completo = f3b_bancada_get( '/llms-full.txt' );

	foreach ( array( '/llms.txt' => $curto, '/llms-full.txt' => $completo ) as $caminho_medido => $r ) {
		if ( 0 === $r['codigo'] ) {
			return array( 'BLOCKED', $caminho_medido . ' não pôde ser buscado. Recurso ausente: servidor HTTP embutido respondendo — ' . $r['corpo'] . '.' );
		}

		if ( 200 !== $r['codigo'] ) {
			return array( 'BLOCKED', $caminho_medido . ' respondeu ' . $r['codigo'] . ': sem a resposta não há o que medir sobre o que ela publica.' );
		}
	}

	$achados = array();

	if ( str_contains( $curto['corpo'], $titulo ) ) {
		$achados[] = '/llms.txt lista a página protegida por senha, com o título "' . $titulo . '"';
	}

	if ( str_contains( $completo['corpo'], $marca ) ) {
		$achados[] = '/llms-full.txt publicou o CORPO INTEIRO da página protegida por senha, em texto puro e sem senha nenhuma';
	}

	if ( array() === $achados ) {
		return array( 'OK', 'a página publicada COM SENHA ficou fora dos dois arquivos: nem o título no índice curto, nem o corpo no texto integral.' );
	}

	return array(
		'FALHA',
		'o conteúdo protegido por senha vazou pelos arquivos de leitura automática: ' . f3b_bancada_amostra( $achados, 2 )
			. '. Quem não tem a senha vê o formulário na página e o texto inteiro no arquivo que este plugin publica.',
	);
}

/**
 * TETO: sem lixeira, o regime operacional PROSSEGUE e diz que foi DEFINITIVO —
 *       200 com `reversivel: false` e sem `reversivel_ate`, o registro fora do
 *       banco, entrada de journal com a janela zerada e o motivo, e o módulo
 *       ATIVO dizendo que a eliminação neste site é definitiva.
 * PISO: `reversivel: true` sem lixeira — o defeito da 1.0.1, que prometia uma
 *       janela sobre um registro que já não existia — e a recusa que não elimina
 *       nada, que deixava o prazo declarado sem ser cumprido. Os dois são
 *       acusados, cada um pelo nome.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_retencao_sem_lixeira(): array {
	if ( ! class_exists( 'F3Base_Modulo_Retencao_Eliminacao' ) ) {
		return array( 'BLOCKED', 'a rota não pôde ser exercitada. Recurso ausente: F3Base_Modulo_Retencao_Eliminacao carregada.' );
	}

	f3b_bancada_limpar_leads();

	$id = f3b_bancada_lead( 'Lead da bancada sem lixeira' );

	if ( 0 === $id ) {
		return array( 'BLOCKED', 'a rota não pôde ser exercitada: o lead de apoio não foi publicado.' );
	}

	F3Base_Options::gravar( 'f3base_journal_eliminacao', array() );

	$modulo = new F3Base_Modulo_Retencao_Eliminacao();
	$sem    = static function (): int {
		return 0;
	};

	add_filter( 'f3base_dias_de_lixeira', $sem );

	$pedido = new WP_REST_Request( 'POST', '/' . F3BASE_REST_NAMESPACE . F3Base_Modulo_Retencao_Eliminacao::ROTA );
	$pedido->set_param( 'regime', 'operacional' );
	$pedido->set_param( 'identificador', (string) $id );

	$resposta = $modulo->eliminar( $pedido );
	$corpo    = (array) $resposta->get_data();
	$sobrou   = null !== get_post( $id );
	$estado   = ( new F3Base_Modulo_Retencao_Eliminacao() )->estado();

	$journal = F3Base_Options::ler( 'f3base_journal_eliminacao' );
	$journal = is_array( $journal ) ? $journal : array();
	$entrada = array();

	foreach ( $journal as $linha ) {
		if ( is_array( $linha ) && 'operacional' === (string) ( $linha['regime'] ?? '' ) ) {
			$entrada = $linha;
		}
	}

	remove_filter( 'f3base_dias_de_lixeira', $sem );

	$achados = array();

	if ( 200 !== (int) $resposta->get_status() ) {
		$achados[] = 'a rota respondeu ' . (int) $resposta->get_status() . ' em vez de 200: recusar o pedido deixa o registro vencido no banco, e o prazo que a política de privacidade promete passa a não ser cumprido para ele';
	}

	if ( ! empty( $corpo['reversivel'] ) ) {
		$achados[] = 'a rota respondeu reversivel: true com a lixeira do WordPress desligada, isto é, prometeu uma janela de reversão sobre uma cópia que não existe';
	}

	if ( array_key_exists( 'reversivel_ate', $corpo ) ) {
		$achados[] = 'a resposta trouxe reversivel_ate mesmo sem janela nenhuma: campo de prazo sobre o que não tem prazo é a mesma promessa falsa com outro nome';
	}

	if ( ! str_contains( (string) ( $corpo['motivo'] ?? '' ), 'EMPTY_TRASH_DAYS' ) ) {
		$achados[] = 'a resposta não NOMEIA EMPTY_TRASH_DAYS: quem opera o site não tem onde mexer para ter a janela de volta';
	}

	if ( 1 !== (int) ( $corpo['contagem'] ?? 0 ) ) {
		$achados[] = 'a resposta declarou contagem ' . (int) ( $corpo['contagem'] ?? 0 ) . ' para um pedido de um registro só';
	}

	if ( $sobrou ) {
		$achados[] = 'o registro continuou no banco em "' . (string) get_post_status( $id ) . '": sem lixeira a eliminação é definitiva, e não acontecer é o prazo declarado deixando de ser cumprido';
	}

	if ( array() === $entrada ) {
		$achados[] = 'o journal ficou com ' . count( $journal ) . ' entrada(s) e nenhuma do regime operacional: a escrita irreversível não deixou linha, e a data em que o registro deixou de existir não fica em lugar nenhum';
	} else {
		if ( 0 !== (int) ( $entrada['reversivel_ate'] ?? -1 ) ) {
			$achados[] = 'a entrada do journal saiu com reversivel_ate = ' . (int) ( $entrada['reversivel_ate'] ?? -1 ) . ', prometendo no registro uma janela sobre o que já foi apagado';
		}

		if ( F3Base_Modulo_Retencao_Eliminacao::MOTIVO_SEM_LIXEIRA !== (string) ( $entrada['motivo'] ?? '' ) ) {
			$achados[] = 'a entrada do journal saiu com motivo "' . (string) ( $entrada['motivo'] ?? '' ) . '" e não com o motivo declarado da eliminação definitiva sem lixeira: zero em reversivel_ate significa duas coisas diferentes, e quem lê o journal meses depois não distingue as duas por um zero';
		}

		if ( (int) ( $entrada['contagem'] ?? 0 ) < 1 ) {
			$achados[] = 'a entrada do journal saiu com contagem ' . (int) ( $entrada['contagem'] ?? 0 );
		}
	}

	if ( F3Base_Modulo::DEGRADADO === (string) ( $estado['estado'] ?? '' ) ) {
		$achados[] = 'o módulo fechou DEGRADADO sem lixeira: ele está cumprindo o prazo declarado e dizendo o que faz, e degradado é reservado ao que está PIOR que o desenho';
	}

	if ( ! str_contains( (string) ( $estado['motivo'] ?? '' ), 'DEFINITIVA' ) ) {
		$achados[] = 'a frase de estado do módulo não diz que a eliminação neste site é DEFINITIVA: o operador precisa saber disso antes de pedir, e não depois';
	}

	/* E COM A LIXEIRA DE VOLTA a janela existe: sem esta metade a regra viraria "nunca arquivar". */
	$id_com_lixeira = f3b_bancada_lead( 'Lead da bancada com lixeira' );

	if ( 0 === $id_com_lixeira ) {
		return array( 'BLOCKED', 'a segunda metade não pôde ser exercitada: o lead de apoio não foi publicado.' );
	}

	$pedido_com_lixeira = new WP_REST_Request( 'POST', '/' . F3BASE_REST_NAMESPACE . F3Base_Modulo_Retencao_Eliminacao::ROTA );
	$pedido_com_lixeira->set_param( 'regime', 'operacional' );
	$pedido_com_lixeira->set_param( 'identificador', (string) $id_com_lixeira );

	$com_lixeira = $modulo->eliminar( $pedido_com_lixeira );
	$corpo_ok    = (array) $com_lixeira->get_data();

	if ( empty( $corpo_ok['reversivel'] ) || (int) ( $corpo_ok['reversivel_ate'] ?? 0 ) <= 0 || 'trash' !== (string) get_post_status( $id_com_lixeira ) ) {
		$achados[] = 'com a lixeira ligada a limpeza operacional deixou de arquivar: o registro ficou em "' . (string) get_post_status( $id_com_lixeira ) . '" e a resposta disse reversivel = ' . wp_json_encode( $corpo_ok['reversivel'] ?? null ) . ' com reversivel_ate = ' . wp_json_encode( $corpo_ok['reversivel_ate'] ?? null );
	}

	if ( array() === $achados ) {
		return array( 'OK', 'sem lixeira a rota eliminou EM DEFINITIVO e disse isso: 200 com reversivel: false e sem reversivel_ate, o registro fora do banco, entrada de journal com a janela zerada e o motivo declarado, e o módulo ATIVO nomeando EMPTY_TRASH_DAYS. Com a lixeira ligada, o mesmo pedido arquivou o registro com janela reversível.' );
	}

	return array(
		'FALHA',
		'o regime operacional não diz o que faz quando não há lixeira: ' . f3b_bancada_amostra( $achados, 3 )
			. '. Com EMPTY_TRASH_DAYS em zero, mover para a lixeira APAGA — e as duas saídas erradas são prometer a janela assim mesmo e recusar o pedido, que deixa o prazo declarado sem ser cumprido.',
	);
}

/**
 * TETO: a eliminação definitiva em lote deixa entrada no journal.
 * PISO: o journal registra a ida para a lixeira — reversível — e não registra a
 *       perda: a data em que o registro deixou de existir não fica em lugar nenhum.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_retencao_definitiva_no_journal(): array {
	if ( ! class_exists( 'F3Base_Modulo_Retencao_Eliminacao' ) ) {
		return array( 'BLOCKED', 'a rotina não pôde ser exercitada. Recurso ausente: F3Base_Modulo_Retencao_Eliminacao carregada.' );
	}

	f3b_bancada_limpar_leads();

	$id = f3b_bancada_lead( 'Lead da bancada com janela vencida' );

	if ( 0 === $id ) {
		return array( 'BLOCKED', 'a rotina não pôde ser exercitada: o lead de apoio não foi publicado.' );
	}

	if ( ! wp_trash_post( $id ) ) {
		return array( 'BLOCKED', 'a rotina não pôde ser exercitada: o lead de apoio não foi para a lixeira.' );
	}

	update_post_meta( $id, F3Base_Modulo_Retencao_Eliminacao::META_REVERSIVEL, time() - HOUR_IN_SECONDS );

	F3Base_Options::gravar( 'f3base_journal_eliminacao', array() );

	( new F3Base_Modulo_Retencao_Eliminacao() )->executar_limpeza( false );

	$journal = F3Base_Options::ler( 'f3base_journal_eliminacao' );
	$journal = is_array( $journal ) ? $journal : array();

	$definitiva = array();

	foreach ( $journal as $entrada ) {
		if ( is_array( $entrada ) && str_starts_with( (string) ( $entrada['identificador'] ?? '' ), 'retencao-definitiva-' ) ) {
			$definitiva = $entrada;
		}
	}

	if ( null !== get_post( $id ) ) {
		return array( 'BLOCKED', 'a rotina não pôde ser medida: o registro com a janela vencida continuou no banco, então não houve eliminação definitiva a registrar.' );
	}

	$achados = array();

	if ( array() === $definitiva ) {
		$achados[] = 'a rotina apagou em definitivo o registro com a janela vencida e o journal ficou com ' . count( $journal ) . ' entrada(s), nenhuma delas da eliminação definitiva';
	} else {
		if ( (int) ( $definitiva['contagem'] ?? 0 ) < 1 ) {
			$achados[] = 'a entrada do journal saiu com contagem ' . (int) ( $definitiva['contagem'] ?? 0 );
		}

		if ( 0 !== (int) ( $definitiva['reversivel_ate'] ?? -1 ) ) {
			$achados[] = 'a entrada da eliminação definitiva saiu com reversivel_ate = ' . (int) ( $definitiva['reversivel_ate'] ?? -1 ) . ', prometendo uma janela sobre o que já foi apagado';
		}
	}

	if ( array() === $achados ) {
		return array( 'OK', 'a eliminação definitiva do lote venceu a janela e deixou entrada no journal, com contagem e com reversivel_ate zerado.' );
	}

	return array(
		'FALHA',
		'a única escrita irreversível desta rotina não entra no journal: ' . f3b_bancada_amostra( $achados, 2 )
			. '. Quem lê o journal vê o registro entrar na janela e nunca vê a data em que ele deixou de existir.',
	);
}

/**
 * TETO: o lote diário diz quanto ficou para trás, e o estado avisa enquanto
 *       houver fila.
 * PISO: o lote é de 200 por dia e nada mede o resto — a rotina carimba o mesmo
 *       número todo dia, parecendo em dia, enquanto o prazo declarado não é
 *       cumprido para ninguém da fila.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_retencao_declara_o_backlog(): array {
	if ( ! class_exists( 'F3Base_Modulo_Retencao_Eliminacao' ) ) {
		return array( 'BLOCKED', 'a rotina não pôde ser exercitada. Recurso ausente: F3Base_Modulo_Retencao_Eliminacao carregada.' );
	}

	f3b_bancada_limpar_leads();

	$velho = gmdate( 'Y-m-d H:i:s', time() - ( 5 * YEAR_IN_SECONDS ) );

	for ( $n = 1; $n <= 3; $n++ ) {
		$id = f3b_bancada_lead(
			'Lead vencido ' . $n,
			array(
				'post_date'     => $velho,
				'post_date_gmt' => $velho,
			)
		);

		if ( 0 === $id ) {
			return array( 'BLOCKED', 'a rotina não pôde ser exercitada: o lead vencido ' . $n . ' não foi publicado.' );
		}
	}

	$dois = static function (): int {
		return 2;
	};

	add_filter( 'f3base_retencao_lote', $dois );

	( new F3Base_Modulo_Retencao_Eliminacao() )->executar_limpeza( false );

	$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_LIMPEZA );
	$estado  = ( new F3Base_Modulo_Retencao_Eliminacao() )->estado();

	remove_filter( 'f3base_retencao_lote', $dois );

	if ( 2 !== (int) ( $carimbo['arquivados'] ?? 0 ) ) {
		return array( 'BLOCKED', 'a rotina não pôde ser medida: com o lote em 2 e três registros vencidos, o carimbo diz ' . (int) ( $carimbo['arquivados'] ?? 0 ) . ' arquivado(s).' );
	}

	$achados = array();

	if ( ! array_key_exists( 'restantes', $carimbo ) ) {
		$achados[] = 'o carimbo da limpeza não registra restantes: não há como saber que sobrou fila';
	} elseif ( (int) $carimbo['restantes'] < 1 ) {
		$achados[] = 'o carimbo registrou restantes = ' . (int) $carimbo['restantes'] . ' com um registro vencido ainda no banco';
	}

	if ( F3Base_Modulo::DEGRADADO !== (string) $estado['estado'] ) {
		$achados[] = 'com fila pendente o módulo fechou "' . (string) $estado['estado'] . '" em vez de degradado: o prazo declarado não está sendo cumprido e nada diz isso';
	}

	if ( array() === $achados ) {
		return array( 'OK', 'com o lote menor que a fila, o carimbo registrou os restantes e o módulo fechou degradado nomeando o backlog: ' . (string) $estado['motivo'] );
	}

	return array(
		'FALHA',
		'o lote diário não dá sinal de saturação: ' . f3b_bancada_amostra( $achados, 2 )
			. '. Um site que acumule mais registros vencidos por dia do que o lote alcança nunca chega ao próprio prazo, e a rotina carimba o mesmo número todo dia como se estivesse em dia.',
	);
}

/**
 * TETO: exportador e eraser do núcleo PAGINAM, e `done` só sai no fim.
 * PISO: os dois param em um lote e devolvem `done => true` — o titular recebe
 *       uma exportação incompleta e uma eliminação incompleta, as duas
 *       declaradas completas pelo núcleo.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_privacidade_pagina_o_titular(): array {
	if ( ! class_exists( 'F3Base_Modulo_Retencao_Eliminacao' ) ) {
		return array( 'BLOCKED', 'as rotinas não puderam ser exercitadas. Recurso ausente: F3Base_Modulo_Retencao_Eliminacao carregada.' );
	}

	f3b_bancada_limpar_leads();

	$email = 'titular-da-bancada@exemplo.test';

	for ( $n = 1; $n <= 3; $n++ ) {
		$id = f3b_bancada_lead( 'Lead do titular ' . $n );

		if ( 0 === $id ) {
			return array( 'BLOCKED', 'as rotinas não puderam ser exercitadas: o lead ' . $n . ' do titular não foi publicado.' );
		}

		update_post_meta( $id, '_f3base_email', $email );
	}

	$dois = static function (): int {
		return 2;
	};

	add_filter( 'f3base_privacidade_lote', $dois );

	$modulo = new F3Base_Modulo_Retencao_Eliminacao();

	$pagina_1 = $modulo->exportar( $email, 1 );
	$pagina_2 = $modulo->exportar( $email, 2 );

	$achados = array();

	if ( 2 !== count( $pagina_1['data'] ) || false !== $pagina_1['done'] ) {
		$achados[] = 'a primeira página da exportação saiu com ' . count( $pagina_1['data'] ) . ' item(ns) e done = ' . wp_json_encode( $pagina_1['done'] ) . ': página cheia declarada como fim é exportação truncada em silêncio';
	}

	if ( 1 !== count( $pagina_2['data'] ) || true !== $pagina_2['done'] ) {
		$achados[] = 'a segunda página da exportação saiu com ' . count( $pagina_2['data'] ) . ' item(ns) e done = ' . wp_json_encode( $pagina_2['done'] );
	}

	$apagar_1 = $modulo->apagar( $email, 1 );
	$apagar_2 = $modulo->apagar( $email, 2 );

	remove_filter( 'f3base_privacidade_lote', $dois );

	if ( false !== $apagar_1['done'] ) {
		$achados[] = 'a primeira passagem do eraser declarou done = true com um lote cheio: o resto do titular ficaria no banco com o núcleo dizendo que a eliminação terminou';
	}

	if ( true !== $apagar_2['done'] ) {
		$achados[] = 'a segunda passagem do eraser não declarou o fim';
	}

	$restaram = get_posts(
		array(
			'post_type'   => F3Base_Modulo_Endpoint_Leads::CPT,
			'post_status' => 'any',
			'numberposts' => 10,
			'fields'      => 'ids',
			'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array(
					'key'     => '_f3base_email',
					'value'   => $email,
					'compare' => '=',
				),
			),
		)
	);

	if ( is_array( $restaram ) && array() !== $restaram ) {
		$achados[] = 'sobraram ' . count( $restaram ) . ' registro(s) do titular depois das duas passagens do eraser';
	}

	if ( array() === $achados ) {
		return array( 'OK', 'exportador e eraser honraram a paginação do núcleo: a página cheia devolveu done = false, a página incompleta fechou o fim, e nada do titular ficou no banco.' );
	}

	return array(
		'FALHA',
		'as rotinas de privacidade do núcleo não paginam: ' . f3b_bancada_amostra( $achados, 3 )
			. '. O titular com mais registros que o lote recebe uma resposta incompleta declarada completa — a pior forma de responder a um pedido de acesso ou de eliminação.',
	);
}

/**
 * TETO: o par declarado com status 410 TERMINA a requisição, com corpo mínimo.
 * PISO: o ramo do 410 só faz `return`, o WordPress segue e carrega o template —
 *       o visitante recebe a PÁGINA com status de removida.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_redirect_410_termina(): array {
	if ( ! class_exists( 'F3Base_Options' ) ) {
		return array( 'BLOCKED', 'o 410 não pôde ser exercitado. Recurso ausente: F3Base_Options carregada.' );
	}

	$caminho = '/removido-da-bancada/';

	F3Base_Options::gravar(
		'f3base_redirects',
		array(
			array(
				'de'     => $caminho,
				'para'   => '/',
				'status' => 410,
			),
		)
	);

	$r = f3b_bancada_get( $caminho );

	if ( 0 === $r['codigo'] ) {
		return array( 'BLOCKED', 'o endereço não pôde ser buscado. Recurso ausente: servidor HTTP embutido respondendo — ' . $r['corpo'] . '.' );
	}

	$achados = array();

	if ( 410 !== $r['codigo'] ) {
		$achados[] = 'o endereço declarado como removido respondeu ' . $r['codigo'];
	}

	$minusculo = strtolower( $r['corpo'] );

	if ( str_contains( $minusculo, '<html' ) || str_contains( $minusculo, '<body' ) ) {
		$achados[] = 'o corpo da resposta traz a PÁGINA renderizada (' . strlen( $r['corpo'] ) . ' bytes de HTML) sob o status 410: o rastreador que lê o status remove o endereço, e a pessoa que lê o corpo vê o site funcionando';
	}

	if ( array() === $achados ) {
		return array( 'OK', 'o par declarado com 410 terminou a requisição com corpo mínimo de texto puro (' . strlen( $r['corpo'] ) . ' bytes), sem carregar o template.' );
	}

	return array(
		'FALHA',
		'o ramo do 410 não termina a requisição: ' . f3b_bancada_amostra( $achados, 2 )
			. '. Duas respostas na mesma requisição, e nenhuma delas é a declarada.',
	);
}

/**
 * TETO: as duas habilidades de CONFIGURAÇÃO executam de ponta a ponta no núcleo
 * real — a entrada válida atravessa a validação de schema do núcleo, chega ao
 * callback e volta como resposta estruturada; sem usuário, a mesma entrada é
 * recusada pelo portão.
 * PISO: `properties` moldado como OBJETO PHP nos dois schemas de entrada.
 *
 * O DEFEITO MEDIDO nasceu numa frente desta release, e a bancada não o via:
 * `wp.habilidades_registradas` executa `como-usar`, que não recebe entrada, e
 * conferia das outras duas só a presença no registro. O núcleo indexa
 * `properties` como ARRAY ao validar cada campo da entrada
 * (`rest_validate_object_value_from_schema`), e um `stdClass` ali derruba a
 * chamada com Error antes de o callback existir. Uma habilidade que está no
 * registro e morre ao ser chamada com a entrada que o próprio schema pede é
 * pior que uma que não existe: o agente a encontra, confia nela e derruba a
 * requisição.
 *
 * O IMPLANTADOR É PLANTADO PELO PASSO — um par `projeto.json`/`projeto.schema.json`
 * numa pasta de plugin da bancada — e removido no fim. A leitura é medida até
 * o conteúdo; a escrita é medida até o callback: sem a classe validadora do
 * implantador ela responde `ok: false` nomeando o que falta e não toca no
 * arquivo, e é isso que este passo exige. Gravar de verdade se mede na suíte
 * do implantador, que é quem tem o validador.
 *
 * @return array{0:string,1:string}
 */
function f3b_bancada_habilidades_de_config_executam(): array {
	if ( ! function_exists( 'wp_get_ability' ) || ! class_exists( 'F3Base_Config_Mcp' ) || ! defined( 'WP_PLUGIN_DIR' ) ) {
		return array( 'BLOCKED', 'as habilidades de configuração não puderam ser exercitadas. Recurso ausente: a Abilities API do núcleo (wp_get_ability), F3Base_Config_Mcp carregada e WP_PLUGIN_DIR definido.' );
	}

	$ler      = wp_get_ability( 'f3base/config-ler' );
	$escrever = wp_get_ability( 'f3base/config-escrever' );

	if ( ! is_object( $ler ) || ! is_object( $escrever ) || ! method_exists( $ler, 'execute' ) ) {
		return array( 'BLOCKED', 'as habilidades de configuração não puderam ser exercitadas: não estão no registro do núcleo, e quem acusa isso é wp.habilidades_registradas.' );
	}

	$pasta  = WP_PLUGIN_DIR . '/implantador-de-bancada-f3';
	$config = $pasta . '/config/projeto.json';
	$schema = $pasta . '/config/projeto.schema.json';

	if ( is_dir( $pasta ) ) {
		f3b_bancada_remover_pasta( $pasta );
	}

	if ( ! wp_mkdir_p( $pasta . '/config' ) ) {
		return array( 'BLOCKED', 'as habilidades de configuração não puderam ser exercitadas: a pasta do implantador de bancada não pôde ser criada em ' . $pasta . '.' );
	}

	$planta = array( 'nome' => 'bancada', 'ambiente' => 'teste' );

	file_put_contents( // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- bancada local.
		$schema,
		(string) wp_json_encode(
			array(
				'$schema'              => 'https://json-schema.org/draft/2020-12/schema',
				'type'                 => 'object',
				'properties'           => array(
					'nome'     => array( 'type' => 'string' ),
					'ambiente' => array( 'type' => 'string' ),
				),
				'required'             => array( 'nome' ),
				'additionalProperties' => false,
			)
		)
	);
	file_put_contents( $config, (string) wp_json_encode( $planta ) . "\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- bancada local.

	$antes = (string) file_get_contents( $config ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- bancada local.

	$candidatos = F3Base_Config_Mcp::diretorios();

	if ( 1 !== count( $candidatos ) ) {
		f3b_bancada_remover_pasta( $pasta );

		return array( 'BLOCKED', 'as habilidades de configuração não puderam ser exercitadas: a bancada enxerga ' . count( $candidatos ) . ' implantador(es) em vez de um (' . implode( ', ', array_map( 'basename', array_map( static fn ( string $c ): string => rtrim( $c, '/' ), $candidatos ) ) ) . ').' );
	}

	$achados = array();
	$entrada = array( 'arquivo' => 'projeto' );

	/*
	 * A CHAMADA É PROTEGIDA UMA A UMA, e a exceção vira o achado com o nome da
	 * habilidade — se ela subisse até o despacho, a linha acusaria "o passo
	 * terminou em exceção" sem dizer qual chamada morreu nem por quê.
	 */
	$chamar = static function ( object $habilidade, array $dados ) {
		try {
			return $habilidade->execute( $dados );
		} catch ( Throwable $erro ) {
			return new WP_Error( 'bancada_excecao', get_class( $erro ) . ' — ' . $erro->getMessage() . ' (' . basename( $erro->getFile() ) . ':' . (int) $erro->getLine() . ')' );
		}
	};

	/* 1. SEM USUÁRIO, entrada válida: o portão recusa, e a recusa não é de schema. */
	wp_set_current_user( 0 );

	$sem_usuario = $chamar( $ler, $entrada );

	if ( ! is_wp_error( $sem_usuario ) ) {
		$achados[] = 'f3base/config-ler executou SEM usuário nenhum com entrada válida: o permission_callback não barra quem não tem manage_options';
	} elseif ( 'bancada_excecao' === $sem_usuario->get_error_code() || 'ability_invalid_input' === $sem_usuario->get_error_code() ) {
		$achados[] = 'f3base/config-ler sem usuário não chegou ao portão: ' . $sem_usuario->get_error_message();
	}

	/* 2. COMO ADMINISTRADOR, a leitura atravessa a validação e devolve o conteúdo plantado. */
	wp_set_current_user( 1 );

	$lido = $chamar( $ler, $entrada );

	if ( is_wp_error( $lido ) ) {
		$achados[] = 'f3base/config-ler morreu ANTES do callback com a entrada que o próprio schema pede ({"arquivo":"projeto"}): ' . $lido->get_error_message();
	} elseif ( ! is_array( $lido ) || true !== ( $lido['ok'] ?? null ) ) {
		$achados[] = 'f3base/config-ler chegou ao callback e não leu o par plantado: ' . mb_substr( (string) wp_json_encode( $lido, JSON_UNESCAPED_UNICODE ), 0, 200 );
	} elseif ( 'bancada' !== (string) ( ( (array) ( $lido['conteudo'] ?? array() ) )['nome'] ?? '' ) ) {
		$achados[] = 'f3base/config-ler respondeu ok e o conteúdo não é o do arquivo plantado: ' . mb_substr( (string) wp_json_encode( $lido['conteudo'] ?? null, JSON_UNESCAPED_UNICODE ), 0, 200 );
	}

	/* 3. A ESCRITA chega ao callback e responde estruturado; sem validador, não grava. */
	$escrita = $chamar( $escrever, array( 'arquivo' => 'projeto', 'conteudo' => array( 'nome' => 'gravado pela bancada' ) ) );

	if ( is_wp_error( $escrita ) ) {
		$achados[] = 'f3base/config-escrever morreu ANTES do callback com a entrada que o próprio schema pede: ' . $escrita->get_error_message();
	} elseif ( ! is_array( $escrita ) || ! array_key_exists( 'ok', $escrita ) ) {
		$achados[] = 'f3base/config-escrever chegou ao callback e não respondeu com o campo ok: ' . mb_substr( (string) wp_json_encode( $escrita, JSON_UNESCAPED_UNICODE ), 0, 200 );
	} elseif ( true === $escrita['ok'] && (string) file_get_contents( $config ) === $antes ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- bancada local.
		$achados[] = 'f3base/config-escrever respondeu ok: true e o arquivo em disco continuou o mesmo';
	} elseif ( false === $escrita['ok'] && (string) file_get_contents( $config ) !== $antes ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- bancada local.
		$achados[] = 'f3base/config-escrever respondeu ok: false e o arquivo em disco MUDOU';
	}

	/*
	 * 4. O MAPA VAZIO DE `como-usar` É LIDO PELO MESMO VALIDADOR. Com um campo
	 * que o schema não declara, a resposta certa é a recusa de schema do núcleo
	 * (`additionalProperties: false`); um `stdClass` no lugar do mapa transformava
	 * essa recusa em Error, pelo mesmo caminho das outras duas.
	 */
	$como_usar = wp_get_ability( 'f3base/como-usar' );

	if ( is_object( $como_usar ) && method_exists( $como_usar, 'execute' ) ) {
		$sobra = $chamar( $como_usar, array( 'campo_que_nao_existe' => 1 ) );

		if ( ! is_wp_error( $sobra ) ) {
			$achados[] = 'f3base/como-usar aceitou um campo que o schema não declara: additionalProperties: false não está sendo lido pelo núcleo';
		} elseif ( 'ability_invalid_input' !== $sobra->get_error_code() ) {
			$achados[] = 'f3base/como-usar com um campo fora do schema não foi recusada pelo schema: ' . $sobra->get_error_message();
		}
	}

	f3b_bancada_remover_pasta( $pasta );

	if ( array() === $achados ) {
		return array(
			'OK',
			'f3base/config-ler e f3base/config-escrever atravessam a validação de entrada do núcleo com a entrada que o schema pede, recusam sem usuário e respondem estruturado, e como-usar recusa pelo schema o campo que não declara: a leitura devolveu o par plantado e a escrita '
				. ( true === $escrita['ok'] ? 'gravou o arquivo' : 'respondeu ok: false sem tocar no arquivo (' . mb_substr( (string) ( $escrita['erro'] ?? '' ), 0, 80 ) . ')' ) . '.',
		);
	}

	return array(
		'FALHA',
		'as habilidades de configuração não executam de ponta a ponta no núcleo real: ' . f3b_bancada_amostra( $achados, 3 )
			. '. Uma habilidade que está no registro e morre ao ser chamada com a entrada que o próprio schema pede é pior que uma que não existe: o agente a encontra, confia nela e derruba a requisição.',
	);
}

/**
 * Remove uma pasta plantada pelo roteiro, com o que houver dentro.
 *
 * @param string $pasta Caminho absoluto.
 * @return void
 */
function f3b_bancada_remover_pasta( string $pasta ): void {
	if ( ! is_dir( $pasta ) ) {
		return;
	}

	$itens = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $pasta, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );

	foreach ( $itens as $item ) {
		if ( $item->isDir() ) {
			rmdir( $item->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- bancada local.
		} else {
			unlink( $item->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink -- bancada local.
		}
	}

	rmdir( $pasta ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- bancada local.
}

/* =========================================================================
 * DESPACHO. Um passo por execução; nome desconhecido fecha BLOCKED.
 * ====================================================================== */

$f3b_passos = array(
	'ativacao_sem_aviso'         => 'f3b_bancada_ativacao_sem_aviso',
	'home_servida'               => 'f3b_bancada_home_servida',
	'habilidades_registradas'    => 'f3b_bancada_habilidades_registradas',
	'habilidades_de_config_executam' => 'f3b_bancada_habilidades_de_config_executam',
	'lote_sem_metricas_gravado'  => 'f3b_bancada_lote_sem_metricas_gravado',
	'esquecer_apaga_sem_oraculo' => 'f3b_bancada_esquecer_apaga_sem_oraculo',
	'llms_full_responde'         => 'f3b_bancada_llms_full_responde',
	'llms_nao_publica_protegido' => 'f3b_bancada_llms_nao_publica_protegido',
	'redirect_nao_gira'          => 'f3b_bancada_redirect_nao_gira',
	'redirect_410_termina'       => 'f3b_bancada_redirect_410_termina',
	'cron_na_ativacao'           => 'f3b_bancada_cron_na_ativacao',
	'token_capi_mascarado'       => 'f3b_bancada_token_capi_mascarado',
	'retencao_sem_lixeira'       => 'f3b_bancada_retencao_sem_lixeira',
	'retencao_definitiva_no_journal' => 'f3b_bancada_retencao_definitiva_no_journal',
	'retencao_declara_o_backlog' => 'f3b_bancada_retencao_declara_o_backlog',
	'privacidade_pagina_o_titular'   => 'f3b_bancada_privacidade_pagina_o_titular',
	'debug_log_limpo'            => 'f3b_bancada_debug_log_limpo',
	'desinstalacao_limpa'        => 'f3b_bancada_desinstalacao_limpa',
);

/*
 * PROCESSO QUE MORRE NÃO ABSOLVE NINGUÉM. Se o passo derrubar o PHP — e derrubar
 * o PHP é um dos defeitos que esta bancada procura —, o encerramento grava a
 * linha adversa em vez de deixar o arquivo vazio, que o `bancada.sh` leria como
 * "não medido".
 */
register_shutdown_function(
	static function () use ( $f3b_passo ): void {
		$erro = error_get_last();

		if ( is_array( $erro ) && in_array( (int) $erro['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR ), true ) ) {
			f3b_bancada_veredito( 'FALHA', $f3b_passo, 'o passo derrubou o processo do WordPress: ' . (string) $erro['message'] . ' — ' . (string) $erro['file'] . ':' . (int) $erro['line'] . '.' );
		}
	}
);

$f3b_passos = array_merge( $f3b_passos, require __DIR__ . '/evolucao.php' );

if ( '' === $f3b_saida || ! isset( $f3b_passos[ $f3b_passo ] ) ) {
	f3b_bancada_veredito( 'BLOCKED', '' === $f3b_passo ? 'passo_sem_nome' : $f3b_passo, 'o roteiro foi chamado sem arquivo de saída ou com um passo que ele não conhece.' );
	return;
}

try {
	$f3b_veredito = call_user_func( $f3b_passos[ $f3b_passo ] );
	f3b_bancada_veredito( (string) $f3b_veredito[0], $f3b_passo, (string) $f3b_veredito[1] );
} catch ( Throwable $f3b_erro ) {
	f3b_bancada_veredito(
		'FALHA',
		$f3b_passo,
		'o passo terminou em exceção dentro do WordPress real: ' . get_class( $f3b_erro ) . ' — ' . $f3b_erro->getMessage()
			. ' em ' . $f3b_erro->getFile() . ':' . $f3b_erro->getLine() . '.'
	);
}
