/* Navegador obrigatório: frontend real e algoritmos oficiais com vetores conhecidos. */
const { chromium } = require('playwright');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
(async () => {
 const browser = await chromium.launch({executablePath:process.env.F3BASE_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--disable-gpu']});
 const evidencia = { navegador: browser.version(), paginas: [], algoritmos: {} };
 try {
  let biblioteca;
  for (const viewport of [{width:1280,height:800},{width:390,height:844}]) {
   const context = await browser.newContext({viewport});
   const pagina = await context.newPage(); const erros=[];
   pagina.on('pageerror',e=>erros.push(String(e)));
   await pagina.route('**/*',route => route.request().method() === 'POST' && /\/lead(?:[/?]|$)/.test(route.request().url()) ? route.fulfill({status:200,contentType:'application/json',body:'{"ok":true}'}) : new URL(route.request().url()).hostname === new URL(process.argv[2]).hostname ? route.continue() : route.abort());
   for (const url of [process.argv[2],process.argv[3]]) {
    await pagina.goto(url,{waitUntil:'networkidle'});
    const botao=pagina.locator('#f3base-whatsapp-flutuante'); assert.equal(await botao.count(),1); await botao.waitFor({state:'visible'});
    assert.match(await botao.getAttribute('href'),/^https:\/\/wa.me\/5511999999999/);
    assert.equal(await botao.getAttribute('target'),'_blank'); assert.ok(await botao.getAttribute('aria-label'));
    const a=await botao.boundingBox(); await pagina.evaluate(()=>scrollTo(0,document.body.scrollHeight)); const b=await botao.boundingBox();
    assert.equal(Math.round(a.y),Math.round(b.y)); assert.ok(b.x>=0 && b.y>=0 && b.x+b.width<=viewport.width && b.y+b.height<=viewport.height && b.width>=44);
    await botao.focus(); assert.ok(await botao.evaluate(el=>el===document.activeElement));
    const destinoTema=await pagina.evaluate(()=>{
     const a=document.createElement('a');a.href='/contato/';a.setAttribute('data-f3base-lead','sentinela-tema');a.textContent='Contato do tema';document.body.appendChild(a);
     a.addEventListener('click',e=>e.preventDefault());a.click();const destino=a.getAttribute('href');a.remove();return destino;
    });assert.equal(destinoTema,'/contato/');

    const scripts=await pagina.locator('script[src*="assets/vendor/web-vitals.js"]').evaluateAll(els=>els.map(e=>e.src)); assert.equal(scripts.length,1);
    assert.equal(await pagina.evaluate(()=>typeof webVitals.onINP),'function');
    biblioteca=await (await context.request.get(scripts[0])).text();
    evidencia.paginas.push({url,viewport,retangulo:b,icone:true,bibliotecaLocal:true});
   }
   assert.deepEqual(erros,[]); await context.close();
  }
  // A distribuição local recebe vetores determinísticos; o patch preserva o máximo entre janelas no mesmo lote.
  const p=await browser.newPage(); await p.goto(process.argv[2]);
  await p.evaluate(()=>{
   const observadores=[];
   window.PerformanceObserver=class {
    static supportedEntryTypes=['paint','layout-shift','event','first-input','largest-contentful-paint'];
    constructor(cb){this.cb=cb;this.tipos=[];observadores.push(this);}
    observe(o){this.tipos.push(o.type);} takeRecords(){return [];} disconnect(){}
   };
   Object.defineProperty(performance,'interactionCount',{value:0,writable:true,configurable:true});
   Object.defineProperty(performance,'getEntriesByType',{value:tipo=>tipo==='navigation'?[{responseStart:10,startTime:0,activationStart:0,domInteractive:20,loadEventEnd:30,type:'navigate'}]:[],configurable:true});
   window.emitirVetor=(tipo,entradas)=>{for(const po of observadores){if(po.tipos.includes(tipo))po.cb({getEntries:()=>entradas});}};
   window.resultados=[];
  });
  await p.addScriptTag({content:biblioteca});
  await p.evaluate(()=>{webVitals.onCLS(m=>resultados.push({nome:m.name,valor:m.value}));webVitals.onINP(m=>resultados.push({nome:m.name,valor:m.value}));});
  await p.evaluate(()=>emitirVetor('paint',[{name:'first-contentful-paint',entryType:'paint',startTime:50}]));
  await p.waitForTimeout(50);
  await p.evaluate(()=>{
   emitirVetor('layout-shift',[{entryType:'layout-shift',startTime:100,value:.2,hadRecentInput:false},{entryType:'layout-shift',startTime:400,value:.3,hadRecentInput:false},{entryType:'layout-shift',startTime:2200,value:.4,hadRecentInput:false},{entryType:'layout-shift',startTime:2300,value:.8,hadRecentInput:true}]);
   performance.interactionCount=50;
   emitirVetor('event',Array.from({length:50},(_,i)=>({entryType:'event',name:'click',interactionId:7+i*7,duration:i===0?800:i===1?600:100,startTime:100+i,processingStart:100+i,processingEnd:110+i})));
  });
  await p.waitForTimeout(80);
  await p.evaluate(()=>{Object.defineProperty(document,'visibilityState',{get:()=> 'hidden',configurable:true});document.dispatchEvent(new Event('visibilitychange',{bubbles:true}));});
  await p.waitForTimeout(80);
  const resultados=await p.evaluate(()=>resultados); const cls=resultados.filter(r=>r.nome==='CLS').pop();const inp=resultados.filter(r=>r.nome==='INP').pop();
  assert.equal(cls?.valor,.5,JSON.stringify(resultados));assert.equal(inp?.valor,600,JSON.stringify(resultados));
  evidencia.algoritmos={clsJanelas:cls.valor,inpCinquentaInteracoes:inp.valor,entradas:'vetores sintéticos; web-vitals com patch local documentado de janelas de CLS'};
  const destino=path.resolve(__dirname,'../../dist/evidencias/browser-160.json');fs.mkdirSync(path.dirname(destino),{recursive:true});fs.writeFileSync(destino,JSON.stringify(evidencia,null,2));
  if(process.argv[4])fs.writeFileSync(process.argv[4],JSON.stringify(evidencia,null,2));
  process.stdout.write('WhatsApp desktop/móvel e algoritmos oficiais CLS/INP conferidos.\n');
 } finally { await browser.close(); }
})().catch(e=>{process.stderr.write(e.stack+'\n');process.exit(1);});
