/**
 * SERVIDOR DA SONDA DE NAVEGADOR: serve a página e recebe os lotes.
 *
 * Ele existe porque o cliente de comportamento não é uma função pura: ele lê
 * geometria do documento, instala `IntersectionObserver` e `PerformanceObserver`
 * de verdade e DESPACHA para uma rota. Um arquivo servido de `file://` não tem
 * origem para despachar, e um DOM montado à mão é a bancada — que é
 * exatamente o que esta sonda existe para não ser.
 *
 * O QUE ELE NÃO DECIDE. A declaração de eventos vem de `pub/dados.json`, gerada
 * do TSV na hora por quem chama; a geometria da página vem de `sonda.mjs`; a
 * classe de cada seção vem de `prefixoSecao`, o MESMO campo que o cliente lê.
 * Nada aqui é escrito à mão, e é por isso que uma edição no TSV chega à página
 * servida sem ninguém tocar neste arquivo.
 *
 *   node servidor.mjs <diretorio-pub> <porta>
 *
 * @package F3Base\Suite
 */

import http from 'node:http';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

import { PAGINA } from './sonda.mjs';

const pub = process.argv[ 2 ] || '.';
const porta = Number( process.argv[ 3 ] || 8731 );

const cliente = readFileSync( join( pub, 'f3base-tracking.js' ), 'utf8' );
const vitais = readFileSync(join(pub, 'web-vitals.js'), 'utf8');
const dados = JSON.parse( readFileSync( join( pub, 'dados.json' ), 'utf8' ) );

let recebidos = [];

/*
 * A SEÇÃO É UM BLOCO DE UMA TELA, com a classe que o tema carimba. O
 * `min-height` mais o preenchimento somam exatamente a altura da janela
 * declarada: é a geometria do site real que gerou o relatório do usuário, com
 * seções de cerca de uma tela, e é ela que faz `faq` descer até a razão 0,1 sem
 * nunca sair inteira do campo de visão.
 */
const corpo = PAGINA.secoes.map( ( nome, i ) =>
	'<section class="wp-block-group ' + dados.comportamento.prefixoSecao + nome + '"' +
	' style="min-height:' + PAGINA.alturaDaSecao + 'px;padding:' + PAGINA.preenchimento + 'px;' +
	'background:hsl(' + ( i * 60 ) + ',30%,' + ( 92 - ( i * 4 ) ) + '%)">' +
	'<h2>' + nome + '</h2><p>' + 'texto '.repeat( 200 ) + '</p></section>'
).join( '\n' );

http.createServer( ( req, res ) => {
	if ( req.url.startsWith( '/wp-json' ) ) {
		let bruto = '';

		req.on( 'data', ( c ) => ( bruto += c ) );
		req.on( 'end', () => {
			try {
				recebidos.push( JSON.parse( bruto ) );
			} catch {
				recebidos.push( { ilegivel: bruto.slice( 0, 200 ) } );
			}

			res.writeHead( 200, { 'Content-Type': 'application/json' } );
			res.end( '{"ok":true}' );
		} );

		return;
	}

	if ( '/recebidos' === req.url ) {
		res.writeHead( 200, { 'Content-Type': 'application/json' } );
		res.end( JSON.stringify( recebidos ) );

		return;
	}

	/* Entre um percurso e outro a lista zera: cada percurso é uma medição. */
	if ( '/zerar' === req.url ) {
		recebidos = [];
		res.writeHead( 200, { 'Content-Type': 'application/json' } );
		res.end( '{"ok":true}' );

		return;
	}

	if (req.url === '/web-vitals.js') { res.writeHead(200, {'Content-Type': 'text/javascript'}); res.end(vitais); return; }
	if ( req.url.startsWith( '/f3base-tracking.js' ) ) {
		res.writeHead( 200, { 'Content-Type': 'text/javascript; charset=utf-8' } );
		res.end( cliente );

		return;
	}

	res.writeHead( 200, { 'Content-Type': 'text/html; charset=utf-8' } );
	res.end(
		'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>sonda de navegador</title>' +
		'<style>body{margin:0;font:16px system-ui}section{box-sizing:content-box}</style></head><body>\n' +
		corpo + '\n' +
		'<script>window.f3baseTrackingDados=' + JSON.stringify( dados ) + ';</script>\n' +
		'<script src="/web-vitals.js" defer></script><script src="/f3base-tracking.js" defer></script>\n' +
		'</body></html>'
	);
} ).listen( porta, () => process.stderr.write( 'sonda de navegador no ar na porta ' + porta + '\n' ) );
