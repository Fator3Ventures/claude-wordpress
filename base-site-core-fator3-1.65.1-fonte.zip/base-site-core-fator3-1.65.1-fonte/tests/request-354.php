<?php
require __DIR__.'/bootstrap.php';
$warm=defined('QA_354_WARM');
$html='<div class="f3base-acao-contato">'.str_repeat('<p>Conteúdo técnico de ensaio, sem dados pessoais. <a href="/contato">Contato</a></p>',2400).'</div>';
if(!$warm){F3Base_Servicos::invalidar_cta();}
wp_set_current_user(0);
$t=microtime(true);$result=F3Base_Servicos::carimbar_conteudo($html);$ms=(microtime(true)-$t)*1000;$diag=F3Base_Servicos::cta_diagnostico();
check(str_contains($result,'data-f3base-lead="contato"'),'354_content_stamped');
check(($diag['fases']['the_content']['cache_acertos']??0)===($warm?1:0),'354_'.($warm?'warm_cross_request_hit':'cold_miss'));
check(($diag['fases']['the_content']['parseamentos']??0)===($warm?0:1),'354_'.($warm?'warm_no_parse':'cold_single_parse'));
if($warm){
 wp_set_current_user(1);$before=get_option('f3base_cta_cache');$post=wp_insert_post(array('post_title'=>'CTA invalidation fixture','post_status'=>'draft'));check($post>0&&get_option('f3base_cta_cache')!==$before,'354_save_post_invalidates');wp_set_current_user(0);
 $again=F3Base_Servicos::carimbar_conteudo($html);check($again===$result,'354_html_after_invalidation_identical');check(F3Base_Servicos::cta_diagnostico()['fases']['the_content']['parseamentos']===1,'354_save_post_forces_parse');
 wp_set_current_user(1);$before=get_option('f3base_cta_cache');do_action('updated_option','f3base_contato',array(),array('revision'=>'fixture'));check(get_option('f3base_cta_cache')!==$before,'354_contact_change_invalidates');wp_delete_post($post,true);
}
file_put_contents(getenv('F3BASE_ROOT').'/evidence/1651/cta-'.($warm?'warm':'cold').'-metrics.json',wp_json_encode(array('own_cta_ms'=>$ms,'input_bytes'=>strlen($html),'output_sha256'=>hash('sha256',$result),'diagnostico'=>$diag),JSON_PRETTY_PRINT));
evidence('request-354-'.($warm?'warm':'cold'));
