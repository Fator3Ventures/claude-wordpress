<?php
/** Native-cycle extension. Disposable database only; never run against a shared site. */
require __DIR__.'/bootstrap.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
$mode=$argv[1]??'snapshot';$expected=$argv[2]??'1.59.0';$plugin='base-site-core-fator3/base-site-core-fator3.php';
check(in_array($expected,['1.58.0','1.59.0','1.60.0','1.61.0','1.61.1','1.62.0','1.63.0','1.64.0','1.65.0','1.65.1'],true)&&(in_array($expected,['1.59.0','1.60.0','1.61.0','1.61.1','1.62.0','1.63.0','1.64.0','1.65.0','1.65.1'],true)||in_array($mode,['seed','snapshot'],true)),'supported_cycle_version');
$tables=['f3base_conversa_vinculos','f3base_desfechos','f3base_caminho_lead','f3base_qualidade_destinos','f3base_wp_mail'];
$http=0;add_filter('pre_http_request',static function()use(&$http){++$http;return new WP_Error('qa_native_cycle_no_http');},PHP_INT_MAX);add_filter('pre_wp_mail',static fn()=>true,PHP_INT_MAX);
function rows1590(array $tables): array {
    global $wpdb;$out=[];
    foreach($tables as $suffix){$table=$wpdb->prefix.$suffix;check($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))===$table,'table_exists_'.$suffix);$out[$suffix]=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i ORDER BY 1',$table),ARRAY_A);check(!$wpdb->last_error,'table_read_'.$suffix);}
    return $out;
}
function hashes1590(array $rows): array {$out=[];foreach($rows as $table=>$items){$out[$table]=['rows'=>count($items),'sha256'=>hash('sha256',wp_json_encode($items)),'states'=>array_count_values(array_column($items,'estado'))];}return $out;}
if($mode==='reactivate'){
    $r=activate_plugin($plugin);check(!is_wp_error($r),'native_reactivation');check(F3BASE_PLUGIN_VERSAO===$expected,'reactivated_version');$cycle=F3Base_Instalacao::atualizar();check(!empty($cycle['ok']),'reactivation_migration');echo wp_json_encode(['ok'=>true,'cycle'=>$cycle,'http_attempts'=>$http]);exit;
}
check(F3BASE_PLUGIN_VERSAO===$expected&&F3Base_Config_Contrato::VERSAO===(['1.65.1'=>'8.30.0','1.65.0'=>'8.30.0','1.64.0'=>'8.29.0','1.63.0'=>'8.28.0','1.62.0'=>'8.27.0','1.61.1'=>'8.26.0','1.61.0'=>'8.25.0','1.60.0'=>'8.24.0','1.59.0'=>'8.23.0','1.58.0'=>'8.23.0'][$expected]??''),'native_target_contract');
if($mode==='seed'){
    rows1590($tables);$record=str_repeat('f',32);$now=time();$future=$now+DAY_IN_SECONDS;
    $insert=static function(string $suffix,array $row)use($wpdb){check($wpdb->insert($wpdb->prefix.$suffix,$row)===1,'seed_'.$suffix.'_'.($row['estado']??$row['eliminado']??'history'));};
    foreach([0,1] as $deleted){$insert('f3base_conversa_vinculos',['chave'=>hash('sha256','cycle1590-conversation-'.$deleted),'record_id'=>$deleted?'':$record,'primeira_em'=>$now-30,'criado_em'=>$now,'eliminado'=>$deleted]);}
    $insert('f3base_desfechos',['chave'=>hash('sha256','cycle1590-outcome'),'record_id'=>$record,'conta'=>'synthetic-cycle-account','negocio_id'=>'1590','ocorreu_em'=>$now-20,'recebido_em'=>$now,'dados'=>F3Base_Capi_Fila::cifrar_payload(['atual'=>['estado'=>'won','valor'=>'123.000000','moeda'=>'BRL'],'origem'=>'qa_cycle1590'])]);
    foreach(['pendente','incerto','enviado'] as $state){
        $insert('f3base_wp_mail',['id'=>substr(hash('sha256','cycle1590-mail-'.$state),0,32),'estado'=>$state,'codigo'=>'fixture1590','fase'=>'smtp','assinatura'=>hash('sha256','cycle1590-mail-signature-'.$state),'payload'=>F3Base_Contato_Comunicacao::cifrar(['subject'=>'Synthetic cycle fixture','to'=>['nobody@example.test']]),'destinatarios'=>1,'criado_em'=>$now,'atualizado_em'=>$now,'proxima'=>$future]);
        $insert('f3base_qualidade_destinos',['chave'=>hash('sha256','cycle1590-stage-'.$state),'record_id'=>$record,'etapa'=>'won','destino'=>'google_ads','acao'=>'fixture-action','destino_ref'=>'fixture-destination','config_revisao'=>str_repeat('a',64),'ocorreu_em'=>$now-20,'estado'=>$state,'codigo'=>'fixture1590','http'=>0,'atualizado_em'=>$now]);
    }
    foreach(['pendente','executando','concluido'] as $state){$insert('f3base_caminho_lead',['id'=>hash('sha256','cycle1590-path-'.$state),'intencao'=>hash('sha256','cycle1590-intent-'.$state),'revisao'=>str_repeat('b',64),'ator'=>1,'estado'=>$state,'versao'=>1,'passo'=>0,'proxima'=>$future,'criado_em'=>$now,'atualizado_em'=>$now,'entrada'=>F3Base_Contato_Comunicacao::cifrar(['formulario'=>'fixture','campos'=>[]]),'recibo'=>wp_json_encode(['versao'=>1,'registros'=>[],'saltos'=>[],'limpeza'=>[],'exclusoes'=>[]])]);}
    echo wp_json_encode(['ok'=>true,'tables'=>hashes1590(rows1590($tables)),'http_attempts'=>$http]);exit;
}
if($mode==='uninstall'){
    $before=rows1590($tables);$expected=$before;
    foreach(['f3base_caminho_lead','f3base_qualidade_destinos','f3base_wp_mail'] as $table){foreach($expected[$table] as &$row){if($row['estado']==='pendente'){$row['estado']='suspenso';}}unset($row);}
    $hooks=[F3Base_Caminho_Lead::HOOK,F3Base_Qualidade_Destinos::HOOK,F3Base_Wp_Mail::HOOK];
    foreach($hooks as $hook){foreach([[],['cycle1590-owned-argument']] as $args){$r=wp_schedule_single_event(time()+DAY_IN_SECONDS,$hook,$args,true);check(!is_wp_error($r)&&$r!==false,'seed_cron_'.$hook.'_'.count($args));}}
    deactivate_plugins($plugin);uninstall_plugin($plugin);
    $after=rows1590($tables);check($after===$expected,'uninstall_preserves_five_tables_and_only_suspends_pending');
    $remaining=[];foreach(_get_cron_array()?:[] as $at=>$entries){foreach($entries as $hook=>$events){if(str_starts_with($hook,'f3base_')){$remaining[]=$hook;}}}
    check(!$remaining,'uninstall_core_cron_empty');check(!is_plugin_active($plugin),'uninstalled_plugin_inactive');check($http===0,'uninstall_zero_http');
    echo wp_json_encode(['ok'=>true,'tables'=>hashes1590($after),'pending_suspended'=>true,'historical_and_uncertain_unchanged'=>true,'cron_remaining'=>$remaining,'http_attempts'=>$http]);exit;
}
check($mode==='snapshot','known_cycle_mode');$rows=rows1590($tables);check($http===0,'cycle_snapshot_zero_http');echo wp_json_encode(['ok'=>true,'tables'=>hashes1590($rows),'http_attempts'=>$http]);
