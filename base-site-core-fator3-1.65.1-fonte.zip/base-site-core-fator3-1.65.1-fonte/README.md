# Fator3 Site Core 1.65.1 — fonte

Runtime em work/plugin/base-site-core-fator3. Base canônica imutável 1.65.0; contrato 8.30.0. Correções 354(h–j), 362 e conclusão técnica da carga por recurso P2. Leia PLANO-1.65.1.md, docs/RELEASE-1.65.1.md e o relatório externo para provas e limites. PLANO-1.65.0.md é a base de requisitos histórica.

O fonte não contém bancos, credenciais, laboratórios prontos, pacotes acompanhantes, node_modules ou ZIPs aninhados. Forneça insumos oficiais e siga build/README.md. A existência de scripts históricos não significa reexecução. Aceites de campo não observados permanecem explicitamente identificados no relatório.
