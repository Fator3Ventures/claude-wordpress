<?php
/** Fixed synthetic scenarios, shared by local WordPress and temporary Site-Teste probe. */
use Fator3\Meta as M;
function meta060_worker_cases(bool $site=false): array {
 global $wpdb;$user=get_current_user_id();M\Access::admin();
 if($site&&(M\Store::list('connection',0,1)||M\Store::list('schedule',0,1)||M\Queue::waiting()))throw new RuntimeException('Site fixture requires no configured connections, schedules or runnable jobs');
 $checks=[];$http=0;$mail=[];$grant=null;$identity=null;$hasMcp=class_exists('Fator3\\McpFiles\\ConnectionContext');
 $verify=static function($name,$ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok];};
 $before=$wpdb->get_results('SELECT bucket,record_key FROM '.M\Store::table().' ORDER BY bucket,record_key',ARRAY_A);$known=[];foreach($before as $r)$known[$r['bucket'].':'.$r['record_key']]=true;
 $beforeHistory=$wpdb->get_col('SELECT row_key FROM '.M\History::table());
 $beforeOptions=$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE 'f3_meta_%'",ARRAY_A);$beforeCron=wp_get_scheduled_event('f3_meta_worker');
 if($hasMcp)$identity=\Fator3\McpFiles\ConnectionContext::resume('integration:user:'.$user,$user);
 $mock=static function($pre,$args,$url)use(&$http){$http++;$id=basename((string)parse_url($url,PHP_URL_PATH));return ['headers'=>[],'body'=>wp_json_encode(['id'=>$id,'name'=>'QA 060 synthetic','username'=>'qa060','followers_count'=>1]),'response'=>['code'=>200,'message'=>'fixture'],'cookies'=>[]];};
 $mailer=static function($pre,$atts)use(&$mail){$mail[]=$atts;return true;};add_filter('pre_http_request',$mock,1,3);add_filter('pre_wp_mail',$mailer,1,2);
 try{
  M\Connections::save(['connection_id'=>'qa060','expected_revision'=>0,'token'=>'qa060-synthetic-not-a-token','assets'=>['instagram'=>['888060']],'users'=>[$user]]);
  $q=['connection_id'=>'qa060','channel'=>'instagram','account_id'=>'888060','report'=>'profile'];
  $saved=M\Schedules::save(['schedule_id'=>'qa060_hourly','label'=>'QA 060 horária','query'=>$q,'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()-7201]);
  wp_clear_scheduled_hook('f3_meta_worker');$observed=M\Worker::health();$verify('13 missing worker and >2 intervals overdue diagnosed',in_array('worker_missing',array_column($observed['issues'],'code'),true)&&in_array('schedule_overdue',array_column($observed['issues'],'code'),true));
  $status=M\Api::dispatch('status');$verify('13 status repairs and preserves observed degraded state',$status['success']&&$status['data']['state']==='degraded'&&$status['data']['cron']['observed_next']===null&&$status['data']['cron']['next']!==null&&$status['data']['recovery']['scheduled']);
  $verify('13 status has no provider or mail call',$http===0&&count($mail)===0);
  $deny=static function($pre,$event){return $event->hook==='f3_meta_worker'?new WP_Error('could_not_set','synthetic persistence failure'):$pre;};
  wp_clear_scheduled_hook('f3_meta_worker');add_filter('pre_schedule_event',$deny,10,2);$s=M\Worker::status();remove_filter('pre_schedule_event',$deny,10);
  $verify('13 failed scheduling is visible and recorded',!$s['recovery']['scheduled']&&$s['cron']['next']===null&&$s['cron']['last_schedule_failure']['code']==='could_not_set');
  do_action('f3_meta_maintenance');$verify('13 real maintenance hook restores missing event',wp_next_scheduled('f3_meta_worker')!==false);
  // Completed history is deliberately older and sorts before the new schedule job.
  $template=['query'=>$q,'principal'=>M\Access::principal(),'connection_revision'=>1,'status'=>'complete','pages'=>0,'rows'=>0,'created_at'=>time()-86400,'updated_at'=>time()-86400,'next_at'=>0,'last_code'=>null,'errors'=>[]];
  for($n=0;$n<2000;$n++)M\Store::put('job','0000000000000000qa060_done_'.str_pad((string)$n,4,'0',STR_PAD_LEFT),$template);
  $explain=$wpdb->get_row($wpdb->prepare("EXPLAIN SELECT record_key,queue_next FROM %i WHERE bucket='job' AND queue_state='queued' AND queue_next<=%d ORDER BY queue_next,record_key LIMIT 20",M\Store::table(),time()),ARRAY_A);
  $verify('14 SQL planner uses runnable index without filesort',($explain['key']??'')==='runnable'&&!str_contains($explain['Extra']??'','filesort'));
  wp_clear_scheduled_hook('f3_meta_worker');do_action('f3_meta_worker');$schedule=M\Store::get('schedule','qa060_hourly');$job=M\Store::get('job',$schedule['value']['last_job']??'missing');
  $verify('14 hourly job completes in first pass with 2000 completed jobs',$job&&$job['value']['status']==='complete');
  $verify('14 worker processes executable candidates only',(get_option('f3_meta_last_worker')['processed']??0)===1);
  $verify('13 schedule runs and is rearmed after watchdog',$schedule['value']['next_at']>time()&&wp_next_scheduled('f3_meta_worker')!==false);
  $j=M\Jobs::create(['query'=>$q,'idempotency_key'=>'qa060-lag']);$row=M\Store::get('job',$j['job_id']);$v=$row['value'];$v['next_at']=time()-123;M\Store::put('job',$j['job_id'],$v,$row['revision']);$health=M\Worker::health();
  $verify('14 status shows oldest due delay in seconds',$health['queue']['oldest_due_lag_seconds']>=123&&$health['queue']['oldest_due_lag_seconds']<135);
  $row=M\Store::get('job',$j['job_id']);$v=$row['value'];$v['status']='retry';$v['next_at']=time()+3600;M\Store::put('job',$j['job_id'],$v,$row['revision']);
  $verify('14 future retry excluded but retains worker',M\Queue::due()===[]&&M\Queue::waiting());
  $row=M\Store::get('job',$j['job_id']);$v=$row['value'];$v['status']='paused';M\Store::put('job',$j['job_id'],$v,$row['revision']);$row=M\Store::get('job',$j['job_id']);
  try{M\Store::put('job',$j['job_id'],$v+['x'=>1],$row['revision']-1);$cas=false;}catch(M\Fault $e){$cas=$e->reason==='revision_conflict';}
  $projection=$wpdb->get_row($wpdb->prepare('SELECT queue_state,queue_next FROM %i WHERE bucket=%s AND record_key=%s',M\Store::table(),'job',$j['job_id']),ARRAY_A);$verify('14 failed CAS leaves projection and payload consistent',$cas&&$projection['queue_state']==='paused'&&(int)$projection['queue_next']===$v['next_at']);
  // Migration preserves exact ciphertext, timestamps and revision; stale CAS cannot project.
  $wpdb->query($wpdb->prepare("UPDATE %i SET queue_state='',queue_next=0 WHERE bucket='job' AND record_key=%s",M\Store::table(),$j['job_id']));
  $raw=$wpdb->get_row($wpdb->prepare('SELECT payload,revision,updated_at,expires_at FROM %i WHERE bucket=%s AND record_key=%s',M\Store::table(),'job',$j['job_id']),ARRAY_A);M\Queue::migrate();$after=$wpdb->get_row($wpdb->prepare('SELECT payload,revision,updated_at,expires_at FROM %i WHERE bucket=%s AND record_key=%s',M\Store::table(),'job',$j['job_id']),ARRAY_A);
  $verify('14 migration preserves exact ciphertext and business revision',$raw===$after&&!M\Queue::pending());
  // Inject a non-Fault exception after pre-arming, then verify finally retained the event.
  $seen=0;$boom=static function($sql)use(&$seen){if(str_starts_with($sql,'SELECT record_key FROM')&&str_contains($sql,"bucket='schedule' ORDER")&&++$seen===2)throw new RuntimeException('synthetic worker exception');return $sql;};
  wp_clear_scheduled_hook('f3_meta_worker');add_filter('query',$boom);do_action('f3_meta_worker');remove_filter('query',$boom);
  $verify('13 unexpected worker exception still rearms',(get_option('f3_meta_last_worker')['state']??'')==='failed'&&wp_next_scheduled('f3_meta_worker')!==false);
  [$dbhost,$dbport,$dbsocket]=$wpdb->parse_db_host(DB_HOST);
  $other=new mysqli($dbhost,DB_USER,DB_PASSWORD,DB_NAME,$dbport??3306,$dbsocket);$name='f3s:'.substr(hash('sha256',DB_NAME.'|'.M\Store::table().'|worker-pass'),0,55);$other->query("SELECT GET_LOCK('".$other->real_escape_string($name)."',0)");$prior=get_option('f3_meta_last_worker');M\Jobs::tick();$verify('concurrent worker pass cannot process or overwrite checkpoint',get_option('f3_meta_last_worker')===$prior);$other->query("SELECT RELEASE_LOCK('".$other->real_escape_string($name)."')");$other->close();
  $wpdb->query($wpdb->prepare("UPDATE %i SET queue_state='',queue_next=0 WHERE bucket='job' AND record_key LIKE %s",M\Store::table(),'0000000000000000qa060_done_%'));
  $m=M\Queue::migrate();$verify('migration is bounded to 100 with pending work',$m['processed']===100&&!$m['complete']&&M\Queue::pending());
  $new=M\Jobs::create(['query'=>$q,'idempotency_key'=>'qa060-migration-priority']);$due=M\Queue::due();$verify('new queued job selectable while old history is migrating',in_array($new['job_id'],array_column($due,'record_key'),true));
  for($pass=0;$pass<25&&M\Queue::pending();$pass++)M\Queue::migrate();$verify('migration completes without rewriting completed jobs',!M\Queue::pending());
  $jr=M\Store::get('job',$new['job_id']);$jv=$jr['value'];$jv['status']='retry';$jv['next_at']=time()-200;M\Store::put('job',$new['job_id'],$jv,$jr['revision']);$verify('overdue retry is selected first',M\Queue::due(1)[0]['record_key']===$new['job_id']);
  $jr=M\Store::get('job',$new['job_id']);$jv=$jr['value'];$jv['status']='paused';M\Store::put('job',$new['job_id'],$jv,$jr['revision']);$beforeHttp=$http;$res=M\Jobs::run($new['job_id'],true);$verify('stale selection rechecks paused state without provider',$res['status']==='paused'&&$http===$beforeHttp);
  $sched=M\Store::get('schedule','qa060_hourly');$sv=$sched['value'];$sv['next_at']=time();
  if($hasMcp){
   $grant='qa060_'.bin2hex(random_bytes(8));\Fator3\McpFiles\Persistence::put('oauth-grants',$grant,['grant_id'=>$grant,'user_id'=>$user,'client_id'=>'qa060','profile'=>'maintenance','status'=>'active']);
   \Fator3\McpFiles\ConnectionContext::oauth(['user_id'=>$user,'grant_id'=>$grant,'client_id'=>'qa060','profile'=>'maintenance']);
   M\Schedules::save(['schedule_id'=>'qa060_hourly','query'=>$q,'expected_revision'=>$sched['revision'],'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()]);
   $principal=M\Store::get('schedule','qa060_hourly')['value']['principal'];$verify('13 schedule saved under real MCP test grant',($principal['channel']['connection_id']??'')==='grant:'.$grant);
   \Fator3\McpFiles\Persistence::put('oauth-grants',$grant,['grant_id'=>$grant,'user_id'=>$user,'client_id'=>'qa060','profile'=>'maintenance','status'=>'revoked']);\Fator3\McpFiles\ConnectionContext::restore_identity(null,$user);
  }else{$sv['principal']['user_id']=2147483647;M\Store::put('schedule','qa060_hourly',$sv,$sched['revision']);}
  delete_option('f3_meta_operation_notice');$beforeMail=count($mail);$beforeHttp=$http;do_action('f3_meta_worker');$h=M\Worker::health();$auth=array_values(array_filter($h['issues'],fn($i)=>$i['code']==='schedule_authorization_failed'));
  $verify('13 revoked authority shows named agenda and resave action',count($auth)===1&&$auth[0]['label']==='QA 060 horária'&&str_contains($auth[0]['action'],'salve novamente'));
  $verify('13 revoked authority never calls provider',$http===$beforeHttp);
  $verify('13 operational email contains action without credentials',count($mail)===$beforeMail+1&&str_contains(end($mail)['message'],'salve novamente')&&!str_contains(end($mail)['message'],'synthetic-not-a-token'));
  M\Worker::notify();$verify('13 repeated passes throttle operational mail',count($mail)===$beforeMail+1);
  $verify('13 mail acceptance distinguished from delivery',get_option('f3_meta_operation_notice')['state']==='accepted');
  if($hasMcp){
   \Fator3\McpFiles\Persistence::put('oauth-grants',$grant,['grant_id'=>$grant,'user_id'=>$user,'client_id'=>'qa060','profile'=>'maintenance','status'=>'active']);
   \Fator3\McpFiles\ConnectionContext::oauth(['user_id'=>$user,'grant_id'=>$grant,'client_id'=>'qa060','profile'=>'maintenance']);
   $policy=\Fator3\McpFiles\Persistence::get('connections','grant:'.$grant);$policy['profile']='read';
   \Fator3\McpFiles\Persistence::put('connections','grant:'.$grant,$policy);$res=M\Api::dispatch('status',[],true);$verify('MCP read profile refuses status local write',!$res['success']&&$res['code']==='not_authorized');
   $policy['profile']='maintenance';\Fator3\McpFiles\Persistence::put('connections','grant:'.$grant,$policy);$res=M\Api::dispatch('status',[],true);$verify('MCP maintenance profile permits status local recovery',$res['success']);
   \Fator3\McpFiles\ConnectionContext::restore_identity(null,$user);
  }
  $meta=wp_get_ability('meta/status')->get_meta();$verify('status explicitly advertises local write and no remote effect',$meta['annotations']['readonly']===false&&$meta['fator3']['local_effect']==='write'&&$meta['fator3']['remote_effect']==='none');
 }finally{
  remove_filter('pre_http_request',$mock,1);remove_filter('pre_wp_mail',$mailer,1);
  if($grant){\Fator3\McpFiles\Persistence::delete('connections','grant:'.$grant);\Fator3\McpFiles\Persistence::delete('oauth-grants',$grant);}
  if($hasMcp)\Fator3\McpFiles\ConnectionContext::restore_identity($identity,$user);
  foreach($wpdb->get_results('SELECT bucket,record_key,revision FROM '.M\Store::table(),ARRAY_A) as $r)if($r['bucket']!=='audit'&&!isset($known[$r['bucket'].':'.$r['record_key']]))M\Store::remove($r['bucket'],$r['record_key'],(int)$r['revision']);
  foreach($wpdb->get_col('SELECT row_key FROM '.M\History::table()) as $id)if(!in_array($id,$beforeHistory,true))$wpdb->delete(M\History::table(),['row_key'=>$id]);
  $options=[];foreach($beforeOptions as $r)$options[$r['option_name']]=maybe_unserialize($r['option_value']);
  foreach($wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'f3_meta_%'") as $key){if($key==='f3_meta_audit_health')continue;if(array_key_exists($key,$options))update_option($key,$options[$key],false);else delete_option($key);}
  wp_clear_scheduled_hook('f3_meta_worker');if($beforeCron)wp_schedule_single_event($beforeCron->timestamp,'f3_meta_worker',$beforeCron->args);
 }
 $verify('synthetic connection and schedules cleaned',M\Store::get('connection','qa060')===null&&M\Store::get('schedule','qa060_hourly')===null);
 return ['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'version'=>M\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'http_fixture_calls'=>$http,'mail_intercepted'=>count($mail),'real_provider_calls'=>0,'explain'=>$explain??null];
}
