<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
foreach(['Meta'] as $name){$ns='Fator3\\'.$name.'\\';$config=$ns.'Config';if(!class_exists($config))continue;if(!in_array($config::VERSION,['0.5.0'],true))throw new RuntimeException('Expected immutable 0.5.0 baseline');$conn=$ns.'Connections';$store=$ns.'Store';$p=['user_id'=>1,'channel'=>null];$meta=$name==='Meta';$channel=$meta?'instagram':'pages';
$assets=$meta?['instagram'=>['111']]:['pages'=>['111'],'ads'=>['222'],'leads'=>['222']];$i=['connection_id'=>'legacy','expected_revision'=>0,'token'=>'synthetic-baseline-token','assets'=>$assets,'retention_days'=>365];if(!$meta)$i+=['forms'=>['222'=>['633']],'application_id'=>'app-legacy','client_id'=>'client-legacy'];$conn::save($i);
$q=['connection_id'=>'legacy','channel'=>$channel,'account_id'=>'111','report'=>$meta?'profile':'organization'];$job=str_repeat($meta?'a':'b',64);$data=['contract'=>'social-reporting/1.0.0','connection_id'=>'legacy','channel'=>$channel,'account_id'=>'111','report'=>$q['report'],'api_version'=>$config::API_VERSION,'selection'=>$q,'fetched_at'=>gmdate('c',time()-100*86400),'rows'=>[['id'=>'111','name'=>'Legacy retained']],'fields'=>['id','name'],'coverage'=>['complete'=>true,'errors'=>[]],'temporal'=>'snapshot','timezone'=>'provider_defined','currency'=>null,'next_cursor'=>null];
$store::put('job',$job,['query'=>$q,'principal'=>$p,'connection_revision'=>1,'status'=>'complete','pages'=>1,'rows'=>1,'created_at'=>time()-100*86400,'updated_at'=>time()-100*86400,'next_at'=>0,'last_code'=>null,'errors'=>[]],0,time()-1);
$store::put('result',$job.':000000',['principal'=>$p,'connection_revision'=>1,'query'=>$q,'data'=>$data],0,time()+200*86400);
$store::put('schedule','legacy',['query'=>$q,'principal'=>$p,'connection_revision'=>1,'enabled'=>true,'interval_minutes'=>1440,'lookback_days'=>7,'next_at'=>time()+86400,'last_job'=>null,'last_code'=>null]);
if(!$meta){$want=['webhook'=>'https://example.com/consumer','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:222'],'versionedForm'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:633,1)','leadType'=>'SPONSORED'];$store::put('subscription',str_repeat('c',64),['consumer'=>'qa','connection_id'=>'legacy','credential_revision'=>1,'wanted'=>$want,'state'=>'creating','remote_id'=>null,'created_at'=>time()-3600]);}
}
echo "{\"baseline_seeded\":true}\n";

$labels=[];foreach(wp_get_abilities() as $name=>$a)if(str_starts_with($name,'meta/'))$labels[$name]=['input'=>$a->get_input_schema(),'output'=>$a->get_output_schema(),'meta'=>$a->get_meta()];
file_put_contents($lab=getenv('F3_LAB_ROOT').'/baseline-abilities.json',json_encode($labels));
global $wpdb;
$records=$wpdb->get_results('SELECT bucket,record_key,revision,payload,updated_at,expires_at FROM '.\Fator3\Meta\Store::table().' ORDER BY bucket,record_key',ARRAY_A);
$history=$wpdb->get_results('SELECT * FROM '.\Fator3\Meta\History::table().' ORDER BY row_key',ARRAY_A);
$options=$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE 'f3_meta_%' AND option_name NOT IN ('f3_meta_schema','f3_meta_queue_migration','f3_meta_worker_schedule_attempt') ORDER BY option_name",ARRAY_A);
file_put_contents(getenv('F3_LAB_ROOT').'/baseline-state.sha256',hash('sha256',serialize([$records,$history,$options])));

