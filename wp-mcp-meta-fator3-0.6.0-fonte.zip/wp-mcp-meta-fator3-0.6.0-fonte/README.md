# Fonte — Fator3 MCP Meta 0.6.0

Pedidos MCP Meta 13 e 14. Atualização direta da base 0.5.0. Este ZIP fonte não é instalável.

## Estrutura

- `plugin/wp-mcp-meta-fator3/`: runtime idêntico ao instalador.
- `build/`: código canônico e compilador determinístico. Os arquivos em `meta/` substituem os homônimos de `common/`; edite `meta/Query.php` para a fila Meta. `meta/Worker.php` contém índice, migração, diagnóstico e alertas; `common/Support.php` mantém a projeção na escrita CAS.
- `tests/native/worker-cases.php` e `release060.php`: cenários novos; `release060-metadata.php`: atualização, metadados, autorização e documentos; `mcp-docs060.php`: leitura completa pelo executor MCP real; `suite.php`, `release030.php` e `release040.php`: regressões Meta. Números históricos nos nomes não significam versão executada.
- `tests/native/ui-dom.cjs`: HTML/JS servido pelo WordPress e REST autenticado, com jsdom; não é prova visual de navegador.
- `tests/site/meta060-qa.php`: sonda temporária preparada para o Site-Teste; não instalada nesta rodada por bloqueio de aprovação, nunca incluída no instalador. Exige administrador, versão 0.6.0, domínio exato do Site-Teste e configuração Meta vazia. Usar apenas após autorização; remover com guarda de hash após executar.
- `tools/lab.py`: laboratório descartável e independente; não edita outro laboratório. `evidence/` contém provas atuais sanitizadas; `inputs/`, os documentos recebidos; `impacts/`, encaminhamento pertinente. Testes antigos não executados não são evidência da 0.6.0.

## Reprodução

Python 3 e PHP 8.3.6 de 64 bits foram usados. Defina `F3_SOCIAL_PHP` para o PHP e `LD_LIBRARY_PATH` quando necessário. Execute `python3 build/build.py`. Saída: `build/dist/wp-mcp-meta-fator3-0.6.0-instalador.zip`. Compare o hash com o relatório.

Prepare os arquivos/runtimes identificados em `tools/dependencies060.json`, ajustando somente caminhos e preservando os hashes. Dependências não estão aninhadas no fonte. Com o instalador construído:

```sh
python3 tools/lab.py --manifest tools/dependencies060.json --workdir /caminho/novo-limpo --order meta-only
python3 tools/lab.py --manifest tools/dependencies060.json --workdir /caminho/novo-upgrade --order meta-integrated --origin upgrade
```

Para DOM: `npm ci --ignore-scripts --no-audit --no-fund` em `tests/dom`; defina `F3_JSDOM` com o caminho absoluto de `tests/dom/node_modules/jsdom` e execute o laboratório com `--order meta-only --ui --ui-only`. O helper inicia WordPress/MySQL próprios e encerra seus processos. Não use banco compartilhado para fabricar instalação limpa.

O runtime testado é WordPress 7.1.3/PHP 8.3.6/MySQL 8.0.46. Mínimos declarados 6.4/8.1.2 herdados não foram reexecutados; não são suporte comprovado nesta rodada. Fornecedores/e-mail foram interceptados. O relatório separa essa prova do aceite remoto bloqueado.

## Fechamento

O instalador deve ser reproduzível byte a byte. `tools/package-source.py --output-dir /diretorio/fora-do-fonte` recusa sobrescrita e ZIP aninhado, exclui dependências e build/dist. A cópia interna do relatório é anterior ao fechamento; hash final do próprio fonte aparece apenas no relatório externo. Não incluir banco, credenciais, sessões nem capturas de navegador.
