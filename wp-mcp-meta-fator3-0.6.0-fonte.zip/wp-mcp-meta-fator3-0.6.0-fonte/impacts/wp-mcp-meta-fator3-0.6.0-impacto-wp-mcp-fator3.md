# Impacto de Fator3 MCP Meta 0.6.0 em Fator3 MCP

Revisão 2 · 22/10/2026 · entrega · situação aberto · validacao-coordenada / alerta-tecnico.

Emissor: Meta 0.5.0 → 0.6.0. Destinatário: MCP 0.28.0, mantenedor/dono/frota. Referência: Pedidos MCP Meta 13(a,d) e 14, normas comuns revisão 4. Instalador: 134999 bytes, SHA-256 `36f5cfe9a20db272fc80d3cdd8fd46da823c4eeac856e31d911e41754fd19f69`.

## Contrato implementado e consequência

`meta/status` preserva o nome e a entrada vazia, mas agora declara `mode=write`, `local_effect=write`, `remote_effect=none`, `readonly=false` e `idempotent=false`. Isso atende ao pedido explícito de recuperar o evento local ausente e é exceção à regra geral de diagnóstico sem reparo. Não consulta fornecedor, não executa coletas e não transfere concessões. O estado observado fica em state/issues/cron.observed_next; recovery e cron.next registram o resultado da tentativa.

O MCP 0.28.0 consome os metadados nativos e sua política real recusa a operação para perfil read, permitindo maintenance. Perfil custom deve incluir meta/status explicitamente. Não há ampliação automática de perfil ou necessidade identificada de mudar código do transporte. A descrição pública avisa o efeito. As outras 32 operações preservam metadados funcionais, exceto a versão; os 33 schemas de entrada permanecem iguais à base.

Revogação do grant continua bloqueando a agenda. O domínio mostra nome e ação de salvar novamente por uma concessão atual autorizada; não ressuscita a antiga nem libera seus resultados. Avisos são do Meta ao admin_email do WordPress, com limitação de uma tentativa por hora. Nenhum consumidor de auditoria de serviço LinkedIn é introduzido no Meta.

## Prova e ação do responsável

Laboratório nativo WordPress 7.1.3/PHP 8.3.6/MySQL 8.0.46: MCP 0.28.0, LinkedIn 0.7.0, Core 1.47.0 e Google 0.17.0. Trinta verificações novas integradas, sem falhas, incluem grant real do MCP salvo/revogado, gate de perfil read/maintenance, índice com 2.000 jobs concluídos, CAS e concorrência. O executor MCP nativo recuperou 17 documentos completos em 19 páginas, com hashes idênticos ao instalador. Fornecedores/e-mail interceptados; não é nova homologação comercial nem sessão HTTP MCP remota.

Dono/frota: conferir perfis personalizados e autorizar a instalação no Site-Teste. A revisão automática bloqueou a troca remota por não reconhecer autorização explícita de deploy; nenhuma instalação ou sonda foi aplicada. Site permanece Meta 0.5.0, oito plugins nas mesmas versões/ativações, healthy=true. Aceite restante: repetir os dois cenários sintéticos e a leitura documental via conexão MCP remota após autorização. Meta tem a sonda preparada no fonte, com guarda de domínio/configuração, interceptação e limpeza.

## Compatibilidade e sequência

Instalação isolada Meta continua funcional. Sem mudança requerida de Core, Google ou LinkedIn. A atualização suportada é direta da 0.5.0; migração aditiva do índice mantém identidade, ciphertext e revisões. Perfis somente leitura devem ser ajustados pelo dono se precisarem do diagnóstico com recuperação. Não há novo ID público. A sonda temporária não integra o instalador.

## Histórico e encerramento

- Revisão 1, planejamento: emitida antes do código, descreveu efeito de status e validação coordenada; cópia preservada em evidence/impact-planning060.md.
- Revisão 2, entrega: contrato implementado e política existente confirmados localmente. Não se atribui trabalho ao mantenedor MCP. Situação permanece aberta apenas para revisão de perfis/aceite remoto pelo dono. Documento preparado, não enviado externamente.
