<?php
/** Verified, bounded cache. SQL residue and the active object cache are distinct stores. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
use Fator3\McpGoogle\Storage\Budget;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Cache {
    public const MAX_DB_BYTES=100000;
    public const MAX_FILE_BYTES=16777216;
    public const MAX_FILES=64;
    public const MAX_TOTAL_BYTES=67108864;
    public const HEADER="<?php http_response_code(404); exit; ?>\n";
    private static ?string $error=null;
    public static function dir(): string {
        return WP_CONTENT_DIR.'/f3-google-cache';
    }
    private static function prefix(): string {
        return 'site-'.(function_exists('get_current_blog_id')?get_current_blog_id():1).'-';
    }
    private static function path(string $key): string {
        return self::dir().'/'.self::prefix().hash('sha256',Recovery::generation().'|'.$key).'.php';
    }
    private static function valid(string $key): bool {
        return str_starts_with($key,'f3_mcp_google_') && strlen($key)<=172;
    }
    private static function lock() {
        $dir=self::dir();
        if (is_link($dir)||(!is_dir($dir)&&!@mkdir($dir,0700,true))) return false;
        $index=$dir.'/index.php';
        $path=$dir.'/'.self::prefix().'lock.php';
        if (is_link($index)||is_link($path)) return false;
        if (!is_file($index) && @file_put_contents($index,self::HEADER,LOCK_EX)!==strlen(self::HEADER)) return false;
        $f=@fopen($path,'c+');
        if (!$f) return false;
        if (!flock($f,LOCK_EX|LOCK_NB)) {
            fclose($f);
            return false;
        }
        if (fstat($f)['size']===0 && (fwrite($f,self::HEADER)!==strlen(self::HEADER)||!fflush($f))) {
            fclose($f);
            return false;
        }
        @chmod($path,0600);
        return $f;
    }
    private static function unlock($lock): void {
        flock($lock,LOCK_UN);
        fclose($lock);
    }
    private static function remove_file(string $path): bool {
        if (is_link(self::dir())||is_link($path)) return false;
        clearstatcache(true,$path);
        if (!file_exists($path)) return true;
        if (!is_file($path)||!@unlink($path)) return false;
        clearstatcache(true,$path);
        return !file_exists($path);
    }
    private static function refresh_sql_cache(string $key): void {
        if (function_exists('wp_using_ext_object_cache') && wp_using_ext_object_cache()) return;
        if (function_exists('wp_cache_delete')) {
            wp_cache_delete('_transient_'.$key,'options');
            wp_cache_delete('_transient_timeout_'.$key,'options');
            // Non-expiring transients can be in alloptions. This invalidates that option snapshot, not the object-cache backend.
            wp_cache_delete('alloptions','options');
            wp_cache_delete('notoptions','options');
        }
    }
    private static function active_value(string $key) {
        self::refresh_sql_cache($key);
        if (!(function_exists('wp_using_ext_object_cache') && wp_using_ext_object_cache())) {
            $timeout=get_option('_transient_timeout_'.$key,0);
            if (is_numeric($timeout) && (int)$timeout>0 && (int)$timeout<time()) return false;
        }
        return get_transient($key);
    }
    public static function get(string $key) {
        if (!self::valid($key)) return false;
        $r=Recovery::run(static function() use($key) {
            $lock=self::lock();
            if (!$lock) return ['value'=>false];
            try {
                $v=self::active_value($key);
                // Legacy conversion belongs to maintenance: reads never extend its TTL.
                if (false!==$v) return ['value'=>$v];
                $path=self::path($key);
                if (is_link($path)||!is_file($path)) return ['value'=>false];
                $size=@filesize($path);
                if (!$size||$size>self::MAX_FILE_BYTES) return ['value'=>false];
                $raw=@file_get_contents($path);
                if (!is_string($raw)||!str_starts_with($raw,self::HEADER)) return ['value'=>false];
                $record=json_decode(substr($raw,strlen(self::HEADER)),true);
                if (!is_array($record)||!is_int($record['expires']??null)||$record['expires']<=time()) return ['value'=>false];
                $plain=Crypto::decrypt((string)($record['cipher']??''));
                if (is_wp_error($plain)||!is_string($plain)) return ['value'=>false];
                $decoded=json_decode($plain,true);
                return ['value'=>is_array($decoded)&&array_key_exists('value',$decoded)?$decoded['value']:false];
            }
            finally {
                self::unlock($lock);
            }
            });
        return $r['value']??false;
    }
    public static function set(string $key,$value,int $ttl=0): bool {
        self::$error=null;
        if (!self::valid($key)) return false;
        $r=Recovery::run(static function() use($key,$value,$ttl) {
            $lock=self::lock();
            if (!$lock) return self::failure('f3_google_cache_unavailable');
            try {
                return self::set_locked($key,$value,$ttl);
            }
            catch (\Throwable $e) {
                return self::failure('f3_google_cache_unavailable');
            }
            finally {
                self::unlock($lock);
            }
            });
        if (empty($r['success'])) self::$error=$r['error_code']??'f3_google_cache_write';
        return !empty($r['success']);
    }
    private static function set_locked(string $key,$value,int $ttl): array {
        $path=self::path($key);
        self::refresh_sql_cache($key);
        if (strlen(serialize($value))<=self::MAX_DB_BYTES) {
            set_transient($key,$value,max(0,$ttl));
            if (self::active_value($key)!==$value) return self::failure('f3_google_cache_verify');
            if (!self::remove_file($path)) return self::failure('f3_google_cache_delete');
        }
        else {
            $json=wp_json_encode(['value'=>$value]);
            if (!is_string($json)) return self::failure('f3_google_cache_encode');
            $cipher=Crypto::encrypt($json);
            if (''===$cipher) return self::failure('f3_google_cache_encrypt');
            $raw=self::HEADER.wp_json_encode(['expires'=>time()+max(1,min(86400,$ttl?:3600)),'cipher'=>$cipher]);
            if (strlen($raw)>self::MAX_FILE_BYTES) return self::failure('f3_google_cache_size');
            if (is_link($path)) return self::failure('f3_google_cache_path');
            $pruned=self::prune_locked(false,new Budget(),strlen($raw),$path);
            if (!$pruned['success']||$pruned['remaining']) return self::failure($pruned['error_code']??'f3_google_cache_capacity');
            $tmp=self::dir().'/'.self::prefix().'tmp-'.bin2hex(random_bytes(8)).'.php';
            $fp=@fopen($tmp,'x');
            if (!$fp) return self::failure('f3_google_cache_write');
            $n=fwrite($fp,$raw);
            $flushed=fflush($fp);
            fclose($fp);
            @chmod($tmp,0600);
            if ($n!==strlen($raw)||!$flushed||!@rename($tmp,$path)) {
                self::remove_file($tmp);
                return self::failure('f3_google_cache_write');
            }
            clearstatcache(true,$path);
            if (@file_get_contents($path)!==$raw) return self::failure('f3_google_cache_verify');
            delete_transient($key);
            if (false!==self::active_value($key)) return self::failure('f3_google_cache_delete');
            $sql=self::delete_sql($key);
            if (!$sql['success']) return self::failure($sql['error_code']);
        }
        $prior=Options::stored('f3_mcp_google_cache_health');
        if (!$prior['success']) return self::failure('f3_google_cache_health_read');
        if (($prior['value']['state']??'')==='failed') {
            $saved=Options::set('f3_mcp_google_cache_health',['state'=>'recovered','at'=>time(),'previous_error'=>$prior['value']['error_code']??null]);
            if (!$saved['success']) return self::failure('f3_google_cache_health_persistence');
        }
        return ['success'=>true];
    }
    /** Delete only obsolete SQL rows; never evict a newer active object-cache entry. Caller owns cache lock. */
    private static function delete_sql(string $key): array {
        foreach (['_transient_'.$key,'_transient_timeout_'.$key] as $name) {
            $r=Options::delete($name);
            if (!$r['success']) return ['success'=>false,'error_code'=>'f3_google_cache_migration_delete'];
        }
        return ['success'=>true];
    }
    /** The legacy SQL value and timeout are a single disposable cache entry. */
    public static function migrate_sql(string $key): array {
        if (!self::valid($key)) return ['success'=>false,'error_code'=>'f3_google_cache_key'];
        return Recovery::run(static function() use($key) {
            $lock=self::lock();
            if (!$lock) return ['success'=>false,'error_code'=>'f3_google_cache_busy','retryable'=>true];
            try {
                $source=Options::stored('_transient_'.$key);
                $timeout=Options::stored('_transient_timeout_'.$key);
                if (!$source['success']||!$timeout['success']) return ['success'=>false,'error_code'=>'f3_google_cache_migration_read'];
                $external=function_exists('wp_using_ext_object_cache')&&wp_using_ext_object_cache();
                $expires=(int)($timeout['value']??0);
                if (!$external && $source['exists'] && $expires>time() && !str_starts_with($key,'f3_mcp_google_discovery_')) {
                    $written=self::set_locked($key,$source['value'],$expires-time());
                    if (!$written['success']) return $written;
                }
                // Expired/unknown legacy values are discarded. External cache is authoritative.
                return self::delete_sql($key);
            }
            finally {
                self::unlock($lock);
            }
            });
    }
    public static function delete(string $key): bool {
        if (!self::valid($key)) return false;
        $r=Recovery::run(static function() use($key) {
            $lock=self::lock();
            if (!$lock) return self::failure('f3_google_cache_busy');
            try {
                self::refresh_sql_cache($key);
                delete_transient($key);
                if (false!==self::active_value($key)) return self::failure('f3_google_cache_delete');
                $sql=self::delete_sql($key);
                if (!$sql['success']) return self::failure($sql['error_code']);
                return self::remove_file(self::path($key))?['success'=>true]:self::failure('f3_google_cache_delete');
            }
            finally {
                self::unlock($lock);
            }
            });
        if (empty($r['success'])) self::$error=$r['error_code']??'f3_google_cache_delete';
        return !empty($r['success']);
    }
    private static function prune_locked(bool $purge,Budget $budget,int $reserve=0,string $replace=''): array {
        $out=['success'=>true,'removed'=>0,'remaining'=>false,'error_code'=>null,'retryable'=>false];
        $files=[];
        $bytes=0;
        foreach (glob(self::dir().'/'.self::prefix().'*.php')?:[] as $file) {
            if (!$budget->available()) {
                $out['remaining']=true;
                break;
            }
            if (str_ends_with($file,'lock.php')) continue;
            if (is_link($file)) {
                $out['success']=false;
                $out['error_code']='f3_google_cache_path';
                $out['remaining']=true;
                continue;
            }
            clearstatcache(true,$file);
            $size=@filesize($file);
            $mtime=@filemtime($file);
            if ($size===false||$mtime===false) {
                $out['success']=false;
                $out['error_code']='f3_google_cache_read';
                $out['remaining']=true;
                continue;
            }
            $head=@file_get_contents($file,false,null,0,256);
            if ($head===false) {
                $out['success']=false;
                $out['error_code']='f3_google_cache_read';
                $out['remaining']=true;
            }
            $expired=is_string($head)&&preg_match('/"expires":([0-9]+)/',$head,$m)&&(int)$m[1]<=time();
            if ($purge||$expired||$mtime<time()-86400||str_contains(basename($file),'tmp-')) {
                if ($budget->claim()) {
                    if (self::remove_file($file)) {
                        ++$out['removed'];
                        continue;
                    }
                    $out['success']=false;
                    $out['error_code']='f3_google_cache_delete';
                }
                $out['remaining']=true;
            }
            if ($file===$replace) continue;
            $files[$file]=['size'=>$size,'at'=>$mtime];
            $bytes+=$size;
        }
        uasort($files,static fn($a,$b)=>$a['at']<=>$b['at']);
        foreach ($files as $file=>$info) {
            if (count($files)+($reserve?1:0)<=self::MAX_FILES && $bytes+$reserve<=self::MAX_TOTAL_BYTES) break;
            if (!$budget->claim()) {
                $out['remaining']=true;
                break;
            }
            if (!self::remove_file($file)) {
                $out['success']=false;
                $out['error_code']='f3_google_cache_delete';
                $out['remaining']=true;
                continue;
            }
            ++$out['removed'];
            $bytes-=$info['size'];
            unset($files[$file]);
        }
        if (count($files)+($reserve?1:0)>self::MAX_FILES||$bytes+$reserve>self::MAX_TOTAL_BYTES) {
            $out['success']=false;
            $out['error_code']=$out['error_code']??'f3_google_cache_capacity';
            $out['remaining']=true;
        }
        $out['files']=count($files);
        $out['bytes']=$bytes;
        return $out;
    }
    public static function maintain(bool $purge=false,?Budget $budget=null): array {
        return Recovery::run(static function() use($purge,$budget) {
            $lock=self::lock();
            if (!$lock) return ['success'=>false,'remaining'=>true,'removed'=>0,'error_code'=>'f3_google_cache_busy','retryable'=>true];
            try {
                $r=self::prune_locked($purge,$budget??new Budget());
                if (!$r['success']) {
                    $health=self::failure($r['error_code']);
                    $r['health_persisted']=$health['health_persisted'];
                }
                return $r;
            }
            finally {
                self::unlock($lock);
            }
            });
    }
    private static function failure(string $code): array {
        self::$error=$code;
        $r=Options::set('f3_mcp_google_cache_health',['state'=>'failed','at'=>time(),'error_code'=>$code]);
        return ['success'=>false,'error_code'=>$code,'health_persisted'=>$r['success']];
    }
    public static function last_error(): ?string {
        return self::$error;
    }
    public static function status(): array {
        $r=Options::stored('f3_mcp_google_cache_health');
        return ['database_max_bytes'=>self::MAX_DB_BYTES,'large_payloads'=>'encrypted_php_files','max_files'=>self::MAX_FILES,'max_total_bytes'=>self::MAX_TOTAL_BYTES,'max_file_ttl'=>86400,'last_error'=>self::$error,'read_success'=>$r['success'],'health'=>$r['success']?($r['value']??['state'=>'no_failure_observed']):['state'=>'unknown','error_code'=>'f3_google_cache_health_read']];
    }
}
