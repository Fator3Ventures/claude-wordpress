<?php
/** Cooperative budget shared by every family in one maintenance pass. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Storage;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Budget {
    private static array $automatic=[];
    public static function automatic(): self {
        $site=function_exists('get_current_blog_id')?get_current_blog_id():1;
        return self::$automatic[$site]??(self::$automatic[$site]=new self());
    }
    public const ROWS = 100;
    public const MILLISECONDS = 1000;
    private int $started;
    private int $used = 0;
    private int $limit;
    private int $milliseconds;
    public function __construct(int $limit=self::ROWS,int $milliseconds=self::MILLISECONDS) {
        $this->started=hrtime(true);
        $this->limit=max(1,min(self::ROWS,$limit));
        $this->milliseconds=max(1,min(self::MILLISECONDS,$milliseconds));
    }
    public function available(): bool {
        return $this->used<$this->limit && $this->elapsed()<$this->milliseconds;
    }
    public function claim(): bool {
        if (!$this->available()) return false;
        ++$this->used;
        return true;
    }
    public function remaining(): int {
        return $this->available() ? $this->limit-$this->used : 0;
    }
    public function elapsed(): int {
        return (int)((hrtime(true)-$this->started)/1000000);
    }
    public function result(): array {
        return ['row_limit'=>$this->limit,'time_limit_ms'=>$this->milliseconds,'processed'=>$this->used,'duration_ms'=>$this->elapsed(),'stop_reason'=>$this->used>=$this->limit?'row_limit':($this->elapsed()>=$this->milliseconds?'time_limit':null)];
    }
}
