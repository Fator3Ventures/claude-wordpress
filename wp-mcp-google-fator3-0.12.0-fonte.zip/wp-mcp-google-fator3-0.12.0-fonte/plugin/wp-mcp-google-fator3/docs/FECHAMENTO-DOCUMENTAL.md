# Fechamento documental — 0.12.0

Os documentos editáveis desta árvore são compilados por `build/compile-documents.py` para `includes/Data/Documentation.php`. Painel e `google/documentation` consomem a mesma allowlist. O catálogo de 283 operações e schemas deriva do registro por `build/export-contracts.php`; execute ambos antes de formar o candidato. `build/check-docs.py` verifica correspondência, inventário, links e versão.

O relatório da rodada é externo e canônico. Sua cópia incluída no fonte antecede o fechamento do ZIP fonte; não contém hash circular. O instalador validado não é reconstruído na promoção. Provas anteriores preservadas no fonte são históricas e não contam como execução da 0.12.0.
