# Validação — 0.12.0

Escopo: Pedido MCP Google 26 e P12-01 a P12-05; regressão do Pedido 25. Bancada: WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46. Matriz principal: Core 1.38.0, MCP 0.24.0 e Meta/LinkedIn 0.3.0; Core 1.35.0 e ausência para transição opcional. Atualização Google direta 0.11.0→0.12.0.

`tools/release012.py` vincula o candidato por SHA-256 aos ensaios nativos e ao inventário instalado. Os testes cobrem contrato adversário, produtor real, booleanos persistidos e relidos em outra requisição, autorização administrativa/MCP, revisão de conversões durante GTM simulado, instalação limpa, isolamento, atualização, rollback e documentação paginada íntegra. Os processos usam banco descartável e transportes externos bloqueados; fixtures não entram no instalador.

Os resultados e contagens efetivamente aprovados estão no relatório externo e em evidence/012 no fonte. Evidências 011 e anteriores são históricas, sem certificar esta versão. A suíte específica não é a execução integral do PHPUnit nem do gate histórico `tools/validate.py`/`build/build.py verify`; esses continuam disponíveis com seus próprios requisitos completos.

As APIs Google reais, jobs/calendário/exportação em contas de produção (pendência 20), navegador, multisite, CDN e cron externo continuam fora da homologação desta rodada. O leitor local não prova entrega de conversões. Provas recebidas dos acompanhantes são distinguidas das verificações próprias. O Site-Teste é verificado em requisição nova, com backup do pacote e sem alteração comercial; seu resultado exato fica no relatório externo.
