# Impacto de wp-mcp-google-fator3 0.12.0 em base-site-core-fator3

Data/hora: 2026-10-19T00:56:31-03:00 · Revisão: 4 · Etapa: entrega
Situação: **resolvido no aceite do consumidor Google**; não implica homologação de fornecedores.
Base: Google 0.11.0 · Alvo entregue: 0.12.0
Instalador emissor: `wp-mcp-google-fator3-0.12.0-instalador.zip`, SHA-256 `d2499a5f0b2b89b5640dc86a780fc8a73335dc20d06003eb22b7185ce98162c0`.
Destinatário: Core 1.38.0, SHA-256 `1b0de25e1dd4276fe7f7d8e428dfc0eb01a249d4108f680aa65bd3a4de3e59ee`; schemas comparados com 1.36.0; transição funcional 1.35.0→1.38.0.
Natureza: contrato e validação integrada · Classificação: validacao-coordenada
Referência: P12-01/P12-02/P12-03; vínculo Pedidos core 222, sem reabrir o aceite do produtor.

## Mudança e consequência

Google adotou `F3Base_Conversoes_Contexto::capabilities()/snapshot(array)` pelo contrato público `site-conversion-purposes/1.0.0`, com cópias próprias e conferidas dos schemas. `google/conversion-context` expõe leitura local administrativa. `gtm/diagnostico` acrescenta `core_conversion_context`, comparando a revisão de medição e revalidando a de conversões depois do GET GTM existente.

Preservados: schema_revision string "1", provider, dois métodos, snapshot sem paginação, quatro destinos, false/null/vazios, procedência e identificação das duas finalidades por purpose. Material não herda rótulo Ads/ID LinkedIn de contato. Nenhum campo foi acrescentado ao contrato antigo de medição. Não há leitura de options privadas, criação de recursos, mudança de emissor ou consentimento.

Ausência do produtor é `unavailable` somente no envelope local do consumidor; o enum original do produtor não foi alterado. Falhas mantêm data:null. Na leitura nova, falha é explícita; no GTM, a indisponibilidade adicional não invalida um diagnóstico antigo válido. Revisão divergente descarta o bloco adicional sem repetir chamada remota.

## Evidência do consumidor e compatibilidade

- 41 verificações de contrato: fixtures publicadas, descritor, tipos, duplicação/ordem de finalidades, exceção sanitizada, revisões e UTC; schemas originais preservados.
- Core 1.38.0 real em WordPress: IDs próprios/vazios, material desabilitado, procedência filtrada, gates, leitura MCP e consistência GTM com fornecedor simulado. Suíte conversions012: 38 asserções por execução.
- Core antigo/ausente e ordens Google-primeiro/Core-primeiro aprovados. Core 1.36.0 não foi executado: apenas seus quatro schemas comparados byte a byte com 1.38.0. Não foi executado downgrade do Core.
- Site-Teste: novo consumidor executado com Core 1.38.0; success/ok true, material download_material, IDs locais incompletos, runtime_verified/remote_access_verified false; stale revision recusada com data:null.

A leitura local não homologa GA4, Ads, GTM, Meta ou LinkedIn. Google não exige Core novo por número; negocia a capacidade. A instalação e as funções próprias permanecem independentes.

## Ação e encerramento

Nenhuma alteração adicional de código no Core foi necessária. Este documento devolve o aceite Google solicitado no retorno Core r3. O responsável Core pode registrar a evidência do consumidor; qualquer evolução futura de contrato deverá ser encaminhada antes de alterar esta fronteira. Não foi declarado implementado trabalho alheio nem enviado relatório a terceiros.

## Histórico

r1: proposta no planejamento. r2: alinhamento após retorno Core; aceite Google pendente. r3: início da implementação com Core 1.38.0 entregue e schemas equivalentes. r4: consumidor entregue e aceite próprio encerrado no escopo acima. O antigo impacto Google 0.11.0→Core permanece histórico na r3, sem renumerar a release congelada.
