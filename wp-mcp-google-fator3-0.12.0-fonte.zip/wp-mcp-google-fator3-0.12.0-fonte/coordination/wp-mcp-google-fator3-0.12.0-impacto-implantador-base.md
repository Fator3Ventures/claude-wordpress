# Impacto de wp-mcp-google-fator3 0.12.0 em implantador-base

Data/hora: 2026-10-19T00:57:03-03:00 · Revisão: 2
Etapa: entrega · Situação: alinhado; correção Google validada, confirmação do destinatário pendente
Versão-base: Google 0.11.0 liberada · Versão-alvo: 0.12.0 entregue
Instalador alvo: `wp-mcp-google-fator3-0.12.0-instalador.zip`, 721839 bytes, SHA-256 `d2499a5f0b2b89b5640dc86a780fc8a73335dc20d06003eb22b7185ce98162c0`. Base SHA-256: `d181deaeee8ef365ac4d6a08884d9fa3d3a3164b21f0538d8ed5d56722536bf9`.
Destinatário: Fator3 Implantador 2.9.0; slug/basename `implantador-base/implantador-base.php`, confirmados em `implantador-base-2.9.0-relatorio.md` revisão documental de 17/10/2026. Hash recebido do instalador: `3911c358e9162e823e4145760806ca17a8d93728b50e818b96f37dc6002b1f5e`; pacote não executado nesta rodada.
Natureza: bug de tipagem do contrato de configuração 4.0.0
Classificação: validacao-coordenada
Tickets: **Pedido MCP Google 26**, origem **IMP-GOOGLE-01**.

## Mudança e consequência

WordPress pode reler false persistido como string vazia. Google 0.11.0 repassa esse valor em `effective_value` de `audit_local_reads` e `purge_on_uninstall`, embora declare booleano. O Implantador 2.9.0 relata tratamento restrito a `audit_local_reads` para reconhecer essa representação.

Google 0.12.0 normaliza a leitura pública das opções booleanas para true/false, sem alterar armazenamento, opções textuais, credenciais ou permissões. As três opções booleanas que já usam leitores tipados foram mantidas. O contrato 4.0.0 permanece: a correção cumpre o tipo já declarado.

## Ação e critério de aceite

Google: testar gravar false, ler em nova requisição por `google/configuration-schema`, e confirmar false booleano nas conexões padrão e nomeada; testar também true e preservar null/vazios de campos não booleanos. Implantador: quando adotar a 0.12.0, repetir a confirmação pelo seu adaptador por conexão, mantendo compatibilidade com 0.11.0 se necessária. Não há obrigação de remover o tratamento anterior nem bloqueio à implementação Google.

## Compatibilidade e sequência

Atualização direta Google 0.11.0→0.12.0, sem migração. Implantador não é dependência do Google e não será instalado no Site-Teste em operação. Prova integrada do fluxo inteiro do Implantador fica com seu responsável; as provas Google e transporte MCP serão entregues aqui.

## Evolução

Revisão 1: encaminhamento criado antes da implementação a partir da aba Google de 18/10 e do relatório Implantador 2.9.0. Nenhuma mensagem enviada nem alteração no pacote destinatário.

## Resultado da entrega — revisão 2 — 2026-10-19T00:56:31-03:00

Pedido 26 implementado e validado em WordPress 7.1.2/PHP 8.3.6, com escrita pública via google/configure-local e expected_revision obrigatório, seguida de google/configuration-schema em requisição HTTP MCP nova. A suíte booleans012 passou com 67 asserções por cenário em clean, upgrade e instalação MCP. As cinco opções booleanas foram exercitadas: enabled, ga_enabled, ads_enabled, audit_local_reads e purge_on_uninstall; true/false persistidos, representação WordPress "1"/"", conexões padrão/nomeada e leitor administrativo com canal fechado. Campo textual vazio permaneceu string.

O Site-Teste foi atualizado à 0.12.0, sem modificar preferências; a configuração selecionada e sua revisão foram preservadas. A prova de escrita false persistida foi feita no laboratório descartável, não mediante alteração da configuração do site compartilhado. Nenhuma alegação de execução do Implantador 2.9.0 é feita.

Ação restante do destinatário: confirmar sua etapa de configuração/confirmação por conexão usando a 0.12.0 e registrar o aceite de IMP-GOOGLE-01. O adaptador legado para 0.11.0 pode permanecer; não há obrigação de retirá-lo. O Google não alterou o Implantador nem encerrou o pedido na lista central. Referência completa: wp-mcp-google-fator3-0.12.0-relatorio.md r1.
