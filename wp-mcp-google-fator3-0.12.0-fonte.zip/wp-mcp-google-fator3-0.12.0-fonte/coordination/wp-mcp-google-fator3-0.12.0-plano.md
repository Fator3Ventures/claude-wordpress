# Plano — Fator3 MCP Google 0.12.0

Revisão 4 · Data/hora: 2026-10-19T00:56:31-03:00 · Etapa: entrega
Base liberada: 0.11.0 · Alvo entregue: **0.12.0** · Status: concluído no escopo testado.
Slug/basename: `wp-mcp-google-fator3/wp-mcp-google-fator3.php`.
Instalador: `wp-mcp-google-fator3-0.12.0-instalador.zip`, 721839 bytes, SHA-256 `d2499a5f0b2b89b5640dc86a780fc8a73335dc20d06003eb22b7185ce98162c0`.

## Escopo e resultado

| Item | Resultado |
|---|---|
| P12-01 | Consumidor separado do SDK opcional `site-conversion-purposes/1.0.0`, schemas fixados, falhas explícitas e dados preservados. |
| P12-02 | `google/conversion-context` com gate administrativo/canal/perfil, sem credencial Google; callback direto protegido. |
| P12-03 | `core_conversion_context` adicional no diagnóstico GTM, com coerência de revisões e indisponibilidade restrita ao bloco. |
| P12-04 | 283 operações, 19 documentos instalados, catálogo e schemas gerados e verificados. |
| P12-05 | Clean, upgrade direto, duas ordens com Core, isolamento, instalação MCP e rollback Google aprovados; Site-Teste atualizado. |
| P12-06 / Pedido MCP Google 26 | `effective_value` true/false para os cinco booleanos declarados, incluindo false persistido pelo WordPress. |

P12-06 foi acrescentado na revisão 3 a partir da aba Google de 18/10 e IMP-GOOGLE-01. Não é uma renumeração de pedido central. Pedido 25 preservado; não se cria Pedido 27.

## Contratos e decisões preservadas

O contrato antigo `site-measurement-context/1.0.0` não recebeu `download_material`. Contato e material são separados pelo novo SDK; vazio/null não herdam IDs de contato. A leitura não cria eventos-chave, ações Ads, tags, publicações, campanhas, conexões, grants ou jobs. Nenhuma migração, permissão reduzida ou dependência artificial foi introduzida. As flags de verificação remota/runtime permanecem false.

Normas: ambas revisão 4, 16/10/2026, relidas integralmente. Base Google 0.11.0: instalador SHA-256 `d181deaeee8ef365ac4d6a08884d9fa3d3a3164b21f0538d8ed5d56722536bf9`; fonte `c142e10c544a73008bf4c132b85b36cd921fd6313aff5491e99dce61ba12c37e`.

## Evidência e limites

683 asserções aprovadas: 642 nativas em cinco laboratórios e 41 contratuais, incluindo repetições por cenário. WordPress 7.1.2/PHP 8.3.6/MySQL 8.0.46; matriz Core 1.38.0/MCP 0.24.0/sociais 0.3.0, transição Core 1.35→1.38 e ausência. Core 1.36.0 teve os quatro schemas comparados, sem execução própria dessa combinação. Downgrade do Core não foi exercitado.

Site-Teste: WordPress 7.1.3/PHP 8.3.30, Google 0.12.0 ativo, healthy true, configuração selecionada preservada. Leitor e conflito executados; 19 documentos/60 páginas completos e hashes idênticos; dez arquivos alterados conferidos; backup `38ea419cb8e4f6cfd8e285af` pronto em prévia de rollback. Detalhes e limites no `wp-mcp-google-fator3-0.12.0-relatorio.md` r1 e nas evidências do fonte.

Permanecem: homologação em APIs Google reais/pendência 20, confirmação do fluxo do Implantador, navegador/multisite/CDN/cron externo e publicação/distribuição pela frota. Não há alegação de PHPUnit integral ou aprovação do gate histórico abrangente. Essas pendências não são convertidas em sucesso.

## Encaminhamentos vigentes

- `wp-mcp-google-fator3-0.12.0-impacto-base-site-core-fator3.md` r4: aceite do consumidor Google resolvido no escopo testado; nenhuma mudança no Core solicitada.
- `wp-mcp-google-fator3-0.12.0-impacto-implantador-base.md` r2: correção entregue e comprovada no Google; validação pelo Implantador pendente.

MCP e sociais: regressões pertinentes aprovadas, sem novo impacto que exija documento individual. Implantador identificado pelo relatório 2.9.0 como `implantador-base/implantador-base.php`; pacote não executado nem alterado.

## Histórico de decisões

1. Revisão 1 — 17/10: proposta P12-01 a P12-05, contrato Core 1.36.0, impacto de validação coordenada.
2. Revisão 2 — 17/10: retorno Core r3 incorporado; contrato suficiente, sem aguardar Core 1.37.0 então condicional.
3. Revisão 3 — 19/10: implementação autorizada; Core 1.38.0 entregue e equivalente; Pedido 26/P12-06 e impacto Implantador registrados antes da correção.
4. Revisão 4 — 2026-10-19T00:56:31-03:00: implementação, validação e instalação de teste concluídas; documentos atualizados para entrega. As revisões anteriores são históricas, sem prevalecer sobre o estado atual.
