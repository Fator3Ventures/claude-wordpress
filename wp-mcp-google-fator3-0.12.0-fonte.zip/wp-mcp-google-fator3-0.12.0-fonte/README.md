# Fonte — Fator3 MCP Google 0.12.0

`plugin/wp-mcp-google-fator3/` contém o fonte completo, os documentos editáveis,
schemas, fixtures, testes, build e ferramentas. Os arquivos de runtime comuns
são exatamente os mesmos do instalador validado. `evidence/012/` contém as provas
sanitizadas desta rodada; provas anteriores no fonte são históricas.

Reprodução do instalador e validação: leia `plugin/wp-mcp-google-fator3/tools/README.md`.
Forneça os insumos externos identificados nas evidências. Não são incluídos
banco, configuração do laboratório, credenciais ou runtime de ferramentas.

O relatório interno é anterior ao fechamento do fonte. Nome, tamanho e SHA-256
final do fonte constam somente no relatório externo canônico. O instalador é o
único ZIP instalável; não instalar este fonte no WordPress.

Para reproduzir o empacotamento do fonte, execute o script deste diretório build
com --source, --installer, --report, --evidence e --output apontando para os
artefatos fechados. O script usa data ZIP fixa e ordenação determinística.
