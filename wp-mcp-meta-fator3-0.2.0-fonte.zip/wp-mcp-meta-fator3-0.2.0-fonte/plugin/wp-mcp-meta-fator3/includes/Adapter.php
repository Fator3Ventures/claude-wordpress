<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
final class Adapter {
    public static function base(array $c): string {return 'https://graph.facebook.com/'.$c['api_version'].'/';}
    public static function encode(array $q): string {return http_build_query($q,'','&',PHP_QUERY_RFC3986);}
    public static function allowed(string $path,string $method): bool {return $method==='GET'&&(bool)preg_match('~^(?:debug_token|me(?:/(?:accounts|permissions))?|[0-9]{1,40}(?:_[0-9]{1,40})?(?:/(?:media|stories|insights|posts|videos|ratings))?)$~D',$path);}
    public static function reports(): array {return Catalog::reports();}
    public static function fields(string $report): array {return Catalog::fields($report);}
    private static function after(array $r): ?string {
        if(empty($r['paging']['next']))return null;
        if(!is_string($r['paging']['cursors']['after']??null)||$r['paging']['cursors']['after']==='')throw new Fault('coverage_incomplete','A origem informou continuação sem cursor seguro.');
        return $r['paging']['cursors']['after'];
    }
    public static function accounts(array $c,array $i): array {
        $q=['fields'=>'id,name,instagram_business_account{id,username,name}','limit'=>50];if(!empty($i['after']))$q['after']=$i['after'];
        $r=Http::request($c,'me/accounts',$q)['body'];if(!is_array($r['data']??null))throw new Fault('upstream_invalid','Lista de Páginas inválida.');
        $rows=[];foreach($r['data'] as $p){if($i['channel']==='facebook')$rows[]=['id'=>(string)$p['id'],'name'=>$p['name']??null];elseif(isset($p['instagram_business_account']['id']))$rows[]=['id'=>(string)$p['instagram_business_account']['id'],'username'=>$p['instagram_business_account']['username']??null,'name'=>$p['instagram_business_account']['name']??null,'page_id'=>(string)$p['id']];}
        return ['rows'=>$rows,'continuation'=>self::after($r),'limitation'=>'A seleção é explícita; a descoberta nunca concede acesso nem retorna tokens.'];
    }
    public static function credential(array $c,string $channel,string $account): array {
        if($channel!=='facebook')return $c;
        Access::asset($c,'facebook',$account);
        $cache=Store::get('page_credential',$c['id'].':'.$account);if($cache&&($cache['value']['generation']??0)===$c['credential_generation']){$c['token']=$cache['value']['token'];return $c;}
        // The Page token is requested only for an explicitly selected Page and is never projected publicly.
        $r=Http::request($c,$account,['fields'=>'id,access_token'])['body'];
        if((string)($r['id']??'')!==$account||empty($r['access_token'])||!is_string($r['access_token'])||strlen($r['access_token'])>16384||preg_match('/[\x00-\x20]/',$r['access_token']))throw new Fault('page_token_unavailable','Não foi possível derivar o token da Página selecionada.');
        Store::lock('page-token:'.$c['id'].':'.$account,static function()use($c,$account,$r){Connections::revalidate($c);$key=$c['id'].':'.$account;$old=Store::get('page_credential',$key);Store::put('page_credential',$key,['token'=>$r['access_token'],'generation'=>$c['credential_generation']],$old['revision']??0);});
        $c['token']=$r['access_token'];return $c;
    }
    public static function validate(array $c,string $channel,string $account): array {
        $c=self::credential($c,$channel,$account);$r=Http::request($c,$account,['fields'=>$channel==='facebook'?'id,name':'id,username'])['body'];
        if((string)($r['id']??'')!==$account)throw new Fault('asset_access_denied','Identidade de conta divergente.');
        return ['account_id'=>$account,'channel'=>$channel,'metadata_read'=>true,'insights_read'=>false,'app_approval_verified'=>false,'checked_at'=>gmdate('c')];
    }
    public static function page(array $c,array $i,array $s): array {
        $account=Util::numeric($i['account_id']);$report=$i['report'];
        if(Catalog::channel($report)!==$i['channel'])throw new Fault('invalid_input','O relatório não pertence ao canal selecionado.');
        $c=self::credential($c,$i['channel'],$account);$fields=$i['fields']??[];
        if(!$fields)$fields=match($report){'profile'=>['id','username','followers_count','media_count'],'page_profile'=>['id','name','fan_count','followers_count'],'media'=>['id','caption','media_type','media_product_type','timestamp','permalink'],'stories'=>['id','media_type','timestamp'],'page_posts'=>['id','message','created_time','permalink_url'],'page_videos'=>['id','title','created_time','permalink_url'],'page_ratings'=>['created_time','recommendation_type','review_text'],'audience'=>['follower_demographics'],'page_audience'=>['page_fans_country'],'page_insights'=>['page_media_view'],'post_insights'=>['post_media_view'],'video_insights'=>['total_video_views'],'stories_insights'=>['reach','views'],default=>['reach','views']};
        $out=['rows'=>[],'next'=>null,'warnings'=>[],'errors'=>[],'origin_complete'=>null,'timezone'=>'provider_defined','currency'=>null,'temporal'=>'snapshot','fields'=>$fields];
        if(in_array($report,['profile','page_profile'],true)){$r=Http::request($c,$account,['fields'=>implode(',',array_unique(array_merge(['id'],$fields)))])['body'];if((string)($r['id']??'')!==$account)throw new Fault('upstream_invalid','Conta divergente.');$out['rows']=[$r];return $out;}
        if(in_array($report,['media','stories','page_posts','page_videos','page_ratings'],true))return self::inventory($c,$i,$s,$fields,$out);
        if($report==='stories_insights'||($report==='media_insights'&&!empty($i['iterate_media'])))return self::capture($c,$i,$s,$fields,$out);
        if(in_array($report,['account_insights','page_insights'],true)&&($i['granularity']??'interval')==='day')return self::daily($c,$i,$s,$fields,$out);
        $index=(int)($s['metric']??0);if(!isset($fields[$index]))throw new Fault('invalid_cursor','Métrica inválida.');$metric=$fields[$index];$entity=$account;$q=['metric'=>$metric];
        if(in_array($report,['media_insights','post_insights','video_insights'],true)){$entity=$i['media_id']??$i['entity_id']??'';self::owner($c,$entity,$account,$i['channel']);$out['warnings'][]='Métrica acumulada observada agora; não distribuída retroativamente.';}
        elseif(in_array($report,['audience','page_audience'],true)){$q+=['period'=>'lifetime'];if($report==='audience')$q+=['metric_type'=>'total_value','timeframe'=>$i['timeframe']??(in_array('last_30_days',Catalog::timeframes($metric,$c['api_version']),true)?'last_30_days':'this_month'),'breakdown'=>$i['breakdown']??'country'];$out['warnings'][]='Demografia sujeita a supressão e disponibilidade; ausência não equivale a zero.';}
        else{$d=Util::dates($i,30);$q+=['period'=>'day','since'=>$d['date_from_ts'],'until'=>$d['date_to_ts']+86400];if($i['channel']==='instagram')$q['metric_type']=in_array($metric,['follower_count','online_followers'],true)?'time_series':'total_value';if($metric==='follows_and_unfollows')$q['breakdown']='follow_type';$out['temporal']='interval';}
        self::insights($c,$entity,$q,[$metric],$out,null);
        if($index+1<count($fields))$out['next']=['metric'=>$index+1];return $out;
    }
    private static function inventory(array $c,array $i,array $s,array $fields,array $out): array {
        $edge=match($i['report']){'page_posts'=>'posts','page_videos'=>'videos','page_ratings'=>'ratings',default=>$i['report']};$q=['fields'=>implode(',',$fields),'limit'=>$i['limit']??50];if(isset($s['after']))$q['after']=$s['after'];
        $r=Http::request($c,$i['account_id'].'/'.$edge,$q)['body'];if(!is_array($r['data']??null))throw new Fault('upstream_invalid','Inventário inválido.');$rows=$r['data'];
        if(isset($i['date_from'],$i['date_to'])){$d=Util::dates($i,3660);$rows=array_values(array_filter($rows,static function($row)use($d){$t=strtotime($row['timestamp']??$row['created_time']??'');return $t!==false&&$t>=$d['date_from_ts']&&$t<$d['date_to_ts']+86400;}));}
        $out['rows']=$rows;$after=self::after($r);$out['next']=$after?['after'=>$after]:null;$out['temporal']=$edge==='stories'?'ephemeral_snapshot':'publication';$out['warnings'][]=$edge==='stories'?'Somente Stories ainda disponíveis na origem.':'A paginação percorre o inventário da origem; não presume cobertura histórica integral.';return $out;
    }
    private static function owner(array $c,string $entity,string $account,string $channel): void {
        if(!preg_match('/^[0-9]{1,40}(?:_[0-9]{1,40})?$/D',$entity))throw new Fault('invalid_input','Identificador de mídia inválido.');
        $r=Http::request($c,$entity,['fields'=>$channel==='instagram'?'id,owner':'id,from'])['body'];$owner=$channel==='instagram'?($r['owner']['id']??$r['owner']??''):($r['from']['id']??'');
        if((string)$owner!==$account||(string)($r['id']??'')!==$entity)throw new Fault('asset_access_denied','A mídia não pertence à conta selecionada.');
    }
    private static function daily(array $c,array $i,array $s,array $fields,array $out): array {
        $d=Util::dates($i,3660);$day=(int)($s['day']??$d['date_from_ts']);$metricAt=(int)($s['metric']??0);$limit=$i['limit']??100;$out['temporal']='daily';$out['timezone']='UTC request boundaries; provider bucket semantics preserved';
        // One day per remote request group: never split an interval total into invented daily values.
        while($day<=$d['date_to_ts']&&count($out['rows'])<$limit){
            $room=$limit-count($out['rows']);$slice=array_slice($fields,$metricAt,min($room,count($fields)-$metricAt));
            $group=[];$type=null;$breakdown=null;
            foreach($slice as $f){$t=in_array($f,['follower_count','online_followers'],true)?'time_series':'total_value';$b=$f==='follows_and_unfollows'?'follow_type':null;if($group&&($t!==$type||$b!==$breakdown))break;$group[]=$f;$type=$t;$breakdown=$b;}
            if(!Http::remaining(count($group)+1)){$out['next']=['day'=>$day,'metric'=>$metricAt];break;}
            $q=['metric'=>implode(',',$group),'period'=>'day','since'=>$day,'until'=>$day+86400];if($i['channel']==='instagram')$q['metric_type']=$type;if($breakdown)$q['breakdown']=$breakdown;
            self::insights($c,$i['account_id'],$q,$group,$out,gmdate('Y-m-d',$day));$metricAt+=count($group);
            if($metricAt>=count($fields)){$metricAt=0;$day+=86400;}
        }
        if($day<=$d['date_to_ts'])$out['next']=['day'=>$day,'metric'=>$metricAt];return $out;
    }
    private static function insights(array $c,string $entity,array $q,array $metrics,array &$out,?string $day): void {
        try{$r=Http::request($c,$entity.'/insights',$q)['body'];if(!is_array($r['data']??null))throw new Fault('upstream_invalid','Insights inválidos.');$seen=[];
            foreach($r['data'] as $row){$metric=$row['name']??'';if(!in_array($metric,$metrics,true))throw new Fault('upstream_invalid','Métrica não solicitada.');$seen[]=$metric;
                $base=['entity_id'=>$entity,'metric'=>$metric,'period'=>$row['period']??null,'date'=>$day,'value'=>null,'breakdowns'=>[],'end_time'=>null,'availability'=>'available'];
                if(array_key_exists('total_value',$row)){$base['value']=$row['total_value']['value']??null;$base['breakdowns']=$row['total_value']['breakdowns']??[];$out['rows'][]=$base;}
                elseif(is_array($row['values']??null)&&count($row['values'])){
                    if($day!==null){$values=$row['values'];$base['source_values']=$values;$base['value']=count($values)===1?($values[0]['value']??null):null;$base['end_time']=count($values)===1?($values[0]['end_time']??null):null;$out['rows'][]=$base;}
                    else foreach($row['values'] as $v)$out['rows'][]=array_merge($base,['value'=>$v['value']??null,'end_time'=>$v['end_time']??null]);
                }else self::missing($out,$entity,$metric,$day,'value_unavailable');
            }
            foreach(array_diff($metrics,$seen) as $metric)self::missing($out,$entity,$metric,$day,'empty_or_suppressed');
        }catch(Fault $e){if(!in_array($e->reason,['upstream_validation','resource_not_found'],true))throw $e;
            // A rejected group is retried individually so one unsupported metric cannot hide valid peers.
            if(count($metrics)>1){foreach($metrics as $metric){$one=$q;$one['metric']=$metric;self::insights($c,$entity,$one,[$metric],$out,$day);}}
            else self::missing($out,$entity,$metrics[0],$day,'unsupported_for_asset_or_version');
        }
    }
    private static function missing(array &$out,string $entity,string $metric,?string $day,string $code): void {$out['errors'][]=['field'=>$metric,'date'=>$day,'entity_id'=>$entity,'code'=>$code];$out['rows'][]=['entity_id'=>$entity,'metric'=>$metric,'date'=>$day,'value'=>null,'availability'=>$code];}
    private static function capture(array $c,array $i,array $s,array $fields,array $out): array {
        $edge=$i['report']==='stories_insights'?'stories':'media';$out['temporal']=$edge==='stories'?'ephemeral_snapshot':'snapshot_or_lifetime';
        $ids=$s['ids']??[];$after=$s['after']??null;$at=(int)($s['at']??0);
        if(!$ids){$q=['fields'=>'id,timestamp,media_type,media_product_type','limit'=>5];if($after)$q['after']=$after;$r=Http::request($c,$i['account_id'].'/'.$edge,$q)['body'];if(!is_array($r['data']??null))throw new Fault('upstream_invalid','Inventário inválido.');$ids=$r['data'];$after=self::after($r);$at=0;}
        $metricAt=(int)($s['metric']??0);$limit=$i['limit']??100;$stop=false;
        for(;$at<count($ids);$at++){
            $m=$ids[$at];$entity=Util::numeric((string)($m['id']??''));
            if(isset($i['date_from'],$i['date_to'])){$d=Util::dates($i,3660);$stamp=strtotime($m['timestamp']??'');if($stamp===false||$stamp<$d['date_from_ts']||$stamp>=$d['date_to_ts']+86400){$metricAt=0;continue;}}
            for(;$metricAt<count($fields);$metricAt++){
                if(!Http::remaining(1)||count($out['rows'])>=$limit){$stop=true;break;}
                $start=count($out['rows']);$metric=$fields[$metricAt];self::insights($c,$entity,['metric'=>$metric],[$metric],$out,null);
                for($n=$start;$n<count($out['rows']);$n++)$out['rows'][$n]+=['published_at'=>$m['timestamp']??null,'observed_at'=>gmdate('c'),'media_type'=>$m['media_type']??null,'media_product_type'=>$m['media_product_type']??null];
            }
            if($stop)break;$metricAt=0;
        }
        if($at<count($ids))$out['next']=['ids'=>$ids,'at'=>$at,'metric'=>$metricAt,'after'=>$after];elseif($after)$out['next']=['after'=>$after];
        $out['warnings'][]=$edge==='stories'?'Snapshot das Stories disponíveis; nenhum arquivo de mídia é arquivado.':'Insights acumulados atuais das mídias encontradas; sem reconstrução retroativa.';return $out;
    }
}
