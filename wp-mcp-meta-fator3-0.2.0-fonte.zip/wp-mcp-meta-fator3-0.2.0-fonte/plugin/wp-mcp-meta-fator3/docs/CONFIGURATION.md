# Configuração Meta — 0.2.0

Cadastre token, versão Graph (padrão v24.0) e IDs de Instagram profissional e/ou Facebook Pages. A descoberta lista candidatos; nenhum ativo é selecionado automaticamente. O modo Instagram implementado usa Facebook Login e Página vinculada. Os produtos e permissões do aplicativo precisam permitir cada consulta. A aprovação de anúncios não é inferida como autorização de métricas orgânicas.

`save-connection` requer expected_revision. Token vazio mantém o atual; clear_token remove. `get-connection` omite segredos. Retenção finita usa retention_days (1–3650); retention_mode=unlimited remove a expiração automática do histórico existente e das próximas páginas. Alterar a retenção não recupera páginas já removidas.

Facebook usa token de Página derivado somente de uma Página explicitamente selecionada. Ele fica cifrado, separado das projeções públicas e vinculado à geração da credencial. Não é exportado nem retornado pela descoberta. Métricas de posts e vídeos verificam o proprietário do objeto.

`rotate-token` exige Meta App ID (client_id) e client_secret, verifica /me e /debug_token com autenticação de aplicativo e confirma o mesmo app, principal, permissões anteriores e ativos antes de gravar. A configuração application_id isolada não é prova remota. O token inspecionado segue o protocolo oficial em input_token; a auditoria local não registra URL nem credencial. A identidade previamente validada permite renovar token expirado. Sem essa prova, o token antigo precisa estar utilizável; caso contrário, reconfigure e revise agendas explicitamente. Rotação assistida limitada a 12 ativos por conexão.

Há três contadores distintos: revisão de configuração (CAS), authorization_revision (seleção/permissão) e credential_generation (troca de token). Alterar nome, expiração ou retenção não muda a autorização do plano. Trocar token por save-connection invalida a revisão de autorização e exige revisar planos antigos; validar a conta depois não reautoriza implicitamente o contexto anterior. rotate-token preserva a autorização quando a identidade é comprovada. Mudanças de ativos, usuários legados, versão da API ou enabled invalidam planos anteriores.
