# Migração e rollback — Meta 0.2.0

Mantenha backup do banco, salts, instalador 0.1.0 e estado de ativação. A atualização preserva slug, arquivo principal, namespace, REST, prefixo, tabela f3_meta_records e opções. Adiciona f3_meta_history e índices próprios. Não desinstale para atualizar.

A estrutura histórica é criada no bootstrap/ativação; migração de resultados antigos é incremental (25 páginas por passo), com checkpoint em migration/history-020. history-status informa progresso. history-migrate e manutenção avançam sem HTTP externo. Páginas ainda retidas são copiadas; páginas expiradas são contadas e não ressuscitadas. Dados de usuário/ativo revogado não são expostos; bloqueios são contabilizados. O legado permanece cifrado no bucket result até a retenção original.

A retenção de jobs não remove um pai enquanto existirem páginas. O histórico migrado não depende desse pai. Ativos e formulários antigos conservam sua seleção; defaults novos não concedem acesso. Agendas antigas cuja revisão já divergia exigem revisão explícita; não são reinterpretadas silenciosamente.

Rollback: pause agendas, restaure instalador e banco do mesmo backup de 0.1.0, preservando salts. Somente trocar o código deixa estruturas novas e políticas de retenção que a 0.1.0 desconhece. A desinstalação da 0.2.0 preserva dados; a rotina de uninstall da 0.1.0 é destrutiva, portanto não a execute para voltar versão.
