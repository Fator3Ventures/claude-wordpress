# 0.2.0

- Gate manage_options em todas as entradas humanas e revalidação de tarefas.
- Documentação completa instalada, índice, paginação UTF-8 e revisão/hash.
- Catálogo versionado, séries diárias e grupos de métricas compatíveis.
- Canal Facebook, tokens de Página privados e propriedade de objetos.
- Histórico cifrado independente de jobs, retenção sem expiração, migração, deduplicação e exportação em partes.
- Backfill com início explícito, janela final congelada e retomada.
- Capturas periódicas de mídias/Stories e rotação validada de token.
- Desinstalação conserva dados.

Homologação de métricas reais, disponibilidade de dois anos e comportamento por tipo de mídia dependem dos ativos/escopos do dono; não são deduzidos dos testes simulados.
