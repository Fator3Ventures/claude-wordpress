# Contratos públicos — 0.2.0

Namespace REST preservado: `/wp-json/f3-meta/v1/{operation}`, POST JSON autenticado. Cookie administrativo exige nonce REST; credenciais MCP também passam pela política do transporte. Abilities preservam prefixo `meta/`. Consulte `contracts` e `input-schemas.json`; todos os objetos de entrada são fechados e parâmetros desconhecidos são recusados. IDs remotos são strings, não números de ponto flutuante.

Envelope: `success`, `code`, `provider`, `version` e `data` em sucesso. Falha: `error_code`, `message`, `conflict`, `retryable`, `details`, `data=null`. Um sucesso local não implica homologação externa. `not_authorized` é HTTP 403 em REST; os demais códigos de domínio usam envelope estruturado.

Relatórios mantêm contrato social-reporting/1.0.0; Meta estende para social-reporting/1.1.0 com linhas diárias e disponibilidade. Nenhum campo anterior é removido. Preserve seleção e next_cursor até esgotar. `coverage.complete` exige fim do plano e nenhuma indisponibilidade registrada; `all_rows_guaranteed` pode ser null. Inventário completo da resposta não comprova todo o histórico remoto.

Revisões são obrigatórias para configuração, agendas, concessões e controle de tarefas. Chaves idempotentes locais têm no máximo 64 caracteres; o transporte pode ter limites próprios. Não reutilize uma chave para outra intenção. Listagens administrativas usam `offset` e `next_offset`; get-connection/get-grant permitem releitura de uma configuração precisa. A falta de uma página não autoriza inferir que os outros registros não existem.

Erros estáveis incluem invalid_input, not_authorized, asset_access_denied, revision_conflict, credential_revalidation_required, rate_limited, upstream_error, operation_uncertain, history_changed, response_limit, storage_unavailable e persistence_unconfirmed. Não trate resultado incerto como autorização para reenviar uma mutação.
