# Validação da implementação 0.13.0

**Gate de release: pendente. Não há instalador estável homologado.**

A tabela registra a última execução de cada suíte, não uma única aprovação global de todos os 83 IDs. O código posterior a uma evidência precisa de regressão correspondente. A execução local mais recente pode registrar hash do fonte em `evidencias/local-invocation-latest.json`.

Ambiente funcional: WordPress 7.1.2, PHP 8.3.30, MySQL 8.0.46 (mysqli/InnoDB). Sondas e OAuth usam servidor HTTP de desenvolvimento PHP com processos separados. Mídia usa GD real. Esses resultados não são aceite em Apache nem jornadas de clientes comerciais.

| Suíte | Verificações | Falhas | Evidência |
| --- | ---: | ---: | --- |
| additional-0130 | 11 | 0 | `evidencias/additional-0130.json` |
| advanced-0130 | 19 | 0 | `evidencias/advanced-0130.json` |
| concurrency-0130 | 3 | 0 | `evidencias/concurrency-0130.json` |
| cancellation-0130 | 4 | 0 | `evidencias/cancellation-0130.json` |
| contracts-0130 | 23 | 0 | `evidencias/contracts-0130.json` |
| coordinated-update-0130 | 2 | 0 | `evidencias/coordinated-update-0130.json` |
| crash-0130 | 6 | 0 | `evidencias/crash-0130.json` |
| documentation-0130 | 22 | 0 | `evidencias/documentation-0130.json` |
| extended-0130 | 17 | 0 | `evidencias/extended-0130.json` |
| maintenance-0130 | 9 | 0 | `evidencias/maintenance-0130.json` |
| media-0130 | 9 | 0 | `evidencias/media-0130.json` |
| migration-0130 | 7 | 0 | `evidencias/migration-0130.json` |
| oauth-http-0130 | 14 | 0 | `evidencias/oauth-http-0130.json` |
| packages-functional | 10 | 0 | `evidencias/packages-functional.json` |
| providers-0130 | 11 | 0 | `evidencias/providers-0130.json` |
| recovery-0130 | 7 | 0 | `evidencias/recovery-0130.json` |
| recovery-storage-0130 | 5 | 0 | `evidencias/recovery-storage-0130.json` |
| opcache-recovery-0130 | 7 | 0 | `evidencias/opcache-recovery-0130.json` |
| browser-0130 | 22 | 0 | `evidencias/browser-0130.json` |
| retention-0130 | 4 | 0 | `evidencias/retention-0130.json` |
| retention-large-0130 | 5 | 0 | `evidencias/retention-large-0130.json` |
| self-update-0130 | 7 | 0 | `evidencias/self-update-0130.json` |
| sql-concurrency-0130 | 2 | 0 | `evidencias/sql-concurrency-0130.json` |
| sql-failures-0130 | 15 | 0 | `evidencias/sql-failures-0130.json` |
| third-party-0130 | 21 | 0 | `evidencias/third-party-0130.json` |
| zip-validation-0130 | 19 | 0 | `evidencias/zip-validation-0130.json` |

Lint sintático em PHP 8.3.30: 584 arquivos PHP dos três pacotes sem erro; consultar `evidencias/php-lint-0130.json`, que contém arquivo e hash. Análise estática incremental PHPStan 2.2.16 nível 2: 72 módulos, sem supressões, com definições nativas WordPress/Yoast; consulte `evidencias/static-analysis-0130.json`. Não cobre todas as classes importadas nem substitui os testes. Inventário Core/Google: 63/132 habilidades aderentes, sem chamadas às APIs Google.

## Escopo dos ensaios

- OAuth HTTP: login/consentimento sintético, PKCE, token, MCP 2026, refresh, revogação, erro de parâmetros e CIMD com transporte controlado. Não usa credenciais de produção.
- Concorrência: dois processos PHP reais para consumo de código OAuth, CAS de arquivo e idempotência; mysqli separado para inserções concorrentes nas fontes/alvos de seleção SQL.
- Pacotes: oferta nativa sintética de atualização, ativação em processo novo e reversão por fatal. Autoatualização troca uma cópia completa do MCP, sem substituir o fonte de trabalho.
- Interrupção: SIGKILL em barreiras determinísticas de journal/rename (preparado, lacuna entre renames, instalado); sentinela preserva lease vivo e recupera após morte. Não é ensaio de disco cheio ou queda total do host.
- Elementor 4.3.0/Yoast 28.5: ZIPs oficiais verificados por hash, catálogo real e sete recursos reconhecidos; callbacks/servidor Elementor preservados; adaptação SEO usa API do Yoast.
- ENOSPC: erro real do kernel em `/dev/full`, redirecionado apenas para temporários da fixture; preservação do original/diário, ausência de fatal de bootstrap e retomada posterior. O controle com o runtime anterior falhou na proteção do bootstrap; o corrigido passou. Não encheu um filesystem montado.
- OPcache: cache real com `validate_timestamps=0` em processo CLI; troca, scripts removidos e rollback. O código anterior falhou em duas verificações de scripts removidos; o corrigido passou nas sete. Não comprova compartilhamento/invalidação entre pools Apache/FPM.
- Navegador: Chromium 154.0.8037.92, oito abas, rodapé sem fatal, JSON recolhido/expandido/copiado, teclado, emissão/revogação de credencial sintética e tela móvel de 390 px. Edição MCP, salvamento e reabertura no editor de `core/group`/`core/paragraph`, preservando `\--`; não cobre blocos de terceiros da frota. Capturas sem credenciais em `evidencias/ui`.
- Documentação: exemplos validados contra nomes/required do schema, aliases, defaults, exclusão SQL de planos e identidade das cópias. Não é revisão editorial exaustiva.

## Gate restante

1. Executar o ambiente `tools/acceptance` em Docker/Apache com imagens identificadas e fonte congelado; ajustar eventuais falhas sem reutilizar evidência antiga.
2. Completar ensaios de filesystem montado cheio e OPcache em Apache/FPM. ENOSPC controlado, OPcache CLI e UX/editor sintéticos já têm evidência delimitada acima. Deadlock, timeout e perda de conexão já têm ensaios MySQL; COMMIT incerto é injetado após commit real. Retenção foi medida com 450 pares e falha parcial controlada. Cancelamento durante escrita real passou com dois processos, incluindo resultado incerto após o efeito.
3. Validar jornada dos clientes reais, roundtrip dos blocos da frota no editor e migração operacional; a migração sintética 0.12.1 → 0.13.0 já passou.
4. Alvos fixados: Core 1.17.1, Google 0.4.1 e MCP 0.13.0. Compatibilidade com a base, atualização de Core/Google e autoatualização do MCP passaram no laboratório; conferir o conjunto final no gate Apache/piloto.
5. Realizar inventário/aceite do piloto e migração de credenciais somente com autorização operacional. Não foram acessados os sites da frota nesta implementação.
6. Aprovar os instaladores de revisão e gerar os manifestos de distribuição com URLs publicadas. Os ZIPs de revisão são determinísticos, mas não homologados. A 0.12.1 preservada não pode ser apresentada como runtime inalterado: esta implementação muda contratos.

## Restrição observada no ambiente desta execução

Docker não está disponível. O mapeamento de UID/GID do executor contém apenas a identidade 0; não foi possível executar Apache com a separação normal de usuário. A proteção do Apache não foi desabilitada. Por isso o requisito de aceite em Apache permanece aberto, mesmo com as regressões funcionais locais aprovadas.

Estado detalhado: `evidencias/implementation-status.json` (83 IDs). A conclusão de um teste não encerra automaticamente o aceite de um ID inteiro. Informações da 0.12.1 ficam em `docs/historico/VALIDACAO-0.12.1.md`.

## Isolamento do laboratório funcional

O runner pode usar `F3_LAB_ISOLATED=1 F3_RESET_LAB=1`: copia o WordPress sintético para uma pasta temporária fora da sincronização do workspace, inicia MySQL novo e remove o ambiente ao terminar. Isso elimina interferência observada da sincronização em árvores de plugins e arquivos do MySQL. Os testes coordenados aprovados foram executados nesse modo. Logs privados de diagnóstico do laboratório não entram no pacote fonte.

## Regressão dos ZIPs de entrega

Os três ZIPs em `dist/review` foram verificados por SHA-256 e extraídos em uma instalação descartável nova. A última execução concluiu 28 comandos sem falha, incluindo concorrência, cancelamento, OAuth HTTP, autoatualização, recuperação por fatal/SIGKILL, mídia e integrações reais Elementor/Yoast. `evidencias/package-regression.json` preserva os hashes dos instaladores e de cada comando. `evidencias/package-regression-junit.xml` contém um caso por comando, sem logs privados; as asserções individuais permanecem nos JSONs das suítes.

Essa regressão usa servidor HTTP PHP e MySQL reais; não converte a evidência em aprovação Apache/piloto. Os manifestos de revisão têm `release_approved:false` e URLs de exemplo não publicadas. Não configurar esses URLs como feed da frota.
