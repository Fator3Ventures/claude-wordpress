# Especificações canônicas — WP MCP Fator3 0.13.0

Revisão 7 · 29/09/2026 · **Planejado; não implementado por esta revisão documental.** Uma seção por ID é a fonte normativa do comportamento futuro. O plano organiza execução; o manual descreve somente a versão instalada. Metas de prazo estão no plano. Responsáveis são papéis a atribuir nominalmente no kickoff, não pessoas já alocadas.

## Regras comuns de execução

| Campo | Semântica proposta |
| --- | --- |
| `success` | A operação cumpriu o contrato solicitado. |
| `changed` | Houve alteração no alvo; `false` distingue operação válida sem mudança. |
| `persisted` | A persistência foi comprovada; usar `null` quando indeterminada e omitir em operações às quais não se aplica. |
| `applied` | Indicação de efeito aplicado, preservando `null` nos casos já tratados como incertos. |
| `error_code` | Código estável, interpretável pelo agente. |
| `conflict` / `retryable` | Orientam reconciliação e repetição; uma falha com efeito incerto não recebe repetição automática. |
| `operation_id` / `request_id` | Correlação entre requisição, execução, resultado e auditoria. |

Preservar os campos existentes e registrar a versão do contrato. Testes compararão schemas com respostas reais, incluindo erro, ausência de alteração, concorrência e persistência parcial. `success: true` dependerá da verificação prevista para cada habilidade.

Preservar códigos públicos; aliases novos são normalizados antes de idempotência, valores diferentes recusam. Autorizar antes de efeitos/replay, adquirir locks compartilhados com os demais escritores, validar pré-condição, preservar pré-imagem, verificar persistência e auditar. Lock padrão 2 s, com limite efetivo consultável. Código com autoridade administrativa no PHP não é isolado por perfis MCP.

## Qualidade de código

- Introduzir análise estática incremental com definições WordPress e padrões de código, começando pelos módulos alterados. Manter uma lista explícita de pendências antigas; falhas novas bloqueiam a entrega.
- Remover dependência de reflexão do caminho do callback conforme as habilidades adotarem o registro explícito. Preservar um adaptador transitório para habilidades legadas.
- Centralizar sanitização de erros e logs. Mensagens ao agente terão código útil e contexto necessário; tokens, senhas e payloads sensíveis não serão gravados em auditoria.
- Aplicar paginação no armazenamento e limites antes de materializar grandes resultados. Reduzir gravações repetidas de atividade de sessão.
- Fixar dependências, manter fonte revisável em Git e ligar pacote, versão e commit. Conservar a separação entre instalador e fonte/testes.

- Declarar em C06 a origem e versão de cada provedor de habilidades, além do contrato e schema. O núcleo, Google e Core terão registro explícito; provedor desconhecido será identificado como desconhecido. A inferência por caminho de callback não será o mecanismo principal de versão.
- Preservar os códigos de erro já públicos; preencher os casos ainda genéricos. Não renomear todos os códigos apenas para acrescentar um prefixo.
- Consolidar o buffer de auditoria legado com o histórico atual sem duplicar eventos nem fabricar registros ausentes. Acrescentar filtros por alvo/caminho, início e fim, incluindo leituras fora de `ABSPATH`.

<a id="p01"></a>

## P01 — Inventário e evidências da frota

**Situação:** pendente. **Responsável funcional:** Responsável técnico + operação da frota.

**Dependências de implementação:** consultar a base/fixtures e os contratos comuns; fechamento integrado conforme o plano.

Adotar como baseline operacional relatada em 24/09: 14 conectores com MCP 0.12.1, WordPress 7.1.2 e PHP 8.3.30. Registrar evidência por site, data, hash/export da leitura e limitações. O relatório não identifica nominalmente todos os 14 nem comprova versão do banco/Apache; completar inventário antes do ensaio. Registrar banco MySQL 8.0.x exato, servidor web/cache e capacidades efetivas. Mapear todas as portas MCP, registrador/arquivo/plugin e autenticação; coexistência com elementor-mcp-composer não prova autoria do servidor default. Registrar revisões dos clientes realmente usados e se algum exige somente 2026. Não chamar produção nem repetir a prova de execução indireta sem tarefa de teste específica.

Os relatos de 25/09 acrescentam Elementor 4.3, sete recursos e volume de log; não presumir essa versão em toda a frota. Inventariar nomes/metadados dos sete recursos, provedor e versões efetivos para F16. Registrar separadamente as pendências de limpeza de N03, sem executar limpeza no inventário.

O anexo Pedidos ao pacote MCP, recebido em 29/09 e com acréscimos de 28/09, informa nova conferência dos 14 sites em 27/09, todos na 0.12.1. Usar sua numeração original como referência de frota, distinta dos IDs deste plano. O item 16 da frota foi retirado pelo dono: registrar a coexistência do servidor Elementor, sem abrir incidente ou tarefa para desligá-lo. A data 29/09 indicada para entrega é marco solicitado; não é evidência de pacote construído ou autorização de publicação.


<a id="p02"></a>

## P02 — Fixar o fonte 0.12.1 e o instalador de referência.

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** consultar a base/fixtures e os contratos comuns; fechamento integrado conforme o plano.

Base identificada por hash e inventário das 100 habilidades, incluindo as três metahabilidades.



<a id="p03"></a>

## P03 — Transformar os relatos e probes em regressões F01–F23 e contratos N01–N08.

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P02](#p02), [P07](#p07).

Defeitos reproduzidos falham na base e passam corrigidos; recursos novos têm testes de contrato. Distinguir incidente relatado, inspeção estática e reprodução executada.



<a id="p04"></a>

## P04 — Homologação e migração atual

**Situação:** pendente. **Responsável funcional:** QA + operação da frota.

**Dependências de implementação:** [P07](#p07).

Criar fixtures e snapshots de arquivos/banco/estado. Gate de migração obrigatório: 0.12.1 → 0.13.0, em homologação e fator3-teste-mcp-1 para aceite. rc.2 sai do gate por ausência relatada na frota, sem remover à força compatibilidade existente. Se P01 encontrar rc.2, tratar a instalação explicitamente antes do rollout; não declarar compatibilidade sem teste. Pilotos e expansão recebem o mesmo artefato completo.



<a id="p05"></a>

## P05 — Investigar o HTTP 429 relatado em `.well-known` por comparação de requisição, cabeçalhos e logs de hospedagem/plugins.

**Situação:** pendente. **Responsável funcional:** Operação da frota.

**Dependências de implementação:** [P01](#p01).

Origem identificada ou resultado inconclusivo documentado; não atribuir o bloqueio ao MCP sem evidência.



<a id="p06"></a>

## P06 — Recuperação com primitivas WordPress

**Situação:** pendente. **Responsável funcional:** Engenharia PHP + infraestrutura.

**Dependências de implementação:** [P07](#p07).

Adotar o desenho do núcleo: backup temporário/move_dir e restauração; integrar diário persistente e backup durável de O12. O processo original já carregado pode restaurar após falha do processo de verificação, mas não é independente de término/timeout nem de autoload tardio. Pré-carregar o caminho de restauração antes de trocar o MCP; incluir sentinela pequena, versionada e revisada fora da árvore substituída, carregada antes dos plugins normais. Ela aceita somente operações do diário autenticado, sem endpoint público genérico, com locks, lease expirada e verificação de hashes; não desfaz operação ainda viva. Homologar SIGKILL/timeout, disco cheio, perda de lock, manutenção residual e autoload misto. mu-plugin depende de novo request e de WP ter chegado ao carregamento de mu-plugins; .maintenance, erro antes desse ponto ou ausência de tráfego exigem executor/acionamento externo da hospedagem ou contingência explícita. Não afirmar cobertura automática até provar esses casos. A sonda técnica de fatal do núcleo não é a sonda anônima O13: pode encaminhar cookies/Basic Auth. F14 local pode ser corrigido/testado sem concluir todo P06; autoatualização e rollback resistente à morte do processo continuam dependendo dele.



<a id="p07"></a>

## P07 — Ambiente reproduzível e suíte automática

**Situação:** pendente. **Responsável funcional:** QA/infraestrutura.

**Dependências de implementação:** [P01](#p01), [P02](#p02).

Criar Docker Compose ou equivalente versionado com MySQL 8.0.x fixado, PHP 8.3.30 e Apache, WordPress 7.1.2 por hash e plugins/fixtures da pilha. Fixar tags/digests e confirmar disponibilidade das imagens; versionar volumes/reset, configuração PHP e banco/charset. Rodar workers HTTP/PHP realmente concorrentes, sem usar servidor embutido como prova. Não adicionar matriz SQLite/MariaDB/multisite.

Suíte automática de regressão, concorrência e interrupção com barreiras determinísticas: códigos/tokens consumidos uma vez, lock/hash, autorização em outras portas, ativação/fatal, recuperação, contratos de bytes e SQL. Um comando prepara/reset e executa; CI preserva logs sem segredos, resultado JUnit, versões e hashes. Testar estado inicial 0.12.1 e upgrade. Usar fixtures sintéticas; fator3-teste-mcp-1 é ambiente de aceite depois dessa suíte. Laboratório reproduzível não reproduz automaticamente restrições da DreamHost/cache: ensaiá-las no aceite.

Incluir fixtures sintéticas de recursos com metadados aninhados/legados, montagem concorrente do servidor, blocos com filhos, busca em arquivo e registros órfãos. Segredos de teste são marcadores inventados; a suíte verifica sua ausência em respostas/logs/replays e sua preservação na pré-imagem privada autorizada conforme F18. Nunca copiar tokens de produção para fixtures ou relatórios. A integração com os sete recursos reais depende de obter o pacote/versão do Elementor pelo fluxo autorizado; não declarar esse aceite a partir de um mock.

Incluir novas fixtures F20–F23/N04–N08 e adendos de F19/O08/O13: fatal com sintaxe válida, hooks thumbnail/Yoast, seleção SQL concorrente, cache de opções/menu, projeção, gzip/CRC/expansão e manutenção de registros. Não depender de arquivos claude/ que o anexo informa já removidos; preservar relato recebido e gerar evidência nova de laboratório.


<a id="c01"></a>

## C01 — Contexto autenticado sem dependência de sessão

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P01](#p01).

Construir contexto por requisição a partir de usuário e credencial/concessão validados, perfil, versão da política, origem de transporte e revisão MCP. Sessão é atributo opcional de compatibilidade legado. clientInfo, nome do conector, header de perfil e user_id declarados pelo chamador não concedem autorização. Chamada interna usa contexto emitido e verificado pelo servidor, sem aceitar sinalizador trusted do agente.

Para o transporte Elementor/MCP Adapter admitido por C02, incluir adaptador de contexto a partir da autenticação WordPress efetivamente validada e da política cadastrada. Ausência de header/sessão proprietária Fator3 não identifica, por si só, chamada anônima. Nunca confiar em identidade, origem ou perfil apenas declarados no payload.


<a id="c02"></a>

## C02 — Política aplicada na fronteira das abilities

**Situação:** pendente. **Responsável funcional:** Responsável técnico de segurança.

**Dependências de implementação:** [C01](#c01).

Combinar permission_callback original com AuthorizationPolicy nas habilidades próprias e revalidar antes de execução, efeito, replay e cada passo. Falso, WP_Error ou exceção na permissão bloqueiam a ação. Preservar as verificações WordPress e por objeto; o perfil só restringe capacidades. O contexto vem de C01, sem dependência obrigatória de sessão MCP.

**Decisão do dono de 25/09 reafirmada no anexo:** manter o servidor MCP do Elementor operacional. Remover a instrução da revisão 6 de desabilitar o servidor default. Não remover sua rota, recusar initialize/discover/listagem, interceptar todas as requisições ou alterar habilidades de propriedade do Elementor para implementar o perfil Fator3. A coexistência deixou de ser defeito no backlog da frota.

Ao chamar habilidades próprias através de outro transporte, o adaptador C01 resolve usuário e credencial/contexto WordPress validados para a política correspondente. A identificação de integração/transportador é feita no servidor; um nome enviado pelo cliente não habilita confiança. O administrador cadastra explicitamente identidades de integração e suas permissões. Se não for possível distinguir credenciais com a mesma identidade WordPress, documentar a granularidade efetivamente possível e exigir usuários dedicados quando o isolamento por conexão depender disso, sem inventar rastreabilidade.

Habilidades sensíveis próprias (files/db/plugins/users/options/themes/backups e outras mutações) continuam exigindo identidade validada e política aplicável. Falta real de contexto autorizado retorna connection_context_required para a habilidade solicitada; ausência de um cabeçalho Fator3 não dispara bloqueio geral da porta. Não conceder Legado implícito nem autoridade adicional às integrações. C06 limita o decorator aos provedores aderentes; código administrativo no host não é isolado por esse mecanismo.

**Aceite conjunto com O01/F10:** jornadas nativas do Elementor permanecem utilizáveis; suas habilidades próprias passam pelos callbacks originais. A mesma ação Fator3 permitida funciona pelos dois aliases e pelo adaptador autenticado; ação fora do perfil e credencial revogada falham no ponto de execução. O executor nativo de entrada continua disponível; F10 recusa usá-lo como alvo de outro executor/plano. Manter endpoint funcional e autorizar uma ação são critérios distintos de teste.


<a id="c03"></a>

## C03 — `ExecutionCoordinator`

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C02](#c02), [C04](#c04), [C05](#c05).

Coordenar validação, autorização, idempotência, bloqueios, pré-condições, execução e verificação.



<a id="c04"></a>

## C04 — Contratos de resultado

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P03](#p03).

Schemas específicos e tratamento consistente de sucesso, alteração, persistência, conflito e falha parcial.



<a id="c05"></a>

## C05 — Persistência InnoDB definida

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P01](#p01), [P07](#p07).

Usar tabelas próprias InnoDB, criadas/evoluídas por dbDelta e migrações versionadas, com verificação de engine/índices: clients, grants, authorization_codes, tokens, legacy_sessions, idempotency, audit, operations/steps e migration_checkpoints. Usar prefixo real e índices por user_id, client_id, grant_id, status, expires_at e cursores compostos tempo/id. Tokens/códigos armazenados por hash único; refresh associado à família/concessão. Sem segredos em logs.

Consumo único por UPDATE condicional ou DELETE com predicates de validade/client/recurso/PKCE/revogação e affected_rows=1. Emissão/persistência do token e consumo do código devem ser transação única; rollback na falha de INSERT. claim de idempotência usa UNIQUE e estado durável; transação SQL não cobre efeitos HTTP/filesystem. Não manter transação aberta durante rede/upgrade; diário e reconciliação preservam operação incerta sem repetição.

Migração em lotes/checkpoints idempotentes da 0.12.1, expirações originais e leitura transitória controlada. Inventariar transients/índices disponíveis, sem depender de varrer wp_options em cada revogação. Legados não enumeráveis devem ser reconhecidos/importados no uso validado ou encerrados por rotação/reautorização conforme O01; não prometer revogar seletivamente identidade que não foi reconstruída. Cache não é autoridade. Migração preserva comprovantes de consumo e não ressuscita credenciais revogadas em rollback.



<a id="c06"></a>

## C06 — Contrato de extensões

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P01](#p01).

Registro explícito de habilidades de complementos e adesão aos contratos Fator3.

versão por registro explícito de identidade do plugin/provedor; integrar MCP/Core/Google. Quando não houver metadado confiável, usar desconhecido com motivo. Não preencher versão externa com a versão do MCP nem inferir por nome de função.

<a id="f01"></a>

## F01 — SQL com superfície explicitamente permitida

**Situação:** pendente. **Responsável funcional:** Responsável técnico de segurança.

**Dependências de implementação:** [P07](#p07).

Abandonar parser completo de linhagem nesta release. db/query terá subconjunto de leitura limitado e reconhecido estruturalmente, com tabelas físicas e funções explicitamente permitidas. Recusar a tabela real $wpdb->users (não só concatenação de prefixo), views, schemas externos/sistema, rotinas armazenadas, SQL dinâmico, comentários executáveis, acesso a arquivos e formas não reconhecidas. Subconsultas/CTEs/UNION não suportados devem ser recusados; permitir algum exige prova do reconhecimento de todas as fontes e funções. SELECT/SHOW/DESCRIBE/EXPLAIN têm validação específica: só começar com verbo permitido não é garantia. Uma denylist lexical users/views isolada não é a política completa.

Nenhum dado protegido pode influenciar projeção, cardinalidade, ordenação, agregação, erro ou controle de execução no subconjunto permitido. Testar aliases e curinga aninhados, WHERE/HAVING/ORDER BY/COUNT, UNION, funções e representações de identificadores; entradas recusadas devem falhar antes de consultar a fonte protegida. Campos sensíveis em options/usermeta e tabelas de extensões requerem política por origem, ou exclusão da tabela do SQL genérico. Dados de usuários devem usar abilities tipadas e autorizadas.

Corrigir já na implementação a descrição absoluta de db/query. F01 reduz exposição por essa interface independentemente de O01, mas a alegação de isolamento do conector só tem aceite conjunto F01+C02+O01. Perfil com escrita de PHP/plugins/SQL arbitrário é administrativo e consegue acessar outros dados: não anunciar ocultação global de segredos para esse perfil. Documentar consultas antigas que passam a ser recusadas e alternativa tipada.

A classificação por origem e chave e a sanitização de saídas são compartilhadas com [F18](#f18). A ocorrência de `redacted` não certifica confidencialidade se a consulta puder transformar/inferir um segredo: continuam obrigatórias as restrições de fontes e influência descritas aqui.


<a id="f02"></a>

## F02 — OAuth

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C05](#c05), [P07](#p07).

Substituir leitura/exclusão separadas por consumo atômico. Validar cliente, PKCE quando aplicável, recurso e expiração dentro da operação protegida; confirmar persistência dos tokens emitidos. Unificar tratamento de chaves atuais e legadas.

Duas trocas válidas simultâneas geram um único consumo; a outra recebe erro reconhecível. Falha de persistência não devolve sucesso. Validar armazenamento e endpoint HTTP.



<a id="f03"></a>

## F03 — Permissão

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** consultar a base/fixtures e os contratos comuns; fechamento integrado conforme o plano.

Fazer `false`, `WP_Error` e exceção interromperem a autorização do transporte. Usar a regra padrão quando não houver callback específico.

Um usuário com a capacidade padrão continua bloqueado quando o callback específico recusa ou falha.



<a id="f04"></a>

## F04 — Sessões apenas do protocolo legado

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C05](#c05).

Aplicar C05 a criação/atividade/remoção/expiração de sessões do modo legado, com registros atômicos; duas criações concorrentes persistem. O modo 2026 não usa sessão MCP. Não usar session_id como identidade obrigatória: usuário/credencial/concessão validados em C01 são suficientes. Distinguir sessão WordPress de sessão do protocolo.



<a id="f05"></a>

## F05 — Clientes

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C05](#c05).

Proteger cadastro/remoção concorrentes; substituir descarte do cliente mais antigo por recusa explícita de novos cadastros ao atingir a capacidade.

O 101º cadastro não remove os 100 anteriores; cliente autorizado permanece utilizável.



<a id="f06"></a>

## F06 — Transporte

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

Centralizar validação de origem, versão e respostas HTTP para ambos os endpoints; permitir clientes sem `Origin`; configurar explicitamente origens aceitas para clientes de navegador.

Origem não permitida é recusada; versão inválida recebe HTTP 400; notificação aceita recebe HTTP 202 sem corpo; clientes homologados continuam conectando.



<a id="f07"></a>

## F07 — Auditoria

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C05](#c05).

Criar índice paginado com cursor estável e migrar o histórico de forma incremental. Consultas não dependem de varrer todos os arquivos.

Com mais de 10 mil registros recentes, primeira página e continuação funcionam sem `audit_scan_limit`; filtros utilizam o índice.

Índice na persistência C05. Importação em lotes com checkpoint, sem duplicar buffer legado/eventos; novos registros entram imediatamente. Expor history_complete:false e progresso enquanto incompleto. Filtrar também alvo/caminho e leituras fora de ABSPATH. Índice reconstruível a partir de fontes preservadas; não fabricar eventos ausentes.

<a id="f08"></a>

## F08 — Upload de plugin

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

Respeitar `activate:false` e `overwrite:false` quando omitidos, em upload por URL e base64. Falha de ativação solicitada retorna falha com instalação/efeitos parciais explícitos. Aplicar ao upload a proteção já usada contra atualização do próprio servidor MCP.

Omissão não ativa nem substitui; substituição/ativação explícitas seguem o pedido; falha de ativação não declara a operação completa como sucesso; nenhum caminho de upload contorna a proteção do próprio MCP.



<a id="f09"></a>

## F09 — Arquivos binários

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

Aplicar à leitura integral a representação base64 quando os bytes não são texto UTF-8 válido ou o formato é identificado como binário, com schema e encoding. Tornar a representação de escrita inequívoca e recusar combinações contraditórias.

Leitura e regravação de imagem/fonte/ZIP preservam bytes e SHA-256; texto e SVG textual continuam suportados.

Leitura integral usa content_base64/encoding para binários e preserva bytes/hash. Escrita recusa content para lista documentada de formatos binários, exige base64 válido e recusa representações simultâneas. Preservar SVG/JSON/CSS/JS textuais; extensão auxilia classificação, sem provar integridade. Limites cobrem conteúdo decodificado e envelope. Cobrir perda relatada de 13.463 → 4.373 B com original, se disponível, e fixtures independentes com NUL/bytes não UTF-8. Essa medida não localiza a etapa da perda.

<a id="f10"></a>

## F10 — Execução indireta por qualquer provedor

**Situação:** pendente. **Responsável funcional:** Responsável técnico de segurança.

**Dependências de implementação:** [C01](#c01), [C02](#c02), [C06](#c06), [P07](#p07).

Classificar comportamento por registro confiável do provedor e revisão do callback: habilidade que delega execução pelo nome de outra habilidade não pode ser alvo de executor/plano, independente de namespace. Recusar wp-mcp-ultimate/execute-ability, mcp-adapter/execute-ability, aliases e executor de teste de outro provedor com error_code estável indirect_execution_forbidden. Discovery/get-info são metahabilidades de introspecção, não automaticamente executores; ficam fora do catálogo de ações pelo papel declarado, preservando ferramentas de entrada.

Classificação desconhecida não vira leitura confiável nem libera execução por heurística de prefixo. C02 protege também a habilidade final quando chamada pela porta default de terceiro. Testar ambos endpoints Fator3, servidor default e chamadas aninhadas à mesma ação; listas não são a fronteira de autorização. O relato provou delegação de system/capabilities por administrador, não uma escalada de privilégios já restringidos. O risco confirmado é caminho não contemplado pela política proposta.

O item 16 retirado na lista da frota não é este ID. Preservar a ferramenta nativa de entrada do servidor Elementor; indirect_execution_forbidden vale para executores usados como alvos encadeados, mantendo C02 na habilidade final. O teste deve comprovar que essa regra não bloqueia o uso normal do servidor autorizado.


<a id="f11"></a>

## F11 — Patch de conteúdo

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

Manter `expected_revision`, lock e `wp_slash`; exigir unicidade por padrão, definir `all`/`limit` nos modos literal e regex e comparar o conteúdo persistido.

Regex respeita limite; revisão obsoleta conflita; readback traz SHA-256, bytes e `char_length`; divergência gera `content_filtered` com efeito real explícito. Detalhes nesta especificação.

Uniformizar literal e regex:

| Entrada | Semântica |
| --- | --- |
| Sem all nem limite positivo explícito | Exigir uma correspondência; zero é no-op, múltiplas recusam escrita. |
| all:true | Autorizar múltiplas; limit positivo limita em ambos os modos; omitido/-1 aplica a todas. |
| limit >= 1 explícito; all omitido | Seleção limitada explicitamente solicitada; mantém o uso anterior de limite. limit:1 não prova unicidade. |
| all:false | Exigir unicidade; limit > 1 é contraditório e será recusado. |
| limit:-1 isolado | Não autoriza substituição em massa; documentar exigência de all:true. |
| limit zero ou menor que -1 | Recusar e documentar a mudança de validação. |

O helper regex recebe limite, conserva guardas PCRE e restaura configurações em finally. Padrão inválido/exaustão não grava. Testar grupos, barras, substituição vazia, Unicode e hífens.

Depois de salvar, ler bytes persistidos por consulta interna parametrizada por ID com CHAR_LENGTH(post_content) e comprimento em bytes. Calcular sha256 desses bytes e comparar com o resultado pretendido; comprimento isolado não prova igualdade. Retornar char_length e bytes distintos. Divergência gera success:false, error_code:content_filtered, hashes esperado/observado e changed/applied/persisted conforme efeito observado. O código identifica divergência; não prova qual filtro a causou. Não repetir automaticamente nem adicionar slashing.

Atualização de evidência (pedido 4, 25/09): o responsável relata que a perda de barras não se reproduziu na 0.12.1 nos modos literal e regex. Não registrar “causa corrigida” sem reprodução. Manter wp_slash e os testes/readback aprovados. Melhorar o erro de PCRE: informar delimitador ausente/inválido, sintaxe inválida ou limite de execução atingido com motivo/código seguro, exemplo de formato delimitado e sem ecoar conteúdo ou padrão sensível em logs. Validar schema, limites e mensagens também nos wrappers.


<a id="f12"></a>

## F12 — Debug pelo serviço existente de arquivos

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

Manter desabilitado por padrão. Extrair/reutilizar a mesma primitiva interna de files/patch para lock, hash, backup, sintaxe PHP, temporário e troca atômica em wp-config.php. Não chamar o executor público recursivamente nem duplicar a implementação dos locks. Validar alterações de constantes, permissões e readback. Remover a habilidade seria mudança de escopo e compatibilidade; não foi adotada.



<a id="f13"></a>

## F13 — Erros e estados normais

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

Preservar a propagação de `success:false`/`isError` já existente; distinguir habilidade inexistente de acesso negado e conservar código estruturado. Tratar log ausente/desabilitado como estado normal. Corrigir acesso a campo `error` ausente no handler.

Falha de domínio chega como erro MCP sem warnings PHP; códigos existentes permanecem válidos; log ausente retorna `exists:false`; erro real de leitura continua sendo falha.

Para `f3_private_storage`, conservar o código e a recusa de acesso direto em todas as operações `files/*`. Acrescentar orientação acionável: consultar `system/health`, campo `storage.path`, se autorizado, e usar as habilidades específicas de backups/auditoria/estado disponíveis ao perfil. Não hardcodar `f3-mcp-private`: o diretório é configurável. A mensagem não devolve conteúdo nem caminho absoluto sensível a quem não tem acesso ao diagnóstico e não recomenda apagar locks ou usar SQL para contornar a proteção. Testar caminho relativo/absoluto, origem/destino, alias de caminho e tentativa de link; diagnóstico permitido não equivale a leitura permitida.


<a id="f14"></a>

## F14 — Update preservando ativação — estratégia B

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

Escolher upgrade() mais reativação em contexto PHP novo, coordenada dentro da mesma chamada externa MCP. Capturar estado/versão antes; ativo deve voltar ativo, inativo permanece inativo. Não reativar no processo com versão antiga já incluída. Usar chamada interna autenticada de uso único vinculada à operação/identidade do pacote, ou worker isolado; nunca uma rota pública de ativação arbitrária. Limitar tempo e verificar estado final independentemente da resposta. Usar ativação silenciosa de atualização quando apropriado, evitando repetir hooks de instalação.

activate_plugin não captura todo fatal como WP_Error nem desfaz efeitos de hooks. Fatal anterior à persistência da ativação normalmente deixa o plugin inativo; fatal tardio e side effects exigem verificar/recuperar. A requisição filha pode encerrar sem envelope JSON: classificar como falha/indeterminação e consultar estado no coordenador. Se falhar, devolver active_before/active_after, versão/mudança e ativação falha explícita. Na entrega completa integrar O12/O13 para restaurar pré-imagem e verificar o site; a correção local pode ser implementada/testada antes desses serviços e sem rebase de protocolo.

Comparar em P07 upgrade() sem correção, estratégia B e bulk_upgrade([$plugin]) com fixtures equivalentes. A alternativa bulk não instala o mesmo hook de desativação, mas muda retorno/skin/manutenção e pode executar código novo com plugin ativo; não é correção completa de uma linha. Não há migração B→A automática planejada. Adotar A somente se ensaio demonstrar vantagem e recuperação adequada.

Frota single-site: remover teste de rede do gate. Detectar estado não suportado antes da troca e recusar, sem convertê-lo silenciosamente. A recusa de rede do Core isoladamente não prova ausência de toda topologia; o recorte decorre da padronização declarada. Retornar active_before/active_after mesmo sem oferta. Conferir home/REST/SEO e cache; não prometer ausência de janela degradada.



<a id="f15"></a>

## F15 — Entrada e saída de hierarquia de páginas

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

Corrigir as três descrições de list/create/update. Manter parent canônico na entrada e aceitar parent_id como alias nos mesmos locais; ambos iguais são válidos, diferentes falham com alias_conflict antes de mutar. Normalizar antes da idempotência. Preservar parent_id nas saídas existentes e acrescentar parent com o mesmo valor em list/get e demais saídas aplicáveis. Zero é valor válido e não ausência. Documentar o par uma vez no contrato.

Testar filtro da listagem, create/update com parent ou parent_id, parent:0/parent_id:0, conflito entre aliases, revisão obsoleta no update e igualdade dos campos devolvidos. O ID não fica restrito à descrição de update-page.



<a id="f16"></a>

## F16 — Recursos MCP com metadados aninhados e log deduplicado

**Situação:** pendente. **Responsável funcional:** Engenharia MCP + QA.

**Dependências de implementação:** [P07](#p07).

**Prioridade:** P1 — recurso indisponível e incidente de volume de log. Correção local, sem dependência de M01 para começar.

Normalizar metadados de recurso em um único adaptador: `meta.mcp.uri` e `meta.mcp.mimeType` são canônicos; `meta.uri` e `meta.mimeType` continuam aceitos como fallback por campo. String ausente/vazia após trim permite fallback; tipo/valor não vazio inválido recebe erro validado, sem conversão silenciosa. Se os dois caminhos forem válidos e divergirem, prevalece `meta.mcp`; registrar um diagnóstico deduplicado `resource_metadata_conflict`, sem rejeitar um recurso válido nem mudar a URI fornecida para um slug Fator3. Manter o validador de URI/MIME e a detecção de URI duplicada entre habilidades; não sobrescrever silenciosamente outro recurso.

Usar o MIME declarado na descrição de `resources/list`, sem o fallback de descrição `text/plain` sobrepor `text/markdown`. Registro/listagem não executam callbacks de leitura para obter conteúdo. Em `resources/read`, executar a habilidade com a permissão/contexto vigentes; preservar URI e MIME válidos do conteúdo retornado e usar o MIME declarado apenas quando o item não o trouxer. Não devolver a descrição da habilidade como se fosse o documento real. Metadado divergente de conteúdo exige diagnóstico/teste, não reescrita silenciosa do payload. Este ajuste não transforma resource em tool nem amplia os perfis de C02.

Sem URI nos dois caminhos, manter `resource_uri_not_found`, excluir só o recurso inválido e registrar o erro **uma vez por habilidade/código/versão do catálogo do site**, mesmo com requests e workers concorrentes. Usar marcador persistente com claim atômico (armazenamento/locks já disponíveis; integrar com C05 no fechamento), não variável estática, transient com TTL curto nem deduplicação restrita a uma requisição. Derivar a versão de metadados canônicos ordenados e versões dos provedores, sem timestamps, sessões, usuário ou ordem de registro; definir o catálogo após os provedores concluírem o registro. Uma alteração efetiva invalida o marcador correspondente; renovação de request não. Não confundir esse identificador técnico com o catálogo filtrado por credencial de O15. Retenção não remove marcadores do catálogo ativo.

O mesmo evento não deve ser duplicado no logger e na observabilidade. Mostrar diagnóstico resumido aos administradores, com ability/provedor/código/versão do catálogo e sem payload/URI sensível. Falha de persistência da deduplicação não libera uma linha por recurso por request: suprimir repetições do logger e indicar falha no diagnóstico, mantendo o servidor utilizável. Uma montagem sem autorização não recebe o inventário de outro perfil.

**Aceite:** fixtures nested-only, legacy-only, ambos iguais/divergentes, vazio/inválido, MIME ausente, URI duplicada e recurso sem URI; 100 montagens sequenciais e 20 concorrentes geram no máximo um evento por chave inválida, e um novo catálogo permite um novo evento. Os sete recursos do relato entram em listagem/leitura autorizadas com URI/MIME corretos quando a integração Elementor for ensaiada. Leituras negadas não executam callback; conteúdo real e schemas são verificados nas duas URLs e nos modos de protocolo da release. Incluir falha do marcador e invalidação por atualização de provedor. O critério não exige que todo o error.log fique vazio: outros erros têm causas próprias.


<a id="f17"></a>

## F17 — Edição de bloco sem descarte implícito de filhos

**Situação:** pendente. **Responsável funcional:** Engenharia PHP + QA de conteúdo.

**Dependências de implementação:** [P07](#p07).

**Prioridade:** P1 — prevenção de perda de conteúdo. Reutilizar o lock/revisão/readback existentes em ContentTools.

Em `content/edit-block`, recusar `inner_html` quando o bloco alvo possuir blocos filhos, em prévia e gravação, com `block_children_would_be_lost`, `changed:false` e indicação de usar `children`. Preferir recusa a um aviso que permita salvar perda silenciosa. Não acrescentar bypass genérico de descarte nesta release. `inner_html` continua aceito para folha com corpo; alterações só em `attributes` preservam filhos. Manter `block_change_conflict` para `inner_html` junto de `children` e `block_has_no_body` em bloco autoencerrado.

`children` é a via explícita de substituição dos filhos, usando estruturas válidas de `parse_blocks`; `children:[]` significa remoção intencional e deve ser descrito como tal. A prévia mostra o conteúdo resultante e contagens `children_before`/`children_after`; não salva conteúdo ou revisão. Validar relação `innerBlocks`/marcadores `innerContent`, limites e árvore resultante, preservando invólucro e blocos fora do alvo. Se a estratégia atual de juntar prefixo/filhos/sufixo perder HTML intermediário entre filhos, recusar com `block_structure_unsupported` até conseguir preservá-lo; não fabricar um contêiner vazio para estruturas não reconhecidas. Preservar `expected_revision` e verificar bytes/hash persistidos conforme E03/F11, sem afirmar validação do editor apenas por parse PHP.

**Aceite:** group/columns com filhos e netos, folha, bloco vazio, autoencerrado, bloco de terceiro e texto intermediário. `inner_html` em contêiner falha sem modificar o banco, inclusive em preview; attributes não elimina descendentes; `children` válido substitui apenas o alcance indicado; array vazio faz somente a remoção explícita; filhos inválidos e entrada ambígua falham. Prévia e escrita concordam para a mesma revisão; uma edição concorrente recebe conflito, sem sobrescrita.


<a id="f18"></a>

## F18 — Segredos em prévias, resultados SQL e exportações

**Situação:** pendente. **Responsável funcional:** Responsável técnico de segurança + engenharia PHP.

**Dependências de implementação:** [P07](#p07).

**Prioridade:** P0 — exposição de segredo relatada. Implementar a correção local antes das funcionalidades sem incidente; integrar com F01/C02/O01/O07/E05 no pacote único, sem aguardar o parser/rebase para corrigir o caso confirmado.

**Diagnóstico da base:** `DatabaseWriter::execute()` já chama `SqlGuard::redact()` na prévia. O redator só reconhece `user_pass` e `user_activation_key`; não considera `option_name`/`option_value`. A prévia não inclui o `redacted` calculado. O resultado final atualmente usa `preview_rows:[]`, mas caminhos de erro repassam mensagens de banco/exceção. O conserto é ampliar a política e cobrir todas as saídas, não apenas acrescentar uma chamada já existente.

Criar política compartilhada por origem (tabela/coluna), chave da linha e provedor registrado, com o prefixo real. Cobrir ao menos senhas/chaves de ativação, tokens de sessão/aplicação e valores de opções/metadados secretos; o caso `_angie_snippets_dev_mode_secret_token` deve ser classificado mesmo que o valor pareça texto comum. A lista explícita de chaves sensíveis e padrões conservadores é versionada/extensível; padrão lexical isolado não prova ausência de segredo. Se uma linha/documento de origem opaca não puder ser classificado com segurança, ocultar seu payload completo (ou recusar a projeção em db/query conforme F01), sem adivinhar que é público. Valores JSON/serializados de configuração sensível são ocultados por inteiro; não desserializar objetos PHP de origem não confiável para redigir um subcampo. INSERT/REPLACE/UPDATE também classificam chaves/valores novos, não só a pré-imagem do DELETE.

Aplicar antes de truncar/amostrar/transportar como base64. Preservar o marcador existente `[redigido]` e acrescentar `redacted` como lista de campos/caminhos suprimidos, com motivo seguro quando necessário, em prévia, resultado e replay. Não expor prefixos, sufixos, tamanho ou hash do valor secreto como “prova” de redação. A classificação pode usar contexto interno que não será enviado; omitir/renomear a coluna identificadora não desativa a regra. Metadados normais de efeito, contagem e backup continuam disponíveis ao perfil autorizado; isso não transforma SQL administrativo em interface sem possibilidade de inferência. A garantia contra influência em SELECT permanece em F01.

Usar cópias redigidas só para apresentação. Hash de pré-imagem, comparação transacional, confirmação e cópia de recuperação utilizam os bytes originais no servidor; a diferença entre dois segredos ocultos deve continuar produzindo `database_conflict`. A confirmação segue vinculada à conexão/SQL/alvo/revisão/expiração; o agente não precisa receber o segredo para confirmar o alcance.

Sanitizar mensagens de `$wpdb->last_error`, exceções e `original_error` aninhado; não devolver SQL completo, literais, dump da linha ou valores em mensagens/logs do canal. Preservar códigos estáveis e `operation_id` para diagnóstico. Auditoria registra metadados por allowlist, sem SQL, token de confirmação ou células; não há evidência nesta inspeção de que Audit::record já grave o token relatado. Resultado durável/idempotente deve guardar a forma sanitizada; revalidar política na leitura/replay de estado legado para não ressuscitar saídas inseguras. Registrar como limite logs de banco/hospedagem/plugins externos: o canal não controla um logger de terceiro que capture SQL.

**Backup íntegro:** documentar no schema/descrição de `db/execute`, prévia, resultado e ajuda que a pré-imagem automática guarda valores originais, inclusive segredos, e na base guarda também SQL. Prévia isolada não cria backup; backup surge antes da escrita quando há linhas anteriores. Acrescentar aviso sem valores e metadado `backup_contains_sensitive_values` com estado `true`, `false` ou `unknown`; desconhecido recebe a mesma proteção de sensível. Não criar `backup_id` fictício para INSERT sem pré-imagem. Não redigir a cópia restaurável nem prometer criptografia porque há envelope PHP/base64.

Separar permissão de listar metadados de permissão explícita de exportar conteúdo de backup (inclusive SQL e arquivos); aplicar a `backups/export` e E05 a cada chamada/parte com C02/O01. Um agente que consulta prévia/lista não herda acesso aos valores originais. A exportação integral autorizada é uma ação de recuperação sensível, auditada e identificada como contendo originais; diagnósticos/exportações de histórico são redigidos. Inventariar legados como sensibilidade desconhecida e manter retenção O08 com simulação, sem apagar evidência ou backups automaticamente nesta atualização.

**Aceite:** DELETE do nome de opção relatado com token fictício; UPDATE/INSERT/REPLACE; nomes/aliases/contextos de tabela diferentes; segredo em JSON/serializado/binário e texto público de controle. Procurar marcadores secretos em todo o envelope MCP, erros, logs do canal, histórico e replay, inclusive saída base64 e escapes usuais. Nenhum deve aparecer nas saídas redigidas. Pré-imagem privada e exportação explicitamente autorizada preservam bytes; acesso não autorizado e continuação após revogação falham. Testar mudança de segredo entre prévia e execução, transação falha, replay legado, sensibilidade desconhecida e ausência de pré-imagem. Não alegar que redação de saída impede SQL/PHP administrativo de inferir ou acessar dados por outros caminhos.


<a id="f19"></a>

## F19 — Busca textual em um arquivo ou diretório

**Situação:** pendente. **Responsável funcional:** Engenharia PHP + QA.

**Dependências de implementação:** [P07](#p07).

**Prioridade:** P2 — correção do alcance de `files/search`.

Aceitar `path` apontando a um arquivo regular legível ou a diretório. Reutilizar um serviço de busca limitado por arquivo, preservando `matches`, `skipped`, `partial_files`, `scanned_bytes`, `has_more`, `next_offset` e `listing_sha256`. O modo de diretório mantém semântica de recursão/paginação. Arquivo único não expande para o diretório pai nem pesquisa vizinhos; tratar como coleção de uma entrada: offset 0 a examina, offset >=1 devolve página vazia, e per_page/max_depth/recursive não ampliam seu alcance. `offset` continua índice de arquivos, não byte; N01 trata leitura por byte.

Aplicar os mesmos limites de texto/bytes/linhas/resultados e a mesma autorização/PathGuard nos dois modos, incluindo f3_private_storage/F13. Não seguir symlink nem abrir pipe/socket/dispositivo; arquivo inexistente ou ilegível retorna erro identificável sem virar “zero ocorrências”. Binário/arquivo acima do limite segue o registro `skipped` com motivo. Ao truncar, informar `partial_files.next_byte_offset`; continuar o trecho por files/read/N01, sem sugerir que has_more:false prova busca integral. Hash de listagem não é hash de todo o conteúdo. Verificar identidade/tipo ao abrir e registrar arquivo rotacionado/alterado em vez de afirmar snapshot consistente; sem promessa de exclusão de escritores externos.

**Aceite:** arquivo normal/vazio/sem ocorrência, Unicode, linha longa, truncamento e continuação, offset 0/1, diretório, binário e limite de tamanho, caminho relativo/absoluto, confinamento, armazenamento privado, link e mudança de alvo. Os matches de um arquivo isolado coincidem com os da mesma entrada na busca em diretório sob os mesmos limites; nenhum arquivo vizinho é lido.

Adendo de 28/09 (anotado após o pedido 19 da frota): acrescentar grep_regex:boolean, default false, com o mesmo formato PCRE delimitado de files/read. Compartilhar compilação/matching e limites de padrão, tamanho de linha, backtracking, recursão e tempo; restaurar configuração PCRE após a execução. Recusar padrão inválido antes de varrer arquivos, com motivo seguro conforme F11. Expressão válida usa os mesmos limites/paginação e retorna linhas, sem execução de shell. Testar literal com metacaracteres, regex /error|fatal/i, Unicode, padrão sem delimitador, backtracking excessivo e continuação de arquivo truncado nos dois modos de alvo.


<a id="f20"></a>

## F20 — Sonda e recuperação de alterações em PHP carregado pelo site

**Situação:** pendente. **Responsável funcional:** Engenharia PHP + infraestrutura.

**Dependências de implementação:** [P06](#p06), [O13](#o13), [P07](#p07).

**Prioridade P0; pedido 20.** Compartilhar o coordenador interno de escrita/lock/backup com files/write e files/patch. PHP do tema ativo (incluindo pai/filho), plugins ativos, mu-plugins e arquivos de bootstrap identificados recebe sonda de execução na mesma chamada. Dependência de include não é decidível só pelo caminho: classificar alcance desconhecido de PHP como exigindo verificação conservadora, sem promessa de análise estática completa. Usar o mesmo controle nos demais escritores capazes de substituir esse alvo, inclusive fetch/restore/copy/move e conclusão de upload em partes; não permitir bypass pelo método escolhido. Manter bloqueio específico de autoalteração do canal fora do fluxo P06/O14.

Antes da troca: permissão, pré-condição, lock comum, sintaxe, pré-imagem persistente obrigatória e diário. backup:false não desliga a proteção de PHP em uso (runtime_backup_required). Arquivo novo registra pré-estado ausente, permitindo remover somente a pós-imagem criada; não inventar backup_id para bytes inexistentes. Sonda baseline deve passar antes de alterar. Depois da troca/invalidação OPcache, executar home e REST anônimos em contexto PHP novo via O13, com execução/bypass de cache comprovados. Uma resposta 200 servida de cache não atesta o código novo.

Se baseline passa e pós-sonda retorna 500/fatal ou viola asserção obrigatória, restaurar na mesma chamada os bytes anteriores usando serviço pré-carregado, sem depender de nova chamada ao endpoint MCP ou reentrar no public files/restore. Proteger pós-imagem por hash/diário: mudança de terceiro gera rollback_conflict em vez de sobrescrevê-la. Reprovar timeout/inconclusão conforme O13 e registrar o motivo sem atribuir causalidade não provada. Verificar novamente depois da reversão. P06 cobre morte do processo e os limites de sentinela/acionamento externo; testar locks e loopback sem deadlock.

Resposta registra operation_id, backup_id real, sondas antes/depois/recuperação, hashes e estado final: applied, rolled_back, rollback_conflict ou recovery_required. Distinguir tentativa que alterou arquivos de estado final restaurado; success só com objetivo verificado. Reverter arquivos não desfaz efeitos de PHP em banco/serviços. O código pode produzir efeitos antes de falhar; não apresentar sonda como sandbox ou análise exaustiva de todas as rotas.

**Aceite:** PHP com sintaxe válida e função realmente ausente/condicional, tema ativo, plugin ativo, mu-plugin, arquivo novo, cache aquecido, OPcache, rota REST quebrada, baseline já ruim, timeout, mudança externa, processo interrompido e falha de restauração. Não criar rota genérica para executar PHP.


<a id="f21"></a>

## F21 — Imagem destacada, hooks e revisão final de conteúdo

**Situação:** pendente. **Responsável funcional:** Engenharia PHP + integração Yoast.

**Dependências de implementação:** [P07](#p07), [E02](#e02).

**Prioridade P1; pedido 21.** A fonte confirma featured_media após wp_update_post. Validar attachment e permissão antes de qualquer efeito, tratar zero como remoção e distinguir valor inválido de no-op. Sob o lock do post e expected_revision, fazer a gravação da imagem por API WordPress antes do save final que dispara os consumidores; preparar taxonomias/metadados relevantes no mesmo fluxo. Não escrever diretamente em tabelas privadas do Yoast. Readback deve verificar tanto o post como a imagem e devolver revision após todos os efeitos síncronos conhecidos, ainda dentro da fronteira protegida.

Antes de mover a chamada, preservar pré-imagem para reconciliar falha de wp_update_post depois de thumbnail alterado; relatar efeito parcial em vez de success:true com aviso ignorável. Evitar segunda chamada genérica a wp_update_post só para disparar hooks sem necessidade, pois duplica efeitos e revisões. Se o adaptador SEO exigir notificação final, usar API suportada e testar sua semântica uma vez por operação.

**Correção da hipótese:** AbilityRuntime já calcula revision depois do callback na linha 52 e ContentTools::revision inclui post, metadados e termos. Portanto “revision lida antes da imagem” não está demonstrado pelo fonte. Reproduzir com decorator efetivo, cache, hooks e escritores concorrentes; fechar a leitura sob lock e comprovar o token final, sem assumir a mesma causa do indexable.

**Aceite:** adicionar/trocar/remover imagem, só imagem, alteração combinada, attachment inválido, no-op, falha de metadata/save e concorrência. Capturar imagem vista no save_post, validar revision por leitura imediata sem escritor intermediário e inspecionar og:image no HTML sem cache com a versão Yoast homologada. Não forçar og:image quando o usuário definiu outra imagem social explicitamente; respeitar configuração SEO. Revisar criação/atualização de páginas/posts que compartilham o fluxo e registrar diferenças de API.


<a id="f22"></a>

## F22 — Exclusão de plugin e registro de atualização automática

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07), [O11](#o11).

**Prioridade P2; pedido 11.** Depois de delete_plugins confirmar remoção e de conferir ausência física/inventário, retirar somente o basename removido de auto_update_plugins usando as APIs WordPress de site option, mesmo no ambiente single-site. A fonte atual limpa cache de plugins, mas não faz essa manutenção explicitamente. Não apagar o registro de um plugin cuja exclusão falhou ou de outros plugins do pacote por prefixo.

Incluir o registro no alcance da prévia/confirmação, no lock de pacote e na pré-imagem de O11; revalidar estado para preservar alterações concorrentes. Conferir persistência após update_site_option e invalidar somente os caches pertinentes. Se arquivos foram removidos e limpeza da configuração falhou, devolver estado parcial identificável, active/exists observados e auto_update_cleanup_pending; não repetir a desinstalação só para ajustar a lista. Repetição deve reconciliar apenas a pendência confirmada, sem executar uninstall novamente. A resposta indica valor antes/depois e changed por componente.

**Aceite:** registro presente/ausente, remoção falha, plugin reinstalado no intervalo, mudança concorrente de outra entrada e falha de persistência. A opção permanece protegida contra mutação genérica; esse trabalho não remove entradas órfãs de uninstall_plugins, que seguem N03.


<a id="f23"></a>

## F23 — Seleção SQL com JOIN ou subconsulta e prévia controlada

**Situação:** pendente. **Responsável funcional:** Engenharia de persistência + segurança.

**Dependências de implementação:** [F01](#f01), [F18](#f18), [C05](#c05), [P07](#p07).

**Prioridade P2; pedido 11.** Tratar a limitação da seleção como contrato próprio, com custo explícito. Manter db/execute em duas fases e fora de operations/plan. Ampliar somente UPDATE/DELETE de uma tabela alvo física com chave primária determinística: selecionar alvos por um INNER JOIN de igualdade ou por IN com uma subconsulta SELECT simples de um nível. WHERE continua obrigatório. Não admitir escrita em múltiplas tabelas, UNION/CTE, rotinas, agregações/janelas, SQL dinâmico, fontes externas/views, funções desconhecidas, efeitos não determinísticos ou múltiplas instruções. INSERT/REPLACE preservam o subconjunto literal atual.

Reconhecer estrutura por parser/AST do subconjunto e autorizar todas as fontes/colunas/funções conforme F01 e perfil, antes de executar. Não remover a recusa lexical existente sem substituí-la por esse reconhecimento. Na prévia, obter chaves alvo distintas (JOIN com duplicatas não multiplica alcance), linhas anteriores e identidade da seleção, sob os limites atuais de linhas/bytes/tempo; resultados usam F18. Guardar no servidor os fingerprints, sem expor hashes de segredos.

Na confirmação, revalidar permissão, plano reconhecido, chaves e pré-imagem dentro da transação InnoDB com bloqueios apropriados de alvo/fontes; qualquer mudança relevante no conjunto selecionado ou nos dados usados no cálculo conflita. Congelar as chaves aceitas e assegurar que o DML não alcance linhas novas; não reexecutar cegamente um predicado que ampliou o conjunto depois da prévia. Para UPDATE, aceitar nesta extensão apenas atribuições literais ao alvo, evitando valor derivado de JOIN ambíguo. O compilador deve preservar a semântica admitida, não truncar silenciosamente a seleção. Backup integral antes do efeito, consumo único e reconhecimento de commit incerto permanecem obrigatórios.

**Aceite:** seleção JOIN e IN simples equivalentes a IDs explícitos; duplicatas, zero linhas, PK composta reconhecida, source/target alterados entre fases, phantom concorrente, deadlock/timeout e replay. Formas fora do subconjunto recebem motivo estável antes de consultar/escrever. Preservar gates de triggers/cascatas/engine e testes de influência de fontes protegidas. A prova transacional é condição de entrega deste item; não liberar SQL complexo só porque o preview exibiu linhas plausíveis.


<a id="n01"></a>

## N01 — Leitura por byte

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

Acrescentar `offset_bytes` como início explícito de leitura por bytes, com `byte_limit`, sem forjar cursor.

Cobrir EOF, offset fora do arquivo, UTF-8 cortado, binários, logs/ZIP e continuação por cursor.

- Inteiro não negativo, zero-based, início explícito do modo byte, com byte_limit limitado.
- Excluir combinação com cursor, inclusive cursor vazio, e com offset/limit/tail_lines/grep/grep_regex.
- Manter cursor vazio para início legado; a string "0" continua inválida como cursor.
- Offset igual ao tamanho é EOF válido; maior gera erro de intervalo sem ajuste silencioso.
- Fazer seek e leitura limitada sob lock compartilhado, sem percorrer o conteúdo anterior. Retornar offset efetivo, bytes, tamanho observado, representação, hash parcial, sha256_scope:returned_content e cursor seguinte.
- Validar identidade/rotação na continuação. A verificação amostral atual não comprova snapshot integral entre chamadas nem detecta toda edição externa.
- Testar final de ZIP/log, corte UTF-8, truncamento/rotação, arquivo vazio e entradas contraditórias. A interpretação do diretório central do ZIP pertence ao consumidor.

<a id="n02"></a>

## N02 — Rewrite

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

Acrescentar `rewrite/flush` com `flush_rewrite_rules(false)`, estado fresco de permalink e readback das regras.

Regras de categoria/tag e contagens antes/depois; mudança funciona sem SQL, mantendo `rewrite_rules` protegido no editor genérico.

Adotar **rewrite/flush** como a solução tipada aprovada. Manter rewrite_rules protegido em options/update. Fluxo: alterar permalink_structure/category_base/tag_base pelas habilidades de opção e chamar regeneração explícita.

- Exigir capacidade administrativa e controles de mutação, auditoria e idempotência.
- Lock por configuração de rewrite compartilhado com as escritas dessas três opções, com ordem definida em relação aos locks de opção.
- Ler opções persistidas e renovar o estado de $wp_rewrite antes da geração; não confiar no objeto carregado antes das mudanças do mesmo plano/requisição.
- Executar flush_rewrite_rules(false) após registro das estruturas. O escopo é regenerar a option, sem gravar .htaccess.
- Capturar antes/depois: quantidades, hashes e regras de categoria/tag, limitando a resposta e marcando truncamento. Conferir persistência.
- Flush explícito, sem executá-lo a cada requisição. A resposta de options/update dessas chaves indica necessidade de regenerar enquanto o automático não existir.
- Testar categoria/tag, permalink de página/post, REST e sitemap quando presente; permissão, concorrência e no-op. Preservar estado anterior para recuperação administrativa sem prometer transação de hooks.

A alternativa com setters nativos e flush numa operação única não é uma segunda funcionalidade do escopo: N02 adota a rota explícita acima, que satisfaz o requisito sem SQL. O flush distingue regeneração da option e atualização das regras do servidor: [flush_rewrite_rules](https://developer.wordpress.org/reference/functions/flush_rewrite_rules/). [Setter nativo de permalink](https://developer.wordpress.org/reference/classes/wp_rewrite/set_permalink_structure/).

<a id="n03"></a>

## N03 — Limpeza tipada de registro de desinstalação órfão

**Situação:** pendente. **Responsável funcional:** Engenharia PHP + operação da frota.

**Dependências de implementação:** [C02](#c02), [O11](#o11), [P07](#p07).

**Prioridade:** P2 — manutenção explícita, sem desbloquear opções protegidas.

Adicionar a habilidade `plugins/cleanup-orphaned-uninstall` (nome proposto para a implementação) restrita a remover uma entrada realmente órfã de `uninstall_plugins`. Manter `options/update` bloqueando a opção inteira e suas chaves; não criar edição arbitrária de callbacks. Exigir perfil de manutenção com `manage_options` e `delete_plugins`, ambas as permissões e C02, em prévia e aplicação.

Entrada por `plugin` com basename exato (diretório/arquivo.php ou plugin de arquivo único), nunca somente um prefixo ou wildcard. Sem `confirm_token`, apenas prévia com entrada candidata, motivo de orfandade, estado do arquivo/inventário, revisão opaca e alcance. Callback é descrito como metadado sanitizado; nunca incluído/executado, nem sequer por tentativa de validação callable. Confirmar com o mesmo alvo/token de uso único vinculado à conexão/site, pré-imagem, inventário e expiração conforme O11. Não oferecer flag force que elimine o teste de orfandade.

Definir órfão pela ausência comprovada do plugin no inventário e do arquivo/caminho de origem, sem registro ativo/pacote em instalação ou atualização. Não considerar inativo como ausente. Inventário incompleto, arquivos inacessíveis, link/estado inconsistente ou outro plugin ainda presente no mesmo pacote tornam o caso inconclusivo; recusar com `orphan_status_unknown`. Plugin presente recebe `plugin_not_orphaned`. Não remover registro de plugin válido porque a classe do callback não está carregada neste request.

Usar lock comum de pacote/registro nos escritores cooperantes, revalidar orfandade e pré-imagem imediatamente antes da mudança, copiar a pré-imagem privada e remover só a chave escolhida com comparação condicional da opção para evitar perder entradas concorrentes. Invalidar caches corretos e fazer readback; preservar todas as demais entradas e semântica de autoload. Comparação falha ou reinstalação observada recebe `uninstall_registry_conflict`, `conflict:true`, sem sobrescrita. Escritores nativos/externos não aderem ao lock: o compare-and-swap impede perda de atualização da opção, mas não torna filesystem e banco uma transação; ensaiar reinstalação e reportar limite/reconciliação, sem garantia global fictícia.

Resultado inclui alvo, `changed`, `removed`, revisão antes/depois e `backup_id` somente se houve pré-imagem persistida. Entrada já ausente é no-op; token reapresentado retorna o resultado registrado, sem nova exclusão. Não restaurar automaticamente um callback antigo de plugin removido; o backup dá evidência/recuperação administrativa controlada, não autorização para executar código ausente. A falha do backup bloqueia a alteração.

**Pendências de operação, não limpeza automática da release:** revisar entradas atribuídas a litespeed-cache em fator3.com.br e korvena.com.br e angie em korvena.com.br, usando basenames/estado então observados. O post `angie_snippet` na lixeira de korvena.com.br é objeto de conteúdo separado: levantar ID/tipo/status/revisão e usar a exclusão de conteúdo com confirmação O11 apenas após decisão sobre aquele post. Não apagar todos os posts do tipo, não restaurar código Angie e não acoplar exclusão de conteúdo à limpeza de uninstall_plugins. Não há ID de post nem autorização de limpeza específica nesta revisão.

**Aceite:** registro órfão, plugin instalado ativo/inativo, entrada ausente, inventário ilegível, callback de classe não carregada, reinstalação entre prévia/aplicação, alteração concorrente de outra chave, backup falho, token expirado/replay e permissão revogada. Só a chave alvo muda; nenhum callback roda, nenhum post/opção/arquivo do plugin é removido. A opção continua protegida na API genérica. O registro dessas pendências não é alegação de execução na frota.


<a id="n04"></a>

## N04 — Leituras seletivas de conteúdo e revisões

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C04](#c04), [P07](#p07).

**Prioridade P2; pedidos 22 e 23(a), incluindo adendo de 28/09.** Adicionar fields a content/get-page, get-post e get-revision como lista não vazia de nomes permitidos, com validação de desconhecidos; não é expressão SQL. Omitido preserva a resposta legada. Campos de envelope success/erro/identidade indispensáveis continuam estáveis. Solicitar somente revision não inclui content nem corpo renderizado; filtros de conteúdo não devem rodar quando esse dado não foi pedido.

Permitir sha256, char_length e bytes do post_content bruto persistido, inclusive em revisão histórica; hash cobre os bytes, char_length usa semântica CHAR_LENGTH do banco padronizado e bytes é medida distinta. list-revisions devolve sha256 de cada revisão listada sem devolver seu corpo; list-pages/list-posts devolvem revision por item. Paginar/limitar e obter estado coerente por item, evitando misturar snapshot de uma linha com metadados de outra alteração. Redução de payload não garante zero leitura interna de conteúdo: ContentTools::revision atualmente inclui post/metas/termos.

Documentar semântica: id de revisão WordPress não é o token opaco revision. O revision de topo de list-revisions é do post pai atual (já acrescentado pelo decorator na base); cada sha256 da lista é do conteúdo histórico. get-revision preserva o significado do token já exposto para aquele objeto; acrescentar parent_revision apenas se explicitamente solicitado para a edição do pai. Não permitir usar hash de corpo ou ID histórico como expected_revision por acidente.

Permissão de leitura é por objeto e, nas revisões, também pelo conteúdo pai; projeção pequena não libera post privado. **Aceite:** id/slug, fields:[revision], omissão de fields, campo inválido, Unicode/barras/emoji, histórico e pai com estados diferentes, alterações só em metadata/thumbnail, paginação e concorrência. Tokens das listagens são aceitos pela mutação correspondente quando o alvo não mudou; não fazer aprovação de escrita só porque a projeção foi autorizada.


<a id="n05"></a>

## N05 — Leitura de uma chave de option

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C04](#c04), [F18](#f18), [P07](#p07).

**Prioridade P2; pedido 23(b).** Acrescentar key opcional a options/get, com a mesma semântica de chave de primeiro nível de options/update. Sem key, preservar contrato atual, sujeito à política de sigilo. key é literal: não interpretar pontos/barras como caminho JSON e não extrair arbitrariamente objetos. Para array, verificar existência da chave distinguindo ausência de false, zero, string vazia e null; opção ausente, opção escalar e chave ausente têm códigos claros.

Retornar name, key quando usado, value, type e metadados de redação, sem devolver as outras chaves. Honrar get_option/filtros de leitura e explicar se o resultado é efetivo/filtrado, sem anunciá-lo como bytes brutos de banco. Conservar manage_options e perfil; classificar opção/chave conforme F18 antes da projeção, evitando usar key como bypass de segredo. **Aceite:** wpseo sintético, chaves numéricas/literais, valores vazios/null, opção não array, ausência e configuração sensível; leitura não altera opção/cache por lógica própria nem exige SQL genérico.


<a id="n06"></a>

## N06 — Leitura gzip com filtros e limites de expansão

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [F09](#f09), [P07](#p07).

**Prioridade P2; pedido 23(c).** Adicionar compression com none (default legado), gzip e auto a files/read. auto reconhece assinatura e declara o modo efetivo; gzip explícito recusa formato incompatível. No modo descompactado, aplicar grep/grep_regex e seletores de linha sobre texto decodificado com a mesma ordem documentada; não executar shell, extrair em diretório público ou sobrescrever o arquivo. Validar zlib disponível e recusar binário descompactado com filtro textual sem transformá-lo silenciosamente.

Processar stream com teto independente de bytes comprimidos lidos, bytes expandidos examinados, tamanho de linha, memória, tempo e bytes de resposta. Defaults propostos para o exame por chamada: 16 MiB comprimidos, 64 MiB expandidos, tempo definido no orçamento do canal; resposta nunca excede o limite atual. A razão de compressão é diagnóstico, não o único freio contra bomba. Gzip truncado/corrompido recebe gzip_invalid; integridade só é atestada após EOF/CRC verificados. Suportar membros gzip concatenados dentro do mesmo orçamento e testar isso expressamente.

Não combinar leitura descompactada com cursor/offset_bytes do arquivo bruto; retornar conflicting_read_modes. Offset de linhas exige reinflar o prefixo e conta no orçamento; tail só é completo se o fluxo inteiro foi examinado. Ao atingir limite, retornar complete:false/truncated e motivo, distinguindo fim de resposta e fim do exame; não prometer continuação aleatória de stream gzip nem omitir esse limite. Nenhum cursor bruto é apresentado como offset descompactado. Hash parcial cobre apenas conteúdo decodificado retornado, com sha256_scope explícito; hash de arquivo compressed é separado quando solicitado/medido.

**Aceite:** log textual, Unicode, grep literal/regex, offset/tail, gzip vazio, membros concatenados, CRC inválido, truncado, expansão extrema, linhas longas, mudança/rotação, permissão/armazenamento privado e modos conflitantes. Conferir fidelidade e tamanho após transporte JSON/base64, sem carregar integralmente uma expansão não limitada.


<a id="n07"></a>

## N07 — Exclusão de menu clássico por API WordPress

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [O11](#o11), [P07](#p07).

**Prioridade P2; pedido 24.** Criar menus/delete por menu_id exato, manage_options não substitui a capacidade adequada edit_theme_options e o perfil. Usar duas fases O11, com prévia de menu, itens, relações, localizações do tema e referências conhecidas. Não confundir menu clássico (taxonomia nav_menu) com post wp_navigation. Se o menu estiver em uso, informar alcance e exigir acknowledge_in_use:true vinculado à confirmação. Não selecionar menus por prefixo nem deduzir abandono pela ausência de um leitor no código.

Preservar pré-imagem privada de termo, itens/metas/relações e localizações, com backup_id e classificação de dados; revalidar revisão sob locks de menu/localizações. Executar wp_delete_nav_menu e conferir ausência do termo/itens e atualização de localizações/cache. Não excluir as páginas/posts apontados pelos itens. Falha de hook/readback recebe resultado parcial por componente; não alegar transação entre todos os hooks/cache/serviços. Backup dá material de recuperação; não prometer restauração automática ou IDs preservados sem habilidade homologada para isso.

**Aceite:** menu vazio/preenchido, menu em uso sem/com reconhecimento, conteúdo referenciado preservado, ID de wp_navigation recusado, alteração concorrente, falha parcial/backup e replay. A exclusão dos três menus relatados já aconteceu; não pedir nem executar a mesma limpeza novamente.


<a id="n08"></a>

## N08 — Exclusão de options por nome em duas fases

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [O11](#o11), [F18](#f18), [P07](#p07).

**Prioridade P2; pedido 24.** Criar options/delete com names, lista limitada a 100 nomes exatos, normalizada sem curingas/prefixos/SQL; confirmação em duas fases vinculada à conexão e à seleção. Usar manage_options e perfil de manutenção. Reutilizar e ampliar a política central de opções protegidas de options/update, incluindo identidade do site, roles, active_plugins, auto_update_plugins, cron, rewrite_rules, uninstall_plugins e estado/segredos internos do canal. Não liberar uma option protegida só porque a operação é delete; usar a habilidade específica quando existir.

Prévia discrimina existentes/ausentes, tipo, autoload, sensibilidade e efeitos conhecidos, com valores redigidos por F18. Não afirmar “sem leitor” como fato verificado: callbacks/plugins carregados dinamicamente e ferramentas externas podem usar a opção. Antes de qualquer efeito, validar todos os nomes/permissões e persistir backup do lote existente com bytes/valores originais, metadado de autoload e indicação de sensibilidade. Referência de confirmação usa estado opaco, sem divulgar hash de segredo. Se todo o lote estiver ausente, responder no-op sem backup fictício.

Sob locks em ordem estável e pré-condições verificadas por item, chamar delete_option para cada nome. Preservar hooks e invalidação nativa de alloptions/option/notoptions; verificar banco e leitura efetiva depois. Filtro/hook que recria a opção ou falha intermediária gera estado parcial com itens removed/unchanged/failed/pending e backup_id, sem anunciar atomicidade do lote. Serializar com escritores cooperantes e validar corridas de escritores externos; se for necessária transação SQL para proteger a pré-imagem, não atribuir rollback aos efeitos externos dos hooks. Retomada/replay aplica só passos comprovadamente pendentes, com revalidação, sem repetir remoção registrada.

**Aceite:** lote misto, option serializada, autoload ligado/desligado, cache aquecido, opção protegida, valor secreto, escritor concorrente, hook que recria/falha, backup falho e token revogado/expirado. Os 34 nomes apagados por SQL no relato são evidência histórica, não tarefas a repetir. Os 288 postmeta _twinia_* ficam como pendência de conteúdo por IDs/keys/revisão em E01/O11; este endpoint não apaga postmeta nem faz limpeza automática por prefixo.


<a id="o01"></a>

## O01 — Perfis por conector

**Situação:** pendente. **Responsável funcional:** Responsável técnico + operação da frota.

**Dependências de implementação:** [C01](#c01), [C02](#c02), [C05](#c05), [C06](#c06).

Oferecer Leitura, Conteúdo, Manutenção e Personalizado. Restringir habilidades, tipos de conteúdo, caminhos e SQL. Descoberta, informações, executor genérico, planos e complementos respeitam a mesma política. Perfil nunca amplia capacidades WordPress.

Legado é apenas uma transição inventariada, com prazo de encerramento definido em O01. Novas habilidades não ampliam esse perfil silenciosamente. Novas conexões recebem um perfil selecionado na configuração da senha de aplicação ou na autorização OAuth.

Construir o perfil legado a partir do catálogo efetivamente exposto após o carregamento dos complementos instalados, preservando as capacidades WordPress e verificações por recurso. Incluir as habilidades Google e demais extensões já utilizadas; a lista de 100 habilidades do pacote principal não define sozinha esse catálogo. O aceite exige preservar o acesso anterior ao complemento Google e bloquear ampliação automática quando uma habilidade nova for adicionada depois.

A identidade virá da autenticação validada pelo servidor. `clientInfo`, nome amigável e parâmetros enviados pelo agente não identificarão a autorização. Credenciais antigas sem vínculo suficiente terão sua abrangência exibida; qualquer revogação com alcance maior será identificada na tela antes de ser executada.

A política protege as habilidades próprias em qualquer transporte e integração admitidos por C02. Outras APIs WordPress e código com privilégio de administrador não são uma sandbox; credenciais e usuários devem ter menor privilégio conforme O01.

O01 inclui escopos OAuth coerentes com os perfis, anunciados nos metadados e explicados no consentimento. O escopo legado `mcp` permanece reconhecido nas concessões existentes. Restrição de leitura vale também no executor genérico: escolher outra ferramenta não amplia a concessão. Anotações MCP orientam o cliente; a política do servidor decide o acesso. O03 depende explicitamente da proteção F10.

O02 permitirá expirar após 24 horas cadastros que nunca concluíram autorização, desde que nenhuma concessão válida dependa deles. Clientes com concessões ativas não serão removidos para abrir espaço. A troca de transients por estado durável é parte de F02/C05; o risco descrito para Redis não cria uma nova matriz de teste em uma pilha que não o utiliza.

Para arquivos, validar caminhos normalizados, origem, destino, diretórios ainda inexistentes e links simbólicos. Aplicar a política novamente após resolver referências de passos anteriores. Habilidades de execução indireta recebem classificação e verificações próprias.

Migração operacional obrigatória: matriz dos 14 conectores contendo site, identificador não secreto, usuário dedicado, tarefas, perfil alvo, raízes/abilities/SQL, responsável operacional e estado. Não concluir que 14 conexões com user_id 1 compartilham a mesma credencial; identificar grants/UUIDs. Reduzir capacidades WordPress com usuários de serviço por função; restrição só dentro de MCP não limita outras REST APIs do mesmo administrador.

Emitir credenciais novas por conector/perfil; homologar leitura/escrita permitidas e recusas; mudar o conector; revogar credencial antiga e família de refresh/sessões associadas; verificar recusa no alias e servidor default. Nunca revogar genericamente todo user_id 1 nem registrar segredos na matriz. Manutenção de PHP/plugin/SQL fica numa credencial administrativa separada, temporária, explicitamente classificada sem garantia de isolamento de dados.

Prazo proposto de implantação: matriz pronta antes do aceite; piloto migrado na ativação da release, demais conexões até D+5 dias úteis do rollout e Legado de rotina encerrado até D+7. São metas a atribuir ao operador no kickoff, não tarefas executadas. A entrega do software e o aceite operacional são distintos: não anunciar benefício de perfis se todos continuam Legado. Exceção temporária exige justificativa e expiração; sem exceção aprovada, rollout não é concluído.

Aplicar a exceção de coexistência Elementor de C02 na migração: testar conexão nativa válida, mapeamento de identidade e revogação de credenciais específicas, preservando o servidor e as integrações autorizadas. A migração por perfil não inclui desligar o segundo servidor.


<a id="o02"></a>

## O02 — Gestão de conexões

**Situação:** pendente. **Responsável funcional:** Engenharia PHP + operação da frota.

**Dependências de implementação:** [C01](#c01), [C02](#c02), [C05](#c05), [O01](#o01).

Exibir cliente, usuário, perfil, último acesso, sessões e revogação. Revogar a concessão bloqueia novas chamadas, renovação e próximos passos de planos vinculados. Tratar famílias de refresh e detectar reutilização.



<a id="o03"></a>

## O03 — Executor de leitura configurável

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [F10](#f10), [C02](#c02).

Entregar ferramenta opcional Execute Readonly Ability com classificação confiável e recusa de mutantes/executores indiretos/desconhecidos. Permissões iguais no executor genérico, nas abilities e em outras portas; nomes de ferramentas não são uma barreira. tools/list dependente de credencial requer cacheScope:private no protocolo 2026. Testar troca de credencial, revogação e replay sem vazamento de lista/resultado.



<a id="o04"></a>

## O04 — `operations/list`

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C02](#c02), [C03](#c03), [C05](#c05).

Listagem paginada de planos acessíveis ao usuário/conexão, com status, progresso e operações relacionadas.



<a id="o05"></a>

## O05 — `operations/preview`

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C03](#c03).

Apresentar alvos, diferenças disponíveis, permissões, pré-condições, efeitos externos e capacidade de compensação por passo. Não executar callbacks mutantes para gerar prévia.



<a id="o06"></a>

## O06 — `operations/cancel`

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C03](#c03), [C05](#c05).

Registrar pedido durante a execução e impedir os passos seguintes. Informar o resultado da etapa que já estava em andamento. Repetir o cancelamento não altera o resultado final.

O pedido de cancelamento terá estado independente do bloqueio longo de execução do plano. `apply` consultará esse estado antes de iniciar cada passo e não o sobrescreverá ao salvar progresso.

Transição normal: `running` → `cancel_requested` → `cancelled`, após registrar o resultado da etapa em andamento. Se o resultado dessa etapa ficar incerto, a resposta preserva essa condição para reconciliação. `cancelled` não significará reversão dos efeitos já aplicados. Compensação será uma ação identificada, autorizada e limitada às etapas com inversa comprovável.

A prévia marcará cada passo como simulável, dependente de resultado anterior ou sem simulador disponível. Guardará revisão/hash dos alvos conhecidos e identificador da prévia. A aplicação verificará mudanças desde a prévia e pedirá nova avaliação por meio de erro de conflito quando necessário.

<a id="o07"></a>

## O07 — Histórico e backups

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C05](#c05), [F18](#f18).

Filtros por conector, usuário, habilidade, período e resultado; navegação por `operation_id`; ligação com backup e exportação sem segredos.

“Exportação sem segredos” refere-se ao histórico/relatório de diagnóstico. Exportação restaurável de backup pode conter valores originais e exige autorização específica de conteúdo, conforme [F18](#f18); não prometer que base64 remove ou cifra segredos.


<a id="o08"></a>

## O08 — Retenção e manutenção

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C05](#c05).

Limpeza incremental por categoria, idade e volume, com simulação, checkpoint, proteção de estados necessários e informações de espaço utilizado.

O contexto novo poderá distinguir conexões do mesmo usuário. A transição consultará as chaves legadas antes de criar novo registro, com checagem de autorização e fingerprint. Atualização de versão ou alteração da chave de armazenamento não autorizará repetir um efeito antigo.

| Categoria | Tratamento inicial |
| --- | --- |
| Auditoria | Política configurável por idade e volume, com exportação e limpeza em lotes. Proposta inicial: 90 dias. |
| Backups | Exibir ocupação e simulação de limpeza. Preservar referências de planos e compensações. Exclusão automática exige política explicitamente habilitada. |
| Códigos OAuth e sessões expiradas | Remover por expiração, usando o estado autoritativo. |
| Idempotência concluída | Permitir compactar o resultado após a janela documentada, conservando comprovante de consumo/fingerprint que impeça repetição silenciosa. |
| Operação incerta ou plano ativo | Preservar até reconciliação ou encerramento explícito. |
| Referência externa de conteúdo | Preservar o vínculo estável. |
| Arquivos de bloqueio | Excluir da limpeza genérica. |

Os novos controles de retenção iniciarão em modo de simulação. O operador habilitará a política de exclusão após visualizar o alcance. Essa etapa é um comportamento de produto para operações destrutivas sobre o histórico.

Pedido 7: backups/prune ganha include_legacy:boolean, default false. Em true, a prévia enumera também os backups reconhecidos da raiz legada f3-mcp-backups, inclusive pares .json/.bak e backups de banco, por ID/tipo/tamanho/data; não trata qualquer arquivo da pasta como backup. Classificar pares incompletos/corruptos como bloqueados para inspeção, sem apagar arquivo desconhecido, link, índice de silêncio ou proteção HTTP. Manter referências de operações/reversões e escopo do site.

Aplicação continua explícita com dry_run:false; para incluir legados, exigir o fingerprint expected_selection_sha256 devolvido pela prévia, revalidar seleção/conteúdo sob lock e retornar backup_selection_conflict se houver mudança. Apagar somente os componentes daquela seleção, em lotes/checkpoints e com contagem por categoria; falha parcial mostra componentes restantes. Repetição não amplia seleção nem apaga backup novo que passou a satisfazer a consulta. Testar retenção com diretório legado grande, arquivos estranhos, pares ausentes, concorrência e falha no meio. Não executar limpeza na ativação da release.


<a id="o09"></a>

## O09 — Diagnóstico e UX

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [O02](#o02), [O04](#o04), [O07](#o07), [O08](#o08).

Diferenciar registro local, teste HTTP, teste OAuth e acesso autenticado observado. Exibir versão de protocolo, última falha classificada e escopo de cada teste. JSON recolhível e copiável.

Manter **Conexão** e **Configurações** e acrescentar **Conectores**, **Operações** e **Histórico e armazenamento**. A organização final pode usar abas ou seções da página existente, com navegação consistente.

Na conexão: URL principal, alias de compatibilidade, copiar configuração e testar, com detalhes técnicos expansíveis. Não recolocar versão WordPress como pré-requisito visual. Na gestão de conexões: alcance do perfil e da revogação. Nas operações: estado, etapa atual, diferenças, cancelar e resultado parcial. No histórico: filtros, espaço e última manutenção.

Registrar separadamente testes iniciados pelo próprio plugin. “Acesso externo observado” dependerá de uma chamada autenticada identificável como externa; ausência de evidência será exibida como “ainda não observado”.

<a id="o10"></a>

## O10 — Integração dos complementos

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C02](#c02), [C06](#c06).

Publicar contrato de registro, autorização, classificação e resultado. Homologar o complemento Google efetivamente instalado; comportamento legado permanece documentado durante a adoção.



<a id="o11"></a>

## O11 — Exclusões em duas fases

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C02](#c02), [C03](#c03), [C05](#c05).

Prévia e confirmação vinculadas à conexão, alvo, parâmetros, revisão e expiração para exclusões permanentes. Cobrir usuários, mídia, plugins, comentários e conteúdo com `force:true`; manter o comportamento documentado de lixeira.

Prévia enumera alcance, efeitos e restauração disponível. users/delete exige reassign_to válido ou delete_content:true explícito. Confirmação de uso único vinculada à conexão, alvo, parâmetros, revisão e expiração; revalidar permissão. Preview não marca efeito como concluído. Repetição idempotente retorna resultado anterior sem excluir novamente. Mídia exige original, derivados, metadados e referências; copiar arquivos apenas não recompõe attachment. Lixeira mantém seu contrato existente.

Incluir as novas exclusões tipadas N07/N08 e os efeitos auxiliares de F22. Menus/options não herdam autorização de SQL; registrar pré-imagem, estado parcial e limitações de recuperação por tipo.


<a id="o12"></a>

## O12 — Atualização e reversão de pacotes

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [F14](#f14), [P06](#p06), [O13](#o13).

Staging, hash/slug esperados, pré-imagem, `plugins/rollback`, versões e ativação antes/depois. Compartilhar serviço com F14, incluindo sonda e cache.

Compartilhar coordenação de pacotes com F14. expected_sha256 refere-se aos bytes do ZIP baixado/decodificado; expected_slug identifica raiz/entrypoint esperado. Validar caminhos antes de extrair. Pré-imagem persistida antes da troca, contendo árvore e versão/ativação. Rollback exige pós-imagem compatível sob lock e não sobrescreve mudança posterior. Retornar backup_id, old_version/version/changed e aliases versao_anterior/versao/mudou, ativação observada, sonda e recuperação. Arquivos/ativação não desfazem migrações de banco nem hooks externos. No-op/novo pacote sem pré-imagem não inventa backup. Backups temporários do núcleo não substituem o backup persistente da habilidade.

<a id="o13"></a>

## O13 — `system/probe`

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

Sonda anônima de mesma origem, asserções e medição com procedência de cache/tempos. Proteção HTTP exige teste específico; critérios nesta especificação.

system/probe será habilidade administrativa autenticada; suas requisições HTTP serão anônimas, sem cookies/credenciais do usuário. Receber caminhos relativos à origem de home_url(), GET/HEAD, asserções tipadas e limites de quantidade/tempo/bytes. Revalidar origem em cada redirect; não aceitar URL arbitrária nem Authorization. Resolver REST conforme permalinks/subdiretório.

O perfil padrão verifica home e REST; espera HTTP 200 quando esse é o contrato da instalação, documentando redirects canônicos. Medir antes/depois. Verificar corpo: página de erro pode retornar 200; rota previamente protegida pode responder outro status legitimamente.

**Ajuste da reversão solicitada:** não usar “qualquer não-200” isolado como causa automática. Asserção obrigatória já falha antes impede atualização automática por pré-condição falha. Se passa antes e falha depois, confirmar segundo política limitada de tentativas e reverter. Timeout/inconclusão têm estado próprio e não aprovam a operação. Política conservadora pode reverter por impossibilidade de verificar, identificando esse motivo sem atribuir causalidade ao pacote.

**Proteção HTTP:** system/health.http_protection_tested depende de teste específico com marcador inofensivo, mapeamento HTTP seguro do local pertinente, verificação de ausência de exposição e limpeza. Registrar escopo, data e fingerprint. Home/REST aprovados não comprovam proteção do armazenamento. Sem URL mapeável ou resultado conclusivo, manter false com motivo; não inventar URL nem buscar backups reais pela web. Health consulta a última evidência válida; teste novo é explícito e limitado.

**Tempos e cache:**

| Campo | Evidência necessária |
| --- | --- |
| total_ms | Duração observada da requisição HTTP. |
| ttfb_ms | Medição específica do transporte; se indisponível, null com motivo. Não usar tempo total como substituto. |
| generation_ms | Instrumentação PHP comprovada, com início/fim e trecho medido. Não equivale à latência total da rede. |
| cache_status | hit, miss, bypass ou unknown, com procedência de integração/cabeçalhos permitidos. |
| cache_bypass_verified | Verdadeiro somente quando o bypass de cache de página foi comprovado. |

Query aleatória ou Cache-Control:no-cache isolados não provam bypass. Homologar o adaptador de WP Super Cache na pilha e separar cache de página, CDN/proxy, object cache e OPcache. Bypass de página não torna os demais caches frios. Sem prova, classificar cache desconhecido e não anunciar “geração sem cache”.

Usar poucas amostras limitadas, devolver cada amostra/estatísticas e tamanho da amostra; não criar benchmark contínuo nem invalidar cache indiscriminadamente. O relato de 1,1–2,8 s orienta investigação, sem determinar a camada causal.

Pedido 3 complementado: contrato inclui método GET/HEAD, cabeçalhos por allowlist, asserções de status, contém/não contém e cabeçalho, sha256 do corpo recebido e resultado individual de cada asserção. Não aceitar Cookie/Authorization/Proxy-Authorization, Host arbitrário ou credenciais repassadas; validar nomes/valores, redirects e limites. HEAD não produz evidência de conteúdo: asserção de corpo incompatível deve ser recusada. O resumo identifica execução a partir do servidor/origem interna e não prova que um cliente externo atravesse o filtro da hospedagem que retornou 429. Sondas especializadas do Core continuam especializadas; este serviço é a sonda genérica única da pilha e será reutilizado por F20.


<a id="o14"></a>

## O14 — Canal de atualizações Fator3

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [O12](#o12), [P06](#p06), [O10](#o10).

Manifestos/`Update URI`/oferta nativa dos três pacotes, com dependências coordenadas e preservação do bloqueio de autoatualização até recuperação independente.

Manifesto versionado por MCP/Core/Google: identidade/arquivo principal, version, url, sha256, requires tipado para WP/PHP e tested com procedência. Update URI e filtro update_plugins_<host> alimentam oferta nativa; plugins/update atual já consome esse mecanismo, sem exclusividade técnica de wordpress.org. Validar origem HTTPS/redirects/digest também no painel. Fixar versões das dependências e ensaiar atualização/recuperação coordenadas. Autoatualização MCP depende de P06 homologado, incluindo autoload; proibir bypass por upload direto.

Pedido 2: conservar a decisão operacional de manter MCP/Core/Google fora de auto_update_plugins até canal próprio e recuperação homologados; a entrada posterior depende de decisão da frota. Não alterar esse estado só ao instalar a release. A documentação deve distinguir ausência de Update URI de Update URI: false: o valor false já inibe ofertas homônimas do wordpress.org no mecanismo documentado do WordPress; ele não fornece o feed Fator3. Conferir ofertas/handlers realmente instalados no aceite. O relato “plugins/update só usa wordpress.org” descreve a oferta observada, não uma restrição universal do consumo de ofertas nativas.

Planejar publicação coordenada na ordem solicitada core → google → canal, com manifesto/compatibilidade verificando que os pacotes iniciais ainda funcionem sob MCP 0.12.1 até o último passo. Se houver dependência inversa, resolver o bootstrap no empacotamento antes de autorizar implantação; não reordenar ou instalar silenciosamente. Este documento não concede publicação.


<a id="o15"></a>

## O15 — Descoberta e inventário econômicos

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C02](#c02), [C06](#c06).

`if_catalog_sha256`, `unchanged`, projeções e `plugins/list` com `campos`/`prefixo`, normalizados para os contrato normalizado descrito abaixo.

if_catalog_sha256 é comparado ao catálogo autorizado/filtros/projeção; não faz parte do hash, assim como o offset da página. Igualdade devolve unchanged:true sem catálogo. plugins/list.campos é alias de fields; prefixo literal é normalizado para prefixes; omissão preserva contrato anterior. Normalizar aliases antes de hash/idempotência e recusar valores diferentes. Mudança de política/provedor invalida reaproveitamento. O cache do catálogo MCP deve respeitar M02; versões de provedores vêm de C06.

<a id="o16"></a>

## O16 — Backups rotulados

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C05](#c05).

`rotulo`/`label` nas mutações com backup, índice e filtros por rótulo/data; registros legados continuam consultáveis.

cobrir files/write, patch, delete e move, além das mutações com backup já previstas. Move distingue origem/destino e IDs. No-op, novo arquivo ou rmdir sem pré-imagem não inventam backup_id. Legados mantêm rótulo ausente. Filtro literal e intervalo UTC com início inclusivo/fim exclusivo, combinável com paginação/caminho. Limitar comprimento e não usar rótulo como caminho físico.

<a id="o17"></a>

## O17 — Cron e autoteste com evidência

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07), [O13](#o13).

Entregar cron e selftest completo: passed/failed/skipped/not_configured separados; nenhum estado não configurado conta como aprovado. Documentar alcance, identidade PHP e limitações somente com evidência. http_protection_tested depende de O13, não de presença de regra no disco. Cron segue os detalhes abaixo.

wp_cron_desabilitado reflete configuração, sem concluir que agendador externo parou. eventos_vencidos agrega quantidade/atraso com limites e sem expor argumentos dos jobs. ultimo_disparo registra um marcador efetivamente executado, timestamp e escopo; permanece null antes da primeira observação. Marcador executado não prova sucesso de todos os jobs; não usar instalação ou próxima agenda como último disparo.

<a id="o18"></a>

## O18 — Contagem de tabelas

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P07](#p07).

`db/schema` com tabela selecionada e `contar:true` (alias `exact`) retorna `rows_exact`; preservar estimativa em `rows_estimate` e alias legado `rows`.

table válida + contar:true faz contagem exata sob orçamento. Retornar rows_estimate, rows_exact e data; timeout produz rows_exact:null e estado explícito. rows legado permanece estimativa. Não contar todas as tabelas nem extrapolar amostras.

<a id="o19"></a>

## O19 — Ajuda embarcada

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [D05](#d05).

`system/guide` fornece instruções da versão instalada por tema, contratos e exemplos; descrições de habilidades usam português consistente e parâmetros derivados do schema. Identificadores existentes permanecem estáveis.



<a id="o20"></a>

## O20 — Planos de atualização

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C03](#c03), [O12](#o12), [O13](#o13).

Permitir upload/rollback após O12/F14; passos tipados de leitura/assertiva para probe/inventário. `db/execute` permanece fora; não injetar idempotência em schema que a recusa.

Planos validam tipos, autorização, hash/revisão e resultado de passos; permitem upload/rollback depois dos serviços O12/F14/O13. Leitura/assertiva pode consumir resultado anterior, com revalidação. Prévia não executa mutação nem download/ativação irreversível. db/execute permanece excluído; não injetar idempotência em schema de terceiro que não a aceita.

<a id="e01"></a>

## E01 — Metadados estruturados

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C02](#c02), [C04](#c04), [C06](#c06).

Novas habilidades de leitura/atualização de metadados registrados, com tipos, schema, capacidades, campos protegidos, revisão e valor efetivamente salvo.

O pedido 24 registra 288 postmeta _twinia_* alegadamente sem leitor. A edição/exclusão tipada de metadados deste item deve permitir selecionar explicitamente post/ID de meta/chave autorizada, preservando múltiplos valores, permissão por objeto, pré-imagem e confirmação O11 quando destrutiva. Não usar exclusão por prefixo em toda a frota nem classificar chave como órfã só pelo nome. Manter a limpeza concreta pendente de decisão e inventário; não removê-la ao instalar o pacote.


<a id="e02"></a>

## E02 — Adaptador SEO sem duplicação de contratos

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [P01](#p01), [O10](#o10), [E01](#e01).

P01/O10 levantam catálogo e schemas das versões atuais de Yoast e Base Site Core. Produzir matriz campo necessário → API/ability existente → lacuna e teste. A afirmação de que Yoast expõe somente pontuações não é aceita sem verificar a API/versão em uso. Reutilizar abilities existentes quando cobrem o contrato; implementar somente lacunas comprovadas com APIs do provedor, autorização/revisão/readback. O requisito é cobertura SEO estruturada, não duplicar 21 rotas nem escrever opções privadas por suposição. Registrar indisponibilidade sem SEO instalado.



<a id="e03"></a>

## E03 — Validação de blocos

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [F11](#f11), [C04](#c04), [F17](#f17).

Validar estrutura e atributos antes da escrita; verificar conteúdo persistido; informar filtros que alteraram o conteúdo. Validar no editor os blocos usados nos sites da Fator3.

Validar estrutura/atributos antes da escrita e readback depois. Reabrir no editor os blocos realmente usados na frota; declarar limitações de blocos de terceiros. Divergência não prova por si só qual filtro modificou o conteúdo.

A proteção local contra perda de filhos é [F17](#f17), implementável sem aguardar toda a validação JavaScript/editor deste item. O aceite integrado cobre os dois contratos e reaproveita suas fixtures.


<a id="e04"></a>

## E04 — Upload por partes

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C02](#c02), [C03](#c03), [C05](#c05).

Criar, enviar parte, consultar estado, finalizar e cancelar transferências. Validar tamanho, hash, propriedade, perfil e destino; permitir retomada e repetir uma parte idêntica com segurança.

Na finalização: montar temporário, adquirir lock do destino, conferir perfil/hash, criar backup, substituir e verificar. Limpeza de partes abandonadas respeita propriedade, atividade e prazo. Parte repetida idêntica é idempotente; parte diferente conflita. Limitar tamanho total, partes, concorrência e disco. Não há demanda acima de 16 MiB comprovada neste relatório; permanece no escopo por decisão explícita de entrega integral, com custo visível.

<a id="e05"></a>

## E05 — Exportação de backup por partes

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C02](#c02), [O08](#o08), [F18](#f18).

Exportar por cursor/parte, mantendo identificação e hash do conteúdo; retomar interrupções sem montar toda a exportação em memória.

Exportação retomável com cursor vinculado a backup/hash, autorização por chamada, expiração e memória limitada. Uma alteração do acervo não pode misturar partes de versões diferentes. A ausência de demanda demonstrada não elimina o ID aprovado; medir utilização após entrega.

Aplicar [F18](#f18) à exportação integral e por partes: o perfil que só consulta metadados não recebe conteúdo original. Cursor, hash e fragmentos não podem ser usados para contornar a autorização. Revogação bloqueia continuação; não fornecer uma exportação redigida como se fosse backup restaurável íntegro.


<a id="e06"></a>

## E06 — Regeneração de mídia

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [C03](#c03).

`media/regenerate` valida attachment, capacidade e revisão; usa mecanismos WordPress e devolve arquivos/tamanhos reais e metadados persistidos.

E06/E07 preservam original, attachment e metadados; retornam derivados produzidos, falhas por tamanho e opção persistida. Reaproveitar locks de attachment/uploads e coordenar site_icon. Derivar tamanhos do WordPress/filtros; não fixar quatro. Testar fonte insuficiente, falha de escrita, derivados existentes, repetição e concorrência. Não excluir arquivo referenciado como limpeza. O fluxo substitui a necessidade relatada de mu-plugin temporário.

<a id="e07"></a>

## E07 — Ícone do site

**Situação:** pendente. **Responsável funcional:** Engenharia PHP.

**Dependências de implementação:** [E06](#e06).

`media/set-site-icon` valida imagem/dimensões, executa o fluxo Site Icon e verifica opção, derivados e URLs.

Usar o fluxo Site Icon, derivando tamanhos de WordPress/filtros; nenhum número fixo de quatro recortes. Coordenar lock do attachment/uploads com site_icon, preservar original e metadados, informar falha parcial. Referência aos requisitos comuns de mídia em E06.

<a id="m01"></a>

## M01 — Integração upstream por revisão

**Situação:** pendente. **Responsável funcional:** Engenharia de integração MCP.

**Dependências de implementação:** [P01](#p01), [P07](#p07).

Integrar seletivamente o upstream após comparação com as adaptações Ultimate/Fator3. PR WordPress/mcp-adapter #310 confirmado merged em 21/09/2026, commit 8bd4a67810da853683ab2e122af394cfe3b7b631. composer.json desse commit depende de wordpress/php-mcp-schema ^0.2.0. Fixar resolução/lock e inventário reais; não aguardar merge nem copiar classes sem revisar namespaces/colisões com adapter de terceiro. Preservar URLs, OAuth e contratos Fator3. O PR declara não incluir MRTR; validar cobertura completa das capacidades que serão anunciadas. Não herdar os testes upstream como homologação do plugin integrado.

A integração/rebase deverá preservar [F16](#f16), inclusive URI/MIME aninhados, permissão na leitura e deduplicação entre requisições. A correção local F16 não aguarda o rebase do protocolo; testar novamente depois dele.


<a id="m02"></a>

## M02 — Contrato MCP dual verificável

**Situação:** pendente. **Responsável funcional:** Engenharia de integração MCP.

**Dependências de implementação:** [M01](#m01).

Fixar e ensaiar modo legado exigido pelos clientes e 2026-07-28. O fonte 0.12.1 anuncia 2025-06-18; upstream #310 anuncia 2025-11-25/2026-07-28. Negociação/fallback dos clientes atuais deve ser provada ou adaptada, sem presumir equivalência dessas revisões. No modo 2026: sem initialize/sessão MCP; server/discover; metadados _meta por requisição; erro UnsupportedProtocolVersion -32022; MCP-Protocol-Version coerente com corpo; Mcp-Method em requests e Mcp-Name onde a revisão exige (tools/call, resources/read, prompts/get), com mismatch rejeitado. resultType conforme schema; ttlMs>=0 e cacheScope nos resultados cacheáveis completos. Lista por credencial usa private e não é reutilizada entre contextos autorizados. Não confundir hash do catálogo de abilities com cache do protocolo.

Negociar capacidades reais, recusar batch/formatos inválidos e tratar métodos/notifications segundo a revisão; não usar a regra genérica F06 para forçar notification legada no modo 2026. Testar corpos/headers crus positivos e negativos, codificação de Mcp-Name, limites e vazamento entre perfis. Funcionalidade opcional de protocolo só é anunciada se implementada/testada, inclusive MRTR se suportado. Os clientes antigos mantêm initialize e sessões apenas em seu modo.



<a id="m03"></a>

## M03 — Autorização e metadados de cliente

**Situação:** pendente. **Responsável funcional:** Engenharia de integração MCP.

**Dependências de implementação:** [M01](#m01), [C05](#c05).

Entregar Client ID Metadata Documents com origem/redirects/limites e binding ao issuer; manter DCR depreciado como compatibilidade. Incluir iss na resposta de autorização conforme RFC 9207 e testar validação/binding no fluxo; documentar SHOULD do servidor sem alegar que é sempre MUST. DCR exige application_type adequado e credenciais vinculadas ao emissor. Revogação atua por concessão/token independentemente da sessão de protocolo.



<a id="m04"></a>

## M04 — Compatibilidade por cliente

**Situação:** pendente. **Responsável funcional:** QA de conectores.

**Dependências de implementação:** [M01](#m01), [M02](#m02), [M03](#m03), [F16](#f16).

Aprovar jornadas completas dos conectores usados pela Fator3, em ambas as URLs: autorização, descoberta, execução, renovação e reconexão.



<a id="d01"></a>

## D01 — Manual exclusivamente instalado

**Situação:** pendente. **Responsável funcional:** QA/documentação + responsável técnico.

**Dependências de implementação:** consultar a base/fixtures e os contratos comuns; fechamento integrado conforme o plano.

OPERACAO.md descreve somente o contrato implementado da versão de referência; nesta preparação continua 0.12.1, com defeitos/limites conhecidos. Remover instruções previstas do manual. PREPARACAO contém escopo futuro e aponta para especificação canônica por ID. Ao construir a release, gerar/revisar manual a partir dos contratos efetivos homologados.

Na revisão 7, o manual mantém o comportamento instalado e documenta a regra do dono de aguardar o pacote, inclusive para correções baratas/reversíveis. Não transformar os relatos de 28/09 em funcionalidades já disponíveis. Só a sessão que conferir uma entrega remove itens da lista de frota, citando a evidência correspondente.


<a id="d02"></a>

## D02 — README, changelog e estado de entrega

**Situação:** pendente. **Responsável funcional:** QA/documentação + responsável técnico.

**Dependências de implementação:** consultar a base/fixtures e os contratos comuns; fechamento integrado conforme o plano.

Preparação documental feita; manter 0.12.1 como versão do código até implementá-la. Na release, sincronizar `VERSION`, cabeçalho, constante, README, changelog, nomes de artefatos e hashes. Anunciar somente correções entregues.



<a id="d03"></a>

## D03 — Descrições e schemas expostos aos agentes

**Situação:** pendente. **Responsável funcional:** QA/documentação + responsável técnico.

**Dependências de implementação:** consultar a base/fixtures e os contratos comuns; fechamento integrado conforme o plano.

Implementação pendente. Corrigir em conjunto com F01–F23, N01–N08 e demais itens, textos falsos sobre SQL, binários, defaults, alcance e patch; incluir campos injetados pelo runtime. Preservar nomes técnicos, permissões e callbacks fora das mudanças funcionais aprovadas.

Incluir nas descrições efetivas: `children` para substituir filhos e a recusa de `inner_html` em contêineres; busca por arquivo ou diretório; indicação de `system/health.storage.path` em erro de armazenamento privado; limites de redação e aviso de que backup de SQL guarda valores originais; finalidade restrita da limpeza de registro órfão. Os novos códigos/campos estarão no schema pós-decorador e nos exemplos homologados.

Cobrir adicionalmente sondas de PHP/reversão, ordem de featured_media e revision, projeções fields, chave de option, leitura gzip, grep_regex em busca, include_legacy na retenção e novas exclusões tipadas. Os motivos de rejeição de SQL/regex devem orientar o agente sem devolver segredos. Documentar o subconjunto de escrita com seleção complexa de F23, mantendo confirmação em duas fases.


<a id="d04"></a>

## D04 — Migração e recuperação

**Situação:** pendente. **Responsável funcional:** QA/documentação + responsável técnico.

**Dependências de implementação:** consultar a base/fixtures e os contratos comuns; fechamento integrado conforme o plano.

Documentar formatos de F02/F04/F05/F07/C05, migração de perfis/credenciais de O01/O02, checkpoints, retomada, revogação e reversão testada sem ressuscitar credenciais. Não herdar a afirmação de “sem migração” da 0.12.1.



<a id="d05"></a>

## D05 — Especificação única e prova de coerência

**Situação:** pendente. **Responsável funcional:** QA/documentação + responsável técnico.

**Dependências de implementação:** [C04](#c04), [C06](#c06), [P07](#p07).

Cada ID tem uma seção canônica em ESPECIFICACOES.md, com regras próprias e referências comuns; os demais documentos remetem a essas seções. Não manter versões normativas independentes em plano/manual/preparação/checklist. Exportar schemas após decoradores para JSON versionado, capacidades e exemplos reais; confrontar nomes/tipos/defaults/aliases/permission/error/retorno com testes de contrato. Igualdade de cópias prova só sincronização de arquivos, não semântica. Reportar distintamente link/JSON/hash, contrato schema↔execução e jornada real.



<a id="d06"></a>

## D06 — Gate do pacote completo no laboratório real

**Situação:** pendente. **Responsável funcional:** QA/documentação + responsável técnico.

**Dependências de implementação:** [P07](#p07), [D05](#d05).

Adaptar build/validação aos diffs funcionais e executar em P07, sem usar SQLite/PHP embutido como evidência de concorrência MySQL/Apache. Fonte, instalador, documentação e schemas do mesmo commit; lint/análise estática, build determinístico, hashes e exclusão de desenvolvimento. Gate completo é 0.12.1→0.13.0, single-site; aceitar fator3-teste-mcp-1 após suíte automática, sem testar destruição primeiro na frota.

Confrontar o artefato final também com cada número da matriz DEMANDAS-2026-09-29, preservando o 16 retirado. Cobertura no plano não equivale a entrega. Registrar versão/hash/caso de teste e resultado por pedido; somente depois do aceite autorizado atualizar o backlog original. Publicação da frota exige decisão do dono e ordem core → google → canal.


<a id="d07"></a>

## D07 — Links, histórico e distribuição

**Situação:** pendente. **Responsável funcional:** QA/documentação + responsável técnico.

**Dependências de implementação:** consultar a base/fixtures e os contratos comuns; fechamento integrado conforme o plano.

Patch documental sincronizado em 24/09; checklist de release incluído. Manter relatórios históricos intactos e identificados; nenhum link de uso corrente deve apontar para documento removido. Documentação permanece nas fontes; `system/guide` exige implementação própria em O19.



<a id="d08"></a>

## D08 — Documentação externa coordenada

**Situação:** pendente. **Responsável funcional:** QA/documentação + responsável técnico.

**Dependências de implementação:** consultar a base/fixtures e os contratos comuns; fechamento integrado conforme o plano.

Manual localizado revisado. Identificar cópias ativas no implantador/skill, comparar a versão vigente e registrar adoção ou pendência com responsável. Não reescrever contratos do Core/Google sem conferir seus fontes e schemas atuais.
