# Atualização e recuperação — WP MCP Fator3 0.13.0

A base operacional é **0.12.1 estável**. Os números de versão e hashes devem corresponder ao relatório do pacote homologado. Um checkpoint de fontes, cabeçalho ainda na base ou gate pendente não constitui instalador aprovado.

## Preparação do operador

Faça backup independente de banco e arquivos; registre a versão e o hash da base. Mantenha acesso à hospedagem para recuperar um erro que impeça painel e REST. Confira filesystem direto, InnoDB, espaço para staging/pré-imagem e a origem HTTPS efetiva. Não apague o plugin para atualizá-lo: a exclusão chama o desinstalador.

A matriz de migração deve identificar cada um dos 14 conectores pelo site, UUID/grant não secreto, usuário, tarefas, perfil alvo, raízes, exceções SQL, responsável, prazo e estado. Não conclua que todas as conexões de user_id 1 compartilham a mesma credencial. Não inclua senhas ou tokens na matriz. A aba Conectores registra substituta, responsável, prazo e tarefas; os campos não executam a migração.

## Ordem de atualização

A implantação coordenada segue **Core → Google → MCP**, usando os pacotes de compatibilidade homologados e seus manifestos. Core/Google precisam continuar funcionais com MCP 0.12.1 até a última etapa. Os alvos fixados são Core 1.17.1, Google 0.4.1 e MCP 0.13.0, ainda sujeitos ao gate; não instale uma dependência que exija MCP novo antes dele sem resolver o bootstrap.

A entrada de 0.12.1 em 0.13.0 precisa do procedimento da hospedagem/painel homologado para a troca inicial, pois a base não contém o novo executor independente. Conserve acesso de recuperação e confira ativação efetiva após a substituição. Nas atualizações posteriores pelo canal, `plugins/update` usa o diário e o executor MU; upload genérico do próprio MCP e atualização nativa sem diário são recusados.

Pasta e entrypoint permanecem `wp-mcp-fator3/wp-mcp-fator3.php`. A URL principal é `/wp-json/mcp/wp-mcp-fator3`; o alias `/wp-json/mcp/wp-mcp-ultimate` continua válido. Copie a URL efetiva do painel em sites com subdiretório/query. Os nomes de metatools preservam compatibilidade.

## Migração de estado e conexões

O plugin cria tabelas próprias InnoDB com `dbDelta` e verifica índices/engine. Códigos, grants, tokens, sessões legadas, idempotência, auditoria, operações e checkpoints passam a ter persistência durável. Importação legada conserva a expiração original e registros de consumo; um token expirado não renasce. Backups antigos permanecem legíveis; a atualização não os apaga.

Identidades antigas elegíveis recebem perfil Legado temporário com catálogo congelado após carregar complementos. A janela automática inicial é de sete dias a partir da instalação da política; não é renovada a cada requisição. Novas identidades sem perfil não ganham administração implícita. Cadastros de cliente OAuth nunca autorizados podem expirar em 24 horas; concessões válidas são preservadas.

Para cada conector: crie usuário de serviço com capacidades adequadas, emita credencial com perfil, teste operações permitidas e recusadas, atualize a configuração do cliente e só então revogue a identidade antiga. Revogar grant bloqueia sua família de tokens; revogar UUID remove apenas aquela senha de aplicação. Sessões legadas vinculadas são marcadas revogadas. Credenciais identificadas apenas por usuário/client legado têm abrangência indicada na interface.

O plano operacional propõe piloto no aceite, demais conexões até D+5 dias úteis e fim do Legado de rotina até D+7; a atribuição concreta é do operador. Exceções precisam de justificativa e expiração. Uma instalação em que todos continuam Legado não concluiu a migração de privilégios.

## Conferência após a troca

Confira `system/capabilities`, as duas URLs, leitura pelo conector real, perfil efetivo, catálogo dos complementos e recusa das antigas credenciais revogadas. Reabra no editor os blocos usados no piloto. Use `system/probe` para home/REST e invariantes específicas do site, e verifique os recursos Elementor preservados no seu servidor nativo. O teste local do painel não substitui essas verificações externas.

Não habilite automaticamente `auto_update_plugins` para MCP/Core/Google. A instalação mantém a decisão operacional existente; configurar feeds não habilita atualização automática. Um erro 429 deve ser correlacionado à requisição externa e aos logs da hospedagem antes de alterar políticas globais.

## Recuperação

Diários e pré-imagens ficam no acervo privado mostrado em `system/health.storage.path`. A sentinela `mu-plugins/000-f3-mcp-recovery.php` usa o runtime independente `f3-mcp-recovery-runtime-v1.php`; ambos permanecem fora da pasta substituída. Ela recupera operações abandonadas apenas após expiração do lease e ausência do bloqueio do processo original. Uma pós-imagem diferente da esperada causa conflito, sem sobrescrever trabalho de terceiro. Após atualizar o pacote, uma sentinela existente recebe o runtime correspondente; confira `system/health.recovery.runtime_refresh` e a requisição seguinte. Falha de armazenamento retorna diagnóstico degradado sem descartar o diário. A restauração invalida também scripts removidos no OPcache do processo/pool atendido, sem garantir coordenação entre pools independentes. Se o disco estiver cheio e um runtime antigo falhar antes dos plugins normais, primeiro restabeleça espaço/acesso pela hospedagem; o plugin ainda não carregado não consegue corrigir esse estado.

`plugins/rollback` exige backup do pacote e a pós-imagem correspondente. Retorna estado final/sonda; restaura arquivos e ativação, sem prometer reverter migrações de banco ou hooks. Se a recuperação ficar inconclusiva, preserve diário e pré-imagem, impeça alterações concorrentes no alvo e use o backup independente da hospedagem para restaurar um estado consistente.

Voltar somente os arquivos à 0.12.1 não é um rollback completo da 0.13.0: a base antiga não conhece tabelas, revogações, consumo e perfis novos. Uma contingência para a base precisa do snapshot pré-migração e de um plano explícito para credenciais, sem reativar tokens revogados silenciosamente. Não remova a sentinela enquanto houver diário pendente nem execute uninstall para tentar resolver uma atualização.
