# Cobertura SEO implementada

Inventário de laboratório: WordPress 7.1.2, Yoast SEO 28.5, Elementor 4.3.0 e Base Site Core 1.17.0 de entrada. Evidência: `evidencias/third-party-catalog-0130.json`; regressões: `evidencias/third-party-0130.json`. Esses dados não substituem inventário da frota.

| Necessidade | Provedor/contrato |
| --- | --- |
| Pontuações SEO e legibilidade | Habilidades nativas `yoast-seo/*` efetivamente registradas no Yoast 28.5. |
| Ler/alterar metadados SEO por post | `content/get-seo` e `content/update-seo`, usando `WPSEO_Meta` e o construtor de indexable do Yoast. |
| Organização, entidade e configuração do site | `f3base/config-core-ler`, `f3base/config-core-escrever` e contratos próprios do Core. |
| Verificação especializada de schema publicado | `f3base/schema-verificar`. |
| HTTP anônimo genérico e asserções | `system/probe`, incluindo delimitação de cache e procedência dos tempos. |
| Recursos de boas práticas do Elementor | Recursos MCP originais, com URI e MIME lidos de `meta.mcp`. |

O fonte Yoast 28.5 contém métodos para get/update estruturado que não são chamados por `register_abilities()`. Não confundir existência de método com habilidade disponível. O adaptador Fator3 preenche a lacuna registrada sem renomear rotas nativas ou escrever opções privadas diretamente.

Teste realizado: gravação/leitura por API Yoast, reconstrução de indexable e recusa de revisão antiga. HTML público, caches e roundtrip visual no editor continuam verificações separadas. A inspeção de frontend deve usar os campos efetivamente publicados; um título armazenado pode conter um template.
