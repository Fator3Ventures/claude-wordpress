# WP MCP Fator3 — manual de operação 0.13.0

Este manual descreve os contratos implementados no fonte da 0.13.0. A identificação e a homologação do pacote são verificadas no README e no relatório de entrega. Um checkpoint de desenvolvimento não autoriza instalar esse código em produção. Este documento não contém propostas futuras; o escopo de preparação permanece em PREPARACAO-0.13.0.md.

## Conexão e diagnóstico

Copie a URL efetiva em **Ferramentas → MCP Fator3 → Conexão**. Com permalinks, a URL principal é `https://seu-dominio/wp-json/mcp/wp-mcp-fator3`. O alias `https://seu-dominio/wp-json/mcp/wp-mcp-ultimate` continua registrado no mesmo transporte. Instalações por query ou em subdiretórios usam a URL produzida por `rest_url()`, exibida no painel; não monte o endereço manualmente.

Os nomes de protocolo dos três metatools permanecem `wp-mcp-ultimate-discover-abilities`, `wp-mcp-ultimate-get-ability-info` e `wp-mcp-ultimate-execute-ability`. Não é necessário expor todas as habilidades como ferramentas do conector. O perfil pode acrescentar **Execute Readonly Ability**; esse executor aceita somente habilidades de leitura classificadas pelos provedores aderentes.

O transporte integra os modos MCP `2025-11-25` e `2026-07-28`. O modo 2026 usa `server/discover`, identificação de método/nome, `resultType`, `ttlMs` e cache privado para resultados por credencial; não cria sessões nem exige `initialize`. O modo legado mantém a negociação/sessão correspondente. A revisão não suportada retorna `-32022`. Compatibilidade de um cliente real deve ser confirmada no próprio cliente, separadamente dos testes de protocolo.

A tela distingue registro local, autoteste HTTP e requisições autenticadas observadas. “Servidor registrado” comprova o registro das rotas e dos metatools. O autoteste usa senha temporária com perfil Leitura, removida ao terminar; testa a comunicação de retorno do servidor e não comprova travessia da hospedagem por um cliente externo. Uma requisição OAuth observada comprova autenticação efetiva, sem identificar a origem de rede através de proxies. O nome autodeclarado pelo cliente não converte uma chamada em evidência externa.

`system/health.recovery` descreve a varredura da sentinela **na requisição atual**: `status` (`not_run`, `checked`, `degraded` ou `unavailable`), contadores `attempted`, `recovered`, `unresolved` quando disponíveis e `runtime_refresh` (`not_needed`, `current`, `updated_for_next_request` ou `failed`). `checked` não certifica todos os diários nem uma recuperação sob disco cheio. Falha de armazenamento é capturada sem interromper a inicialização; o diário e a pré-imagem ficam para nova tentativa. `checks.recovery_sweep` é `null` sem verificação, `false` em degradação/falha de atualização e `true` quando a varredura terminou sem essas falhas.

Os exemplos de configuração ficam em painéis expansíveis, com cópia explícita. A versão do WordPress aparece no diagnóstico técnico, sem um item redundante de pré-requisito na tela de conexão.

## Autenticação e perfis

OAuth usa consentimento, PKCE S256, códigos de uso único e rotação de refresh token. Reutilizar refresh token consumido revoga a família. Resource, emissor, cliente, usuário e concessão são verificados. A resposta de autorização inclui `iss`. DCR é mantido para compatibilidade, com capacidade de 100 clientes e limite de cinco tentativas por IP direto por hora; um novo cadastro não expulsa um cliente existente. CIMD resolve documentos HTTPS públicos de identidade exata, com limite de tamanho, cache limitado e sem redirecionamentos.

Senhas de aplicação recebem identidade por UUID; concessões OAuth recebem identidade por grant. Uma identidade validada apenas pelo usuário WordPress precisa de mapeamento explícito e compartilha a política desse usuário. O mesmo usuário pode ter várias conexões com perfis diferentes. A política se soma às permissões nativas do WordPress.

| Perfil | Alcance |
| --- | --- |
| Leitura | Habilidades de leitura; exclui canais de arquivos, SQL, usuários, backups e auditoria. |
| Conteúdo | Leitura permitida e edição de conteúdo, mídia, comentários, menus e widgets, respeitando capacidades nativas. |
| Manutenção | Operações administrativas; arquivos exigem raízes explícitas, SQL mutante exige autorização adicional e backups originais exigem permissão de exportação. |
| Personalizado | Lista exata de habilidades, com as mesmas restrições adicionais de alvo e capacidade. |
| Legado | Catálogo congelado durante a transição; é uma exceção temporária, não um perfil recomendado para novas conexões. |

Em **Conectores**, emita a senha para o usuário de serviço adequado, selecione perfil, tipos de conteúdo, raízes e exceções exatas de metadados. Configure e teste o conector antes de revogar a identidade antiga. Exceções Legado manuais exigem justificativa e expiração. Identidades novas sem configuração não recebem administração implícita. A migração automática de identidades antigas tem janela inicial de sete dias; a troca de credenciais é uma operação explícita do administrador.

A verificação fica no `permission_callback` das habilidades próprias e dos provedores que aderem ao contrato Fator3. Assim também vale quando a habilidade é chamada por outra porta MCP. Sem contexto autorizado, uma habilidade própria permanece negada. Habilidades nativas do Elementor e seu servidor padrão são preservados. Não há um interceptador global de provedores desconhecidos.

Executores não podem executar outros executores, inclusive `mcp-adapter/execute-ability`, nem transformá-los em etapas de planos. O erro identificável é `executor_target_forbidden`.

## Descoberta e contratos

Comece por `system/capabilities`, descubra a habilidade e leia seu schema com Get Ability Info. `system/guide` sem parâmetros lista temas deste manual; `topic` lê um tema; `ability` devolve o contrato efetivo visível para a conexão. `CONTRATOS-INSTALADOS.json` é a exportação do registro efetivo incluída no pacote.

`discover-abilities` aceita filtros, paginação e `if_catalog_sha256`. Quando o catálogo visível é o mesmo, retorna `unchanged:true`. O hash é vinculado à conexão/política e aos filtros; não compartilhe cursores ou hashes entre credenciais. Provedor sem versão identificável aparece com motivo explícito, sem inventar uma versão.

`plugins/list` aceita `fields`/`campos` e `prefixes`/`prefixo` para reduzir o inventário. `fields` é lista de nomes do schema; o prefixo pode ser texto ou lista. Aliases equivalentes são aceitos; valores divergentes retornam conflito de parâmetros.

Resultados distinguem `success`, `changed`, `persisted`, `applied`, `conflict`, `retryable`, `operation_id` e `request_id`. `applied:null` significa resultado incerto. `changed:false` pode ser sucesso sem alteração. Não deduza sucesso apenas pelo status HTTP: examine o resultado da habilidade e, em planos, cada etapa.

## Concorrência e repetição

`expected_sha256` compara a pré-imagem do arquivo sob o mesmo bloqueio usado por leitura, comparação, backup e substituição. Escritores cooperantes compartilham o bloqueio por arquivo; cópias/movimentos bloqueiam os alvos envolvidos em ordem estável. Um arquivo modificado desde a leitura retorna `file_conflict`. `expected_revision` protege conteúdo e metadados contra uma revisão antiga.

A espera padrão do lock é de **2 segundos** (`system/capabilities.limits.lock_wait_seconds`). Dois agentes no mesmo site devem tratar `resource_busy` como contenção, aguardar o intervalo informado e reler o estado antes de repetir uma alteração com revisão/hash. Editores e processos externos que não usam esse serviço de bloqueio não recebem garantia de exclusão mútua.

Use a mesma `idempotency_key` para retomar a mesma operação mutante. Parâmetros diferentes com a mesma chave retornam `idempotency_conflict`; a permissão atual é reavaliada antes do replay. Uma operação incerta exige reconciliação. A compactação do resultado conserva a chave/fingerprint e retorna `idempotency_result_expired`, impedindo a repetição silenciosa do efeito.

## Arquivos e transferências

`files/read` suporta leitura integral, linhas (`offset`, `limit`, `tail_lines`, `grep`, `grep_regex`) e leitura por bytes. Em modo de bytes, `cursor:""` começa a sequência; `offset_bytes` inicia em um byte arbitrário e `byte_limit` limita a resposta. Um cursor devolvido é opaco; `"0"` não é um offset válido. Não combine paginação por byte com filtros por linha.

Binários retornam `encoding` e `content_base64`. Para regravar um binário, envie `content_base64`; não converta os bytes em texto. Extensões binárias conhecidas recusam `content` textual. Fornecer simultaneamente texto e base64 é inválido. SVG, JSON, CSS e JavaScript textuais continuam disponíveis. Confira o SHA-256 após uma transferência.

`compression` admite `none`, `gzip` e `auto`. A expansão gzip valida integridade e limites; byte offset não representa acesso aleatório ao conteúdo descompactado. `files/search` aceita arquivo individual ou diretório, filtros e paginação. Use `files/delete` com `empty_dir:true` para remover apenas uma pasta vazia; não há exclusão recursiva implícita.

O limite padrão do canal é 16 MiB. `files/upload-create` recebe destino, `total_bytes`, `sha256` e eventual hash anterior; devolve `transfer_id`. Envie `files/upload-part` em partes de até 256 KiB, com índice a partir de zero e `content_base64`. Repetir o mesmo índice/bytes é seguro; bytes diferentes conflitam. Consulte `files/upload-status`, conclua com `files/upload-finalize` ou cancele com `files/upload-cancel`. Partes expiram em 24 horas; o máximo é quatro uploads ativos por conexão. Finalizar revalida o perfil e passa pelo mesmo serviço de `files/write`.

`files/write`, `files/patch`, `files/delete` e `files/move` aceitam `label`/`rotulo` para os backups. `files/copy` e `files/move` têm hashes separados para origem e destino; confira o schema antes de enviar. Uma escrita PHP recebe verificação de sintaxe e, conservadoramente, sonda de execução em novo processo. `system/toggle-debug` usa esse mesmo serviço e exige opt-in para editar a configuração. Autoalteração do código MCP por rotas genéricas de arquivos é recusada.

O diretório privado `f3-mcp-private` é protegido das rotas genéricas. Consulte `system/health.storage.path` para localizar o acervo e use as habilidades de backups/manutenção. Não tente contornar a restrição com outro caminho ou alias.

## Conteúdo, metadados e blocos

As leituras de post, página e revisão aceitam `fields`, permitindo omitir corpos extensos. Leituras de lista podem omitir totais quando o schema oferece `include_totals`. `content/get-revision` fornece uma revisão específica. Leia o schema efetivo para os campos disponíveis em cada rota.

`content/update-page` usa `parent`; `parent_id` é alias compatível. Enviar os dois com valores divergentes falha. `parent:0` remove o pai. A saída conserva campos compatíveis; a documentação da entrada usa o nome canônico.

`content/patch-page` e `content/patch-post` exigem ocorrência única por padrão. Use `all:true` para substituição múltipla intencional ou `limit` explícito. O limite vale também para regex. `expected_revision` é conferido sob lock. A resposta inclui leitura efetiva, SHA-256, bytes e comprimento de caracteres; divergência de conteúdo aparece como `content_filtered`, sem afirmar que a causa foi localizada. O serviço aplica slashing na fronteira correta das APIs WordPress.

`featured_media` é gravado antes dos hooks de salvamento do post. O resultado usa a revisão final após hooks e leitura de volta; um filtro que altere o valor precisa ser observado, não presumido como sucesso. `content/upsert` usa `external_ref` estável para convergir para um ID, sem recriar silenciosamente conteúdo excluído ou com criação anterior incerta.

`content/get-meta` e `content/update-meta` usam post, chave exata e schema/capacidade registrados. Chaves não registradas exigem exceção explícita do administrador no perfil. Múltiplos valores são preservados: use `meta_id` para selecionar um deles. `content/delete-meta` exige post, chave e `meta_id`, com prévia e confirmação. Uma chave com prefixo conhecido não é automaticamente órfã.

`content/blocks` devolve a árvore e os caminhos dos blocos nomeados. Em `content/edit-block`, `block_path` seleciona o bloco. `inner_html` em bloco com filhos é recusado: use `children` para substituir filhos, inclusive `[]` para remoção intencional. Alterar atributos não reconstrói automaticamente o HTML salvo pelo editor. A prévia e a validação estrutural PHP não comprovam compatibilidade com a função JavaScript `save` de um bloco; confira o editor para blocos estáticos personalizados.

`content/delete-post`/`delete-page` não prometem lixeira para tipos que o WordPress não suporta. A exclusão definitiva exige a intenção explícita e a confirmação correspondente. `content/untrash` e `content/restore-revision` usam APIs nativas e verificam o resultado.

## SEO e mídia

Com Yoast compatível ativo, `content/get-seo` lê valores armazenados; `content/update-seo` altera apenas os campos fornecidos, com revisão, lock, backup e leitura de volta. Os campos abrangem título, descrição, palavra-chave, canonical, indexação, nofollow e metadados sociais. String vazia limpa o campo; `indexing:default` restaura a herança. O adaptador usa `WPSEO_Meta` e o construtor de indexable do Yoast. `indexable_rebuilt` não comprova o HTML servido pelo cache. Ausência/incompatibilidade do provedor é falha explícita.

A configuração institucional e as verificações especializadas do Base Site Core continuam nas habilidades `f3base/*`. O catálogo real do Yoast 28.5 registra pontuações; seus métodos de get/update estruturado existem no código, mas não estão registrados no catálogo. A matriz de cobertura fica em COBERTURA-SEO.md.

`media/regenerate` usa o editor de imagem WordPress e os tamanhos registrados, preserva o original e cria pré-imagem de metadados/arquivos. Verifica derivados e informa o resultado real. `media/set-site-icon` prepara os tamanhos do ícone pelo serviço nativo e atualiza a option correspondente; não requer um mu-plugin descartável. Use `expected_revision` quando partir de uma leitura anterior. A exclusão definitiva de anexo inclui pré-imagem dos arquivos relacionados.

## Plugins e recuperação

`plugins/upload` instala por URL. `plugins/upload-base64` recebe `content_base64` ou `zip_path` autorizado. `activate` e `overwrite` são **false quando omitidos**. Ao substituir um plugin já ativo, o serviço preserva essa intenção de ativação; `activate:false` não é uma operação de desativação.

`expected_sha256` confere o ZIP; `expected_slug` confere a pasta raiz. O pacote precisa ter uma única raiz e entrypoint inequívoco. Staging recusa caminhos inseguros, links, tipos especiais, arquivos duplicados, ZIPs inválidos e expansão acima do orçamento. O ZIP tem limite de 16 MiB e a expansão validada de 128 MiB.

Antes de trocar arquivos, o serviço verifica a home e a REST, registra pré-imagem e diário persistido, prepara uma árvore completa no filesystem de destino e usa rename. `plugins/update` consome a oferta nativa disponível — do wordpress.org ou do canal próprio — e reativa na mesma operação o plugin anteriormente ativo. A ativação ocorre em requisição PHP nova pelo executor independente, permitindo detectar fatal da nova versão. A resposta informa `old_version`/`versao_anterior`, `version`/`versao`, `changed`/`mudou`, `active_before`, `active_after`, `backup_id` e evidências de sonda.

Falha na ativação/sonda tenta restaurar a pré-imagem na mesma chamada. A sentinela MU pode retomar um diário abandonado quando o lease expira e o processo original já não detém o bloqueio. `recovery_required` ou `rollback_conflict` exigem inspeção; o serviço não sobrescreve uma pós-imagem alterada por terceiro. `plugins/rollback` restaura a árvore e o estado de ativação registrados quando a pré-condição ainda corresponde. Reversão de arquivos não desfaz migrações de banco, hooks ou efeitos externos do plugin. Após aplicar ou recuperar um pacote, o serviço solicita invalidação pela API do Base Site Core quando disponível. `cache_invalidation` distingue solicitação, indisponibilidade e falha; isso não é prova de cache público atualizado.

A autoatualização do MCP usa exclusivamente `plugins/update`, com pré-carregamento das classes privadas e executor fora da pasta substituída. Upload genérico e atualizador nativo sem diário recusam essa autoalteração. A sentinela fica em `mu-plugins/000-f3-mcp-recovery.php` e `f3-mcp-recovery-runtime-v1.php`; não a remova com diários pendentes. A recuperação depende de filesystem direto e do mesmo acervo de bloqueios; não há garantia para disco defeituoso, perda de toda a pré-imagem ou alterações externas simultâneas. A troca e a restauração invalidam no OPcache os caminhos das duas árvores, inclusive scripts removidos. Escritas e exclusões PHP invalidam o caminho antes da sonda. Isso não coordena pools PHP independentes da hospedagem. Uma sentinela já instalada é atualizada quando o fonte muda; a classe carregada na requisição atual só muda na próxima requisição.

`plugins/delete` carrega as APIs administrativas necessárias, exige plugin inativo e usa prévia/confirmação. Somente depois de verificar a ausência dos arquivos remove a entrada daquele plugin em `auto_update_plugins`. Falha dessa limpeza retorna `auto_update_cleanup_pending`; retomar a mesma confirmação não repete o uninstall.

`plugins/cleanup-orphaned-uninstall` limpa entradas exatas comprovadamente órfãs no registro protegido de uninstall, em duas fases. Não executa callbacks órfãos nem remove plugins/conteúdo com base no nome.

## Canal próprio de atualização

Os três pacotes têm `Update URI` sob `fator3.com.br`. Isso identifica o canal; não publica um ZIP nem cria automaticamente um feed. Configure a URL HTTPS real do `manifest.json` de cada pacote na aba **Atualizações**. Campo vazio mantém o feed desabilitado. O filtro `update_plugins_fator3.com.br` fornece as ofertas ao mecanismo WordPress.

Cada manifesto schema 1 declara `package`, `plugin`, `version`, `url`, `sha256`, `requires` e `tested`. Requisitos de WordPress/PHP são tipados; dependências entre os três pacotes são versões mínimas verificadas. `tested.evidence` identifica a evidência de homologação. O ZIP deve usar o host do manifesto ou um host explicitamente permitido, por HTTPS, sem redirecionamento. O download é conferido por digest também no painel; o digest depende da integridade do manifesto HTTPS, não é uma assinatura independente.

A instalação do MCP não habilita automaticamente `auto_update_plugins` para MCP/Core/Google. A publicação coordenada usa a ordem Core → Google → MCP e exige versões compatíveis com a base durante a transição. Não reutilize o número de uma versão publicada para bytes diferentes. A configuração concreta dos feeds e a implantação na frota são operações separadas.

## SQL e configurações

`db/query` opera sobre superfície classificada: referências a usuários, usermeta, views, fontes sensíveis e construções não reconhecidas são recusadas. A proteção alcança também predicados, ordenação e contagem; não é apenas uma máscara da projeção. Tabelas de extensões precisam de classificação explícita no servidor. Um perfil capaz de gravar código ou executar SQL administrativo continua tendo poderes administrativos; a proteção de leitura não substitui o isolamento por perfil/credencial.

`db/execute` é administrativo, limitado a instrução única e duas fases. A prévia congela a seleção e emite confirmação com expiração. O executor revalida a seleção em transação InnoDB e usa a conexão mysqli original, sem reconectar uma transação perdida. JOIN/subconsultas suportados estão restritos ao analisador; construções fora do subconjunto são recusadas. Divergência de seleção retorna conflito. Resultado de commit incerto não autoriza repetir cegamente a mutação.

Prévias e resultados SQL redigem valores reconhecidos como segredos, inclusive options. **O backup automático retém os valores originais e o SQL necessário à recuperação**, podendo conter segredos. Ele cobre linhas do alvo, não todo o banco. Base64 não é criptografia. `db/execute` não é permitido em planos.

`db/schema` aceita `exact:true` ou `contar:true`, com paginação. `rows_exact` complementa a estimativa; timeout/limite produz resultado inconclusivo, não contagem inventada. Contagens de tabelas diferentes são instruções independentes.

`options/get` pode ler uma chave de estrutura com `key`. `options/update` verifica leitura de volta e usa APIs WordPress. `options/delete` seleciona nomes exatos em duas fases, respeitando options protegidas. Não use SQL para manipular serialização quando existir habilidade tipada.

Para permalinks, categoria e tag, use as options próprias e `rewrite/flush`, que executa flush leve (`false`) e relata contagem/regras antes e depois. `rewrite_rules` continua protegido contra escrita arbitrária. `menus/delete` usa API WordPress, verifica vínculos e requer reconhecimento explícito quando o menu está em uso.

## Exclusões e planos

Exclusões destrutivas tipadas fazem prévia na primeira chamada e devolvem `confirm_token`. Revise alvos, pré-imagem e efeitos. Confirme reenviando a mesma intenção e o token, que expira em dez minutos e é vinculado à credencial/revisão. Mudança de alvo, conteúdo ou permissão invalida a execução. Exclusão de usuário distingue reassociação e exclusão explícita de conteúdo. Um token não autoriza ampliar a seleção.

`operations/plan` armazena até 50 etapas permitidas sem executá-las. IDs são únicos; referências usam `{"$ref":"etapa.campo"}` e dependência anterior explícita. `operations/preview` registra alvos/pré-condições conhecidos e identifica etapas que dependem de resultado futuro ou não têm simulador. Não interprete prévia como execução bem-sucedida.

`operations/apply` avança em lotes, revalida schema/permissão e reutiliza idempotência por etapa. Retome o mesmo `plan_id`. `operations/list` e `operations/status` informam andamento. `operations/cancel` usa estado independente do lock longo: a etapa corrente pode concluir, as próximas são impedidas. Cancelar não desfaz efeitos anteriores. Compensação é limitada a inversas comprovadas e pode ficar incompleta; um plano não é uma transação global.

Uploads/atualizações/rollback de plugins e leitura/assertiva/sonda são etapas tipadas permitidas. O schema efetivo de `operations/plan` enumera a lista completa. Não há execução de `db/execute`, executor arbitrário ou plano aninhado como etapa.

## Backups, histórico e manutenção

`audit/list` filtra habilidade exata, conexão, usuário, alvo, operação, resultado e período. `before` é alias de `cursor`; `path` é alias de `target`. O histórico armazena metadados, sem payloads de conteúdo, tokens ou prévias SQL. A importação do histórico legado é incremental; `history_complete:false` informa que a listagem ainda está incompleta.

`backups/list` filtra rótulo (`label`/`rotulo`) e datas (`since`/`until`). `backups/export` exporta o envelope restaurável; `backups/export-part` permite partes de até 256 KiB com cursor vinculado à conexão/backup/hash. O perfil precisa permitir exportação e, separadamente, backups de outra conexão ou acervo legado. A autorização é revalidada em cada parte.

`backups/prune` começa em simulação; aceita idade, volume e `include_legacy:false` por padrão. Para apagar, envie `dry_run:false` e `expected_selection_sha256` da seleção revisada. Incluir legado alcança somente formatos reconhecidos; arquivos estranhos, pares incompletos, links e proteções de diretório não são apagados como se fossem backups. Referências de planos/compensações são preservadas, inclusive vínculos criados depois da prévia. Falhas parciais conservam o checkpoint da seleção.

`system/maintenance` simula lotes de até 100 registros por categoria e aplica apenas a seleção confirmada. Auditoria aceita idade e `max_total_bytes`; os defaults de simulação são 90 dias para auditoria e 14 para resultados de idempotência. Códigos, tokens, sessões e partes usam a expiração autoritativa. Clientes novos não autorizados expiram em 24 horas; autorização conserva o registro. Estados incertos/ativos e arquivos de lock ficam fora da limpeza genérica. Não há exclusão automática habilitada pela instalação.

Ocupação em `system/health.maintenance` identifica o escopo medido: payloads de banco e bytes indexados de envelopes. Árvores de recuperação, caches de exportação e arquivos legados podem estar fora desse total; o número não equivale ao uso completo do disco.

## Sondas e desempenho

`system/probe` executa GET/HEAD na origem de `home_url()`, sem cookie ou Authorization. Aceita até cinco caminhos, três amostras e timeout de até dez segundos, sob orçamento total. Cabeçalhos permitidos são Accept, Accept-Language, Cache-Control e Pragma. Não permite Host arbitrário ou credenciais do chamador.

Asserções incluem status, contém/não contém e cabeçalhos. HEAD não aceita asserção de corpo. Cada amostra informa hash, completude do corpo, asserções e tempos com procedência. O marcador PHP novo comprova bypass de cache quando observado; `generation_ms` mede bootstrap/preparação da resposta. `total_ms` não é TTFB. `ttfb_ms:null` indica que o transporte WordPress não forneceu medição separada. Não atribua a latência fria de uma página a uma causa sem medição adicional.

`test_private_storage:true` tenta um marcador descartável quando há mapeamento seguro para URL. `system/health` só marca `http_protection_tested` a partir dessa evidência válida; armazenamento sem URL mapeável permanece inconclusivo, sem falso sucesso.

`system/health.cron` informa `wp_cron_desabilitado`, `eventos_vencidos` e `ultimo_disparo`. O último disparo é o marcador observado do plugin, não prova de execução de todos os jobs. O HTTP 429 da hospedagem precisa ser investigado a partir da requisição externa correspondente; uma sonda interna não resolve essa atribuição.

## Exemplos e referências

Os valores abaixo são exemplos. Substitua IDs, hashes e raízes por leituras do site e confira o schema.

```json
{"ability_name":"files/read","parameters":{"path":"/caminho/autorizado/log.txt","tail_lines":100,"grep":"ERROR"}}
```

```json
{"ability_name":"content/update-page","parameters":{"id":15,"parent":0,"expected_revision":"REVISAO_DA_LEITURA"}}
```

```json
{"ability_name":"system/probe","parameters":{"paths":[{"path":"/","assert":{"status":200}},{"path":"/wp-json/","assert":{"status":200,"contains":"namespaces"}}],"samples":2}}
```

Referências distribuídas: CONTRATOS-INSTALADOS.json (schema efetivo), ATUALIZACAO.md (migração/recuperação), COBERTURA-SEO.md (divisão de responsabilidades) e CONTRATO-EXTENSOES.md (integração Core/Google). O pacote de fontes contém a especificação por ID, testes e evidências com seu escopo de validade.
