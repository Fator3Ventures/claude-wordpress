# WP MCP Fator3 0.13.0 — pacote para homologação

A implementação foi empacotada na versão alvo 0.13.0, com as adaptações coordenadas Core 1.17.1 e Google 0.4.1. Não há versões intermediárias publicadas. **Esta entrega ainda não é uma release estável homologada para produção.**

## Conteúdo e instalação no laboratório

Este ZIP externo reúne a entrega; ele não deve ser enviado diretamente à tela de instalação do WordPress. Extraia-o e use os ZIPs da pasta `instaladores/`, na ordem:

1. `base-site-core-fator3-1.17.1.nao-homologado.zip`.
2. `wp-mcp-google-fator3-0.4.1.nao-homologado.zip`.
3. `wp-mcp-fator3-0.13.0.nao-homologado.zip`.

Os complementos atualizam os pacotes correspondentes já existentes. O ZIP MCP atualiza `wp-mcp-fator3/wp-mcp-fator3.php`; não exclua o plugin para atualizar. O fonte completo e as ferramentas de build/teste estão em `fontes/`. A documentação de operação também acompanha o instalador MCP.

A URL principal continua `/wp-json/mcp/wp-mcp-fator3`, com `/wp-json/mcp/wp-mcp-ultimate` preservada. A migração 0.12.1 → 0.13.0 muda contratos e perfis: a janela Legado automática é de sete dias. Leia `documentacao/ATUALIZACAO.md` e prepare a migração das credenciais antes do aceite operacional. Não basta substituir o ZIP e supor que a migração dos conectores esteja concluída.

## Implementação

Inclui perfis por credencial e revogação; persistência InnoDB; protocolo MCP dual e compatibilidade de URLs; política em habilidades aderentes; correções de arquivos/binários/locks, conteúdo/revisões/slashing, SQL e segredos; upload/update/rollback com recuperação e sonda; recursos Elementor; mídia/ícone; planos/cancelamento; transferências e backups; manutenção e melhorias de interface/documentação. O fonte traz a especificação canônica e o estado dos 83 IDs, distinguindo implementação, teste e aceite externo.

## Verificação e pendências

Os próprios ZIPs foram extraídos em WordPress 7.1.2, PHP 8.3.30 e MySQL 8.0.46 descartáveis: 28 comandos da suíte concluíram sem falha. Foram verificados 584 arquivos PHP e a análise estática nível 2 passou em 72 módulos. Há evidências de migração sintética, atualização dos complementos, autoatualização, rollback por fatal, SIGKILL, concorrência, cancelamento durante escrita, OAuth e integrações Elementor/Yoast. Detalhes e limitações em `documentacao/VALIDACAO.md`.

A continuação corrigiu a interrupção de inicialização por ENOSPC e a execução de scripts removidos ainda em OPcache. Foram aprovadas 5 verificações de falha de armazenamento, 7 de OPcache real em CLI e 22 em Chromium (painel, JSON/cópia, teclado, credencial sintética e roundtrip core/group/core/paragraph). O diagnóstico system/health informa a varredura da recuperação na requisição atual. As tabelas do painel foram ajustadas para telas pequenas.

O HTTP dos ensaios locais usou o servidor PHP. Ainda faltam o gate Apache/OPcache por pool, filesystem montado cheio, blocos e clientes reais da frota e piloto. O ambiente Docker/Apache está fornecido, mas Docker não estava disponível no executor; a proteção do Apache não foi desabilitada para contornar essa limitação. Não trate os testes locais como aceite da frota.

Os manifestos de `manifestos/` são de revisão: `release_approved:false`, URLs de exemplo não publicadas. Não use esses URLs como feed. Nenhum site de produção, credencial de produção ou feed foi alterado/publicado. O build estável exige aprovação do gate dos mesmos bytes.

`SHA256SUMS.txt` confere todos os arquivos internos desta entrega. Os hashes de cada instalador também constam em `manifestos/packages.json` e nas evidências da regressão dentro do pacote fonte.
