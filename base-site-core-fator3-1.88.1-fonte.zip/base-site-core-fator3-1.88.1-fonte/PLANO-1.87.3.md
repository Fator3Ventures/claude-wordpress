# Fator3 Site Core 1.87.3

Base oficial 1.86.0. Rodada de 14/11/2026, pedidos 407–412 em reference/pedidos-407-412.md. As seis alterações afetam condições, leitores, relatórios, formato compacto e filas do Core. O MCP fornece o transporte de descoberta dinâmica. Nenhum pedido exige alteração de código em outro pacote. O novo compacto muda a projeção usada pela frota e a documentação orienta a leitura por rota de detalhe.

- 407 e 408. Corrigir a decisão do histórico e expor regras com revisão, resultado local, options e efeitos da agenda. Exercitar os cinco perfis.
- 409. Centralizar a leitura estruturada e manter o tratamento distinto de campos cifrados e de texto. Testar formas ausentes, já decodificadas e inválidas.
- 410. Medir o custo das linhas no banco antes da materialização e o consumo durante os lotes. Conferir recusa identificada com pouca memória e a leitura normal.
- 411. Gerar o resumo diretamente das contagens, sem montar o estado detalhado. Comparar as duas rotas e medir o JSON no Site-Teste.
- 412. Preservar a recorrência em execução ociosa, urgência separada quando há prazo e operações sob trava. Comparar a agenda antes e depois de passagens repetidas e verificar a migração dos avulsos anteriores.

## Patch 1.87.1

Padrões recebidos após a instalação da 1.87.0 no Site-Teste. Atualizar navegação, selo e paginação. Comprovar a faixa 360/768/1440 px, a identidade dos arquivos, o piso, o contrato, as abilities, as opções operáveis e a confirmação de prontidão. A base direta de frota é 1.86.0 e o Site-Teste segue da 1.87.0. A frota publica os três artefatos no main.

## 1.87.2

Agrupar as conexões e os destinos de Operação, provar suas subabas e o acesso antigo; identificar Medição no menu e o pacote nas telas secundárias. Validar o instalador final nas bases aceitas.

## 1.87.3

Conter a largura das tabelas em Avisos e Qualidade no painel e incluir a prova do navegador nas três larguras.
