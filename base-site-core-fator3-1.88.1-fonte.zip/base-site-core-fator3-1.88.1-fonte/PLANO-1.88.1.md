# Fator3 Site Core 1.88.1

O pedido 413 e sua revisão de preços seguem o plano da 1.88.0, preservado neste fonte. A 1.88.0 já tinha sido instalada no laboratório. O ensaio do exportador com uma sessão real encontrou uma colisão entre a rede efetiva do navegador e a classificação de rede do servidor. A correção exige patch e um novo instalador.

A 1.88.1 publica o sinal do navegador como `rede_efetiva` no relatório de sessões e no CSV. O objeto `rede` conserva o contrato anterior. O parâmetro de filtro `rede` continua selecionando o sinal do navegador. O ensaio de regressão usa sessões sintéticas gravadas no WordPress e o exportador administrativo.

A prova de saída cobre instalação limpa, migração direta da 1.87.3, preservação dos contatos de teste, coexistência com os cinco pacotes vigentes e leitura pelo MCP no Site-Teste. O relatório distingue a composição integral do aviso no WordPress da entrega a um canal do Slack.
