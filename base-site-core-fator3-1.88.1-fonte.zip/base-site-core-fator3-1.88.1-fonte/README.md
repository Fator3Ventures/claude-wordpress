# Fonte do Fator3 Site Core 1.88.1

A base de migração está em `history/1.87.3-runtime`. O pedido, o catálogo e as referências dos preços ficam em `reference/413/`. A retomada do candidato e a correção do CSV constam em `PLANO-1.88.1.md`. Os comprovantes desta entrega ficam em `evidence/1880/`, incluindo o estado final do Site-Teste e as capturas do painel.

## Reprodução do instalador

Na raiz do fonte, use Python 3 e PHP 8.3 ou superior. O primeiro comando recompila o índice de aparelhos. O segundo confere a integridade do runtime e a sintaxe de todos os arquivos PHP.

```sh
python3 build/gerar-catalogo-aparelhos.py
python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.88.1-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.88.1-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.88.1-fonte.zip
```

## Ensaios em WordPress descartável

`tests/pedidos-413.php` cria contatos, eventos e sessões sintéticos, compõe as mensagens, verifica consentimento, filtros e leituras e remove os registros. `tests/conferir-csv-413.py` lê a saída do exportador real. Execute com WP-CLI autenticado como administrador no laboratório local de instalação limpa ou atualização indicado nos guardas dos ensaios.

```sh
wp --user=1 eval-file tests/pedidos-413.php
F3_QA_CSV=1 wp --user=1 eval-file tests/pedidos-413.php > /tmp/f3base-sessoes-413.csv
python3 tests/conferir-csv-413.py /tmp/f3base-sessoes-413.csv
F3_QA_CATALOGO="$PWD/reference/413/catalogo-aparelhos.csv" wp --user=1 eval-file tests/catalogo-precos-413.php
```

`tests/regressoes-1880.php` restaura as opções e agendas temporárias do ensaio. Com todos os acompanhantes, crie um administrador sintético exclusivo na instalação local e use o mesmo usuário nas três chamadas seguintes. A associação de leitura expira após uma hora e a última chamada a revoga. Use apenas o banco descartável `core1881upgrade` para esse ensaio. Os nomes de scripts históricos identificam a rodada que os originou.

```sh
F3_QA_PERFIL=associate wp --user="$usuario_qa" eval-file tests/perfil-leitura-413.php
wp --user="$usuario_qa" eval-file tests/regressoes-1880.php
F3_QA_PERFIL=revoke wp --user="$usuario_qa" eval-file tests/perfil-leitura-413.php
```
