<?php
/** Coleta adicional limitada, sem conteúdo digitado, com consentimento e idempotência. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Analise {
    private static array $recursos = array();
    public const ESQUEMA_VERSAO=16400;
    const TABELA='f3base_analise';
    const HISTORICO='f3base_atendimento_historico';
    public static function tabela(): string { global $wpdb;return $wpdb->prefix.self::TABELA; }
    public static function iniciar(): void {
        add_action('rest_api_init',static function(){register_rest_route(F3BASE_REST_NAMESPACE,'/analise',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array(__CLASS__,'receber_seguro')));});
        add_action('wp_enqueue_scripts',array(__CLASS__,'enfileirar'),30);
        add_filter('render_block',array(__CLASS__,'inspecionar_recursos'),30);
        add_filter('the_content',array(__CLASS__,'inspecionar_recursos'),30);
        add_action(F3Base_Leads_Notificacoes::EVENTO,array(__CLASS__,'reter'));
    }
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();$t=self::tabela();$h=$wpdb->prefix.self::HISTORICO;
        dbDelta("CREATE TABLE {$t} (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 evento char(32) NOT NULL,
 visitante char(32) NOT NULL,
 sessao char(32) NOT NULL,
 classe_trafego varchar(16) NOT NULL DEFAULT 'nao_marcado',
 navegacao char(32) NOT NULL,
 navegacao_anterior char(32) NOT NULL DEFAULT '',
 automacao varchar(20) NOT NULL DEFAULT 'nao_identificada',
 automacao_motivos varchar(190) NOT NULL DEFAULT '',
 automacao_regra varchar(40) NOT NULL DEFAULT '',
 automacao_evidencia text NULL,
 post_id bigint unsigned NOT NULL DEFAULT 0,
 tipo_conteudo varchar(32) NOT NULL DEFAULT '',
 representacao varchar(20) NOT NULL DEFAULT 'html',
 aquisicao_regra varchar(40) NOT NULL DEFAULT '',
 aquisicao_evidencia varchar(64) NOT NULL DEFAULT '',
 aquisicao_conflitos varchar(190) NOT NULL DEFAULT '',
 canal varchar(32) NOT NULL DEFAULT 'direto_desconhecido',
 origem_ia varchar(24) NOT NULL DEFAULT '',
 entrada varchar(190) NOT NULL DEFAULT '',
 inicio_sessao bigint unsigned NOT NULL DEFAULT 0,
 tipo varchar(20) NOT NULL,
 caminho varchar(190) NOT NULL,
 formulario varchar(80) NOT NULL DEFAULT '',
 formulario_revisao varchar(64) NOT NULL DEFAULT '',
 correlacao varchar(64) NOT NULL DEFAULT '',
 dispositivo varchar(16) NOT NULL,
 largura_faixa varchar(12) NOT NULL DEFAULT '',
 navegador varchar(16) NOT NULL DEFAULT '',
 sistema varchar(12) NOT NULL DEFAULT '',
 retorno varchar(10) NOT NULL DEFAULT '',
 aparelho varchar(16) NOT NULL DEFAULT '',
 criado_em bigint unsigned NOT NULL,
 recebido_em bigint unsigned NOT NULL,
 qualidade varchar(16) NOT NULL,
 oferta_id varchar(80) NOT NULL DEFAULT '',
 oferta_tipo varchar(16) NOT NULL DEFAULT '',
 oferta_instancia char(32) NOT NULL DEFAULT '',
 detalhe varchar(64) NOT NULL DEFAULT '',
 ultimo_campo varchar(80) NOT NULL DEFAULT '',
 etapa tinyint unsigned NOT NULL DEFAULT 0,
 campos_preenchidos smallint unsigned NOT NULL DEFAULT 0,
 clique_rotulo varchar(160) NOT NULL DEFAULT '',
 clique_destino varchar(190) NOT NULL DEFAULT '',
 valor double NOT NULL DEFAULT 0,
 sequencia int unsigned NOT NULL DEFAULT 1,
 decisao_ref char(64) NOT NULL DEFAULT '',
 publicidade tinyint NOT NULL DEFAULT 0,
 atribuicao text NOT NULL,
 payload_hash char(64) NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY evento (evento),
 KEY periodo (criado_em,tipo),
 KEY trafego_periodo (classe_trafego,criado_em,tipo),
 KEY sessao (sessao,criado_em),
 KEY navegacao (navegacao,tipo),
 KEY conteudo_periodo (post_id,criado_em),
 KEY inicio_sessao (inicio_sessao,sessao),
 KEY tipo_periodo (tipo_conteudo,criado_em),
 KEY visitante (visitante),
 KEY visitante_tempo (visitante,classe_trafego,criado_em,evento),
 KEY correlacao (correlacao)
) {$cc};");
        if($wpdb->last_error){return false;}
        dbDelta("CREATE TABLE {$h} (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 record_id char(32) NOT NULL,
 revisao bigint unsigned NOT NULL,
 anterior varchar(20) NOT NULL,
 atual varchar(20) NOT NULL,
 em bigint unsigned NOT NULL,
 operador bigint unsigned NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY alteracao (record_id,revisao),
 KEY periodo (em)
) {$cc};");
        return !$wpdb->last_error && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($h)))===$h;
    }
    public static function caminho(string $url): string {return F3Base_Editorial::caminho($url);}
    /** Leitura e escrita de atribuição pelo contrato comum. */
    /** Cookies auxiliares podem surgir entre dois flushes; a origem continua imutável. */
    public static function origem_imutavel($json): string {
        $v=is_string($json)?json_decode($json,true):$json;
        $limpar=static function($a) use (&$limpar){if(!is_array($a)){return $a;}unset($a['fbc'],$a['fbp']);foreach($a as $k=>$x){$a[$k]=$limpar($x);}ksort($a);return $a;};
        return wp_json_encode($limpar(self::atribuicao(is_array($v)?$v:array())));
    }
    public static function atribuicao($v): array { return F3Base_Atribuicao::normalizar($v); }
    public static function enfileirar(): void {
        if(F3Base_Audiencia::pagina_excluida() || !F3Base_Modulo_Comportamento::ligado() || !wp_script_is('f3base-tracking','enqueued')){return;}
        $suffix=defined('SCRIPT_DEBUG')&&SCRIPT_DEBUG?'.js':'.min.js';
        $base='assets/f3base-analise'.$suffix;
        wp_enqueue_script('f3base-analise',F3BASE_PLUGIN_URL.$base,array('f3base-tracking'),F3Base_Ativos_Publicos::versao($base),array('in_footer'=>true,'strategy'=>'defer'));
        $recursos=array();
        foreach(array('formularios'=>'f3base-formulario-analise','ofertas'=>'f3base-ofertas') as $nome=>$handle){
            $arquivo='assets/'.($nome==='ofertas'?'f3base-ofertas-modulo':$handle).$suffix;$versao=F3Base_Ativos_Publicos::versao($arquivo);
            wp_register_script($handle,F3BASE_PLUGIN_URL.$arquivo,array('f3base-analise'),$versao,array('in_footer'=>true,'strategy'=>'defer'));
            $recursos[$nome]=array('handle'=>$handle,'src'=>add_query_arg('ver',$versao,F3BASE_PLUGIN_URL.$arquivo));
        }
        wp_localize_script('f3base-analise','f3baseAnaliseDados',array('endpoint'=>rest_url(F3BASE_REST_NAMESPACE.'/analise'),'token'=>F3Base_Modulo_Endpoint_Leads::emitir_token(),'rotaToken'=>rest_url(F3BASE_REST_NAMESPACE.'/comportamento/token'),'caminho'=>self::caminho((string)get_permalink(get_queried_object_id()))?:self::caminho(wp_unslash($_SERVER['REQUEST_URI']??'/')),'recursos'=>$recursos));
        self::selecionar_recursos();
    }
    /** Presence follows rendered HTML; definitions saved elsewhere do not force downloads. */
    public static function declarar_recurso(string $nome): void {
        $handles=array('formularios'=>'f3base-formulario-analise','ofertas'=>'f3base-ofertas');
        if(!isset($handles[$nome])||!empty(self::$recursos[$nome])){return;}self::$recursos[$nome]=true;
        self::selecionar_recursos();
    }
    private static function selecionar_recursos(): void {
        if(!wp_script_is('f3base-analise','enqueued')||wp_script_is('f3base-analise','done')){return;}
        $mask=(!empty(self::$recursos['formularios'])?1:0)|(!empty(self::$recursos['ofertas'])?2:0);
        $arquivo='assets/perfis/analise-'.$mask.'.min.js';
        if(!(defined('SCRIPT_DEBUG')&&SCRIPT_DEBUG)&&isset(F3Base_Ativos_Publicos::build()['arquivos'][$arquivo])){
            $script=wp_scripts()->registered['f3base-analise'];$script->src=F3BASE_PLUGIN_URL.$arquivo;$script->ver=F3Base_Ativos_Publicos::versao($arquivo);
        }else{
            foreach(array('formularios'=>'f3base-formulario-analise','ofertas'=>'f3base-ofertas') as $nome=>$handle){if(!empty(self::$recursos[$nome])&&wp_script_is($handle,'registered')){wp_enqueue_script($handle);}}
        }
    }
    public static function inspecionar_recursos(string $html): string {
        if(empty(self::$recursos['formularios'])&&str_contains($html,'data-f3base-formulario')&&preg_match('/<form\b[^>]*\bdata-f3base-formulario\s*=/i',$html)){self::declarar_recurso('formularios');}
        if(empty(self::$recursos['ofertas'])&&str_contains($html,'data-f3base-oferta')&&preg_match('/<[a-z][^>]*\sdata-f3base-oferta(?:\s|=|>)/i',$html)){self::declarar_recurso('ofertas');}
        return $html;
    }
    private static function resposta(int $status,array $d): WP_REST_Response {
        $r=new WP_REST_Response($d,$status);$r->header('Cache-Control','no-store, private');
        if(in_array($status,array(429,503),true)){$r->header('Retry-After','15');}return $r;
    }
    /** Diagnóstico limitado, sem SQL, corpo, endereço de rede ou informação pessoal. */
    public static function diagnosticar(string $codigo,string $classe,int $confirmados,string $operacao='',?string $automacao=null,string $renovacao=''): void {
        $automacao=$automacao??F3Base_Audiencia::automacao()['automacao'];$bot=in_array($automacao,array('declarada','provavel'),true);$day=wp_date('Y-m-d');
        F3Base_Options::atualizar_estado('f3base_analise_saude',static function($v) use($codigo,$classe,$confirmados,$operacao,$automacao,$bot,$day,$renovacao){
            $v=is_array($v)?$v:array();if(($v['schema']??0)<2&&isset($v['contagens'])){$v['contagens_legadas_sem_separacao']=$v['contagens'];$v['contagens']=array();}$key=$classe.':'.$codigo;$bucket=$bot?'contagens_automacao':'contagens';$v[$bucket][$key]=(int)($v[$bucket][$key]??0)+1;
            $v['dias'][$day][$bucket][$key]=(int)($v['dias'][$day][$bucket][$key]??0)+1;
            $v['ultima']=array('codigo'=>$codigo,'classe_trafego'=>$classe,'automacao'=>$automacao,'confirmados'=>$confirmados,'operacao'=>$operacao,'em'=>time(),'versao'=>F3BASE_PLUGIN_VERSAO);
            if($classe!=='teste'&&!$bot){$v['ultima_operacional']=$v['ultima'];}
            if($bot){$v['ultima_automacao']=$v['ultima'];}
            $v['renovacoes_consumidas']=array_filter($v['renovacoes_consumidas']??array(),static fn($at)=>$at>=time()-900);
            if($renovacao!==''&&!isset($v['renovacoes_consumidas'][$renovacao])&&count($v['renovacoes_consumidas'])<512){
                $v['renovacoes_consumidas'][$renovacao]=time();$k=$classe.':renovacao_aceita';$v[$bucket][$k]=(int)($v[$bucket][$k]??0)+1;$v['dias'][$day][$bucket][$k]=(int)($v['dias'][$day][$bucket][$k]??0)+1;
            }
            ksort($v['dias']);$v['dias']=array_slice($v['dias'],-30,null,true);$v['schema']=2;return $v;
        });
    }
    /** Receipt contains no token or visitor data. Bound to the rejected event and agent, expires in 15 min. */
    private static function prova_renovacao(array $eventos,string $prefix): string {
        $id=is_string($eventos[0]['evento']??null)?$eventos[0]['evento']:'';
        return hash_hmac('sha256',$prefix.'|'.$id.'|'.hash('sha256',(string)($_SERVER['HTTP_USER_AGENT']??'')),wp_salt('auth'));
    }
    private static function renovacao_valida(array $e): string {
        $proof=$e['renovacao']??'';if(!is_string($proof)||!preg_match('/^([0-9]{10}\.[a-f0-9]{16})\.([a-f0-9]{64})$/D',$proof,$m)){return '';}
        $at=(int)substr($m[1],0,10);return $at<=time()&&$at>=time()-900&&hash_equals(self::prova_renovacao($e['eventos'],$m[1]),$m[2])?hash('sha256',$proof):'';
    }
    /** INSERT disputa a chave única; só uma linha comprovada pode confirmar duplicata. */
    public static function persistir(array $row,?array $contexto=null): array {
        if(($row['tipo']??'')==='clique_interno'&&!self::cliques_prontos()){return array('ok'=>false,'codigo'=>'estrutura_cliques_pendente','status'=>503,'operacao'=>'estrutura');}

        $link=$row['_link'] ?? null; unset($row['_link']);
        $perfil=$row['_perfil_aparelho']??[];unset($row['_perfil_aparelho']);
        global $wpdb;$t=self::tabela();$prev=$wpdb->suppress_errors(true);
        try {
            $old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE evento=%s',$t,$row['evento']),ARRAY_A);
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>'leitura','status'=>503);}
            if(!$old){
                if(!F3Base_Leads_Repositorio::quota('analise-sessao|'.$row['sessao'],1000,time()+DAY_IN_SECONDS)){return F3Base_Leads_Repositorio::quota_erro()?array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>'quota','status'=>503):array('ok'=>false,'codigo'=>'limite_sessao','status'=>429);}
                if($wpdb->query('START TRANSACTION')===false){return array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>'transacao','status'=>503);}
                try{
                    if(false!==$wpdb->insert($t,$row)){
                        if(($link && !F3Base_Clique_Link::gravar($row,$link)) || ($perfil&&!F3Base_Perfil_Aparelho::gravar($row['classe_trafego'],$row['sessao'],$row['visitante'],(int)$row['criado_em'],$perfil))||!F3Base_Sessoes::registrar_evento($row,$contexto)||$wpdb->query('COMMIT')===false){$wpdb->query('ROLLBACK');return array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>'contexto_sessao','status'=>503);}
                        F3Base_Editorial::marcar_dia((int)$row['criado_em']);return array('ok'=>true);
                    }
                    $erro=$wpdb->last_error;$wpdb->query('ROLLBACK');
                }catch(Throwable $x){$wpdb->query('ROLLBACK');return array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>'contexto_sessao','status'=>503);}
                $old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE evento=%s',$t,$row['evento']),ARRAY_A);
                if(!$old||$wpdb->last_error){return array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>stripos($erro,'deadlock')!==false?'deadlock':(stripos($erro,'lock wait')!==false?'lock_timeout':'insercao'),'status'=>503);}
            }
            if(hash_equals($old['payload_hash'],$row['payload_hash'])){return array('ok'=>true,'duplicado'=>true);}
            if ($row['tipo']==='clique_link') { return ['ok'=>false,'codigo'=>'evento_conflitante','status'=>409]; }
            $same=true;foreach(array('sessao','visitante','navegacao','tipo','caminho','detalhe','classe_trafego','formulario','formulario_revisao','correlacao','dispositivo','atribuicao','oferta_id','oferta_tipo','oferta_instancia') as $k){$same=$same&&($k==='atribuicao'?self::origem_imutavel($old[$k])===self::origem_imutavel($row[$k]):(string)$old[$k]===(string)$row[$k]);}
            if($same&&(float)$old['valor']===(float)$row['valor']&&(int)$old['sequencia']===(int)$row['sequencia']&&(int)$old['criado_em']===(int)$row['criado_em']){return array('ok'=>true,'duplicado'=>true);}
            if($row['tipo']==='vital'&&$same){
                if((int)$old['sequencia']>$row['sequencia']){return array('ok'=>true,'superado'=>true);}
                if((int)$old['sequencia']===$row['sequencia']){return array('ok'=>false,'codigo'=>'evento_conflitante','status'=>409);}
                $ok=$wpdb->query($wpdb->prepare('UPDATE %i SET valor=%f,sequencia=%d,payload_hash=%s,recebido_em=%d WHERE evento=%s AND sequencia<%d',$t,$row['valor'],$row['sequencia'],$row['payload_hash'],time(),$row['evento'],$row['sequencia']));
                if(false===$ok){return array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>'atualizacao_vital','status'=>503);}
                $saved=$wpdb->get_row($wpdb->prepare('SELECT sequencia,payload_hash FROM %i WHERE evento=%s',$t,$row['evento']),ARRAY_A);
                if(!$saved||$wpdb->last_error){return array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>'confirmacao_vital','status'=>503);}
                if((int)$saved['sequencia']>$row['sequencia']||hash_equals($saved['payload_hash'],$row['payload_hash'])){return array('ok'=>true);}
            }
            return array('ok'=>false,'codigo'=>'evento_conflitante','status'=>409);
        } finally { $wpdb->suppress_errors($prev); }
    }
    public static function cliques_prontos(): bool {if(!F3Base_Esquema::manutencao()){return F3Base_Esquema::pronta(__CLASS__);}global $wpdb;$cols=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i WHERE Field IN (%s,%s)',self::tabela(),'clique_rotulo','clique_destino'));return !$wpdb->last_error&&count($cols??array())===2;}
    public static function receber_seguro(WP_REST_Request $req): WP_REST_Response {
        $ativo=true;
        register_shutdown_function(static function()use(&$ativo){if(!$ativo){return;}$err=error_get_last();if($err&&in_array($err['type'],array(E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR),true)){@error_log('F3BASE analise codigo=fatal_php motivo=execucao_interrompida arquivo='.basename($err['file']).' linha='.(int)$err['line']);}});
        try{return self::receber($req);}catch(Throwable $x){$details=F3Base_Operacao::excecao($x,'endpoint_analise');@error_log('F3BASE analise '.wp_json_encode($details));self::diagnosticar('erro_interno_analise','nao_identificada',0,'excecao_servidor');F3Base_Options::atualizar_estado('f3base_analise_saude',static function($v)use($details){$v['ultima_falha_500']=$details+array('em'=>time());return $v;});return self::resposta(500,array('ok'=>false,'codigo'=>'erro_interno_analise','motivo'=>'Falha interna ao processar a coleta; consulte o diagnóstico do pacote.','confirmados'=>array()));}finally{$ativo=false;}
    }
    public static function receber(WP_REST_Request $req): WP_REST_Response {
        if(F3Base_Audiencia::editor()){return self::resposta(403,array('ok'=>false,'codigo'=>'medicao_nao_permitida','confirmados'=>array()));}
        $request=bin2hex(random_bytes(8));$confirmed=array();
        if(strlen($req->get_body())>32768){return self::resposta(413,array('ok'=>false,'codigo'=>'corpo_grande','confirmados'=>array()));}
        $e=$req->get_json_params();
        if(!is_array($e)||array_diff(array_keys($e),array('token','medicao','eventos','renovacao'))||!is_string($e['token']??null)||!is_array($e['eventos']??null)||!array_is_list($e['eventos'])||count($e['eventos'])>20||!$e['eventos']){return self::resposta(400,array('ok'=>false,'codigo'=>'entrada_invalida','confirmados'=>array()));}
        $auto=F3Base_Audiencia::automacao(is_array($e['eventos'][0]['sinais']??null)?$e['eventos'][0]['sinais']:array())['automacao'];
        if(!F3Base_Modulo_Endpoint_Leads::validar_token($e['token'])){$marca=F3Base_Testes::resolver(is_array($e['eventos'][0])?$e['eventos'][0]:array(),$req);self::diagnosticar('token_invalido',$marca['classe_trafego']??'nao_marcado',0,'token',$auto);$prefix=time().'.'.bin2hex(random_bytes(8));return self::resposta(403,array('ok'=>false,'codigo'=>'token_invalido','confirmados'=>array(),'renovacao'=>$prefix.'.'.self::prova_renovacao($e['eventos'],$prefix)));}
        if(($e['medicao']??null)!==true||!F3Base_Modulo_Consentimento::permite_categoria('medicao')||!F3Base_Modulo_Comportamento::ligado()){return self::resposta(403,array('ok'=>false,'codigo'=>'medicao_nao_permitida','confirmados'=>array()));}
        $origin=$req->get_header('origin');if($origin&&strtolower((string)wp_parse_url($origin,PHP_URL_HOST))!==strtolower((string)wp_parse_url(home_url(),PHP_URL_HOST))){return self::resposta(403,array('ok'=>false,'codigo'=>'origem_invalida','confirmados'=>array()));}
        $rows=array();foreach($e['eventos'] as $v){
            if(!is_array($v)){return self::resposta(400,array('ok'=>false,'codigo'=>'evento_invalido','confirmados'=>array()));}
            $marca=F3Base_Testes::resolver($v,$req);if(empty($marca['ok'])){return self::resposta(400,$marca+array('confirmados'=>array()));}
            $v['contexto_teste']=$marca['contexto_teste'];$r=self::validar($v);
            if(isset($r['erro'])){return self::resposta(400,array('ok'=>false,'codigo'=>$r['erro'],'evento'=>$v['evento']??'','confirmados'=>array()));}if(F3Base_Audiencia::caminho_tecnico($r['caminho'])){return self::resposta(403,array('ok'=>false,'codigo'=>'medicao_nao_permitida','confirmados'=>array()));}$rows[]=$r;
        }
        if(count(array_unique(array_column($rows,'classe_trafego')))>1){return self::resposta(400,array('ok'=>false,'codigo'=>'lote_misto','confirmados'=>array()));}
        $auto=in_array('declarada',array_column($rows,'automacao'),true)?'declarada':(in_array('provavel',array_column($rows,'automacao'),true)?'provavel':$auto);$classe=$rows[0]['classe_trafego'];$origem=F3Base_Modulo_Endpoint_Leads::origem();$key='analise|'.hash_hmac('sha256',wp_json_encode($origem),wp_salt('auth')).'|'.floor(time()/600);
        if(!F3Base_Leads_Repositorio::quota($key,300,time()+600)){if(F3Base_Leads_Repositorio::quota_erro()){self::diagnosticar('persistencia_falhou',$classe,0,'quota',$auto);return self::resposta(503,array('ok'=>false,'codigo'=>'persistencia_falhou','confirmados'=>array(),'request_id'=>$request));}return self::resposta(429,array('ok'=>false,'codigo'=>'limite_origem','confirmados'=>array()));}
        $contexto=F3Base_Sessao_Contexto::capturar($req);
        foreach($rows as $row){
            $r=self::persistir($row,$contexto);
            if(empty($r['ok'])){self::diagnosticar($r['codigo'],$classe,count($confirmed),$r['operacao']??'',$auto);return self::resposta($r['status'],array('ok'=>false,'codigo'=>$r['codigo'],'evento'=>$row['evento'],'confirmados'=>$confirmed,'salvos'=>count($confirmed),'parcial'=>(bool)$confirmed,'request_id'=>$request,'classe_trafego'=>$classe));}
            $confirmed[]=array('evento'=>$row['evento'],'sequencia'=>$row['sequencia']);
        }
        self::diagnosticar('confirmado',$classe,count($confirmed),'',$auto,self::renovacao_valida($e));
        return self::resposta(200,array('ok'=>true,'persisted'=>true,'confirmados'=>$confirmed,'salvos'=>count($confirmed),'request_id'=>$request,'classe_trafego'=>$classe));
    }
    /** Public, signed technical schema: cached revisions remain verifiable without storing values. */
    public static function prova_formulario(array $form): string {
        $fields=array();foreach($form['campos'] as $field){if(($field['tipo']??'')!=='static'){$fields[$field['nome']]=(int)($field['etapa']??1);}}
        $raw=wp_json_encode(array('v'=>1,'f'=>$form['id'],'r'=>F3Base_Formularios::revisao($form),'c'=>$fields));
        $body=rtrim(strtr(base64_encode($raw),'+/','-_'),'=');return $body.'.'.hash_hmac('sha256',$body.'|'.home_url('/').'|'.get_current_blog_id(),wp_salt('auth'));
    }
    private static function definicao_abandono(array $v): ?array {
        if(isset($v['formulario_prova'])){
            $proof=$v['formulario_prova'];if(!is_string($proof)||strlen($proof)>16384||!preg_match('/^([A-Za-z0-9_-]+)\.([a-f0-9]{64})$/D',$proof,$parts)){return null;}
            $mac=hash_hmac('sha256',$parts[1].'|'.home_url('/').'|'.get_current_blog_id(),wp_salt('auth'));if(!hash_equals($mac,$parts[2])){return null;}
            $raw=base64_decode(strtr($parts[1],'-_','+/'),true);$schema=is_string($raw)?json_decode($raw,true):null;
            if(!is_array($schema)||($schema['v']??null)!==1||($schema['f']??null)!==$v['formulario']||($schema['r']??null)!==($v['formulario_revisao']??'')||!is_array($schema['c']??null)||count($schema['c'])>100){return null;}
            foreach($schema['c'] as $name=>$stage){if(!is_string($name)||!preg_match('/^[a-z][a-z0-9_-]{0,79}$/D',$name)||!in_array($stage,array(1,2),true)){return null;}}
            return $schema['c'];
        }
        $form=F3Base_Formularios::obter($v['formulario']);if(!$form||!hash_equals(F3Base_Formularios::revisao($form),(string)($v['formulario_revisao']??''))){return null;}
        $fields=array();foreach($form['campos'] as $field){if(($field['tipo']??'')!=='static'){$fields[$field['nome']]=(int)($field['etapa']??1);}}return $fields;
    }
    public static function validar($v): array {
        $campos=array('evento','visitante','sessao','navegacao','tipo','caminho','formulario','formulario_revisao','correlacao','dispositivo','criado_em','detalhe','valor','sequencia','atribuicao','contexto_teste','sinais','navegacao_anterior','oferta','largura','max_touch_points','retorno','clique_rotulo','clique_destino','ultimo_campo','etapa','campos_preenchidos','formulario_prova','perfil_aparelho','link');
        if(!is_array($v)||array_diff(array_keys($v),$campos)){return array('erro'=>'campo_desconhecido');}
        foreach(array('evento','visitante','sessao','navegacao') as $n){if(!F3Base_Leads_Contexto::sessao($v[$n]??null)){return array('erro'=>'identificador_invalido');}}
        if(!in_array($v['tipo']??'',array('pagina','aparelho','form_vista','form_inicio','form_tentativa','form_erro','form_aceito','form_fechado','form_dialogo','form_complemento','form_pulada','form_conversa','vital','oferta_exibida','oferta_aberta','oferta_fechada','clique_interno','clique_link'),true)||!in_array($v['dispositivo']??'',array('movel','desktop'),true)||!is_string($v['caminho']??null)||!self::caminho($v['caminho'])){return array('erro'=>'contexto_invalido');}
        if(isset($v['largura'])&&(!is_int($v['largura'])||$v['largura']<0||$v['largura']>20000)){return array('erro'=>'contexto_invalido');}
        if(isset($v['retorno'])&&!in_array($v['retorno'],array_merge(array(''),F3Base_Audiencia::RETORNOS),true)){return array('erro'=>'contexto_invalido');}
        if(isset($v['max_touch_points'])&&(!is_int($v['max_touch_points'])||$v['max_touch_points']<0||$v['max_touch_points']>20)){return array('erro'=>'contexto_invalido');}
        if($v['tipo']==='pagina'&&!in_array($v['detalhe']??'',array('','ancora'),true)){return array('erro'=>'detalhe_invalido');}
        foreach(array('formulario'=>80,'formulario_revisao'=>64,'correlacao'=>64,'detalhe'=>64) as $k=>$max){if(isset($v[$k])&&(!is_string($v[$k])||strlen($v[$k])>$max||($v[$k]!==''&&!preg_match('/^[A-Za-z0-9_.:-]+$/D',$v[$k])))){return array('erro'=>'detalhe_invalido');}}
        if(str_starts_with($v['tipo'],'form_')){if(empty($v['formulario'])||empty($v['correlacao'])||(!F3Base_Formularios::obter($v['formulario'])&&($v['tipo']!=='form_fechado'||!isset($v['formulario_prova'])))){return array('erro'=>'formulario_invalido');}}
        if(array_intersect(array_keys($v),array('ultimo_campo','etapa','campos_preenchidos','formulario_prova'))){
            if($v['tipo']!=='form_fechado'||!is_string($v['ultimo_campo']??null)||!in_array($v['etapa']??null,array(1,2),true)||!is_int($v['campos_preenchidos']??null)||$v['campos_preenchidos']<0||$v['campos_preenchidos']>100){return array('erro'=>'abandono_invalido');}
            $fields=self::definicao_abandono($v);if($fields===null){return array('erro'=>'revisao_formulario_nao_comprovada');}if($v['ultimo_campo']!==''&&!array_key_exists($v['ultimo_campo'],$fields)){return array('erro'=>'campo_formulario_invalido');}if($v['campos_preenchidos']>count($fields)||($v['etapa']===2&&!in_array(2,$fields,true))){return array('erro'=>'abandono_invalido');}
        }
        $o=isset($v['oferta'])?F3Base_Ofertas_Medicao::validar($v['oferta']):null;if((isset($v['oferta'])&&!$o)||(in_array($v['tipo'],F3Base_Ofertas_Medicao::EVENTOS,true)&&(!$o||!F3Base_Formularios::obter($v['formulario']??'')))){return array('erro'=>'oferta_invalida');}
        if(($v['tipo']==='oferta_aberta'&&!in_array($v['detalhe']??'',array('rolagem','saida','tempo','clique'),true))||($v['tipo']==='oferta_fechada'&&!in_array($v['detalhe']??'',array('botao','esc','fora','navegacao'),true))||($v['tipo']==='oferta_exibida'&&($v['detalhe']??'')!=='')){return array('erro'=>'oferta_evento_invalido');}
        $link=null;
        if ($v['tipo']==='clique_link') {
            $link=F3Base_Clique_Link::normalizar($v['link'] ?? null);
            if (!$link) { return ['erro'=>'link_invalido']; }
            $v['link']=$link;
        } elseif (isset($v['link'])) { return ['erro'=>'clique_fora_do_evento']; }
        if($v['tipo']==='clique_interno'){
            if(!is_string($v['clique_rotulo']??null)||mb_strlen($v['clique_rotulo'])>160||!is_string($v['clique_destino']??null)||strlen($v['clique_destino'])>190||!self::caminho($v['clique_destino'])||str_starts_with($v['clique_destino'],'//')||preg_match('~[?#]|/f3base/(?:arquivo|download)~i',$v['clique_destino'])){return array('erro'=>'clique_invalido');}
        }elseif(isset($v['clique_rotulo'])||isset($v['clique_destino'])){return array('erro'=>'clique_fora_do_evento');}
        $valor=$v['valor']??0;$seq=$v['sequencia']??1;
        if(!is_numeric($valor)||!is_finite((float)$valor)||(float)$valor<0||(float)$valor>3600000||!is_int($seq)||$seq<1||$seq>60){return array('erro'=>'valor_invalido');}
        if($v['tipo']==='vital'&&!in_array($v['detalhe']??'',array('LCP','CLS','INP','TTFB'),true)){return array('erro'=>'vital_invalido');}
        if(!F3Base_Audiencia::sinais_validos($v['sinais']??array())||(!empty($v['navegacao_anterior'])&&!F3Base_Leads_Contexto::sessao($v['navegacao_anterior']))){return array('erro'=>'sinais_invalidos');}
        $a=$v['atribuicao']??array();if(!F3Base_Atribuicao::validar($a)){return array('erro'=>'atribuicao_invalida');}
        $a=F3Base_Atribuicao::para_captura($a,true,F3Base_Modulo_Consentimento::permite_categoria('publicidade'));
        $stamp=$v['criado_em']??null;if(!is_int($stamp)){return array('erro'=>'horario_invalido');}
        $valid=$stamp>=time()-F3Base_Modulo_Comportamento::retencao_eventos_dias()*DAY_IN_SECONDS&&$stamp<=time()+300;
        $row=array_merge(array('formulario'=>'','formulario_revisao'=>'','correlacao'=>'','detalhe'=>''),array_intersect_key($v,array_flip(array('evento','visitante','sessao','navegacao','tipo','formulario','formulario_revisao','correlacao','dispositivo','detalhe'))));
        if ($link) { $row['_link']=$link; }
        if($v['tipo']==='clique_interno'){$row['clique_rotulo']=sanitize_text_field($v['clique_rotulo']);$row['clique_destino']=self::caminho($v['clique_destino']);}
        if($v['tipo']==='form_fechado'){$row+=array_intersect_key($v,array_flip(array('ultimo_campo','etapa','campos_preenchidos')));}
        $row+=array('oferta_id'=>$o['id']??'','oferta_tipo'=>$o['tipo']??'','oferta_instancia'=>$o['instancia']??'');
        $hints=array_filter(array('mobile'=>$_SERVER['HTTP_SEC_CH_UA_MOBILE']??null,'max_touch_points'=>$v['max_touch_points']??null),static fn($x)=>$x!==null);
        $ref=F3Base_Modulo_Consentimento::referencia_confirmada();$row+=array('decisao_ref'=>$ref['decisao_ref']??$ref['ref']??'','publicidade'=>F3Base_Modulo_Consentimento::permite_categoria('publicidade')?1:0);
        $row+=array('sistema'=>F3Base_Audiencia::sistema(null,$hints),'retorno'=>$v['retorno']??'','aparelho'=>F3Base_Contato_Apresentacao::aparelho((string)($_SERVER['HTTP_USER_AGENT']??''),$hints)['tipo'],'largura_faixa'=>F3Base_Audiencia::faixa_largura((int)($v['largura']??0)),'navegador'=>F3Base_Audiencia::navegador(),'classe_trafego'=>!empty($v['contexto_teste'])?'teste':'nao_marcado','caminho'=>self::caminho($v['caminho']),'criado_em'=>$valid?$stamp:time(),'recebido_em'=>time(),'qualidade'=>$valid?'cliente':'servidor','valor'=>(float)$valor,'sequencia'=>$seq,'atribuicao'=>wp_json_encode(self::atribuicao($a)),'payload_hash'=>hash('sha256',wp_json_encode(F3Base_Auditoria::ordenar($v))));
        if (isset($v['perfil_aparelho'])) {
            $perfil=F3Base_Perfil_Aparelho::sinais($v['perfil_aparelho']);
            if ($v['tipo']!=='aparelho'||!$perfil) {return ['erro'=>'perfil_aparelho_invalido'];}
            $row['_perfil_aparelho']=$perfil;
        }
        $orig=self::atribuicao($a)['sessao_origem']??self::atribuicao($a);$canal=F3Base_Audiencia::canal($orig);$conteudo=F3Base_Editorial::resolver($row['caminho'],$row['criado_em']);
        $row['automacao_evidencia']=wp_json_encode(F3Base_Automacao_Provavel::evidencia());
        $row+=F3Base_Audiencia::automacao($v['sinais']??array())+array('navegacao_anterior'=>$v['navegacao_anterior']??'','post_id'=>$conteudo['post_id'],'tipo_conteudo'=>$conteudo['tipo'],'representacao'=>$conteudo['representacao'],'canal'=>$canal['canal'],'aquisicao_regra'=>$canal['regra'],'aquisicao_evidencia'=>$canal['evidencia'],'aquisicao_conflitos'=>$canal['conflitos'],'origem_ia'=>$canal['origem_ia'],'entrada'=>$orig['entrada']??'','inicio_sessao'=>(($orig['inicio_conhecido']??'')==='1'&&(int)($orig['inicio_em']??0)>0&&(int)$orig['inicio_em']<=$row['criado_em']+300)?(int)$orig['inicio_em']:0);return $row;
    }
    public static function reter(): void {if(!F3Base_Editorial::antes_retencao()){return;}global $wpdb;$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE criado_em<%d',self::tabela(),F3Base_Editorial::corte_retencao()));}
    public static function esquecer(string $visitante): void {F3Base_Sessoes::esquecer($visitante);global $wpdb;$wpdb->delete(self::tabela(),array('visitante'=>$visitante));}
    public static function eliminar_lead(array $lead): bool {global $wpdb;if(false===$wpdb->delete($wpdb->prefix.self::HISTORICO,array('record_id'=>$lead['record_id']))){return false;}return empty($lead['sessao']) || false!==$wpdb->delete(self::tabela(),array('sessao'=>$lead['sessao']));}
}
