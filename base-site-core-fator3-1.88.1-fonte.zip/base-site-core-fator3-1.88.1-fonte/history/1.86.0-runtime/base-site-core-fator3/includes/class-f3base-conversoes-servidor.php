<?php
/** Accepted-record conversion journal. Provider HTTP is allowed only in the worker. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
require_once __DIR__.'/class-f3base-ga4-sessao.php';
final class F3Base_Conversoes_Servidor {
    public const ESQUEMA_VERSAO=16400;
    public const CONTRATO='site-conversion-delivery/1.0.0';
    public const HOOK='f3base_conversoes_servidor';
    /** Only symbolic codes, never provider response text or credentials. */
    public static function codigo($value,string $fallback): string {
        return is_string($value)&&preg_match('/^[a-z][a-z0-9_]{0,79}$/D',$value)?$value:$fallback;
    }
    public static function referencia(array $lead,string $target): string {
        $ref=$lead['dados']['conversoes_transporte']['referencias'][$target]??'';
        return is_string($ref)&&strlen($ref)<=191?$ref:'';
    }
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_conversoes_servidor';}
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta('CREATE TABLE '.self::tabela()." (
 record_id char(32) NOT NULL,
 destino varchar(16) NOT NULL,
 estado varchar(24) NOT NULL,
 codigo varchar(80) NOT NULL DEFAULT '',
 http smallint unsigned NOT NULL DEFAULT 0,
 telefone_estado varchar(20) NOT NULL DEFAULT 'nao_observado',
 destino_ref varchar(191) NOT NULL DEFAULT '',
 ocorrido_em bigint unsigned NOT NULL,
 atualizado_em bigint unsigned NOT NULL,
 proxima bigint unsigned NOT NULL,
 tentativas int unsigned NOT NULL DEFAULT 0,
 PRIMARY KEY  (record_id,destino),
 KEY agenda (estado,proxima)
) ENGINE=InnoDB ".$wpdb->get_charset_collate().';');return !$wpdb->last_error;
    }
    public static function iniciar(): void {
        add_action('f3base_lead_persistido',array(__CLASS__,'capturar'));
        add_action(self::HOOK,array(__CLASS__,'processar'));
        add_action('f3base_zelador',array(__CLASS__,'conferir_agenda_1'),98);
        add_action('f3base_lead_eliminando',static function($id){global $wpdb;$wpdb->update(self::tabela(),array('estado'=>'cancelado','codigo'=>'registro_eliminado'),array('record_id'=>$id));});
        add_action('wp_abilities_api_init',static function(){
            $id=array('type'=>'string','pattern'=>'^[a-f0-9]{32}$');
            F3Base_Servicos::ability('linkedin-conversao-previa','Prévia privada de conversão LinkedIn de um registro, inclusive de teste; não enfileira nem envia',array(F3Base_Linkedin_Conversoes::class,'previa'),array('record_id'=>$id),array('record_id'));
            F3Base_Servicos::ability('conversoes-entregas-ler','Estado privado de conversões por registro; não consulta fornecedores',array(__CLASS__,'ler'),array('record_id'=>$id),array('record_id'));
            F3Base_Servicos::ability('conversoes-recuperar','Simular ou agendar conversões perdidas sem repetir entregas ou resultados incertos',array(__CLASS__,'recuperar'),array('record_id'=>$id,'confirmar'=>array('type'=>'boolean','default'=>false),'vincular_destinos'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array('ga4'=>array('type'=>'string','minLength'=>1,'maxLength'=>191),'google_ads'=>array('type'=>'string','minLength'=>1,'maxLength'=>191),'linkedin'=>array('type'=>'string','minLength'=>1,'maxLength'=>191))),'nao_entregues_confirmados'=>array('type'=>'array','uniqueItems'=>true,'items'=>array('type'=>'string','enum'=>array('ga4','google_ads','linkedin','meta')))),array('record_id'),false);
        });
    }
    public static function capturar(array $lead,?string $somente=null): void {
        if(class_exists('F3Base_Caminho_Lead')&&F3Base_Caminho_Lead::pertence($lead['record_id'])){return;}
        if(($lead['captura']??'')!=='aceito'||!in_array($lead['metodo']??'',array('formulario','whatsapp_formulario'),true)){return;}
        if(!F3Base_Telefone::converter($lead)){return;}
        global $wpdb;$time=strtotime($lead['criado_em'].' UTC');
        foreach(array('ga4','google_ads','linkedin','meta') as $target){$code=F3Base_Contato_Identidade::bloqueio($lead,$target);if($code!==''){$wpdb->query($wpdb->prepare('INSERT IGNORE INTO %i (record_id,destino,estado,codigo,destino_ref,ocorrido_em,atualizado_em,proxima,telefone_estado) VALUES (%s,%s,%s,%s,%s,%d,%d,%d,%s)',self::tabela(),$lead['record_id'],$target,'cancelado',$code,'',$time,time(),0,F3Base_Telefone::marca($lead)));}}
        foreach($somente?array($somente):array('ga4','google_ads','linkedin') as $target){if(!self::servidor($lead,$target)){continue;}$wpdb->query($wpdb->prepare('INSERT IGNORE INTO %i (record_id,destino,estado,codigo,destino_ref,ocorrido_em,atualizado_em,proxima,telefone_estado) VALUES (%s,%s,%s,%s,%s,%d,%d,%d,%s)',self::tabela(),$lead['record_id'],$target,self::referencia($lead,$target)!==''?'pendente':'bloqueado',self::referencia($lead,$target)!==''?'':'destino_historico_ausente',self::referencia($lead,$target),$time,time(),time(),F3Base_Telefone::marca($lead)));}
        // Scheduling does not call an external service.
        if($somente===null&&!empty($lead['dados']['consentimento_snapshot']['publicidade'])){F3Base_Modulo_Meta_Capi::agendar_registro($lead['record_id'],true);}
        F3Base_Fila::agendar(self::HOOK,time()+30);
    }
    /** Provider owns credentials and APIs. Capabilities must perform only local reads. */
    public static function adaptador(string $target,string $contract=self::CONTRATO): ?object {
        $a=apply_filters('f3base_conversoes_adaptador',null,$target,$contract,array('consumer_id'=>'site-core-conversions'));
        return is_object($a)&&is_callable(array($a,'capabilities'))&&is_callable(array($a,'send'))?$a:null;
    }
    private static function servidor(array $lead,string $target): bool {
        if(in_array(F3Base_Conversoes_Transporte::registro($lead)[$target]??'',array('servidor','ambos'),true)){return true;}
        $v=$lead['dados']['conversoes_transporte']['vinculos_administrativos'][$target]??array();
        return ($v['recuperacao_servidor']??false)===true&&($v['nao_entrega_confirmada']??false)===true&&($v['usuario']??0)>0&&($v['em']??0)>0&&self::referencia($lead,$target)!=='';
    }
    public static function motivo(string $code): string {
        return array('elegivel'=>'Elegível para agendamento pelo servidor no destino confirmado.','transporte_nao_servidor'=>'O transporte original não era servidor. Confirme a não entrega e vincule o destino atual pronto.','exige_confirmacao_nao_entrega'=>'Confirme que a conversão não foi entregue neste destino.','destino_historico_ausente'=>'O registro não tem destino vinculado. Informe a referência atual e confirme a não entrega.','destino_nao_pronto'=>'O fornecedor ainda não declara o destino pronto para receber.','destino_alterado'=>'A referência informada difere do destino atual. Consulte o estado do fornecedor.','vinculo_nao_persistido'=>'O banco não confirmou a vinculação administrativa. Nenhum envio foi agendado.','entregue'=>'Este destino já confirmou a entrega. Um novo envio foi recusado.','incerto'=>'Um envio já pode ter ocorrido. Aguarde a reconciliação, sem reenviar.','cancelado'=>'A entrega foi cancelada e não pode ser reativada por esta recuperação.','esgotado'=>'O limite de tentativas foi atingido.','recuperacao_ja_agendada'=>'A recuperação deste destino já foi agendada. Não foi criado outro envio.','registro_inelegivel'=>'O contato precisa estar aceito, fora da lixeira e sem eliminação pendente.','trafego_suprimido'=>'O registro está marcado como teste ou tráfego não elegível.','audiencia_excluida'=>'Esta audiência está excluída da medição.','consentimento_nao_permite'=>'Falta consentimento no aceite ou a autorização foi revogada.','prazo_expirado'=>'O contato está fora do prazo aceito pelo destino.','identidade_ga4_ausente'=>'Faltam os identificadores da visita no Google Analytics.','identificador_clique_ausente'=>'Não há identificador de clique de anúncio válido.','identificador_clique_ambiguo'=>'Há mais de um identificador de clique; a origem não é unívoca.','clique_expirado'=>'O clique ocorreu há mais de 90 dias.','instante_clique_invalido'=>'A data do clique está ausente, no futuro ou depois do contato.')[ $code ]??('A recuperação foi recusada: '.str_replace('_',' ',$code).'.');
    }
    public static function preparar(array $lead,string $target,?array $cap=null): array {
        if(class_exists('F3Base_Caminho_Lead')&&F3Base_Caminho_Lead::pertence($lead['record_id'])){return array('ok'=>false,'codigo'=>'caminho_teste_sem_envio');}
        $fail=static fn($c)=>array('ok'=>false,'codigo'=>$c);
        if(!F3Base_Telefone::converter($lead)){return $fail('contato_sem_identificador_suprimido');}
        if(!self::servidor($lead,$target)){return $fail('transporte_nao_servidor');}
        if($lead['captura']!=='aceito'||!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])||!in_array($lead['metodo'],array('formulario','whatsapp_formulario'),true)){return $fail('registro_inelegivel');}
        if(($lead['classe_trafego']??'')!=='nao_marcado'||($target==='linkedin'&&(($lead['atendimento']??'')==='spam'||!empty($lead['dados']['homologacao'])))){return $fail('trafego_suprimido');}
        if(!empty($lead['dados']['audiencia_excluida'])){return $fail('audiencia_excluida');}
        $duplicate=F3Base_Contato_Identidade::bloqueio($lead,$target);if($duplicate!==''){return $fail($duplicate);}
        $cons=F3Base_Contato_Apresentacao::consentimento_atual($lead['dados']);$snapshot=$lead['dados']['consentimento_snapshot']??array();if(empty($snapshot[$target==='ga4'?'medicao':'publicidade'])){return $fail('consentimento_nao_permite');}$time=strtotime($lead['criado_em'].' UTC');$age=time()-$time;
        if(!$cons[$target==='ga4'?'medicao':'publicidade']){return $fail('consentimento_nao_permite');}
        if($age<0||$age>($target==='ga4'?72*HOUR_IN_SECONDS:90*DAY_IN_SECONDS)){return $fail('prazo_expirado');}
        if($target==='linkedin'){return F3Base_Linkedin_Conversoes::montar($lead);}
        $p=array('record_id'=>$lead['record_id'],'event_id'=>$lead['record_id'],'occurred_at'=>gmdate('Y-m-d\TH:i:sP',$time));
        if($target==='ga4'){$g=$lead['dados']['ga4']??array();if(!preg_match('/^[0-9]{1,20}\.[0-9]{1,20}$/D',(string)($g['client_id']??''))||!preg_match('/^[1-9][0-9]{0,19}$/D',(string)($g['session_id']??''))){return $fail('identidade_ga4_ausente');}$temporal=F3Base_Ga4_Sessao::validar($g,$time);if($temporal!==''){return $fail($temporal);}$p+=array('measurement_id'=>$g['measurement_id']??'','client_id'=>$g['client_id'],'session_id'=>$g['session_id'],'timestamp_micros'=>$time*1000000,'event_name'=>'generate_lead');}
        else{if($cap===null){try{$cap=F3Base_Google_Conversoes::selecionar()['cap'];}catch(Throwable $x){$cap=array();}}$google=F3Base_Google_Conversoes::montar($lead,$cap);if(empty($google['ok'])){return $google;}$p+=$google['payload'];}
        return array('ok'=>true,'payload'=>$p);
    }
    public static function processar(): array {
        global $wpdb;$lock=F3Base_Trava::adquirir('conversoes-servidor',120);if(!$lock){return array('ok'=>false,'codigo'=>'ocupado');}$done=0;
        try{
            self::reconciliar_bloqueada();
            $missing=$wpdb->get_col($wpdb->prepare("SELECT l.record_id FROM %i l WHERE l.captura='aceito' AND l.lixeira=0 AND l.eliminacao_pendente=0 AND (JSON_EXTRACT(l.dados,'$.conversoes_servidor_versao')=1 OR JSON_UNQUOTE(JSON_EXTRACT(l.dados,'$.conversoes_transporte.destinos.ga4'))='servidor' OR JSON_UNQUOTE(JSON_EXTRACT(l.dados,'$.conversoes_transporte.destinos.google_ads'))='servidor') AND l.criado_em>=%s AND (SELECT COUNT(*) FROM %i q WHERE q.record_id=l.record_id AND q.destino IN ('ga4','google_ads'))<IF(JSON_EXTRACT(l.dados,'$.conversoes_servidor_versao')=1,2,IF(JSON_UNQUOTE(JSON_EXTRACT(l.dados,'$.conversoes_transporte.destinos.ga4'))='servidor',1,0)+IF(JSON_UNQUOTE(JSON_EXTRACT(l.dados,'$.conversoes_transporte.destinos.google_ads'))='servidor',1,0)) ORDER BY l.id LIMIT 50",F3Base_Leads_Repositorio::tabela(),gmdate('Y-m-d H:i:s',time()-90*DAY_IN_SECONDS),self::tabela()));
            $li=$wpdb->get_col($wpdb->prepare("SELECT l.record_id FROM %i l LEFT JOIN %i q ON q.record_id=l.record_id AND q.destino='linkedin' WHERE q.record_id IS NULL AND l.captura='aceito' AND l.lixeira=0 AND l.eliminacao_pendente=0 AND JSON_UNQUOTE(JSON_EXTRACT(l.dados,'$.conversoes_transporte.destinos.linkedin'))='ambos' AND l.criado_em>=%s ORDER BY l.id LIMIT 50",F3Base_Leads_Repositorio::tabela(),self::tabela(),gmdate('Y-m-d H:i:s',time()-90*DAY_IN_SECONDS)));$missing=array_unique(array_merge($missing?:array(),$li?:array()));
            foreach($missing as $id){$lead=F3Base_Leads_Repositorio::obter($id);if($lead){self::capturar($lead);}}
            $rows=self::selecionar(10);
            foreach($rows as $row){if(F3Base_Execucoes::deadline()-microtime(true)<20){break;}$where=array('record_id'=>$row['record_id'],'destino'=>$row['destino'],'estado'=>$row['estado']);$lead=F3Base_Leads_Repositorio::obter($row['record_id']);$adapter=null;$cap=array();try{if($row['destino']==='google_ads'){$selected=F3Base_Google_Conversoes::selecionar();$adapter=$selected['adapter'];$cap=$selected['cap'];}else{$adapter=self::adaptador($row['destino']);$cap=$adapter?$adapter->capabilities():array();}}catch(Throwable $x){$cap=array();}$cap=is_array($cap)?$cap:array();$prep=$lead?self::preparar($lead,$row['destino'],$cap):array('ok'=>false,'codigo'=>'registro_ausente');
                if((int)$row['tentativas']>=10){$wpdb->update(self::tabela(),array('estado'=>'esgotado','codigo'=>'limite_tentativas','atualizado_em'=>time()),$where);continue;}if(empty($prep['ok'])){$terminal=in_array($prep['codigo'],array('transporte_nao_servidor','prazo_expirado','clique_expirado','registro_ausente','registro_inelegivel','trafego_suprimido','audiencia_excluida','consentimento_nao_permite','ga4_sessao_expirada','caminho_teste_sem_envio'),true);$wpdb->update(self::tabela(),array('estado'=>$terminal?'cancelado':'bloqueado','codigo'=>$prep['codigo'],'proxima'=>time()+HOUR_IN_SECONDS,'atualizado_em'=>time()),$where);continue;}
                if(!in_array($cap['contract']??'',array_merge(array(self::CONTRATO),$row['destino']==='google_ads'?array(F3Base_Google_Conversoes::CONTRACT):array()),true)||empty($cap['ready'])||!is_string($cap['destination_ref']??null)||$cap['destination_ref']===''||strlen($cap['destination_ref'])>191){$wpdb->update(self::tabela(),array('estado'=>'bloqueado','codigo'=>self::codigo($cap['reason']??null,'adaptador_indisponivel'),'proxima'=>time()+HOUR_IN_SECONDS,'atualizado_em'=>time()),$where);continue;}
                if($row['destino']==='linkedin'&&((string)($cap['conversion_id']??'')!==F3Base_Linkedin_Conversoes::regra($lead)||(string)F3Base_Options::ler('f3base_linkedin_server_conversion_id')!==F3Base_Linkedin_Conversoes::regra($lead))){$wpdb->update(self::tabela(),array('estado'=>'bloqueado','codigo'=>'regra_linkedin_divergente','proxima'=>time()+HOUR_IN_SECONDS,'atualizado_em'=>time()),$where);continue;}
                if($row['destino_ref']===''){$wpdb->update(self::tabela(),array('estado'=>'bloqueado','codigo'=>'destino_historico_ausente','proxima'=>time()+HOUR_IN_SECONDS,'atualizado_em'=>time()),$where);continue;}
                if(!is_callable(array($adapter,'sendBound'))){$wpdb->update(self::tabela(),array('estado'=>'bloqueado','codigo'=>'destination_binding_unsupported','proxima'=>time()+HOUR_IN_SECONDS,'atualizado_em'=>time()),$where);continue;}
                if($row['destino_ref']!==''&&!hash_equals($row['destino_ref'],$cap['destination_ref'])){$wpdb->update(self::tabela(),array('estado'=>'bloqueado','codigo'=>'destino_alterado','proxima'=>time()+HOUR_IN_SECONDS,'atualizado_em'=>time()),$where);continue;}
                // Persist uncertain BEFORE HTTP. A crash cannot make this row eligible again.
                if($wpdb->update(self::tabela(),array('estado'=>'incerto','codigo'=>'envio_iniciado','destino_ref'=>$cap['destination_ref'],'tentativas'=>(int)$row['tentativas']+1,'atualizado_em'=>time()),$where)!==1){continue;}
                try{$result=$adapter->sendBound($prep['payload'],$row['destino_ref']);}catch(Throwable $e){$result=array('status'=>'incerto');}
                $status=is_array($result)?($result['status']??'incerto'):'incerto';if(!is_array($result)){$result=array();}if(!in_array($status,array('entregue','recusado'),true)){$status='incerto';}
                if($status==='recusado'&&empty($result['non_delivery_proven'])){$status='incerto';}
                $wpdb->update(self::tabela(),array('estado'=>$status,'codigo'=>self::codigo($result['code']??null,$status),'http'=>is_int($result['http']??null)&&$result['http']>=100&&$result['http']<=599?$result['http']:0,'proxima'=>time()+max(300,min(DAY_IN_SECONDS,(int)($result['retry_after']??3600))),'atualizado_em'=>time()),array('record_id'=>$row['record_id'],'destino'=>$row['destino'],'estado'=>'incerto'));++$done;
            }return array('ok'=>true,'processados'=>$done);
        }finally{F3Base_Trava::liberar($lock);}
    }
    /**
     * Linhas vencidas da passagem, com prioridade para o que pode sair agora (1.49.0).
     *
     * Antes, `pendente`, `recusado` e `bloqueado` disputavam as mesmas dez vagas por
     * `proxima`: uma fila de bloqueios de configuração (ex.: regra LinkedIn ausente
     * em 90 dias de contatos) ocupava todas as vagas a cada hora e atrasava por horas
     * a conversão nova de outro destino. Bloqueados continuam reavaliados, nas vagas
     * que sobram. Duas leituras pelo índice `agenda (estado,proxima)`.
     *
     * @return list<array<string,mixed>>
     */
    public static function selecionar(int $limite): array {
        global $wpdb;$limite=max(1,min(50,$limite));$agora=time();
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado IN ('pendente','recusado') AND proxima<=%d ORDER BY proxima LIMIT %d",self::tabela(),$agora,$limite),ARRAY_A)?:array();
        if(count($rows)<$limite){$rows=array_merge($rows,$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado='bloqueado' AND proxima<=%d ORDER BY proxima LIMIT %d",self::tabela(),$agora,$limite-count($rows)),ARRAY_A)?:array());}
        return $rows;
    }
    /** Optional provider reconciliation: read-only, no retry of an uncertain ingestion. Caller owns the queue lock. */
    public static function reconciliar(): void {
        $lock=F3Base_Trava::adquirir('conversoes-servidor',120);if(!$lock){return;}try{self::reconciliar_bloqueada();}finally{F3Base_Trava::liberar($lock);}
    }
    private static function reconciliar_bloqueada(): void {
        global $wpdb;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado='incerto' AND proxima<=%d ORDER BY proxima LIMIT 10",self::tabela(),time()),ARRAY_A);
        foreach ($rows as $row) {
            if(F3Base_Execucoes::deadline()-microtime(true)<15) break;
            $lead=F3Base_Leads_Repositorio::obter($row['record_id']);
            if (!$lead||!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])) continue;
            try {
                $adapter=self::adaptador($row['destino']);$cap=$adapter?$adapter->capabilities():array();
                if (($cap['contract']??'')!==self::CONTRATO||($cap['async_reconciliation']??'')!=='site-conversion-reconcile/1.0.0'||!is_callable(array($adapter,'reconcileBound'))) continue;
                if ($row['destino_ref']===''||!hash_equals($row['destino_ref'],(string)($cap['destination_ref']??''))) continue;
                $result=$adapter->reconcileBound($row['record_id'],$row['destino_ref']);
            } catch(Throwable $e) {$result=array('status'=>'incerto');}
            if(!is_array($result)) $result=array();
            $status=$result['status']??'incerto';
            if(!in_array($status,array('entregue','recusado'),true)||($status==='recusado'&&empty($result['non_delivery_proven']))) $status='incerto';
            $wpdb->update(self::tabela(),array('estado'=>$status,'codigo'=>self::codigo($result['code']??null,$status),
                'proxima'=>time()+max(1800,min(DAY_IN_SECONDS,(int)($result['retry_after']??1800))),'atualizado_em'=>time()),
                array('record_id'=>$row['record_id'],'destino'=>$row['destino'],'estado'=>'incerto','destino_ref'=>$row['destino_ref']));
        }
    }
    public static function ler(array $e): array {if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}global $wpdb;return array('ok'=>true,'contract'=>self::CONTRATO,'entregas'=>$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s',self::tabela(),$e['record_id']),ARRAY_A),'transporte'=>F3Base_Conversoes_Transporte::registro(F3Base_Leads_Repositorio::obter($e['record_id'])??array()),'limite'=>'GA4 entregue comprova recepção HTTP, não processamento analítico. Ads segue confirmação individual do adaptador. Homologação analítica é externa.');}
    public static function recuperar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $lock=F3Base_Trava::adquirir('conversoes-servidor',120);if(!$lock){return array('ok'=>false,'codigo'=>'ocupado');}
        try{return self::recuperar_interno($e);}finally{F3Base_Trava::liberar($lock);}
    }
    private static function vincular(array $lead,string $target,string $ref): bool {
        global $wpdb;$raw=$wpdb->get_var($wpdb->prepare('SELECT dados FROM %i WHERE record_id=%s',F3Base_Leads_Repositorio::tabela(),$lead['record_id']));
        $data=json_decode((string)$raw,true);if(!is_array($data)||$data!==$lead['dados']){return false;}
        $data['conversoes_transporte']['referencias'][$target]=$ref;
        $data['conversoes_transporte']['vinculos_administrativos'][$target]=array('usuario'=>get_current_user_id(),'em'=>time(),'nao_entrega_confirmada'=>true,'recuperacao_servidor'=>true,'transporte_original'=>F3Base_Conversoes_Transporte::registro($lead)[$target]??'ausente','destino_ref'=>$ref);
        $wpdb->query('START TRANSACTION');
        $saved=$wpdb->query($wpdb->prepare('UPDATE %i SET dados=%s WHERE record_id=%s AND dados=%s',F3Base_Leads_Repositorio::tabela(),wp_json_encode($data),$lead['record_id'],$raw));
        if($saved!==1){$wpdb->query('ROLLBACK');return false;}
        self::capturar(array_replace($lead,array('dados'=>$data)),$target);
        $updated=$wpdb->query($wpdb->prepare("UPDATE %i SET destino_ref=%s,codigo='destino_vinculado' WHERE record_id=%s AND destino=%s AND destino_ref='' AND estado IN ('pendente','bloqueado','recusado')",self::tabela(),$ref,$lead['record_id'],$target));
        if($updated===false){$wpdb->query('ROLLBACK');return false;}$row=$wpdb->get_row($wpdb->prepare('SELECT estado,destino_ref FROM %i WHERE record_id=%s AND destino=%s',self::tabela(),$lead['record_id'],$target),ARRAY_A);if(!$row||$row['destino_ref']!==$ref||!in_array($row['estado'],array('pendente','bloqueado','recusado'),true)){$wpdb->query('ROLLBACK');return false;}return $wpdb->query('COMMIT')!==false;
    }
    private static function recuperar_interno(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$lead=F3Base_Leads_Repositorio::obter($e['record_id']);if(!$lead){return array('ok'=>false,'codigo'=>'registro_ausente');}$rows=array_column(self::ler($e)['entregas'],null,'destino');$out=array();
        foreach(array('ga4','google_ads','linkedin') as $target){
            $state=$rows[$target]['estado']??'';$ref=$rows[$target]['destino_ref']??self::referencia($lead,$target);
            $binding=$e['vincular_destinos'][$target]??null;$confirmed=in_array($target,$e['nao_entregues_confirmados']??array(),true);
            $server=self::servidor($lead,$target);$needsBinding=!$server||$ref==='';$p=self::preparar($lead,$target);
            if(in_array($state,array('entregue','incerto','cancelado','esgotado'),true)){$p=array('ok'=>false,'codigo'=>$state);}
            elseif(!empty($lead['dados']['conversoes_transporte']['vinculos_administrativos'][$target]['recuperacao_servidor'])&&$state!==''){$p=array('ok'=>false,'codigo'=>'recuperacao_ja_agendada');}
            elseif($needsBinding){
                if(!$confirmed){$p=array('ok'=>false,'codigo'=>'exige_confirmacao_nao_entrega');}
                elseif(!is_string($binding)||$binding===''){$p=array('ok'=>false,'codigo'=>'destino_historico_ausente');}
                else{
                    $cap=F3Base_Conversoes_Transporte::capacidade($target);if($target==='linkedin'&&F3Base_Linkedin_Conversoes::regra($lead)!==(string)F3Base_Options::ler('f3base_linkedin_server_conversion_id')){$cap['ready']=false;}
                    if(empty($cap['ready'])){$p=array('ok'=>false,'codigo'=>'destino_nao_pronto');}
                    elseif(!hash_equals((string)$cap['destination_ref'],$binding)||($ref!==''&&!hash_equals($ref,$binding))){$p=array('ok'=>false,'codigo'=>'destino_alterado');}
                    else{
                        $candidate=$lead;$candidate['dados']['conversoes_transporte']['referencias'][$target]=$binding;
                        $candidate['dados']['conversoes_transporte']['vinculos_administrativos'][$target]=array('usuario'=>get_current_user_id(),'em'=>time(),'nao_entrega_confirmada'=>true,'recuperacao_servidor'=>true);
                        $p=self::preparar($candidate,$target);
                        if(!empty($p['ok'])&&!empty($e['confirmar'])){
                            if(!self::vincular($lead,$target,$binding)){$p=array('ok'=>false,'codigo'=>'vinculo_nao_persistido');}
                            else{$lead=F3Base_Leads_Repositorio::obter($lead['record_id']);}
                        }
                    }
                }
            }elseif($state===''&&!$confirmed){$p=array('ok'=>false,'codigo'=>'exige_confirmacao_nao_entrega');}
            $eligible=!empty($p['ok']);$code=$eligible?'elegivel':$p['codigo'];
            $out[$target]=array('elegivel'=>$eligible,'codigo'=>$code,'motivo'=>self::motivo($code));
            if($eligible&&!empty($e['confirmar'])){self::capturar($lead,$target);global $wpdb;$wpdb->update(self::tabela(),array('estado'=>'pendente','proxima'=>time()),array('record_id'=>$lead['record_id'],'destino'=>$target,'estado'=>$state?:'pendente'));}
        }
        $meta=F3Base_Capi_Fila::ler($lead['record_id']);$age=time()-strtotime($lead['criado_em'].' UTC');$cons=F3Base_Contato_Apresentacao::consentimento($lead['dados']);$known=$meta!==null;$state=$meta['estado']??'';
        $eligible=$lead['captura']==='aceito'&&!$lead['lixeira']&&!$lead['eliminacao_pendente']&&$cons['publicidade']&&$age>=0&&$age<=7*DAY_IN_SECONDS&&!in_array($state,array('entregue','incerto','enviando','cancelando','cancelado','falhou','expirado'),true)&&($known||in_array('meta',$e['nao_entregues_confirmados']??array(),true));
        $out['meta']=array('elegivel'=>$eligible,'codigo'=>$state?:'exige_confirmacao_nao_entrega','motivo'=>$eligible?'Elegível conforme a janela e a autorização da Meta.':'Confira aceite, consentimento, prazo de sete dias, estado da fila e confirmação de não entrega.');if($eligible&&!empty($e['confirmar'])){$out['meta']['resultado']=F3Base_Modulo_Meta_Capi::agendar_registro($lead['record_id'],true);}
        return array('ok'=>true,'simulacao'=>empty($e['confirmar']),'destinos'=>$out);
    }
    public static function conferir_agenda_1(): void {if(!wp_next_scheduled(self::HOOK)){wp_schedule_event(time()+60,'hourly',self::HOOK);}}
}
