<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

final class FieldHelp {
    public static function fields(): array {
        $auth='LinkedIn Developers → seu aplicativo → Auth → Application credentials → Authentication keys.';
        return [
            'label'=>['Nome da conexão','Use o nome do membro que gerou o token e o nome do aplicativo como aparecem no LinkedIn, separados por ·. Exemplo: Membro de marketing · Aplicativo da empresa. Onde ver: LinkedIn Developers → My apps → <aplicativo> → Settings → App name; o membro é o perfil conectado ao gerar o token no Token Generator.',''],
            'token'=>['Token de acesso (Access Token)','LinkedIn Developers → Tools → OAuth Token Tools → Token Generator → seu aplicativo. Leitura: r_ads, r_ads_reporting, r_organization_admin e r_organization_social; gestão: acrescente rw_ads e w_organization_social; Lead Sync: r_marketing_leadgen_automation; conversões: rw_conversions e r_ads, se aprovados no aplicativo. Copie o Access Token e confira sua validade.','https://www.linkedin.com/developers/tools/oauth/token-generator'],
            'client_id'=>['ID do cliente (Client ID)',$auth.' Copie Client ID; não use o número do endereço do aplicativo.','https://www.linkedin.com/developers/apps'],
            'client_secret'=>['Chave secreta do aplicativo (Primary Client Secret)',$auth.' Use o botão de copiar ao lado de Primary Client Secret. Não cole Access Token nem Client ID aqui.','https://www.linkedin.com/developers/apps'],
            'application_id'=>['Número do aplicativo (App ID no endereço)','LinkedIn Developers → seu aplicativo: é o número depois de /developers/apps/ no endereço da página. Usado nas notificações Lead Sync; é diferente de Client ID.','https://www.linkedin.com/developers/apps'],
            'refresh_token'=>['Token de renovação (Refresh Token, opcional)','Retorno OAuth: campo refresh_token. Só é emitido para aplicativos aprovados para Programmatic Refresh Tokens; não é o Primary Client Secret. Deixe vazio se o LinkedIn não o forneceu.','https://learn.microsoft.com/en-us/linkedin/shared/authentication/programmatic-refresh-tokens'],
            'refresh_expires'=>['Validade da renovação (refresh_token_expires_in, UTC)','Resposta OAuth → refresh_token_expires_in: some esses segundos ao instante em que o token foi emitido e informe a data em UTC. Sem token de renovação, deixe vazio.',''],
            'expires'=>['Validade do acesso (Access Token expiration / expires_in, UTC)','Use a validade exibida pelo Token Generator ou o instante de emissão somado a expires_in da resposta OAuth. Preencha em UTC, não no horário local. Após conferir o token, prevalece expires_at da introspecção.','https://www.linkedin.com/developers/tools/oauth/token-generator'],
            'retention_days'=>['Retenção dos resultados (configuração local)','Quantidade de dias no WordPress; não muda a retenção nem a validade de credenciais no LinkedIn.',''],
            'clear_refresh_token'=>['Remover renovação (Refresh Token)','Remove apenas o Refresh Token armazenado neste site. Não revoga o aplicativo no LinkedIn.',''],
            'clear_token'=>['Remover acesso salvo (Access Token)','Remove o Access Token deste site. Operações que dependem dele ficam bloqueadas.',''],
            'clear_client_secret'=>['Remover segredo salvo (Primary Client Secret)','Remove o segredo deste site e impede introspecção/renovação até novo preenchimento.',''],
            'enabled'=>['Ativar esta configuração (controle local)','Permissão local no WordPress. Não ativa campanha nem concede produto ou escopo no LinkedIn.',''],
            'connection_id'=>['Conexão (configuração local)','Selecione a conexão salva em Configurar → Conexões deste plugin; este nome não existe no LinkedIn.',''],
            'consumer_id'=>['Consumidor autorizado (integração local)','Escolha o plugin que receberá a concessão no WordPress. Lead Sync e Conversions API têm concessões independentes.',''],
            'callback_url'=>['Endereço de notificações (Webhook URL)','Endereço HTTPS fornecido pelo consumidor Lead Sync no site. Não use o endereço OAuth Authorized redirect URLs neste campo.',''],
            'page_id'=>['Página (Page ID / Organization ID)','Abra a Página como administrador. O número em /company/<ID>/ no endereço é o ID da Página; use a descoberta para confirmar o nome.','https://www.linkedin.com/company/'],
            'account_id'=>['Conta de anúncios (Ad account ID)','Campaign Manager → escolha a conta. O número depois de /campaignmanager/accounts/ no endereço é o ID. Use apenas a conta marcada em Ativos.','https://www.linkedin.com/campaignmanager/'],
            'form_id'=>['Formulário (Lead Gen Form ID)','Campaign Manager → conta → Assets → Lead Gen Forms → formulário. Confira o nome e o ID retornado pela descoberta; o rótulo pode estar traduzido na sua conta.','https://www.linkedin.com/campaignmanager/'],
            'conversion_id'=>['Regra de conversão (Conversion ID)','Campaign Manager → conta → Measurement → Conversion tracking → regra. ID após /conversions/ no endereço; a fonte Data source precisa ser Direct API / Conversions API.','https://www.linkedin.com/campaignmanager/'],
        ];
    }
    /** Select help by the field in this screen; never infer it from a reused HTML name. */
    public static function forField(string $label): ?string {
        return [ 'Nome da conexão'=>'label', 'ID do aplicativo'=>'client_id', 'Chave secreta do aplicativo'=>'client_secret',
            'Identificação do aplicativo nas notificações'=>'application_id', 'Token de acesso'=>'token',
            'Validade informada do token (UTC)'=>'expires','Token de renovação (opcional)'=>'refresh_token',
            'Validade do token de renovação (UTC)'=>'refresh_expires','Dias de guarda'=>'retention_days',
            'Consumidor autorizado'=>'consumer_id','Endereço de notificações'=>'callback_url'
        ][$label]??null;
    }
    public static function disclosure(string $key,string $id): void {
        $help=self::fields()[$key]??null;
        if(!$help)return;
        echo '<details class="f3-collapsible" data-f3-field-doc><summary id="'.esc_attr($id).'">Onde encontrar: '.esc_html($help[0]).'</summary>';
        self::hint($key);
        echo '</details>';
    }
    public static function label(string $name,string $fallback): string {return self::fields()[$name][0]??$fallback;}
    public static function hint(string $name,string $id=''): void {
        $f=self::fields()[$name]??null;if(!$f)return;
        echo '<small class="description" data-f3-field-help'.($id!==''?' id="'.esc_attr($id).'"':'').'>'.esc_html($f[1]);if($f[2])echo ' <a href="'.esc_url($f[2]).'" target="_blank" rel="noopener noreferrer">Abrir referência</a>';echo '</small>';
    }
    public static function callback(): void {
        echo '<div class="f3-field"><label for="f3-oauth-return">Endereço de retorno OAuth (Authorized redirect URLs for your app)</label><input id="f3-oauth-return" aria-describedby="f3-oauth-return-help" readonly value="'.esc_attr(Credentials::callbackUrl()).'"><small class="description" id="f3-oauth-return-help" data-f3-field-help>LinkedIn Developers → aplicativo → Auth → OAuth 2.0 settings → Authorized redirect URLs for your app. Cadastre exatamente este endereço, incluindo a consulta após ?. O endereço está pronto para selecionar e copiar.</small></div><div class="f3-actions"><button class="button" type="button" id="f3-copy-oauth-return">Copiar endereço de retorno</button><span id="f3-copy-oauth-state" role="status"></span></div>';
    }
    public static function table(): void {
        echo '<h3>Campos e localização no LinkedIn</h3><p>Referências oficiais consultadas em 22/10/2026; nomes podem aparecer traduzidos. A conferência em sessão autenticada do dono ainda é necessária.</p><div class="f3-field-reference f3-table-scroll" role="region" aria-label="Tabela de referência dos campos" tabindex="0"><table class="widefat striped"><thead><tr><th scope="col">Campo</th><th scope="col">Nome no LinkedIn</th><th scope="col">Onde fica</th></tr></thead><tbody>';
        foreach(self::fields() as $name=>$f){echo '<tr><td>'.esc_html($f[0]).'</td><td>'.esc_html(str_contains($f[0],'(')?substr($f[0],strpos($f[0],'(')+1,-1):'Configuração local').'</td><td>';self::hint($name);echo '</td></tr>';}
        echo '<tr><td>Retorno OAuth</td><td>Authorized redirect URLs for your app</td><td>Developers → aplicativo → Auth → OAuth 2.0 settings. Copie o endereço exibido em Configurar → Conexões.</td></tr></tbody></table></div>';
    }
    private static function grantSelectors(string $prefix): void {
        foreach(['connection_id'=>'Conexão','account_id'=>'Conta de anúncios','conversion_id'=>'Regra de conversão'] as $name=>$label){
            $id='f3-'.$prefix.'-'.$name;
            echo '<div class="f3-field"><label for="'.esc_attr($id).'">'.esc_html($label).'</label><select id="'.esc_attr($id).'" aria-describedby="'.esc_attr($id.'-help').'"><option value="">Escolha</option></select>';
            self::disclosure($name,$id.'-help');echo '</div>';
        }
    }
    public static function conversions(string $kind): void {
        if($kind==='acquisition'){
            ?><div id="f3-acquisition-form" class="f3-grant-content">
            <h2>Conversões de aquisição</h2>
            <p class="f3-lead">Autorize o Site Core a enviar conversões de aquisição pela Conversions API. Escolha uma regra ativa de fonte API. O consentimento e a fila de entrega permanecem no Site Core.</p>
            <p id="f3-capi-status" role="status"></p>
            <div class="f3-grid"><?php self::grantSelectors('capi');?></div>
            <p>Se a regra disponível for de Insight Tag, abra Measurement → Conversion tracking no LinkedIn e configure uma regra de fonte API. No Site Core, configure o mesmo ID de servidor que será autorizado aqui. Para autorizar outra regra por etapa, abra Configurar → Etapas comerciais.</p>
            <div class="f3-actions"><button class="button button-primary" id="f3-capi-grant" type="button">Confirmar concessão ao Site Core</button><button class="button" id="f3-capi-load" type="button">Carregar regras de conversão</button><button class="button" id="f3-capi-more" type="button" hidden>Mais regras</button></div>
            <details class="f3-collapsible f3-danger"><summary>Revogar concessão de aquisição</summary><p>Ao confirmar, o Site Core deixa de poder enviar conversões por este vínculo.</p><button class="button" id="f3-capi-revoke" type="button">Confirmar revogação da concessão</button></details>
            </div><?php
            return;
        }
        ?><div id="f3-stage-conversions" class="f3-grant-content">
        <h2>Conversões de etapas comerciais</h2>
        <p class="f3-lead">Autorize uma regra por etapa para o Site Core. Cada concessão pertence à conta e à ação escolhidas. Configure o mapa das etapas no Site Core; a aquisição permanece independente.</p>
        <p id="f3-stage-status" role="status"></p><div id="f3-stage-grants"></div>
        <div class="f3-grid"><?php self::grantSelectors('stage');?></div>
        <p>Consumidor: <code>site-core-quality</code>. Finalidade: <code>crm_stage</code>. Confirmar novamente renova o vínculo; eventos já reservados para o vínculo anterior ficam bloqueados no Core. Esta tela não envia conversões.</p>
        <div class="f3-actions"><button class="button button-primary" id="f3-stage-grant" type="button" disabled>Confirmar concessão comercial</button><button class="button" id="f3-stage-load" type="button">Carregar regras</button><button class="button" id="f3-stage-more" type="button" hidden>Mais regras</button><button class="button" id="f3-stage-preview" type="button">Conferir concessão comercial</button></div>
        <details class="f3-collapsible f3-danger"><summary>Revogar concessão da etapa</summary><p>Ao confirmar, o Site Core deixa de poder enviar conversões pela ação selecionada. As outras etapas mantêm suas concessões.</p><button class="button" id="f3-stage-revoke" type="button">Confirmar revogação da etapa</button></details>
        </div><?php
    }
}
