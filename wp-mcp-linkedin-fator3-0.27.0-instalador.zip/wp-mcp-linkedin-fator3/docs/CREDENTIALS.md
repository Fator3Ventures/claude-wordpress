# Credenciais, identidade e renovação — 0.27.0

Token manual continua sendo padrão. O novo fluxo OAuth pelo navegador é opcional e usa retorno no próprio site: `https://SEU-SITE/wp-admin/admin-post.php?action=f3_linkedin_oauth_callback`. Cadastre exatamente esse endereço no aplicativo do LinkedIn. Sem token inicial, salve a conexão pausada com Client ID e Primary Client Secret; selecione as permissões necessárias e clique Autorizar no LinkedIn. O retorno exige sessão administrativa atual e state aleatório, de uso único, vinculado a usuário, sessão, conexão e revisão, com validade de dez minutos. O endereço público da autorização sai em `consent_url`; os tokens nunca saem na resposta.

O aplicativo só recebe refresh token quando o programa/produto e a aprovação do LinkedIn permitem. O fluxo não promete renovação para aplicativos sem essa habilitação. Troca de código e refresh são POST HTTPS sem redirecionamento. Tokens e segredo são armazenados cifrados; configuração pública informa apenas disponibilidade, validade e geração.

`save-connection` adiciona refresh_token, refresh_expires_at e clear_refresh_token. Campo vazio preserva o segredo salvo; remoção é explícita. Alterar manualmente token, ID ou segredo do app limpa o refresh anterior se não vier novo refresh na mesma gravação, impedindo associação silenciosa à credencial antiga. Salvar somente nome/configuração após renovação mantém o token efetivo novo.

## O que o diagnóstico prova

**Consultar estado local** lê validade, incidentes, escopos registrados e avisos em lote (até 100 conexões). Não faz HTTP, não solicita introspecção, não renova a credencial e não concede permissões. Os valores secretos não são enviados ao painel. Escopos de uma prova de token que não corresponde à credencial atual não contam como autorização conhecida.

**Validar ativo no LinkedIn** faz uma leitura de metadados do ativo selecionado. Uma resposta aceita contém `proof`, `persisted:true` e a `revision` de configuração em uso. A última prova de ativo da conexão fica em um registro local cifrado separado, vinculado à revisão e à credencial consultadas. Se elas mudarem durante a consulta, a prova não é gravada como atual; releia o estado e valide a seleção pretendida. A prova nova só aparece como `remote_proof` na consulta/listagem da conexão enquanto o vínculo corresponder.

Repetir a validação não altera a revisão, a agenda ou uma concessão vigente. Uma concessão que já estava obsoleta continua exigindo revisão explícita. O resultado comprova a leitura dos metadados daquele ativo naquele instante; não comprova acesso a analytics ou leads, aprovação do aplicativo nem permissão de escrita. Inspeção de token e concessão de consumidores têm objetivos e registros próprios.

## Renovação e observação

A manutenção horária tenta a renovação nos três dias anteriores ao vencimento. O administrador que salvou a conexão é preferido; quando perde a capacidade, outro administrador atual permite a continuidade. A troca de identidade ainda exige simulação e confirmação humana. A conexão preserva o token diante de uma falha de renovação.

A manutenção acompanha separadamente o token de acesso e o de renovação nos marcos de 30, 14 e 3 dias. Envia o marco mais urgente observado, uma vez por episódio. Validade desconhecida não implica recuperação. Os incidentes, inclusive falha de renovação, seguem ao e-mail técnico configurado no Site Core; sem o contrato ficam na fila local. Não há envio direto a admin_email ou Slack. O campo configurável do painel continua sendo referência visual; os três marcos técnicos são independentes dele.

## Conferência e troca guiada de identidade

Credencial nova exige o par Access Token / Client ID / Primary Client Secret completo e introspecção ativa com r_ads, r_ads_reporting, r_organization_admin e r_organization_social. Client ID divergente, validade ausente/expirada, par recusado ou escopo ausente preservam a conexão e os vínculos salvos. A validade digitada é substituída pela validade conferida. Campos de segredo vazios preservam o salvo. Desde a 0.13.0, tamanhos usuais, alfabeto do Client ID e semelhança com outro tipo de credencial geram avisos, sem recusar a tentativa por formato. A decisão depende do LinkedIn. App ID continua sendo identificador numérico de ativo.

A introspecção **não retorna nome do aplicativo nem membro**. O nome do aplicativo vem da parte após · no nome da conexão, identificado como informado pelo administrador. Client ID, validade e escopos vêm da introspecção. Quando openid e profile já estiverem autorizados, userinfo fornece o membro; seu subject é comparável somente dentro do mesmo Client ID. Não se acrescentam essas permissões automaticamente. Ausência/falha de userinfo não vira prova de mesma identidade. A tela informa “Membro não informado pelo LinkedIn” e destaca escopos de escrita.

`save-connection` aceita `dry_run=true`. Retorna `persisted=false`, `identity_change_required`, `identity`, `affected` (agendas e concessões) e `confirmation` opaca com validade de dez minutos. Confirme reenviando exatamente a candidata/revisão com `confirmation`, `reconfirm_leads` e `reconfirm_conversions` quando houver concessões ativas. A prova é ligada à candidata, membro/Client ID/escopos conferidos, administrador, revisão e revisões dos vínculos. Alteração de qualquer um exige nova simulação. Não enviar confirmação como chave de idempotência de transporte.

Token de outro membro/aplicativo, ou token novo sem prova de mesma identidade, exige esse caminho. A seleção de ativos, formulários, usuários e versão API é mantida na troca. A tela reconfirma concessões explicitamente; CAPI reconfere papel, escopos e regra ativa CONVERSIONS_API; Lead Sync exige seu escopo e conserva permissões/formulários. Isso não substitui o teste de acesso aos formulários reais. Concessões desativadas não são reativadas. Identidade nova invalida planos em execução e identidades de serviço anteriores; o diário é preservado e pode exigir reconciliação pelo contrato existente. Agendas recebem a revisão nova sem reativação de pausas manuais.

Nome/segredo e token comprovadamente do mesmo membro/aplicativo preservam autorização; geração muda com a tupla. A conexão, agendas vigentes e concessões vigentes são regravadas atomicamente por CAS numa transação InnoDB. Histórico local conserva as últimas vinte alterações, administrador, revisões e agendas regravadas, sem credenciais. Mudança relevante para a concessão exige reconfirmação; uma mudança benigna não recupera concessão já conflitante. Cursores de SDK e operações iniciadas antes de uma gravação manual continuam sujeitos à revisão do contrato e devem ser relidos; não se reescrevem recibos nem trabalhos já iniciados.

Referências oficiais consultadas em 23/10/2026: https://learn.microsoft.com/en-us/linkedin/shared/authentication/token-introspection e https://learn.microsoft.com/en-us/linkedin/consumer/integrations/self-serve/sign-in-with-linkedin-v2 .

## Recuperação

Confira incidente e próxima tentativa, produtos/escopos liberados, segredo do app e validade do refresh. Reautorize quando necessário. Não remova concessões ou diário para sanar timeout. Preserve as salts do WordPress junto do backup cifrado. Voltar a 0.4.1 ignora a sobreposição renovada; pode voltar ao token-base antigo. Antes de rollback, faça backup completo e planeje credencial manual válida/reautorização; consulte MIGRATION.md.

Consulte FIELD-HELP.md para nomes exatos. O escopo rw_conversions foi acrescido ao consentimento opcional; r_ads também é obrigatório para CAPI. Conceder Lead Sync não concede conversões.

## Origem do Refresh Token

Um Refresh Token colado manualmente não comprova vínculo com o Access Token salvo. Na primeira renovação, se não houver prova de mesmo membro, o novo par fica como candidata cifrada por dez minutos; a credencial ativa permanece em uso e a tela exige simulação/confirmação. Somente um par emitido na mesma resposta OAuth/refresh e aceito pelo fluxo passa a fornecer continuidade para renovações seguintes sem membro legível. Trocar manualmente o refresh desfaz esse vínculo. Membro legível divergente sempre exige troca guiada.

## Avisos de credenciais

`save-connection` normaliza Access Token (`token`), Primary Client Secret (`client_secret`), Refresh Token (`refresh_token`) e Client ID. Espaços Unicode da categoria Zs nas pontas são aparados com `credential_spaces_trimmed`; espaços internos são preservados com `credential_internal_spaces`. Controles Unicode Cc, inclusive CR/LF/TAB/DEL, são recusados antes de aparar. Texto inválido e entrada só de espaços são recusados. Limites: 16.384 bytes por segredo, 160 bytes para Client ID, aplicados antes da normalização. Campo secreto exatamente vazio conserva a salva; remoção usa os controles explícitos existentes.

A resposta bem-sucedida ou prévia inclui `data.warnings`, lista de `{field,code,message}`. Falha posterior do fornecedor inclui a mesma lista em `details.warnings`. O aviso não contém valor, fragmento, tamanho medido ou fingerprint de credencial. A tela exibe cada motivo junto ao campo, inclusive após limpar os campos de senha no sucesso. Editar a credencial ou abrir outra conexão limpa avisos anteriores.

Heurísticas adicionais: `access_token_short`, `access_token_looks_like_app_credential`, `client_id_numeric`, `client_id_unexpected_characters`, `client_secret_long`, `client_secret_looks_like_other_credential`, `refresh_token_matches_access_token`. Não comprovam validade nem troca de identidade. Preservam-se a conferência do aplicativo, escopos, validade, membro e confirmação guiada, CAS e transação. Espaço removido de um token já salvo também provoca nova introspecção; rejeição mantém a salva intacta.

Client ID é enviado ao fornecedor com os caracteres internos preservados, sem sanitização textual que altere a credencial. O identificador público é escapado na renderização. O App ID das notificações não é credencial e mantém validação numérica. Refresh Token manual fica marcado como não verificado: a introspecção do Access Token não valida a renovação. Ela é conferida no endpoint OAuth quando usada, com preservação do token vigente e confirmação de outra identidade. Respostas OAuth do fornecedor mantêm a validação estrutural já existente; a regra desta versão trata a entrada administrativa e a confirmação da candidata.

## Diagnóstico do retorno OAuth e aviso de vencimento

O retorno OAuth grava `oauth-finish` em `linkedin/audit`, transporte `oauth_callback`, com `authorization_diagnostic`: operation_id, connection_id, requested_scopes, steps, result e verification_reason. Cada etapa informa endpoint, HTTP (null se falha de transporte) e resultado; introspecção acrescenta active, client_id, expires_at, status e verified_scopes, restritos a tipos e valores permitidos. A troca informa expires_in. Corpo bruto, code, state, tokens, segredos, cookies e mensagens livres do fornecedor nunca integram esse registro. Client ID público fora do formato seguro é omitido no diagnóstico. A interface mostra o motivo e o diagnóstico escapado; o retorno reabre a conexão correta. Falha de gravação da auditoria é indicada por audit_warning.

O código trocado e o novo token são enviados com o mesmo aplicativo e URI vinculados ao início do consentimento. State permanece de uso único, inclusive em falha/cancelamento. Inatividade, aplicativo divergente e vencimento têm motivos distintos; nada aceita active=false nem repete o código. HTTP 200 não comprova que o token pertence ao aplicativo. A causa do incidente histórico depende do diagnóstico da próxima autorização real. Fonte primária consultada em 31/10/2026: https://learn.microsoft.com/en-us/linkedin/shared/authentication/token-introspection .

As 11 opções de escopo, inclusive openid/profile, estão disponíveis. Ao editar, a seleção inicial reflete os escopos conferidos e conhecidos; nova conexão não herda a seleção anterior. Não se adicionam permissões automaticamente.

`credential_notice_days` é inteiro de 1 a 365 por conexão, padrão 14. Alterar esse prazo exige `save-connection` com dry_run=true e confirmação da mesma candidata/revisão. A prévia mostra credential_notice_policy.before e credential_notice_policy.after. A gravação direta de um prazo diferente retorna simulation_required. Esse prazo controla o indicador da conexão no painel. Os marcos de e-mail para o token e para a renovação são 30, 14 e 3 dias.

Salvar Refresh Token manual sem vínculo conferido abre incidente identity_change_required imediatamente, visível em status/painel, sem envio de e-mail na gravação. O texto orienta: primeira renovação exige confirmação; use **Renovar agora**, selecione **Usar autorização candidata**, simule e confirme a identidade e as concessões. O token vigente continua em uso. Enquanto aguarda confirmação, next_attempt é null e a manutenção não repete automaticamente o refresh. Se a renovação comprovar a mesma identidade, o fluxo normal pode concluir diretamente.

No diagnóstico local, confira o incidente e a ação recomendada antes de tentar outra renovação. Para uma conexão ativa com renovação pendente de confirmação, a manutenção publica o episódio técnico da credencial no Site Core. O LinkedIn não envia e-mail diretamente. O aceite do transporte do Core não comprova entrega à caixa postal.

## Concessões por domínio

Na prévia, affected.lead_grants e affected.conversion_grants incluem status, can_reconfirm, reconfirm_field e action. Estados: inactive, preserved, requires_reconfirmation, already_stale, blocked. O resultado persistido grant_effects acrescenta reconfirmed. Formulários, seleção automática de leads, rótulo e intervalo preservam CAPI quando conta/credencial/regra continuam válidas. Pages e contas Ads não usadas pelo grant preservam Lead Sync; campaign_lookup exige suas contas Ads. Mudança de identidade, versão API, usuários ou aplicativo exige avaliação/reconfirmação; remoção de recurso necessário bloqueia essa reconfirmação até corrigir a seleção/concessão.

Simule save-connection com a candidata e expected_revision; examine os vínculos e confirme com confirmation. reconfirm_leads/reconfirm_conversions podem ser escolhidos no commit da mesma candidata. Verificações remotas precedem a transação. Concessão já stale só volta mediante confirmação explícita; instalar ou editar rótulo não a recupera. Sem reconfirmar, a concessão afetada continua diagnosticada como obsoleta e a resposta/auditoria/tela informam a ação. Identidades de serviço/destino CAPI são mantidas no rebase benigno e renovadas na reconfirmação efetiva. Cursores externos conservam suas próprias revisões e precisam ser relidos após salvamento.

Quando o prazo configurado no Core coincide com um dos três marcos, os dois observadores usam a mesma referência. Se o Core tiver outro prazo, seu aviso configurado continua adicional. Falhas de renovação usam o episódio credencial_invalida da conexão; o motivo da falha aparece no diagnóstico.
