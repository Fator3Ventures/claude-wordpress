# Notas da versão — Fator3 MCP LinkedIn 0.27.0

20/11/2026. Atualização direta da 0.26.0. A nova organização do painel reúne tarefas afins e mantém os endereços das subabas que você já usava.

| Procuro… | Caminho em Ferramentas → Fator3 MCP LinkedIn |
|---|---|
| Cadastro e autorização de contas | Configurar → Conexões ou Ativos |
| Permissões de Lead Sync ou Conversions API | Configurar → Formulários, Conversões de aquisição ou Etapas comerciais |
| Métricas, agendamento ou arquivos | Dados → Relatórios, Coletas ou Histórico |
| Gerenciar campanhas ou conteúdo da Página | Dados → Anúncios e publicações |
| Conferir o site, rever prazo ou ler manual | Suporte → Diagnóstico, Retenção ou Ajuda |

A seleção ativa e o foco do teclado acompanham a cor de destaque do WordPress. O resultado de uma ação fica sob a barra administrativa e permanece legível até ser dispensado ou substituído. As cores dos estados vêm acompanhadas de texto. Em tela estreita, os grupos e subabas quebram linha; tabelas largas rolam dentro de sua própria região. A busca, o total e a paginação continuam disponíveis nas listas.

Os ajustes de tela de 20/11 (itens 1 a 15) usam a folha comum Fator3 1.0.0, incluída localmente. Nenhum novo escopo do LinkedIn é solicitado e o painel continua exigindo `manage_options`. A atualização não muda os esquemas das operações, as permissões concedidas, os dados das coletas ou o contrato com o Site Core. Consulte MIGRATION.md para conferir a troca e ADMINISTRATION.md para localizar as tarefas.
