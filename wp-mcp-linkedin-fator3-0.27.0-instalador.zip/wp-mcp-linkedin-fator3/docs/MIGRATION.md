# Instalação e atualização — 0.27.0

Instale o ZIP **instalador** em WordPress 7.1.4 ou superior, com PHP de 64 bits a partir de 8.3. Para atualizar da 0.26.0, substitua o plugin no mesmo slug. Preserve o banco, os sais do WordPress e a configuração vigente. Esta versão muda a navegação, os estilos e os componentes administrativos; não introduz uma migração de banco ou de credenciais.

1. Antes da troca, registre a versão em `linkedin/status` e o estado de um exemplo de cada fluxo que já usa: conexão, concessão, agenda ou coleta. Guarde o endereço de uma subaba que utiliza com frequência.
2. Após a troca, em nova requisição, confira `linkedin/status`, `linkedin/selftest` e a versão do índice em `linkedin/documentation` com `{"document":"index"}`. Abra o favorito anterior: ele leva à mesma subaba dentro de Configurar, Dados ou Suporte. O rodapé ou o endereço da página não são prova de versão por si só.
3. Revise os mesmos registros. Não regrave tokens nem repita ações com resultado externo incerto para comprovar a mudança visual. Se a aparência antiga persistir em um navegador, recarregue a página antes de investigar a carga das folhas.

Consulte RELEASE-0.27.0.md para localizar os comandos movidos e ADMINISTRATION.md para o mapa completo. A recuperação de agendas e a projeção do histórico por site são recursos da 0.26.0, descritos em RELEASE-0.26.0.md. Esta mudança do painel não reinicia esse processamento. Diante de uma regressão, contenha o fluxo afetado, preserve seus recibos e aplique uma nova versão corretiva.
