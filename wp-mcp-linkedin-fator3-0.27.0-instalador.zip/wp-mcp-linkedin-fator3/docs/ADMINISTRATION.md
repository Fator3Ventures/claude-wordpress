# Administração pelo painel — 0.27.0

Abra Ferramentas → Fator3 MCP LinkedIn com um usuário que tenha `manage_options`. A tela inicial é Configurar → Conexões. A primeira linha de navegação escolhe o grupo; a segunda mostra as subabas desse grupo. Cada link mantém um endereço que pode ser salvo como favorito ou aberto em outra guia. A escolha do destino funciona mesmo sem JavaScript; as consultas e gravações interativas usam os controles do painel.

Para compartilhar o grupo inteiro, abra sua primeira subaba pelo link do grupo. Por exemplo, `tools.php?page=wp-mcp-linkedin-fator3&grupo=dados` abre Relatórios. Um favorito para `tools.php?page=wp-mcp-linkedin-fator3&tab=history` continua abrindo Histórico, sem passar por Conexões.

## Onde realizar cada tarefa

| Grupo | Subaba | Quando usar |
|---|---|---|
| Configurar | Conexões | Criar ou editar o cadastro de um aplicativo e seu token. Pesquisar conexões pelo nome ou identificador. |
| Configurar | Ativos | Selecionar Páginas, contas de anúncios e formulários que uma conexão pode usar. A descoberta sozinha não concede acesso. |
| Configurar | Formulários | Conceder a um consumidor acesso aos formulários e permissões escolhidos. Para consultar o anúncio de um lead, conferir a conta, a leitura de respostas e a permissão de origem em AD-SOURCE.md. |
| Configurar | Conversões de aquisição | Associar uma conta e uma regra de conversão de fonte API ao Site Core. |
| Configurar | Etapas comerciais | Conceder uma regra específica para cada etapa do funil, distinta da regra de aquisição. |
| Dados | Relatórios | Escolher conexão, canal, ativo, datas e campos. Consultar uma página não cria uma agenda. |
| Dados | Coletas | Acompanhar, agendar e retomar uma coleta. Confira o estado, o cursor e a execução prevista antes de agir. |
| Dados | Histórico | Consultar métricas diárias já armazenadas, verificar a cobertura, preparar carga retroativa ou exportação. |
| Dados | Anúncios e publicações | Conferir o destino e a prévia antes de confirmar uma ação externa. Consultar o diário se a confirmação for incerta. |
| Suporte | Diagnóstico | Ler o estado local, executar autoteste ou, quando autorizado, verificar o acesso a um ativo no LinkedIn. |
| Suporte | Retenção | Rever e simular o prazo de auditoria. Essa política tem alcance diferente da guarda de resultados por conexão e do histórico diário. |
| Suporte | Ajuda | Ler os manuais, schemas e notas da versão que está instalada. A leitura independe da conexão com o fornecedor. |

## Editar e conferir o resultado

Em **Conexões**, use **Nova conexão** para começar. Para OAuth, cadastre o endereço de retorno no aplicativo; para acesso manual, preencha Client ID, segredo e token. Campo secreto vazio preserva o valor guardado. Datas de validade indicadas como UTC usam esse fuso.

Quando uma alteração exigir simulação, use **Simular alterações**, leia o efeito sobre ativos e concessões e use **Confirmar alterações**. Se editar o rascunho depois da prévia, simule novamente. Em formulários longos, as ações de gravação ficam na barra inferior. Um bloco recolhível agrupa opções avançadas; abra a área de risco somente para executar a ação indicada.

O resultado de uma ação aparece sob a barra do wp-admin. Leia o texto e, quando houver, a orientação para corrigir a falha. Use **Dispensar** para fechar a mensagem. Fechar o aviso não desfaz uma gravação, não repete um envio e não resolve um estado incerto. Consulte MANAGEMENT.md para reconciliar operações externas.

## Navegar com tela estreita ou teclado

A cor de destaque acompanha o esquema do usuário no WordPress. A subaba ativa tem traço e indicação de página atual. O texto do selo informa o estado também sem depender da cor. No teclado, use Tab para percorrer os controles e Enter para seguir um link ou abrir um resumo. Os botões e campos se acomodam em uma coluna nas telas menores.

Na lista de conexões, use a busca e Anterior/Próxima; o filtro considera inclusive registros de outras páginas. Se as colunas excederem a largura disponível, deslize na área da tabela; pelo teclado, dê foco à região e use as setas. Nas listas com dados obtidos em lotes, o total exibido refere-se aos itens carregados. Para consultar outro lote da origem, use o comando de mais resultados da própria lista.
