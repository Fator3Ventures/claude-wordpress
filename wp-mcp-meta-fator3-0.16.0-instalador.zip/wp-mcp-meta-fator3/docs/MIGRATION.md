# Instalação, atualização e reversão — Meta 0.16.0

Base direta aceita: 0.15.0. Instalar o ZIP 0.16.0 sobre wp-mcp-meta-fator3/wp-mcp-meta-fator3.php, sem desinstalar. Preservar backup de arquivos, banco e salts; conferir SHA-256 no relatório. Conferir versão em PHP novo, health/selftest, 47 operações e 27 documentos completos com hashes. O fonte não é instalável.

Mantidos schema de registros 2 e histórico 1, sem nova tabela nem migração destrutiva. Configuração antiga recebe assets.ads=[] apenas na normalização; nenhum ativo, consumidor, token, agenda ou contato é autorizado automaticamente. A atualização preserva ciphertext/revisões das conexões, histórico orgânico, agendas, resultados, arquivo de Stories, retenção e exclusões. Novos campos de diagnóstico são preenchidos em execuções novas; não se inventa sucesso retroativo de agendas legadas.

Conexões Ads exigem ads_read conferido na geração atual do token e seleção explícita. Regravar ativos altera a autorização da conexão e pode exigir revisão das agendas/concessões conforme os guardas existentes. Renovações da mesma identidade seguem preservando a autorização quando a validação permite. Nenhuma agenda de anúncios é criada automaticamente.

Ads usa a tabela histórica existente em partição própria por conexão/conta/nível/atribuição, compartilhável entre administradores autorizados e consumidores registrados com concessão. Histórico orgânico conserva sua partição por principal. Registros Ads ficam sempre sem prazo, mesmo em conexão com política finita. O bucket cifrado ads_grant conserva concessões/revogações sem expiração. Core1.57.1 já integra a eliminação instagram-message-erasure/1.0.0; Core1.59.0 já registra o leitor Ads, que exige configuração e concessão explícitas.

A 0.16.0 atualiza documentação e metadados de versão. Não muda lógica de negócio, assets, schemas, contratos ou armazenamento. O Core 1.61.1 registra o consumidor meta-ads-monitoring/1.0.0; o procedimento de ativação está em CORE-MONITORING.md. Instalar esta versão não altera a configuração do Core nem concede acesso.

Para voltar à 0.15.0, preserve banco, salts, chaves de privacidade, bloqueios e recibos e substitua somente os arquivos pelo instalador-base. Os relatórios e concessões de monitoramento já existem nessa base. O rollback não desfaz configurações, credenciais renovadas, revogações ou avisos já enviados; não apague recibos para repetir alertas. Não volte a versões anteriores à 0.12.0 com mensagens habilitadas, pois ignoram bloqueios de privacidade. Desativação/desinstalação preserva os dados.
