# Integração de monitoramento — Meta 0.16.0 e Core 1.61.1

O Core 1.61.1 registra `base-site-core-fator3` no contrato `meta-ads-monitoring/1.0.0` e implementa os pedidos Core 340/341. O Meta coleta e conserva atividades, contagens e EMQ; o Core lê esse acervo e decide sobre o aviso do site. O leitor de performance `meta-ads-reader/1.0.0` é independente. Não há nova concessão automática, alteração de anúncios ou compartilhamento de token.

## Configurar e autorizar

1. No Meta, confira a conexão na identidade atual com `ads_read`. Autorize a conta de anúncios e cada dataset; confira o vínculo entre dataset e conta. Leia MONITORING.md para a coleta e os limites remotos.
2. No Core, consulte o schema e leia `f3base/config-core-ler` com `nome=f3base_meta_monitoramento`. Guarde a revisão devolvida. Use `f3base/config-core-escrever`, primeiro com simulação, informando `revisao_esperada` atual e o valor tipado completo: `ativo`, `conexao`, `conta_id`, `revisao`, `reports`, `dataset_ids`, `avisar`, `canal` e o campo `operador` conforme o schema. O Core registra o operador; não escolha outra pessoa manualmente. Aumente a revisão numérica ao mudar a configuração. Use a mesma conexão/conta e os relatórios e datasets que serão concedidos. Limite de 12 datasets. Os padrões são desligado, sem conta/conexão, relatórios `ads_activity`/`dataset_quality`, avisos desligados e canal Slack. Ativação de leitura não autoriza envio.
3. Leia `meta/monitoring-consumers`. O consumidor precisa estar registrado e com configuração pronta. A recuperação do Core também precisa estar pronta e não pausada. `consumer_not_ready` significa que ainda falta uma dessas condições; instalar os pacotes não as substitui.
4. Leia `meta/get-monitoring-grant` para o consumidor, a conexão e a conta. Grave `meta/save-monitoring-grant` com a revisão esperada devolvida, `enabled=true`, `reports` e `dataset_ids` exatamente correspondentes à configuração do consumidor. A concessão é explícita por administrador autorizado e depende também do perfil de escrita do transporte MCP.
5. Confira `f3base/meta-monitoramento-status` e a concessão. Crie ou revise explicitamente as coletas/agendas no Meta para preencher o histórico. Uma concessão pronta não significa que já há dados coletados. Leia as páginas do Core até a continuação terminar, mantendo período, seleção e filtros.
6. Habilite `avisar` apenas com autorização para o canal escolhido e após conferir as provas. Qualquer mudança na configuração do Core, inclusive `avisar`, canal ou revisão, muda a revisão observada pelo SDK: confira e regrave a concessão para essa configuração antes de esperar novos avisos. Não restaure valores antigos como tentativa de reautorizar. Novas leituras devem começar sem cursor anterior.

## Identificadores e leitura

| Entrada | Conta e dataset | Período / página |
| --- | --- | --- |
| Coleta Meta `ads_activity` | `channel=ads`, `account_id` é a conta | `date_from`, `date_to` |
| Coleta Meta `dataset_quality` | `channel=dataset`, `account_id` é o dataset, `ads_account_id` é a conta | `date_from`, `date_to` |
| SDK de monitoramento | `account_id` é sempre a conta; `dataset_id` seleciona qualidade | `date_from`, `date_to`, `limit`, `cursor` |
| Core `f3base/meta-monitoramento-ler` | Usa a seleção configurada; `report` e `dataset_id` para qualidade | `de`, `ate`, `limite`, `cursor` |

Com o Fator3 MCP ativo, a chamada pública de `meta/health` também passa pela política MCP. Confira a permissão de leitura da identidade de integração local do operador usado pelo job; uma concessão SDK válida não substitui essa política. `leitura_recusada` pode indicar recusa dessa chamada pública: verifique o diagnóstico e a autorização efetiva, sem ampliar permissões automaticamente nem contornar o transporte.

O Core aceita até 366 dias e páginas de até 100 linhas nessa leitura. `f3base/anuncios-alteracoes-ler` com `plataforma=meta_ads` apresenta alterações; `entidade` é o object_id e `campo` filtra detalhes/event_type. Valores antigo/novo só existem quando a Meta os forneceu. Filtros podem deixar uma página vazia com continuação válida. `meta-entregas-ler` e `midia-prontidao-ler` do Core acrescentam `recebido_meta`.

Leitura operacional exige `manage_options`; autoria e dados pessoais exigem também `f3base_ler_leads`. Sem essa capacidade, o Core remove autoria inclusive de metadados históricos. O SDK usa somente o armazenamento local cifrado do Meta. A leitura não consulta a Graph API nem envia avisos; a operação administrativa despachada pode registrar auditoria local. Nunca leia tabelas/opções privadas de outro pacote como alternativa ao contrato.

Browser e servidor podem descrever o mesmo evento e não devem ser somados como recebidos únicos. EMQ é uma observação datada separada, não uma nota histórica do dia das contagens. Ausência, erro, limite ou cobertura incompleta permanecem desconhecidos; não viram zero. O acervo de monitoramento continua sem expiração automática, inclusive em conexão com política finita. Eliminação explícita e controles de privacidade continuam aplicáveis às funcionalidades correspondentes.

## Condições dos avisos

O Meta apresenta `dataset_optimized_event_zero` em `meta/health` somente com agenda autorizada, dia completo recente, zero explícito nas duas fontes, cobertura confirmada e evento padrão usado por conjunto observado ativo. O Core revalida a prova pelo SDK, a concessão, o operador e o estado de recuperação. Exige ainda emissão local no pixel/evento/dia exatos ou gasto positivo autorizado. Pixel do navegador e destino CAPI diferentes não são intercambiáveis. Prova desconhecida, inclusive pixel legado/GTM sem identidade demonstrada, impede aviso.

O Core limita a busca a 31 páginas locais/3100 linhas por prova; exceder o limite mantém o resultado desconhecido. Com `avisar=true`, usa Slack do site ou e-mail técnico configurado. Reserva recibo durável antes do transporte e deduplica por incidente. Resultado incerto não é repetido automaticamente. Cron depende de execução do WordPress/servidor e mantém a autorização do operador salvo. Não apague recibos para forçar repetição.

## Diagnóstico e aceite

`consumer_not_ready`: conferir seleção e recuperação Core. `grant_revoked`: obter concessão explícita atual. `revision_conflict`: reler configuração/concessão, reautorizar o escopo aprovado e reiniciar a paginação. Nenhum desses estados admite fallback para token, principal ou configuração antiga. Leitura vazia exige conferir coleta, datas, cobertura e continuação, sem presumir zero.

Para aceite com ativos reais, conferir identidade/permissões, conta/dataset, coletas de dia completo, alteração com detalhes fornecidos, contagens separadas, EMQ datada, concessão e revogação. Testar envio somente para canal autorizado e conferir uma única notificação por incidente elegível. Fixtures de laboratório validam integração e controles; não homologam a disponibilidade remota por ativo, versão da API ou permissão. O relatório da entrega informa o que foi efetivamente exercitado.

Referência de integração: código e documentação do Core 1.61.1 recebidos nesta rodada, especialmente ACERVOS-E-EMAIL-1.61.1.md. Nenhuma alteração no runtime Core é exigida por esta versão do Meta.
