# Plano — Fator3 MCP Google 0.22.0

28/10/2026 · America/Sao_Paulo. Base exata 0.21.0, instalador SHA-256 25da9ef78e303f30ce2f73b8f98743a26e09b8ed238177474e4a956578a63814. Alvo previsto 0.22.0, ainda não gerado. Entrada: impacto Core1.58.0→Google revisão2, Pedidos Core323; não criar numeração Google.

Implementar contrato opcional site-conversion-delivery/1.2.0 para site-core-quality/crm_stage, quarta posição do filtro, seleção exata por ação, concessão independente e geração vinculada. Aquisição explícita ou ausência comprovada; não reutilizar ação de contato. Manter 1.0/1.1 e os pedidos39–42.

Configuração/verificação/status administrativos por ação, sem novo segredo ou tabela. Estado limitado a100 ações na configuração de conversões existente, com revisão e trava compartilhadas. Prova por ação e renovação limitada; mudança de identidade/política/grant exige autorização atual. Capabilities são locais. Payload fechado; evento/ação deduplicam e order_id=event_id. Valor comercial fixo0/BRL. Dados pessoais e hashes somente em memória.

Reutilizar Data Manager com um evento por pedido e recibo durável. O resultado inicial é incerto, não entrega. Nova consequência concreta: Core1.58 não reconcilia recibos comerciais incertos. Emitido desde o planejamento impacto ao Core propondo site-stage-conversion-reconcile/1.0.0 e método reconcileBound(event_id,destination_ref), sem reingestão. Sua implementação Google prossegue independente; o consumidor Core permanece responsabilidade daquele pacote.

Testar contratos legados, concessões/ações independentes, aquisição ausente/ambígua/igual, revogação e troca durante HTTP, valor/evento, consentimento, userData, incerteza/dedup/reconciliação e falha de persistência. Usar consumidor Core1.58 original e produtor Google real com HTTP sintético. Matriz: limpa WP7.1.2/7.1.3, upgrade0.21, Google primeiro/isolado, MCP0.34, Meta0.13 e LinkedIn0.11. Site-Teste inicialmente Core1.57.1: não alterar outro pacote para fabricar aceite; documentar diferença. Nenhum envio comercial ou publicação autorizados.

Revisão5 das normas prevalece. Atendimento Core316 já recebido no1.58; registrar desfecho no relatório, sem reemitir impacto anterior. Artefatos: instalador/fonte/relatório próprios e impacto somente pela nova necessidade de reconciliação. Fechar bytes após validação; fonte inclui relatório pré-fechamento. Entrega corrente persiste pelo fluxo de arquivos.

Ajuste de escopo antes do fechamento: atender orientação do usuário de implementar dependências Core sem aguardar retorno. Preparar patch aplicável ao Core1.58 original e testá-lo em bancada separada, sem substituir o pacote original nos testes de coexistência nem no Site-Teste.
