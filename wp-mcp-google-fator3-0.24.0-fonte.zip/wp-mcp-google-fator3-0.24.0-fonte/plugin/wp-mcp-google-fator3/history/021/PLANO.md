# Plano — Fator3 MCP Google 0.21.0

28/10/2026, America/Sao_Paulo. Implementação a partir da 0.20.0 entregue, SHA-256 do instalador `8c2456de80896dc7078321248a1df01c89745fc7f80a2c6e769ef1b6d543bbfd`. Alvo previsto 0.21.0, ainda não empacotado.

Pedidos MCP Google 39–42. Acompanhantes recebidos: Core 1.57.1, LinkedIn 0.11.0, Pipedrive 0.2.0; preservados MCP 0.33.0 e Meta 0.12.0. Normas: instruções revisão 4 e padrão revisão 5, incorporado na entrega anterior e no Core recebido. Anexos revisão 4 não revogam a revisão 5 já vigente.

1. Ampliar contrato de conversões para 1.1.0 com negociação retrocompatível da 1.0.0, prontidão por conta/ação observada durante verificação explícita, normalização/hash de `user_data.email`/`telefone`, consentimento e recusa própria. Leituras de capabilities/status permanecem locais. A base já usa Data Manager: preservar esse transporte, recibo durável e reconciliação; mapear hashes para seu `userData.userIdentifiers`, com `encoding=HEX`, sem introduzir outro envio da mesma conversão. O texto ClickConversion do pedido não corresponde ao transporte vigente. Documentação oficial confirma Data Manager para leads e restringe novas integrações no endpoint antigo.
2. Acrescentar `compact` e `fields` ao schema de configuração; `compact` ao status. Preservar resposta completa por padrão, revisão, leitura administrativa e redação de segredos.
3. Expor somente `client_email`/`project_id` da chave de conta de serviço salva por conexão nas duas consultas pedidas, sem id/chave privada, sem usar a credencial candidata como ativa.
4. Registrar fase/diagnóstico sanitizado e cada tentativa de renovação, inclusive executor, além de histórico desde a verificação anterior e intervalo sem prova vigente. Não coletar evento real na verificação.

Impacto técnico novo: Core 316, documentado antes da implementação em `wp-mcp-google-fator3-0.21.0-impacto-base-site-core-fator3.md`. Google 38/Core 313 já recebido como atendido pelo Core 1.57.1; encerramento no relatório principal, sem reemitir impacto antigo. Nenhuma espera pelo Core condiciona a entrega Google. Nenhuma alteração prevista nos demais acompanhantes.

Validação prevista: regressões unitárias, fixtures HTTP, autorização/privacidade, consultas curtas comparadas às completas, falhas de renovação, contrato Core original 1.57.1, WordPress limpo e atualização direta 0.20.0, documentação via MCP, instalação autorizada no Site-Teste com hash. Dados Google reais e primeiro contato da frota dependem das credenciais e da implementação Core 316; não serão simulados como aceite externo.
