# Proposta histórica incorporada ao Core

O Core 1.61.1 já implementa e amplia os leitores Core 337/340/342. Não copie, inclua ou aplique estes PHP no Core atual. O bootstrap está desativado e não registra classes/hooks nem modifica opções, inclusive se carregado antes do Core. Os arquivos de classes permanecem como referência histórica de origem; não são uma alternativa de implantação.

Atendimento ao impacto Core 1.61.1 revisão 2: a referência da opção Ads foi corrigida para f3base_google_ads_acervo. A opção f3base_google_ads pertence a conversões/tag e deve ser preservada. O código efetivo e a integração de sessões/contatos/histórico são mantidos pelo Core. Não há migração automática de configuração ou dados a partir da proposta.

Use a configuração pública e os contratos descritos em docs/CORE-ACERVOS.md da release Google 0.24.0. Os testes apply-core023/core023 e as evidências 023 descrevem a proposta anterior sobre Core 1.60; não executá-los para aplicar consumidores nesta release. A prova corrente usa o instalador original Core 1.61.1.
