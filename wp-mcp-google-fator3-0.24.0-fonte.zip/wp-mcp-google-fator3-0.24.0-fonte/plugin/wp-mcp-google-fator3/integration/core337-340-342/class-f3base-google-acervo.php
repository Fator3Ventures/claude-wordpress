<?php
/** Core 337/340: optional local Ads reader; credentials and collection remain in Google. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Google_Acervo {
    const OPTION='f3base_google_ads_acervo';const CONTRACT='google-ads-reader/1.0.0';const CONSUMER='base-site-core-fator3';
    private static $client=null;
    public static function padroes(): array{return ['ativo'=>false,'conexao'=>'','conta_id'=>'','revisao'=>0];}
    public static function props(): array{return ['ativo'=>['type'=>'boolean'],'conexao'=>['type'=>'string','maxLength'=>40],'conta_id'=>['type'=>'string','pattern'=>'^([0-9]{10})?$'],'revisao'=>['type'=>'integer','minimum'=>0,'maximum'=>2147483647]];}
    public static function opcoes(): array{return array_replace(self::padroes(),(array)F3Base_Options::ler(self::OPTION));}
    public static function validar($v): string {
        $e=rest_validate_value_from_schema($v,['type'=>'object','properties'=>self::props(),'additionalProperties'=>false]);if(is_wp_error($e))return $e->get_error_message();
        $v=array_replace(self::padroes(),$v);$old=self::opcoes();
        if($v['ativo']&&($v['conexao']===''||!preg_match('/^[0-9]{10}$/D',$v['conta_id'])||$v['revisao']<1))return 'Informe conexão, conta e revisão positiva.';
        if($v!==$old&&$v['revisao']<=$old['revisao'])return 'Aumente a revisão para alterar ou restaurar a seleção.';
        return '';
    }
    public static function configuracao(): array {
        $c=self::opcoes();$state=F3Base_Recuperacao::ler();
        return ['account_ids'=>$c['conta_id']!==''?[$c['conta_id']]:[],'revision'=>hash('sha256',wp_json_encode([$c,$state['geracao']??0])),'ready'=>$c['ativo']&&$c['conexao']!==''&&(bool)preg_match('/^[0-9]{10}$/D',$c['conta_id'])&&!empty($state['ok'])&&empty($state['pausado'])];
    }
    public static function descobrir($sdk,string $contract): void {
        if($contract!==self::CONTRACT||self::$client)return;
        try{$caps=$sdk::capabilities();if(($caps['contract']??'')!==self::CONTRACT||($caps['remote_calls']??null)!==false)return;$client=$sdk::register_consumer(self::CONSUMER,F3BASE_PLUGIN_VERSAO,self::CONTRACT,[__CLASS__,'configuracao']);if(is_object($client)&&is_callable([$client,'query'])&&is_callable([$client,'status']))self::$client=$client;}catch(Throwable $e){self::$client=null;}
    }
    public static function iniciar(): void {
        add_filter('f3base_options_catalogo',static function($c){$c[self::OPTION]=F3Base_Conversas::catalogo_grupo(self::OPTION,'Google Ads — acervo local',self::padroes(),self::props(),[__CLASS__,'validar']);$c[self::OPTION]['secao']='integracoes';$c[self::OPTION]['descricao']='Seleciona conta e conexão do leitor. Autorize a coleta e o leitor no MCP Google; nenhuma concessão é automática.';return $c;});
        add_action('wp_abilities_api_init',[__CLASS__,'registrar']);
    }
    public static function registrar(): void {
        F3Base_Servicos::ability('google-ads-acervo-status','Estado do leitor Google Ads, sem chamada ao fornecedor',[__CLASS__,'status']);
        F3Base_Servicos::ability('google-ads-acervo-ler','Lê dias do acervo Google Ads, com moeda, revisão e cobertura; GCLID somente por igualdade exata',[__CLASS__,'consultar'],self::schema(),['de','ate','dataset'],true,'manage_options',static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads'));
    }
    public static function schema(): array{return ['de'=>['type'=>'string','format'=>'date'],'ate'=>['type'=>'string','format'=>'date'],'dataset'=>['type'=>'string','enum'=>['clicks','customer','campaign','ad_group','ad','search_terms','changes']],'limite'=>['type'=>'integer','minimum'=>1,'maximum'=>1000,'default'=>500],'cursor'=>['type'=>'string','maxLength'=>20000],'gclid'=>['type'=>'string','minLength'=>1,'maxLength'=>1024]];}
    private static function erro(string $code): array{return ['ok'=>false,'codigo'=>$code,'linhas'=>[],'proximo_cursor'=>null,'http_fornecedor'=>false];}
    private static function chamar(string $method,array $i=[]): array {
        if(!self::$client)return ['success'=>false,'error_code'=>'sdk_ausente'];
        $deny=static fn()=>new WP_Error('google_acervo_local','Leitura exclusivamente local.');add_filter('pre_http_request',$deny,PHP_INT_MAX,3);
        try{$r=$method==='status'?self::$client->status():self::$client->query($i);return is_array($r)?$r:['success'=>false,'error_code'=>'resposta_sdk_invalida'];}catch(Throwable $e){return ['success'=>false,'error_code'=>'sdk_indisponivel'];}finally{remove_filter('pre_http_request',$deny,PHP_INT_MAX);}
    }
    public static function status(array $i=[]): array {
        if(!current_user_can('manage_options'))return self::erro('sem_permissao');
        return ['ok'=>true,'contrato'=>self::CONTRACT,'registrado'=>self::$client!==null,'configuracao'=>self::configuracao(),'conexao'=>self::opcoes()['conexao'],'sdk'=>self::chamar('status'),'http_fornecedor'=>false,'coleta'=>'Configurar e conceder no MCP Google.'];
    }
    private static function cursor(array $v): string {$s=base64_encode(wp_json_encode($v));return $s.'.'.hash_hmac('sha256',$s,wp_salt('auth'));}
    public static function consultar(array $i): array {
        if(!current_user_can('manage_options')||!current_user_can('f3base_ler_leads'))return self::erro('sem_permissao');
        $e=rest_validate_value_from_schema($i,['type'=>'object','properties'=>self::schema(),'additionalProperties'=>false,'required'=>['de','ate','dataset']]);
        if(is_wp_error($e)||!F3Base_Gsc::data_valida($i['de']??'')||!F3Base_Gsc::data_valida($i['ate']??'')||$i['de']>$i['ate']||(new DateTimeImmutable($i['de']))->diff(new DateTimeImmutable($i['ate']))->days>365||isset($i['gclid'])&&$i['dataset']!=='clicks')return self::erro('consulta_invalida');
        $cfg=self::configuracao();$sel=self::opcoes();if(!$cfg['ready'])return self::erro('configuracao_pendente');
        $bind=hash('sha256',wp_json_encode([$cfg,$sel,$i['de'],$i['ate'],$i['dataset'],$i['limite']??500,$i['gclid']??null]));$day=$i['de'];$provider=null;
        if(!empty($i['cursor'])){if(substr_count($i['cursor'],'.')!==1)return self::erro('cursor_invalido');[$body,$sig]=explode('.',$i['cursor']);if(!hash_equals(hash_hmac('sha256',$body,wp_salt('auth')),$sig))return self::erro('cursor_invalido');$plain=base64_decode($body,true);$c=$plain!==false?json_decode($plain,true):null;if(!is_array($c)||($c['binding']??'')!==$bind||($c['expires']??0)<time()||!F3Base_Gsc::data_valida((string)($c['date']??''))||$c['date']<$i['de']||$c['date']>$i['ate'])return self::erro('cursor_expirado_ou_alterado');$day=$c['date'];$provider=$c['provider'];}
        $q=['contract_version'=>'1.0.0','connection_id'=>$sel['conexao'],'account_id'=>$sel['conta_id'],'dataset'=>$i['dataset'],'date'=>$day,'consumer_revision'=>$cfg['revision'],'limit'=>$i['limite']??500];if($provider)$q['cursor']=$provider;
        $r=self::chamar('query',$q);if(empty($r['success']))return self::erro($r['error_code']??'sdk_indisponivel');
        if(($r['contract_version']??'')!=='1.0.0'||!is_array($r['rows']??null)||!array_key_exists('next_cursor',$r)||!is_array($r['coverage']??null))return self::erro('resposta_sdk_invalida');
        $rows=[];foreach($r['rows'] as $row){if(!is_array($row)||($row['account_id']??'')!==$sel['conta_id']||($row['date']??'')!==$day||($row['dataset']??'')!==$i['dataset'])return self::erro('linha_sdk_invalida');if(!isset($i['gclid'])||isset($row['gclid'])&&is_string($row['gclid'])&&hash_equals($i['gclid'],$row['gclid']))$rows[]=$row;}
        if(self::configuracao()!==$cfg||self::opcoes()!==$sel)return self::erro('configuracao_alterada');
        $nextDay=$r['next_cursor']?$day:(new DateTimeImmutable($day))->modify('+1 day')->format('Y-m-d');
        $next=$nextDay<=$i['ate']?self::cursor(['binding'=>$bind,'date'=>$nextDay,'provider'=>$r['next_cursor'],'expires'=>time()+86400]):null;
        return ['ok'=>true,'contrato'=>self::CONTRACT,'conta_id'=>$sel['conta_id'],'data'=>$day,'dataset'=>$i['dataset'],'linhas'=>$rows,'proximo_cursor'=>$next,'revisao'=>$r['revision']??null,'extraido_em'=>$r['extracted_at']??null,'moeda'=>$r['currency']??null,'fuso'=>$r['time_zone']??null,'cobertura'=>$r['coverage'],'http_fornecedor'=>false,'totais_agregados'=>false,'gclid_filtro_exato'=>isset($i['gclid']),'limites'=>['Não somar revisões do mesmo recorte nem moedas distintas.','Ausência de linha não prova zero ou ausência de clique.','Termos agregados não são associados a GCLID.']];
    }
}
