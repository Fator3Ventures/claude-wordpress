<?php
/** Core 342: independent GSC query/page/day reader, preserving the existing page/day archive. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Gsc_Consultas {
    const OPTION='f3base_gsc_consultas';const CONTRACT='search-console-reader/1.1.0';
    private static $client=null;
    public static function configuracao(): array {
        $base=F3Base_Gsc::configuracao();$cfg=(array)F3Base_Options::ler(self::OPTION);
        return ['property'=>$base['property'],'revision'=>hash('sha256',wp_json_encode([$base['revision'],$cfg])),'ready'=>$base['ready']&&!empty($cfg['ativo'])];
    }
    public static function descobrir($sdk,string $contract): void {
        if($contract!==self::CONTRACT||self::$client)return;
        try{$caps=$sdk::capabilities();if(!in_array('gsc.query-page-day.read',$caps['capabilities']??[],true))return;$c=$sdk::register_consumer('base-site-core-fator3',F3BASE_PLUGIN_VERSAO,self::CONTRACT,[__CLASS__,'configuracao']);if(is_object($c)&&is_callable([$c,'query'])&&is_callable([$c,'effective_status']))self::$client=$c;}catch(Throwable $e){self::$client=null;}
    }
    public static function iniciar(): void {
        add_filter('f3base_options_catalogo',static function($c){$c[self::OPTION]=F3Base_Conversas::catalogo_grupo(self::OPTION,'Search Console — consultas por página e dia',['ativo'=>false,'revisao'=>0],['ativo'=>['type'=>'boolean'],'revisao'=>['type'=>'integer','minimum'=>0,'maximum'=>2147483647]],static function($v){$old=(array)F3Base_Options::ler(self::OPTION);return $v!==$old&&($v['revisao']??0)<=($old['revisao']??0)?'Aumente a revisão ao alterar esta seleção.':'';});$c[self::OPTION]['secao']='integracoes';return $c;});
        add_action('wp_abilities_api_init',[__CLASS__,'registrar']);
    }
    public static function registrar(): void {
        F3Base_Servicos::ability('gsc-consultas-status','Estado local da leitura consulta × página × dia',[__CLASS__,'status']);
        F3Base_Servicos::ability('gsc-consultas-ler','Consulta GSC 1.1 com continuação e cobertura explícitas; preserva page-day 1.0',[__CLASS__,'consultar'],['data'=>['type'=>'string','format'=>'date'],'limite'=>['type'=>'integer','minimum'=>1,'maximum'=>5000,'default'=>1000],'cursor'=>['type'=>'string','maxLength'=>4096]],['data'],true,'manage_options');
    }
    public static function status(array $i=[]): array {
        if(!current_user_can('manage_options'))return ['ok'=>false,'codigo'=>'sem_permissao'];
        return ['ok'=>true,'contrato'=>self::CONTRACT,'registrado'=>self::$client!==null,'configuracao'=>self::configuracao(),'servico'=>self::$client?self::$client->effective_status():null,'http_fornecedor'=>false];
    }
    public static function consultar(array $i): array {
        if(!current_user_can('manage_options'))return ['ok'=>false,'codigo'=>'sem_permissao'];
        if(!is_string($i['data']??null)||!F3Base_Gsc::data_valida($i['data'])||array_diff(array_keys($i),['data','limite','cursor']))return ['ok'=>false,'codigo'=>'consulta_invalida'];
        $cfg=self::configuracao();if(!$cfg['ready']||!self::$client)return ['ok'=>false,'codigo'=>self::$client?'configuracao_pendente':'sdk_ausente'];
        $q=['contract_version'=>'1.1.0','property'=>$cfg['property'],'consumer_revision'=>$cfg['revision'],'date'=>$i['data'],'run_id'=>'core-query-'.bin2hex(random_bytes(8)),'trigger'=>'manual','budget_ms'=>20000,'limit'=>$i['limite']??1000];if(isset($i['cursor']))$q['cursor']=$i['cursor'];
        try{$r=self::$client->query($q);}catch(Throwable $e){return ['ok'=>false,'codigo'=>'sdk_indisponivel'];}
        if(!is_array($r)||empty($r['success']))return ['ok'=>false,'codigo'=>$r['error_code']??'resposta_sdk_invalida'];
        if(self::configuracao()!==$cfg||($r['contract_version']??'')!=='1.1.0'||($r['coverage']['dimensions']??null)!==['date','page','query']||($r['coverage']['anonymous_queries_excluded']??null)!==true)return ['ok'=>false,'codigo'=>'resposta_ou_configuracao_alterada'];
        return ['ok'=>true,'contrato'=>self::CONTRACT,'linhas'=>$r['rows'],'proximo_cursor'=>$r['next_cursor'],'cobertura'=>$r['coverage'],'http_fornecedor'=>$r['remote_dispatched'],'page_day_anterior_preservado'=>true,'cliques_anonimizados'=>null,'nota'=>'A diferença para page-day inclui possíveis limites e agregação. Não é uma contagem exata de anonimização.'];
    }
}
