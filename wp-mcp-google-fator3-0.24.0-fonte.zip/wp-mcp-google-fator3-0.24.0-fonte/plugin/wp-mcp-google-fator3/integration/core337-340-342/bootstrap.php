<?php
/** Retired source proposal. Core 1.61.1 owns these consumers; never load them from Google. */
if (!defined('ABSPATH')) { exit; }
// Intentionally inert even when included before the native Core plugin.
return;
