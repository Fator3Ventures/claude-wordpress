# Integração Core 323 — reconciliação comercial

Patch sobre o arquivo original do Core 1.58.0, identificado por SHA-256 em identity.json. Aplique com `git apply --check core-1.58.0-reconciliacao-comercial.patch` e depois `git apply core-1.58.0-reconciliacao-comercial.patch` na raiz do plugin Core correspondente. O arquivo completo modificado acompanha o diff. Não é novo pacote/versionamento oficial Core e não foi instalado no Site-Teste.

O worker mantém seu caminho de pendentes e consulta até dois incertos Google por passagem, após 1800s, sob a mesma trava renovável. Reserva o intervalo antes de consultar, exige configuração/ação/referência atuais e a extensão exata. Reconstrói apenas event_id; não lê identificadores pessoais nem chama sendBound nesse caminho. Prova de envio expirada pode ser consultada; concessão revogada ou alterada fica incerta sem HTTP. Sem capacidade, erro ou persistência confirmada, não autoriza reenvio. Destinos LinkedIn permanecem com o comportamento original.

Não altera schema nem opções. O backoff remoto permanece imposto pelo produtor. Reversão do arquivo preserva todos os recibos e deixa os incertos sem reconciliação automática. O relatório distingue teste do Core original e teste desse patch. O mantenedor deve incorporar a alteração em sua próxima versão e seus gates completos.
