"""Google 0.23.0 final verification: clean, direct upgrade 0.22.0, independent order and isolated. All inputs are pinned by SHA-256."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, shutil, subprocess, sys, zipfile

ROOT = Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path); module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

CASES = {
    'clean': ('min','clean','mcp-first','7.1.2',['minimum018','clean','credentials019','contracts023','requests020','requests021','requests022','requests023','documentation018']),
    'clean-713': ('current','clean','mcp-first','7.1.3',['minimum018','clean','contracts023','requests020','requests021','requests022','requests023','documentation018']),
    'upgrade': ('upgrade018','upgrade','mcp-first','7.1.3',['upgrade019','minimum018','contracts023','requests020','requests021','requests022','requests023','documentation018']),
    'google-first': ('current','clean','google-first','7.1.3',['minimum018','clean','public-sdk','regression017','delivery017','delivery018','dom017','requests020','requests021','requests022','requests023']),
    'core-consumers': ('current','clean','mcp-first','7.1.3',['apply-core023','core023']),
    'isolated': ('min','clean','google-only','7.1.2',['minimum018','clean','requests020','requests021','requests022','requests023','standalone014']),
}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ['manifest', 'manifest-current', 'manifest-upgrade', 'work-base', 'evidence', 'php']: p.add_argument('--' + name, required=True, type=Path)
    p.add_argument('--only', action='append', default=[])
    a = p.parse_args(); ev = a.evidence.resolve(); work = a.work_base.resolve()
    if ev.exists() and any(ev.iterdir()): raise ValueError('Evidence destination must be empty')
    ev.mkdir(parents=True, exist_ok=True)
    lab = load_module('release018_lab', ROOT / 'tools/lab.py'); build = load_module('release018_build', ROOT / 'build/build.py')
    manifests = {'min': a.manifest.resolve(), 'current': a.manifest_current.resolve(), 'upgrade018': a.manifest_upgrade.resolve()}
    configs = {}
    for key, path in manifests.items():
        configs[key] = lab.checked_inputs(path)
    candidate = configs['min'][1]['candidate']; identity = build.identity(); digest = sha(candidate)
    if sha(configs['current'][1]['candidate']) != digest: raise ValueError('Both manifests must pin the same candidate')
    with zipfile.ZipFile(candidate) as z:
        if len(z.namelist()) != len(set(z.namelist())): raise ValueError('Duplicate ZIP member')
        actual = {n.removeprefix('wp-mcp-google-fator3/'): z.read(n) for n in z.namelist()}
    if actual != build.manifest(): raise ValueError('Runtime/candidate mismatch')
    php = a.php.resolve()
    for path in actual:
        if path.endswith('.php'): subprocess.run([str(php), '-l', str(ROOT / path)], check=True, stdout=subprocess.DEVNULL)
    subprocess.run([str(php), str(ROOT / 'build/export-contracts.php'), '--check'], check=True)
    subprocess.run([sys.executable, str(ROOT / 'build/check-docs.py')], check=True)
    contracts = {}
    for mode in ['absent', 'missing-method', 'matrix']:
        proof = json.loads(subprocess.run([str(php), str(ROOT / 'tests/conversions-contract012.php'), mode], check=True, capture_output=True, text=True).stdout)
        (ev / ('contracts-' + mode + '.json')).write_text(json.dumps(proof, indent=2) + '\n')
        contracts[mode] = {'checks': proof['checks'], 'sha256': sha(ev / ('contracts-' + mode + '.json'))}
    fixed = json.loads(subprocess.run([str(php), str(ROOT / 'tests/conversion-response013.php')], check=True, capture_output=True, text=True).stdout)
    (ev / 'response-candidate018.json').write_text(json.dumps(fixed, indent=2) + '\n')
    contracts['response013'] = {'checks': fixed['checks'], 'sha256': sha(ev / 'response-candidate018.json')}
    groups = {}
    for name, (mkey, origin, order, wp_expected, suites) in CASES.items():
        if a.only and name not in a.only: continue
        print('RUN ' + name, flush=True); dest = work / name
        current_manifest = manifests[mkey]; current_inputs = configs[mkey][1]
        env = os.environ.copy(); env['F3_LAB_WP_EXPECTED'] = wp_expected
        cmd = [sys.executable, str(ROOT / 'tools/lab.py'), '--manifest', str(current_manifest), '--workdir', str(dest), '--origin', origin, '--order', order] + ['tests/native/' + s + '.php' for s in suites]
        with open(ev / (name + '.log'), 'w') as log: subprocess.run(cmd, check=True, stdout=log, stderr=subprocess.STDOUT, env=env)
        out = ev / name; shutil.copytree(dest / 'evidence', out)
        reports = {}
        for suite in suites:
            f = out / (suite + '.json'); d = json.loads(f.read_text())
            if d.get('failures') != 0 or d.get('candidate_sha256') != digest or d.get('checks', 0) != len(d.get('passed', [])) or d.get('checks', 0) < 1: raise ValueError('Invalid suite ' + suite)
            if d.get('wordpress') != wp_expected: raise ValueError('Suite ran on unexpected WordPress ' + suite)
            reports[suite] = {'checks': d['checks'], 'sha256': sha(f)}
        env_report = json.loads((out / 'environment.json').read_text())
        if not env_report['processes_stopped'] or env_report['candidate_sha256'] != digest: raise ValueError('Environment not closed')
        debug = dest / 'wordpress/wp-content/debug.log'
        google_notices = [l for l in (debug.read_text(errors='replace').splitlines() if debug.exists() else []) if 'wp-mcp-google-fator3' in l and ('PHP Warning' in l or 'PHP Notice' in l or 'PHP Deprecated' in l or 'PHP Fatal' in l)]
        (out / 'google-debug-findings.json').write_text(json.dumps(google_notices, indent=2) + '\n')
        if google_notices: raise ValueError('Google PHP notices in ' + name)
        inv = {'candidate': lab.installed_inventory(candidate, dest / 'wordpress/wp-content/plugins', 'wp-mcp-google-fator3')}
        for key, slug in [('mcp', 'wp-mcp-fator3'), ('core', 'base-site-core-fator3'), ('meta', 'wp-mcp-meta-fator3'), ('linkedin', 'wp-mcp-linkedin-fator3')]:
            if (dest / 'wordpress/wp-content/plugins' / slug).exists(): inv[key] = lab.installed_inventory(current_inputs[key], dest / 'wordpress/wp-content/plugins', slug)
        groups[name] = {'checks': sum(d['checks'] for d in reports.values()), 'reports': reports, 'environment_sha256': sha(out / 'environment.json'), 'installed_inventory': inv, 'origin': origin, 'order': order, 'wordpress': wp_expected, 'google_php_notices': 0}
        print('PASS ' + name + ' ' + str(groups[name]['checks']), flush=True)
    if build.identity() != identity or sha(candidate) != digest: raise ValueError('Inputs changed during verification')
    proof = {'schema_version': 1, 'release': '0.23.0', 'scope': 'Google43–46; Google39–42/Core323 regression; baseline0.22.0; MCP0.36/Core1.60/Meta0.14/LinkedIn0.12 original; synthetic provider; no real-account claim',
             'candidate_sha256': digest, 'identity': identity, 'checks': sum(g['checks'] for g in groups.values()), 'contract_tests': contracts, 'failures': 0,
             'runtime_files': len(actual), 'php_lint_files': sum(n.endswith('.php') for n in actual), 'groups': groups,
             'inputs': {key: {k: {'sha256': v['sha256'], 'version': v['version']} for k, v in cfg[0]['inputs'].items()} for key, cfg in configs.items()}}
    (ev / 'validation023.json').write_text(json.dumps(proof, indent=2) + '\n')
    print(json.dumps({'passed': True, 'checks': proof['checks'], 'candidate_sha256': digest}), flush=True)

if __name__ == '__main__': main()
