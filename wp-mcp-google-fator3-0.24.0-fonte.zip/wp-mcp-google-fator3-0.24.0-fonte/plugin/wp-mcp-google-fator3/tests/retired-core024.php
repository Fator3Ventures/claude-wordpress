<?php
define('ABSPATH',__DIR__.'/');$calls=0;function add_action(...$args){global $calls;$calls++;}function add_filter(...$args){global $calls;$calls++;}
require dirname(__DIR__).'/integration/core337-340-342/bootstrap.php';
if($calls!==0||class_exists('F3Base_Google_Acervo',false)||class_exists('F3Base_Gsc_Consultas',false))throw new RuntimeException('Retired bootstrap still active');
echo json_encode(['checks'=>1,'failures'=>0,'scope'=>'Including retired bootstrap before native Core is inert'])."\n";
