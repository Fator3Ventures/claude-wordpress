<?php
/** Pedidos 39–42 against original WordPress, Google and companion runtimes. */
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{ConversionDelivery as D,Options as O,Connections as C,Settings,Policy,Records,Audit,Configuration,Auth\Credentials};
wp_get_abilities();$calls=[];$phase='ok';$terms=true;$leads=true;$secret='synthetic-mp-021';$sent=[];
O::set(D::CONFIG,D::defaults());
if(class_exists('F3Base_Conversoes_Contexto'))update_option('f3base_ga4_measurement_id','G-TEST021');
$fixture=static function($pre,$args,$url)use(&$calls,&$phase,&$terms,&$leads,$secret,&$sent){
 if(str_starts_with($url,getenv('F3_LAB_URL').'/'))return $pre;
 $calls[]=['url'=>$url,'method'=>$args['method']??'GET'];$body=[];$code=200;$c=O::get(D::CONFIG);$input=is_string($args['body']??null)?json_decode($args['body'],true):($args['body']??[]);
 if(str_contains($url,'/token'))$body=['access_token'=>'synthetic-access021','expires_in'=>3600];
 elseif(str_contains($url,'googleAds:search')){
  if(str_contains($input['query']??'','FROM customer'))$body=['results'=>[['customer'=>['id'=>$c['customer_id'],'conversionTrackingSetting'=>['acceptedCustomerDataTerms'=>$terms,'enhancedConversionsForLeadsEnabled'=>$leads]]]]];
  else $body=['results'=>[['conversionAction'=>['resourceName'=>$c['conversion_action'],'type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>0,'defaultCurrencyCode'=>'BRL']]]]];
 }
 elseif(str_contains($url,'/events:ingest')){$sent[]=$input;$body=empty($input['validateOnly'])?['requestId'=>'synthetic-request-'.count($sent)]:[];}
 elseif(str_contains($url,'measurementProtocolSecrets')){if($phase==='secret'){$code=403;$body=['error'=>['status'=>'PERMISSION_DENIED','message'=>'Access denied to secret list.']];}else $body=['measurementProtocolSecrets'=>[['secretValue'=>$secret]]];}
 elseif(str_contains($url,'analyticsadmin.googleapis.com')){
  if($phase==='exception')throw new RuntimeException('private-exception user@example.test');
  if($phase==='stream'){$code=403;$body=['error'=>['status'=>'PERMISSION_DENIED','message'=>'Stream denied user@example.test api_secret='.$secret.' Bearer secret-token '.str_repeat('b',64)]];}
  else $body=['name'=>$c['stream'],'webStreamData'=>['measurementId'=>'G-TEST021']];
 }
 elseif(str_contains($url,'/debug/mp/collect'))$body=['validationMessages'=>$phase==='debug'?[['validationCode'=>'VALUE_INVALID','description'=>'Invalid event name for validation.']]:[]];
 else return $pre;
 return ['response'=>['code'=>$code],'headers'=>[],'body'=>wp_json_encode($body)];
};add_filter('pre_http_request',$fixture,1,3);
O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ga'=>'write','ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic-021',O::OAUTH_REFRESH_TOKEN=>'synthetic-021',O::ADS_DEVELOPER_TOKEN=>'synthetic-dev021']);
$fields=['audit_retention','job_detail_days','job_summary_days'];$full=Configuration::read();
$small=wp_get_ability('google/configuration-schema')->execute(['compact'=>true,'fields'=>$fields]);
verifyLab('40 compact selected three fields under 2KB',!empty($small['success'])&&strlen(wp_json_encode($small))<2048,['bytes'=>strlen(wp_json_encode($small))]);
foreach($fields as $id)verifyLab('40 same effective value '.$id,$small['options'][$id]['value']===$full['options'][$id]['state']['effective_value']);
verifyLab('40 only selected options returned',count($small['options'])===3&&!array_diff(array_keys($small['options']),$fields));
$full=wp_get_ability('google/status')->execute([]);$small=wp_get_ability('google/status')->execute(['compact'=>true]);
verifyLab('40 compact status is smaller and local',$small['success']&&strlen(wp_json_encode($small))<strlen(wp_json_encode($full))&&!$calls);
$all=wp_get_ability('google/status')->execute(['compact'=>true,'scope'=>'all_connections']);verifyLab('40 all connections compact status executes',$all['success']&&!$calls);
$created=C::create('identity021','Identity fixture');verifyLab('41 fixture connection created',$created['success'],$created);
C::run('identity021',static function(){O::set_secret(O::SA_JSON,wp_json_encode(['type'=>'service_account','project_id'=>'fixture021','client_email'=>'robot@fixture021.iam.gserviceaccount.com','private_key'=>'private-fixture021','private_key_id'=>str_repeat('f',40)]));});
$list=wp_get_ability('google/list-connections')->execute([]);$by=array_column($list['connections'],null,'connection_id');
verifyLab('41 public identity from saved key',$by['identity021']['client_email']==='robot@fixture021.iam.gserviceaccount.com'&&$by['identity021']['project_id']==='fixture021');
foreach([false,true]as$compact){$r=C::run('identity021',static fn()=>wp_get_ability('google/integration-status')->execute(['compact'=>$compact]));verifyLab('41 integration identity compact '.(int)$compact,$r['client_email']===$by['identity021']['client_email']&&$r['project_id']==='fixture021');}
foreach(['private-fixture021',str_repeat('f',40),'private_key_id','private_key']as$bad)verifyLab('41 saved key material excluded '.strlen($bad),!str_contains(wp_json_encode([$list,$r]),$bad));
verifyLab('41 identity reads perform zero HTTP',!$calls);
C::run('identity021',static fn()=>delete_option(C::option_name(O::SA_JSON)));
$reg=O::get(C::REGISTRY);unset($reg['identity021']);O::set(C::REGISTRY,$reg);
function config021(array $config,array $extra=[]):array{return D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true]+$config]+$extra);}
function verify021(string $target):array{return D::verify(['expected_revision'=>D::revision(),'target'=>$target]);}
function payload021(int $n,array $replace=[]):array{$id=str_pad(dechex($n),32,'a',STR_PAD_LEFT);return array_replace(['record_id'=>$id,'event_id'=>$id,'order_id'=>$id,'occurred_at'=>gmdate('c',time()-60),'click_ids'=>[],'ad_user_data'=>'GRANTED','user_data'=>['email'=>' First.Last@Gmail.com ','telefone'=>'+55 (11) 99999-9999']],$replace);}
$r=config021(['customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789']);verifyLab('39 destination configured',$r['success'],$r);
$r=verify021('google_ads');verifyLab('39 action and customer flags verified',$r['success'],$r);$a=new D('google_ads');$cap=$a->capabilities();
verifyLab('39 capability identifies account action and enhanced readiness',$cap['contract']===D::CONTRACT&&$cap['enhanced_leads']['ready']&&$cap['enhanced_leads']['customer_id']==='1234567890'&&$cap['enhanced_leads']['conversion_action']==='customers/1234567890/conversionActions/789',$cap);
$n=count($calls);$status=wp_get_ability('google/status')->execute(['compact'=>true]);verifyLab('39 status capability matches without new HTTP',$status['conversion_delivery']['google_ads']['enhanced_leads']===$cap['enhanced_leads']&&count($calls)===$n);
foreach([D::LEGACY_CONTRACT,D::CONTRACT] as $v)verifyLab('39 negotiated '.$v,D::adapter(null,'google_ads',$v)->capabilities()['contract']===$v);
if(is_callable(['F3Base_Conversoes_Transporte','capacidade']))verifyLab('39 original Core 1.57.1 still sees ready Google adapter',F3Base_Conversoes_Transporte::capacidade('google_ads')['ready']);
foreach([[],['gclid'=>'synthetic-click'],['gbraid'=>'synthetic-braid'],['wbraid'=>'synthetic-wbraid']] as $i=>$click){
 $p=payload021($i+1,['click_ids'=>$click]);$r=$a->sendBound($p,$cap['destination_ref']);$body=end($sent);$ev=$body['events'][0];
 verifyLab('39 single event receipt pending variant '.$i,$r['status']==='incerto'&&$r['code']==='data_manager_pending'&&count($body['events'])===1,$r);
 verifyLab('39 hashes and encoding variant '.$i,$body['encoding']==='HEX'&&$ev['userData']['userIdentifiers']===[['emailAddress'=>hash('sha256','firstlast@gmail.com')],['phoneNumber'=>hash('sha256','+5511999999999')]]);
 verifyLab('39 click identifiers preserved variant '.$i,($ev['adIdentifiers']??[])===$click);
 $n=count($calls);verifyLab('39 replay does not duplicate variant '.$i,$a->send($p)===$r&&count($calls)===$n);
}
$terms=false;verify021('google_ads');$n=count($calls);$r=$a->send(payload021(10));verifyLab('39 no click rejected with own code on nonready account',$r['code']==='enhanced_leads_not_ready'&&$r['non_delivery_proven']&&count($calls)===$n,$r);
verifyLab('39 missing terms reason visible',$a->capabilities()['enhanced_leads']['reason']==='customer_data_terms_not_accepted');
$p=payload021(11,['click_ids'=>['gclid'=>'legacy-click']]);unset($p['user_data']);$r=$a->send($p);verifyLab('39 old click-only delivery survives disabled enhanced leads',$r['code']==='data_manager_pending'&&!isset(end($sent)['events'][0]['userData']),$r);
$terms=true;$leads=false;verify021('google_ads');verifyLab('39 disabled leads reason visible',$a->capabilities()['enhanced_leads']['reason']==='enhanced_leads_disabled');$leads=true;verify021('google_ads');
foreach([['ad_user_data'=>'DENIED'],['user_data'=>['telefone'=>'11999999999']],['click_ids'=>['gclid'=>'a','gbraid'=>'b']]] as $i=>$bad){$n=count($calls);$r=$a->send(payload021(20+$i,$bad));verifyLab('39 invalid payload refused before HTTP '.$i,$r['status']==='recusado'&&$r['non_delivery_proven']&&count($calls)===$n);}
$stored=wp_json_encode([Audit::recent(200),Records::list('conversion',100),O::get(D::CONFIG)]);
foreach(['First.Last','firstlast@gmail.com','5511999999999',hash('sha256','firstlast@gmail.com'),hash('sha256','+5511999999999')] as $bad)verifyLab('39 PII and hash absent from durable state '.strlen($bad),!str_contains($stored,$bad));
if(class_exists('F3Base_Conversoes_Contexto')){
 $r=config021(['stream'=>'properties/123/dataStreams/456'],['mp_secret'=>$secret]);verifyLab('42 GA4 configured',$r['success'],$r);$r=verify021('ga4');verifyLab('42 initial GA4 verification succeeds',$r['success'],$r);
 $c=O::get(D::CONFIG);$c['verified']['ga4']['expires']=time()-90;$c['renewal']['ga4']['next_attempt']=time()-1;O::set(D::CONFIG,$c);$phase='stream';
 wp_set_current_user(0);$r=D::renew_due();wp_set_current_user(1);verifyLab('42 executor forced renewal fails with stream code',$r['ga4']['code']==='stream_unverified',$r);
 $id=hash('sha256','default|conversion_renewal|ga4');$incident=Records::get('incident',$id);$renew=(new D('ga4'))->capabilities()['renewal'];
 verifyLab('42 renewal incident records phase HTTP status and provider state',$incident['phase']==='ga4_stream_read'&&$incident['provider_error']['http_status']===403&&$incident['provider_error']['status']==='PERMISSION_DENIED',$incident);
 verifyLab('42 renewal history captures executor and downtime',$renew['attempt_count']===1&&$renew['attempts'][0]['origin']==='executor'&&$renew['attempts'][0]['code']==='stream_unverified'&&$renew['unverified_seconds']>=90&&$renew['proof_status']==='expired',$renew);
 $audit=Audit::recent(200);$matching=array_values(array_filter($audit,static fn($e)=>$e['action']==='conversion:verification'&&$e['target']==='ga4'&&($e['extra']['origin']??'')==='executor'));
 verifyLab('42 executor attempt audited with diagnostic',count($matching)>=1&&$matching[0]['extra']['phase']==='ga4_stream_read'&&$matching[0]['extra']['http_status']===403&&$matching[0]['extra']['status']==='error',$matching);
 foreach([$secret,'user@example.test','secret-token',str_repeat('b',64)] as $bad)verifyLab('42 sanitized incident history and audit '.strlen($bad),!str_contains(wp_json_encode([$incident,$renew,$matching]),$bad));
 foreach(['secret'=>'ga4_secret_read','debug'=>'ga4_debug_validation','exception'=>'execution']as$test=>$expect){$phase=$test;$c=O::get(D::CONFIG);$c['renewal']['ga4']['next_attempt']=time()-1;O::set(D::CONFIG,$c);D::renew_due();$renew=(new D('ga4'))->capabilities()['renewal'];verifyLab('42 phase retained '.$test,$renew['phase']===$expect,$renew);}
 $phase='ok';$c=O::get(D::CONFIG);$c['renewal']['ga4']['next_attempt']=time()-1;O::set(D::CONFIG,$c);$r=D::renew_due();$renew=(new D('ga4'))->capabilities()['renewal'];
 verifyLab('42 successful renewal resolves incident and preserves cycle history',$r['ga4']['success']&&Records::get('incident',$id)['status']==='resolved'&&$renew['attempt_count']===5&&$renew['attempts'][4]['code']==='ok'&&$renew['last_unverified_period']['seconds']>=90&&$renew['proof_status']==='valid',$renew);
 verifyLab('42 complete cycle attempt timestamps and audit markers',!array_filter($renew['attempts'],static fn($r)=>!is_int($r['at'])||empty($r['audit_marker'])));
}
// Native capability gates and, when available, the actual MCP decorator/HTTP transport.
$user=wp_create_user('reader021',bin2hex(random_bytes(16)),'reader021@example.invalid');$u=new WP_User($user);$u->set_role('subscriber');wp_set_current_user($user);
foreach(['google/status','google/configuration-schema','google/list-connections','google/integration-status']as$route)verifyLab('021 administrative permission '.$route,wp_get_ability($route)->check_permissions([])!==true);
wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($user);
if(class_exists('Fator3\McpFiles\Persistence')){
 $identity=rpc_identityLab();$auth=$identity['auth'];$r=rpcLab('google/configuration-schema',['compact'=>true,'fields'=>$fields]);verifyLab('40 real MCP HTTP compact three options under 2KB',!empty($r['success'])&&count($r['options'])===3&&strlen(wp_json_encode($r))<2048,['bytes'=>strlen(wp_json_encode($r))]);WP_Application_Passwords::delete_application_password(1,$identity['uuid']);
}
O::set(D::CONFIG,D::defaults());remove_filter('pre_http_request',$fixture,1);
finishLab('requests021',['requests'=>[39,40,41,42],'http'=>'intercepted synthetic provider; no real conversion','core_original'=>defined('F3BASE_PLUGIN_VERSAO')?F3BASE_PLUGIN_VERSAO:null,'provider_attempts'=>count($calls),'real_google'=>'not exercised']);
