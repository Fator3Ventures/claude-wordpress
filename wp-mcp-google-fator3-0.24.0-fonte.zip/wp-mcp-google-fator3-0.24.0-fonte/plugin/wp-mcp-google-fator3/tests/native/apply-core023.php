<?php
require __DIR__.'/common.php';
$source=dirname(__DIR__,2).'/integration/core337-340-342/';
$target=WPMU_PLUGIN_DIR.'/google023-core-consumer';wp_mkdir_p($target);
foreach(['bootstrap.php','class-f3base-google-acervo.php','class-f3base-gsc-consultas.php'] as $file)verifyLab('Copy proposed consumer into owned lab '.$file,copy($source.$file,$target.'/'.$file));
file_put_contents(WPMU_PLUGIN_DIR.'/google023-core-consumer.php',"<?php\n// Synthetic integration harness in owned laboratory only.\nrequire __DIR__.'/google023-core-consumer/bootstrap.php';\n");
verifyLab('Core 1.60 runtime itself remains original',defined('F3BASE_PLUGIN_VERSAO')&&F3BASE_PLUGIN_VERSAO==='1.60.0');
finishLab('apply-core023',['scope'=>'optional proposed Core reader files, loaded before Core and SDK in next process; no Core runtime edits']);
