<?php
require __DIR__.'/common.php';
$base=json_decode(file_get_contents(dirname(__DIR__).'/fixtures/contracts0200-mcp033.json'),true);wp_get_abilities();
$changed=['google/configuration-schema','google/status','google/integration-status','google/conversion-delivery-status','google/configure-conversion-delivery','google/verify-conversion-delivery'];
foreach($base['abilities']as $name=>$old){
 $a=wp_get_ability($name);verifyLab('Existing identity '.$name,$a!==null);
 if(!in_array($name,$changed,true))verifyLab('Unchanged public schemas '.$name,$a->get_input_schema()===$old['input_schema']&&$a->get_output_schema()===$old['output_schema']);
 foreach(['mode','remote_effect','local_effect']as $k)verifyLab('Unchanged effect '.$name.' '.$k,($a->get_meta()['fator3'][$k]??null)===($old['meta']['fator3'][$k]??null));
}
foreach($changed as $name){$a=wp_get_ability($name);$old=$base['abilities'][$name];verifyLab('Existing required fields preserved '.$name,($a->get_input_schema()['required']??[])===($old['input_schema']['required']??[]));verifyLab('Old fields remain '.$name,!array_diff(array_keys($old['input_schema']['properties']),array_keys($a->get_input_schema()['properties'])));}
$all=array_filter(wp_get_abilities(),static fn($a)=>($a->get_meta()['fator3']['provider']??'')==='wp-mcp-google-fator3');verifyLab('290 Google identities',count($all)===290);
verifyLab('38 protected configuration options',count(Fator3\McpGoogle\Configuration::definitions())===38);
verifyLab('Legacy reader unchanged',Fator3\McpGoogle\Integration\ServiceApi::CONTRACT==='search-console-reader/1.0.0');
verifyLab('GA4 reader independent contract',Fator3\McpGoogle\Integration\Ga4ServiceApi::CONTRACT==='ga4-reader/1.0.0');
finishLab('contracts021',['baseline'=>'0.20.0','mcp'=>'0.33.0','additive_or_widened_schemas'=>$changed]);
