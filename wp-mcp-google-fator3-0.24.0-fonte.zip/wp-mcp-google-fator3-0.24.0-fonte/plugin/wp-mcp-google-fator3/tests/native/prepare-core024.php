<?php
require __DIR__.'/common.php';
wp_get_abilities();
$r=F3Base_Instalacao::atualizar();
$s=get_option(F3Base_Instalacao::OPTION,[]);
if(!empty($s['concluido_em'])&&($s['estado']??'')!=='concluida'){
 $s['concluido_em']=time()-61;global $wpdb;$wpdb->update($wpdb->options,['option_value'=>maybe_serialize($s)],['option_name'=>F3Base_Instalacao::OPTION]);wp_cache_delete(F3Base_Instalacao::OPTION,'options');F3Base_Instalacao::atualizar();
}
verifyLab('Original Core 1.61.1 native storage ready',F3BASE_PLUGIN_VERSAO==='1.61.1'&&F3Base_Atualizacao::pronta()&&F3Base_Gsc_Consultas_Acervo::pronta());
verifyLab('Core recovery ready',!empty(F3Base_Recuperacao::ler()['ok'])&&empty(F3Base_Recuperacao::ler()['pausado']),F3Base_Recuperacao::ler());
finishLab('prepare-core024',['clock'=>'Only native Core installation confirmation delay accelerated in owned disposable state']);
