<?php
/** Proposed consumers on original Core 1.60, real Google archive and native permissions. */
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options as O,Connections as C,Settings,Policy,Ads\Archive,Ads\ArchiveStore,Integration\AdsServiceApi as Ads,Integration\QueryServiceApi as Gsc};
wp_get_abilities();get_role('administrator')->add_cap('f3base_ler_leads');wp_set_current_user(0);wp_set_current_user(1);$calls=0;$cost='1000000';$grows=3;$account='1234567890';
$fixture=static function($pre,$args,$url)use(&$calls,&$cost,&$grows,$account){
 if(str_starts_with($url,getenv('F3_LAB_URL').'/'))return $pre;$calls++;
 $i=is_string($args['body']??null)?json_decode($args['body'],true):($args['body']??[]);
 if(str_contains($url,'/token'))$r=['access_token'=>'synthetic-core023','expires_in'=>3600];
 elseif(str_contains($url,'googleAds:search')){
  preg_match("/segments.date = '([0-9-]+)'/",$i['query'],$m);$customer=['id'=>$account,'currencyCode'=>'BRL','timeZone'=>'America/Sao_Paulo'];
  if(!$m)$r=['results'=>[['customer'=>$customer]]];
  else{$row=['customer'=>$customer,'segments'=>['date'=>$m[1]],'campaign'=>['id'=>'1','name'=>'Synthetic'],'metrics'=>['costMicros'=>$cost,'clicks'=>'3','impressions'=>'10','conversions'=>1]];
   if(str_contains($i['query'],'click_view'))$row+=['adGroup'=>['id'=>'2','name'=>'Synthetic'],'clickView'=>['resourceName'=>'customers/'.$account.'/clickViews/'.$m[1].'~exact-gclid-023','gclid'=>'exact-gclid-023','keywordInfo'=>['text'=>'keyword fixture','matchType'=>'EXACT']]];
   $r=['results'=>[$row]];}
 }elseif(str_contains($url,'searchAnalytics/query')){$rows=[];for($n=$i['startRow'];$n<min($grows,$i['startRow']+$i['rowLimit']);$n++)$rows[]=['keys'=>[$i['startDate'],home_url('/fixture'),'synthetic query '.$n],'clicks'=>2,'impressions'=>10,'ctr'=>0.2,'position'=>3];$r=['rows'=>$rows,'responseAggregationType'=>'byPage'];}
 else return new WP_Error('fixture_external_denied','External request blocked.');
 return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($r)];
};add_filter('pre_http_request',$fixture,1,3);
O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::GA_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ads'=>'read','gsc'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic023',O::OAUTH_REFRESH_TOKEN=>'synthetic023',O::ADS_DEVELOPER_TOKEN=>'synthetic023']);
verifyLab('Core proposed options present in actual catalog',isset(F3Base_Options::catalogo()['f3base_google_ads'],F3Base_Options::catalogo()['f3base_gsc_consultas']));
verifyLab('Core proposed abilities registered',wp_get_ability('f3base/google-ads-acervo-ler')!==null&&wp_get_ability('f3base/gsc-consultas-ler')!==null);
update_option(F3Base_Google_Acervo::OPTION,['ativo'=>true,'conexao'=>'default','conta_id'=>$account,'revisao'=>1]);
verifyLab('Core reader configured and SDK discovered',F3Base_Google_Acervo::configuracao()['ready']&&F3Base_Google_Acervo::status()['registrado'],F3Base_Google_Acervo::status());
$end=(new DateTimeImmutable('yesterday',new DateTimeZone('America/Sao_Paulo')))->format('Y-m-d');$start=(new DateTimeImmutable($end))->modify('-29 days')->format('Y-m-d');$query=['de'=>$start,'ate'=>$end,'dataset'=>'campaign'];
$n=$calls;verifyLab('Core ungranted local reader refuses without HTTP',!F3Base_Google_Acervo::consultar($query)['ok']&&$calls===$n);
$r=Archive::configure(['account_id'=>$account,'enabled'=>true,'datasets'=>['campaign','clicks'],'expected_revision'=>Settings::revision()]);verifyLab('Core test explicit collection grant',$r['success'],$r);
$r=Ads::configure(['consumer_id'=>'base-site-core-fator3','account_id'=>$account,'enabled'=>true,'datasets'=>['campaign','clicks'],'expected_revision'=>Settings::revision()]);verifyLab('Core test explicit reader grant',$r['success'],$r);
for($n=0;$n<30;$n++){$d=(new DateTimeImmutable($start))->modify('+'.$n.' days')->format('Y-m-d');$r=Archive::collect(['account_id'=>$account,'dataset'=>'campaign','date'=>$d]);verifyLab('Core day collected '.$n,$r['success']&&$r['state']==='complete',$r);}
$sum=0;$clicks=0;$days=[];$cursor=null;$n=$calls;
do{$r=F3Base_Google_Acervo::consultar($query+($cursor?['cursor'=>$cursor]:[]));verifyLab('Core actual consumer reads daily revision '.count($days),$r['ok']&&$r['moeda']==='BRL'&&$r['cobertura']['archived']&&count($r['linhas'])===1,$r);$days[]=$r['data'];$sum+=(int)$r['linhas'][0]['cost_micros'];$clicks+=(int)$r['linhas'][0]['clicks'];$cursor=$r['proximo_cursor'];}while($cursor&&count($days)<=30);
verifyLab('Core 30 days have correct costs clicks dates and zero supplier calls',count(array_unique($days))===30&&$sum===30000000&&$clicks===90&&$cursor===null&&$calls===$n);
$cost='2500000';$r=Archive::collect(['account_id'=>$account,'dataset'=>'campaign','date'=>$end,'refresh'=>true]);$r=F3Base_Google_Acervo::consultar(['de'=>$end,'ate'=>$end,'dataset'=>'campaign']);verifyLab('Core revisitation replaces rather than adds',count($r['linhas'])===1&&$r['linhas'][0]['cost_micros']==='2500000');
$r=Archive::collect(['account_id'=>$account,'dataset'=>'clicks','date'=>$end]);$r=F3Base_Google_Acervo::consultar(['de'=>$end,'ate'=>$end,'dataset'=>'clicks','gclid'=>'exact-gclid-023']);verifyLab('Core exact GCLID with keyword and no invented term',$r['ok']&&count($r['linhas'])===1&&$r['linhas'][0]['keyword']==='keyword fixture'&&$r['linhas'][0]['search_term']===null);
$r=F3Base_Google_Acervo::consultar(['de'=>$end,'ate'=>$end,'dataset'=>'clicks','gclid'=>'EXACT-gclid-023']);verifyLab('Core does not fuzzy join GCLID',$r['ok']&&$r['linhas']===[]);
$r=F3Base_Google_Acervo::consultar($query);$cur=$r['proximo_cursor'];update_option(F3Base_Google_Acervo::OPTION,['ativo'=>true,'conexao'=>'default','conta_id'=>$account,'revisao'=>2]);verifyLab('Core changed selection invalidates old cursor',!F3Base_Google_Acervo::consultar($query+['cursor'=>$cur])['ok']);
verifyLab('Core monotonic configuration validator rejects rollback',F3Base_Google_Acervo::validar(['ativo'=>true,'conexao'=>'default','conta_id'=>$account,'revisao'=>1])!=='');
update_option('f3base_gsc_property',home_url('/'));$old=F3Base_Options::ler('f3base_gsc');$old['ativo']=true;update_option('f3base_gsc',$old);F3Base_Gsc::validar_propriedade();update_option(F3Base_Gsc_Consultas::OPTION,['ativo'=>true,'revisao'=>1]);
verifyLab('Core query reader independently configured',F3Base_Gsc_Consultas::configuracao()['ready'],F3Base_Gsc_Consultas::configuracao());
$gd=(new DateTimeImmutable('yesterday',new DateTimeZone('America/Los_Angeles')))->format('Y-m-d');$q=['data'=>$gd,'limite'=>2];verifyLab('Core query requires new grant',!F3Base_Gsc_Consultas::consultar($q)['ok']);
$r=Gsc::configure(['contract'=>Gsc::CONTRACT,'consumer_id'=>'base-site-core-fator3','enabled'=>true,'expected_revision'=>Settings::revision()]);verifyLab('Core query explicit grant',$r['success'],$r);
$r=F3Base_Gsc_Consultas::consultar($q);verifyLab('Core query reader preserves query/page/date and coverage',$r['ok']&&count($r['linhas'])===2&&$r['linhas'][0]['query']==='synthetic query 0'&&$r['cliques_anonimizados']===null,$r);$r=F3Base_Gsc_Consultas::consultar($q+['cursor'=>$r['proximo_cursor']]);verifyLab('Core query short page continues to API end',$r['ok']&&count($r['linhas'])===1&&$r['proximo_cursor']!==null);$r=F3Base_Gsc_Consultas::consultar($q+['cursor'=>$r['proximo_cursor']]);verifyLab('Core query final empty page explicit',$r['ok']&&$r['proximo_cursor']===null&&$r['cobertura']['pagination_complete']);
verifyLab('Core legacy GSC contract preserved',F3Base_Gsc::CONTRATO==='search-console-reader/1.0.0');
Ads::configure(['consumer_id'=>'base-site-core-fator3','account_id'=>$account,'enabled'=>false,'expected_revision'=>Settings::revision()]);$n=$calls;verifyLab('Core revoked reader has no HTTP',!F3Base_Google_Acervo::consultar($query)['ok']&&$calls===$n);
wp_set_current_user(0);verifyLab('Core both readers refuse anonymous callers',!F3Base_Google_Acervo::consultar($query)['ok']&&!F3Base_Gsc_Consultas::consultar($q)['ok']);wp_set_current_user(1);
remove_filter('pre_http_request',$fixture,1);O::set(Archive::CONFIG,[]);O::set(Ads::GRANTS,[]);O::set(Gsc::GRANTS,[]);
foreach(['bootstrap.php','class-f3base-google-acervo.php','class-f3base-gsc-consultas.php'] as $file)unlink(WPMU_PLUGIN_DIR.'/google023-core-consumer/'.$file);rmdir(WPMU_PLUGIN_DIR.'/google023-core-consumer');unlink(WPMU_PLUGIN_DIR.'/google023-core-consumer.php');
finishLab('core023',['core_original'=>'1.60.0','proposed_consumers'=>'Core337/340/342 bridge','supplier'=>'synthetic','core_installer_unchanged'=>true]);
