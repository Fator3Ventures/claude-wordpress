<?php
/** Core323: real consumer and producer, synthetic Google transport only. */
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{ConversionDelivery as D,StageConversionDelivery as S,Options as O,Connections as C,Policy,Settings,Records,Audit};
wp_get_abilities();$calls=[];$sent=[];$receipts=[];$terms=true;$leadFlags=true;$status='SUCCESS';$count='1';$actionA='customers/1234567890/conversionActions/222';$actionB='customers/1234567890/conversionActions/333';$acq='customers/1234567890/conversionActions/111';
$fixture=static function($pre,$args,$url)use(&$calls,&$sent,&$receipts,&$terms,&$leadFlags,&$status,&$count){
 if(str_starts_with($url,getenv('F3_LAB_URL').'/'))return $pre;
 $input=is_string($args['body']??null)?json_decode($args['body'],true):($args['body']??[]);$calls[]=[$url,$args['method']??'GET'];
 if(str_contains($url,'/token'))$body=['access_token'=>'synthetic-token022','expires_in'=>3600];
 elseif(str_contains($url,'googleAds:search')){
  preg_match('~/customers/([0-9]+)/~',$url,$customer);
  if(str_contains($input['query']??'','FROM customer'))$body=['results'=>[['customer'=>['id'=>$customer[1],'conversionTrackingSetting'=>['acceptedCustomerDataTerms'=>$terms,'enhancedConversionsForLeadsEnabled'=>$leadFlags]]]]];
  else {preg_match('~customers/[0-9]+/conversionActions/[0-9]+~',$input['query'],$m);$body=['results'=>[['conversionAction'=>['resourceName'=>$m[0],'type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>25.0,'defaultCurrencyCode'=>'USD','alwaysUseDefaultValue'=>false]]]]];}
 }elseif(str_contains($url,'events:ingest')){$sent[]=$input;if(empty($input['validateOnly'])){$rid='stage-request-'.count($receipts);$receipts[$rid]=$input;$body=['requestId'=>$rid];}else $body=[];}
 elseif(str_contains($url,'requestStatus:retrieve')){parse_str(parse_url($url,PHP_URL_QUERY),$query);$body=['requestStatusPerDestination'=>[['destination'=>$receipts[$query['requestId']]['destinations'][0],'requestStatus'=>$status,'eventsIngestionStatus'=>['recordCount'=>$count]]]];}
 else return new WP_Error('fixture_external_denied','External request blocked.');
 return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($body)];
};add_filter('pre_http_request',$fixture,1,3);
O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::GA_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ads'=>'write','ga'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],
 [O::OAUTH_CLIENT_SECRET=>'synthetic022',O::OAUTH_REFRESH_TOKEN=>'synthetic022',O::ADS_DEVELOPER_TOKEN=>'synthetic022']);
O::set(D::CONFIG,D::defaults());
function grant022(string $action,bool $enable=true):array{return S::configure(['expected_revision'=>D::revision(),'action'=>$action,'enabled'=>$enable]);}
function verify022(string $action):array{return S::verify(['expected_revision'=>D::revision(),'action'=>$action]);}
function adapter022(string $action):S{return apply_filters('f3base_conversoes_adaptador',null,'google_ads',S::CONTRACT,['consumer_id'=>S::CONSUMER,'purpose'=>S::PURPOSE,'action'=>$action]);}
function payload022(string $action,string $event):array{return ['contract'=>S::CONTRACT,'purpose'=>'crm_stage','record_id'=>str_repeat('e',32),'stage_id'=>'qualificado','action'=>$action,'event_id'=>$event,'order_id'=>$event,'occurred_at'=>gmdate('c',time()-5),'click_ids'=>['gclid'=>'synthetic-click022'],'ad_user_data'=>'GRANTED','value'=>0,'currency'=>'BRL'];}
function ref022(S $a,string $action):string{return $a->capabilities()['actions'][$action]['destination_ref'];}
function due022(string $ref):void{foreach(Records::list('conversion',1000) as $key=>$row)if(($row['destination_ref']??'')===$ref){$row['next_attempt']=time()-1;Records::put('conversion',$key,$row);}}
$r=D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'customer_id'=>'1234567890','conversion_action'=>$acq]]);verifyLab('323 acquisition configured',$r['success'],$r);
$r=D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads']);verifyLab('323 acquisition verified',$r['success'],$r);
$base=D::adapter(null,'google_ads',D::LEGACY_CONTRACT)->capabilities();verifyLab('323 legacy supported and announces optional contract',$base['contract']===D::LEGACY_CONTRACT&&$base['ready']&&in_array(S::CONTRACT,$base['supported_contracts'],true));
$n=count($calls);$a=adapter022($actionA);$cap=$a->capabilities();verifyLab('323 fourth argument selects commercial object with no inherited grant',$cap['reason']==='stage_grant_missing'&&$cap['acquisition_action']===$acq&&count($calls)===$n,$cap);
verifyLab('323 acquisition action cannot be granted',grant022($acq)['code']==='acquisition_action_reused');
foreach([$actionA,$actionB] as $action){$r=grant022($action);verifyLab('323 independent grant '.basename($action),$r['success'],$r);$r=verify022($action);verifyLab('323 explicit action validation '.basename($action),$r['success']&&$r['verified'],$r);}
$a=adapter022($actionA);$b=adapter022($actionB);$ref=ref022($a,$actionA);$refB=ref022($b,$actionB);verifyLab('323 distinct action references',$ref!==$refB);
$GLOBALS['native022_grantB']=O::get(D::CONFIG)['stage_actions'][$actionB];$cap=$a->capabilities();verifyLab('323 enhanced readiness belongs to selected commercial action',$cap['actions'][$actionA]['enhanced_leads']['ready']&&$cap['actions'][$actionA]['enhanced_leads']['conversion_action']===$actionA);
foreach($sent as $i=>$body)if(($body['destinations'][0]['productDestinationId']??'')!=='111')verifyLab('323 validateOnly fixed zero BRL '.$i,!empty($body['validateOnly'])&&$body['events'][0]['conversionValue']==0&&$body['events'][0]['currency']==='BRL');
$before=O::get(D::CONFIG);$n=count($calls);$s=wp_get_ability('google/stage-conversion-status')->execute([]);verifyLab('323 status is administrative local read',$s['success']&&count($s['actions'])===2&&count($calls)===$n&&O::get(D::CONFIG)===$before);
// Real Core consumer preview, eligibility, reservation, worker and persistent receipts.
$core=class_exists('F3Base_Qualidade_Destinos');$corePatch=$core&&method_exists('F3Base_Qualidade_Destinos','reconciliar_incertos');$leadIds=[];
if($core){
 wp_get_current_user()->add_cap('f3base_ler_leads');verifyLab('323 original Core table installed',F3Base_Qualidade_Destinos::instalar());
 $q=F3Base_Qualidade::padrao();$q['ativo']=true;$q['etapas']=[['id'=>'qualificado','nome'=>'Qualificado','evento_meta'=>''],['id'=>'fechado','nome'=>'Fechado','evento_meta'=>'']];update_option('f3base_qualidade',$q);
 $qc=F3Base_Qualidade_Destinos::padroes();$qc['google_ads']=['ativo'=>true,'acoes'=>['qualificado'=>$actionA,'fechado'=>$actionB]];update_option(F3Base_Qualidade_Destinos::OPTION,$qc);
 function lead022(int $seed,bool $click=true):array {
  global $wpdb;$id=md5('native022-'.$seed);$d=['classe_trafego'=>'nao_marcado','contexto_teste'=>false,'consentimento_snapshot'=>['publicidade'=>true,'politica_versao'=>'legado:'.F3Base_Modulo_Consentimento::politica_versao()],
   'atribuicao'=>$click?['gclid'=>'core-click022','ultimo_toque_em'=>time()-100]:[],'telefone'=>'+5511999999999'];
  $lead=['record_id'=>$id,'captura'=>'aceito','metodo'=>'formulario','classe_trafego'=>'nao_marcado','email'=>'native022@example.test','nome'=>'Synthetic022','criado_em'=>gmdate('Y-m-d H:i:s',time()-60),'lixeira'=>0,'eliminacao_pendente'=>0,'dados'=>$d];
  $ok=$wpdb->insert(F3Base_Leads_Repositorio::tabela(),array_replace($lead,['dados'=>wp_json_encode($d),'payload_hash'=>hash('sha256',$id),'anexos'=>'[]','revisao'=>1,'atualizado_em'=>gmdate('Y-m-d H:i:s')]));verifyLab('323 seed isolated Core contact '.$seed,$ok===1);return $lead;
 }
 $lead=lead022(1);$leadIds[]=$lead['record_id'];$n=count($calls);$rows=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Qualidade_Destinos::tabela());
 $preview=F3Base_Qualidade_Destinos::previa(['record_id'=>$lead['record_id'],'etapa'=>'qualificado']);
 verifyLab('323 real Core preview eligible with original Google producer',!empty($preview['destinos']['google_ads']['elegivel']),$preview);
 verifyLab('323 preview does not enqueue or call provider',$rows===(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Qualidade_Destinos::tabela())&&count($calls)===$n);
 verifyLab('323 preview omits raw personal and click data',!str_contains(wp_json_encode($preview),'native022@example.test')&&!str_contains(wp_json_encode($preview),'core-click022'));
 $bad=$lead;$bad['dados']['consentimento_snapshot']['publicidade']=false;verifyLab('323 Core consent preserved',F3Base_Qualidade_Destinos::preparar($bad,'qualificado','google_ads',time())['codigo']==='consentimento_nao_permite');
 $bad=$lead;$bad['classe_trafego']='teste';verifyLab('323 Core traffic suppression preserved',F3Base_Qualidade_Destinos::preparar($bad,'qualificado','google_ads',time())['codigo']==='trafego_suprimido');
 verifyLab('323 Core stage date bound preserved',F3Base_Qualidade_Destinos::preparar($lead,'qualificado','google_ads',time()-120)['codigo']==='etapa_fora_da_janela');
 $r=F3Base_Qualidade::registrar($lead,'qualificado','pipedrive',time(),'google022-'.$lead['record_id']);verifyLab('323 real Core reserves commercial receipt',$r['ok'],$r);
 F3Base_Execucoes::encerrar();$r=F3Base_Qualidade_Destinos::processar();$row=F3Base_Qualidade_Destinos::ler($lead['record_id'])[0];
 verifyLab('323 original Core records uncertain receipt after ingestion',$r['processados']===1&&$row['estado']==='incerto'&&$row['codigo']==='data_manager_pending',$row);
 $body=end($sent);$ev=$body['events'][0];$event=$ev['transactionId'];
 verifyLab('323 commercial order is stable Core event not contact ID',str_starts_with($event,'f3q-')&&$event!==$lead['record_id']&&$body['destinations'][0]['productDestinationId']==='222');
 verifyLab('323 real Core payload keeps zero BRL and consent',$ev['conversionValue']==0&&$ev['currency']==='BRL'&&$ev['consent']['adUserData']==='CONSENT_GRANTED'&&isset($ev['userData']));
 $n=count($calls);F3Base_Execucoes::encerrar();F3Base_Qualidade_Destinos::processar();verifyLab('323 uncertain Core receipt never reingests',count($calls)===$n);
 F3Base_Qualidade_Destinos::registrar($lead,'qualificado',time());verifyLab('323 stage revisit has one receipt',count(F3Base_Qualidade_Destinos::ler($lead['record_id']))===1);
 $prepared=F3Base_Qualidade_Destinos::preparar($lead,'qualificado','google_ads',(int)$row['ocorreu_em']);verifyLab('323 producer replay also does not ingest',$a->sendBound($prepared['payload'],$ref)['status']==='incerto'&&count($calls)===$n);
 due022($ref);$count='2';$r=$a->reconcileBound($event,$ref);verifyLab('323 mismatched provider record count cannot confirm',$r['status']==='incerto',$r);
 due022($ref);$count='1';$status='PROCESSING';$r=$a->reconcileBound($event,$ref);verifyLab('323 processing remains uncertain',$r['status']==='incerto');
 due022($ref);$status='SUCCESS';$n=count($receipts);$r=$a->reconcileBound($event,$ref);verifyLab('323 exact provider confirmation from query only',$r['status']==='entregue'&&count($receipts)===$n,$r);
 F3Base_Execucoes::encerrar();F3Base_Qualidade_Destinos::processar();verifyLab('323 Core158 lacks commercial reconciliation explicitly observed',F3Base_Qualidade_Destinos::ler($lead['record_id'])[0]['estado']==='incerto');
 if($corePatch){$wpdb->update(F3Base_Qualidade_Destinos::tabela(),['atualizado_em'=>time()-1801],['record_id'=>$lead['record_id']]);$n=count($calls);F3Base_Execucoes::encerrar();$r=F3Base_Qualidade_Destinos::processar();verifyLab('Core patch confirms same receipt without new HTTP or ingestion',$r['reconciliados']===1&&F3Base_Qualidade_Destinos::ler($lead['record_id'])[0]['estado']==='entregue'&&count($calls)===$n);}
 $r=F3Base_Qualidade::registrar($lead,'fechado','pipedrive',time(),'google022-closed-'.$lead['record_id']);F3Base_Execucoes::encerrar();F3Base_Qualidade_Destinos::processar();$ev2=end($sent)['events'][0];
 verifyLab('323 second stage sends separate action and event',$r['ok']&&count(F3Base_Qualidade_Destinos::ler($lead['record_id']))===2&&end($sent)['destinations'][0]['productDestinationId']==='333'&&$ev2['transactionId']!==$event);
 if($corePatch){
  $n=count($receipts);$wpdb->update(F3Base_Qualidade_Destinos::tabela(),['atualizado_em'=>time()-1801],['record_id'=>$lead['record_id'],'etapa'=>'fechado']);due022($refB);$status='PROCESSING';F3Base_Execucoes::encerrar();$r=F3Base_Qualidade_Destinos::processar();verifyLab('Core patch queries pending Google status without reingestion',$r['reconciliados']===1&&count($receipts)===$n&&F3Base_Qualidade_Destinos::ler($lead['record_id'])[1]['estado']==='incerto');
  $http=count($calls);F3Base_Execucoes::encerrar();$r=F3Base_Qualidade_Destinos::processar();verifyLab('Core patch reserves cooldown before query',$r['reconciliados']===0&&count($calls)===$http);
  $wpdb->update(F3Base_Qualidade_Destinos::tabela(),['atualizado_em'=>time()-1801],['record_id'=>$lead['record_id'],'etapa'=>'fechado']);grant022($actionB,false);$http=count($calls);F3Base_Execucoes::encerrar();F3Base_Qualidade_Destinos::processar();verifyLab('Core patch revocation preserves uncertainty and blocks query',F3Base_Qualidade_Destinos::ler($lead['record_id'])[1]['estado']==='incerto'&&count($calls)===$http);
  // Restore the exact pre-revocation grant only inside this disposable fixture, preserving its original receipt binding.
  $stored=O::get(D::CONFIG);$stored['stage_actions'][$actionB]=$GLOBALS['native022_grantB'];$stored['stage_actions'][$actionB]['proof']['expires']=time()-1;O::set(D::CONFIG,$stored);
  $wpdb->update(F3Base_Qualidade_Destinos::tabela(),['atualizado_em'=>time()-1801],['record_id'=>$lead['record_id'],'etapa'=>'fechado']);due022($refB);$status='SUCCESS';F3Base_Execucoes::encerrar();$r=F3Base_Qualidade_Destinos::processar();verifyLab('Core patch confirms exact Google receipt despite expired send proof',$r['reconciliados']===1&&F3Base_Qualidade_Destinos::ler($lead['record_id'])[1]['estado']==='entregue'&&count($receipts)===$n);
 }
 $without=lead022(2,false);$leadIds[]=$without['record_id'];$p=F3Base_Qualidade_Destinos::preparar($without,'qualificado','google_ads',time());verifyLab('323 real Core no click uses enhanced capability of stage',$p['ok']&&empty($p['payload']['click_ids'])&&!empty($p['payload']['user_data']),$p['codigo']);
 F3Base_Qualidade::registrar($without,'qualificado','pipedrive',time(),'google022-noclick-'.$without['record_id']);F3Base_Execucoes::encerrar();F3Base_Qualidade_Destinos::processar();verifyLab('323 no click stage uses userData only',isset(end($sent)['events'][0]['userData'])&&!isset(end($sent)['events'][0]['adIdentifiers']));
 $revoked=lead022(3);$leadIds[]=$revoked['record_id'];F3Base_Qualidade::registrar($revoked,'qualificado','pipedrive',time(),'google022-revoke-'.$revoked['record_id']);grant022($actionA,false);$n=count($calls);F3Base_Execucoes::encerrar();F3Base_Qualidade_Destinos::processar();$blocked=F3Base_Qualidade_Destinos::ler($revoked['record_id'])[0];verifyLab('323 revocation after reservation blocks original Core worker',$blocked['estado']==='bloqueado'&&count($calls)===$n,$blocked);
 grant022($actionA);verify022($actionA);verifyLab('323 regrant changes destination generation',ref022($a,$actionA)!==$ref);$n=count($calls);verifyLab('323 old bound destination cannot be sent after regrant',$a->sendBound($prepared['payload'],$ref)['non_delivery_proven']&&count($calls)===$n);
 $n=count($calls);$newref=ref022($a,$actionA);$r=$a->sendBound($prepared['payload'],$newref);verifyLab('323 old event cannot reingest under new grant',$r['status']==='incerto'&&count($calls)===$n,$r);
}else verifyLab('323 isolated producer does not require Core',!class_exists('F3Base_Qualidade_Destinos'));
$ref=ref022($a,$actionA);$terms=false;verify022($actionA);$n=count($calls);$payload=payload022($actionA,'noready022');$payload['click_ids']=[];$payload['user_data']=['email'=>'synthetic022@example.test'];$r=$a->sendBound($payload,$ref);verifyLab('323 no click nonready action refuses without HTTP',$r['code']==='enhanced_leads_not_ready'&&count($calls)===$n,$r);
$terms=true;verify022($actionA);
$snapshot=O::get(D::CONFIG);$r=D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'customer_id'=>'1234567890','conversion_action'=>$actionA]]);$n=count($calls);verifyLab('323 acquisition changed to stage fails closed',$a->capabilities()['reason']==='acquisition_action_reused'&&$a->sendBound(payload022($actionA,'reused022'),$ref)['non_delivery_proven']&&count($calls)===$n);O::set(D::CONFIG,$snapshot);
$persist=wp_json_encode([O::get(D::CONFIG),Records::list('conversion',1000),Audit::recent(1000)]);foreach(['native022@example.test','core-click022',hash('sha256','native022@example.test'),hash('sha256','+5511999999999')] as $i=>$bad)verifyLab('323 personal input absent from Google persisted state '.$i,!str_contains($persist,$bad));
require_once ABSPATH.'wp-admin/includes/template.php';$_GET=['section'=>'conversions'];$_SERVER['REQUEST_METHOD']='GET';ob_start();Fator3\McpGoogle\Admin::render();$html=ob_get_clean();verifyLab('323 panel has separate grant and verify controls',str_contains($html,'id="f3-commercial-actions"')&&str_contains($html,'name="stage_enabled"')&&str_contains($html,'value="stage-verify"'));
if(class_exists('Fator3\McpFiles\Persistence')){$credential=rpc_identityLab();$auth=$credential['auth'];$r=rpcLab('google/stage-conversion-status');verifyLab('323 new status through authenticated MCP HTTP',!empty($r['success'])&&$r['contract']===S::CONTRACT,$r);WP_Application_Passwords::delete_application_password(1,$credential['uuid']);}
wp_set_current_user(0);verifyLab('323 anonymous administrative status refused',empty(S::status()['success']));wp_set_current_user(1);
if($core){foreach($leadIds as $id){$wpdb->delete(F3Base_Qualidade_Destinos::tabela(),['record_id'=>$id]);$wpdb->delete(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id]);}update_option('f3base_qualidade',F3Base_Qualidade::padrao());update_option(F3Base_Qualidade_Destinos::OPTION,F3Base_Qualidade_Destinos::padroes());}
O::set(D::CONFIG,D::defaults());remove_filter('pre_http_request',$fixture,1);
finishLab('requests022',['request'=>'Core323','core_consumer'=>$core?($corePatch?'1.58.0 plus proposed reconciliation patch':'original1.58.0'):'absent','google_provider'=>'real plugin; HTTP intercepted','core_commercial_reconciliation'=>$corePatch?'patched consumer proven':'not implemented in1.58.0; producer query proven','real_google'=>'not exercised']);
