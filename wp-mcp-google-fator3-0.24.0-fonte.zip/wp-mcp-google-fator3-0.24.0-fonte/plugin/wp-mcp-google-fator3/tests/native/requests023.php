<?php
/** Requests Google 43–46: real WordPress/MySQL, only supplier HTTP is synthetic. */
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options as O,Connections as C,Settings,Policy,Auth\Configuration as AuthConfig,Auth\ServiceAccount,Auth\Candidate,Ads\Archive,Ads\ArchiveQuery,Ads\ArchiveStore,Integration\AdsServiceApi as Ads,Integration\QueryServiceApi as Gsc,Integration\ServiceApi as Legacy,Storage\Repository,Auth\Credentials,Recovery};
wp_get_abilities();$calls=[];$rejectSa=true;$phase='normal';$amount='1200000';$pages=2;$gscRows=2;$revoke=false;$gscRevoke=false;
$account='1234567890';$day=(new DateTimeImmutable('yesterday',new DateTimeZone('America/Sao_Paulo')))->format('Y-m-d');
$fixture=static function($pre,$args,$url)use(&$calls,&$rejectSa,&$phase,&$amount,&$pages,&$gscRows,&$revoke,&$gscRevoke,$account,$day){
 if(str_starts_with($url,getenv('F3_LAB_URL').'/'))return $pre;
 $body=is_string($args['body']??null)?json_decode($args['body'],true):($args['body']??[]);$calls[]=['url'=>$url,'body'=>$body];
 if(str_contains($url,'oauth2.googleapis.com/')){
  if(isset($body['assertion'])&&$rejectSa)return ['response'=>['code'=>400],'headers'=>[],'body'=>wp_json_encode(['error'=>'invalid_grant','error_description'=>'Synthetic credential refused'])];
  $out=['access_token'=>'synthetic023','expires_in'=>3600];
 }elseif(str_contains($url,'googleAds:search')){
  $q=$body['query'];preg_match('~/customers/(\d+)/~',$url,$m);$a=$m[1];
  if(str_contains($q,'FROM customer LIMIT 1'))$out=['results'=>[['customer'=>['id'=>$a,'currencyCode'=>'BRL','timeZone'=>'America/Sao_Paulo','manager'=>false]]]];
  else {
   preg_match("/segments.date = '([0-9-]+)'/",$q,$d);$date=$d[1]??$day;
   $row=['customer'=>['id'=>$a,'currencyCode'=>'BRL','timeZone'=>'America/Sao_Paulo'],'segments'=>['date'=>$date,'adNetworkType'=>'SEARCH','device'=>'MOBILE'],'campaign'=>['id'=>'11','name'=>'Synthetic campaign'],'adGroup'=>['id'=>'22','name'=>'Synthetic ad group'],'adGroupAd'=>['ad'=>['id'=>'33']],'metrics'=>['costMicros'=>$amount,'clicks'=>'12','impressions'=>'120','conversions'=>1.5],'searchTermView'=>['searchTerm'=>'synthetic search term']];
   if(str_contains($q,'FROM click_view')){$n=isset($body['pageToken'])?2:1;$row['clickView']=['resourceName'=>'customers/'.$a.'/clickViews/'.$date.'~synthetic-gclid-'.$n,'gclid'=>'synthetic-gclid-'.$n,'adGroupAd'=>'customers/'.$a.'/adGroupAds/22~33','keyword'=>'customers/'.$a.'/adGroupCriteria/22~44','keywordInfo'=>['text'=>'synthetic keyword','matchType'=>'EXACT']];}
   if(str_contains($q,'FROM change_event')){
    preg_match("/change_event.change_date_time >= '([^']+)'/",$q,$lo);$date=substr($lo[1],0,10);$change=['changeEvent'=>['resourceName'=>'customers/'.$a.'/changeEvents/synthetic-'.substr($lo[1],11),'changeDateTime'=>$lo[1],'changeResourceName'=>'customers/'.$a.'/campaignBudgets/7','changeResourceType'=>'CAMPAIGN_BUDGET','resourceChangeOperation'=>'UPDATE','changedFields'=>'amount_micros','oldResource'=>['campaignBudget'=>['amountMicros'=>'1000000']],'newResource'=>['campaignBudget'=>['amountMicros'=>'2000000']],'userEmail'=>'synthetic@example.test','clientType'=>'GOOGLE_ADS_WEB_CLIENT']];
    $out=['results'=>[$change]];
    if($phase==='split'&&str_contains($q,$date." 00:00:00' AND change_event.change_date_time < '".(new DateTimeImmutable($date))->modify('+1 day')->format('Y-m-d')." 00:00:00'"))$out=['results'=>array_fill(0,10000,$change)];
    if($phase==='second-limit')$out=['results'=>array_fill(0,10000,$change)];
   }else {$out=['results'=>[$row]];if(str_contains($q,'FROM click_view')&&$pages===2&&!isset($body['pageToken']))$out['nextPageToken']='synthetic-next023';}
   if($phase==='empty')$out=[];
   if($phase==='bad-account')$out['results'][0]['customer']['id']='9999999999';
   if($phase==='repeat-token')$out['nextPageToken']='synthetic-next023';
   if($revoke){$cfg=Archive::config();$cfg[$a]['enabled']=false;O::set(Archive::CONFIG,$cfg);$revoke=false;}
  }
 }elseif(str_contains($url,'searchAnalytics/query')){
  $rs=[];$start=$body['startRow'];for($n=$start;$n<min($gscRows,$start+$body['rowLimit']);$n++){$keys=[$body['startDate'],home_url('/synthetic-'.$n)];if(count($body['dimensions'])===3)$keys[]='synthetic query '.$n;$rs[]=['keys'=>$keys,'clicks'=>2,'impressions'=>10,'ctr'=>0.2,'position'=>3];}
  $out=['rows'=>$rs,'responseAggregationType'=>'byPage'];
  if($gscRevoke){O::set(Gsc::GRANTS,[]);$gscRevoke=false;}
 }else return new WP_Error('fixture_external_denied','External request blocked.');
 return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($out)];
};add_filter('pre_http_request',$fixture,1,3);
O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::GA_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ads'=>'read','ga'=>'read','gsc'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic023',O::OAUTH_REFRESH_TOKEN=>'synthetic023',O::ADS_DEVELOPER_TOKEN=>'synthetic023']);
// 43: only structure/host/cryptographic readability block local input.
$key=openssl_pkey_new(['private_key_bits'=>2048,'private_key_type'=>OPENSSL_KEYTYPE_RSA]);openssl_pkey_export($key,$pem);
$sa=['type'=>'service_account','client_email'=>'synthetic@example.test','project_id'=>'','private_key_id'=>'atypical','private_key'=>$pem,'token_uri'=>ServiceAccount::DEFAULT_TOKEN_URI];
verifyLab('43 atypical identity reaches validation',is_array(ServiceAccount::validate_key(wp_json_encode($sa),true)));
verifyLab('43 stable warning codes',array_column(ServiceAccount::warnings($sa),'code')===['f3_google_sa_format_project_id','f3_google_sa_format_private_key_id','f3_google_sa_format_client_email']);
$before=O::get_secret(O::SA_JSON);$candidate=Candidate::read('service_account');$n=count($calls);$r=AuthConfig::save_sa(wp_json_encode($sa),null,false,Settings::revision());
verifyLab('43 remote refusal preserves active and candidate',empty($r['success'])&&$r['error_code']==='f3_google_credential_rejected'&&count($calls)===$n+1&&O::get_secret(O::SA_JSON)===$before&&Candidate::read('service_account')===$candidate,$r);
verifyLab('43 rejection includes warnings',count($r['warnings'])===3&&$r['active_preserved']);
foreach(['private_key','client_email','token_uri'] as $field){$bad=$sa;unset($bad[$field]);$n=count($calls);$r=AuthConfig::save_sa(wp_json_encode($bad));verifyLab('43 required field '.$field,is_wp_error(ServiceAccount::validate_key(wp_json_encode($bad),true))&&empty($r['success'])&&count($calls)===$n);}
foreach(['https://evil.example/token','https://oauth2.googleapis.com.evil.example/token','https://oauth2.googleapis.com@evil.example/token','http://oauth2.googleapis.com/token'] as $url){$bad=$sa;$bad['token_uri']=$url;verifyLab('43 JWT host guard '.hash('sha256',$url),is_wp_error(ServiceAccount::validate_key(wp_json_encode($bad),true)));}
$bad=$sa;$bad['private_key']='unreadable';verifyLab('43 unreadable PEM remains blocked',is_wp_error(ServiceAccount::validate_key(wp_json_encode($bad),true)));
verifyLab('43 nonJSON and OAuth client blocked',is_wp_error(ServiceAccount::validate_key('{bad',true))&&str_contains(ServiceAccount::validate_key('{"web":{}}',true)->get_error_message(),'OAuth'));
$rejectSa=false;$r=AuthConfig::save_sa(wp_json_encode($sa),null,false,Settings::revision());verifyLab('43 remote acceptance prepares candidate with warnings',$r['success']&&count($r['warnings'])===3&&O::get_secret(O::SA_JSON)===$before,$r);O::delete(Candidate::SA);
// 44/45: account grant, resumable encrypted publication and local SDK.
$cfg=['account_ids'=>[$account],'revision'=>'core023-1','ready'=>true];$client=Ads::register_consumer('native-google023','1.0.0',Ads::CONTRACT,static function()use(&$cfg){return $cfg;});
$input=['contract_version'=>'1.0.0','connection_id'=>'default','account_id'=>$account,'dataset'=>'clicks','date'=>$day,'consumer_revision'=>$cfg['revision'],'limit'=>1];
$n=count($calls);verifyLab('44 SDK ungranted blocks locally',empty($client->query($input)['success'])&&count($calls)===$n);
$r=Archive::configure(['account_id'=>$account,'enabled'=>true,'datasets'=>ArchiveQuery::DATASETS,'backfill_days'=>90,'revisit_days'=>7,'expected_revision'=>Settings::revision()]);verifyLab('44 explicit account metadata and collection grant',$r['success']&&Archive::config()[$account]['currency']==='BRL',$r);
$r=Ads::configure(['consumer_id'=>'native-google023','account_id'=>$account,'enabled'=>true,'datasets'=>ArchiveQuery::DATASETS,'expected_revision'=>Settings::revision()]);verifyLab('44 separate read grant',$r['success'],$r);
$n=count($calls);$r=$client->query($input);verifyLab('44 uncollected date is unknown, not zero',$r['success']&&$r['coverage']['archive_state']==='not_collected'&&$r['coverage']['archived']===false&&!$r['coverage']['pagination_complete']&&count($calls)===$n,$r);
$r=Archive::collect(['account_id'=>$account,'dataset'=>'clicks','date'=>$day]);verifyLab('44 first page persists without publishing',$r['success']&&$r['state']==='pending'&&ArchiveStore::latest($account,'clicks',$day)===null,$r);
$pending=$client->query($input);verifyLab('Core1.61 request incomplete differs from not collected',$pending['success']&&$pending['coverage']['archive_state']==='incomplete'&&$pending['coverage']['latest_collection_state']==='fetch'&&!$pending['coverage']['archived']);
$r=Archive::collect(['account_id'=>$account,'dataset'=>'clicks','date'=>$day]);verifyLab('44 continuation publishes both click pages',$r['success']&&$r['rows']===2&&$r['published'],$r);
$n=count($calls);$first=$client->query($input);$second=$client->query($input+['cursor'=>$first['next_cursor']]);verifyLab('44 local cursor returns each GCLID once',$first['rows'][0]['gclid']==='synthetic-gclid-1'&&$second['rows'][0]['gclid']==='synthetic-gclid-2'&&$second['next_cursor']===null&&count($calls)===$n);
verifyLab('44 no fabricated per-click search term',$first['rows'][0]['search_term']===null&&$first['rows'][0]['keyword']==='synthetic keyword'&&$first['rows'][0]['match_type']==='EXACT');
$raw=$wpdb->get_results("SELECT payload FROM ".Repository::table()." WHERE kind IN ('adsrows','adsjob','adssnapshot')",ARRAY_A);verifyLab('44 click identifiers encrypted at rest',!str_contains(wp_json_encode($raw),'synthetic-gclid')&&!str_contains(wp_json_encode($raw),'synthetic-next023'));
$n=count($calls);$r=Archive::collect(['account_id'=>$account,'dataset'=>'clicks','date'=>$day]);verifyLab('44 completed collection does not repeat HTTP',$r['success']&&$r['reused']&&count($calls)===$n);
$bad=$input;$bad['account_id']='9999999999';$bad['cursor']=$first['next_cursor'];verifyLab('44 account grant isolation',empty($client->query($bad)['success']));
$bad=$input;$bad['limit']=2;$bad['cursor']=$first['next_cursor'];verifyLab('44 cursor binds query limit',empty($client->query($bad)['success']));
foreach(['customer','campaign','ad_group','ad','search_terms','changes'] as $ds){$r=Archive::collect(['account_id'=>$account,'dataset'=>$ds,'date'=>$day]);verifyLab('45 collect '.$ds,$r['success']&&$r['state']==='complete',$r);$q=$input;$q['dataset']=$ds;$r=$client->query($q);verifyLab('45 local data '.$ds,$r['success']&&count($r['rows'])===1&&$r['rows'][0]['currency']==='BRL',$r);if($ds==='changes')verifyLab('45 budget history keeps old new and author',$r['rows'][0]['old']['campaignBudget']['amountMicros']==='1000000'&&$r['rows'][0]['new']['campaignBudget']['amountMicros']==='2000000'&&$r['rows'][0]['author']==='synthetic@example.test');}
$old=ArchiveStore::latest($account,'campaign',$day);$amount='2300000';$r=Archive::collect(['account_id'=>$account,'dataset'=>'campaign','date'=>$day,'refresh'=>true]);$q=$input;$q['dataset']='campaign';$r=$client->query($q);verifyLab('45 revisit replaces totals and retains old revision',$r['rows'][0]['cost_micros']===$amount&&$r['revision']!==$old['revision']&&is_array(ArchiveStore::get('adssnapshot',$old['revision'])));
$pages=1;$r=Archive::collect(['account_id'=>$account,'dataset'=>'clicks','date'=>$day,'refresh'=>true]);verifyLab('44 old cursor invalid after revisitation',empty($client->query($input+['cursor'=>$first['next_cursor']])['success']));
$old=ArchiveStore::latest($account,'campaign',$day);$phase='bad-account';$r=Archive::collect(['account_id'=>$account,'dataset'=>'campaign','date'=>$day,'refresh'=>true]);verifyLab('45 malformed account response preserves complete revision',empty($r['success'])&&ArchiveStore::latest($account,'campaign',$day)['revision']===$old['revision']);$phase='normal';
$cfg['revision']='core023-2';$n=count($calls);verifyLab('44 consumer revision change denies without HTTP',empty($client->query($input)['success'])&&count($calls)===$n);$cfg['revision']='core023-1';
$g=Ads::grants();$r=Ads::configure(['consumer_id'=>'native-google023','account_id'=>$account,'enabled'=>false,'expected_revision'=>Settings::revision()]);$n=count($calls);verifyLab('44 read revoke blocks locally',$r['success']&&empty($client->query($input)['success'])&&count($calls)===$n);O::set(Ads::GRANTS,$g);
$original=Archive::config();$revoke=true;$r=Archive::collect(['account_id'=>$account,'dataset'=>'customer','date'=>$day,'refresh'=>true]);verifyLab('44 revocation during HTTP fences persistence',empty($r['success'])&&$r['error_code']==='f3_google_archive_paused');O::set(Archive::CONFIG,$original);
$phase='split';$r=Archive::collect(['account_id'=>$account,'dataset'=>'changes','date'=>$day,'refresh'=>true]);verifyLab('45 10000 limit splits rather than declaring complete',$r['success']&&$r['state']==='pending',$r);for($i=0;$i<3&&$r['state']==='pending';$i++)$r=Archive::collect(['account_id'=>$account,'dataset'=>'changes','date'=>$day]);verifyLab('45 disjoint change windows merge without cap duplicate',$r['success']&&$r['state']==='complete'&&$r['rows']===2&&!$r['coverage']['truncated'],$r);$phase='normal';
$old=ArchiveStore::latest($account,'changes',$day);$id=ArchiveStore::key($account,'changes',$day);$job=ArchiveStore::get('adsjob',$id);$job['state']='fetch';$job['revision']=bin2hex(random_bytes(16));$job['ranges']=[[36000,36001]];$job['chunks']=[];$job['rows']=0;$job['pages']=0;$job['token']='';$job['window_rows']=0;$job['window_chunks']=[];ArchiveStore::put('adsjob',$id,$job);$phase='second-limit';$r=Archive::collect(['account_id'=>$account,'dataset'=>'changes','date'=>$day]);verifyLab('45 indivisible cap reported without replacing complete view',$r['success']&&$r['coverage']['truncated']&&!$r['published']&&ArchiveStore::latest($account,'changes',$day)['revision']===$old['revision'],$r);$phase='normal';
$q=$input;$q['dataset']='changes';$kept=$client->query($q);verifyLab('Core1.61 partial revisit exposes preserved complete revision',$kept['success']&&$kept['coverage']['archive_state']==='published'&&$kept['coverage']['previous_complete_preserved']&&$kept['coverage']['latest_collection_truncated']);
foreach(['clicks'=>91,'changes'=>30,'campaign'=>1200] as $ds=>$days){$n=count($calls);$date=(new DateTimeImmutable($day))->modify('-'.$days.' days')->format('Y-m-d');$r=Archive::collect(['account_id'=>$account,'dataset'=>$ds,'date'=>$date]);verifyLab('44/45 provider window '.$ds,empty($r['success'])&&count($calls)===$n);}
// Automatic worker: failed slices defer, other datasets advance, retry resumes durably.
$r=Archive::configure(['account_id'=>$account,'enabled'=>true,'datasets'=>['customer','campaign'],'backfill_days'=>2,'revisit_days'=>1,'expected_revision'=>Settings::revision()]);
verifyLab('44 automatic agenda is present',$r['success']&&Fator3\McpGoogle\Automation\ExecutorSchedule::status()['state']==='present');
$backday=(new DateTimeImmutable($day))->modify('-1 day')->format('Y-m-d');$phase='bad-account';wp_set_current_user(0);Archive::cron();
$pid=ArchiveStore::key($account,'plan','');$plan=ArchiveStore::get('adsplan',$pid);
verifyLab('44 cron restores anonymous actor and defers failed slice',get_current_user_id()===0&&!empty($plan['deferred']['customer|'.$backday])&&empty($plan['working']));
$phase='normal';Archive::cron();verifyLab('44 failed customer does not starve campaign',is_array(ArchiveStore::latest($account,'campaign',$backday))&&get_current_user_id()===0);
$plan=ArchiveStore::get('adsplan',$pid);$plan['deferred']['customer|'.$backday]['retry_at']=time()-1;ArchiveStore::put('adsplan',$pid,$plan);Archive::cron();
verifyLab('44 deferred backfill resumes without losing day',is_array(ArchiveStore::latest($account,'customer',$backday))&&empty(ArchiveStore::get('adsplan',$pid)['deferred']));wp_set_current_user(1);
$beforeCalls=count($calls);$ac=Archive::config();$ac[$account]['enabled']=false;O::set(Archive::CONFIG,$ac);wp_set_current_user(0);Archive::cron();verifyLab('44 paused account does no cron HTTP',count($calls)===$beforeCalls&&get_current_user_id()===0);wp_set_current_user(1);O::set(Archive::CONFIG,$original);
// 46: independent grant, full continuation to API end, legacy contract retained.
$gcfg=['property'=>home_url('/'),'revision'=>'gsc023-1','ready'=>true];$gclient=Gsc::register_consumer('native-google023','1.0.0',Gsc::CONTRACT,static function()use(&$gcfg){return $gcfg;});$lclient=Legacy::register_consumer('native-google023','1.0.0',Legacy::CONTRACT,static function()use(&$gcfg){return $gcfg;});
$gi=['contract_version'=>'1.1.0','property'=>$gcfg['property'],'consumer_revision'=>$gcfg['revision'],'date'=>(new DateTimeImmutable('yesterday',new DateTimeZone('America/Los_Angeles')))->format('Y-m-d'),'run_id'=>'native023','trigger'=>'cli','budget_ms'=>20000,'limit'=>1];
Legacy::configure(['consumer_id'=>'native-google023','enabled'=>true,'expected_revision'=>Settings::revision()]);$n=count($calls);verifyLab('46 legacy grant does not authorize query capability',empty($gclient->query($gi)['success'])&&count($calls)===$n);
$r=Legacy::configure(['contract'=>Gsc::CONTRACT,'consumer_id'=>'native-google023','enabled'=>true,'expected_revision'=>Settings::revision()]);verifyLab('46 new capability explicitly granted',$r['success'],$r);
$grantBefore=O::get(Gsc::GRANTS);Legacy::configure(['contract'=>Gsc::CONTRACT,'consumer_id'=>'native-google023','enabled'=>true,'expected_revision'=>Settings::revision()]);verifyLab('46 repeating identical grant preserves cursor revision',O::get(Gsc::GRANTS)===$grantBefore);
$a=$gclient->query($gi);$b=$gclient->query($gi+['cursor'=>$a['next_cursor']]);$z=$gclient->query($gi+['cursor'=>$b['next_cursor']]);
verifyLab('46 exact dimensions and returned query',$a['success']&&$a['coverage']['dimensions']===['date','page','query']&&$a['rows'][0]['query']==='synthetic query 0',$a);
verifyLab('46 pagination reaches empty API end',$b['rows'][0]['query']==='synthetic query 1'&&$z['rows']===[]&&$z['next_cursor']===null&&$z['coverage']['pagination_complete']&&!$z['coverage']['truncated']);
verifyLab('46 anonymization reported without invented counts',$z['coverage']['anonymous_queries_excluded']&&$z['coverage']['anonymous_query_clicks']===null&&$z['coverage']['anonymous_query_count']===null&&!$z['coverage']['all_rows_guaranteed']);
$li=$gi;$li['contract_version']='1.0.0';$r=$lclient->query($li);verifyLab('46 legacy 1.0 remains page-day',$r['success']&&$r['coverage']['dimensions']===['date','page']&&!isset($r['rows'][0]['query']));
$bad=$li;$bad['cursor']=$a['next_cursor'];verifyLab('46 query cursor cannot enter legacy reader',empty($lclient->query($bad)['success']));
$gscRevoke=true;$r=$gclient->query($gi);verifyLab('46 revoke during request discards results',empty($r['success'])&&empty($r['rows']));
// Local diagnostics and UI never collect.
$n=count($calls);Archive::status();Ads::capabilities();Gsc::capabilities();verifyLab('44/46 capabilities and status have no HTTP',count($calls)===$n);
require_once ABSPATH.'wp-admin/includes/template.php';$_GET=['section'=>'archive'];$_POST=[];$_SERVER['REQUEST_METHOD']='GET';ob_start();Fator3\McpGoogle\Admin::render();$html=ob_get_clean();verifyLab('44 accessible native collection and separate reader controls',str_contains($html,'id="f3-ads-archive"')&&str_contains($html,'archive_datasets[]')&&str_contains($html,'value="reader"'));
wp_set_current_user(0);$n=count($calls);verifyLab('43/44 anonymous cannot configure or collect',empty(Archive::configure(['account_id'=>$account,'enabled'=>false,'expected_revision'=>'x'])['success'])&&empty(Archive::collect(['account_id'=>$account,'dataset'=>'clicks','date'=>$day])['success'])&&empty(AuthConfig::save_sa(wp_json_encode($sa))['success'])&&count($calls)===$n);wp_set_current_user(1);
// Only own fixture grants are removed; the disposable database remains evidence-bound.
O::set(Archive::CONFIG,[]);O::set(Ads::GRANTS,[]);O::set(Gsc::GRANTS,[]);remove_filter('pre_http_request',$fixture,1);
finishLab('requests023',['requests'=>[43,44,45,46],'supplier'=>'synthetic HTTP only','real_accounts'=>'not exercised']);
