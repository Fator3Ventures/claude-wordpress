<?php
require __DIR__.'/common.php';
$root=dirname(__DIR__,2).'/integration/core323/';$identity=json_decode(file_get_contents($root.'identity.json'),true);
$target=WP_PLUGIN_DIR.'/base-site-core-fator3/includes/class-f3base-qualidade-destinos.php';
verifyLab('Core patch exact original baseline',hash_file('sha256',$target)===$identity['base_file_sha256']);
verifyLab('Core patch proposed file identity',hash_file('sha256',$root.'class-f3base-qualidade-destinos.php')===$identity['patched_file_sha256']);
verifyLab('Core patch installed only in disposable laboratory',copy($root.'class-f3base-qualidade-destinos.php',$target));
finishLab('apply-core022',['scope'=>'proposed patch; not original companion and not remote deployment']);
