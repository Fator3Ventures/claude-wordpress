<?php
require __DIR__.'/common.php';wp_get_abilities();
$cat=F3Base_Options::catalogo();$before=[get_option('f3base_google_ads'),get_option('f3base_google_ads_acervo'),get_option('f3base_gsc_consultas')];
verifyLab('Conversion and archive configurations remain independent',isset($cat['f3base_google_ads'],$cat['f3base_google_ads_acervo'])&&F3Base_Google_Acervo::OPTION==='f3base_google_ads_acervo');
$refs=[(new ReflectionClass('F3Base_Google_Acervo'))->getFileName(),(new ReflectionClass('F3Base_Gsc_Consultas'))->getFileName()];
$hooks=[$GLOBALS['wp_filter']['f3_mcp_google_register_ads_consumers']->callbacks,$GLOBALS['wp_filter']['f3_mcp_google_register_consumers']->callbacks];
require dirname(__DIR__,2).'/integration/core337-340-342/bootstrap.php';
verifyLab('Retired source bootstrap preserves native classes and hooks',$refs===[(new ReflectionClass('F3Base_Google_Acervo'))->getFileName(),(new ReflectionClass('F3Base_Gsc_Consultas'))->getFileName()]&&$hooks===[$GLOBALS['wp_filter']['f3_mcp_google_register_ads_consumers']->callbacks,$GLOBALS['wp_filter']['f3_mcp_google_register_consumers']->callbacks]);
verifyLab('Retired bootstrap preserves conversion reader and GSC options',$before===[get_option('f3base_google_ads'),get_option('f3base_google_ads_acervo'),get_option('f3base_gsc_consultas')]);
foreach(['google-ads-acervo-status','google-ads-acervo-ler','gsc-consultas-status','gsc-historico','gsc-consultas-coletar','anuncios-alteracoes-ler','relatorios-integrados-ler'] as $id)verifyLab('Documented Core route exists '.$id,wp_get_ability('f3base/'.$id)!==null);
$docs=Fator3\McpGoogle\Documentation::read(['document'=>'CORE-ACERVOS.md']);verifyLab('Installed Core guide identifies corrected option and distinct conversion option',$docs['success']&&str_contains($docs['content'],'`f3base_google_ads_acervo`')&&str_contains($docs['content'],'`f3base_google_ads`')&&str_contains($docs['content'],'Core 1.61.1'));
foreach(['f3base_google_ads_acervo','f3base_gsc_consultas'] as $name){$r=wp_get_ability('f3base/config-core-ler')->execute(['nome'=>$name]);verifyLab('Documented Core configuration read '.$name,!is_wp_error($r)&&!empty($r['ok']),$r);}
$denied=wp_create_user('reader024',bin2hex(random_bytes(16)),'reader024@example.invalid');wp_set_current_user($denied);
verifyLab('Core archive denies nonadministrator',F3Base_Google_Acervo::consultar(['de'=>'2026-10-27','ate'=>'2026-10-27','dataset'=>'campaign'])['codigo']==='sem_permissao');
wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($denied);
finishLab('integration024',['scope'=>'Real Core configuration and historical bootstrap isolation']);
