<?php
/** Recreate the exact baseline catalog under the current MCP transport. */
require __DIR__.'/common.php';
verifyLab('Published baseline version',F3_MCP_GOOGLE_VERSION==='0.22.0');
$out=[];foreach(wp_get_abilities() as $name=>$a)if(($a->get_meta()['fator3']['provider']??'')==='wp-mcp-google-fator3')$out[$name]=['input_schema'=>$a->get_input_schema(),'output_schema'=>$a->get_output_schema(),'meta'=>$a->get_meta()];
ksort($out);file_put_contents(getenv('F3_EVIDENCE_DIR').'/contracts0220-mcp036.json',wp_json_encode(['plugin_version'=>F3_MCP_GOOGLE_VERSION,'mcp_version'=>'0.36.0','abilities'=>$out],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n");
verifyLab('Published baseline identities',count($out)===294);finishLab('snapshot022');
