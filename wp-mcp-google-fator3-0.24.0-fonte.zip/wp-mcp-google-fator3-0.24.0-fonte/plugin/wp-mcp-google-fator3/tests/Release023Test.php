<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Options as O,Settings,Connections as C,Policy,Plugin,Auth\ServiceAccount as SA,Auth\Configuration as Auth,Auth\Candidate,Ads\ArchiveQuery as Query,Integration\QueryServiceApi as Gsc,Integration\ServiceApi as Legacy,Crypto};
final class Release023Test extends TestCase {
 private array $cfg;
 protected function setUp():void {
  $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];$GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;$GLOBALS['f3_test_user_caps']=[1=>true];FakeHttp::reset();C::select('default');
  O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'synthetic.apps.googleusercontent.com',C::SERVICES=>['gsc'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic',O::OAUTH_REFRESH_TOKEN=>'synthetic']);
  foreach([Gsc::class,Legacy::class] as $class){$p=new \ReflectionProperty($class,'consumers');$p->setAccessible(true);$p->setValue(null,[]);}
  $this->cfg=['property'=>'sc-domain:example.test','revision'=>'rev023','ready'=>true];Plugin::register_abilities();
 }
 private function key():array {return ['type'=>'service_account','client_email'=>'robot@example.test','private_key_id'=>'unusual','project_id'=>'','private_key'=>file_get_contents(__DIR__.'/fixtures/service-account-pkcs1-023.pem'),'token_uri'=>SA::DEFAULT_TOKEN_URI];}
 /** @dataProvider atypical */
 public function test_atypical_formats_reach_google_and_do_not_replace_saved_key(string $field,$value):void {
  $key=$this->key();$key[$field]=$value;$before=Settings::revision();
  $this->assertIsArray(SA::validate_key(wp_json_encode($key),true));FakeHttp::push('/token',400,['error'=>'invalid_grant']);
  $r=Auth::save_sa(wp_json_encode($key),null,false,$before);$this->assertFalse($r['success']);$this->assertSame('f3_google_credential_rejected',$r['error_code']);$this->assertCount(1,FakeHttp::$requests);$this->assertNotEmpty($r['warnings']);$this->assertSame($before,Settings::revision());$this->assertNull(Candidate::read('service_account'));
  $this->assertStringNotContainsString('BEGIN RSA PRIVATE KEY',wp_json_encode($r));
 }
 public static function atypical():array{return [['project_id',''],['project_id',null],['private_key_id','bad'],['private_key_id',null],['client_email','robot@other.example'],['client_email','not-a-usual-email']];}
 public function test_pkcs1_warning_is_advisory_and_token_endpoint_is_bound_to_audience():void {
  $key=$this->key();$key['token_uri']='https://oauth2.googleapis.com/token';FakeHttp::push('/token',200,['access_token'=>'synthetic']);$r=Auth::save_sa(wp_json_encode($key));$this->assertTrue($r['success']);$this->assertContains('f3_google_sa_format_private_key',array_column($r['warnings'],'code'));$jwt=FakeHttp::last()['body']['assertion'];$claims=json_decode(base64_decode(strtr(explode('.',$jwt)[1],'-_','+/')),true);$this->assertSame($key['token_uri'],$claims['aud']);$this->assertSame($key['client_email'],$claims['iss']);
 }
 /** @dataProvider blocked */
 public function test_structural_failures_do_not_dispatch(string $field,$value):void {
  $key=$this->key();$key[$field]=$value;$r=Auth::save_sa(wp_json_encode($key));$this->assertFalse($r['success']);$this->assertCount(0,FakeHttp::$requests);
 }
 public static function blocked():array{return [['type','authorized_user'],['client_email',''],['client_email','   '],['private_key',''],['private_key','-----BEGIN PRIVATE KEY----- invalid'],['token_uri',''],['token_uri','https://evil.example/token'],['token_uri','https://oauth2.googleapis.com@evil.example/token'],['token_uri','https://oauth2.googleapis.com.evil.example/token'],['token_uri',"https://oauth2.googleapis.com/\n/token"]];}
 private function input():array{return ['contract_version'=>'1.1.0','property'=>$this->cfg['property'],'consumer_revision'=>$this->cfg['revision'],'date'=>'2026-01-01','run_id'=>'unit023','trigger'=>'cli','budget_ms'=>20000,'limit'=>1];}
 private function client(){return Gsc::register_consumer('fixture023','1.0.0',Gsc::CONTRACT,fn()=>$this->cfg);}
 private function grant():array{return Legacy::configure(['contract'=>Gsc::CONTRACT,'consumer_id'=>'fixture023','enabled'=>true,'expected_revision'=>Settings::revision()]);}
 private function response(array $rows):void {FakeHttp::push('/token',200,['access_token'=>'synthetic','expires_in'=>3600]);FakeHttp::push('/searchAnalytics/query',200,['rows'=>$rows,'responseAggregationType'=>'byPage']);}
 private function row(string $query='fixture'):array{return ['keys'=>['2026-01-01','https://example.test/page',$query],'clicks'=>3,'impressions'=>10,'ctr'=>0.3,'position'=>2];}
 public function test_gsc_at_50k_ceiling_continues_to_empty_end_and_remains_partial():void {
  $c=$this->client();$this->assertTrue($this->grant()['success']);$this->response([$this->row()]);$a=$c->query($this->input());$this->assertTrue($a['success'],wp_json_encode($a));$cursor=json_decode(Crypto::decrypt($a['next_cursor']),true);$cursor['start']=49999;
  FakeHttp::push('/searchAnalytics/query',200,['rows'=>[$this->row('last')],'responseAggregationType'=>'byPage']);$r=$c->query($this->input()+['cursor'=>Crypto::encrypt(wp_json_encode($cursor))]);$this->assertTrue($r['success']);$this->assertNotNull($r['next_cursor']);$this->assertSame(50000,$r['coverage']['rows_accumulated']);
  FakeHttp::push('/searchAnalytics/query',200,['rows'=>[],'responseAggregationType'=>'byPage']);$z=$c->query($this->input()+['cursor'=>$r['next_cursor']]);$this->assertTrue($z['coverage']['pagination_complete']);$this->assertTrue($z['coverage']['truncated']);$this->assertSame('api_daily_row_limit',$z['coverage']['truncation_reason']);$this->assertNull($z['coverage']['anonymous_query_clicks']);
 }
 public function test_gsc_new_grant_binds_property_principal_and_grantor():void {
  $c=$this->client();$this->grant();$this->cfg['property']='sc-domain:other.test';$this->assertSame('f3_google_consumer_unauthorized',$c->query($this->input())['error_code']);$this->cfg['property']='sc-domain:example.test';
  $GLOBALS['f3_test_user_caps'][1]=false;$this->assertSame('f3_google_consumer_unauthorized',$c->query($this->input())['error_code']);$this->assertCount(0,FakeHttp::$requests);
 }
 public function test_gsc_cannot_reuse_client_identity_in_other_service():void {
  $c=$this->client();$this->grant();$i=$this->input();$i['contract_version']='1.0.0';$this->assertSame('f3_google_consumer_unregistered',Legacy::query($c,$i)['error_code']);$this->assertCount(0,FakeHttp::$requests);
 }
 public function test_queries_use_separate_resources_and_daily_windows():void {
  $q=Query::gaql('clicks','2026-01-02');$this->assertStringContainsString("FROM click_view WHERE segments.date = '2026-01-02'",$q);$this->assertStringNotContainsString('search_term',$q);$this->assertStringContainsString('click_view.keyword_info.text',$q);
  $change=Query::gaql('changes','2026-01-02',[0,43200]);$this->assertStringContainsString("change_event.change_date_time < '2026-01-02 12:00:00'",$change);$this->assertStringEndsWith('LIMIT 10000',$change);$this->assertSame('2026-01-01',Query::first_day('changes','2026-01-30'));$this->assertSame('2025-11-01',Query::first_day('clicks','2026-01-30'));$this->assertFalse(Query::valid_date('2026-02-30'));
 }
 public function test_archive_ability_effects_are_local_writes_and_remote_reads():void {
  foreach(['ads/archive-configure','ads/archive-collect','ads/archive-consumer-grant'] as $name){$a=wp_get_ability($name);$m=$a->get_meta();$this->assertSame('write',$m['fator3']['mode']);$this->assertFalse($m['annotations']['destructive']??$m['mcp']['annotations']['destructiveHint']??false);$this->assertSame($name==='ads/archive-consumer-grant'?'none':'read',$m['fator3']['remote_effect']);}
  $this->assertSame('none',wp_get_ability('ads/archive-status')->get_meta()['fator3']['remote_effect']);
 }
}
