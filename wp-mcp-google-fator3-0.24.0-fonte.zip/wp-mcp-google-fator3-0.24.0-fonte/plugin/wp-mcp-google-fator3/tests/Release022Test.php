<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Options as O,Connections as C,Settings,Policy,ConversionDelivery as D,StageConversionDelivery as S,Plugin,Records,Audit};
use Fator3\McpGoogle\Ads\DataManager as DM;
final class Release022Test extends TestCase {
    private const ACTION='customers/1234567890/conversionActions/222';
    private const ACQ='customers/1234567890/conversionActions/111';
    protected function setUp():void {
        if(!defined('HOUR_IN_SECONDS'))define('HOUR_IN_SECONDS',3600);
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;$GLOBALS['f3_test_user_caps']=[];FakeHttp::reset();
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $p)unlink($p);
        O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::GA_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ads'=>'write','ga'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],
            [O::OAUTH_CLIENT_SECRET=>'fixture-secret',O::OAUTH_REFRESH_TOKEN=>'fixture-refresh',O::ADS_DEVELOPER_TOKEN=>'fixture-dev']);
        O::set(D::CONFIG,array_replace(D::defaults(),['enabled'=>true,'customer_id'=>'1234567890','conversion_action'=>self::ACQ,'granted_by_target'=>['google_ads'=>1]]));
        Plugin::register_abilities();
    }
    private function adapter(string $action=self::ACTION):S {return D::adapter(null,'google_ads',S::CONTRACT,['consumer_id'=>S::CONSUMER,'purpose'=>S::PURPOSE,'action'=>$action]);}
    private function grant(bool $enabled=true,string $action=self::ACTION):array {
        return S::configure(['expected_revision'=>D::revision(),'action'=>$action,'enabled'=>$enabled]);
    }
    private function verified(string $action=self::ACTION,bool $enhanced=true):S {
        $r=$this->grant(true,$action);$this->assertTrue($r['success'],wp_json_encode($r));
        for($i=0;$i<3;++$i)FakeHttp::push('/token',200,['access_token'=>'test-access','expires_in'=>3600]);
        FakeHttp::push('googleAds:search',200,['results'=>[['conversionAction'=>['resourceName'=>$action,'type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>37.5,'defaultCurrencyCode'=>'USD','alwaysUseDefaultValue'=>false]]]]]);
        FakeHttp::push('/events:ingest',200,[]);
        FakeHttp::push('googleAds:search',200,['results'=>[['customer'=>['id'=>'1234567890','conversionTrackingSetting'=>['acceptedCustomerDataTerms'=>$enhanced,'enhancedConversionsForLeadsEnabled'=>$enhanced]]]]]);
        $r=S::verify(['expected_revision'=>D::revision(),'action'=>$action]);$this->assertTrue($r['success'],wp_json_encode($r));
        $this->assertTrue($r['verified']);return $this->adapter($action);
    }
    private function payload(array $changes=[]):array {
        return array_replace(['contract'=>S::CONTRACT,'purpose'=>S::PURPOSE,'record_id'=>str_repeat('a',32),'stage_id'=>'qualificado','action'=>self::ACTION,
            'event_id'=>'f3q-'.str_repeat('b',64),'order_id'=>'f3q-'.str_repeat('b',64),'occurred_at'=>gmdate('c',time()-5),
            'click_ids'=>['gclid'=>'synthetic-click'],'ad_user_data'=>'GRANTED','value'=>0,'currency'=>'BRL'],$changes);
    }
    private function ref(S $a,string $action=self::ACTION):string {return $a->capabilities()['actions'][$action]['destination_ref'];}
    public function test_acquisition_cannot_grant_commercial_access_and_discovery_is_local():void {
        $a=$this->adapter();$cap=$a->capabilities();$this->assertFalse($cap['ready']);$this->assertSame('stage_grant_missing',$cap['reason']);$this->assertSame(self::ACQ,$cap['acquisition_action']);
        foreach([D::LEGACY_CONTRACT,D::CONTRACT] as $contract){$old=D::adapter(null,'google_ads',$contract);$this->assertSame($contract,$old->capabilities()['contract']);$this->assertContains(S::CONTRACT,$old->capabilities()['supported_contracts']);}
        $this->assertNotContains(S::CONTRACT,D::adapter(null,'ga4',D::CONTRACT)->capabilities()['supported_contracts']);
        $this->assertSame('stage_grant_missing',$a->sendBound($this->payload(),$this->ref($a))['code']);$this->assertSame([],FakeHttp::$requests);
    }
    public function test_fourth_filter_argument_and_invalid_context():void {
        D::init();$a=apply_filters('f3base_conversoes_adaptador',null,'google_ads',S::CONTRACT,['consumer_id'=>S::CONSUMER,'purpose'=>S::PURPOSE,'action'=>self::ACTION]);$this->assertInstanceOf(S::class,$a);
        foreach([[],['consumer_id'=>'other','purpose'=>S::PURPOSE,'action'=>self::ACTION],['consumer_id'=>S::CONSUMER,'purpose'=>'acquisition','action'=>self::ACTION]] as $ctx)$this->assertSame('stage_context_invalid',D::adapter(null,'google_ads',S::CONTRACT,$ctx)->capabilities()['reason']);
        $sentinel=new \stdClass();$this->assertSame($sentinel,D::adapter($sentinel,'google_ads',S::CONTRACT,[]));
    }
    public function test_acquisition_null_requires_readable_absence_and_no_reuse():void {
        $this->assertSame('acquisition_action_reused',$this->grant(true,self::ACQ)['code']);
        $c=O::get(D::CONFIG);$c['conversion_action']='';O::set(D::CONFIG,$c);$this->assertNull($this->adapter()->capabilities()['acquisition_action']);
        $c['conversion_action']='invalid';O::set(D::CONFIG,$c);$cap=$this->adapter()->capabilities();$this->assertArrayNotHasKey('acquisition_action',$cap);$this->assertSame('acquisition_unreadable',$cap['reason']);
    }
    public function test_grant_verification_fixed_value_and_generation():void {
        $before=O::get(D::CONFIG);$a=$this->verified();$cap=$a->capabilities();$this->assertTrue($cap['ready']);$this->assertSame(self::ACQ,$cap['acquisition_action']);
        $events=array_values(array_filter(FakeHttp::$requests,fn($r)=>str_contains($r['url'],'events:ingest')));$body=json_decode($events[0]['body'],true);$this->assertTrue($body['validateOnly']);$this->assertEquals(0,$body['events'][0]['conversionValue']);$this->assertSame('BRL',$body['events'][0]['currency']);
        foreach($before as $k=>$v)$this->assertSame($v,O::get(D::CONFIG)[$k]);
        $ref=$this->ref($a);$this->assertFalse($this->grant()['changed']);$this->assertSame($ref,$this->ref($a));
        $r=S::configure(['expected_revision'=>D::revision(),'action'=>self::ACTION,'enabled'=>true,'renew_grant'=>true]);$this->assertTrue($r['success']);$this->assertNotSame($ref,$this->ref($a));$this->assertFalse($a->capabilities()['ready']);
    }
    public function test_send_event_identity_privacy_and_replay():void {
        $a=$this->verified();$p=$this->payload(['click_ids'=>[],'user_data'=>['email'=>'First.Last@gmail.com','telefone'=>'+5511999999999']]);$ref=$this->ref($a);
        FakeHttp::push('events:ingest',200,['requestId'=>'stage-receipt']);$r=$a->sendBound($p,$ref);$this->assertSame('incerto',$r['status']);
        $body=json_decode(FakeHttp::last()['body'],true);$this->assertSame($p['event_id'],$body['events'][0]['transactionId']);$this->assertEquals(0,$body['events'][0]['conversionValue']);$this->assertSame('BRL',$body['events'][0]['currency']);$this->assertSame('222',$body['destinations'][0]['productDestinationId']);$this->assertArrayNotHasKey('adIdentifiers',$body['events'][0]);$this->assertSame('HEX',$body['encoding']);
        $count=FakeHttp::count();$this->assertSame($r,$a->sendBound($p,$ref));$this->assertSame($count,FakeHttp::count());
        $store=wp_json_encode([$GLOBALS['f3_test_options'],Records::list('conversion',100),Audit::recent(100)]);
        foreach(['First.Last','firstlast@gmail.com','5511999999999',hash('sha256','firstlast@gmail.com'),hash('sha256','+5511999999999')] as $value)$this->assertStringNotContainsString($value,$store);
        $p['stage_id']='other';$this->assertSame('data_manager_event_conflict',$a->sendBound($p,$ref)['code']);$this->assertSame($count,FakeHttp::count());
    }
    /** @dataProvider invalidPayloads */
    public function test_closed_payload_rejected_before_http(array $changes):void {
        $a=$this->verified();$count=FakeHttp::count();$r=$a->sendBound($this->payload($changes),$this->ref($a));$this->assertSame('recusado',$r['status']);$this->assertTrue($r['non_delivery_proven']);$this->assertSame($count,FakeHttp::count());
    }
    public static function invalidPayloads():array {return [
        [['contract'=>D::CONTRACT]],[['purpose'=>'acquisition']],[['record_id'=>'bad']],[['stage_id'=>'']],[['action'=>self::ACQ]],
        [['order_id'=>str_repeat('a',32)]],[['event_id'=>str_repeat('x',129)]],[['ad_user_data'=>'DENIED']],[['value'=>42]],[['currency'=>'USD']],
        [['extra'=>'forbidden']],[['click_ids'=>['gclid'=>'a','gbraid'=>'b']]],[['click_ids'=>[]]],[['user_data'=>['email'=>'bad']]],
        [['occurred_at'=>'tomorrow']],[['occurred_at'=>'2026-02-30T12:00:00Z']],[['occurred_at'=>'2000-01-01T00:00:00Z']],
    ];}
    public function test_revocation_identity_action_and_permission_changes_block_before_effect():void {
        $a=$this->verified();$p=$this->payload();$ref=$this->ref($a);$count=FakeHttp::count();$this->grant(false);
        $this->assertSame('stage_grant_revoked',$a->sendBound($p,$ref)['code']);$this->assertSame($count,FakeHttp::count());
        $a=$this->verified();$ref=$this->ref($a);O::set_secret(O::OAUTH_REFRESH_TOKEN,'different');$count=FakeHttp::count();
        $this->assertSame('stage_grant_changed',$a->sendBound($p,$ref)['code']);$this->assertSame($count,FakeHttp::count());
        $GLOBALS['f3_test_caps']=false;$this->assertFalse(S::configure(['expected_revision'=>D::revision(),'action'=>self::ACTION,'enabled'=>true])['success']);
        foreach(['stage-conversion-status','configure-stage-conversion','verify-stage-conversion','reconcile-stage-conversion'] as $n)$this->assertFalse(wp_get_ability('google/'.$n)->check_permissions([]));
    }
    public function test_different_actions_do_not_share_receipts():void {
        $a=$this->verified();$other='customers/1234567890/conversionActions/333';$b=$this->verified($other);$p=$this->payload();
        foreach([[$a,self::ACTION],[$b,$other]] as [$adapter,$action]){FakeHttp::push('events:ingest',200,['requestId'=>'receipt-'.basename($action)]);$this->assertSame('incerto',$adapter->sendBound(array_replace($p,['action'=>$action]),$this->ref($adapter,$action))['status']);}
        $this->assertCount(2,Records::list('conversion',100));
    }
    public function test_reconciliation_confirms_only_exact_single_event_without_ingestion():void {
        $a=$this->verified();$p=$this->payload();$ref=$this->ref($a);FakeHttp::push('events:ingest',200,['requestId'=>'receipt-stage']);$a->sendBound($p,$ref);
        $rows=Records::list('conversion',100);$key=array_key_first($rows);$row=$rows[$key];$row['next_attempt']=time()-1;Records::put('conversion',$key,$row);
        $count=FakeHttp::count();FakeHttp::push('requestStatus:retrieve',200,['requestStatusPerDestination'=>[['destination'=>$row['destination'],'requestStatus'=>'SUCCESS','eventsIngestionStatus'=>['recordCount'=>'1']]]]);
        $r=$a->reconcileBound($p['event_id'],$ref);$this->assertSame('entregue',$r['status']);$this->assertSame($count+1,FakeHttp::count());$this->assertSame('GET',FakeHttp::last()['method']);
        $this->assertSame('entregue',$a->sendBound($p,$ref)['status']);$this->assertSame($count+1,FakeHttp::count());
        $this->assertSame('data_manager_receipt_unknown',$a->reconcileBound('missing',$ref)['code']);$this->assertSame($count+1,FakeHttp::count());
    }
    public function test_enhanced_unready_still_allows_click_only():void {
        $a=$this->verified(self::ACTION,false);$ref=$this->ref($a);$count=FakeHttp::count();
        $this->assertSame('enhanced_leads_not_ready',$a->sendBound($this->payload(['click_ids'=>[],'user_data'=>['email'=>'a@example.test']]),$ref)['code']);$this->assertSame($count,FakeHttp::count());
        FakeHttp::push('events:ingest',200,['requestId'=>'click-only']);$this->assertSame('incerto',$a->sendBound($this->payload(),$ref)['status']);
    }
    public function test_value_override_conflict_is_not_verified():void {
        $this->grant();FakeHttp::push('/token',200,['access_token'=>'test','expires_in'=>3600]);
        FakeHttp::push('googleAds:search',200,['results'=>[['conversionAction'=>['resourceName'=>self::ACTION,'type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>99,'defaultCurrencyCode'=>'BRL','alwaysUseDefaultValue'=>true]]]]]);
        $r=S::verify(['expected_revision'=>D::revision(),'action'=>self::ACTION]);$this->assertFalse($r['success']);$this->assertSame('ads_action_unverified',$r['code']);$this->assertFalse($this->adapter()->capabilities()['ready']);
        $this->assertCount(0,array_filter(FakeHttp::$requests,fn($x)=>str_contains($x['url'],'events:ingest')));
    }
    public function test_status_has_no_http_and_metadata_is_correct():void {
        $this->verified();$n=FakeHttp::count();$r=wp_get_ability('google/stage-conversion-status')->execute([]);$this->assertTrue($r['success']);$this->assertSame($n,FakeHttp::count());
        foreach(['stage-conversion-status'=>'none','configure-stage-conversion'=>'none','verify-stage-conversion'=>'read','reconcile-stage-conversion'=>'read'] as $name=>$effect)$this->assertSame($effect,wp_get_ability('google/'.$name)->get_meta()['fator3']['remote_effect']);
    }
    public function test_expired_proof_blocks_send_but_reconciliation_keeps_original_receipt():void {
        $a=$this->verified();$p=$this->payload();$ref=$this->ref($a);FakeHttp::push('events:ingest',200,['requestId'=>'expired-proof']);$a->sendBound($p,$ref);
        $c=O::get(D::CONFIG);$c['stage_actions'][self::ACTION]['proof']['expires']=time()-1;O::set(D::CONFIG,$c);$n=FakeHttp::count();
        $this->assertSame('stage_verification_required',$a->sendBound($p,$ref)['code']);$this->assertSame($ref,$this->ref($a));
        $rows=Records::list('conversion',100);$key=array_key_first($rows);$row=$rows[$key];$row['next_attempt']=time()-1;Records::put('conversion',$key,$row);
        FakeHttp::push('requestStatus:retrieve',200,['requestStatusPerDestination'=>[['destination'=>$row['destination'],'requestStatus'=>'SUCCESS','eventsIngestionStatus'=>['recordCount'=>'1']]]]);
        $this->assertSame('entregue',$a->reconcileBound($p['event_id'],$ref)['status']);$this->assertSame($n+1,FakeHttp::count());
    }
    public function test_background_renewal_preserves_generation_and_records_origin():void {
        $a=$this->verified();$ref=$this->ref($a);$c=O::get(D::CONFIG);$c['stage_actions'][self::ACTION]['renewal']['next_attempt']=time()-1;O::set(D::CONFIG,$c);
        FakeHttp::push('googleAds:search',200,['results'=>[['conversionAction'=>['resourceName'=>self::ACTION,'type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>0,'defaultCurrencyCode'=>'BRL','alwaysUseDefaultValue'=>true]]]]]);
        FakeHttp::push('/events:ingest',200,[]);FakeHttp::push('googleAds:search',200,['results'=>[['customer'=>['id'=>'1234567890','conversionTrackingSetting'=>['acceptedCustomerDataTerms'=>true,'enhancedConversionsForLeadsEnabled'=>true]]]]]);
        $r=D::renew_due();$this->assertTrue($r['crm_stage']['success'],wp_json_encode($r));$this->assertTrue($r['crm_stage']['actions'][self::ACTION]['success']);$this->assertSame($ref,$this->ref($a));
        $g=O::get(D::CONFIG)['stage_actions'][self::ACTION];$this->assertGreaterThan(time()+43000,$g['renewal']['next_attempt']);$this->assertStringContainsString('executor',wp_json_encode(Audit::recent(100)));
        $n=FakeHttp::count();$this->assertSame([],S::renew_due());$this->assertSame($n,FakeHttp::count());
    }
    public function test_grant_persistence_failure_does_not_claim_authorized():void {
        $GLOBALS['f3_test_write_fail'][D::CONFIG]=true;$r=$this->grant();$this->assertFalse($r['success']);$this->assertSame('grant_not_saved',$r['code']);$this->assertFalse($this->adapter()->capabilities()['ready']);$this->assertSame([],FakeHttp::$requests);
    }
    public function test_revocation_between_token_and_validation_stops_further_http():void {
        $this->grant();$hook=static function($r,$args,$url){if(str_contains($url,'/token')){$c=O::get(D::CONFIG);$c['stage_actions'][self::ACTION]['enabled']=false;O::set(D::CONFIG,$c);}return $r;};
        add_filter('pre_http_request',$hook,20,3);FakeHttp::push('/token',200,['access_token'=>'race-token','expires_in'=>3600]);
        try{$r=S::verify(['expected_revision'=>D::revision(),'action'=>self::ACTION]);$this->assertFalse($r['success']);$this->assertCount(1,FakeHttp::$requests);$this->assertSame('stage_grant_revoked',$this->adapter()->capabilities()['reason']);}
        finally{remove_filter('pre_http_request',$hook,20);}
    }

    public function test_duplicate_action_across_connections_is_never_selected_or_sent():void {
        $a=$this->verified();$p=$this->payload();$ref=$this->ref($a);$n=FakeHttp::count();$raw=O::get(D::CONFIG);
        $this->assertTrue(C::create('duplicate','Duplicate fixture')['success']);
        C::run('duplicate',static fn()=>O::set(D::CONFIG,$raw));
        $this->assertSame('ambiguous_stage_connection',$this->adapter()->capabilities()['reason']);
        $this->assertSame('ambiguous_stage_connection',$a->sendBound($p,$ref)['code']);$this->assertSame($n,FakeHttp::count());
    }

}
