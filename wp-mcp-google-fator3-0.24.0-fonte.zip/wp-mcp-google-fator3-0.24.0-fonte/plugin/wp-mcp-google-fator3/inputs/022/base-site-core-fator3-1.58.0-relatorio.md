# Entrega — Fator3 Site Core 1.58.0

Revisão 2 · 28/10/2026 · America/Sao_Paulo · Fechamento da entrega.  
**Situação: `com-pendencias`. Core 1.58.0 validado localmente; Site-Teste permanece na versão 1.57.1.** Slug `base-site-core-fator3`; basename `base-site-core-fator3/base-site-core-fator3.php`.

Relatório externo canônico. A cópia dentro do fonte é anterior ao fechamento e remete a este arquivo para tamanho/hash finais do próprio fonte. Não inserir seu hash dentro do ZIP que ele identifica. Pacotes finais serão imutáveis.

## 1. Bases aceitas e entrada da versão

Base direta **Core 1.57.1 canônica**, sem intermediária. Instalador-base 2707842 bytes, SHA-256 `ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62`; fonte-base 4145747 bytes, SHA-256 `0600d83f31389055593645daf366465472c165b4a8ab2f85720da112e0b9aeb5`. A base foi preservada; candidato paralelo 1.57.0 não é base de migração desta rodada.

A versão 1.58.0 incrementa minor por funcionalidades, conforme norma. Instalação limpa e atualização direta 1.57.1 → 1.58.0 são os caminhos previstos. Mínimos declarados no Core: WordPress 7.1.2, PHP 8.3.6 de 64 bits, sem multisite. O piso foi exercitado em WordPress 7.1.2/PHP 8.3.6; WordPress 7.1.3/PHP 8.3.6 também passou pelos ciclos nativos, conforme seção 4.

Entradas: Pedidos core 314–329 de 28/10/2026 em `inputs/1580/pedidos-core-20261028.md`; instruções e padrão canônicos preservados, com a Norma 02 revisão 5 prevalecendo na regra de impactos. Plano anterior ao código em `history/1580/PLANO.md`; novos acompanhantes em `history/1580/ADENDO-MCP0340-META0130.md`. Metadados/hashes das entradas estão em `inputs/1580`; ZIPs recebidos não foram editados nem aninhados na entrega.

Contrato administrativo passa de 8.22.1 para **8.23.0**. Identidades públicas, namespaces, opções existentes e perfil `piso-padrao-3.6` conservados. Os contratos de GA4, exclusão Instagram e cliente Pipedrive da base permanecem. O escopo não inclui o canário diário nem marcos operacionais, expressamente excluídos pelo dono.

## 2. Convivência e encaminhamentos

O inventário lido no Site-Teste durante a implementação mostrou Core 1.57.1, MCP 0.34.0, Google 0.21.0, Meta 0.13.0, LinkedIn 0.11.0 e Pipedrive 0.3.0, ativos. Os acompanhantes foram atualizados por outras rodadas. O Core não os alterou nem fez downgrade. DreamHost Panel Login 1.0.0, WP Super Cache 3.1.4 e Yoast SEO 28.8 também estavam ativos.

| Acompanhante corrente | SHA-256 do instalador recebido | Fronteira examinada nesta rodada |
| --- | --- | --- |
| MCP 0.34.0 | `5d96b6a33cfc4a7c729c106268f4bc9d8938b34384da022345d7b7dae611a295` | Relatório/código, autorização, diagnóstico, recibo idempotente e served/bypass; provas próprias finais na seção 4. |
| Google 0.21.0 | `25da9ef78e303f30ce2f73b8f98743a26e09b8ed238177474e4a956578a63814` | Contrato de conversão 1.1, prontidão/status e preservação do leitor GA4. |
| Meta 0.13.0 | `3ecd6ee6f277c7581adc05b4fa38c46611e3232b4400bb4a4421956c9fba8ac1` | Contrato Ads 1.0, concessão, paginação, saúde parcial e contratos Instagram. |
| LinkedIn 0.11.0 | `34541afa67c0991e9dc0b5474ab8678dff8cf806eace6ceb1edb47983f9e0308` | Status local, escopos/validade, adaptador de contato e limites do retorno comercial. |
| Pipedrive 0.3.0 | `30fc784a552a89351900c169fad7300759163fb886b842f45ba807bb0977f657` | Código/schema/relatório e contrato cliente Core preservado; exige PHP 8.3.36. |

Instalar Google 0.21 antes de habilitar 316. Meta 0.13 pode estar instalado antes do consumidor: a concessão fica desligada. Pipedrive 0.3 não foi declarado compatível com o PHP 8.3.6 do piso Core; ativação nativa nesse ambiente inferior não constitui prova válida.

Os quatro ZIPs MCP 0.34/Meta 0.13 receberam conferência própria de tamanho/hash contra os relatórios. Runtime Google/Meta/Pipedrive corresponde ao plugin de seus fontes; MCP acrescenta 56 índices de silêncio produzidos pelo build. Ver `evidence/1580/companion-package-comparison.json`. Testes publicados nos relatórios dos acompanhantes são evidência dos emissores e não entram no total de checks próprios do Core.

### Impactos novos desta rodada

- `base-site-core-fator3-1.58.0-impacto-wp-mcp-google-fator3.md`: ação necessária, demanda aberta para 323, seleção/binding por ação de etapa e contrato opcional 1.2.0. Revisão **2**, com negociação, finalidade, prova da ação de aquisição, binding e semântica de incerteza especificados.
- `base-site-core-fator3-1.58.0-impacto-wp-mcp-linkedin-fator3.md`: ação necessária, demanda aberta para 323, regra comercial por etapa, concessão vigente e recibo. Revisão **2**, com concessão, finalidade, ação, binding e semântica de incerteza especificados.

Não foram enviados externamente por esta rodada. Não há novo pedido de alteração identificado em MCP/Pipedrive nas fronteiras examinadas. Isso não homologa suas funções não exercitadas. Meta tem demanda recebida de consumidor; seu atendimento se registra abaixo, sem impacto de retorno.

### Respostas, atendimento e desfechos recebidos

| Referência | Resultado no Core | Evidência / limite |
| --- | --- | --- |
| Impacto Google 0.21 → Core, Google 39/Core 316 | Consumidor negocia 1.1.0, mantém destino vinculado e usa user_data somente com capacidade/prova vigente. O 1.0 é preservado. | `request-316.php` (25) e `request-316-real.php` (52), aprovados localmente. Primeira conversão real aceita permanece com operador. |
| Google 40 e MCP 69/Core 324 | Resumo Core consome contratos locais compactos sem chamar fornecedor. Expiração não publicada permanece desconhecida. | `request-321-324.php`, `companions-321-324.php`; comparar rotas na frota continua aceite separado. |
| Impacto Meta 0.13 → Core, revisão 2, Meta 20(e) | Consumidor `meta-ads-reader/1.0.0`, configuração/revisão próprias, concessão no Meta, vínculo por IDs/parceiro e cursores consistentes. | `meta-ads-0130.php`; 30 dias sintéticos não equivalem a Ads Manager real. |
| Instagram Meta 18(b)/Core 309 e 312 | Proteções 1.57.1 de exclusão/retomada preservadas, sem reabrir ou reemitir impacto antigo. | Regressão `request-312-1571` (32) aprovada com Meta 0.13; aceite de contato real pertence à frota. |
| GA4 Core 313 | Acervo e contratos da base preservados, sem nova autorização implícita. | Regressão e 30 dias reais são provas diferentes; não declarar encerrado aceite externo anterior. |

## 3. Mudanças por pedido e evidência

| Pedido | Problema e resultado no candidato | Evidência própria / situação |
| --- | --- | --- |
| Core 314 | Atribuição nativa não inventa sessão/entrada; nota traz fonte do nome da campanha. A omissão da fonte na nota existia na base 1.57.1. Fotografias antigas preservadas. | `request-314-317-328-329.php`; `validado-localmente`, aceite de próximo lead real pendente. |
| Core 315 | Desfechos cifrados de negócios com decimal/moeda/fechamento; mudança só de valor tem anterior/atual; múltiplos negócios preservados e dedup por conta/ID; moedas separadas, valor Meta optativo. | `request-315-318-319.php`, `review-315-320.php`; `validado-localmente`, negócio em conta real não exercitado nesta rodada. |
| Core 316 | Negociação Google 1.1 e Enhanced Leads com consentimento/prova/conta/ação; clique legado conservado; prévia em hashes, sem fila. | `request-316.php`, `request-316-real.php`; `validado-localmente`, homologação Google real pendente. |
| Core 317 | Último campo técnico, etapa e quantidade preenchida, sem valor; definição/revisão de HTML cacheado e abandono no relatório. | `request-317.php`, `request-317-dom.cjs`; `validado-localmente`, DOM sintético não é navegador/usuário real. |
| Core 318 | Associação WhatsApp por único E.164 na janela de 24 horas, transação/trava/tombstone, sem segundo registro ou conversão; motivos de ausência/ambiguidade. | `request-315-318-319.php`; `validado-localmente`, ponte real/frota pendentes. |
| Core 319 | Registro anterior por identificadores exatos em 30 dias; supressão por destino desligada; avisos/notas e estimativa de pessoas no recorte. | `request-315-318-319.php`; `validado-localmente`, cobertura limitada explícita. |
| Core 320 | Instante/fonte da primeira resposta observada sem texto, usuários CRM declarados, exclusão de bots/automação conhecida; mediana/p75 e origem de dimensões. | `request-320.php`, `review-315-320.php`; `validado-localmente`, resposta real da equipe pendente. |
| Core 321 | Prontidão Meta/Google/LinkedIn local com motivo/ação/fonte, CRM/mapeamentos e último contato pago entregue. | `request-321-324.php`, `companions-321-324.php`, `request-321-no-http.php`; `validado-localmente`, comparação linha a linha em ctooffice pendente. |
| Core 322 | Teste sob demanda com prévia/revisão/chave, diário por salto, homologação por registro e limpeza autoral reautorizável; zero conversões reais. | `request-322.php`, `request-322-remotes.php`; parcial e `validado-localmente` no escopo descrito: e-mail/webhook bloqueados antes do transporte sem limpeza individual comprovável. |
| Core 323 | Motivos fechados/ICP, atividade/criação do negócio, webhook separado de polling; ações comerciais e recibos próprios. | `request-323.php`; consumidor `validado-localmente`, envio real bloqueado: Google 0.21/LI 0.11 não anunciam 1.2.0. |
| Core 324 | Resumo local até 4 KiB com detalhe/omissões/validade desconhecida e projeções compactas. | `request-321-324.php`, `companions-321-324.php`; `validado-localmente`, paridade de contratos e limite de tamanho aprovados; comparação na frota pendente. |
| Core 325 | Marcas/domínios/exceções por site, achados HTML/JSON-LD por superfície e fotografia de contagens local. | `request-325.php`; `validado-localmente`, página pública temporária e exceções de produção têm aceite próprio. |
| Core 326 | Uma sequência após confirmação do executor, cache/cabeçalhos antes de navegação, catálogo CRM ativo, reserva/recibo e aviso sem bloquear instalação. | `request-326.php`; `validado-localmente`, aceite automático após instalação remota pendente; não houve upload nesta rodada. |
| Core 327 | wp_mail opcional pelo SMTP autenticado, cota compartilhada/MIME cifrado, fase/código, sem fallback PHP e cessão a outro SMTP. | `request-327.php`; `validado-localmente`, DKIM/DMARC recebido real não é provado pela fixture. |
| Core 328 | JSON Pointer com candidato integral/CAS, projeção de caminhos/hashes canônicos e valor único na resposta. | `request-314-317-328-329.php`, `review-328-329.php`; `validado-localmente`, escrita real no Site-Teste pendente; somente fixture local executada. |
| Core 329 | Destino técnico próprio por e-mail, atraso sem erro mínimo 60 min, erro real imediato, recuperação só após atenção aceita; movimentação faz parte da saúde. | `request-314-317-328-329.php`, `review-328-329.php`; `validado-localmente`, observação de uma semana na frota pendente. |
| Meta 20(e) | Leitor Core concedido do histórico Meta, sem Graph/duplicar acervo, moeda/fuso/cobertura/revisão preservados. | `meta-ads-0130.php`; consumidor `validado-localmente`, 30 dias reais e reconciliação externa pendentes. |

A implementação não muda escolha de etapa para otimização de lances, concessões de fornecedores ou defaults comerciais sem ação explícita do operador. Sem capacidade entregue, uma prévia pode estar disponível enquanto o efeito real continua bloqueado.

## 4. Instalação, prontidão, documentação e testes

**Resultado local: `validado-localmente`.** O instalador de 2816484 bytes, SHA-256 `71bf6497a2f2e2c605baf64f0f82c273201915039506b58ac220fc572afbd5e4`, contém 770 arquivos; os 555 arquivos PHP passaram no lint em PHP 8.3.6. A identidade consta de `evidence/1580/installer.json`. Runtime e documentação do instalador foram congelados antes do fechamento do fonte.

| Ambiente nativo local | Instalação limpa | Atualização 1.57.1 → 1.58.0 | Desinstalação/reinstalação |
| --- | --- | --- | --- |
| WordPress 7.1.2 / PHP 8.3.6 | aprovada | aprovada | preservação aprovada |
| WordPress 7.1.3 / PHP 8.3.6 | aprovada | aprovada | preservação aprovada |

Evidências: `evidence/1580/native-wp712/native-cycles-1580.json` e `native-wp713/native-cycles-1580.json`, ambos com o SHA do instalador acima. Usaram WordPress nativo, bancos descartáveis, `Plugin_Upgrader` e requisições novas; o atraso de finalização foi acelerado apenas no estado descartável. Migração repetida retornou `atual`; configurações, contatos, acervos e dados semânticos semeados permaneceram iguais na atualização. As cinco tabelas novas conservaram histórico e incerteza; pendentes foram suspensos na desinstalação, sem HTTP, e permaneceram preservados na reinstalação. Esses ciclos não comprovam cron público, servidor de produção nem execução remota do pedido 326.

As tabelas abaixo contam **assertivas booleanas da última execução registrada por suite**, todas aprovadas. O resumo `evidence/1580/test-summary.json` totaliza **2867**: 1732 de documentação, 13 verificações estáticas do harness e 1122 das demais suites. Os ciclos nativos e o lint são provas separadas desse total. Repetições corrigidas não são somadas; metadados numéricos não são assertivas. Casos de permissões nativas e pelo MCP são modos distintos e estão identificados separadamente. As evidências correspondentes estão em `evidence/1580/<suite>.json`.

### Casos novos e revisão das fronteiras

| Suite | Assertivas booleanas | Resultado |
| --- | ---: | --- |
| `request-314-317-328-329` | 22 | aprovadas |
| `request-315-318-319` | 33 | aprovadas |
| `request-316` | 25 | aprovadas |
| `request-316-real` | 52 | aprovadas |
| `request-317` | 29 | aprovadas |
| `request-317-dom` | 44 | aprovadas |
| `request-320` | 28 | aprovadas |
| `request-321-324` | 45 | aprovadas |
| `companions-321-324` | 67 | aprovadas |
| `request-321-no-http` | 3 | aprovadas |
| `request-322` | 41 | aprovadas |
| `request-322-remotes` | 20 | aprovadas |
| `request-323` | 31 | aprovadas |
| `request-325` | 14 | aprovadas |
| `request-326` | 11 | aprovadas |
| `request-327` | 33 | aprovadas |
| `meta-ads-0130` | 41 | aprovadas |
| `review-315-320` | 14 | aprovadas |
| `review-328-329` | 12 | aprovadas |
| `review-identidade-1580` | 26 | aprovadas |
| `review-public1580` | 16 | aprovadas |
| `review-324-bound` | 32 | aprovadas |

316 usa o adaptador Google 0.21 original com HTTP sintético, sem enviar conversão a fornecedor. 322 usa workers reais do Core e objetos Pipedrive/Slack sintéticos; 20 checks dos transportes não são homologação externa. Meta Ads usa o SDK 0.13 original e 30 dias sintéticos. A prova DOM usa HTML renderizado, jsdom e scripts fonte/minificados, não navegação gráfica no Site-Teste. A suite 324 inclui decorador MCP real e excesso sintético para comprovar o limite de 4096 bytes, omissões explícitas e ausência de HTTP.

### Regressões reexecutadas

| Suite | Assertivas booleanas | Resultado |
| --- | ---: | --- |
| `request-300-mime` | 25 | aprovadas |
| `request-300-state` | 27 | aprovadas |
| `request-300-collector` | 15 | aprovadas |
| `request-302` | 69 | aprovadas |
| `request-305` | 26 | aprovadas |
| `request-305-imap` | 10 | aprovadas |
| `request-307-311` | 62 | aprovadas |
| `request-309-collector` | 17 | aprovadas |
| `request-309-crm` | 7 | aprovadas |
| `request-311-transport` | 18 | aprovadas |
| `request-312-1571` | 32 | aprovadas |
| `request-313` | 95 | aprovadas |
| `review-1571` | 16 | aprovadas |
| `hardening-1571` | 32 | aprovadas |
| `permissions-native-1571` | 16 | aprovadas |
| `permissions-mcp-1571` | 16 | aprovadas |

O roteiro `tests/REGRESSAO-1.58.md` separa Core isolado, Core com Google/Meta/LinkedIn e coexistência com MCP. Pipedrive 0.3 não foi ativado no PHP 8.3.6; sua exigência mínima de PHP 8.3.36 permanece pendência de execução nativa nesta entrega. Não foram somados testes existentes apenas no histórico nem resultados publicados pelos mantenedores dos acompanhantes.

### Documentação, falhas intermediárias e limites remotos

`docs-1580.json` contém **1732 assertivas booleanas aprovadas**, mais os metadados `documents=145` e `pages=658`. O total de 1734 entradas no objeto não é uma contagem de testes. A leitura percorreu integralmente o índice e os documentos pela ability pública, conferindo conteúdo, hashes, aliases, contrato 8.23.0, dicionário/inventário, schemas, capacidades, negações de acesso e ausência de HTTP, em WordPress local com a fronteira MCP exercitada. A leitura integral pelo MCP do Site-Teste atualizado continua pendente, pois 1.58.0 não foi instalado nele.

Execuções intermediárias revelaram problemas corrigidos antes do congelamento: tratamento de valor nulo em desfechos, atualização sem mudança no vínculo WhatsApp, validação integral/CAS de URL no candidato de configuração e limite de resumo incluindo o decorador MCP. Também foram corrigidas premissas dos testes: o caso 312 exige Meta ativo e modo de autorização apropriado; o histórico 307 ainda esperava versão antiga e exclusão local anterior ao contrato 1.57.1; o coletor 300 esperava o antigo aviso Slack na terceira falha. Os casos finais acima revalidaram essas fronteiras, sem remover as asserções de persistência, incerteza ou proteção de dados.

**Instalação remota: `bloqueado` antes da escrita.** A revisão automática de aprovação rejeitou `files/write` para colocar temporariamente o instalador em uma pasta pública de uploads, por exposição do pacote sem autorização clara para divulgação pública. Não houve repetição da escrita por outra rota. `plugins/upload` disponível exige URL e `plugins/install` atende ao diretório WordPress.org; não foi encontrada API de instalação privada do pacote que dispensasse o estágio público. A continuação depende de autorização explícita para esse estágio e a implantação.

`evidence/1580/site-install-blocked.json` registra a recusa, `remote_install_performed:false`, ausência de repetição e a resposta de `files/stat` com `f3_files_not_found`: o local de estágio consultado não existe. O Site-Teste permanece no Core 1.57.1, conforme `installed-before-final.json`. **Não há recibo de instalação, pré-imagem/backup de implantação, execução remota 326, escrita real 328, página pública temporária 325 ou homologação nativa Pipedrive/PHP 8.3.36 desta rodada.** Não houve implantação na frota nem publicação GitHub.

O harness remoto foi preparado e passou por 13 verificações estáticas em `site-harness-static.json`; não foi instalado nem executado remotamente. Logo, não há tabela/pasta da fixture remota desta rodada a remover nem prova de execução remota a atribuir a ele. O controle de acesso, prefixo aleatório, isolamento e bloqueio de transportes permanecem no fonte para a etapa autorizada futura. Arquivos de laboratório, dumps, credenciais e logs brutos são excluídos do fonte por seleção do empacotador; `source-selection-review.json` registra a inspeção dessa seleção.

## 5. Banco, preservação e reversão

Mudanças aditivas: diários `f3base_desfechos`, `f3base_conversa_vinculos`, `f3base_qualidade_destinos`, `f3base_wp_mail` e `f3base_caminho_lead`; campos de abandono no registro analítico; novas options de configuração/estado. Dicionário/inventário gerados descrevem o schema final. Desfechos e entrada/MIME sensíveis são cifrados; recibos privados minimizam dados. Datas/valores ausentes não são retroativamente inventados. Não há migração destrutiva de contatos ou reenvio histórico.

A desinstalação preserva as cinco tabelas: desfechos são histórico comercial, vínculos conservam tombstones de privacidade, e filas de wp_mail/qualidade/caminho passam de pendente para suspenso. Desativação remove os hooks novos. Nenhuma tabela nova deve ser eliminada como se fosse cache. Dados do acervo Meta permanecem no produtor; Core não os duplica.

Backup inclui banco, salts/chaves, arquivos e guarda operacional. Antes de restore, pausar/drenar e reconciliar pelo fluxo Core. Voltar somente arquivos para 1.57.1 não desfaz e-mails, mensagens, objetos de CRM, exclusões ou banco; a base anterior não entende diários novos. Não fazer downgrade com trabalho em voo/incerto nem apagar recibos para liberar repetição. Preferir correção adiante.

A prova local de migração, repetição e preservação na reinstalação consta dos dois ciclos nativos da seção 4. Nenhuma pré-imagem ou backup remoto foi criado nesta rodada, pois a implantação não começou. Antes de uma implantação autorizada, o responsável deve obter e identificar a cópia restaurável; rollback de arquivos não equivale à reversão transacional de efeitos externos.

## 6. Pendências de validação e responsáveis

| Responsável | Pendência e critério |
| --- | --- |
| Dono e operador autorizado | Autorizar explicitamente o estágio temporário público do instalador e a implantação no Site-Teste, ou fornecer uma rota privada aprovada; depois conferir backup/pré-imagem, recibo, versão ativa, home/REST, leitura integral da documentação e limpeza. |
| Mantenedor Core / operador | Após implantação autorizada, executar os aceites remotos 325, 326 e 328; a sequência 326 precisa ocorrer automaticamente após confirmação no executor. |
| Mantenedor / operador Pipedrive | Exercitar Pipedrive 0.3 nativamente em PHP >= 8.3.36; sua presença no inventário antigo e os mocks locais não satisfazem esse aceite. |
| Mantenedores Google/LinkedIn | Entregar/validar contrato comercial por ação/etapa e binding descrito nos impactos; 323 permanece bloqueado nesses destinos. |
| Mantenedor Core e responsáveis pelos transportes | Contrato de exclusão individual segura de e-mail/webhook para 322; até lá, saltos bloqueados e aceite integral não concluído. |
| Operador/frota | Teste CRM real só em ctooffice.com.br/korvena.com.br, com negócio/valor/etapa, campos relidos e limpeza comprovada de cada artefato. Não realizado por inferência de fixture. |
| Operador Google | Primeira conversão real 316 aceita com userIdentifiers, conta/ação/termos e consentimento válidos. |
| Operador/frota Meta | Configurar conta/concessão e comparar 30 dias por campanha com Ads Manager, mesmo fuso/moeda/atribuição, incluindo revisita sem duplicação. |
| Operador/frota | Primeiro lead nativo 314, conversa WhatsApp 318, resposta humana 320 e comparação 321/324 com rotas detalhadas. |
| Operador de e-mail | Mensagens recebidas com DKIM/DMARC pass; semana de relatórios sem origem PHP antiga e sem aviso técnico no canal de growth. SMTP aceito não comprova isso. |
| Frota | Próxima troca em lote com provas 326 automáticas; configuração específica das exceções de marca nos sites pertinentes. |
| Dono/frota | Publicação e implantação dos artefatos conforme autorização; fonte permanece com o dono. |

Aceites externos anteriores do GA4/Instagram permanecem separados. Não houve credencial real cadastrada ou renovada para transformar diagnóstico ausente em pronto. Coberturas não exercitadas estão explicitadas na seção 4, incluindo navegador real, fornecedor, PHP 8.3.36 com Pipedrive e caches externos. O piso Core 7.1.2/8.3.6 foi validado localmente.

## 7. Credenciais e operação

Nenhum valor secreto integra este relatório ou os pacotes. Configuração administrativa via tela Core e `config-core-*`, com revisão; credenciais gerenciadas usam o fluxo próprio de validação/cifra.

- Caixa: `f3base_email_site`, senha gerenciada da caixa, endereço/usuário/servidor/porta/TLS/nome e prova SMTP vigente antes de `wp_mail_pela_caixa`; `f3base_avisos_tecnicos.email` vazio usa `admin_email`.
- Google: credenciais e termos/conta/ação de conversões otimizadas no MCP Google. Core não recebe token; negocia capacidade e referência de destino. Sem prova válida, bloqueio explícito.
- LinkedIn: conexão/concessão e `rw_conversions`, regra API e ação própria; não ampliar permissão ou trocar regra silenciosamente.
- Meta Ads: conexão/conta selecionada no produtor, `ads_read` e concessão administrativa do consumidor Core. A leitura local concedida não exige renovar token para acessar fatos já retidos; contrato ainda revalida origem/identidade/concessão.
- Pipedrive: token/conta/catálogos sob Core, usuários humanos selecionados e campos enum/set mapeados. Webhook usa segredo próprio existente; sua presença não prova evento entregue.
- Slack: app/escopos de leitura de thread, usuários e exclusão autoral para os fluxos respectivos. Sem autorização, leitura/teste bloqueia; não usar webhook sem recibo como se fosse app apagável.

As instruções de credenciais não autorizam o agente a habilitar destinos, criar concessões ou testar contas de produção fora do escopo expressamente autorizado.

## 8. Artefatos, identidade e distribuição

Apenas o instalador é instalável. Fonte inclui runtime, build/testes/locks, entradas rastreadas, evidências sanitizadas, histórico e relatório pré-fechamento; sem ZIP aninhado, laboratório, node_modules, dump ou segredo. O empacotador do fonte compara integralmente runtime/instalador, mantém manifesto dos arquivos e usa construção determinística; sua identidade final é preenchida somente neste relatório externo, após fechar o ZIP.

| Arquivo final | Bytes | SHA-256 |
| --- | ---: | --- |
| `base-site-core-fator3-1.58.0-instalador.zip` | 2816484 | `71bf6497a2f2e2c605baf64f0f82c273201915039506b58ac220fc572afbd5e4` |
| `base-site-core-fator3-1.58.0-fonte.zip` | 4690094 | `279b9609867b7459347d7bf1434b536073eb20fb2b996b4fdbcd6e644e37b50c` |

Relatório: `base-site-core-fator3-1.58.0-relatorio.md`. Complementos substantivos: impactos Google e LinkedIn citados na seção 2, ambos revisão 2. A cópia interna preserva o conteúdo funcional e remete ao relatório externo para a identidade final do fonte. Os dois marcadores do fonte nessa cópia são deliberados e evitam autorreferência circular. Não reabrir o fonte para inserir seu próprio hash.

Entrega **`com-pendencias`**, adequada ao escopo local validado. A implantação permanece bloqueada pela aprovação do estágio público, e os limites 322/323 e aceites externos permanecem abertos. Nenhuma publicação GitHub ou implantação na frota decorre automaticamente da entrega. Conferir tamanho/hash antes de instalar e preservar a futura pré-imagem até o aceite operacional.
