# Fechamento documental — 0.24.0

Catálogo e opções são gerados do runtime. Guia, especificação do acervo, SDK, exemplos e índice MCP usam a mesma versão. Dados PHP protegidos levam a documentação no instalador; o fonte contém os editáveis e geradores. Candidato aprovado é promovido sem recompressão. O relatório no fonte antecede seu fechamento; bytes e SHA finais do fonte constam somente no relatório externo. Nenhum ZIP aninhado.
