# Guia — Fator3 MCP Google 0.22.0

Instalação limpa ou atualização direta de 0.21.0, sem desinstalar. WordPress 7.1.2+, PHP 8.3.6+. Preserve banco, recibos, credenciais e salts; confira o SHA-256 do instalador. Não há conversão ou concessão automática na atualização.

## Versão 0.22.0 — Pedidos Core 323

Base direta 0.21.0. O contrato opcional `site-conversion-delivery/1.2.0` atende ações Google Ads comerciais por etapa, com concessão independente para `site-core-quality` / `crm_stage`. Mantém aquisição 1.0/1.1, conversões otimizadas e pedidos Google 39–42. São 294 habilidades (113 leitura, 181 escrita), 38 opções, sem nova tabela ou segredo.

Core 1.58.0 implementa o consumidor de conversões otimizadas (Core 316) e o envio comercial (Core 323). Acompanhantes recebidos: MCP 0.34.0, Meta 0.13.0, LinkedIn 0.11.0; Pipedrive 0.2.0 disponível em pacote. O Site-Teste é inventariado separadamente. Nenhum mínimo próprio ou ordem de ativação dos acompanhantes foi imposto.

A aceitação inicial pela Data Manager é `incerto`. O produtor fornece `site-stage-conversion-reconcile/1.0.0`, consulta sem reenvio. Core 1.58.0 original ainda não consome essa confirmação comercial; o fonte desta entrega inclui implementação proposta em patch para esse consumidor, ensaiada separadamente. Não confundir esse ensaio com o pacote Core original nem com implantação no Site-Teste.

Comece por `google/readiness-status`. GA4 seleciona seu destino pelo stream configurado; painel e descrições estão em português.

## Concessão comercial por ação

Em Ferramentas → Fator3 MCP Google → Conversões, informe o resource name exato em “Ações comerciais”. Conceda e depois verifique. A ação precisa ser UPLOAD_CLICKS ativa, diferente da aquisição. Use a revisão devolvida pela última escrita em toda alteração seguinte.

Equivalentes MCP, com IDs sintéticos:

```json
{"ability":"google/stage-conversion-status","parameters":{}}
{"ability":"google/configure-stage-conversion","parameters":{"expected_revision":"SHA256_ATUAL","action":"customers/1234567890/conversionActions/222","enabled":true}}
{"ability":"google/verify-stage-conversion","parameters":{"expected_revision":"SHA256_APOS_CONCESSAO","action":"customers/1234567890/conversionActions/222"}}
```

`stage-conversion-status` é local e não renova a prova. `configure-stage-conversion` não faz HTTP. `verify-stage-conversion` consulta ação/termos e faz validateOnly; grava prova e auditoria, sem conversão real. A referência é vinculada a conta, ação, consumidor, finalidade, conexão, identidade/política e geração. `enabled:false` revoga; `renew_grant:true` cria geração nova e exige nova prova. Nenhuma concessão da aquisição é herdada. Limite de 100 ações armazenadas por conexão, incluindo revogadas. O recurso deve estar autorizado pela política Ads da conexão.

A prova expira em 24 horas; a próxima renovação é programada para 12 horas. O cron tenta até duas ações devidas por conexão, respeitando o orçamento, com backoff entre 5 minutos e uma hora na falha. Cada tentativa registra origem, fase e diagnóstico sanitizado. Renovação não muda destination_ref. Troca de identidade, política ou aquisição pode invalidar a referência: não reaproveitar recibo nem gerar outro evento para contornar o bloqueio.

## Contrato PHP 1.2

```php
$a = apply_filters('f3base_conversoes_adaptador', null, 'google_ads',
    'site-conversion-delivery/1.2.0', [
        'consumer_id' => 'site-core-quality', 'purpose' => 'crm_stage',
        'action' => 'customers/1234567890/conversionActions/222',
    ]);
$cap = $a->capabilities(); // somente leitura local
```

Exija ready global e de `actions[resource]`, finalidade correta e destination_ref não vazio. `acquisition_action` é o resource completo da aquisição, ou null somente se sua ausência foi comprovada em todas as conexões legíveis. Campo omitido, vazio, inválido ou ações de aquisição divergentes bloqueiam. Duas conexões com concessão para a mesma ação bloqueiam a seleção. O consumidor deve revalidar consentimento e elegibilidade imediatamente antes do envio; o Google valida contrato, tempo, identidade e destino novamente antes de cada chamada HTTP.

`sendBound(payload,destination_ref)` aceita somente o [schema publicado](stage-conversion-payload.json). Regras adicionais: order_id igual a event_id; occurred_at RFC3339 válido, não futuro e no máximo sete dias; um clique no máximo; sem clique exige email/telefone válido e enhanced_leads.ready da ação. Valor é sempre zero e moeda BRL. A verificação recusa ação que force valor/moeda padrão incompatível, sem modificar a configuração Google. Aquisição mantém seu comportamento anterior.

```json
{"contract":"site-conversion-delivery/1.2.0","purpose":"crm_stage","record_id":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","stage_id":"qualificado","action":"customers/1234567890/conversionActions/222","event_id":"f3q-exemplo-estavel","order_id":"f3q-exemplo-estavel","occurred_at":"2026-10-28T10:00:00Z","click_ids":{"gclid":"exemplo"},"ad_user_data":"GRANTED","value":0,"currency":"BRL","user_data":{"email":"sintetico@example.test"}}
```

Dados e hashes pessoais só existem em memória/HTTP; recibos guardam metadados e hash do contexto do evento, sem email, telefone ou clique. event_id é a identidade da conversão; record_id identifica o contato. A deduplicação persiste por site/ação/evento, inclusive após renovar a concessão. A mesma identidade com contato, etapa ou data diferentes é conflito. Nunca apagar recibos para repetir envio.

## Confirmação assíncrona

`cap.async_reconciliation` anuncia `site-stage-conversion-reconcile/1.0.0`. No mesmo adaptador, use `reconcileBound(event_id,destination_ref)`. A consulta não recebe dados pessoais nem envia outro evento. Exige concessão e identidade atuais; a prova de envio expirada não impede consultar um recibo previamente reservado. Somente um evento confirmado no destino exato produz entregue. Ausência, timeout, processing, erro desconhecido ou contagem diferente ficam incertos. Recusado exige non_delivery_proven=true. Cooldown inicial 1800 segundos e backoff do recibo são respeitados no produtor.

```json
{"ability":"google/reconcile-stage-conversion","parameters":{"action":"customers/1234567890/conversionActions/222","event_id":"f3q-exemplo-estavel","destination_ref":"google:crm_stage:REFERENCIA_RESERVADA"}}
```

Essa operação administrativa atualiza só o recibo Google. Core 1.58.0 original deixa seu recibo incerto; o patch de integração no fonte acrescenta consulta periódica sem reenviar. Não instalar uma versão Core inexistente nem usar esse patch como pacote oficial. A homologação Google real requer conta/ação concedidas e consentimento adequado; HTTP sintético não comprova atribuição comercial.

## Recuperação e compatibilidade

Estado novo fica em stage_actions na opção existente de conversões. Não há migração destrutiva, tabela ou segredo novo. Antes de reverter para 0.21.0, desligue os destinos comerciais no Core e preserve/reconcilie recibos; a versão anterior não conhece 1.2. Reverter arquivos não desfaz efeitos remotos. Os [contratos de aquisição](CONVERSION-DELIVERY-CORE-140.md), [SDK público](SDK-PHP.md), leituras compactas e identidade pública SA continuam disponíveis. Core 1.58.0 já atende o consumo enhanced 1.1; GA4 reader continua independente.
