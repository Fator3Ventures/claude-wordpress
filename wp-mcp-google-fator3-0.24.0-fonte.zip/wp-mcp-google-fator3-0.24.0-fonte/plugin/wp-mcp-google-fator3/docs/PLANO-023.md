# Plano Google 0.23.0

29/10/2026, America/Sao_Paulo. Base exata 0.22.0 preservada. Pedidos Google 43–46. Norma comum revisão 5. Acompanhantes recebidos: Core 1.60.0, MCP 0.36.0, Meta 0.14.0, LinkedIn 0.12.0. Identidades em received.json na raiz do fonte.

1. Transformar heurísticas de formato SA em avisos, mantendo rejeição estrutural, token_uri restrito ao host Google, chave OpenSSL válida e validação remota antes de substituir a chave salva.
2. Acrescentar coleta Ads diária, revisita e backfill por conta autorizada; armazenamento cifrado e permanente; publicação de revisões por recorte, retomada e cobertura; SDK local com concessão por consumidor/conta/dataset.
3. Acrescentar GSC query-page-day 1.1 com concessão própria, mantendo o contrato 1.0. Paginação, cobertura e exclusão de consultas anonimizadas explícitas.
4. Produzir adaptador Core separado e testes com Core 1.60 original/consumidor proposto, sem aguardar outra sessão e sem instalar Core no ambiente compartilhado.
5. Executar regressões, instalação limpa, upgrade direto 0.22, isolamento, ordem Google primeiro e documentação. Atualizar somente Google no Site-Teste com o ZIP final, preservando acompanhantes e configuração.
6. Fechar instalador, relatório pré-fonte, fonte e relatório externo, sem ZIP aninhado ou segredo. Homologação com contas Ads/GSC reais será distinguida das provas sintéticas.

Impacto substantivo emitido antes da implementação: wp-mcp-google-fator3-0.23.0-impacto-base-site-core-fator3.md, revisão 1, Core 337/340/342. Não emitir impactos para simples atualização de pacote. Core 1.60 incorpora a reconciliação comercial da rodada anterior; confirmação e evidência ficam no relatório principal.
