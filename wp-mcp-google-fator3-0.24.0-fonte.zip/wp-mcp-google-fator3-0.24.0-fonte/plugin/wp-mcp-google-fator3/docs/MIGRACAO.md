# Atualização e recuperação — 0.24.0

Instalação limpa ou atualização direta da 0.23.0, sem desinstalar. Faça backup de arquivos, banco e salts. Slug, tabelas, formato cifrado, opções, contratos e concessões são preservados. Nenhuma migração, nova tabela, segredo, coleta ou concessão automática.

Core 1.61.1 já incorpora os consumidores Ads/GSC. Configure f3base_google_ads_acervo, preservando a opção de conversão/tag f3base_google_ads. Não copie integration/core337-340-342 nem integration/core323 sobre o Core atual. A proposta histórica tem bootstrap desativado. Veja [CORE-ACERVOS.md](CORE-ACERVOS.md). Referência da rodada: MCP 0.37.0, Meta 0.16.0 e LinkedIn 0.13.0; nenhum mínimo ou ordem artificial foi criado.

Rollback para 0.23.0 restaura os arquivos da base, que compreende os mesmos dados/contratos. Preserve banco, salts, acervo, revisões, checkpoints e concessões. A volta não desfaz chamadas Google, conversões ou mensagens já aceitas. Não repetir conversões para testar rollback. A orientação antiga sobre o adaptador não deve ser seguida após a reversão.

Em falha de coleta, consulte ads/archive-status, política, identidade e cron. Reautorize após mudança de seleção/revisão e retome o recorte. Falha na publicação conserva a visão anterior. Cursor vencido/revisão alterada exige reiniciar o dia; não somar revisões. Retenção permanente exige acompanhamento da capacidade e backup.
