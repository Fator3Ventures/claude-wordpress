# Validação — 0.24.0

A rodada compara o runtime à base exata 0.23.0 e valida o consumidor entregue Core 1.61.1, MCP 0.37.0, Meta 0.16.0 e LinkedIn 0.13.0. Instalação limpa/isolada, atualização autenticada, preservação de dados e concessões, rollback/reaplicação e leitura documental são executados em WordPress descartável. Mínimos próprios: WordPress 7.1.2/PHP 8.3.6; combinação adicional WordPress 7.1.3/MySQL 8.0.46.

A fronteira usa o SDK real e o Core original, com HTTP Google sintético: 30 dias de custos/cliques, GCLID exato, persistência em sessões/contatos, revogação, GSC consulta com publicação atômica e histórico anterior preservado. O bootstrap da proposta histórica é verificado como inerte antes/depois do Core nativo.

Resultados executados, contagens, ferramentas indisponíveis e hashes ficam em evidence/024 e no relatório externo. Evidence/023 e anteriores são históricos e não integram os totais desta rodada. A leitura e instalação no Site-Teste são provas separadas. Aceites com contas Ads/GSC reais em ctooffice permanecem pendentes.
