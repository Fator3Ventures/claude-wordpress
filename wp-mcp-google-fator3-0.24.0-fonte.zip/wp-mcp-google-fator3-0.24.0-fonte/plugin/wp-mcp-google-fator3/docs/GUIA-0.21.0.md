# Guia — Fator3 MCP Google 0.21.0

Atualização direta 0.20.0 ou instalação limpa. Preserve arquivos, banco e salts; confira o hash do instalador. Mínimos próprios: WordPress 7.1.2 e PHP 8.3.6. Pipedrive 0.2.0 possui mínimo PHP próprio superior. Não desinstale para atualizar.

Comece por `google/readiness-status` para verificar bloqueios locais. GA4 seleciona o destino pelo stream configurado; a interface e as descrições de operação estão em português.

## Leituras curtas e identidade da conexão

```json
{"compact":true,"fields":["audit_retention","job_detail_days","job_summary_days"]}
```

Use a entrada acima em `google/configuration-schema`. `fields` usa IDs curtos exatos do catálogo de opções e recusa nomes desconhecidos. `compact` retorna `options[id]` com `name` (option_name), `type`, `default` e `value` efetivo; segredos recebem `[redigido]`. `include_values:false` omite `value`; `values_complete:false` informa leitura não comprovada. Sem compact, a resposta completa mantém o formato; fields restringe suas opções. O contrato de configuração continua 4.0.0, com campos de entrada aditivos.

`google/status {"compact":true}` retorna canal, serviços, identidade e prontidão de conversões. `scope:all_connections` resume todas as conexões; live não é admitido nesse escopo. Somente `live:true` na conexão selecionada solicita token. Nenhuma dessas leituras atualiza a prova do destino.

`google/list-connections` lista `client_email` e `project_id` por conexão; `google/integration-status` fornece os mesmos campos na conexão selecionada, inclusive compact. São lidos da chave SA salva, independentemente de a autenticação selecionada ser OAuth; não representam a candidata nem comprovam que a chave está ativa/válida no Google. Campos ausentes, inválidos ou ilegíveis retornam null. Nunca são retornados private_key, private_key_id ou client_id. Para renomear, use `google/rename-connection` com a revisão atual e o rótulo `<client_email> · <project_id>`; não deduza esses valores de logs.

## Conversões otimizadas de leads — contrato 1.1.0

Configure/verifique o destino por `google/configure-conversion-delivery` e `google/verify-conversion-delivery`. A verificação lê a ação UPLOAD_CLICKS ativa, seu valor/moeda, valida o destino Data Manager sem coletar e consulta por GAQL os termos de dados do cliente e a habilitação de conversões otimizadas. `enhanced_leads` em capabilities e status informa conta, ação, ready, reason, checked_at, expires_at e diagnóstico. Sem observação válida retorna `enhanced_leads_unverified`; termos recusados ou recurso desligado têm motivos próprios. A prova expira em 24h; a renovação é agendada para 12h. A prontidão observada não comprova tag, consentimento individual, atribuição nem entrega de contato real.

O consumidor solicita o adaptador no filtro `f3base_conversoes_adaptador`, target `google_ads`, contrato `site-conversion-delivery/1.1.0`. O contrato 1.0.0 permanece aceito, e capabilities.contract reflete exatamente a versão solicitada para preservar Core 1.57.1. `supported_contracts` anuncia ambas. `enhanced_leads.supported` anuncia suporte ao payload; `ready` é o resultado atual do destino. `ga4` não aceita dados pessoais.

No payload de conversão Ads, acrescentar `user_data:{email:"...",telefone:"+55..."}` somente com consentimento elegível. Ambos são opcionais entre si; ao menos um valor válido é necessário quando user_data estiver presente. Telefone exige DDI E.164; dados/hash preexistentes e outros campos são recusados. Normalização usa a implementação Google existente, incluindo remoção de pontos em Gmail, antes de SHA-256. Com clique, envia ambos os tipos de identificador. Sem clique, aceita `click_ids:{}` ou campo omitido, somente com prontidão. Mais de um clique permanece ambíguo. Dados fornecidos sem prontidão geram `enhanced_leads_not_ready`, sem envio; dados inválidos geram `enhanced_leads_user_data_invalid`. Não há descarte silencioso dos dados para enviar apenas o clique.

O transporte vigente é **Data Manager v1**: os hashes intermediários hashedEmail/hashedPhoneNumber são enviados como `userData.userIdentifiers[].emailAddress/phoneNumber`, `encoding:HEX`. Nenhum ClickConversion adicional é criado. Identidade/order_id, destino vinculado, prazo de 90 dias, consentimento GRANTED e recibo durável permanecem. O primeiro retorno é incerto/pending; somente a reconciliação individual confirma entrega. Repetir com o mesmo record_id consulta o recibo local e não reenvia. Nunca transformar timeout ou recibo desconhecido em nova conversão.

Instalar Google primeiro. Core 1.57.1 continua compatível e mantém sua exigência de clique; Core 316 deve consumir a nova capacidade para fornecer email/telefone e habilitar o caminho sem clique. Esta entrega não muda a coleta de dados, tags ou consentimento do Core. Primeiro contato real da frota permanece um aceite coordenado.

## Renovação GA4 e auditoria

`google/conversion-delivery-status` retorna por destino `renewal`: phase, provider_error, last_at, result, code, next_attempt, failures, attempts, attempt_count, cycle_started_at, proof_status, unverified_since e unverified_seconds. Fases: `ga4_stream_read`, `ga4_secret_read`, `ga4_secret_match`, `ga4_debug_validation`; `execution` para falha no orçamento/execução. provider_error preserva HTTP, estado/motivo e mensagem limitada/sanitizada, sem corpo de solicitação, token, email, telefone ou hash pessoal.

Cada tentativa executada é registrada como `conversion:verification` no `google/audit`, target ga4/google_ads, extra.origin executor/administrator, status success/error e diagnóstico. A configuração guarda as últimas 50 tentativas do ciclo, com instante/código e audit_marker. `attempt_count`, `attempts_omitted` e `attempts_complete` tornam explícito o recorte. Para o histórico completo, pagine `google/audit` filtrando action `conversion:verification`, target e período desde cycle_started_at, respeitando a política de retenção escolhida. Após sucesso, o ciclo concluído permanece visível; a próxima tentativa inicia novo ciclo. Não reconstruímos tentativas anteriores à 0.21.0.

O tempo sem prova conta desde a expiração conhecida até a consulta ou o sucesso da renovação. Se nunca houve prova, é null. Sucesso preserva `last_unverified_period` quando houve lacuna. `valid` descreve validade temporal; concessão/identidade continuam sendo conferidas por ready/reason. Incidentes conservam a causa sanitizada; sucesso resolve sem apagar o diagnóstico anterior. Auditoria falha é indicada por audit_success, sem inventar persistência.

## Retenção, SDKs e recuperação

Retenção zero continua sem prazo; valores explícitos são preservados. GA4 `ga4-reader/1.0.0` e GSC `search-console-reader/1.0.0` não mudam. Core 1.57.1 já registra o consumidor GA4: configure propriedade e ativo no Core antes de conceder pelo Google, pois a concessão exige callback pronto. Leia o [SDK](SDK-PHP.md).

Sem migração destrutiva. Observações novas ficam na opção existente de conversões; auditoria usa a tabela atual. Reverter arquivos não desfaz envio nem remove recibos. Voltar para 0.20.0 remove suporte a user_data e os novos diagnósticos; suspenda o consumidor Core novo antes da reversão e preserve/reconcilie estados incertos. Instalação e status não enviam contato real.
