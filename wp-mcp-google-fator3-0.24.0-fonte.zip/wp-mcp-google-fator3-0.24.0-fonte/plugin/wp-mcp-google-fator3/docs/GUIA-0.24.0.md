# Guia — Fator3 MCP Google 0.24.0

Instale sobre a 0.23.0, sem desinstalar, ou em WordPress limpo. PHP 8.3.6+, WordPress 7.1.2+. Preserve banco e salts; confira o SHA-256. A atualização não cria concessões nem começa a coletar dados automaticamente.

## Versão 0.24.0 — Integração Core 1.61.1

Atualização direta da 0.23.0. Guia instalado da integração Ads/GSC com o Core entregue, configuração do leitor corrigida e proposta histórica desativada. Permanecem 298 habilidades (114 de leitura, 184 de escrita), 41 opções e todos os contratos. Pedidos Google 43–46 estão preservados: avisos de formato da Service Account com validação remota; acervo Ads cifrado permanente e leitor local `google-ads-reader/1.0.0`; GSC `search-console-reader/1.1.0` consulta/página/dia com concessão própria e GSC 1.0 independente.

Acompanhantes desta rodada: Core 1.61.1, MCP 0.37.0, Meta 0.16.0 e LinkedIn 0.13.0. O Core já incorpora os consumidores Ads/GSC e a reconciliação comercial. Configure o leitor por `f3base_google_ads_acervo`; preserve `f3base_google_ads` para conversões/tag. Não reaplique os adaptadores históricos Core323/337/340/342. A operação integrada está em CORE-ACERVOS.md; resultados e limites constam do relatório externo. Somente Google é atualizado por esta release.

Comece por `google/readiness-status`. A seleção GA4 continua vinculada ao stream configurado; painel e descrições estão em português. A prontidão local não comprova acesso remoto à conta.

## Credenciais — Pedido 43

Em Ferramentas → Fator3 MCP Google → Conexão, importe a chave. `project_id` vazio, `private_key_id` fora de 40 hexadecimais, e-mail fora de `.iam.gserviceaccount.com` e PEM com cabeçalho diferente geram avisos com código/motivo. A troca JWT de token no Google decide a validade. Recusa remota conserva a chave ativa e não grava uma candidata inválida. Nenhum aviso contém a chave privada.

JSON inválido, tipo diferente de `service_account`, ausência de e-mail/chave/token_uri, token_uri fora de `https://oauth2.googleapis.com/` e chave ilegível pelo OpenSSL continuam recusados antes de HTTP. A mesma identidade pode rotacionar a chave; mudança de identidade continua pelo plano confirmado já existente. Formato atípico não dispensa autorização ao recurso.

## Acervo e consulta orgânica — Pedidos 44–46

Na aba Acervo Ads, selecione uma conexão com Ads em leitura ou escrita, developer token e política permitindo a conta anunciante. Informe a conta sem hífens, datasets, revisita e backfill; marque a concessão. A API confirma conta, moeda e fuso. Uma conta gerenciadora não substitui a conta anunciante. A leitura para cada plugin é outra concessão na mesma aba. Os clientes devem registrar-se antes para aparecer no formulário.

Na aba Search Console, conceda separadamente `search-console-reader/1.1.0` ao consumidor registrado. Sua concessão 1.0.0 não autoriza consultas individuais. A leitura retorna cursores até o fim observável da API e informa anonimização/limites, sem fabricar contagens de consultas ocultas.

Consulte [campos, exemplos e limites](ACERVO-ADS-GSC.md), [SDK PHP](SDK-PHP.md), [recuperação](MIGRACAO.md) e [cron](ACOMPANHAMENTO-CRON.md). Conversões comerciais e aquisição continuam conforme [GUIA-0.22.0.md](GUIA-0.22.0.md), como capacidades anteriores; a base desta atualização é 0.23.0.


Fluxo atual do consumidor incorporado: [Core Ads/GSC](CORE-ACERVOS.md). Não carregar a proposta histórica sobre o Core 1.61.1.
