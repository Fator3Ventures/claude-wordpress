# Plano — Google 0.24.0

29/10/2026, America/Sao_Paulo. Base publicada Google 0.23.0; alvo previsto 0.24.0, instalador ainda não gerado. Rodada de alinhamento operacional e validação da integração entregue Core 1.61.1 com Meta 0.16.0, MCP 0.37.0 e LinkedIn 0.13.0.

## Escopo e decisões

Pedidos Google 43–46 já implementados na base; a lista mais recente localizada é a mesma de 29/10 03:04. Nenhum pedido 47 ou nova função foi recebido. Impacto Core 1.61.1→Google revisão 2 pede corrigir a proposta/referência de configuração para f3base_google_ads_acervo e não reaplicar o adaptador antigo. O runtime Google não exige novo contrato.

Atualizar a documentação instalada com o consumidor efetivo, concessões independentes, schemas reais e critérios de aceite. Corrigir o nome na proposta separada; impedir seu bootstrap de redeclarar classes ou adicionar hooks se o Core já incorporou os consumidores. Preservar seu caráter histórico: não é caminho de implantação no Core 1.61.1. Atualizar exemplos, versão e documentação compilada. Nenhuma migração, coleta, credencial ou concessão automática.

Esta nova rodada recebe minor 0.24.0 por solicitação de nova versão, com conteúdo instalado alterado; correções adicionais neste ciclo usarão patch conforme orientação do dono. Não representa nova API de coleta. Normas r4 de project_sources lidas; r5 preservadas na base prevalecem para registrar respostas no relatório principal. Não emitir novo impacto só para responder ou encerrar o recebido.

## Provas previstas

Comparação exata do runtime 0.23; schemas preservados; geradores/lint; unitários da base; WordPress limpo/isolado nos mínimos; atualização autenticada 0.23→0.24 com acervo/grants preservados, rollback e reaplicação. Consumidor Core 1.61.1 real com HTTP Google sintético: 30 dias, custo/cliques, GCLID, sessões/contatos, revogação, GSC consulta e publicação atômica. Conferir proteção do bootstrap histórico e preservação das conversões Core. Testar documentação via MCP e instalar somente Google no Site-Teste. Homologação Ads/GSC real em ctooffice permanece com operador, sem afirmar aceite por fixtures.

## Encaminhamentos

Nenhum novo pedido ao Core/Meta/MCP/LinkedIn identificado no planejamento. Atendimento ao impacto recebido será documentado no relatório principal. Se a integração reproduzir um defeito que exija mudança alheia, emitir impacto substantivo antes de implementar a fronteira.
