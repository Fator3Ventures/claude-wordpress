# Guia — Fator3 MCP Google 0.23.0

Instale sobre a 0.22.0, sem desinstalar, ou em WordPress limpo. PHP 8.3.6+, WordPress 7.1.2+. Preserve banco e salts; confira o SHA-256. A atualização não cria concessões nem começa a coletar dados automaticamente.

## Versão 0.23.0 — Pedidos Google 43–46

Base direta 0.22.0. São 298 habilidades (114 de leitura, 184 de escrita) e 41 opções de configuração. As quatro heurísticas de formato da Service Account geram avisos; a validação remota continua obrigatória antes da gravação. Há acervo Ads cifrado permanente, coleta diária autorizada por conta e leitor local `google-ads-reader/1.0.0`. O leitor GSC `search-console-reader/1.1.0` acrescenta consulta/página/dia com concessão própria, preservando 1.0.0.

Acompanhantes recebidos e usados na bancada: Core 1.60.0, MCP 0.36.0, Meta 0.14.0 e LinkedIn 0.12.0. O inventário remoto é separado no relatório. Core 1.60.0 já incorpora a reconciliação comercial da 0.22; o patch histórico Core323 não deve ser reaplicado. Os novos consumidores opcionais Core337/340/342 estão em fonte separado para incorporação. Nenhum acompanhante é atualizado por esta release.

Comece por `google/readiness-status`. A seleção GA4 continua vinculada ao stream configurado; painel e descrições estão em português. A prontidão local não comprova acesso remoto à conta.

## Credenciais — Pedido 43

Em Ferramentas → Fator3 MCP Google → Conexão, importe a chave. `project_id` vazio, `private_key_id` fora de 40 hexadecimais, e-mail fora de `.iam.gserviceaccount.com` e PEM com cabeçalho diferente geram avisos com código/motivo. A troca JWT de token no Google decide a validade. Recusa remota conserva a chave ativa e não grava uma candidata inválida. Nenhum aviso contém a chave privada.

JSON inválido, tipo diferente de `service_account`, ausência de e-mail/chave/token_uri, token_uri fora de `https://oauth2.googleapis.com/` e chave ilegível pelo OpenSSL continuam recusados antes de HTTP. A mesma identidade pode rotacionar a chave; mudança de identidade continua pelo plano confirmado já existente. Formato atípico não dispensa autorização ao recurso.

## Acervo e consulta orgânica — Pedidos 44–46

Na aba Acervo Ads, selecione uma conexão com Ads em leitura ou escrita, developer token e política permitindo a conta anunciante. Informe a conta sem hífens, datasets, revisita e backfill; marque a concessão. A API confirma conta, moeda e fuso. Uma conta gerenciadora não substitui a conta anunciante. A leitura para cada plugin é outra concessão na mesma aba. Os clientes devem registrar-se antes para aparecer no formulário.

Na aba Search Console, conceda separadamente `search-console-reader/1.1.0` ao consumidor registrado. Sua concessão 1.0.0 não autoriza consultas individuais. A leitura retorna cursores até o fim observável da API e informa anonimização/limites, sem fabricar contagens de consultas ocultas.

Consulte [campos, exemplos e limites](ACERVO-ADS-GSC.md), [SDK PHP](SDK-PHP.md), [recuperação](MIGRACAO.md) e [cron](ACOMPANHAMENTO-CRON.md). Conversões comerciais e aquisição continuam conforme [GUIA-0.22.0.md](GUIA-0.22.0.md), como capacidades anteriores; a base desta atualização é 0.22.0.
