# Acompanhamento operacional — Google 0.23.0

## Versão 0.24.0 — Integração Core 1.61.1

Atualização direta da 0.23.0. Guia instalado da integração Ads/GSC com o Core entregue, configuração do leitor corrigida e proposta histórica desativada. Permanecem 298 habilidades (114 de leitura, 184 de escrita), 41 opções e todos os contratos. Pedidos Google 43–46 estão preservados: avisos de formato da Service Account com validação remota; acervo Ads cifrado permanente e leitor local `google-ads-reader/1.0.0`; GSC `search-console-reader/1.1.0` consulta/página/dia com concessão própria e GSC 1.0 independente.

Acompanhantes desta rodada: Core 1.61.1, MCP 0.37.0, Meta 0.16.0 e LinkedIn 0.13.0. O Core já incorpora os consumidores Ads/GSC e a reconciliação comercial. Configure o leitor por `f3base_google_ads_acervo`; preserve `f3base_google_ads` para conversões/tag. Não reaplique os adaptadores históricos Core323/337/340/342. A operação integrada está em CORE-ACERVOS.md; resultados e limites constam do relatório externo. Somente Google é atualizado por esta release.
## Acervo Ads

O mesmo evento WP-Cron de minuto aciona o coletor Ads após o executor de jobs. Cada conta tem plano diário de ontem/revisitas e backfill. Até quatro contas por passagem e uma página por conta, sob orçamento cooperativo de 20 segundos. O cron assume somente o administrador que concedeu a coleta, revalida identidade/canal/política e restaura o usuário anterior. Falhas deferem o recorte com espera de 5 minutos até 6 horas, sem bloquear outros datasets. `ads/archive-status` informa progresso e quantidade de recortes deferidos. O status não agenda nem coleta.

O coletor não é um job da API antiga `google/list-jobs`; seu estado fica no acervo. WP-Cron depende de tráfego ou de cron do servidor. Retomar chamadas `ads/archive-collect` também é possível.

## Passagem, histórico e cobertura

`google/status.cron` mantém `ultima_cli`, `ultima_http`, `ultima_manual`, `last_pass`, `cron_servidor_ativo`, `executor`, `passagens_24h` e a manutenção 2.0.0. CLI observada nas últimas duas horas define `server-cron`; a evidência não comprova crontab instalado ou aprovação dos trabalhos. Uma origem não sobrescreve a outra.

`google/executar-vencidos` e `wp mcp-google run-due` retornam cessão normal com `success:true`, `state:yielded`, `work_success:null`, zero itens próprios e `connection_examined:false`. Isso significa que outra passagem possui a admissão. O CLI encerra sem erro nesse caso. Falha real de leitura, escrita ou posse conserva o código e a saída de erro.

`history_status` é `confirmed` quando o evento/projeção foram confirmados, `pending` quando existe fonte durável para reconciliação e `unconfirmed` quando a prova é insuficiente. Os resultados e contadores do trabalho ficam preservados. Repetir uma escrita remota para corrigir histórico é proibido. A próxima execução autorizada reconcilia até 20 fontes pendentes por conexão, sem executar seu trabalho novamente. Leitura de status pode reconstruir projeções somente em memória.

`observability_error` é falha ativa. `last_observability_error` conserva a identidade original; `resolved_at` e `resolved_by` comprovam resolução. A confirmação compara a identidade sob a mesma trava usada por novas falhas. Idade, outra conexão, passagem apenas iniciada, cessão e sucesso HTTP isolado não limpam o erro. Manutenção conserva seu próprio resultado. Falhas atuais e sua identidade são preservadas na atualização.

`history_pending`, `coverage_gap` e `truncated_in_window` mantêm as lacunas visíveis. `window_complete:false` não deve ser substituído por aprovação só porque o erro ativo ficou nulo. A marca limitada de lacuna conserva a última ocorrência não confirmada na janela de 24 horas; falha em gravá-la é informada pela chamada quando disponível. Ausência de telemetria não comprova ausência de execução.

## Avisos nativos WordPress

O WordPress escreve a linha `could_not_set` antes de chamar `cron_reschedule_event_error` ou `cron_unschedule_event_error`. O código traduz um retorno falso de persistência; sozinho não distingue falha real, ausência de alteração e disputa. A 0.12.0 não suprime logs. Correlação de horários CLI/HTTP não demonstra a causa de cada aviso.

`cron.scheduling` tem contrato **2.0.0**, escopo **site**. A lista permitida contém `f3_mcp_google_jobs_tick`, `f3_mcp_google_maintenance` e `f3_mcp_google_storage_step`. O marcador `f3_mcp_cron_observed` pertence ao MCP 0.22.0 (`CronMarker`, contrato `mcp-cron-marker/2`); ganchos `f3base_` pertencem ao Core.

Cada observação contém gancho, operação, origem, `target_at` quando conhecido, recorrência/intervalo, assinatura dos argumentos, `at`, idade, `original_code`, `read_success`, `postcondition`, `state`, `diagnostic_persisted` e eventual `diagnostic_error_code`. Argumentos brutos, credenciais e eventos alheios não são expostos. `observations` preserva o último estado por gancho/origem/operação; `active_errors` contém erros por intenção; `last_errors` conserva histórico limitado. Há até 100 intenções ativas; `untracked_errors>0` declara perda de detalhe e impede inferir cobertura integral. Os dados não têm expiração que resolva erros por idade. `last_diagnostic_write` é observação da invocação atual, sem promessa de duração quando sua gravação falhou.

| Operação | Confirmação exigida |
|---|---|
| `schedule` | Evento esperado com timestamp, argumentos, recorrência e intervalo |
| `reschedule` | Próxima ocorrência esperada ou posterior da mesma cadeia e intervalo; nunca apenas a vencida |
| `unschedule` | Ausência da ocorrência exata removida |
| `clear` | Ausência dos eventos do gancho com os argumentos incluídos na limpeza |

Estados: `confirmed` (pós-condição comprovada), `failed` (pós-condição não satisfeita), `unconfirmed` (leitura divergente/ilegível ou contexto insuficiente). A confirmação usa leitura persistida nova e confere a visão efetiva do WordPress, com invalidação dirigida do cache, sem flush global. Resposta booleana `true` também exige confirmação. `schedule_observation` acompanha a observação mais recente do jobs tick e preserva a projeção antiga quando ainda não existe observação nova.

A linha é inofensiva **para aquela operação** somente com a pós-condição comprovada. Evento futuro não prova remoção da ocorrência vencida; agenda confirmada não prova callback executado ou efeito Google. A manutenção pode reconferir até 20 erros de agenda, com rodízio, sem repetir chamadas de agenda nem callbacks. Uma intenção antiga não é recriada; as rotinas normais de agendamento continuam responsáveis pela agenda desejada. Falha persistente permanece disponível para diagnóstico.

A desativação/desinstalação conserva a limpeza nativa de callbacks, inclusive com bootstrap mínimo e guarda pausada; não emite uma passagem ou novo diagnóstico operacional. A confirmação `clear` descreve as chamadas da camada de agenda em funcionamento.

Consulta de status não resolve nem grava incidentes. Durante recuperação, mutações e telemetria Google ficam bloqueadas. Confirmação da agenda não limpa falhas do histórico de passagens, e uma passagem concluída não resolve um evento ausente. O WordPress ainda pode emitir avisos antes do observador; não editar `wp-cron.php` ou ocultar `error.log` para cumprir o aceite.

## Acompanhamento após publicação

A observação operacional da frota pertence ao responsável pela implantação. Registre domínio, hashes/versões, conexão, janela, origens, contadores, idade, erro ativo/histórico e cobertura. Snapshot saudável não comprova execução contínua nem cobertura de vários dias. A entrega local não cria agendamento, autoriza rollout ou encerra aceites de produção.

Correlacione avisos nativos com gancho, operação, timestamp, origem e pós-condição. O diário tem retenção de oito dias e limites de volume; exporte as evidências necessárias antes da poda. `at` e `target_at` são Unix UTC; o painel usa o fuso WordPress.

## Diagnóstico e reparação na 0.12.0

1. Consultar `google/status.cron.scheduling.checks.executor`. `missing` exige reparação; `invalid` exige avaliar forma/multiplicidade; `unknown` exige resolver leitura/divergência. Duas consultas não devem alterar o estado.
2. Conferir `desired_state` e `repair_blocked_by`. Retomar recuperação ou indisponibilidade do armazenamento pelo procedimento autorizado antes de reparar.
3. Executar uma passagem admitida por `google/executar-vencidos`, `wp mcp-google run-due --user=<administrador>`, observador `wp cron event run --due-now` ou `google/maintenance`. O comando manual pode executar trabalho vencido; não é uma consulta.
4. Conferir o subresultado `executor_repair` e uma nova leitura de `checks.executor`. `present` prova agenda, não processamento nem callback passado.
5. Comparar `ultima_cli`, `ultima_http`, `ultima_manual`, `last_pass`, histórico e cobertura separadamente. Atividade CLI nas últimas duas horas mantém `server-cron` mesmo se o evento Google foi perdido.

Não editar a option cron inteira, remover hooks MCP/Core, preencher confirmação automaticamente nem repetir jobs para corrigir o diagnóstico. Estrutura inválida não ganha outra ocorrência silenciosa. MCP 0.22.0 só recompõe seu próprio marcador no ciclo explícito; manutenção Google pode corrigir apenas Google e deixar a ausência MCP visível.

O adaptador `wp mcp-google` exige usuário WordPress autorizado. Quando o MCP aplica sua política à identidade WordPress/CLI, essa identidade também precisa de perfil que permita a habilidade (por exemplo, Manutenção). `profile_denied` é recusa de autorização; não é falha de cron e não deve ser contornada.

## Google 0.14.0 — lacuna de observação e trabalho devido

`observation_health` distingue `observed`, `gap` e `unreadable`. `work_observation` descreve somente a fila atual, sempre com `interval_proven:false`; fila vazia agora não comprova ausência de trabalho no passado. `completion_unconfirmed` sinaliza conclusão não observada. `success:null` não é sucesso nem fracasso do trabalho.

A passagem registra metadados de trabalho antes de iniciar, incluindo sequência monotônica, geração, estado e vencimento. O próximo executor autorizado pode encerrar `coverage_gap` somente quando as duas fotografias são idênticas e nenhum vencimento foi atingido em todo o intervalo. Inserção seguida de remoção altera o contador de sequência e impede essa prova. Lacunas antigas sem fotografia inicial permanecem desconhecidas. A resolução fica preservada em `last_coverage_gap.resolved_by`; consultar status não grava nem reconcilia estado.

Um lock de sessão MySQL indica se a requisição observada ainda vive. Uma passagem longa com sessão ativa permanece running. Sem conclusão e sem sessão viva, o estado observado é interrupted/completion_not_recorded, causa desconhecida. O shutdown registra apenas causas efetivamente observadas: time_limit, memory_limit ou php_fatal; saída antecipada sem erro mantém causa desconhecida. Exceção capturada e erros de armazenamento conservam suas causas próprias. Nenhuma hipótese de hospedagem vira diagnóstico confirmado.

A 0.14.0 não declara cumprida a observação de três dias nos 12 sites. O relatório externo distingue testes de interrupção do acompanhamento real.
