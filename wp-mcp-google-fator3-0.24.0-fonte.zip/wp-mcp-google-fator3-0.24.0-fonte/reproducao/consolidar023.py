"""Consolidate disjoint release023 groups only after matching exact code, ZIP and tests."""
from pathlib import Path
import argparse,json,hashlib,shutil,importlib.util,xml.etree.ElementTree as ET,zipfile
ROOT=Path(__file__).resolve().parents[1]/'plugin/wp-mcp-google-fator3'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--matrix',action='append',required=True,type=Path);p.add_argument('--unit',required=True,type=Path);p.add_argument('--unit-log',required=True,type=Path);p.add_argument('--candidate',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
 spec=importlib.util.spec_from_file_location('release_build',ROOT/'build/build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);ident=b.identity();digest=sha(a.candidate)
 out=a.output;out.mkdir(parents=True,exist_ok=True);groups={};parts=[]
 for file in a.matrix:
  d=json.loads(file.read_text());assert d['identity']==ident and d['candidate_sha256']==digest and d['failures']==0
  for name,g in d['groups'].items():
   assert name not in groups;groups[name]=g;shutil.copytree(file.parent/name,out/name)
   for suite,check in g['reports'].items():
    f=out/name/(suite+'.json');v=json.loads(f.read_text());assert sha(f)==check['sha256'] and v['candidate_sha256']==digest and v['failures']==0 and v['checks']==len(v['passed'])
   assert sha(out/name/'environment.json')==g['environment_sha256']
  parts.append(d)
 assert set(groups)=={'clean','clean-713','upgrade','google-first','isolated','core-consumers'}
 with zipfile.ZipFile(a.candidate) as z:assert {n.removeprefix('wp-mcp-google-fator3/'):z.read(n) for n in z.namelist()}==b.manifest()
 xml=ET.parse(a.unit).getroot();s=xml.find('testsuite') if xml.tag=='testsuites' else xml
 assert int(s.attrib.get('failures',0))==int(s.attrib.get('errors',0))==0 and int(s.attrib['tests'])>=1279
 shutil.copyfile(a.unit,out/'unit-junit.xml');shutil.copyfile(a.unit_log,out/'unit.log')
 proof={'schema_version':1,'release':'0.23.0','candidate_sha256':digest,'identity':ident,'failures':0,'native_checks':sum(g['checks'] for g in groups.values()),'groups':groups,'unit':dict(s.attrib)|{'junit_sha256':sha(a.unit),'tool':'PHPUnit9.6.31'},'contract_tests':parts[0]['contract_tests'],'runtime_files':len(b.manifest()),'php_lint_files':sum(n.endswith('.php') for n in b.manifest()),'inputs':parts[0]['inputs']}
 for name in ['contracts-absent.json','contracts-missing-method.json','contracts-matrix.json','response-candidate018.json']:
  src=a.matrix[0].parent/name;shutil.copyfile(src,out/name)
 (out/'validation023.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in proof.items() if k in ['candidate_sha256','native_checks','unit','runtime_files','php_lint_files']},indent=2))
if __name__=='__main__':main()
