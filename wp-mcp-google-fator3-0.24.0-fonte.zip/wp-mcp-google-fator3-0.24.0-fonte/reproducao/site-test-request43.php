<?php
/** Temporary administrative acceptance for Request43; remove after use. Never ship in runtime. */
if (!defined('ABSPATH')) { exit; }
add_action('wp_abilities_api_init', static function () {
    wp_register_ability('qa-google023/service-account-warning', [
        'label'=>'QA Google43: aviso e validação remota',
        'description'=>'Sonda temporária fixa: chave sintética em memória, somente endpoint OAuth Google; não ativa credencial nem altera contas.',
        'category'=>'google','input_schema'=>['type'=>'object','additionalProperties'=>false],
        'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),
        'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>false]],
        'execute_callback'=>static function () {
            if (!defined('F3_MCP_GOOGLE_VERSION') || F3_MCP_GOOGLE_VERSION!=='0.23.0' || parse_url(home_url(),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com') return ['success'=>false,'code'=>'wrong_environment'];
            return \Fator3\McpGoogle\Connections::run('default',static function () {
                $O='Fator3\\McpGoogle\\Options';$A='Fator3\\McpGoogle\\Auth\\Configuration';$S='Fator3\\McpGoogle\\Settings';
                $snapshot=static function () use($O) {return [$O::stored($O::storage_name($O::SA_JSON)),$O::stored($O::storage_name(\Fator3\McpGoogle\Auth\Candidate::SA))];};
                $before=$snapshot();$revision=$S::revision();if(is_wp_error($revision))return ['success'=>false,'code'=>'revision_unavailable'];
                $rsa=openssl_pkey_new(['private_key_bits'=>2048,'private_key_type'=>OPENSSL_KEYTYPE_RSA]);if(!$rsa||!openssl_pkey_export($rsa,$pem))return ['success'=>false,'code'=>'synthetic_key_failed'];
                $key=['type'=>'service_account','project_id'=>'','private_key_id'=>'synthetic023','client_email'=>'synthetic-google023@example.test','private_key'=>$pem,'token_uri'=>'https://oauth2.googleapis.com/token'];
                $requests=0;$codes=[];
                $guard=static function($pre,$args,$url)use(&$requests){if($url==='https://oauth2.googleapis.com/token'&&($args['method']??'')==='POST'){++$requests;return $pre;}return new WP_Error('qa_external_denied','Sonda só permite troca JWT no Google.');};
                $observe=static function($response,$context,$class,$args,$url)use(&$codes){if($context==='response'&&$url==='https://oauth2.googleapis.com/token')$codes[]=is_wp_error($response)?$response->get_error_code():wp_remote_retrieve_response_code($response);};
                add_filter('pre_http_request',$guard,PHP_INT_MAX,3);add_action('http_api_debug',$observe,10,5);
                try {
                    $result=$A::save_sa(wp_json_encode($key),'',false,$revision);
                    $count=$requests;unset($key['private_key']);$missing=$A::save_sa(wp_json_encode($key),'',false,$revision);
                }finally {remove_filter('pre_http_request',$guard,PHP_INT_MAX);remove_action('http_api_debug',$observe,10);unset($pem,$rsa,$key);}
                $warnings=array_column($result['warnings']??[],'code');$preserved=$before===$snapshot()&&$revision===$S::revision();
                return ['success'=>empty($result['success'])&&($result['error_code']??'')==='f3_google_credential_rejected'&&in_array('f3_google_sa_format_client_email',$warnings,true)&&in_array(400,$codes,true)&&$count===1&&$requests===$count&&empty($missing['success'])&&$preserved,
                    'plugin_version'=>F3_MCP_GOOGLE_VERSION,'token_http_codes'=>$codes,'token_requests'=>$count,'warning_codes'=>$warnings,
                    'rejection_code'=>$result['error_code']??null,'rejection_message'=>$result['message']??null,'missing_key_code'=>$missing['error_code']??null,
                    'missing_key_http_calls'=>$requests-$count,'active_candidate_and_revision_preserved'=>$preserved,'credential'=>'synthetic in memory only'];
            });
        },
    ]);
},30);
