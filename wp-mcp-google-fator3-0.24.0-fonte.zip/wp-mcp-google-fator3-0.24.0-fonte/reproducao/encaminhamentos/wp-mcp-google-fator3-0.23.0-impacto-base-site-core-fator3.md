# Impacto técnico — Google 0.23.0 → Fator3 Site Core

Revisão 1, 29/10/2026, America/Sao_Paulo. Etapa: planejamento. Situação: demanda-aberta. Classificação: acao-necessaria e validacao-coordenada. Natureza: contrato, autorização, dados e consumidor opcional.

Emissor wp-mcp-google-fator3; base 0.22.0, SHA-256 do instalador a84754409f89b7b9c7367c1d261c44ef93c2f6039b379c3ec5c6242ec7188ebd. Alvo previsto 0.23.0, instalador ainda não gerado. Destinatário base-site-core-fator3, versão examinada 1.60.0, instalador SHA-256 1dc4e94305ea55394024d6527bc06b46209f0ae51a55f734853763bcb232e27c.

## Mudanças e consequências

Pedidos Google 44/45 e Core 337/340: novo contrato opcional google-ads-reader/1.0.0, hook f3_mcp_google_register_ads_consumers, cliente local com capabilities/status/query. O produtor arquiva cliques, desempenho por dia e nível, termos e alterações; o cliente não faz HTTP. A concessão é explícita por consumidor, conexão, conta e conjunto de dados. Não herda concessões de conversão nem expõe credenciais. Acervo cifrado sem expiração; revisitas publicam uma nova revisão e substituem a visão corrente, sem somar contagens. O Core deve persistir proveniência, moeda, fuso, revisão e cobertura, e relacionar gclid somente por igualdade exata. Termo agregado de pesquisa não identifica o termo de um clique.

Pedidos Google 46 e Core 342: novo contrato search-console-reader/1.1.0, capability gsc.query-page-day.read, registro no hook existente com versão exata. O contrato 1.0.0 e sua concessão permanecem independentes. A leitura usa date/page/query, paginação retomável e cobertura explícita. Consultas anonimizadas não são retornadas pela API; a diferença para page-day não constitui contagem exata de anonimização, pois há outros limites. O Core deve manter essas dimensões separadas, sem substituir o histórico page-day anterior ou declarar completude universal.

## Providências e aceite

Implementar nesta rodada um adaptador consumidor sobre o Core 1.60.0, em fonte separado para incorporação pelo mantenedor, conforme autorização do dono para não aguardar outra sessão. Não alterar o Core instalado no Site-Teste. Responsável pela incorporação/publicação Core: seu mantenedor. IDs existentes: Core 337, 340 e 342; não são criados tickets novos.

Aceites: consumidor ausente não derruba nenhum plugin; concessão ausente/revogada bloqueia leitura; revisão/cursor de outra conta ou concessão falha; 30 dias sintéticos têm custo/clicks por moeda e sem soma duplicada; backfill e revisitas preservam dados; cliques mantêm gclid e origem sem associação inventada; query-page-day mantém page-day 1.0 e informa limites/anonimização. Homologação real em ctooffice exige operador autorizado e comparação com Ads/GSC, não se encerra com fixtures.

## Compatibilidade e sequência

Google 0.23 pode entrar antes do Core consumidor: coleta só após autorização explícita e SDK permanece opcional. Core 1.60 original continua usando os contratos anteriores. Consumidor novo detecta a capacidade e apresenta indisponibilidade quando Google antigo/ausente. Não há dependência nova no MCP, Meta ou LinkedIn. Não transferir tags, consentimento ou pipeline comercial para Google.

## Base e incertezas

Base da análise: pedidos Google 43–46 anexados em 29/10, runtime e relatório Core 1.60, produtor GSC 1.0 Google 0.22, leitor Ads Meta 0.14. Google limita click_view a um dia por consulta e 90 dias de busca; change_event aos 30 dias recentes e 10.000 linhas por consulta. O coletor deverá declarar recortes incompletos. Documentação oficial Google orienta paginação GSC e limita a 50.000 linhas/dia/tipo; não garante todas as linhas. Testes de fornecedor com contas reais ainda não executados.

Primeira emissão. Respostas, implementação, testes e encerramentos serão registrados no relatório principal, sem revisar este documento somente para comunicar conclusão ou hash final.
