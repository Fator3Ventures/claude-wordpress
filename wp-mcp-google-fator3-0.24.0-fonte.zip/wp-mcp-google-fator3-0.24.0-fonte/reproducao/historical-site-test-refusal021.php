<?php
/** Temporary Site-Teste acceptance probe. Remove immediately after use. Never part of the installer. */
if (!defined('ABSPATH')) { exit; }
add_action('wp_abilities_api_init', static function () {
    wp_register_ability('qa-google021/refusal', [
        'label' => 'QA Google 0.21: recusa local',
        'description' => 'Sonda temporária administrativa: exige destino não pronto, bloqueia HTTP e devolve somente resultado sem identificadores.',
        'category' => 'google',
        'input_schema' => ['type'=>'object','additionalProperties'=>false],
        'output_schema' => ['type'=>'object'],
        'permission_callback' => static fn() => current_user_can('manage_options'),
        'meta' => ['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>true,'destructive'=>false,'idempotent'=>true]],
        'execute_callback' => static function () {
            $adapter = \Fator3\McpGoogle\ConversionDelivery::adapter(null,'google_ads','site-conversion-delivery/1.1.0');
            if (!$adapter) { return ['success'=>false,'code'=>'adapter_missing']; }
            $cap = $adapter->capabilities();
            if (!empty($cap['ready']) || !empty($cap['enhanced_leads']['ready'])) { return ['success'=>false,'code'=>'fixture_precondition_failed']; }
            $revision = \Fator3\McpGoogle\ConversionDelivery::revision();
            $http = 0;
            $guard = static function () use (&$http) { ++$http; return new WP_Error('qa_external_blocked','HTTP bloqueado nesta sonda.'); };
            add_filter('pre_http_request',$guard,PHP_INT_MAX,3);
            try {
                $id = md5('google021-site-test-local-refusal');
                $out = $adapter->sendBound(['record_id'=>$id,'event_id'=>$id,'order_id'=>$id,'occurred_at'=>gmdate('c',time()-5),'click_ids'=>[],
                    'user_data'=>['email'=>'synthetic-refusal@example.test'],'ad_user_data'=>'GRANTED'],$cap['destination_ref']);
            } finally { remove_filter('pre_http_request',$guard,PHP_INT_MAX); }
            return ['success'=>($out['code']??'')==='enhanced_leads_not_ready'&&$http===0,
                'result'=>$out,'http_calls'=>$http,'configuration_unchanged'=>$revision===\Fator3\McpGoogle\ConversionDelivery::revision(),
                'enhanced_leads'=>$cap['enhanced_leads']];
        },
    ]);
}, 30);
