# Impacto técnico — Core1.61.1 → MCP Google0.23.0

29/10/2026. Emissor: Fator3 Site Core, base1.61.0/alvo1.61.1. Destinatário: responsável MCP Google. Tipo: alerta-tecnico e validacao-coordenada. Etapa: entrega; revisão2. Situação: integração Core implementada; aceite de contas reais pendente.

Pedidos337/340/342; Google44–46. O Core incorporou os consumidores opcionais nos contratos públicos `google-ads-reader/1.0.0` e `search-console-reader/1.1.0`, preservando GSC1.0. Há concessões separadas, cursores, cobertura, leitura local Ads e publicação atômica do acervo GSC consultas. O Core não administra credenciais ou tabelas Google.

Na integração foi identificada colisão na proposta recebida: `f3base_google_ads` já era a configuração de conversão/tag do Core. A opção do novo leitor passou a `f3base_google_ads_acervo`; a opção anterior é preservada e isso é verificado na atualização nativa. Não aplicar o patch opcional antigo sobre esta release nem alterar a opção de conversões para configurar o leitor. Responsável Google: atualizar a referência/proposta futura para o nome efetivo; não há alteração obrigatória no runtime0.23.0.

Provas próprias: SDK real0.23.0 em WordPress com respostas sintéticas de fornecedor; 30 dias/90 cliques/30.000.000micros, revisita sem soma, igualdade exata de GCLID, persistência em sessão/contato e bloqueio após revogação. GSC consulta: página curta, conclusão vazia explícita, filtro e revisita; páginas anteriores preservadas. Leitura de Ads não faz HTTP.

Aceite coordenado pelo dono/operador em ctooffice.com.br: comparar conta/dia/campanha/moeda e GCLID à origem, além de consulta×página×dia. A API não fornece quantidade de consultas anônimas nesta dimensão: permanece nula com motivo. Não usar diferença entre universos como contagem anônima. Esta entrega não declara aceites de produção cumpridos. O relatório principal fornece hashes finais e estado do Site-Teste. Documento preparado para o responsável; não enviado.

## Fechamento da entrega

Instalador emissor: `base-site-core-fator3-1.61.1-instalador.zip`, 2933589 bytes, SHA-256 `9cfbab0b667c877c3c14b9d6704c827665d20d7b34ff4c9b9d915d6b3c9bd6d3`.

Site-Teste: WordPress 7.1.4/PHP 8.3.36, Core 1.61.1 e Google 0.23.0; 85 verificações Google Ads/GSC passaram na bancada isolada com HTTP sintético. Evidência: `evidence/1611/site-request-337-340-342.json`. Contrato integrado e colisão de opção resolvidos no Core; a orientação de configuração acima e o aceite em conta real permanecem para o responsável.
