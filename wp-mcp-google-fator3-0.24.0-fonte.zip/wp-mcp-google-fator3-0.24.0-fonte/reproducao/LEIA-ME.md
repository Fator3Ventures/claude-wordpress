# Reprodução — Google 0.24.0

Base publicada exata: Google 0.23.0. Runtime: 172 arquivos (168 PHP). Evidências desta rodada: plugin/wp-mcp-google-fator3/evidence/024. Diretórios 023 e anteriores, scripts release023 e anteriores, entradas/ e encaminhamentos/ conservam histórico; não integram os totais atuais. As normas r5 em entradas/ continuam aplicáveis. entradas024/ contém os relatórios novos. Não há ZIP aninhado.

## Dependências e entradas

Linux amd64, Python 3, PHP 8.3.6, MySQL 8.0.46. runtime-dependencies.json e download-runtime.py fixam a origem oficial das bibliotecas; o manifesto atual fixa o hash da árvore runtime usada nesta rodada. Reproduza em diretórios novos e bancos descartáveis. A ferramenta lab.py calcula e exige os hashes das entradas. Os caminhos absolutos dos manifestos são exemplos da execução; substitua somente os caminhos, preservando versões e hashes.

WordPress oficial: https://wordpress.org/wordpress-7.1.2.zip (SHA-256 8fc96c59a78b7219e4a130222b7fadb51b03e503e8b0123beaa7e28961c21ce2) e https://wordpress.org/wordpress-7.1.3.zip (eb58a90ed55147f90f7bd55d0d3334960a69b7e8a4cc142c8ddfea8965218227). Não reutilize sem conferência o hash de um download histórico: estes são os bytes recebidos e testados nesta rodada.

Acompanhantes originais: Core 1.61.1, MCP 0.37.0, Meta 0.16.0, LinkedIn 0.13.0. O cenário minimum usa apenas Google. A atualização parte do Google 0.23.0. Nenhum arquivo oficial do Core é alterado. O antigo adaptador em integration/core337-340-342 é histórico e seu bootstrap está inerte; não o instale.

## Execução corrente

1. Configure PHP_INI_SCAN_DIR vazio, LD_LIBRARY_PATH para runtime/usr/lib/x86_64-linux-gnu e extension_dir do php.ini para runtime/usr/lib/php/20230831. O wrapper deve invocar runtime/usr/bin/php8.3 com esse php.ini. Use php024.ini.template, substituindo RUNTIME_DIRECTORY pela pasta absoluta; OpenSSL já integra o binário; a bancada usa MySQL nativo descartável.
2. Dentro do plugin, execute PHP_WRAPPER build/export-contracts.php --check e python3 build/check-docs.py. Gere candidato com python3 build/build.py candidate --output /novo/wp-mcp-google-fator3-0.24.0-instalador.zip. O resultado deve ter SHA-256 803fa058182b9f43625352f2b4a1572a3cd4b728f8c07fd58314a9a111d41849.
3. Ajuste os caminhos de manifest024-7.1.2.json e manifest024-7.1.3.json para as entradas exatas. mkmanifest.py pode gerar hashes, que devem coincidir com os manifestos fixados. baseline_core/mcp repetem os acompanhantes atuais.
4. Execute python3 tools/release024.py --case CASO --manifest MANIFESTO --workdir /novo/CASO --evidence /novo/CASO-prova --php /PHP_WRAPPER. CASO=minimum usa WordPress 7.1.2; current, core e upgrade usam 7.1.3. Cada caso exige destino novo, verifica a identidade antes/depois, lint, documentos, inventários instalados, resultados e ausência de notices Google. Os casos são independentes.
5. Execute PHP_WRAPPER tests/retired-core024.php. A inclusão do bootstrap antes do Core também deve permanecer inerte.
6. O caso core executa os consumidores oficiais do Core. tests/core024-provenance.json identifica o teste recebido adaptado somente para a bancada; prepare-core024 conclui migrações nativas em instalação descartável. Não é patch no Core. O caso upgrade usa MCP autenticado para atualização, preview/guarda, rollback real e reaplicação.
7. Documentação é lida integralmente via MCP nos casos current e upgrade. Provedores Google são sintéticos; as provas não representam aceite de contas reais. O gate build/build.py verify é legado; release024.py é a rota atual.

PHPUnit integral não foi executado nesta rodada: downloads do PHAR oficial retornaram HTTP 403. Os números unitários históricos não são somados aos testes nativos atuais. Nenhuma dependência nova de produção.

## Fechamento

empacotar-fonte.py inclui plugin e reproducao. Gere uma única vez o fonte com relatório marcado como cópia anterior ao fechamento; a identidade final do fonte aparece apenas no relatório externo. Reconstrua o instalador a partir do fonte fechado e compare seus bytes. A instalação compartilhada autorizada troca somente Google no Site-Teste. Não publique nem instale os acompanhantes como parte dessa reprodução.
