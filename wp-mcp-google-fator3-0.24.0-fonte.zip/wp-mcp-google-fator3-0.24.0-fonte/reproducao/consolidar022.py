"""Verify partial gates, unit proof and consumer patch before accepting the same candidate."""
from pathlib import Path
import hashlib,json,importlib.util,xml.etree.ElementTree as ET,zipfile,shutil
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'plugin/wp-mcp-google-fator3';E=P/'evidence/022'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('build',P/'build/build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
parts=[json.loads((E/d/'validation022.json').read_text()) for d in ['final-a','final-b']]
a=parts[0];candidate=ROOT/'candidates/google022.zip';identity=b.identity();assert a['identity']==identity and a['candidate_sha256']==sha(candidate)
checks=0;groups={}
for folder,part in zip(['final-a','final-b'],parts):
 assert part['identity']==identity and part['candidate_sha256']==sha(candidate) and part['failures']==0
 for name,g in part['groups'].items():
  assert name not in groups
  for suite,r in g['reports'].items():
   f=E/folder/name/(suite+'.json');d=json.loads(f.read_text());assert sha(f)==r['sha256'] and d['checks']==len(d['passed'])==r['checks'] and d['failures']==0 and d['candidate_sha256']==sha(candidate)
  env=E/folder/name/'environment.json';assert sha(env)==g['environment_sha256'] and json.loads(env.read_text())['processes_stopped']
  assert g['installed_inventory']['candidate']['exact']
  groups[name]={'source':folder,**g};checks+=g['checks']
assert set(groups)=={'clean','clean-713','upgrade','google-first','isolated'}
unit=ET.parse(E/'unit-junit.xml');cases=list(unit.getroot().iter('testcase'));assert cases and not any(c.findall('error') or c.findall('failure') or c.findall('skipped') for c in cases)
assert sum(int(c.get('assertions','0')) for c in cases)>15000
with zipfile.ZipFile(candidate) as z:assert {n.split('/',1)[1]:z.read(n) for n in z.namelist()}==b.manifest() and z.testzip() is None
patch=E/'core-patch';env=json.loads((patch/'environment.json').read_text());assert env['processes_stopped'] and env['candidate_sha256']==sha(candidate)
pchecks=0
for name in ['apply-core022','requests022']:
 d=json.loads((patch/(name+'.json')).read_text());assert d['failures']==0 and d['checks']==len(d['passed']) and d['candidate_sha256']==sha(candidate);pchecks+=d['checks']
result={**a,'groups':groups,'checks':checks,'scope':'Core323; original companions matrix; proposed Core patch tested separately','unit':{'tests':len(cases),'assertions':sum(int(c.get('assertions','0')) for c in cases),'failures':0,'sha256':sha(E/'unit-junit.xml')},'core_patch':{'checks':pchecks,'failures':0,'official_core_release':False,'installed_remote':False,'requests_sha256':sha(patch/'requests022.json')}}
(E/'validation022.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'candidate_sha256':sha(candidate),'native_checks':checks,'unit':result['unit'],'core_patch_checks':pchecks,'files':len(b.manifest())}))
