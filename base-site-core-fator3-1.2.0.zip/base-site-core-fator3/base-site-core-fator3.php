<?php
/**
 * Plugin Name:       Base Site Core Fator3
 * Plugin URI:        https://github.com/Fator3Ventures/claude-wordpress
 * Description:       Plugin persistente do Método F3: leads e endpoint endurecido, consentimento, tracking de GA4, Google Ads, Meta e LinkedIn dirigido pelos IDs gravados e gateado pelo consentimento, resumo agregado do comportamento das páginas guardado no próprio site, rota de origem, reserva de llms.txt, redirects de slug, honra de noindex, extensão de schema, retenção e eliminação com journal, cabeçalhos de resposta e o ouvinte da cadência do modo somente-relatório. Tudo declarado num registro único de módulos que alimenta hooks, tela e relatório. EXIGE PHP DE 64 BITS: o carimbo de milissegundo do registro de comportamento é um inteiro que não cabe nos 32 bits, e num PHP de 32 bits ele estoura em silêncio e a série de tempo passa a mentir. INSTALAÇÃO ÚNICA, NÃO MULTISITE: a desinstalação limpa o site corrente, e a ativação em rede é recusada dizendo por quê.
 * Version:           1.2.0
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            Fator 3 Ventures
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       f3base
 * Update URI:        false
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * A NUMERAÇÃO RECOMEÇA EM 1.0.0, E ISSO É DELIBERADO.
 *
 * Até a 1.3.6 este arquivo era `f3base-site-core.php`, construído pelo
 * implantador e numerado na esteira dele. A partir desta release ele é um
 * ARTEFATO PRÓPRIO, com identidade própria, publicado como zip e instalado em
 * qualquer site desta operação como qualquer outro plugin de catálogo. Herdar
 * o 1.3.7 diria que este é o mesmo artefato de antes com uma correção a mais;
 * ele não é — o que mudou foi o que ele É. O 1.0.0 é a afirmação de que a série
 * anterior pertence a outro objeto, e a migração de quem está na série antiga
 * está escrita em `F3Base_Site_Core::desativar_copias_do_mesmo_plugin()`.
 *
 * O PREFIXO INTERNO `f3base` NÃO MUDA, e é a metade que importa. Nome de pasta
 * é ENDEREÇO: trocá-lo custa uma reinstalação. Nome de option é CHAVE DE DADO:
 * trocá-lo orfana o valor sem apagar nada e sem erro nenhum, e o site continua
 * rodando com o padrão de fábrica em cima de uma configuração que ninguém
 * apagou. Nome de tabela é pior — renomear apaga a série histórica. Nome de
 * evento é pior ainda — renomear quebra a série na conta de medição do
 * fornecedor, onde não há como reparar depois. Por isso `f3base_*` continua
 * exatamente como está em options, tabelas, eventos, namespace REST, classes e
 * text domain.
 */

/*
 * Identidade e caminhos. Constantes definidas antes de qualquer require: as classes
 * do plugin as consomem no carregamento e o guard de PHP abaixo precisa da versão
 * para nomear o próprio motivo.
 *
 * A VERSÃO SAI DO CABEÇALHO, NUNCA DE UM LITERAL AO LADO DELE. O defeito era
 * medido e estava aqui: o cabeçalho dizia `Version: 1.3.6` e esta constante
 * dizia `'1.3.5'`. Ninguém acusava, porque as duas são verdadeiras isoladamente
 * — e quem lê a constante (a tela, o parâmetro de versão dos assets publicados)
 * carimbava um número que o WordPress não mostra em lugar nenhum. É a mesma
 * regra que o tema já cumpre com o cabeçalho do `style.css`: o contrato é o
 * cabeçalho que o código lê, e constante que repete o número sai de sincronia
 * na primeira release em que alguém esquece de mexer nos dois.
 *
 * `get_file_data()` mora em `wp-includes/functions.php`, carregado antes de
 * qualquer plugin: ela está disponível aqui e não exige `wp-admin`.
 *
 * `UPDATE URI: FALSE` NO CABEÇALHO, e ele é a linha mais barata deste arquivo.
 * Sem ela, o atualizador do wordpress.org confere o SLUG da pasta contra o
 * diretório público a cada verificação de atualização: qualquer plugin
 * publicado lá com o slug `base-site-core-fator3` passaria a ser oferecido — e,
 * com atualização automática ligada, INSTALADO — por cima deste. O valor
 * `false` é o que a documentação do núcleo declara para "nenhum servidor de
 * atualização", e ele desliga a consulta inteira.
 */

/**
 * O CABEÇALHO DESTE ARQUIVO, lido UMA VEZ por processo.
 *
 * O DEFEITO MEDIDO era de custo, não de correção: `get_file_data()` abre o
 * arquivo, lê 8 KiB e roda uma expressão regular por campo pedido, e a chamada
 * acontecia em TODA requisição do site — inclusive nas do beacon de
 * comportamento, que é a rota mais chamada do pacote. O valor não muda dentro
 * de um processo: o arquivo que ele lê é o arquivo que está executando.
 *
 * Memoizado em `static`, e não numa constante a mais: a constante já existe e é
 * `F3BASE_PLUGIN_VERSAO`. O que esta função guarda é a LEITURA, para que um
 * campo novo do cabeçalho não custe uma segunda abertura do arquivo.
 *
 * @return array<string,string> Campos declarados do cabeçalho.
 */
function f3base_site_core_cabecalho(): array {
	static $cabecalho = null;

	if ( null === $cabecalho ) {
		$cabecalho = get_file_data(
			__FILE__,
			array(
				'versao'      => 'Version',
				'php_minimo'  => 'Requires PHP',
				'nome'        => 'Plugin Name',
			),
			'plugin'
		);
	}

	return array_map( 'strval', (array) $cabecalho );
}

if ( ! defined( 'F3BASE_PLUGIN_VERSAO' ) ) {
	define(
		'F3BASE_PLUGIN_VERSAO',
		(string) ( f3base_site_core_cabecalho()['versao'] ?? '' )
	);
}
if ( ! defined( 'F3BASE_PLUGIN_PHP_MINIMO' ) ) {
	/* O MÍNIMO SAI DO MESMO CABEÇALHO, pelo mesmo motivo da versão: o número que
	 * o WordPress mostra e usa para barrar a instalação é o do cabeçalho, e um
	 * literal ao lado dele sai de sincronia na primeira release em que alguém
	 * mexer em só um dos dois. O `?:` é a posição segura de um cabeçalho ilegível
	 * — sem mínimo declarado, o guard abaixo não tem contra o que comparar. */
	define( 'F3BASE_PLUGIN_PHP_MINIMO', (string) ( f3base_site_core_cabecalho()['php_minimo'] ?: '8.1' ) );
}
if ( ! defined( 'F3BASE_PREFIXO' ) ) {
	define( 'F3BASE_PREFIXO', 'f3base' );
}
if ( ! defined( 'F3BASE_TEXT_DOMAIN' ) ) {
	/*
	 * O TEXT DOMAIN EXISTE E O CARREGADOR NÃO, e a decisão é declarada aqui.
	 *
	 * O DEFEITO MEDIDO: o cabeçalho trazia `Domain Path: /languages` e a
	 * ativação chamava `load_plugin_textdomain()` apontando para essa pasta — e a
	 * pasta NÃO EXISTE no zip. Um caminho de tradução que não existe não falha e
	 * não avisa: ele faz o núcleo procurar arquivo em disco a cada carregamento e
	 * não achar nada, para sempre.
	 *
	 * DAS DUAS SAÍDAS — criar a pasta com um `.pot` gerado, ou tirar as duas
	 * linhas —, ESTE PACOTE É MONOLÍNGUE e escolhe a segunda. Toda string dele é
	 * escrita em português para quem opera o site, e um `.pot` sem nenhuma
	 * tradução é um arquivo que declara um processo de tradução que ninguém
	 * mantém. O domínio `f3base` continua declarado no cabeçalho e nas chamadas
	 * de `__()`, e é ele que um site que QUISER traduzir usa por
	 * `load_plugin_textdomain()` próprio ou pelo `.mo` de
	 * `wp-content/languages/plugins/` — que é o caminho que o núcleo carrega
	 * sozinho, sem `Domain Path` nenhum, desde a 4.6.
	 */
	define( 'F3BASE_TEXT_DOMAIN', 'f3base' );
}
if ( ! defined( 'F3BASE_REST_NAMESPACE' ) ) {
	define( 'F3BASE_REST_NAMESPACE', 'f3base/v1' );
}
if ( ! defined( 'F3BASE_PLUGIN_ARQUIVO' ) ) {
	define( 'F3BASE_PLUGIN_ARQUIVO', __FILE__ );
}
if ( ! defined( 'F3BASE_PLUGIN_DIR' ) ) {
	define( 'F3BASE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'F3BASE_PLUGIN_URL' ) ) {
	define( 'F3BASE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

/**
 * Guard de versão de PHP.
 *
 * `version_compare()` aqui usa `<`, operador da lista permitida pelo contrato
 * (`< lt <= le > gt >= ge == = eq != <> ne`).
 *
 * @return bool Verdadeiro quando o PHP em execução atende ao mínimo declarado.
 */
function f3base_site_core_php_suportado(): bool {
	return ! version_compare( PHP_VERSION, F3BASE_PLUGIN_PHP_MINIMO, '<' );
}

if ( ! f3base_site_core_php_suportado() ) {
	add_action(
		'admin_notices',
		static function (): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html(
					sprintf(
						/* translators: 1: versão mínima de PHP exigida, 2: versão de PHP em execução. */
						__( 'Base Site Core Fator3 exige PHP %1$s ou superior. Este servidor executa PHP %2$s: o plugin ficou inerte e nenhum hook foi registrado.', 'f3base' ),
						F3BASE_PLUGIN_PHP_MINIMO,
						PHP_VERSION
					)
				)
			);
		}
	);

	return;
}

/**
 * Autoload simples: lista declarada de arquivos, um `require_once` por arquivo.
 *
 * Sem PSR-4 e sem `spl_autoload_register` de propósito — o pacote precisa ser
 * legível por quem abre a pasta, e a lista é a mesma que o empacotador confere.
 *
 * CINCO DESTES ARQUIVOS SÃO CONTRATO COMPARTILHADO com o implantador —
 * `class-f3base-chaves-seo.php`, `class-f3base-vocabulario.php`,
 * `class-f3base-emissores.php`, `class-f3base-censo-demonstrativo.php` e
 * `dados/emissores-conhecidos.tsv` —, e é preciso dizer o que isso significa. O
 * implantador precisa das mesmas regras ANTES de este plugin existir na
 * instalação — o preflight roda antes de instalar qualquer coisa —, e este
 * plugin precisa delas em runtime.
 *
 * ELES MORAM NESTE REPOSITÓRIO, no caminho declarado nesta lista: quatro em
 * `includes/` e um em `dados/`. A pasta `fontes/plugin/` deste repositório é
 * INSTALÁVEL COMO ESTÁ — a frase anterior, herdada de quando esta fonte viajava
 * dentro do bundle do implantador e cinco arquivos vinham de `partilhado/`, era
 * falsa neste repositório, e uma frase falsa num docblock de carregamento é a
 * que manda outro agente procurar arquivo que já está no lugar. Quem carrega
 * uma CÓPIA é o implantador, que a vendoriza na árvore dele.
 *
 * `pacote.plugin_completo_no_zip` confere, em toda rodada, que o zip montado
 * contém cada arquivo desta lista — uma lista que cita um arquivo que o zip não
 * tem é um plugin que morre no `require_once` da ativação, e o piso do detector
 * planta exatamente esse defeito.
 *
 * A ALTERNATIVA REJEITADA era o implantador continuar lendo de dentro da
 * fonte deste plugin, como fazia até a 1.6.6. Era ela que obrigava a fonte do
 * plugin a viajar dentro do bundle do implantador, e era ela que fazia a
 * renomeação de prefixo produzir um FORK deste plugin por site.
 *
 * @return void
 */
function f3base_site_core_carregar(): void {
	$arquivos = array(
		'includes/class-f3base-chaves-seo.php',
		'includes/class-f3base-vocabulario.php',
		'includes/class-f3base-options.php',
		'includes/class-f3base-atividade.php',
		'includes/class-f3base-modulo.php',
		'includes/class-f3base-modulo-leads-whatsapp.php',
		'includes/class-f3base-modulo-endpoint-leads.php',
		'includes/class-f3base-modulo-consentimento.php',
		'includes/class-f3base-emissores.php',
		'includes/class-f3base-censo-demonstrativo.php',
		'includes/class-f3base-modulo-tracking.php',
		'includes/class-f3base-modulo-comportamento.php',
		'includes/class-f3base-modulo-acessos-servidor.php',
		'includes/class-f3base-acessos-atuais.php',
		'includes/class-f3base-modulo-sessao-de-login.php',
		'includes/class-f3base-acessos-mcp.php',
		'includes/class-f3base-modulo-meta-capi.php',
		'includes/class-f3base-modulo-verificacao-dominio.php',
		'includes/class-f3base-modulo-rota-origem.php',
		'includes/class-f3base-llms.php',
		'includes/class-f3base-modulo-llms-txt-reserva.php',
		'includes/class-f3base-modulo-llms-full-txt.php',
		'includes/class-f3base-modulo-redirects.php',
		'includes/class-f3base-modulo-noindex-honrado.php',
		'includes/class-f3base-modulo-schema-extensao.php',
		'includes/class-f3base-modulo-retencao-eliminacao.php',
		'includes/class-f3base-modulo-cabecalhos.php',
		'includes/class-f3base-modulo-cadencia-relatorio.php',
		'includes/class-f3base-registro.php',
		'includes/class-f3base-como-usar.php',
		'includes/class-f3base-config-mcp.php',
		'includes/class-f3base-plugin.php',
		'admin/class-f3base-admin-tela.php',
		'admin/class-f3base-admin-medicao.php',
		'admin/class-f3base-admin-acessos.php',
	);

	foreach ( $arquivos as $relativo ) {
		require_once F3BASE_PLUGIN_DIR . $relativo;
	}
}

f3base_site_core_carregar();

/*
 * O BOOTSTRAP NÃO ACONTECE NA DESINSTALAÇÃO, e é ele que faz `uninstall.php`
 * poder carregar este arquivo inteiro.
 *
 * O DEFEITO MEDIDO, num WordPress real: `uninstall.php` fazia `require_once` de
 * `class-f3base-options.php` e MAIS NADA, e o catálogo daquela classe cita
 * `F3Base_Vocabulario` e `F3Base_Llms` nos padrões. O processo da desinstalação
 * morria em `Class "F3Base_Vocabulario" not found`, o WordPress mostrava "erro
 * crítico", e NADA do que a desinstalação promete limpar era limpo — a tabela do
 * registro detalhado, com apelido, sessão e carimbo, sobrevivia ao apagamento do
 * plugin. Manter uma segunda lista de `require` dentro do `uninstall.php` só
 * adiaria o mesmo defeito para o dia em que um padrão do catálogo citasse uma
 * classe a mais.
 *
 * A saída é esta: a lista de arquivos é UMA, mora em `f3base_site_core_carregar()`
 * logo acima, e o `uninstall.php` carrega ESTE arquivo. O que ele NÃO pode
 * herdar é o registro de hooks — a desinstalação roda com o plugin inativo e
 * registrar `init`, `admin_notices` e as duas telas ali seria ressuscitar o
 * plugin no processo que existe para apagá-lo. `WP_UNINSTALL_PLUGIN` é definida
 * pelo núcleo antes de incluir o arquivo, e é ela que separa os dois usos.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	register_activation_hook( __FILE__, array( 'F3Base_Site_Core', 'ativar' ) );
	register_deactivation_hook( __FILE__, array( 'F3Base_Site_Core', 'desativar' ) );

	F3Base_Site_Core::iniciar();
}
