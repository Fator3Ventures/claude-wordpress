<?php
/**
 * Registro único de módulos.
 *
 * Esta é a ÚNICA lista de módulos do plugin. Ela alimenta (a) o registro dos
 * hooks, (b) a tela de administração e (c) o relatório da implantação. Módulo
 * novo aparece nos três lugares sozinho; lista escrita à mão em três lugares
 * mente no primeiro release que esquecer de atualizar uma delas.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fonte única dos módulos.
 */
final class F3Base_Registro {

	/**
	 * Instâncias usadas para registrar hooks.
	 *
	 * @var array<string,F3Base_Modulo>|null
	 */
	private static ?array $modulos = null;

	/**
	 * Nomes que o filtro `f3base_modulos` ofereceu e o registro RECUSOU.
	 *
	 * @var array<int,array{nome:string,motivo:string}>
	 */
	private static array $recusadas = array();

	/**
	 * O QUE O FILTRO OFERECEU E O REGISTRO NÃO ACEITOU.
	 *
	 * Público porque o relatório e a tela o mostram: uma recusa que só existe
	 * dentro de `classes()` é um módulo que o agente acrescentou, que não
	 * apareceu em lugar nenhum e cuja ausência ele descobriria pelo efeito que
	 * não aconteceu no site.
	 *
	 * @return array<int,array{nome:string,motivo:string}>
	 */
	public static function classes_recusadas(): array {
		self::classes();

		return self::$recusadas;
	}

	/**
	 * Classes declaradas, na ordem em que a tela as apresenta.
	 *
	 * @return string[]
	 */
	public static function classes(): array {
		$classes = array(
			'F3Base_Modulo_Leads_Whatsapp',
			'F3Base_Modulo_Endpoint_Leads',
			'F3Base_Modulo_Consentimento',
			'F3Base_Modulo_Tracking',
			'F3Base_Modulo_Comportamento',
			'F3Base_Modulo_Acessos_Servidor',
			'F3Base_Modulo_Sessao_De_Login',
			'F3Base_Modulo_Meta_Capi',
			'F3Base_Modulo_Verificacao_Dominio',
			'F3Base_Modulo_Rota_Origem',
			'F3Base_Modulo_Llms_Txt_Reserva',
			'F3Base_Modulo_Llms_Full_Txt',
			'F3Base_Modulo_Redirects',
			'F3Base_Modulo_Noindex_Honrado',
			'F3Base_Modulo_Schema_Extensao',
			'F3Base_Modulo_Retencao_Eliminacao',
			'F3Base_Modulo_Cabecalhos',
			'F3Base_Modulo_Cadencia_Relatorio',
		);

		/**
		 * Permite ao pacote acrescentar módulos ao registro único.
		 *
		 * @param string[] $classes Nomes de classe que estendem F3Base_Modulo.
		 */
		$declaradas = $classes;
		$classes    = apply_filters( 'f3base_modulos', $classes );

		self::$recusadas = array();

		if ( ! is_array( $classes ) ) {
			self::recusar(
				'(o filtro devolveu ' . gettype( $classes ) . ')',
				__( 'o filtro f3base_modulos precisa devolver a LISTA de classes, e devolveu outra coisa: o registro voltou a ficar vazio e nenhum módulo deste plugin foi ligado.', 'f3base' )
			);

			return array();
		}

		$validas = array();

		foreach ( $classes as $classe ) {
			$classe = (string) $classe;

			/*
			 * O NOME RECUSADO SAI NOMEADO, e a recusa silenciosa era o defeito.
			 * Até aqui um `continue` descartava a classe: quem acrescentasse um
			 * módulo pelo filtro com a classe ainda não carregada, ou herdando de
			 * outra base, via o site continuar exatamente igual — sem erro, sem
			 * linha no relatório, sem nada a que voltar. O que ele descobriria
			 * seria o efeito que não aconteceu, dias depois.
			 *
			 * `_doing_it_wrong()` é o instrumento certo porque o público é quem
			 * ESCREVEU o filtro, e ele fala com quem tem `WP_DEBUG` ligado — que é
			 * o ambiente em que se escreve filtro. A linha do relatório é para o
			 * resto do tempo.
			 */
			if ( ! class_exists( $classe ) ) {
				self::recusar(
					$classe,
					__( 'a classe não existe no momento em que o registro é lido. Módulo acrescentado pelo filtro precisa estar carregado antes de init na prioridade do registro — um require dentro do próprio filtro resolve.', 'f3base' )
				);
				continue;
			}

			if ( ! is_subclass_of( $classe, 'F3Base_Modulo' ) ) {
				self::recusar(
					$classe,
					__( 'a classe existe e NÃO estende F3Base_Modulo. O registro chama id(), nome(), hooks() e estado() em tudo o que aceita, e uma classe sem essa base derrubaria a tela e o relatório na primeira leitura.', 'f3base' )
				);
				continue;
			}

			$validas[] = $classe;
		}

		foreach ( $declaradas as $embutida ) {
			if ( ! in_array( (string) $embutida, $validas, true ) ) {
				self::recusar(
					(string) $embutida,
					__( 'módulo EMBUTIDO deste plugin que o filtro f3base_modulos retirou da lista. Ele não registra hook nenhum e a parte do site que ele serve fica parada.', 'f3base' )
				);
			}
		}

		return array_values( array_unique( $validas ) );
	}

	/**
	 * Guarda uma recusa e avisa quem escreveu o filtro.
	 *
	 * @param string $nome   Nome oferecido.
	 * @param string $motivo O que aconteceu, e o que fazer.
	 * @return void
	 */
	private static function recusar( string $nome, string $motivo ): void {
		foreach ( self::$recusadas as $ja ) {
			if ( $ja['nome'] === $nome ) {
				return;
			}
		}

		self::$recusadas[] = array(
			'nome'   => $nome,
			'motivo' => $motivo,
		);

		if ( function_exists( '_doing_it_wrong' ) ) {
			_doing_it_wrong(
				'f3base_modulos',
				esc_html( $nome . ' — ' . $motivo ),
				esc_html( defined( 'F3BASE_PLUGIN_VERSAO' ) ? F3BASE_PLUGIN_VERSAO : '' )
			);
		}
	}

	/**
	 * Instâncias compartilhadas (as que registram hooks).
	 *
	 * @return array<string,F3Base_Modulo>
	 */
	public static function modulos(): array {
		if ( null !== self::$modulos ) {
			return self::$modulos;
		}

		self::$modulos = self::instanciar();

		return self::$modulos;
	}

	/**
	 * Um módulo pelo id.
	 *
	 * @param string $id Identificador do módulo.
	 * @return F3Base_Modulo|null
	 */
	public static function modulo( string $id ): ?F3Base_Modulo {
		$modulos = self::modulos();

		return isset( $modulos[ $id ] ) ? $modulos[ $id ] : null;
	}

	/**
	 * Instâncias novas, para medir estado no momento do relatório.
	 *
	 * @return array<string,F3Base_Modulo>
	 */
	public static function instanciar(): array {
		$modulos = array();

		foreach ( self::classes() as $classe ) {
			/** @var F3Base_Modulo $modulo */
			$modulo = new $classe();

			$modulos[ $modulo->id() ] = $modulo;
		}

		return $modulos;
	}

	/**
	 * Relatório completo, medido agora.
	 *
	 * A tela do wp-admin e o relatório da implantação consomem esta estrutura —
	 * é o que impede código, tela e relatório de divergirem.
	 *
	 * @return array<string,mixed>
	 */
	public static function relatorio(): array {
		$modulos     = self::instanciar();
		$reivindicadas = array();
		$linhas      = array();

		foreach ( $modulos as $modulo ) {
			$estado = $modulo->estado();

			$options = array();
			foreach ( $modulo->options_que_controlam() as $nome ) {
				$linha = self::linha_de_option( $nome );
				if ( null !== $linha ) {
					$options[]       = $linha;
					$reivindicadas[] = $nome;
				}
			}

			$hooks = array();
			foreach ( $modulo->hooks() as $hook ) {
				$hooks[] = array(
					'tipo'       => (string) $hook['tipo'],
					'hook'       => (string) $hook['hook'],
					'metodo'     => (string) $hook['metodo'],
					'prioridade' => (int) $hook['prioridade'],
					'args'       => (int) $hook['args'],
					'sempre'     => ! empty( $hook['sempre'] ),
				);
			}

			$linhas[] = array(
				'id'            => $modulo->id(),
				'nome'          => $modulo->nome(),
				'descricao'     => $modulo->descricao(),
				'estado'        => $estado['estado'],
				'motivo'        => $estado['motivo'],
				'registra_hooks' => $modulo->deve_registrar(),
				'dependencias'  => $modulo->dependencias(),
				'options'       => $options,
				'hooks'         => $hooks,
				'atividade'     => $modulo->atividade(),
				'avisos'        => self::avisos_do( $modulo ),
			);
		}

		$sem_modulo = array();
		foreach ( F3Base_Options::nomes() as $nome ) {
			if ( in_array( $nome, $reivindicadas, true ) ) {
				continue;
			}

			$linha = self::linha_de_option( $nome );
			if ( null !== $linha ) {
				$sem_modulo[] = $linha;
			}
		}

		$relatorio = array(
			'plugin'            => array(
				'nome'           => 'Base Site Core Fator3',
				'versao'         => F3BASE_PLUGIN_VERSAO,
				'rest_namespace' => F3BASE_REST_NAMESPACE,
				'gerado_em'      => time(),
			),
			'resumo'            => self::resumo( $linhas ),
			'modulos'           => $linhas,
			'options_sem_modulo' => $sem_modulo,
			/*
			 * O QUE O FILTRO OFERECEU E O REGISTRO NÃO ACEITOU. Lista vazia na
			 * operação normal; com item, ela é a única resposta à pergunta "por
			 * que o módulo que eu acrescentei não faz nada".
			 */
			'modulos_recusados'  => self::classes_recusadas(),
		);

		/**
		 * Permite ao implantador enriquecer o relatório sem duplicar a fonte.
		 *
		 * @param array<string,mixed> $relatorio Relatório montado do registro.
		 */
		return apply_filters( 'f3base_site_core_relatorio', $relatorio );
	}

	/**
	 * AVISOS de um módulo, normalizados.
	 *
	 * O estado do aviso é fechado em WARN — a lista de estados do contrato tem
	 * seis nomes e este é o único que cabe a "funciona, e custa isto". Item sem
	 * motivo é descartado: aviso sem consequência nomeada é ruído amarelo.
	 *
	 * @param F3Base_Modulo $modulo Módulo.
	 * @return array<int,array{estado:string,motivo:string}>
	 */
	private static function avisos_do( F3Base_Modulo $modulo ): array {
		$saida = array();

		foreach ( $modulo->avisos() as $aviso ) {
			if ( ! is_array( $aviso ) ) {
				continue;
			}

			$motivo = isset( $aviso['motivo'] ) ? trim( (string) $aviso['motivo'] ) : '';

			if ( '' === $motivo ) {
				continue;
			}

			$saida[] = array(
				'estado' => 'WARN',
				'motivo' => $motivo,
			);
		}

		return $saida;
	}

	/**
	 * Contagem por estado.
	 *
	 * @param array<int,array<string,mixed>> $linhas Linhas do relatório.
	 * @return array<string,int>
	 */
	private static function resumo( array $linhas ): array {
		$resumo = array(
			F3Base_Modulo::ATIVO     => 0,
			F3Base_Modulo::DEGRADADO => 0,
			F3Base_Modulo::INATIVO   => 0,
		);

		foreach ( $linhas as $linha ) {
			$estado = (string) $linha['estado'];

			if ( isset( $resumo[ $estado ] ) ) {
				++$resumo[ $estado ];
			}
		}

		return $resumo;
	}

	/**
	 * Monta a linha de uma option gerenciada.
	 *
	 * @param string $nome Nome da option.
	 * @return array<string,mixed>|null
	 */
	private static function linha_de_option( string $nome ): ?array {
		$declaracao = F3Base_Options::declaracao( $nome );

		if ( null === $declaracao ) {
			return null;
		}

		/*
		 * SEGREDO NÃO ENTRA NO RELATÓRIO, e o `null` é deliberado. Este array é
		 * o corpo da rota `/f3base/v1/relatorio` e o que a tela renderiza: um
		 * token de fornecedor aqui é a credencial servida em JSON a qualquer
		 * administrador, e presente em toda captura de tela do painel. O que sai
		 * no lugar é o MARCADOR — existe ou não existe —, e para isso a leitura
		 * do valor acontece e o valor é descartado na mesma linha.
		 */
		$origem  = F3Base_Options::proveniencia( $nome );
		$segredo = F3Base_Options::e_segredo( $nome );
		$valor   = $segredo ? null : F3Base_Options::ler( $nome );

		return array(
			'nome'          => $nome,
			'rotulo'        => (string) $declaracao['rotulo'],
			'descricao'     => (string) $declaracao['descricao'],
			'operavel'      => F3Base_Options::operavel( $nome ),
			'campo'         => (string) $declaracao['campo'],
			'existe'        => F3Base_Options::existe( $nome ),
			'valor'         => $valor,
			'valor_texto'   => $segredo
				? F3Base_Options::marcador_de_segredo( F3Base_Options::ler( $nome ) )
				: self::formatar( $valor ),
			'origem'        => $origem,
			'origem_rotulo' => F3Base_Options::rotulo_origem( $origem ),
			'carimbo'       => F3Base_Options::carimbo( $nome ),
		);
	}

	/**
	 * Formata um valor para leitura humana.
	 *
	 * @param mixed $valor Valor lido.
	 * @return string
	 */
	private static function formatar( $valor ): string {
		if ( is_bool( $valor ) ) {
			return $valor ? __( 'sim', 'f3base' ) : __( 'não', 'f3base' );
		}

		if ( is_array( $valor ) ) {
			if ( array() === $valor ) {
				return __( '(vazio)', 'f3base' );
			}

			$json = wp_json_encode( $valor, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

			return is_string( $json ) ? $json : '';
		}

		if ( null === $valor || '' === $valor ) {
			return __( '(vazio)', 'f3base' );
		}

		return (string) $valor;
	}
}
