# Instruções do plugin — Base Site Core Fator3

## O que este documento é

Ele viaja **dentro do zip do plugin** e é a única coisa que outro agente lê para entender, operar
e MUDAR este plugin. Quem o lê não tem a memória da operação que o produziu: nada aqui depende de
conversa anterior, e cada afirmação verificável aponta para o arquivo — e, quando é preciso, a
função — em que ela pode ser conferida.

Ele **não** narra a história das correções: o registro linha a linha do que mudou vive em
`suite/correcoes/`, no repositório, e as decisões são narradas no `MEMORIA-DECISOES.md` de lá.
Aqui fica o estado atual e a razão dele.

<!-- gerado:inicio=plugin-identidade -->
> Este bloco é **gerado** por leitura de disco na primeira etapa do comando único, antes de o zip
> ser montado, e conferido por `estatica.carimbo_de_release_nos_documentos`. Nenhum número deste
> documento é digitado à mão: número digitado envelhece em silêncio, e um documento que descreve
> outro plugin é pior do que documento nenhum.

| Fato medido | Valor |
|---|---|
| Nome do artefato | `Base Site Core Fator3` |
| Versão, lida do cabeçalho | `1.2.0` |
| Pasta instalada | `base-site-core-fator3` |
| Prefixo interno | `f3base` |
| Namespace REST | `f3base/v1` |
| Text domain | `f3base` |
| WordPress mínimo · PHP mínimo | `6.4` · `8.1` |
| Módulos no registro único | 18 |
| Options no catálogo | 29 |
| Options operáveis na tela | 18 |
| Eventos de comportamento declarados | 7 |
| Rotas REST registradas | 7 |
| Tabelas próprias com colunas declaradas | 2 |
| Arquivos na fonte do plugin | 42 |
| Arquivos vindos de `partilhado/` | 5 |
<!-- gerado:fim=plugin-identidade -->

### A regra do número, dita com precisão

Este documento tem regiões marcadas `gerado:inicio` / `gerado:fim`. Elas são reescritas por
`suite/lib/documentos.php` na PRIMEIRA etapa do comando único, por leitura de disco, antes de o zip
ser montado; `estatica.carimbo_de_release_nos_documentos` compara cada região com a medição de
agora e reprova a que divergir. Se você mudar o plugin, **não conserte os números aqui**:
reempacote, e eles se consertam sozinhos.

Fora das regiões geradas valem duas proibições, e quem as aplica é
`pacote.instrucoes_do_plugin_no_zip`:

- **Contagem digitada em prosa não entra.** Ela está certa no dia em que foi escrita e é
  contradita pela rodada seguinte, sem nada acusando. Contagem pertence a região gerada.
- **Limite e prazo do código não são transcritos aqui.** Eles têm região própria — a
  `plugin-limites`, gerada de `const` e do padrão de cada `apply_filters` do plugin —, e a prosa
  aponta para ela em vez de repetir o valor.

O que sobra de número em prosa é o que o detector isenta e a razão da isenção: marcador de lista
ordenada, dígito colado a letra (que é NOME) e número dentro de vão de código que existe VERBATIM
na fonte do plugin — um código de resposta HTTP que a rota emite, por exemplo. Bloco de código
cercado fica inteiro fora da varredura: ali o número é argumento de consulta.

---

## Como o plugin está organizado

### O que ele é

É a **peça persistente** de uma arquitetura de três peças — implantador, tema e plugin. O
implantador constrói o site e se autodesativa; o tema pode ser trocado; este plugin fica. Tudo o
que precisa sobreviver à troca de tema mora aqui: medição, consentimento, leads, retenção,
cabeçalhos de resposta, arquivos para leitores automáticos.

Ele tem **release própria** e numeração própria: não é construído pelo implantador, é publicado
como zip e instalado em qualquer site desta operação como qualquer outro plugin de catálogo. A
numeração recomeçou na release em que ele deixou de ser parte do implantador — herdar a série
anterior diria que este é o mesmo artefato de antes com uma correção a mais, e o que mudou foi o
que ele **é**.

**Ele exige PHP de sessenta e quatro bits e não suporta multisite.** As duas condições estão no cabeçalho de
`base-site-core-fator3.php`, e a segunda é aplicada: `F3Base_Site_Core::ativar()` chama
`recusar_ativacao_em_rede()`, que desativa o plugin e explica por quê. As duas seções finais deste
documento dizem o custo de cada uma.

**A pasta `fontes/plugin/` do repositório NÃO é instalável como está.** Faltam os arquivos de
CONTRATO COMPARTILHADO com o implantador — `includes/class-f3base-chaves-seo.php`,
`includes/class-f3base-vocabulario.php`, `includes/class-f3base-emissores.php`,
`includes/class-f3base-censo-demonstrativo.php` e `dados/emissores-conhecidos.tsv` —, que moram em
`partilhado/` no repositório e são copiados para dentro do zip pelo empacotamento. Quem instala,
instala o **zip publicado**. `pacote.plugin_completo_no_zip` confere, a cada rodada, que o zip
contém cada arquivo da lista de autoload.

### O registro único de módulos

`includes/class-f3base-registro.php` guarda a **única** lista de módulos. Ela alimenta três coisas
e não existe segunda lista: o registro dos hooks, em `includes/class-f3base-plugin.php`; a tela do
wp-admin, em `admin/class-f3base-admin-tela.php`; e o relatório que a rota de leitura devolve e que
o implantador consome. Módulo novo aparece nos três lugares sozinho.

<!-- gerado:inicio=plugin-modulos -->
| Módulo | Arquivo | Options que o controlam | Hooks (tipo, gancho, prioridade) |
|---|---|---|---|
| `F3Base_Modulo_Acessos_Servidor`<br>id `acessos-servidor` | `class-f3base-modulo-acessos-servidor.php` | `f3base_acessos`, `f3base_acessos_estado`, `tipo`, `action`, `hook`, `init`, `metodo`, `inicializar`, `prioridade`, `args`, `sempre`, `f3base_acessos_somar`, `somar`, `f3base_acessos_continuar` | `action init (25)`<br>`action f3base_acessos_somar (10)`<br>`action f3base_acessos_continuar (10)` |
| `F3Base_Modulo_Cabecalhos`<br>id `cabecalhos` | `class-f3base-modulo-cabecalhos.php` | `f3base_cabecalhos` | `action send_headers (10)`<br>`filter rest_pre_serve_request (10)` |
| `F3Base_Modulo_Cadencia_Relatorio`<br>id `cadencia-relatorio` | `class-f3base-modulo-cadencia-relatorio.php` | `f3base_cadencia`, `f3base_cadencia_estado` | `filter cron_schedules (10)`<br>`action init (20)`<br>`action f3base_cadencia_relatorio (10)`<br>`action updated_option (10)`<br>`action added_option (10)`<br>`action deleted_option (10)` |
| `F3Base_Modulo_Comportamento`<br>id `comportamento` | `class-f3base-modulo-comportamento.php` | `f3base_comportamento` | `action init (20)`<br>`action rest_api_init (10)` |
| `F3Base_Modulo_Consentimento`<br>id `consentimento` | `class-f3base-modulo-consentimento.php` | `f3base_consentimento` | `action wp_enqueue_scripts (1)`<br>`action wp_footer (20)` |
| `F3Base_Modulo_Endpoint_Leads`<br>id `endpoint-leads` | `class-f3base-modulo-endpoint-leads.php` | `f3base_contato`, `f3base_endpoint_segredo`, `f3base_origem_confiavel` | `action init (10)`<br>`action init (20)`<br>`action rest_api_init (10)` |
| `F3Base_Modulo_Leads_Whatsapp`<br>id `leads-whatsapp` | `class-f3base-modulo-leads-whatsapp.php` | `f3base_contato`, `f3base_atribuicao` | `action wp_enqueue_scripts (10)`<br>`filter render_block (10)` |
| `F3Base_Modulo_Llms_Full_Txt`<br>id `llms-full-txt` | `class-f3base-modulo-llms-full-txt.php` | `f3base_llms` | `action template_redirect (0)` |
| `F3Base_Modulo_Llms_Txt_Reserva`<br>id `llms-txt-reserva` | `class-f3base-modulo-llms-txt-reserva.php` | `f3base_llms` | `action template_redirect (0)` |
| `F3Base_Modulo_Meta_Capi`<br>id `meta-capi` | `class-f3base-modulo-meta-capi.php` | `f3base_meta_capi_token`, `f3base_meta_pixel_id` | `action f3base_meta_capi_enviar (10)` |
| `F3Base_Modulo_Noindex_Honrado`<br>id `noindex-honrado` | `class-f3base-modulo-noindex-honrado.php` | nenhuma | `filter wp_robots (20)` |
| `F3Base_Modulo_Redirects`<br>id `redirects` | `class-f3base-modulo-redirects.php` | `f3base_redirects` | `action template_redirect (1)` |
| `F3Base_Modulo_Retencao_Eliminacao`<br>id `retencao-e-eliminacao` | `class-f3base-modulo-retencao-eliminacao.php` | `f3base_retencao_meses`, `f3base_journal_eliminacao` | `action init (20)`<br>`action f3base_retencao_limpeza (10)`<br>`action rest_api_init (10)`<br>`filter wp_privacy_personal_data_exporters (10)`<br>`filter wp_privacy_personal_data_erasers (10)` |
| `F3Base_Modulo_Rota_Origem`<br>id `rota-origem` | `class-f3base-modulo-rota-origem.php` | nenhuma | `action rest_api_init (10)` |
| `F3Base_Modulo_Schema_Extensao`<br>id `schema-extensao` | `class-f3base-modulo-schema-extensao.php` | `f3base_seo_entidade` | `filter wpseo_schema_organization (20)`<br>`filter wpseo_schema_graph (20)` |
| `F3Base_Modulo_Sessao_De_Login`<br>id `sessao-de-login` | `class-f3base-modulo-sessao-de-login.php` | `f3base_sessao`, `tipo`, `filter`, `hook`, `auth_cookie_expiration`, `metodo`, `duracao`, `prioridade`, `self::PRIORIDADE`, `args`, `action`, `login_form_login`, `lembrar`, `wp_login_form_defaults`, `padroes_formulario` | nenhum |
| `F3Base_Modulo_Tracking`<br>id `tracking` | `class-f3base-modulo-tracking.php` | `f3base_gtm_container_id`, `f3base_ga4_measurement_id`, `f3base_google_ads`, `f3base_meta_pixel_id`, `f3base_linkedin_partner_id`, `f3base_linkedin_conversion_id` | `action wp_enqueue_scripts (20)` |
| `F3Base_Modulo_Verificacao_Dominio`<br>id `verificacao-dominio` | `class-f3base-modulo-verificacao-dominio.php` | `f3base_verificacao_google`, `f3base_verificacao_meta` | `action wp_head (1)` |
<!-- gerado:fim=plugin-modulos -->

A coluna de options é lida de `options_que_controlam()` de cada módulo, e a leitura resolve as três
formas em que uma lista pode ser declarada: literal, `self::CONST` e chamada a método do próprio
módulo — `array_keys( self::tags() )` é a forma que o módulo de verificação de domínio usa. Uma
forma não lida sairia da tabela como "nenhuma", e ausência parece um fato medido.

### O ciclo de um módulo

Cada módulo estende `F3Base_Modulo` (`includes/class-f3base-modulo.php`) e declara: `id()`,
`nome()`, `descricao()`, `hooks()`, `options_que_controlam()`, `dependencias()`, `atividade()`,
`avisos()` e `calcular_estado()`.

**O estado é fechado em três valores** — `ativo`, `degradado`, `inativo` — e vem **sempre com
motivo**. `degradado` é reservado ao que está PIOR que o desenho; reserva ociosa com o principal
funcionando é `ativo`.

**Módulo inativo é inerte de verdade:** nenhum hook é registrado, nenhum endpoint existe, nenhum
asset é enfileirado. A exceção é declarada por hook, no próprio item, pela marca `sempre`, e existe
por um motivo só: há filtro cuja decisão é POR OBJETO e cujo caso mais importante acontece
justamente com o módulo inativo — o filtro que decide se o bloco do botão de contato é publicado.
Um filtro desses que não se registra não decide nada, e a regra vira letra morta sem ninguém
perceber.

**`avisos()` é outra coisa:** é o que funciona **e custa alguma coisa em outro lugar**. Aviso não é
estado — o módulo continua ativo e nada é recusado. Aviso sem consequência nomeada é descartado
pelo registro, porque aviso que sai sempre treina o operador a ignorar aviso.

**`instalar()` e `desinstalar()` são do módulo.** A ativação chama `instalar()` só nos módulos que
devem registrar; a desativação chama `desinstalar()` em todos. Estrutura que precisa nascer também
numa ATUALIZAÇÃO de versão não pode depender do gancho de ativação — ele não roda numa atualização
— e por isso o módulo de comportamento a garante em `init`.

### O gravador único de options, e a leitura de volta

`includes/class-f3base-options.php` é o **gravador único**. Regra dura do contrato: nenhuma chamada
direta a `update_option`, `update_site_option` ou `delete_option` fora dessa classe. Todo módulo, a
tela e o `uninstall.php` passam por ali, e `estatica.detector_escrita_unica` varre o pacote inteiro
atrás de exceção.

`gravar()` faz, nesta ordem: **recusa declarada**, sanitização, ajuste de escrita, gravação,
**leitura de volta** pelo mesmo sanitizador e comparação. Devolve `ok`, `lido` e `motivo`, e o
motivo distingue "divergiu da gravação" de "foi normalizado pela sanitização antes de gravar".

**A recusa vem ANTES da sanitização**, e é a diferença entre devolver a decisão a quem a tomou e
decidir por ele. O valor recusado não é reescrito nem gravado: o que estava no banco continua lá.
Só declara recusa a option cujo valor fora da faixa significaria o OPOSTO do pedido — o caso é
`f3base_retencao_meses` no valor mínimo do campo, em que quem queria desligar a limpeza obtinha o
prazo mais curto possível. A regra mora em `F3Base_Options::recusa_retencao_meses()`. Não existe
"mínimo declarado" que eleve valor em silêncio.

**Ler passa pelo sanitizador.** Chave ausente ou valor corrompido não vira aviso no consumidor: a
leitura devolve forma.

### A proveniência, e as duas options que não são configuração

A **procedência** de cada chave — implantador, edição manual ou padrão embutido — e o carimbo da
última escrita ficam em `f3base_proveniencia`. `f3base_operaveis`, quando presente, RESTRINGE o que
a tela abre: o catálogo é o teto, e essa lista nunca abre o que o catálogo declarou estrutural.

As duas **não têm entrada no catálogo**, e a consequência é precisa:

- `gravar()` as RECUSA, porque `gravar()` exige declaração de catálogo. Quem escreve
  `f3base_proveniencia` é `registrar_proveniencia()`, o método privado da própria classe, pelo
  mesmo `escrever()` que todas as outras usam, com `autoload` desligado.
- `f3base_operaveis` é gravada pelo IMPLANTADOR e apenas LIDA aqui, em `F3Base_Options::operavel()`.
- as duas entram em `proprias()` e em `descartaveis_na_desinstalacao()`, e é por isso que
  `remover()` as aceita e a desinstalação as leva.

**Procedência só é registrada em gravação de CONFIGURAÇÃO.** Carimbo de execução não tem
procedência: ninguém escolheu que a última limpeza foi na hora em que ela foi. `estado_de_execucao()`
sai do catálogo, chave a chave, e as chaves do implantador dentro da entrada — o resumo do valor e
a release — são preservadas quando o valor não mudou.

### As três habilidades MCP

O plugin registra três habilidades para o agente:

| Habilidade | Onde | O que faz |
|---|---|---|
| `f3base/como-usar` | `includes/class-f3base-como-usar.php` | Diz por assunto o que o plugin já faz, a option exata para mudar cada coisa e o que NÃO fazer por outro caminho. A lista de assuntos sai do REGISTRO de módulos |
| `f3base/config-ler` | `includes/class-f3base-config-mcp.php` | Lê a configuração do implantador e o schema dela |
| `f3base/config-escrever` | `includes/class-f3base-config-mcp.php` | Grava a configuração, tudo ou nada, validando pelo validador do implantador |

**Duas coisas fazem as três existirem, e sem qualquer uma delas o núcleo as recusa em silêncio:**
o gancho é `wp_abilities_api_init` — com o prefixo, que é a grafia que o núcleo dispara — e cada
habilidade declara `category`. `F3Base_Site_Core::registrar_hooks()` liga os dois registradores
nesse gancho, e a categoria própria do plugin é registrada antes por
`wp_register_ability_category()`. `wp.habilidades_registradas` mede as três num WordPress real, e o
mutante que tira a categoria prova que a medição sabe reprovar.

**Existir no registro não é executar, e a suíte mede as duas coisas separadas.** O núcleo valida a
entrada contra `input_schema` antes de chamar o callback, e ele indexa `properties` como ARRAY: um
`stdClass` ali — a forma que se usa para um mapa vazio sair como `{}` — derruba a chamada com
`Error` antes de o callback existir, com a habilidade intacta no registro. Por isso `properties`
é array PHP nos schemas que têm campos, e em `como-usar`, que não recebe entrada, a chave não
existe. `wp.habilidades_de_config_executam` chama `config-ler` e `config-escrever` num WordPress
real com a entrada que o schema pede — como administrador e sem usuário — e chama `como-usar` com
um campo fora do schema; o mutante que devolve o `stdClass` aos três prova que o passo sabe reprovar.

`mcp.options_citadas_existem` cruza toda option citada no manual com o catálogo: gravar uma option
que módulo nenhum lê não falha, não avisa e não muda nada, e quem seguiu a instrução conclui que o
plugin não faz o que o próprio manual dele afirma.

### O contrato de nomes

O **prefixo interno não muda de site para site**, e essa é a metade que importa. Nome de pasta é
ENDEREÇO: trocá-lo custa uma reinstalação. Nome de option é CHAVE DE DADO: trocá-lo orfana o valor
sem apagar nada e sem erro nenhum, e o site passa a rodar no padrão de fábrica em cima de uma
configuração que ninguém apagou. Nome de tabela é pior — renomear cria uma tabela vazia ao lado e
orfana a série histórica. Nome de evento é pior ainda — renomear quebra a série na conta de medição
do fornecedor, onde não há como reparar depois.

`dados/contrato-de-nomes.tsv` declara as grafias que a ferramenta de renomeação de prefixo NÃO
reescreve. Ele cobre **TODA option do catálogo** — não só as que o implantador grava —, todo evento
declarado, as tabelas, o namespace REST, as classes compartilhadas, o hook da cadência e o prefixo
da classe de seção medida. `renomeacao.contrato_de_nomes_completo` confere essa cobertura, e
`estatica.sem_residuo_de_prefixo` confere que a renomeação não deixou resíduo.

---

## As options

<!-- gerado:inicio=plugin-options -->
| Option | Seção da tela | Campo | Operável | Sub-campos | Sanitizador |
|---|---|---|---|---|---|
| `f3base_contato` | contato | grupo | sim | 2 | `sanitiza_contato` |
| `f3base_ga4_measurement_id` | medicao | texto | sim | — | `sanitiza_id_de_tag` |
| `f3base_gtm_container_id` | medicao | texto | sim | — | `sanitiza_id_de_tag` |
| `f3base_google_ads` | medicao | grupo | sim | 2 | `sanitiza_google_ads` |
| `f3base_meta_pixel_id` | medicao | texto | sim | — | `sanitiza_id_de_tag` |
| `f3base_meta_capi_token` | medicao | segredo | sim | — | `sanitiza_segredo_opaco` |
| `f3base_linkedin_partner_id` | medicao | texto | sim | — | `sanitiza_partner_id` |
| `f3base_linkedin_conversion_id` | medicao | texto | sim | — | `sanitiza_partner_id` |
| `f3base_atribuicao` | medicao | grupo | sim | 2 | `sanitiza_atribuicao` |
| `f3base_verificacao_google` | medicao | texto | sim | — | `sanitiza_token_de_verificacao` |
| `f3base_verificacao_meta` | medicao | texto | sim | — | `sanitiza_token_de_verificacao` |
| `f3base_consentimento` | consentimento | grupo | sim | 4 | `sanitiza_consentimento` |
| `f3base_retencao_meses` | privacidade | inteiro | sim | — | `sanitiza_retencao_meses` |
| `f3base_acessos` | medicao | grupo | sim | 4 | `sanitiza_acessos` |
| `f3base_acessos_estado` | — | grupo | não | — | `sanitiza_lista_generica` |
| `f3base_sessao` | privacidade | grupo | sim | 2 | `sanitiza_sessao` |
| `f3base_comportamento` | privacidade | grupo | sim | 4 | `sanitiza_comportamento` |
| `f3base_origem_confiavel` | privacidade | grupo | sim | 3 | `sanitiza_origem_confiavel` |
| `f3base_llms` | privacidade | grupo | sim | 7 | `sanitiza_llms` |
| `f3base_redirects` | — | grupo | não | — | `sanitiza_redirects` |
| `f3base_seo_entidade` | — | grupo | não | — | `sanitiza_seo_entidade` |
| `f3base_cabecalhos` | — | grupo | não | — | `sanitiza_cabecalhos` |
| `f3base_nav_id` | — | inteiro | não | — | `sanitiza_id_post` |
| `f3base_mcp_files_audit` | — | grupo | não | — | `sanitiza_auditoria_do_canal` |
| `f3base_atividade` | — | grupo | não | — | `sanitiza_atividade` |
| `f3base_journal_eliminacao` | — | grupo | não | — | `sanitiza_journal` |
| `f3base_cadencia` | — | grupo | não | — | `sanitiza_cadencia` |
| `f3base_cadencia_estado` | — | grupo | não | — | `sanitiza_cadencia_estado` |
| `f3base_endpoint_segredo` | — | segredo | não | — | `sanitiza_segredo` |
<!-- gerado:fim=plugin-options -->

### As regras que valem para TODOS os sanitizadores

1. **Chave desconhecida dentro de um grupo é PRESERVADA, em todos os níveis.** `preservar_desconhecidas()`
   desce a estrutura, e é por isso que o que um agente gravou por um caminho lateral não é apagado
   pela primeira gravação da tela. Preservar só o primeiro nível apagava as chaves de dentro dos
   itens de lista sem que ninguém percebesse.
2. **Normalização é AVISADA, e o aviso nomeia o campo.** A comparação é entre a ENTRADA e a leitura
   de volta, campo a campo, e vale para grupo — "algo foi normalizado" não serve a quem precisa
   descobrir qual dos campos do grupo não entrou como ele escreveu. Quem mede é
   `options.normalizacao_avisa`.
3. **Sanitizar duas vezes dá o mesmo que sanitizar uma.** Idempotência é o que faz a leitura de
   volta conferir; sem ela `gravar()` acusa divergência sobre um valor que ela mesma produziu. Quem
   mede é `options.sanitizador_idempotente`, sobre todo o catálogo.
4. **Valor que significaria o oposto do pedido é RECUSADO, não reescrito.** A recusa devolve o
   valor anterior de pé e o motivo nomeado.
5. **Segredo é mascarado na exibição e EDITÁVEL na tela.** `segredos_do_site()` declara as duas
   âncoras — `f3base_meta_capi_token` e `f3base_endpoint_segredo` —, `marcador_de_segredo()` produz
   a máscara, e nem o relatório da rota nem o `value` do campo carregam o valor em claro. A
   declaração tem duas invariantes que um detector cobra a cada rodada: o nome não aparece no
   arquivo de configuração do implantador nem no schema dele, e nenhum lote do implantador as grava.

### O que cada uma é, e o que acontece com ela vazia

| Option | O que é | Forma esperada | Quem grava | Vazia |
|---|---|---|---|---|
| `f3base_contato` | Para onde vai quem clica no botão de contato, e com que mensagem a conversa começa | grupo: número em formato internacional só com dígitos, mensagem livre | implantador; tela; canal | O botão do modelo **não é publicado** em página nenhuma. O site continua no ar, sem esse caminho de contato |
| `f3base_ga4_measurement_id` | Fluxo de dados da propriedade do Google Analytics | identificador do fornecedor | implantador; tela; canal | Nada chega ao Google Analytics. O resumo próprio do site continua |
| `f3base_gtm_container_id` | Contêiner do Gerenciador de Tags | identificador do fornecedor | implantador; tela; canal | O site publica as tags diretas de cada ID preenchido. Preenchida, ela é o **único** caminho e desliga toda tag direta |
| `f3base_google_ads` | A conta e a ação de conversão que recebem o clique | grupo: identificador da conta e rótulo da ação | implantador; tela; canal | Nenhuma conversão vai ao Google Ads. **Só uma das metades preenchida também não envia nada**, e sai um aviso |
| `f3base_meta_pixel_id` | Pixel de Facebook e Instagram | só dígitos | implantador; tela; canal | Nenhum código da Meta existe na página |
| `f3base_meta_capi_token` | Credencial do envio de servidor | opaca | **só** tela ou canal — nunca o arquivo de configuração | Existe apenas o envio pelo navegador, e o que ele perder está perdido |
| `f3base_linkedin_partner_id` | Conta de anúncios do LinkedIn | só dígitos | implantador; tela; canal | Nenhum código do LinkedIn existe na página |
| `f3base_linkedin_conversion_id` | Conversão do LinkedIn no clique do botão | só dígitos | implantador; tela; canal | O identificador de parceiro sozinho registra apenas visitas |
| `f3base_atribuicao` | Qual campanha leva o crédito, e por quanto tempo | grupo: modelo do vocabulário e prazo em dias | implantador; tela; canal | Cai no padrão embutido: primeiro toque, com o prazo padrão |
| `f3base_verificacao_google` | Token de posse do domínio no Search Console | token do console | implantador; tela; canal | Nenhuma metatag é publicada; a verificação por DNS dispensa este campo |
| `f3base_verificacao_meta` | Token de posse do domínio no Gerenciador de Negócios | token do console | implantador; tela; canal | Nenhuma metatag é publicada |
| `f3base_consentimento` | O que vale antes de o visitante decidir, e por onde ele muda de ideia | grupo: política, controle no rodapé, aviso de primeira visita, prazo | implantador; tela; canal | O módulo fica DEGRADADO e o site opera sobre o padrão embutido, não sobre a política declarada do projeto |
| `f3base_retencao_meses` | Por quanto tempo os registros de contato ficam no site | inteiro em meses | implantador; tela; canal | Valor fora da faixa é RECUSADO na gravação, com o prazo anterior de pé. É o prazo que a política de privacidade promete |
| `f3base_comportamento` | O resumo que o site guarda por conta própria | grupo: liga/desliga, prazo do resumo, prazo do registro, período do painel | implantador; tela; canal | Cai no padrão embutido, que é **ligado** |
| `f3base_origem_confiavel` | Como o site descobre o endereço do visitante atrás de CDN | grupo: nome do cabeçalho, posição na cadeia e faixas de IP dos proxies | implantador; tela; canal | Sem cabeçalho declarado, conta pelo endereço da conexão. **Com as faixas de IP declaradas, o cabeçalho só é lido de quem vem delas**; com as faixas vazias ele é lido de qualquer conexão e o módulo AVISA, porque cabeçalho é texto que qualquer cliente manda |
| `f3base_llms` | O índice curto que apresenta o site a leitores automáticos | grupo: liga/desliga, textos, modo, tipos, texto integral, indexável | implantador; tela; canal | Cai no padrão embutido: ligado, texto integral desligado |
| `f3base_redirects` | Pares origem/destino aplicados antes do `404` | grupo de pares de caminho | implantador | Nenhum par declarado; o redirecionamento por slug antigo continua |
| `f3base_seo_entidade` | Propriedades de entidade e serviços para estender o grafo de SEO | grupo | implantador | Nada é acrescentado ao grafo. Vazio fica vazio, por desenho |
| `f3base_cabecalhos` | Cabeçalhos de segurança emitidos no front-end e no REST | grupo de vocabulário fechado por cabeçalho | implantador | Cai no padrão embutido, com HSTS desligado |
| `f3base_nav_id` | O post de navegação gerenciado | inteiro | implantador | Estrutural: quebrar o vínculo derruba o menu do topo |
| `f3base_mcp_files_audit` | Registro de escritas do canal de manutenção | grupo | complemento do canal | Leitura apenas; vazia significa nenhuma escrita registrada |
| `f3base_atividade` | Carimbos do que cada módulo fez por último | grupo | os próprios módulos | Estado de execução, não configuração. Vazia significa "nada aconteceu ainda", e a tela diz isso |
| `f3base_journal_eliminacao` | Identificador, contagem, carimbo, operador e regime de cada eliminação | grupo | o módulo de retenção | Nunca guarda o conteúdo eliminado. Vazia significa nenhuma eliminação |
| `f3base_cadencia` | Periodicidade, gatilho por ajustes, mecanismo e nome do hook | grupo | implantador | O módulo de cadência fica INATIVO |
| `f3base_cadencia_estado` | Contador de ajustes e carimbo previsto da próxima execução | grupo | o módulo de cadência | Estado de execução. Vazia recomeça a contagem |
| `f3base_endpoint_segredo` | Chave de assinatura do token efêmero do endpoint | opaca | **nasce dentro do plugin**, na ativação; nunca é exibida | Gerada na ativação. Declarada como segredo do site para que nunca possa ser declarada de fora |

---

## As duas tabelas, e a medição de comportamento

<!-- gerado:inicio=plugin-tabelas -->
**`<prefixo-do-wpdb>f3base_comportamento`**

| Coluna | Definição |
|---|---|
| `chave` | `char(64) NOT NULL` |
| `dia` | `char(10) NOT NULL` |
| `caminho` | `varchar(190) NOT NULL` |
| `metrica` | `varchar(64) NOT NULL` |
| `detalhe` | `varchar(60) NOT NULL DEFAULT ''` |
| `contagem` | `bigint unsigned NOT NULL DEFAULT 0` |
| `soma` | `double NOT NULL DEFAULT 0` |
| `atualizado_em` | `bigint unsigned NOT NULL DEFAULT 0` |
| _índice_ | `PRIMARY KEY (chave)` |
| _índice_ | `KEY dia (dia)` |
| _índice_ | `KEY dia_metrica (dia,metrica)` |

**`<prefixo-do-wpdb>f3base_eventos`**

| Coluna | Definição |
|---|---|
| `id` | `bigint unsigned NOT NULL AUTO_INCREMENT` |
| `visitante` | `char(32) NOT NULL` |
| `sessao` | `char(32) NOT NULL` |
| `dia` | `char(10) NOT NULL` |
| `caminho` | `varchar(190) NOT NULL` |
| `metrica` | `varchar(64) NOT NULL` |
| `detalhe` | `varchar(60) NOT NULL DEFAULT ''` |
| `valor` | `double NOT NULL DEFAULT 0` |
| `ocorrencia` | `int unsigned NOT NULL DEFAULT 1` |
| `ms` | `bigint unsigned NOT NULL DEFAULT 0` |
| `criado_em` | `bigint unsigned NOT NULL DEFAULT 0` |
| `ancora` | `varchar(16) NOT NULL DEFAULT ''` |
| _índice_ | `PRIMARY KEY (id)` |
| _índice_ | `KEY dia (dia)` |
| _índice_ | `KEY dia_caminho (dia,caminho)` |
| _índice_ | `KEY sessao (sessao)` |
| _índice_ | `KEY visitante (visitante)` |
<!-- gerado:fim=plugin-tabelas -->

O prefixo real é o do `wpdb` da instalação. Uma terceira tabela, `f3base_leads_dedup`, pertence ao
endpoint de leads e guarda a reserva de deduplicação e o balde do limite de pedidos; ela não tem
constante de colunas e por isso não aparece no bloco gerado acima.

### O que cada uma responde

`f3base_comportamento` é o **agregado**. Uma linha por dia, caminho, evento e detalhe, com contagem
e soma. Ele não identifica ninguém. Responde: quantas visitas viram este bloco, quantas passaram
deste marco, para onde o tráfego saiu, quanto o carregamento demorou.

`f3base_eventos` é o **registro**. Uma linha por acontecimento, com apelido sorteado do visitante,
identificador da visita, número da ocorrência, o deslocamento em milissegundos desde o carregamento
(`ms`), o instante do acionamento (`criado_em`) e a procedência desse instante (`ancora`). **Aqui
nada soma e nada é reescrito:** cada acionamento é uma linha, com `id` próprio. Responde: quanto
tempo a pessoa levou para descer até aqui, ela voltou e leu de novo, quantas pessoas diferentes
passaram por esta página. Por guardar isso, ele é **dado pessoal pseudonimizado**, ainda que o
apelido não diga quem a pessoa é.

**A TELA DIZ, EM CADA QUADRO, DE QUAL DAS DUAS ELE VEM.** A frase de cada tabela tem produtor único,
em `proposito_das_tabelas()`: escrita em cada quadro, ela divergiria na primeira edição apressada e
a tela passaria a descrever a mesma tabela de dois jeitos. O quadro de profundidade é o único que
mistura as duas — os totais de cada marco e o denominador saem do agregado, o tempo típico e a
releitura saem do registro — e ele diz isso.

### Por que o agregado NÃO é derivado do registro

**As retenções são diferentes, e essa é a razão maior.** O registro tem prazo CURTO
(`f3base_comportamento.retencao_eventos_dias`); o agregado pode durar
(`f3base_comportamento.retencao_dias`), e nunca menos. Derivar o agregado do registro faria a série
histórica do painel evaporar junto com o log na primeira execução da retenção.

**A leitura do painel é barata e precisa continuar sendo.** Recalcular totais varrendo o registro a
cada abertura de tela é aceitável com cem linhas e inaceitável com um milhão — e o site que mais
precisa da tela é justamente o que tem tráfego.

O preço é uma escrita a mais por requisição, na mesma chamada, sobre o mesmo corpo já validado.
**A ordem importa:** o agregado é somado ANTES do registro. Se o banco recusar a segunda escrita, o
número do painel continua certo e o que se perde é o detalhe.

`somar()` faz `INSERT … ON DUPLICATE KEY UPDATE` numa instrução só, e a chave primária é um resumo
criptográfico de `dia | caminho | evento | detalhe`. Ler, somar e gravar em três passos perderia
incrementos sob concorrência exatamente no horário de pico, que é quando o número importa.

### A declaração única dos eventos

`dados/eventos-comportamento.tsv` declara, num lugar só: nome do evento, parâmetros **na ordem em
que o coletor os entrega**, teto por página, gatilho, limiar, a pergunta que o evento responde em
português comum, a frase que a tabela bruta imprime, e a natureza (`uso` ou `tecnica`).

<!-- gerado:inicio=plugin-eventos -->
| Evento | Gatilho | Parâmetros | Teto por página | Limiar | Natureza |
|---|---|---|---|---|---|
| `f3base_rolagem` | `rolagem` | `f3base_marco` | 4 | `marcos=25,50,75,90;travessias_por_sessao=20;histerese_pp=5` | uso |
| `f3base_secao_vista` | `interseccao` | `f3base_secao` | 12 | `visivel=0.5;saida=0.2;travessias_por_sessao=20` | uso |
| `f3base_link_externo` | `clique-externo` | `f3base_dominio` | 10 | `—` | uso |
| `f3base_friccao` | `clique-repetido` | `f3base_cliques` | 3 | `cliques=4;janela_ms=1200;raio_px=24;alvo=interativo` | uso |
| `f3base_erro_js` | `erro` | `f3base_arquivo,f3base_linha` | 3 | `origem=site` | tecnica |
| `f3base_web_vital` | `desempenho` | `f3base_vital,f3base_valor` | 4 | `vitais=LCP,CLS,INP,TTFB;duracao_minima_ms=16` | tecnica |
| `f3base_pagina_vista` | `pagina` | nenhum | 1 | `inatividade_min=30` | uso |
<!-- gerado:fim=plugin-eventos -->

**O cliente NÃO conhece nome de evento.** Ele manda o GATILHO, e quem resolve o nome é o servidor,
contra esta declaração. Gatilho que não está lá não vira linha. É isso que torna o nome renomeável
num lugar só, sem tocar em uma linha de JavaScript.

**O GATILHO É CHAVE ÚNICA.** `declaracao( gatilho )`, em `assets/f3base-tracking.js`, devolve a
PRIMEIRA linha cuja coluna de gatilho casa, e `F3Base_Modulo_Tracking::eventos_de_comportamento()`
indexa por NOME do evento. Duas linhas com o mesmo gatilho fazem a segunda nunca disparar: o
coletor resolve a primeira e para. Evento novo exige **gatilho novo**, com coletor próprio — está
na receita, mais abaixo.

Nenhum número de limiar vive no cliente pela mesma razão do nome: os marcos de rolagem, os cliques
da fricção, a janela e o raio, as faixas do observador — todos saem daqui, publicados ao navegador
por `F3Base_Modulo_Tracking::comportamento()`.
`tracking.eventos_de_comportamento_declarados` reprova qualquer literal de nome declarado dentro do
JavaScript e cobra que a RESERVA de cada `numeroDoLimiar()` seja o mesmo número da declaração — uma
reserva menor apertaria o teto em silêncio no dia em que o arquivo se corrompesse.

**A ORDEM DOS PARÂMETROS É CARREGADA.** O coletor entrega os valores POSICIONALMENTE e o servidor
os casa com a coluna, na ordem em que ela está escrita. Trocar a ordem de dois parâmetros troca o
significado dos dois no relatório.

**O que nunca entra em parâmetro:** texto digitado, seletor com valor, URL com query, mensagem de
erro. Quem varre o payload é `js.comportamento_instrumentado`.

### Os coletores

Seis coletores, todos em `assets/f3base-tracking.js`, todos instalados pelo mesmo portão de
consentimento e só quando há destino:

- **rolagem** — marcos de profundidade sobre a faixa ROLÁVEL do documento (`altura - visível`), e a
  altura é RELIDA a cada medição: a imagem que carrega depois, o acordeão que abre e o bloco que
  expande entram na conta na medição seguinte. Página que cabe na tela conta como lida inteira, mas
  só depois de a página TERMINAR de carregar — medindo cedo, uma página longa cujas imagens ainda
  não tinham altura emitia todos os marcos de uma vez e os queimava.
- **interseccao** — seção vista, pelo NOME que o markup declara. Assunto da seção **Como marcar uma
  seção para ser medida**.
- **clique-externo** — só o HOST de destino, nunca a URL. Caminho e query são onde mora o
  identificador.
- **clique-repetido** — fricção: cliques repetidos no mesmo ponto, dentro de uma janela, em alvo
  interativo. O limiar não é dois nem três porque duplo clique é gesto normal de sistema e triplo
  clique é o gesto normal de selecionar um parágrafo.
- **erro** — erro de JavaScript **do próprio site**. A origem é o PORTÃO, não um parâmetro: erro de
  terceiro e de extensão do visitante ficam de fora porque nenhuma release nossa os conserta. A
  MENSAGEM não entra, porque ela carrega o valor interpolado que produziu o erro, e esse valor pode
  ser o dado do titular.
- **desempenho** — medidas de carregamento por observador nativo, sem biblioteca externa. O valor
  sai CRU e sem classificação: os cortes de bom/ruim são do fornecedor e mudam por calendário.
  `dados/vitais.tsv` guarda a explicação e o limiar que a tela mostra ao lado.

Mais um, que é o denominador: **pagina** — o contador de carregamentos. Sem ele não há proporção:
"duas pessoas chegaram ao fim" pode ser duas de duas ou duas de duzentas, e as duas leituras levam
a decisões opostas sobre o tamanho da página.

### O apelido do visitante: quando ele nasce

`podeIdentificar()`, em `assets/f3base-tracking.js`, decide — e ele responde pelo **portão do
consentimento**, e por mais nada. O apelido, e portanto o registro detalhado, nasce onde a medição é
permitida:

- **política pré-aprovada** — nasce já no primeiro carregamento. A política é decisão de projeto,
  declarada por quem implanta o site; o controle de recusa está no rodapé de toda página publicada;
  e a política de privacidade descreve a coleta.
- **política de negativa por padrão** — não nasce nada antes do aceite, e nasce no instante dele,
  sem esperar a navegação seguinte.
- **recusa no controle do rodapé** — o apelido é apagado do navegador **e** a exclusão do registro é
  pedida ao servidor, na mesma ação.

**O aviso de primeira visita não decide isto.** `f3base_consentimento.aviso_primeira_visita` liga e
desliga a faixa não bloqueante mostrada a quem chega, e nada além dela. Houve uma versão deste
cliente em que, no modo pré-aprovado, o apelido só nascia com esse aviso ligado; ela deixava o site
somando o agregado e sem registro detalhado nenhum, por omissão de um banner e sem que a política
tivesse mudado. O que estava errado era uma frase da tela Medição, que prometia consentimento onde
havia política declarada — e é essa frase que hoje diz qual política permitiu medir.

**Com o portão fechado para de existir a medição inteira**, e não só o registro: o resumo passa pela
mesma porta das quatro tags. Com o armazenamento local bloqueado é o contrário — o **agregado
continua inteiro** e o registro detalhado não acontece: medição parcial e anônima é melhor que
medição nenhuma.

### O contador de travessias é da VISITA; o estado armado é do CARREGAMENTO

**O contador atravessa a navegação.** Ele mora no registro da visita, no armazenamento local, e é
chaveado por `caminho | gatilho | detalhe`. **O caminho está na chave** porque o mesmo nome de bloco
em duas páginas são duas seções diferentes: somá-las responderia uma pergunta que ninguém fez e
esconderia as duas. Sem isso, quem passava por um bloco, ia para outra página e voltava era
registrado como primeira vez, sempre — e o limiar se chama `travessias_por_sessao`.

**O estado armado NÃO atravessa.** `dentro` (marcos) e `dentroDaVista` (seções) continuam sendo do
carregamento: uma página nova começa com nada em vista e nada rolado. Persistir "já estou dentro"
faria a primeira entrada do carregamento seguinte ser engolida.

### A banda de fronteira: entrada, saída e histerese

O observador de seção é armado com três faixas: zero, a linha de SAÍDA e a linha de ENTRADA, ambas
declaradas na mesma célula de limiar do TSV. A seção ENTRA quando a razão alcança a linha de entrada
e só REARMA quando cai abaixo da linha de saída. Entre as duas nada muda de estado — é banda, e não
indecisão. **Declaração incoerente cai no comportamento simétrico:** linha de saída ausente, não
numérica, negativa ou maior/igual à de entrada faz a saída virar a própria entrada. Banda invertida
não é banda mais larga: ela faz a seção contar em laço enquanto o visitante não mexer em nada.

O marco de rolagem tem a mesma proteção pelo `histerese_pp`: ele só rearma **abaixo de**
`marco - histerese_pp`, nunca na própria linha. Fronteira sem banda transforma TREMOR em leitura —
o dedo que segura a página, o cabeçalho que recolhe, a imagem que entra e empurra a altura do
documento fabricam uma travessia que ninguém fez. O que a banda **descarta** é o movimento abaixo
dela; o que ela **custa** é a reentrada curta e legítima que não chega a cruzá-la, e esse é o lado
certo de errar.

O **agregado continua contando uma vez por carregamento**. As duas leituras convivem: o total
responde "quantas visitas viram este bloco" e o registro responde "quantas vezes cada uma o viu".

### O envio: lote, confirmação de entrega e fila pendente durável

**Enviar-e-limpar, não enviar-uma-vez.** O evento de ocultamento dispara quando a aba perde o foco,
e não só quando a pessoa sai. Uma trava que fechasse ali deixaria a página SURDA pelo resto da
visita. Hoje a trava é apenas guarda de reentrância, e o lote resolve a contagem dobrada por
construção: cada selamento leva só o que foi acumulado desde o anterior, e o acumulado é esvaziado
ao selar. `estatica.saida_com_trava_de_uma_vez` cobra a trava dos dois emissores de saída.

**Confirmação de ENTREGA, não de enfileiramento.** O despacho usa `fetch` com `keepalive` quando o
navegador o tem — é a única combinação que dá as duas coisas: a requisição continua depois de a
página ser descarregada, e a resposta volta. O discriminante é `keepalive`, e não `fetch`. Sem essa
combinação, cai para `sendBeacon`, e ali o retorno diz que o navegador ACEITOU a carga, não que ela
chegou. Essa perda residual está declarada e é estritamente menor que a de antes: o lote pendente
já foi GRAVADO antes do despacho.

**A fila de pendentes é durável.** Cada entrada é um lote SELADO que já saiu do acumulado e ainda
não teve entrega confirmada, gravado no registro da visita e lido de volta pelo carregamento
seguinte da mesma visita. **A ordem é a do selamento, e o despacho a respeita: o pendente sai antes
do novo.** É o que faz a sequência de ocorrências fechar sem buraco mesmo quando um carregamento
inteiro morre no meio. **A fila não tem teto próprio:** toda linha que entra num lote já gastou o
orçamento da visita, e um segundo teto divergiria do primeiro na primeira vez que alguém mexesse
num só.

**Recusa permanente x transitória.** Os códigos de corpo inválido e de corpo grande nunca mudam por
esperar: o lote é esquecido e as linhas dele viram cortadas nomeadas. Tudo o mais é transitório e o
lote FICA, com o mesmo selo — rede caindo, token expirado (o carregamento seguinte leva um fresco),
medição desligada, balde cheio, migração em curso. Reter sem critério produz o pendente eterno, que
bloqueia atrás dele tudo o que veio depois.

**Um lote é partido no SELAMENTO, nunca no despacho.** Partir um lote já selado mudaria o conteúdo
sob o mesmo selo. Os totais e as cortadas viajam só no primeiro pedaço: repeti-los somaria o mesmo
total tantas vezes quantas o registro precisou ser partido. Uma linha sozinha que não cabe vira
cortada nomeada — sem essa saída o laço não avançaria.

### A âncora do lote, a guarda do relógio e o dia

**O carimbo de cada linha é o do ACIONAMENTO, e não o da chegada do lote.** O cliente calcula `ms` a
partir da origem temporal do carregamento (`window.performance.timeOrigin`, com `Date.now()` de
reserva) e envia essa origem **uma vez por lote, dentro do lote SELADO** — dentro do selo, e não no
despacho, para que ela sobreviva à fila pendente: um lote retomado no carregamento seguinte sairia
carimbado com a origem da página que o encontrou. O servidor grava `criado_em` de cada linha como
âncora mais deslocamento.

**A guarda do relógio.** `F3Base_Modulo_Comportamento::ancora_do_lote()` NÃO usa a origem do
visitante em quatro casos: ausente, não numérica, no futuro além da tolerância declarada
(`TOLERANCIA_RELOGIO_MS`, na região de limites) e mais velha que a janela de retenção do registro —
esse último limite não é um número próprio, é a própria
`f3base_comportamento.retencao_eventos_dias`, porque uma origem além dela gravaria uma linha que a
próxima poda apaga.

**A segunda âncora é derivada do servidor:** chegada menos o maior deslocamento do lote. Ela dá o
mesmo espaçamento relativo sem confiar em relógio nenhum. **A ORDEM e o ESPAÇAMENTO ficam certos nos
dois caminhos; o ABSOLUTO só é exato no primeiro**, o da origem aceita — um lote entregue com atraso
chega muito depois de ter sido selado.

**Qual âncora foi usada é uma COLUNA**, com produtor único nas constantes do módulo:

| Valor | O que ele diz |
|---|---|
| `visitante` | a origem do navegador passou na guarda: hora, ordem e espaçamento exatos |
| `servidor` | a origem foi recusada e a âncora saiu da chegada: ordem e espaçamento exatos, absoluto exato só quando o lote não ficou na fila |
| vazio | linha gravada por uma versão anterior: o carimbo é o da CHEGADA do lote |

A pergunta "quanto vale este horário?" é de CADA LINHA, e as três qualidades convivem na mesma tela.
Um contador diria quantas são de cada tipo e não diria QUAL linha é qual.

**A âncora é truncada ao segundo inteiro antes de somar o deslocamento.** `criado_em` é contado em
SEGUNDOS — é o que ele sempre foi e o que as linhas já gravadas têm. Com a âncora truncada, a fração
do instante é exatamente o resto do deslocamento em milissegundos: derivável de cada linha sozinha,
sem transportar nada. O preço é um erro menor que um segundo no ABSOLUTO, **igual para todas as
linhas do lote**, e por isso ele não move nem a ordem nem o espaçamento.

**O dia sai da âncora do lote nas DUAS tabelas.** `receber()` calcula `$dia_do_lote` uma vez e o
passa a `somar()`; `registrar_evento()` deriva o `dia` do `criado_em` que a mesma âncora produziu.
Um lote entregue depois da virada soma o total e registra o acionamento no MESMO dia, e os dois
quadros da tela fecham. `dia` é o corte de todas as leituras da tela e o corte da retenção.

**A ordenação da tela é `ORDER BY criado_em DESC, id DESC`**, e o desempate por `id` não é enfeite:
dois acionamentos separados por menos de um segundo caem no mesmo `criado_em`, e é o `id` que os
ordena — na ordem certa, porque a inserção é na ordem do lote, que é a ordem cronológica.

**As linhas antigas NÃO são reescritas.** Sem a origem daqueles lotes, qualquer carimbo derivado
seria inventado. Elas ficam com `ancora` vazia, a tela as marca como chegada e não mostra fração de
segundo nelas, e a retenção do registro as leva no prazo dela.

### O selo do lote e a idempotência no servidor

Confirmar a entrega implica reenviar, e reenviar implica poder contar duas vezes. O lote leva um
**selo sorteado** pelo navegador, na mesma forma do apelido — `[a-f0-9]{32}` —, e o que identifica o
lote são a visita E o selo. No servidor a reserva é a MESMA do lead: **inserção atômica na chave
única, confirmação depois da persistência, compensação quando nada foi gravado**. Ela nasce
PENDENTE, vira FIRME só depois de a linha estar no banco, e é APAGADA quando nada foi gravado —
marcar e gravar em seguida deixaria o selo queimado sobre uma escrita que falhou.

O prefixo `f3base-comportamento-lote|` separa este espaço de chaves do da deduplicação de leads, que
usa a mesma tabela e o mesmo mecanismo. **Selo vazio não reserva nada:** sem gerador criptográfico o
navegador não tem selo, e também não tem apelido nem visita gravada.

**A janela em que o selo é lembrado é a MESMA janela da visita**, lida da mesma declaração que o
cliente lê (`inatividade_min` do evento de página). Um número escrito no servidor divergiria do de
lá e a divergência apareceria como linha contada duas vezes.

### As cortadas

O corte já era contado — o cliente conta o que estourou o orçamento da visita, o servidor conta o
que estourou o teto do corpo — e o número saía NOMEADO na resposta da rota, **onde ninguém o lê**: a
resposta morre no navegador. Hoje o descarte é **gravado**, na mesma tabela do resumo, sob o nome
`f3base_cortadas`, que tem produtor único na constante `METRICA_CORTADAS`.

**Por que na mesma tabela:** o descarte tem exatamente a granularidade do resumo — dia, caminho — e
exatamente o prazo dele. **Por que um nome FORA da declaração:** cortada não é comportamento de
ninguém, foi o pacote que descartou; declará-la no TSV a faria aparecer como evento na tela, no
`dataLayer` e na série histórica. **Todo leitor do resumo a exclui pelo nome** — se você escrever
uma leitura nova, exclua-a também, ou o total passa a somar o que não aconteceu.

### A migração da estrutura, e por que ela não espera

O gancho de ativação NÃO roda numa ATUALIZAÇÃO de plugin. Por isso `garantir_estrutura()` roda em
`init` e é guardada por um transiente curto. **O transiente é trava da TENTATIVA, e não espera pelo
fracasso:** ele já foi longo, e um `dbDelta` que falhasse punha a rota em minutos de recusa sem
nenhuma nova tentativa no meio. A trava **cai no sucesso**.

A guarda pergunta pelas **duas** tabelas. Num site que já tinha o resumo, perguntar só por ele fazia
a função sair cedo e a tabela de registro nunca nascer: instalação limpa passava, e a atualização
sobre site existente ficava sem o registro, sem erro nenhum.

### A tela Medição

`admin/class-f3base-admin-medicao.php` é um menu próprio, e não um quadro no fim da tela de
configuração: ela responde outra pergunta e não é sub-item de configuração nenhuma.

- **O fuso é declarado na própria tela:** o dia dos quadros é UTC — é assim que ele é gravado nas
  duas tabelas — e a coluna de horário sai em `wp_date()`, no fuso do site.
- **O que foi DESCARTADO é dito antes de qualquer tabela**, para que ninguém some achando que tem
  tudo. Zero não imprime nada: um quadro dizendo "nada descartado" em toda abertura treina o
  operador a ignorar o quadro.
- **O quadro de vitais existe e lê `dados/vitais.tsv`** para a explicação e o limiar ao lado do
  valor medido. Sem o arquivo, a tela diz que a declaração não pôde ser lida — um número sem régua
  não decide nada.
- **Quando os quadros não cobrem o mesmo período, a tela diz.** O painel soma um prazo e o registro
  detalhado guarda outro; a frase nomeia os dois e diz quais quadros vêm de qual tabela.
- **Bloco cortado é bloco REMOVIDO, e não escondido.**

### Consultas típicas

Trocar `wp_` pelo prefixo real da instalação.

Os totais dos últimos dias, por página e por evento — é o que o painel mostra:

```sql
SELECT caminho, metrica, detalhe, SUM(contagem) AS total, SUM(soma) AS acumulado
FROM wp_f3base_comportamento
WHERE dia >= DATE_FORMAT(NOW() - INTERVAL 28 DAY, '%Y-%m-%d')
GROUP BY caminho, metrica, detalhe
ORDER BY total DESC;
```

Quanto o site DESCARTOU, que é lido em separado e nunca entra no total:

```sql
SELECT dia, caminho, SUM(contagem) AS cortadas
FROM wp_f3base_comportamento
WHERE metrica = 'f3base_cortadas'
GROUP BY dia, caminho
ORDER BY dia DESC;
```

Pessoas diferentes por dia — só o registro responde isso:

```sql
SELECT dia, COUNT(DISTINCT visitante) AS visitantes
FROM wp_f3base_eventos
GROUP BY dia
ORDER BY dia DESC;
```

A releitura de um bloco dentro de uma visita, que é a pergunta que o registro existe para responder:

```sql
SELECT caminho, detalhe, ocorrencia, ms, criado_em, ancora
FROM wp_f3base_eventos
WHERE metrica = 'f3base_secao_vista' AND sessao = ?
ORDER BY criado_em, id;
```

O tempo até cada marco de rolagem, por visita:

```sql
SELECT sessao, caminho, detalhe, MIN(ms) AS ms_ate_o_marco
FROM wp_f3base_eventos
WHERE metrica = 'f3base_rolagem'
GROUP BY sessao, caminho, detalhe
ORDER BY sessao, ms_ate_o_marco;
```

Desde quando este site está coletando — a resposta honesta é o dia mais antigo que a tabela guarda,
e não a data em que a option foi ligada:

```sql
SELECT MIN(dia) FROM wp_f3base_comportamento;
```

### Como marcar uma seção para ser medida

A seção precisa carregar a classe `f3base-secao-<nome>` no markup. No editor de blocos, isso é o
campo **`className`** de um bloco de grupo — nunca um atributo cru escrito à mão no HTML do bloco,
que o editor descarta na primeira revisão.

O nome sai do **markup**, nunca do texto. Derivar o nome de um título produziria uma série histórica
que muda sozinha na primeira revisão de texto, e quem lê a série é um agente comparando períodos.
**Seção sem a classe não é medida**, e essa é a escolha certa entre não medir e medir errado.

**Essa grafia é contrato do PLUGIN, e não muda com o prefixo do site.** Cada site nasce de uma cópia
do pacote renomeada para o próprio prefixo técnico. A classe é carimbada pelos patterns do TEMA e
pelo CONTEÚDO — os dois renomeados — e é procurada pelo coletor deste PLUGIN, que não é renomeado.
Com o tema carimbando `<prefixo>-secao-abertura` e o plugin observando `f3base-secao-`, a medição de
seções morreria calada em todo site renomeado. A grafia está em `dados/contrato-de-nomes.tsv`, e
`renomeacao.secao_medida_apos_renomear` renomeia de verdade e roda a função REAL do coletor contra
as classes que o markup renomeado carimba. O prefixo chega ao cliente por `prefixoSecao`, publicado
de `F3Base_Modulo_Tracking::PREFIXO_SECAO`. Não escreva a classe no JavaScript.

---

## Leads

### `F3Base_Modulo_Leads_Whatsapp` — o botão de contato

**O que faz.** Promove a link profundo do WhatsApp o botão de contato que ainda carrega o `href` do
modelo, monta a URL a partir do número gravado, e enfileira `assets/f3base-leads.js`, que registra a
interação por beacon antes da navegação e transporta a atribuição.

**Quando fica INATIVO.** Sem número em `f3base_contato`. Nenhum script é enfileirado e nenhum `href`
é reescrito. O filtro `render_block` continua registrado — ele é declarado `sempre` —, e nele o
botão que ainda tem o `href` do modelo **não é publicado**, enquanto um botão com destino próprio
fica na página, intocado. **Fica DEGRADADO** quando `WP_HTML_Tag_Processor` não existe nesta versão
do WordPress: o caminho sem JavaScript não recebe o link profundo.

**O que quebra.** Reescrever o `href` cegamente desfaz a escolha de quem trocou o destino a cada
render. Suprimir o bloco cegamente apaga qualquer bloco da classe, inclusive o que tem destino
próprio. Os quatro quadrantes (com número ou sem, com `href` do modelo ou próprio) são bancada em
`leads.cta_preserva_destino`.

### `F3Base_Modulo_Endpoint_Leads` — o endpoint

**O que faz.** Rota REST pública e endurecida que recebe o beacon do clique: schema fechado com
recusa de campo desconhecido pelo nome, limites por campo medidos em CARACTERES (a mesma unidade em
que o cliente corta), token efêmero assinado, honeypot, limite de pedidos por janela e deduplicação
atômica por chave única no banco.

**Ele é infraestrutura de outros módulos.** `emitir_token()`, `validar_token()`, `origem()`,
`incrementar_janela()`, `reservar()`, `confirmar_reserva()` e `liberar_reserva()` são usados também
pelo módulo de comportamento. Uma segunda implementação de qualquer uma delas seria uma segunda
regra para o mesmo risco.

**Nunca fica inativo.** Fica DEGRADADO quando a tentativa mais recente não foi gravada e nenhuma
entrou depois dela; quando a tabela de reservas não tem a coluna de estado desta versão (a
deduplicação e o limite caem para transiente, e transiente faz ler-modificar-gravar, que perde
incremento sob concorrência); e quando o Flamingo está ausente.

**O token com escopo, e a rota que o renova.** O token é `<expiração>.<assinatura>`, assinado com
`f3base_endpoint_segredo`. Ele é recusado quando a expiração não é numérica, quando já passou,
quando está longe demais no futuro e quando a assinatura não confere — a comparação é em tempo
constante. **A assinatura cobre também o ESCOPO**: a rota e o caminho da página em que o token foi
emitido, sem a query string; incluí-la faria todo lead de tráfego pago cair no escopo errado. Um
token colhido numa página não vale num POST que diz vir de outra.

O prazo padrão está na região de limites, com piso e teto aplicados sobre o filtro que o ajusta.
Prazo curto tem um custo, e ele é a **página servida de cache**: o HTML carrega o token impresso
quando aquela página foi gerada, e um cache mais velho que o prazo faria todo beacon voltar
recusado. Por isso existe a rota `/token`, GET e sem nonce — o token é público por natureza, e
exigir nonce obrigaria a página em cache a ter um nonce válido, que é o que ela não tem —, limitada
pelo MESMO balde de limite por janela. O cliente pede um token novo quando o que ele tem já venceu e
também quando recebe a recusa de token, e reenvia **uma vez**. A recusa por token CARIMBA a atividade
com a página: sem isso, um site em cache podia estar perdendo lead há semanas com o módulo verde na
tela.

**A reserva e a deduplicação.** A reserva nasce PENDENTE, vira FIRME depois da persistência e é
APAGADA quando nada foi gravado. Marcar e gravar em seguida deixa o selo queimado numa escrita que
falhou, e a retentativa recebe "já gravei isto" sobre nada. E **falha de BANCO na reserva não é
duplicata**: sem reserva anterior atrás da recusa, a rota responde `f3base_reserva_indisponivel` —
recusa de armazenamento, com a reserva compensada — em vez de dizer que a correlação já estava
registrada com o identificador em branco, porque o cliente apaga o lead da fila ao receber resposta
de sucesso. Gravação recusada responde `5xx` com o código e com o que o visitante deve fazer, nunca
`201` com `ok` falso.

**O consentimento arquivado é o ESTADO MEDIDO**, no vocabulário fechado de três valores de
`F3Base_Modulo_Consentimento` — `sim`, `nao`, `padrao-pre-aprovado`. O booleano que o navegador manda
é o portão das tags e vale verdadeiro quando ninguém decidiu: arquivá-lo como "sim" poria em todo
lead uma decisão do titular que não existiu. É esse mesmo estado que decide se o evento de servidor
da Conversions API chega a ser agendado.

**A origem do balde.** `f3base_origem_confiavel` declara o cabeçalho, a posição na cadeia e as
FAIXAS DE IP dos proxies. **As faixas ligam a conferência da conexão**, e são elas que fecham a
porta: cabeçalho é texto que qualquer cliente manda, e quem alcança a origem por fora da CDN
escolheria o balde em que conta — e o `client_ip_address` que vai para a Meta. Declaradas, só o
pedido que vem de dentro delas tem o cabeçalho lido, e os outros voltam ao endereço da conexão.
**Vazias, o cabeçalho é lido de qualquer conexão** — que é o que o pacote sempre fez, e mudá-lo numa
atualização quebraria em silêncio toda instalação já entregue — e `avisos()` do módulo emite o aviso
nomeando o risco e o campo que o fecha. A leitura devolve o cabeçalho COMO ELE VEIO: repetido, sai
lista.

**A atribuição é gateada.** `assets/f3base-leads.js` só grava `localStorage` e cookie de fornecedor
depois de `permiteTags()`, e a janela em que dois cliques no mesmo botão são a MESMA interação vem
do servidor, do filtro declarado na região de limites — o identificador de correlação não renasce a
cada poucos segundos.

**Flamingo × contingência.** Grava no Flamingo quando ele existe, e no tipo de conteúdo privado de
contingência quando não existe. **A listagem de contingência não some com os leads dentro:** ela
aparece enquanto existir ao menos um lead gravado no tipo de conteúdo privado, e não apenas quando o
Flamingo está ausente — a caixa única costuma entrar DEPOIS, e nada migra para ela.

### `F3Base_Modulo_Meta_Capi` — Conversions API

**O que faz.** Envia o evento de lead **de servidor** depois da persistência confirmada, com o MESMO
identificador de evento que o navegador manda no Pixel — é ele que deduplica os dois caminhos.
E-mail e telefone saem em resumo criptográfico sobre o valor normalizado pela regra da Meta; nada de
dado pessoal em claro, e o token fica fora de log e de URL.

**O portão do consentimento vem antes do agendamento.** `F3Base_Modulo_Endpoint_Leads` só chama
`F3Base_Modulo_Meta_Capi::agendar()` sob o mesmo estado de consentimento que gateia o navegador. O
payload leva e-mail, telefone, endereço do visitante e os identificadores de clique: agendar sem
consultar o portão mandaria à Meta exatamente o que a recusa existe para impedir.

**Quando fica INATIVO.** Sem token em `f3base_meta_capi_token`. Essa option é SEGREDO DO SITE: ela
não existe no arquivo de configuração do implantador nem no schema dele, e nenhum lote a grava.
**Fica DEGRADADO** com token gravado e `f3base_meta_pixel_id` vazia (o endereço da API é montado com
o identificador do Pixel: sem ele não há destino), e quando a Meta recusou o evento mais recente e
nenhum foi aceito depois dele.

**O que quebra.** Recusa da Meta **nunca** muda o status de um lead: o lead já estava gravado antes
de o envio ser agendado. O evento é agendado COM ARGUMENTO, e por isso a desinstalação usa
`wp_unschedule_hook()` — `wp_next_scheduled()` sem argumento não encontra evento agendado com um, e
o agendamento ficaria órfão na option de cron para sempre.

### `F3Base_Modulo_Rota_Origem` — leitura de volta pela origem

**O que faz.** Requisita um caminho do próprio site a partir do servidor e devolve status, cabeçalhos
e corpo carimbados com a fase `origem`. **Nunca fica inativo.** Aceita apenas caminho do próprio
`home_url()`, valida o host e não segue redirecionamento para fora — aceitar host de fora
transformaria a rota num proxy aberto, e a validação de host é a rota inteira.

---

## Consentimento e tracking

### `F3Base_Modulo_Consentimento`

**O que faz.** Aplica a política declarada em `f3base_consentimento`, publica o controle de revisão
no rodapé de toda página, persiste a negativa pelo prazo configurado e religa no re-aceite.
`permite_tags()` é o portão que todo o resto consulta, e `estado_arquivado()` é o vocabulário fechado
de três valores que o lead arquiva.

**Nunca fica inativo.** Fica DEGRADADO quando `f3base_consentimento` nunca foi gravada pelo
implantador (o site opera sobre o padrão embutido, não sobre a política declarada do projeto) e
quando o controle do rodapé está desligado (o titular fica sem instrumento permanente de revisão).

**A estratégia de carregamento sai de `estrategia_de_carga()`.** No modo pré-aprovado o script sai
com `defer`, fora do caminho crítico, porque o `default` desse modo é `granted` e ausência de
`default` já é `granted` para o fornecedor. No modo de negativa por padrão ele sai **bloqueante no
cabeçalho**: ali a ordem é a garantia, e chegar depois de uma tag de terceiro seria um primeiro
`page_view` sem o `denied`. `js.ordem_do_consentimento` mede a ordem de execução, e não a string do
atributo.

**O que a recusa faz e o que ela não faz.** Ela fecha o portão: nenhuma tag de fornecedor é
carregada, nenhum cookie de fornecedor é gravado pelo cliente de leads, e o evento de servidor não é
agendado. O agregado de comportamento continua, porque ele não identifica ninguém. O re-aceite
religa o portão na mesma navegação.

### `F3Base_Modulo_Tracking`

**O que faz.** Duas metades pelo mesmo portão. A primeira emite as tags de GA4, Google Ads, Meta e
LinkedIn a partir dos IDs gravados. A segunda instrumenta o COMPORTAMENTO — assunto da seção
anterior.

**O caminho é um só.** `f3base_gtm_container_id` preenchido decide: o site publica o contêiner,
alimenta o `dataLayer` com objetos, e NENHUMA tag direta é emitida. Vazio, o site publica as tags
diretas de cada ID presente. Duas fontes para a mesma conversão é conversão contada em dobro, e
conversão em dobro reescreve o lance do leilão. O **emissor único** é medido no HTML publicado, por
`tracking.emissor_unico`, contra a declaração de `dados/emissores-conhecidos.tsv`.

**Quando fica INATIVO.** Nenhum slot de medição preenchido **e** o resumo do próprio site desligado.
Repare na conjunção: com os slots vazios e o resumo ligado o módulo continua ATIVO, porque o coletor
de comportamento não depende de fornecedor nenhum. **Fica DEGRADADO** quando o consentimento foi
negado no navegador desta requisição: nenhuma das tags é carregada nele. Pixel e Insight Tag não têm
modo de consentimento — carregar e "atualizar para negado" seria carregar assim mesmo.

**O portão mora no CLIENTE, e o motivo é o cache de página.** O enfileiramento do carregador lia o
cookie de consentimento para decidir se o `<script>` entra no HTML, sem `Vary` nem
`DONOTCACHEPAGE`: a decisão do primeiro visitante a gerar aquela página ficava congelada para todos
os seguintes. O carregador é servido SEMPRE que há destino — ele é o mesmo para todo visitante, e
por isso é cacheável —, e quem confere o consentimento é `assets/f3base-tracking.js`, no navegador em
que a decisão foi tomada, antes de carregar qualquer tag. O que continua decidido no servidor é o
DESTINO, que não depende de visitante nenhum.

**O que quebra.** `ids()` é a fonte única dos slots: estado, dependências, aviso de forma e o que vai
para o navegador leem daqui. Duas listas de slots divergiriam no primeiro canal acrescentado.

---

## SEO, cabeçalhos, retenção e cadência

### `F3Base_Modulo_Llms_Txt_Reserva` e `F3Base_Modulo_Llms_Full_Txt`

**O que fazem.** Servem `/llms.txt` e `/llms-full.txt` por rota virtual, com a mesma seleção, as
mesmas exclusões e a mesma precedência de emissor. A regra compartilhada mora em
`includes/class-f3base-llms.php`, e os dois módulos a consultam.

**A precedência do endereço:** arquivo físico na raiz vence; emissor concorrente MEDIDO vem depois;
e só então esta rota. **O emissor concorrente é cruzado com o plugin ATIVO**, e não só com a option
que ele deixou para trás: uma option que sobrevive à desativação do plugin de SEO faria a rota se
declarar não-responsável para sempre e o endereço virar `404` permanente com o módulo em estado
ativo. Cada rota grava o próprio carimbo e emite o mecanismo REAL que respondeu.

**O que fica de fora da lista:** o que está em `noindex`, e o conteúdo PROTEGIDO POR SENHA — publicar
o texto integral de um post protegido num arquivo para leitores automáticos é entregar exatamente o
que a senha existe para reter.

**Quando ficam INATIVOS.** `f3base_llms.ligado` desligado derruba os dois. O `llms-full.txt` tem uma
segunda condição, e ela é o padrão: `f3base_llms.full` desligado. Ele publica uma segunda cópia
integral do site em texto puro — o custo é certo e o ganho é hipótese. **O `llms.txt` fica
DEGRADADO** quando não há arquivo físico, não há emissor concorrente e não há item nenhum a listar.

**O que quebra.** Os dois são registrados em `template_redirect` com prioridade zero para não receber
a barra final de `redirect_canonical`. Subir a prioridade quebra o endereço.

### `F3Base_Modulo_Noindex_Honrado`

**O que faz.** Lê o `noindex` gravado nas chaves do plugin de SEO — meta por conteúdo, padrões por
tipo e taxonomia, `noindex` por termo — e o aplica pelo filtro `wp_robots` **mesmo com o plugin de
SEO desativado**. **Nunca fica inativo:** com o plugin de SEO presente ele imprime o `robots` e esta
honra fica de reserva sobre as mesmas chaves, e o estado é `ativo` nos dois casos.

**O que quebra.** Este módulo é o **produtor único** do fato "este conteúdo está em noindex". Os dois
módulos de `llms` o consultam e nenhum lê a meta por conta própria. Uma segunda leitura divergiria
na primeira chave acrescentada, e o site publicaria numa lista para leitores automáticos exatamente
o que ele pediu para não ser indexado.

### `F3Base_Modulo_Redirects`

**O que faz.** Redireciona slugs antigos de páginas e posts lendo a meta `_f3base_old_slug`, tratando
as variáveis de consulta `pagename` e `name`, e aplica os pares declarados em `f3base_redirects`
antes do `404`. **Nunca fica inativo:** o núcleo cobre parte disso, e este módulo cobre o resto.

**O que quebra.** Aplicar depois do `404` já não redireciona nada — a prioridade em `template_redirect`
é o módulo inteiro. E o par é comparado pela MESMA normalização que a aplicação usa: barra final e
query normalizadas dos dois lados, senão um par que o sanitizador aceita gira para sempre em
produção. O ramo de recurso removido TERMINA a requisição: sem isso, o corpo da página era servido
com o status de removido.

### `F3Base_Modulo_Cabecalhos`

**O que faz.** Emite os cabeçalhos de segurança declarados em `f3base_cabecalhos`, cada um com o
valor gravado — no front-end **e** na resposta da API REST, ali com o recorte que faz sentido em
JSON.

**Ele não atropela outro emissor.** A `Content-Security-Policy` COMPÕE; os demais só saem quando
ninguém os pôs antes NESTA resposta, e o carimbo do que foi cedido responde pelo front-end.

**Fica DEGRADADO** quando o COOP gravado não é o que o botão de contato precisa: o valor gravado é o
que sai, e o módulo NOMEIA a consequência — o botão abre a conversa em janela nova, e fora daquele
valor o navegador corta a relação com ela. Também degrada com HSTS ligado sem HTTPS nesta requisição.

**Os avisos deste módulo.** O `Referrer-Policy` é o caso em que um `avisos()` existe: há valor que
apaga a atribuição dos canais pagos, e isso funciona exatamente como foi pedido **e** custa alguma
coisa em outro lugar. Os outros dois: o que nomeia os cabeçalhos CEDIDOS a outro emissor da mesma
resposta, e o que nomeia um `csp_frame_ancestors` fora da FORMA da diretiva — este último não é
emitido enquanto estiver assim, porque o ponto e vírgula abre uma diretiva nova e vira um CSP
inteiro escrito pelo campo da moldura.

### `F3Base_Modulo_Schema_Extensao`

**O que faz.** Acrescenta ao grafo do plugin de SEO os nós de serviço e as propriedades de entidade
declaradas em `f3base_seo_entidade`, pelos filtros do próprio plugin de SEO. **Fica DEGRADADO**
quando o plugin de SEO está ausente: sem grafo para estender, nada é emitido.

**O FAQ é lido só em requisição SINGULAR.** `faq_da_pagina()` é guardada por `is_singular()`: num
arquivo de termo ou de autor ela emitiria o FAQ de outro post, e o buscador receberia perguntas
ligadas a um endereço que não as tem.

**`sameAs` é UNIÃO**, e não reescrita: o que já está no grafo permanece, e o declarado é acrescentado
sem duplicar. `sameAs` vazio fica vazio, por desenho — preencher com endereço inventado é pior que
não preencher.

### `F3Base_Modulo_Verificacao_Dominio`

**O que faz.** Emite no `<head>` a metatag de verificação de posse do domínio de cada token gravado,
para o Google e para a Meta. A lista de options que o controlam sai de `array_keys( self::tags() )`,
que é a mesma declaração de onde saem a tag, o fornecedor e a explicação de onde o token é obtido.

**Quando fica INATIVO.** Nenhum token gravado: nenhuma metatag é emitida. Os tokens vêm dos consoles
— passo humano —, e gravá-los faz a tag existir na página seguinte, sem release nova.

**O que quebra.** Valor fora da forma esperada é **preservado e avisado**, nunca apagado. O pacote
não apaga o que alguém gravou.

### `F3Base_Modulo_Retencao_Eliminacao`

**O que faz.** Limpa registros de lead pelo prazo declarado em `f3base_retencao_meses`, medindo o
próprio atraso e se recuperando no carregamento seguinte; registra o exportador e o eliminador de
dados pessoais do núcleo; e expõe a rota de eliminação com journal.

**Nunca fica inativo.** Fica DEGRADADO em três situações: quando o lote do dia não alcançou toda a
fila de registros vencidos — e aí o carimbo NOMEIA o backlog e o filtro que ajusta o lote; quando o
evento de limpeza está sem agendamento; e quando a última execução saiu com atraso acima da
tolerância declarada.

**Sem lixeira a eliminação é DEFINITIVA, e o módulo diz isso sem degradar.** `EMPTY_TRASH_DAYS` em
zero faz `wp_trash_post()` APAGAR — o núcleo pula a lixeira inteira —, e não há neste host onde
guardar a cópia protegida da janela reversível. A rotina diária e o regime operacional da rota
**prosseguem**: o prazo que a política de privacidade promete continua sendo cumprido, a resposta sai
`reversivel: false` e **sem** `reversivel_ate`, a entrada do journal sai com a janela zerada e o
motivo, e a frase de estado nomeia `EMPTY_TRASH_DAYS`. Recusar o pedido por causa disso trocaria uma
palavra errada na resposta por dado pessoal vencido guardado indefinidamente.

**O corte é em CALENDÁRIO.** O prazo em meses é contado por calendário, e não por uma aproximação em
dias: a aproximação encurtava o prazo que a política de privacidade promete, sem dizer.

**O journal separa** limpeza operacional reversível de eliminação irreversível a pedido do titular, e
guarda identificador, contagem, carimbo, operador e regime — **nunca o conteúdo eliminado**. O corte
do journal acontece na ESCRITA, e a entrada de corte diz quantas saíram e desde quando: cortado na
leitura, o banco continuaria inteiro e a tela mostraria um recorte sem dizer que é um recorte. A
eliminação definitiva do lote — o fim da janela reversível — também deixa entrada, com o prazo
reversível zerado. Zero em `reversivel_ate` significa duas coisas diferentes — a janela venceu, ou
este host nunca teve janela —, e por isso a entrada carrega um `motivo` que distingue as duas; ele
diz por que, nunca o quê.

**O exportador e o eliminador do núcleo PAGINAM:** quem tem mais registros que o lote recebe página
por página, e o fim só é declarado na página incompleta.

### `F3Base_Modulo_Cadencia_Relatorio`

**O que faz.** Escuta o evento `f3base_cadencia_relatorio` que o implantador agenda, registra as
recorrências quinzenal e mensal que o núcleo não tem, executa a releitura das options gerenciadas e
dos módulos, e registra última execução, próxima, duração, resultado, erro e atraso. Conta também os
ajustes em option gerenciada e dispara ao alcançar o número declarado.

**As recorrências são registradas ANTES de a ativação agendar.** O gancho de ativação roda depois de
`init`, e um `wp_schedule_event()` sobre uma recorrência que o núcleo ainda não conhece devolve
falso: a ativação passa a agendar no próprio processo, e a previsão só é gravada quando há evento
agendado de verdade. A frase de estado NOMEIA o evento.

**Quando fica INATIVO.** A configuração declara periodicidade `nenhuma` **e** nenhum gatilho por
número de ajustes. **Fica DEGRADADO** quando a última execução terminou em erro, quando o evento está
sem agendamento, quando a recorrência agendada não é a declarada e quando o atraso passa da
tolerância.

**O que quebra.** O contador de ajustes escuta `updated_option`, `added_option` e `deleted_option`, e
usa a MESMA função de equivalência do gravador único (`F3Base_Options::equivalente()`) — duas
implementações fariam a releitura acusar divergência onde a gravação tinha conferido.

---

## As rotas REST e os limites

<!-- gerado:inicio=plugin-rotas -->
| Rota | Método | Autenticação | Onde é registrada |
|---|---|---|---|
| `/wp-json/f3base/v1/comportamento` | POST | `__return_true` | `includes/class-f3base-modulo-comportamento.php` |
| `/wp-json/f3base/v1/comportamento/esquecer` | POST | `__return_true` | `includes/class-f3base-modulo-comportamento.php` |
| `/wp-json/f3base/v1/eliminacao` | POST | `pode_eliminar()` | `includes/class-f3base-modulo-retencao-eliminacao.php` |
| `/wp-json/f3base/v1/lead` | POST | `__return_true` | `includes/class-f3base-modulo-endpoint-leads.php` |
| `/wp-json/f3base/v1/origem` | GET | `pode_ler()` | `includes/class-f3base-modulo-rota-origem.php` |
| `/wp-json/f3base/v1/relatorio` | GET | `current_user_can( manage_options )` | `includes/class-f3base-plugin.php` |
| `/wp-json/f3base/v1/token` | GET | `__return_true` | `includes/class-f3base-modulo-endpoint-leads.php` |
<!-- gerado:fim=plugin-rotas -->

### Como cada uma autentica

`/relatorio` e as rotas de eliminação e de origem exigem capacidade de administração — a de
eliminação e a de origem checam também um nonce próprio. As três públicas — lead, comportamento e
esquecer — validam o **token efêmero assinado**, e não cookie.

**Os clientes de comportamento e de esquecer usam `credentials: 'omit'`**, em
`assets/f3base-tracking.js`: mandar o cookie de sessão do WordPress numa requisição de medição o
entregaria também ao CDN que estiver na frente, sem servir para nada ali. **O cliente de LEAD usa
`same-origin`**, em `assets/f3base-leads.js`, e a diferença tem motivo: o servidor lê o cookie de
consentimento para gravar no lead o ESTADO REAL da decisão do titular, e o `sendBeacon` — que é o
caminho normal — já o manda. Os dois caminhos precisam contar a mesma coisa ao servidor, senão o
mesmo clique fica arquivado com um estado de consentimento diferente conforme o navegador tenha
aceitado o beacon.

### Toda recusa é NOMEADA

O corpo traz `ok`, `registrado`, um `codigo` estável e um `motivo` em português.

| Código HTTP | `codigo` | Quando |
|---|---|---|
| `400` | `f3base_campo_desconhecido` | Campo fora do schema fechado. O nome do campo recusado vem na resposta |
| `400` | `f3base_caminho_invalido` | O caminho não é deste site, ou traz query ou fragmento |
| `400` | `f3base_pseudonimo_invalido` | Apelido, visita ou selo fora da forma `[a-f0-9]{32}` |
| `403` | `f3base_token_invalido` | Token ausente, expirado, fora de escopo ou com assinatura inválida |
| `409` | `f3base_resumo_desligado` | `f3base_comportamento.ligado` está desligado neste site |
| `413` | `f3base_corpo_grande` | Corpo acima do limite declarado. A resposta traz o `limite` |
| `429` | `f3base_rate_limit` | Limite de pedidos por janela excedido para esta origem |
| `503` | `f3base_armazenamento_indisponivel` | A tabela não está pronta com as colunas desta versão |
| `503` | `f3base_gravacao_indisponivel` | O banco recusou a escrita. Nada foi guardado, e o navegador reenvia o mesmo lote |
| `503` | `f3base_reserva_indisponivel` | O banco recusou a RESERVA. A reserva foi compensada e a retentativa é aceita |
| `200` | `f3base_lote_repetido` | Este lote já foi gravado para esta visita. **Repetição responde `2xx` de propósito** |

Duas escolhas nessa tabela são decisões, e não descuido:

**Repetição responde `2xx`.** Para quem envia, "já tenho isto" e "acabei de gravar" precisam ser a
mesma resposta boa: qualquer outro código faria o cliente reter o lote e reenviá-lo para sempre,
exatamente o lote que o servidor já tem.

**Zero linha apagada na rota de esquecer não é erro, e a rota não devolve contagem.** Um apelido sem
registro nenhum é o caso comum de quem nunca foi medido; responder erro — ou devolver quantas linhas
saíram — diria ao pedinte se aquele apelido existe no banco, que é informação sobre outra pessoa
quando o apelido é chutado.

### Os limites

<!-- gerado:inicio=plugin-limites -->
**Tetos fixos — constante do código, sem ponto de ajuste**

| Constante | Valor | Arquivo |
|---|---|---|
| `F3Base_Admin_Acessos::TETO_PAGINAS` | `200` | `class-f3base-admin-acessos.php` |
| `F3Base_Censo_Demonstrativo::TETO_DE_NOMES` | `12` | `class-f3base-censo-demonstrativo.php` |
| `F3Base_Modulo_Acessos_Servidor::MAX_BYTES_ARQUIVO` | `67108864` | `class-f3base-modulo-acessos-servidor.php` |
| `F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_DIA` | `8` | `class-f3base-modulo-acessos-servidor.php` |
| `F3Base_Modulo_Acessos_Servidor::TETO_AGREGADOS` | `50000` | `class-f3base-modulo-acessos-servidor.php` |
| `F3Base_Modulo_Acessos_Servidor::TETO_CAMINHOS_POR_DIA` | `500` | `class-f3base-modulo-acessos-servidor.php` |
| `F3Base_Modulo_Acessos_Servidor::TETO_LINHAS` | `1000` | `class-f3base-modulo-acessos-servidor.php` |
| `F3Base_Modulo_Cadencia_Relatorio::TETO_DE_DESAGENDAMENTO` | `50` | `class-f3base-modulo-cadencia-relatorio.php` |
| `F3Base_Modulo_Comportamento::MAX_BYTES` | `8192` | `class-f3base-modulo-comportamento.php` |
| `F3Base_Modulo_Comportamento::MAX_EVENTOS` | `120` | `class-f3base-modulo-comportamento.php` |
| `F3Base_Modulo_Comportamento::MAX_MS` | `86400000` | `class-f3base-modulo-comportamento.php` |
| `F3Base_Modulo_Comportamento::MAX_POR_VISITA` | `200` | `class-f3base-modulo-comportamento.php` |
| `F3Base_Modulo_Comportamento::TOLERANCIA_RELOGIO_MS` | `300000` | `class-f3base-modulo-comportamento.php` |
| `F3Base_Modulo_Llms_Txt_Reserva::PALAVRAS_DO_RESUMO` | `28` | `class-f3base-modulo-llms-txt-reserva.php` |
| `F3Base_Modulo_Llms_Txt_Reserva::TETO_DE_ITENS` | `200` | `class-f3base-modulo-llms-txt-reserva.php` |
| `F3Base_Modulo_Retencao_Eliminacao::TETO_DA_CONTAGEM` | `5000` | `class-f3base-modulo-retencao-eliminacao.php` |
| `F3Base_Modulo_Retencao_Eliminacao::TETO_DE_DESAGENDAMENTO` | `50` | `class-f3base-modulo-retencao-eliminacao.php` |
| `F3Base_Modulo_Sessao_De_Login::PRIORIDADE` | `9999` | `class-f3base-modulo-sessao-de-login.php` |
| `F3Base_Modulo_Verificacao_Dominio::TETO` | `200` | `class-f3base-modulo-verificacao-dominio.php` |
| `F3Base_Site_Core::PRIORIDADE_REGISTRO` | `5` | `class-f3base-plugin.php` |

**Prazos e tamanhos ajustáveis — o valor é o PADRÃO do código, e o gancho é onde o site o muda**

| Filtro | Padrão | Arquivo |
|---|---|---|
| `f3base_cadencia_atraso_tolerado` | `2 * DAY_IN_SECONDS` | `class-f3base-modulo-cadencia-relatorio.php` |
| `f3base_cadencia_tolerancia_recuperacao` | `12 * HOUR_IN_SECONDS` | `class-f3base-modulo-cadencia-relatorio.php` |
| `f3base_categoria_rasa_limite` | `2` | `class-f3base-modulo-noindex-honrado.php` |
| `f3base_comportamento_rate_limit_janela` | `10 * MINUTE_IN_SECONDS` | `class-f3base-modulo-comportamento.php` |
| `f3base_janela_reversivel_dias` | `30` | `class-f3base-modulo-retencao-eliminacao.php` |
| `f3base_lead_dedup_ttl` | `30 * DAY_IN_SECONDS` | `class-f3base-modulo-endpoint-leads.php` |
| `f3base_lead_janela_correlacao` | `MINUTE_IN_SECONDS` | `class-f3base-modulo-endpoint-leads.php` |
| `f3base_lead_rate_limit_janela` | `10 * MINUTE_IN_SECONDS` | `class-f3base-modulo-endpoint-leads.php` |
| `f3base_lead_rate_limit_maximo` | `20` | `class-f3base-modulo-endpoint-leads.php` |
| `f3base_lead_reserva_pendente_ttl` | `5 * MINUTE_IN_SECONDS` | `class-f3base-modulo-endpoint-leads.php` |
| `f3base_meta_capi_payload_ttl` | `HOUR_IN_SECONDS` | `class-f3base-modulo-meta-capi.php` |
| `f3base_meta_capi_timeout` | `10` | `class-f3base-modulo-meta-capi.php` |
| `f3base_origem_limite_corpo` | `1048576` | `class-f3base-modulo-rota-origem.php` |
| `f3base_privacidade_lote` | `100` | `class-f3base-modulo-retencao-eliminacao.php` |
| `f3base_retencao_atraso_tolerado` | `2 * DAY_IN_SECONDS` | `class-f3base-modulo-retencao-eliminacao.php` |
| `f3base_retencao_lote` | `200` | `class-f3base-modulo-retencao-eliminacao.php` |
| `f3base_retencao_tolerancia_recuperacao` | `6 * HOUR_IN_SECONDS` | `class-f3base-modulo-retencao-eliminacao.php` |
| `f3base_token_lead_ttl` | `HOUR_IN_SECONDS` | `class-f3base-modulo-endpoint-leads.php` |
| `f3base_varredura_de_links` | `200` | `class-f3base-modulo-comportamento.php` |
<!-- gerado:fim=plugin-limites -->

Os que a tabela não pode carregar porque não são número:

| Limite | Onde ele sai |
|---|---|
| Idade máxima da origem temporal do lote | `f3base_comportamento.retencao_eventos_dias`, a própria janela de retenção do registro |
| Janela em que o selo do lote é lembrado | `inatividade_min` do evento de página, no TSV — a MESMA declaração que o cliente lê |
| Orçamento de linhas de uma VISITA inteira | `MAX_POR_VISITA`, gasto ao longo das páginas e não por página |
| Origem que conta no balde | `f3base_origem_confiavel`; sem cabeçalho declarado, o endereço da conexão |

---

## O que a suíte cobra de quem mexer

O comando único é `bash suite/verificar.sh <caminho-do-pacote>`, e ele tem quatro regras que
ninguém contorna: rodar sem argumento REPROVA; empacotar é a primeira etapa, sempre, e arquivo em
disco fora de `suite/inventario.tsv` aborta o build com o nome; o código de saída vem da contagem de
estados; e selar é a última etapa, que não acontece em rodada com FALHA.

`bash suite/verificar.sh piso <caminho>` roda só o piso: cada detector contra a fixture que
reproduz o defeito.

### As classes de evidência

| Classe | O que ela é | Onde |
|---|---|---|
| `analise-estatica` | Detector que lê a fonte, com fixture negativa e positiva em disco | `suite/checagens/estatica.php`, `meta.php` |
| `teste-funcional` | Sonda em subprocesso que roda o código REAL contra um `wpdb` de mentira e stubs do núcleo | `suite/lib/sonda-site-core.php` |
| `teste-funcional` (JS) | Os clientes reais rodados sob o Node contra uma plataforma de mentira | `suite/checagens/js.mjs` |
| `medida` (navegador) | O cliente ENTREGUE rodado num Chromium real, dirigido só por rolagem | `suite/sonda-navegador/` |
| `wp-real` | O zip que a rodada acabou de montar, instalado num WordPress de verdade com SQLite | `suite/bancada-wp/` |

**A bancada WordPress real existe porque duas classes de evidência faltavam.** A sonda monta um
`wpdb` de mentira e stubs de funções do núcleo, e havia coisa que só o núcleo carregado responde:
`dbDelta` de verdade, a Abilities API de verdade, o cron de verdade e a DESINSTALAÇÃO como o
WordPress a executa — plugin inativo, processo novo. Cada passo dela tem um mutante declarado em
`suite/bancada-wp/pisos.tsv`, com o patch em `suite/bancada-wp/mutantes/`.

**A sonda de navegador existe porque quatro releases seguidas a bancada aprovou o que o navegador
reprovou.** A bancada SIMULA o observador de interseção; o navegador TEM um. Ela mede o cliente
ENTREGUE — o de `dist/entregue/`, sem comentário, que é o que o visitante baixa — numa página de
geometria de site real, com a declaração de eventos GERADA do TSV na hora, em dois percursos
declarados em pixels exatos da faixa rolável. Confere ainda: zero erro de página, zero cortada, e
que o lote **chegou ao servidor**. Para rodar à mão:

```
cd suite/sonda-navegador
node servidor.mjs <diretorio-pub> <porta> &
node sonda.mjs <porta> [caminho-do-chromium]
```

**Sem Chromium a linha fecha `N/A` com a condição declarada, e nunca OK.** Verde sobre medição que
não aconteceu é o instrumento mentindo com a melhor cara possível. **Uma mudança na medição de
comportamento não é dada por boa sem ela** — se você mexeu em coletor, em limiar, em contador de
travessia, em banda de fronteira ou no envio, a bancada passando não é evidência suficiente.

### A regra de teto e piso

**Toda checagem tem de saber falhar.** A fixture negativa reproduz o defeito e a checagem PRECISA
acusar; a positiva preserva o caso correto e a checagem PRECISA ficar em silêncio. O piso roda a
MESMA função que roda contra o pacote, trocando só a raiz — uma suíte cujo piso reimplementa a regra
prova que a cópia funciona, não que o detector funciona. E **escopo vazio não é aprovação**: uma
checagem que não encontra o que mede fecha adverso, nunca OK.

O piso tem três formas, e a forma segue a natureza da checagem:

1. **Fixture em disco**, em `suite/fixtures/<nome-da-checagem>/negativa` e `/positiva`, para detector
   de análise estática.
2. **Mutante `.patch`** sobre `fontes/plugin/`, em `suite/bancada-wp/mutantes/`, para passo de
   bancada: ali o caso negativo não é uma árvore de arquivos, é um plugin INSTALADO com o defeito
   dentro, num WordPress que sobe e responde.
3. **Piso dentro da própria sonda**, declarado em `suite/pisos-em-sonda.tsv`, para sonda funcional. A
   declaração não absolve por si: ela só é aceita quando a sonda tem ramo de TETO e ramo de PISO
   escritos, e quem confere isso é `estatica.piso_em_sonda_declarado` — que tem fixture em disco como
   qualquer outro detector.

### As tabelas da suíte, e a regra que as amarra

| Tabela | O que ela declara |
|---|---|
| `suite/manifesto.tsv` | requisito → checagem, ambiente e classe de evidência. O cruzamento é BIDIRECIONAL |
| `suite/armadilhas.tsv` | armadilha conhecida → checagem que a cobre, ou pendência declarada |
| `suite/pisos-em-sonda.tsv` | checagem → sonda em que o piso dela mora |
| `suite/afirmacoes.tsv` | frase deste documento → regra e fato medido que a sustentam |
| `suite/inventario.tsv` | caminho → papel. É a allow-list do empacotamento |
| `suite/excluidas.tsv` | checagem da referência que NÃO entrou aqui, e por quê |

**Checagem nova precisa de linha em `manifesto.tsv` e em `armadilhas.tsv`, e de piso.**
`manifesto.bidirecional` acusa requisito sem checagem emitida E rótulo emitido sem requisito;
`armadilhas.mapeadas` recusa mapear armadilha para checagem sem piso. As três coisas juntas são o
que impede a cobertura de encolher em silêncio.

### As linhas que reprovam com mais frequência

- `pacote.plugin_completo_no_zip` — arquivo na lista de autoload que não entrou no zip. Não aparece
  como erro de build: aparece como erro fatal no `require_once` da ativação, no site do cliente.
- `pacote.instrucoes_do_plugin_no_zip` — este documento no zip, sem número digitado fora das regiões
  geradas, e com **todo** módulo de `includes/` descrito na prosa.
- `estatica.carimbo_de_release_nos_documentos` — as regiões geradas batendo com a medição de agora.
- `doc.afirmacao_conferida` — toda frase declarada em `suite/afirmacoes.tsv` ainda escrita aqui, e o
  fato que ela promete medido no pacote.
- `estatica.campo_operavel_tem_impacto_e_exemplo` — toda folha operável do catálogo com impacto e
  exemplo escritos.
- `estatica.option_fonte_unica` e `estatica.detector_escrita_unica` — nenhuma escrita de option fora
  do gravador único.
- `tracking.eventos_de_comportamento_declarados` — nenhum literal de nome de evento dentro do
  JavaScript, e a reserva de cada limiar igual à declaração.
- `renomeacao.contrato_de_nomes_completo` — o contrato de nomes cobrindo toda option do catálogo,
  todo evento declarado e o prefixo de seção.
- `pacote.js_entregue_sem_comentario` — o JavaScript entregue é a fonte com cada comentário trocado
  por espaço, e **nada mais**, provado por fluxo de tokens.
- `medicao.carimbo_do_acionamento` — o carimbo de cada linha é o instante do acionamento, a ordenação
  continua cronológica com carimbos que se repartem, a guarda do relógio cai na âncora do servidor
  nos quatro casos declarados, e o lote atrasado não embaralha a ordem dentro dele.

---

## Receitas

Pré-condições de ambiente, e o comando único aborta nomeando a que faltar: `php`, `node`, `zip`,
`unzip`, `faketime`. A sonda de navegador precisa de um **Chromium**; sem ele a linha dela fecha
`N/A` com a condição declarada.

`faketime` não é enfeite: o piso de `pacote.reserva_identica_ao_avulso` monta o zip do plugin duas
vezes com o relógio em dias diferentes e exige bytes idênticos. Sem mover o tempo de verdade, aquele
piso mediria uma função pura contra si mesma.

### Onde fica o quê

| Caminho | O que é |
|---|---|
| `base-site-core-fator3.php` | Cabeçalho, constantes, guarda de versão de PHP e a **lista de autoload** — um `require_once` por arquivo, sem carregamento automático de propósito, para que quem abre a pasta consiga ler |
| `includes/class-f3base-registro.php` | O **registro único** de módulos |
| `includes/class-f3base-modulo.php` | O contrato que todo módulo estende |
| `includes/class-f3base-modulo-*.php` | Um arquivo por módulo |
| `includes/class-f3base-options.php` | O **gravador único** de options, com catálogo e sanitizadores |
| `includes/class-f3base-plugin.php` | Orquestrador: ativação, desativação, registro dos hooks lendo o registro, rota de relatório, gancho das habilidades |
| `includes/class-f3base-atividade.php` | Carimbos de última atividade por módulo |
| `includes/class-f3base-llms.php` | Regra compartilhada pelos dois módulos de `llms` |
| `includes/class-f3base-como-usar.php` | A habilidade que diz ao agente por MCP o que o plugin já faz — montada do registro, nunca de texto à mão |
| `includes/class-f3base-config-mcp.php` | As habilidades de ler e escrever a configuração do implantador pelo canal |
| `admin/class-f3base-admin-tela.php` | A tela de configuração, renderizada do registro e do catálogo |
| `admin/class-f3base-admin-medicao.php` | O menu **Medição**: o que os visitantes fizeram |
| `assets/f3base-tracking.js` | Carregador das tags **e** os coletores de comportamento |
| `assets/f3base-leads.js` | O cliente do botão de contato e da conversão |
| `assets/f3base-consentimento.js` | O banner e o controle de revisão do rodapé |
| `dados/eventos-comportamento.tsv` | Declaração única dos eventos de comportamento |
| `dados/vitais.tsv` | Declaração única das medidas de carregamento |
| `dados/contrato-de-nomes.tsv` | As grafias que a renomeação de prefixo NÃO reescreve |
| `uninstall.php` | O destino declarado de cada conjunto de dados na desinstalação |

Os arquivos de contrato compartilhado — as classes sem pai e a declaração de emissores — chegam de
`partilhado/` no empacotamento e ficam nos mesmos caminhos relativos.

### Acrescentar um módulo

1. Criar `includes/class-f3base-modulo-<nome>.php` com uma classe que estende `F3Base_Modulo` e
   implementa `id()`, `nome()`, `descricao()`, `hooks()` e `calcular_estado()`. Declarar também
   `options_que_controlam()` e `dependencias()` quando houver.
2. Acrescentar o arquivo à lista de autoload em `base-site-core-fator3.php`, **antes** de
   `includes/class-f3base-registro.php`.
3. Acrescentar a classe a `F3Base_Registro::classes()`, na posição em que a tela deve apresentá-la.
4. Escrever a entrada dele **neste documento**, com a pergunta de negócio, quando ele fica inativo e
   o que quebra. `pacote.instrucoes_do_plugin_no_zip` reprova o módulo sem entrada na prosa.
5. Acrescentar a linha do papel dele em `suite/inventario.tsv` — arquivo fora da allow-list aborta o
   empacotamento.
6. Rodar `bash suite/verificar.sh "$PWD"`. A tabela gerada de módulos passa a trazê-lo sozinha.

Não escreva `add_action` de módulo em lugar nenhum: quem registra é o orquestrador, lendo o registro.
Se o módulo precisa criar estrutura própria (tabela, agendamento), implemente `instalar()` e
`desinstalar()`. Se a estrutura precisa nascer também numa ATUALIZAÇÃO de versão, registre um hook em
`init` que verifique e crie, como o módulo de comportamento faz.

### Acrescentar uma option

1. **O catálogo**, em `F3Base_Options::catalogo()`: rótulo, descrição, `operavel`, `secao`, `campo`,
   `padrao` e `sanitiza`. Quando o campo é grupo, declare `subcampos`. Toda folha operável exige
   `impacto` e `exemplo` escritos, e `estatica.campo_operavel_tem_impacto_e_exemplo` cobra isso — um
   campo cujo impacto honesto é "preencher não muda nada" não é campo, é armadilha na tela de quem
   opera.
2. **O sanitizador**, na mesma classe. Ele precisa normalizar o conhecido **e preservar o
   desconhecido** em todos os níveis, e precisa ser idempotente.
3. **A tela não precisa de nada:** `admin/class-f3base-admin-tela.php` percorre
   `F3Base_Options::catalogo()`, pergunta a `F3Base_Options::operavel()` e agrupa pelas seções de
   `F3Base_Options::secoes_da_tela()`.
4. **A linha em `dados/contrato-de-nomes.tsv` é obrigatória para TODA option**, e não só para as que
   o implantador grava: `renomeacao.contrato_de_nomes_completo` cruza o contrato com o catálogo
   inteiro. Sem ela, a renomeação de prefixo reescreve um lado e não o outro, e a configuração fica
   órfã sem erro nenhum.
5. Se ela é SEGREDO, acrescente-a a `segredos_do_site()` e **não** a declare no arquivo de
   configuração do implantador. Se ela guarda estado de execução e não configuração, declare
   `'autoload' => false` e `'estado_execucao' => true`; se a desinstalação deve levá-la, declare
   `'descartavel' => true`.

### Acrescentar um evento de comportamento

**Edite o TSV, não o JavaScript.**

1. Acrescente a linha em `dados/eventos-comportamento.tsv`, com todas as colunas: nome, parâmetros na
   ordem em que o coletor os entrega, teto por página, gatilho, limiar, pergunta, frase e natureza.
2. **O gatilho tem de ser NOVO.** `declaracao( gatilho )` devolve a primeira linha cujo gatilho casa:
   uma segunda linha sobre um gatilho já declarado nunca dispara, e nada acusa. Evento novo, gatilho
   novo.
3. Escreva o coletor do gatilho novo em `assets/f3base-tracking.js`, chamando `declaracao( '<gatilho>' )`
   e `numeroDoLimiar( '<gatilho>', '<chave>', <reserva> )`. **Não escreva o nome do evento nem os
   números do limiar no cliente.** A reserva do `numeroDoLimiar()` tem de ser o MESMO número da
   declaração — uma reserva menor aperta o teto em silêncio no dia em que o arquivo se corromper —, e
   `tracking.eventos_de_comportamento_declarados` cobra isso.
4. Acrescente a linha ao contrato de nomes: nome de evento é grafia que a renomeação não reescreve.
5. `natureza` ausente cai em `tecnica` de propósito — o silêncio não pode promover um evento novo a
   comportamento de uso sem que alguém decida.
6. Rode a sonda de navegador. Coletor novo é mudança na medição de comportamento, e a bancada
   passando não é evidência suficiente.

O teto por página não é enfeite: sem ele, uma única página pode gerar mais eventos que o site inteiro
em um dia, e a conta de medição amostra ou descarta o excesso silenciosamente. O teto está ali para
que o descarte seja NOSSO e declarado.

### Mudar um limite

1. Se ele é **constante**, mude a `const` no módulo. Se ele é **padrão de filtro**, mude o segundo
   argumento do `apply_filters` — e confira o piso e o teto que a função aplica em volta dele, porque
   é a faixa que governa o que um site pode pedir.
2. **Não toque neste documento.** A região `plugin-limites` é gerada da mesma leitura; a prosa aponta
   para ela e não repete valor.
3. Se o limite tem consumidor no CLIENTE, o valor precisa viajar do servidor — nunca ser escrito no
   JavaScript. Limiar de evento sai do TSV; janela, prazo e limite de rota são localizados pelo
   módulo que os publica.
4. Rode `bash suite/verificar.sh "$PWD"`. Um limite publicado que ninguém aplica é achado:
   `leads.limite_por_caractere` mede a unidade, e o servidor e o cliente têm de cortar na mesma.

### Cortar uma release

1. Suba **só** `Version:` no cabeçalho de `fontes/plugin/base-site-core-fator3.php`. Não existe
   constante de versão ao lado dele: a versão é lida por `get_file_data()`, e uma constante que
   repete o número sai de sincronia na primeira release em que alguém mexe nos dois.
2. Rode `bash suite/verificar.sh "$PWD"` na raiz do repositório. A etapa de empacotamento reescreve
   as regiões geradas DESTE documento — inclusive a identidade com a versão nova — e monta o zip; a
   etapa de checagens verifica; a etapa da bancada instala o zip num WordPress real; a etapa do selo
   fecha.
3. Rode `bash suite/verificar.sh piso "$PWD"`. Zero FALHA e zero BLOCKED nas duas.
4. O artefato é o **zip avulso** em `dist/`, e a cópia de conferência do que entrou nele fica em
   `dist/entregue/`. O `sha256` do zip é impresso pela etapa do selo e gravado em
   `suite/rodada.json` e em `dist/lock.tsv`.
5. Declare esse `sha256` no catálogo do implantador, junto ao nome de arquivo publicado
   `base-site-core-fator3.zip`. O digesto é medido e fixado na primeira observação: um zip que muda
   sem release nova é acusado como troca de artefato.
6. `git status` limpo antes de publicar. Rodada com FALHA não sela e apaga o registro anterior — um
   `suite/rodada.json` ausente é a informação de que a última rodada reprovou.

---

## Desinstalação, e o que ela não faz

`uninstall.php` roda inteiro, com o plugin INATIVO e num processo novo — é assim que o WordPress o
executa —, e por isso ele carrega por conta própria todas as classes de que precisa. Toda escrita
passa pelo gravador único, inclusive aqui.

**SAI** — tudo isto é estado de execução, coisa que o plugin produziu sozinho e sabe recriar:

| O quê | Detalhe |
|---|---|
| Options declaradas `descartavel` no catálogo | os carimbos de atividade, o segredo do endpoint, o estado da cadência, a auditoria de escritas do canal |
| `f3base_proveniencia` e `f3base_operaveis` | as duas âncoras: estado SOBRE o catálogo, e nada mais as lê |
| Os agendamentos | inclusive o evento da Conversions API, que é agendado com argumento e por isso pede `wp_unschedule_hook()` |
| Os transientes | |
| As TRÊS tabelas próprias | `f3base_leads_dedup`, `f3base_comportamento` e `f3base_eventos` |

`f3base_eventos` está nessa lista, e a ausência dela era o defeito mais caro daqui: ela guarda o
apelido do visitante, o identificador da sessão e o carimbo de cada acionamento — dado pessoal
pseudonimizado —, e sobrevivia ao apagamento do plugin. Tabela órfã com dado pessoal, sem plugin
nenhum para lê-la, apagá-la ou responder por ela, é o pior desfecho possível de uma desinstalação.

**FICA**, por decisão declarada:

| O quê | Por quê |
|---|---|
| Os registros de lead — o tipo de conteúdo de contingência e a caixa do Flamingo | Desinstalar plugin não é pedido de eliminação de dado pessoal, e esses registros são o histórico comercial de quem opera o site |
| `f3base_journal_eliminacao` | Ele é a PROVA do que já foi apagado e quando; apagá-lo junto destruiria exatamente o registro que uma auditoria procuraria |
| As options de CONFIGURAÇÃO | Reinstalar devolve o site ao que ele era; apagá-las obrigaria a reconfigurar tudo à mão depois de uma desinstalação feita por engano |

A remoção do que fica tem rota própria, com capacidade exigida, journal e regime declarado.

**Na desativação simples**, os módulos são desinstalados e **nenhum dado de lead é tocado**. Nem a
ativação nem a desativação regravam regras de reescrita: este plugin não registra nenhuma — as rotas
dele são REST, e as reservas de `/llms.txt` e `/llms-full.txt` são servidas em `template_redirect`.

**MULTISITE É RECUSADO NA ATIVAÇÃO EM REDE.** Tudo o que este plugin guarda é do site corrente e por
site: options, as duas tabelas, o tipo de conteúdo de contingência e os agendamentos. A desinstalação,
que o WordPress roda UMA vez, limparia o site corrente e deixaria as tabelas e as options de todos os
outros. Não há `wpmu_drop_tables` e não há laço por blog, e fingir que há seria pior que declarar o
limite. `recusar_ativacao_em_rede()` desativa o plugin e explica; quem quer o plugin numa rede o
ativa SITE A SITE, e cada ativação faz exatamente o que faz numa instalação única.

**PHP DE SESSENTA E QUATRO BITS É EXIGÊNCIA, e ela está no cabeçalho.** O carimbo em milissegundos do
registro de comportamento não cabe em trinta e dois bits: ali ele estoura em silêncio e a série de
tempo passa a mentir.

### Convivência com uma cópia anterior

**Ativar sobre um site que roda a cópia antiga desativa a cópia antiga.** Duas cópias do mesmo plugin
ativas significam dois registros de hooks, duas rotas REST para o mesmo endereço, dois coletores
enfileirados na mesma página e a conversão contada em dobro. O WordPress não impede isso e não avisa:
nada aparece como erro, aparece como número errado, semanas depois.

**O discriminante é o namespace REST reivindicado**, lido do topo do arquivo principal de cada plugin
ativo — e não uma lista de nomes de pasta, que só reconhece o que alguém lembrou de escrever nela.
**NÃO HÁ DADO A MIGRAR**, e é por isso que o prefixo interno não mudou: as options são as mesmas e as
tabelas são as mesmas. O que mudou foi o ENDEREÇO do código, e endereço não guarda dado.

**Por que desativar a outra, e não recusar ativar esta.** Recusar deixaria o site rodando a cópia
ANTIGA — o artefato que esta release existe para substituir —, e a instalação é feita pelo
implantador, sem ninguém olhando. **O que ela NÃO faz:** não apaga arquivo nenhum, não toca em option
nem em tabela, e não desativa nada que não carregue a marca. A pasta antiga continua em disco e
reativá-la é um clique. O que ela deixa é REGISTRO: um transiente com prazo, lido uma vez pela tela,
com o nome do que foi desativado. **O gancho de desativação da cópia antiga não roda** — ele
desinstalaria os módulos e desagendaria a cadência, os MESMOS agendamentos que esta cópia acabou de
instalar, porque as chaves são as mesmas.

---

## O que NUNCA se toca

| O quê | Por quê |
|---|---|
| Nome de option (`f3base_*`) | Renomear orfana o valor sem apagar nada e sem erro nenhum. O site passa a rodar no padrão de fábrica em cima de uma configuração que ninguém apagou |
| Nome de tabela | Renomear não migra nada: cria uma tabela vazia ao lado e a série histórica fica órfã |
| Nome de evento declarado no TSV | Renomear quebra a série na conta de medição do fornecedor, onde não há como reparar depois |
| O GATILHO como chave única | O coletor resolve a primeira linha que casa. Duas linhas no mesmo gatilho fazem a segunda nunca disparar, e nada acusa |
| Namespace REST | O implantador e a suíte montam URLs contra ele; renomear de um lado só faz a chamada bater em `404`. É também a MARCA que reconhece uma cópia mais velha deste plugin na ativação |
| O prefixo `f3base-secao-` | É contrato do plugin, carimbado por tema e conteúdo renomeados. Trocá-lo mata a medição de seções em todo site derivado, calada |
| As classes de `partilhado/` | O implantador as carrega ANTES de o plugin existir na instalação. Renomear um lado só faz o autoload procurar um arquivo que não existe: erro fatal na ativação |
| A versão lida do cabeçalho | Constante que repete o número sai de sincronia na primeira release em que alguém mexe nos dois. Já foi medido: o cabeçalho dizia um número e a constante dizia outro |
| A ordem dos parâmetros no TSV | O coletor entrega posicionalmente. Trocar duas colunas troca o significado das duas no relatório |
| A escrita direta de option | O ponto único é o que torna a leitura de volta e a procedência auditáveis |
| O nome `f3base_cortadas` fora da declaração | Declará-lo como evento o faria responder, na tela e na série histórica, uma pergunta que ele não responde |
| A unidade de `criado_em` | Ele é contado em SEGUNDOS, e é o que as linhas já gravadas têm. Trocar para milissegundos mistura duas unidades na mesma coluna, e todo leitor passa a mostrar datas de outro século sem erro nenhum |
| O carimbo vindo da ÂNCORA do lote | Voltar ao instante da chegada faz dezenas de acionamentos de segundos de navegação caírem no mesmo segundo, e a tela mostra linhas distintas como se fossem a mesma sendo reescrita |
| A origem viajando DENTRO do lote selado | Lida no despacho, ela é a da página que encontrou o pendente, e o lote retomado sai carimbado no futuro dele |
| O gancho `wp_abilities_api_init` e o `category` das habilidades | Sem os dois, o núcleo recusa o registro com `_doing_it_wrong` e as três habilidades somem sem erro visível |

---

## O peso entregue

**Os comentários da fonte não viajam.** A disciplina de comentário deste plugin existe para impedir
regressão, e quem lê é quem MANTÉM o pacote — não o navegador de quem visita. O empacotamento entrega
os `.js` de `assets/` **sem comentário**, e a fonte continua com tudo.

<!-- gerado:inicio=plugin-peso -->
| Arquivo | Fonte | Entregue | Fonte comprimido | Entregue comprimido |
|---|---|---|---|---|
| `assets/f3base-consentimento.js` | 15044 B | 9034 B | 5381 B | 2693 B |
| `assets/f3base-leads.js` | 35655 B | 16972 B | 12172 B | 4714 B |
| `assets/f3base-tracking.js` | 117436 B | 33607 B | 39047 B | 8486 B |
<!-- gerado:fim=plugin-peso -->

**O corte é feito por TOKENIZADOR, nunca por expressão regular.** `/*` dentro de string e `//` dentro
de URL ou de literal de expressão regular existem NESTES arquivos, e um corte ingênuo os apaga
entregando um arquivo que ainda analisa e faz outra coisa.

**Quem mexer no empacotamento tem de manter a checagem que compara o FLUXO DE TOKENS.** Contar
comentários não veria nada disso — o arquivo corrompido também não tem comentário nenhum. A prova é:
fonte e entregue são tokenizados, os comentários são descartados dos dois, os espaços são
normalizados, e o que sobra tem de ser idêntico token a token. Quem diz que o entregue ainda é
JavaScript é o `node --check`; quem diz que ele se COMPORTA igual são as bancadas e a sonda de
navegador, que rodam contra o entregue e não contra a fonte.

---

## A memória curta desta release

O que mudou da versão de teste para esta é registrado achado a achado em `suite/correcoes/`, uma
linha por achado, com o arquivo, o que mudou, a checagem que prova e o piso dela. O `MEMORIA-DECISOES.md`
do repositório narra as decisões. Aqui fica só o mapa de por onde procurar.

| Família | Registro | O que ela fechou |
|---|---|---|
| Medição e coletor | `suite/correcoes/A.tsv` | O lote sem métricas deixou de ser descartado; o carimbo passou a ser o do acionamento, com âncora e guarda de relógio; o dia passou a sair da âncora nas duas tabelas; o apelido do visitante deixou de nascer sem decisão; a tela Medição ganhou o quadro de vitais e passou a declarar o recorte |
| Leads, consentimento e CAPI | `suite/correcoes/B.tsv` | O evento de servidor passou pelo portão do consentimento; o token ganhou escopo e rota de renovação; a reserva passou a ser compensada; a origem confiável passou a exigir faixas de IP; a atribuição e os cookies de fornecedor ficaram atrás do portão; a contingência deixou de sumir com os leads dentro |
| Núcleo, options, tela e habilidades | `suite/correcoes/C.tsv` | A desinstalação passou a rodar inteira e a levar o registro detalhado; as três habilidades passaram a existir num WordPress real; o gravador único passou a avisar por campo, recusar em vez de reescrever, preservar em todos os níveis e não reescrever a procedência a cada visita; o token da Conversions API virou segredo mascarado e editável |
| Módulos restantes e partilhado | `suite/correcoes/D.tsv` | `/llms-full.txt` deixou de responder erro; conteúdo protegido saiu das listas; o redirect deixou de girar e o ramo de recurso removido passou a terminar a requisição; os cabeçalhos passaram a compor, validar a forma e alcançar o REST; o FAQ ficou restrito ao singular; a retenção passou a cortar em calendário, declarar o backlog e registrar a eliminação definitiva |

A última rodada e o último piso de cada frente estão em `suite/correcoes/*-rodada-final.log` e
`*-piso-final.log`, e o que ficou POR CORRIGIR em cada uma está na própria tabela, na linha cujo
"o que mudou" diz `(mantido)`, com o motivo ao lado.

## Acessos do servidor e sessão de login

### `F3Base_Modulo_Acessos_Servidor` — `acessos-servidor`

A aba **Medição → Acessos** soma os arquivos `access.log.AAAA-MM-DD` disponíveis no servidor, até ontem. O dia do agregado é o nome do arquivo de rotação, no calendário do host; o registro do navegador usa UTC. O módulo começa ligado. A configuração nasce com `~/logs/<host-de-home_url>/https/access.log.*`. O prefixo `www.` do domínio é removido no padrão; caminhos personalizados são preservados. Se `HOME` não existir, a resolução consulta os diretórios POSIX disponíveis e os ascendentes da instalação, procurando a pasta completa de logs. Um caminho absoluto continua disponível. Um glob que alcance diretórios distintos é recusado porque o formato combined não identifica o domínio. Arquivos numéricos como `.0`, compactados e o arquivo do dia corrente não entram.

**Atualizar** relê `access.log` a cada clique e combina as linhas completas de hoje com o histórico do período. A data atual usa o fuso do WordPress e aparece como parcial com o horário da leitura. A janela inclui hoje: um dia significa somente hoje; estão disponíveis um, dois, três, quatro, cinco, seis, sete, quinze, trinta, sessenta e noventa dias. A leitura não armazena hoje e ignora linhas de outros dias ou ainda incompletas. O arquivo atual pode perder cobertura ao rotacionar; atrasos de escrita do servidor também afetam a atualização. Não há atualização automática da tela sem um novo clique. Arquivo ausente, formato inválido ou limite de leitura excedido gera aviso, mantendo o histórico visível.

**Coletar e Armazenar Logs** mantém o comportamento da soma histórica: processa apenas arquivos datados anteriores a hoje, sem duplicar dias já coletados e sem ler o arquivo corrente ou o numérico. O formulário conserva período e filtro de erros após executar. A mesma coleta é agendada diariamente às nove horas UTC, com recuperação do agendamento ausente na inicialização. A tela informa a próxima execução no fuso do WordPress e avisa sobre atraso ou acionamento automático desabilitado. O WP-Cron depende de requisições ao site; uma tarefa cron do servidor pode acioná-lo regularmente quando não há tráfego. Desligar o módulo remove o agendamento e também desliga a leitura atual.

Cada dia é substituído integralmente numa transação InnoDB; arquivos do mesmo dia são agrupados antes da escrita e aliases do mesmo inode são descartados. Assinaturas com nome, tamanho, mtime e configuração evitam repetir trabalho. Falha de formato majoritária, erro de banco ou arquivo alterado durante a leitura preservam o agregado anterior e não confirmam o checkpoint. A trava por arquivo serializa cron e botão no mesmo host; ambientes com vários hosts de aplicação exigem um coletor coordenado externo.

A primeira requisição após atualização cria tabela e evento sem reativação. A soma começa no próprio processo e trabalha por lotes de dias; depois do orçamento de execução, agenda continuação e declara quantos dias faltam. Arquivos individuais têm limite explícito de tamanho; exceder o limite degrada o módulo com o nome do arquivo, preservando o dia anterior. A cobertura é o número de dias efetivamente processados dentro do período, incluindo dias com arquivo vazio. Não é o intervalo entre duas datas. A retenção do agregado nasce em vinte e cinco meses, com limite configurável de um a cento e vinte meses.

A fonte `dados/robos-conhecidos.tsv` declara famílias HTTP e finalidade. Busca em IA entra em `busca`; `resposta-ia` identifica requisição em nome de usuário. `Google-Extended` e `Applebot-Extended` são controles de uso em robots.txt; não representam crawlers independentes. `GoogleOther`, `CCBot` e marcas sem finalidade atual confirmada ficam em `generico`. Essas classes não demonstram o uso posterior do conteúdo. A identidade é declarada e não é verificada.

O caminho perde query e fragmento. REST com `rest_route` é classificada como REST; instalação em subdiretório e variantes codificadas da administração respeitam a exclusão. Administração, MCP e recursos excluídos são somados com caminho vazio. Recursos estáticos, descoberta, APIs e páginas têm classes próprias. Ao ultrapassar o teto de caminhos por dia e família, o excedente vai para `outro`, sem detalhe de caminho. A tabela usa comparação binária para caminhos, preservando a diferença entre maiúsculas e minúsculas.

O agregado não guarda IP, referer ou User-Agent bruto. Isso **não permite afirmar anonimização irrestrita**: caminhos públicos podem conter nomes ou identificadores. E-mails e tokens evidentes perdem o detalhe; configure `caminhos_excluidos` para rotas privadas e dados do seu domínio. A coleta não cria entrada no journal de eliminação de leads. O gerador de privacidade pertence ao implantador e não oferece nesta fonte um contrato de frase por módulo; a atualização de sua página de privacidade permanece uma pendência de integração.

**Humanos** significa requisições de agente não declarado como robô. **Pessoas medidas** significa identificadores distintos no registro do navegador, com sua retenção própria. A diferença entre eles não mede automação: repetição de visitas, consentimento, bloqueio de scripts, CDN e calendários diferentes afetam os resultados. A tela declara limites e mostra o detalhe de famílias por página, o bloco de descoberta/APIs e o rodapé de excluídos, estáticos e excedentes. Status de sucesso e redirecionamento são o padrão; erros podem ser incluídos.

`F3Base_Acessos_Mcp` registra `f3base/acessos-ler` com `manage_options`. A entrada aceita `dias`, `classe_caminho`, `prefixo`, `incluir_erros` e `offset`; a resposta informa as linhas, o total antes da paginação, o limite, a cobertura, o estado e os totais do rodapé de todo o período. Consulta somente o histórico até ontem, sem o complemento temporário de hoje da tela. Não executa a soma. `como-usar` descobre o módulo pelo registro único. Alterar regras reprocessa apenas arquivos ainda presentes; dias cujas fontes foram apagadas conservam a classificação anterior.

### `F3Base_Modulo_Sessao_De_Login` — `sessao-de-login`

A option `f3base_sessao` nasce ligada, com noventa dias, aceitando de um a trezentos e sessenta e cinco. `auth_cookie_expiration` define o prazo assinado e o token do núcleo; `login_form_login` força `rememberme` no POST nativo. O núcleo acrescenta doze horas ao vencimento do cookie no navegador, mantendo o token no prazo declarado. Para `wp_login_form`, `value_remember` marca a caixa; `remember` apenas controla sua exibição.

O diagnóstico executa a cadeia real de filtros para o usuário consultado e informa a duração efetiva. Havendo divergência, lista os callbacks do último grupo de prioridade que mudou o valor. Quando há vários na mesma prioridade, o grupo é explicitamente apresentado, sem atribuir a um callback um efeito que não foi isolado. Sondas temporárias observam uma única execução da cadeia, sem repetir callbacks que possam ter efeitos próprios.

Cookies existentes conservam seu prazo após desligar ou mudar a duração. “Sair de todos os outros dispositivos”, no perfil, revoga as demais sessões pelo mecanismo do núcleo. O módulo não altera `WP_Session_Tokens`, flags de segurança ou sessões por dispositivo. O filtro alcança os logins que usam a emissão de cookies do núcleo; formulários externos precisam respeitar o fluxo nativo para obter a persistência de `rememberme`.

### Índice de texto e texto integral

Quando `llms.full` está ligado, existe seleção e o emissor deste plugin é responsável, `llms.txt` ganha `## Optional` com o link produzido por `home_url()` para `llms-full.txt`. Desligado, não há link. Arquivo físico ou emissor concorrente conserva sua precedência. Nenhum dos dois arquivos é acrescentado ao sitemap. O texto de `robots.txt` continua sob responsabilidade do implantador.

A leitura de cada dia tem orçamento de até oito segundos, reduzido quando o limite de execução do PHP é menor. Se esse orçamento ou os demais limites forem excedidos, o dia anterior permanece confirmado e o motivo aparece no estado. A continuação automática é entre dias; ela não declara concluído um arquivo parcialmente lido.
