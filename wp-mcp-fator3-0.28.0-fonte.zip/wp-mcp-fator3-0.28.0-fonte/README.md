# Fator3 MCP 0.28.0

Versão vigente 0.28.0: Pedido MCP 65, auditoria de serviço integrada ao LinkedIn 0.7.0. Guia: docs/MUTATION-SERVICE-AUDIT.md; evidências novas em evidencias/0280.
Servidor MCP independente para WordPress. Pedido MCP 65: Registro central de escritas de serviço e leitura administrativa do recibo. Base imediata 0.27.0; instalação limpa; WordPress 7.1.2 / PHP 8.3.6.

Operação e contratos: docs/OPERACAO.md, docs/OAUTH-CIMD.md e docs/RELEASE-0270.md. Guias instalados consultáveis por system/guide. Identidade wp-mcp-fator3/wp-mcp-fator3.php. B22 ChatGPT encerrado historicamente; aceite do aplicativo Claude distinguido dos testes do servidor.

Build: python3 tools/sync_docs.py; python3 tools/build_packages.py. Testes da rodada: tools/release0270; evidencias/0270. Fechamento: tools/release0270/close-release.py. Evidências anteriores são históricas. Contrato humano mutation-audit/1.0.0 revalidado com LinkedIn 0.6.0; contrato de serviço permanece proposta no impacto, sem capacidade de runtime. Nenhuma publicação automática em GitHub/frota. Sem tokens reais ou bancos privados nos pacotes.
