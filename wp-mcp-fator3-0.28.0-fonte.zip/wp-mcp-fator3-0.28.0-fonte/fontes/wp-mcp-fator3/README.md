# Fator3 MCP 0.28.0

Servidor MCP independente para WordPress. Pedido 65: auditoria de serviço, principal separado, introspecção e recibo de persistência; integração real com LinkedIn 0.7.0. Atualização direta da 0.27.0 e instalação limpa. Mínimos WordPress 7.1.2/PHP 8.3.6.

Operação/contratos: docs/OPERACAO.md, MUTATION-SERVICE-AUDIT.md e RELEASE-0280.md. Guias instalados via system/guide. Identidade wp-mcp-fator3/wp-mcp-fator3.php preservada. B22 e Claude aceitos conforme documento do dono recebido; nenhuma pendência nova de CIMD.

Build: python3 tools/sync_docs.py; python3 tools/build_packages.py. Provas novas em tools/release0280 e evidencias/0280; provas anteriores são históricas. Nenhuma publicação automática em GitHub/frota, segredo real, banco ou fixture ativa no instalador.
