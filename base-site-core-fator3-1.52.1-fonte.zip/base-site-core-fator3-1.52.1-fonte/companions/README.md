# Acompanhantes para reproduzir os testes

Os acompanhantes foram examinados e testados em suas cópias originais. Seus runtimes não são republicados no fonte Core: pertencem a outros pacotes e podem conter exemplos/documentação próprios. O instalador Core é autônomo.

Antes dos testes integrados, forneça os instaladores originais e extraia suas pastas, sem alterar conteúdo, em `companions/<slug>/`. Copie essas mesmas pastas para os plugins do laboratório. `evidence/1521/inputs.json` identifica os arquivos recebidos; `companions.json` registra a igualdade byte a byte verificada entre quatro instaladores e as cópias usadas.

| Pacote | Versão |
|---|---|
| wp-mcp-fator3 | 0.30.1 |
| wp-mcp-google-fator3 | 0.19.0 |
| wp-mcp-meta-fator3 | 0.10.1 |
| wp-mcp-linkedin-fator3 | 0.10.1 |
| wp-mcp-pipedrive-fator3 | 0.1.0 |

Google 0.19.0 foi preservado byte a byte da entrada usada na 1.51.0; não foi recebido novo Google nesta rodada. Seu instalador está identificado no relatório de base pelo SHA-256 `d15868915e3fdf886d7e883a82d9d302df7242808fc94d45bf3e1857234759d1`; use como referência autoritativa a identidade completa do arquivo original recebido, não um nome de versão isolado. A prova desta rodada compara a árvore Google com a base preservada.

Pipedrive exige PHP 8.3.36: não o ative em PHP 8.3.6. O teste request-294 carrega somente o consumidor original via fixture; o pacote completo permanece instalado no Site-Teste, com operação comercial desligada e sem transporte real.
