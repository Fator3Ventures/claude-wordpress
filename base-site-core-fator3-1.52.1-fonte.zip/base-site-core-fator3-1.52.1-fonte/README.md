# Fator3 Site Core 1.52.1 — fonte

Base direta 1.51.0; pedidos 296, 297 e 298. Contrato administrativo 8.17.0, 146 abilities Core, ciclo de 17 etapas. Runtime em `work/plugin/base-site-core-fator3`, idêntico ao instalador. Este ZIP não é instalável.

A 1.52.0 foi o candidato de homologação; a 1.52.1 corrige nomes de contadores que o MCP 0.30.1 mascarava. Os pedidos e efeitos técnicos estão no relatório principal e no impacto individual ao MCP. As normas centrais não foram alteradas.

`build/README.md` explica reprodução. `tests/request-296.php`, `request-297.php` e `request-298.php` cobrem limpeza conferida, memória/fallback/retentativa e alarmes/prioridade. `evidence/1521/` identifica o candidato final; `evidence/1520/` conserva a regressão ampla e a primeira homologação. Os arquivos mais antigos são históricos, não prova de execução nesta rodada.

Os acompanhantes usados foram MCP 0.30.1, Google 0.19.0, Meta 0.10.1, LinkedIn 0.10.1 e Pipedrive 0.1.0. Seus runtimes não são republicados; forneça os originais para reproduzir a integração, conforme `build/COMPANIONS.md`. Manifestos preservam versões, hashes e provas de igualdade. Documentação Core substituída está em `history/docs-ate-1.51.0/`, fora do instalador.

Não contém banco, credenciais reais, cookies, dependências de laboratório, node_modules ou ZIP aninhado. A cópia do relatório no fonte antecede o fechamento; o relatório externo identifica o ZIP final. O pedido 296 foi sanitizado na cópia de entrada para não republicar os contatos pessoais citados no original.
