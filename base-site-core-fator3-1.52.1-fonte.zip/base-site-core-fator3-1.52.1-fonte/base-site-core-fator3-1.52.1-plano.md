# Plano — Fator3 Site Core 1.52.0

Base 1.51.0 → minor prevista 1.52.0; contrato administrativo previsto 8.17.0. Pedidos Core 296, 297, 298; impacto recebido Implantador 2.11.0 (schema sem type) e Pipedrive 0.1.0 (contrato já entregue em 1.51.0). Fontes centrais permanecem intactas.

296: retirar compat/email-legado, alias e migração automática; precondição explícita para atualização de instalação existente; limpeza administrativa simulável e com revisão, verificando conteúdo corrente antes de remover resíduos. Retirar importador CF7 sem chamador e inferência/ganchos Elementor. Arquivar documentos substituídos em history, índice vigente e varredura de dados pessoais. Inventariar outras transições sem ampliar remoções arriscadas.
297: memória incremental e teto efetivo; fallback por rota quando catálogo não cabe, diagnóstico persistido e nova tentativa em falha sem publicar dia parcial.
298: duas cadências perdidas / três falhas consecutivas de transporte; incidentes com supressão ao recuperar antes do envio, abertura única e encerramento condicionado à abertura. Captação Meta/LinkedIn e entrega Pipedrive/Slack vencidas antes da manutenção, com cotas próprias e limites de rede preservados.

Matriz atual: MCP 0.30.1, Google 0.19.0, Meta 0.10.1, LinkedIn 0.10.1, Pipedrive 0.1.0. Sem adaptação identificada nos acompanhantes. O alerta do Implantador será reproduzido/corrigido no Core; não exige alterar contrato consumidor. O impacto Pipedrive é entrada já atendida, não novo encaminhamento. Nenhum relatório apenas de encerramento será emitido (norma revisão 5). O Implantador não será instalado em site existente.

Provas: WordPress descartável limpo e atualização direta 1.51.0; funcionalidade, autorização/revisão/falha/concorrência pertinentes; novas versões dos acompanhantes, leitura documental integral; Site-Teste com cópia final e homologação sintética confinada, sem CRM real (aceite comercial nos sites indicados pertence à frota). Não usar credenciais reais nem enviar mensagens no teste. Pico real do processo/catálogo e tempos por passagem serão medidos. Sete dias na frota permanecem aceite posterior.

## Ajuste da homologação

A 1.52.0 foi instalada no Site-Teste. O MCP 0.30.1 ocultou os campos novos com a palavra passagens; a entrega final é 1.52.1, com nomes operacionais explícitos, testes repetidos e impacto técnico novo ao MCP. O aviso do Implantador não se reproduziu no Core atual; não houve mudança de schema. Não há novo impacto a Pipedrive, Google, Meta ou LinkedIn.
