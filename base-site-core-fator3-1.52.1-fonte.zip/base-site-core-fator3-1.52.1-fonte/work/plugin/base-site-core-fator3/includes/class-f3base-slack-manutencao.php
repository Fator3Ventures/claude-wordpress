<?php
/** Manutenção restrita aos avisos emitidos e registrados nesta instalação. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
require_once __DIR__.'/trait-f3base-slack-gestao.php';
final class F3Base_Slack_Manutencao {
    use F3Base_Slack_Gestao;
    private static array $identidades=array();
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_slack_manutencao';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();dbDelta("CREATE TABLE {$t} (
 id char(64) NOT NULL,
 tipo varchar(16) NOT NULL,
 aviso_tipo varchar(32) NOT NULL DEFAULT 'desconhecido',
 alvo char(64) NOT NULL DEFAULT '',
 record_id char(32) NOT NULL DEFAULT '',
 teste tinyint NOT NULL DEFAULT 0,
 site char(64) NOT NULL,
 destino char(64) NOT NULL,
 canal varchar(64) NOT NULL DEFAULT '',
 ts varchar(32) NOT NULL DEFAULT '',
 principal char(64) NOT NULL DEFAULT '',
 team_id varchar(64) NOT NULL DEFAULT '',
 bot_id varchar(64) NOT NULL DEFAULT '',
 user_id varchar(64) NOT NULL DEFAULT '',
 estado varchar(32) NOT NULL,
 revisao char(64) NOT NULL,
 payload longtext NOT NULL,
 criado_em bigint NOT NULL,
 atualizado_em bigint NOT NULL,
 ausencia_em bigint NOT NULL DEFAULT 0,
 remocao_aceita_em bigint NOT NULL DEFAULT 0,
 PRIMARY KEY  (id),
 KEY registro (record_id,tipo),
 KEY remoto (canal,ts),
 KEY principal (principal),
 KEY tipo (tipo,criado_em)
 ) ENGINE=InnoDB {$wpdb->get_charset_collate()};");if($wpdb->last_error){return false;}
        // Classify surviving historical records without reconstructing erased contact content.
        $wpdb->query($wpdb->prepare("UPDATE %i m LEFT JOIN %i l ON l.record_id=m.record_id SET m.aviso_tipo=CASE WHEN m.tipo='teste' THEN 'teste_conexao' WHEN l.captura='suspeito' THEN 'suspeito' WHEN l.metodo LIKE 'anuncio_%%' THEN 'captacao' WHEN l.record_id IS NOT NULL AND l.captura NOT IN ('eliminado','eliminando') THEN 'contato' ELSE 'desconhecido' END WHERE m.tipo IN ('parte','teste') AND m.aviso_tipo='desconhecido'",self::tabela(),F3Base_Leads_Repositorio::tabela()));return !$wpdb->last_error;
    }
    private static function site(): string {return hash('sha256',home_url().'|'.wp_salt('auth'));}
    private static function erro(string $s,array $extra=array()): array {return array_merge(array('ok'=>false,'codigo'=>$s),$extra);}
    private static function linha(string $id): ?array {global $wpdb;if(!preg_match('/^[a-f0-9]{64}$/D',$id)){return null;}return $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s',self::tabela(),$id),ARRAY_A);}
    private static function gravar(array $r,array $data): bool {global $wpdb;$cipher=F3Base_Contato_Comunicacao::cifrar($data);if(!$cipher){return false;}$r['payload']=$cipher;return false!==$wpdb->insert(self::tabela(),$r,array_fill(0,count($r),'%s'));}
    private static function mudar(array $r,array $changes,?array $data=null): bool {global $wpdb;if($data!==null){$changes['payload']=F3Base_Contato_Comunicacao::cifrar($data);if(!$changes['payload']){return false;}}$changes['atualizado_em']=time();$n=$wpdb->update(self::tabela(),$changes,array('id'=>$r['id'],'revisao'=>$r['revisao']));if($n===1){return true;}if($n===false){return false;}$same=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s AND revisao=%s',self::tabela(),$r['id'],$r['revisao']),ARRAY_A);if(!$same){return false;}foreach($changes as $k=>$v){if((string)$same[$k]!== (string)$v){return false;}}return true;}
    public static function identidade(): array {
        $rev=F3Base_Slack::destino();if(isset(self::$identidades[$rev])){return self::$identidades[$rev];}$token=F3Base_Segredos::abrir(F3Base_Slack::SEGREDO);if(!$token){return self::erro('credencial_ausente');}$r=F3Base_Slack::api('auth.test',$token,array());
        if(empty($r['ok'])||empty($r['team_id'])||empty($r['bot_id'])||empty($r['user_id'])){return empty($r['ok'])?$r:self::erro('identidade_bot_incompleta');}self::$identidades[$rev]=$r;return $r;
    }
    /** Persiste classificação antes de enviar; nunca deriva teste de um texto remoto. */
    public static function preparar(array $p,array $message,bool $teste,string $tipo='parte'): array {
        $old=self::linha($p['chave']);if($old){return $old['site']===self::site()&&$old['destino']===F3Base_Slack::destino()?array('ok'=>true,'id'=>$old['id']):self::erro('registro_de_outra_instalacao_ou_destino');}
        $lead=!empty($p['record_id'])?F3Base_Leads_Repositorio::obter($p['record_id']):null;$aviso_tipo=$tipo==='teste'?'teste_conexao':(($lead['captura']??'')==='suspeito'?'suspeito':(in_array($lead['metodo']??'',array('material','conteudo','captacao'),true)||str_starts_with($lead['metodo']??'','anuncio_')?'captacao':'contato'));
        $who=self::identidade();if(empty($who['ok'])){return $who;}$r=array('aviso_tipo'=>$aviso_tipo,'id'=>$p['chave'],'tipo'=>$tipo,'alvo'=>$tipo==='parte'?$p['chave']:'','record_id'=>$p['record_id']??'','teste'=>$teste?1:0,'site'=>self::site(),'destino'=>F3Base_Slack::destino(),'canal'=>$p['canal'],'ts'=>'','principal'=>$p['principal']??'','team_id'=>$who['team_id'],'bot_id'=>$who['bot_id'],'user_id'=>$who['user_id'],'estado'=>'preparado','revisao'=>hash('sha256',wp_json_encode($message)),'criado_em'=>time(),'atualizado_em'=>time());
        return self::gravar($r,array('mensagem'=>$message,'autor'=>get_current_user_id()))?array('ok'=>true,'id'=>$r['id']):self::erro('registro_previo_falhou');
    }
    public static function concluir(string $id,array $res): bool {$r=self::linha($id);if(!$r){return false;}$d=F3Base_Contato_Comunicacao::abrir($r['payload']);$d['aceite']=$res;$changes=array('estado'=>!empty($res['ok'])?'aceito':(!empty($res['recusado'])||!empty($res['permanente'])||!empty($res['retry_after'])?'recusado':'incerto'));if(!empty($res['ok'])){$changes['ts']=$res['ts'];$changes['canal']=$res['canal'];}return self::mudar($r,$changes,$d);}
    public static function teste(): array {
        $c=F3Base_Options::ler('f3base_avisos');$id=hash('sha256',wp_generate_uuid4());$message=array('text'=>'[TESTE] Site Core · '.sanitize_text_field(get_bloginfo('name')).' · verificação solicitada pelo administrador.','blocks'=>array(),'unfurl_links'=>false,'unfurl_media'=>false);$p=array('chave'=>$id,'canal'=>$c['slack_canal_id']);$r=self::preparar($p,$message,true,'teste');if(empty($r['ok'])){return $r;}
        $res=F3Base_Slack::api('chat.postMessage',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),$message+array('channel'=>$p['canal']));$saved=self::concluir($id,$res);return array_merge($res,array('id_local'=>$id,'registro_persistido'=>$saved,'codigo'=>$saved?$res['codigo']:'resultado_incerto_nao_persistido'));
    }
    private static function alvo(string $id): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}$r=self::linha($id);if(!$r||!in_array($r['tipo'],array('parte','teste'),true)){return self::erro('alvo_nao_registrado');}
        if($r['site']!==self::site()||$r['destino']!==F3Base_Slack::destino()){return self::erro('instalacao_ou_destino_divergente');}if(!$r['ts']||!$r['team_id']||!$r['bot_id']||!$r['user_id']){return self::erro('referencia_remota_nao_comprovada');}
        $who=self::identidade();if(empty($who['ok'])){return $who;}foreach(array('team_id','bot_id','user_id') as $k){if($who[$k]!==$r[$k]){return self::erro('autoria_ou_workspace_divergente');}}
        return array('ok'=>true,'registro'=>$r);
    }
    public static function publico(array $r): array {return array_intersect_key($r,array_flip(array('id','tipo','record_id','teste','canal','ts','principal','estado','revisao','criado_em','atualizado_em')))+array('criado_legivel'=>wp_date('d/m/Y H:i:s',(int)$r['criado_em']),'manutencao_disponivel'=>$r['site']===self::site()&&$r['destino']===F3Base_Slack::destino()&&$r['ts']!=='');}
    public static function listar(array $e=array()): array {
        global $wpdb;$where="tipo IN ('parte','teste')";if(!empty($e['record_id'])){$where.=$wpdb->prepare(' AND record_id=%s',$e['record_id']);}if(isset($e['teste'])){$where.=$wpdb->prepare(' AND teste=%d',$e['teste']?1:0);}if(($e['origem']??'')==='teste_conexao'){$where.=" AND tipo='teste'";}elseif(($e['origem']??'')==='contato'){$where.=" AND tipo='parte'";}
        $page=max(1,(int)($e['pagina']??1));$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$where} ORDER BY criado_em DESC,id LIMIT 51 OFFSET %d",self::tabela(),($page-1)*50),ARRAY_A)?:array();return array('linhas'=>array_map(array(__CLASS__,'publico'),array_slice($rows,0,50)),'proxima_pagina'=>count($rows)>50?$page+1:null);
    }
    private static function remota(array $r,bool $thread=false,string $cursor=''): array {
        $reply=$r['principal']!=='';$root=$reply?self::linha($r['principal']):$r;
        if(!$root||!$root['ts']){return self::erro('principal_nao_registrada');}
        foreach(array('site','destino','canal','team_id') as $k){if($root[$k]!==$r[$k]){return self::erro('principal_contexto_divergente');}}
        $method=$reply||$thread?'conversations.replies':'conversations.history';
        $body=array('channel'=>$r['canal'],'limit'=>15);
        if($method==='conversations.replies'){$body['ts']=$root['ts'];}
        if(!$thread){$body+=array('oldest'=>$r['ts'],'latest'=>$r['ts'],'inclusive'=>true);}
        if($cursor!==''){$body['cursor']=$cursor;}$seen=array();
        for($page=0;$page<20;$page++){
            $x=F3Base_Slack::api($method,F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),$body);if(empty($x['ok'])){return $x;}
            $msgs=$x['messages'];foreach($msgs as $m){if(!is_array($m)||!is_string($m['ts']??null)||!preg_match('/^[0-9]+\.[0-9]+$/D',$m['ts'])){return self::erro('slack_historico_invalido');}}
            $partial=$x['has_more']||$x['cursor']!=='';
            if(!$thread){$msgs=array_values(array_filter($msgs,static fn($m)=>$m['ts']===$r['ts']));}
            if($thread||$msgs||!$partial){return array('ok'=>true,'messages'=>$msgs,'cursor'=>$thread?$x['cursor']:'','parcial'=>$thread&&$partial,'principal'=>$root['id']);}
            if($x['cursor']===''||isset($seen[$x['cursor']])){break;}$seen[$x['cursor']]=true;$body['cursor']=$x['cursor'];
        }
        return self::erro('slack_consulta_incompleta');
    }
    private static function hash_remoto(array $m): string {return hash('sha256',wp_json_encode(array(self::texto_equivalente((string)($m['text']??'')),self::blocos($m['blocks']??array()))));}
    /** Canonicalize maps, not ordered lists. Preserve meaningful text and formatting. */
    private static function blocos(array $blocks): array {
        $list=array_is_list($blocks);$type=$blocks['type']??'';
        if(!$list){unset($blocks['block_id']);
            if($type==='mrkdwn'){unset($blocks['verbatim']);}
            if($type==='plain_text'){unset($blocks['emoji']);}
        }
        foreach($blocks as $k=>&$value){if(is_array($value)){$value=self::blocos($value);}elseif($k==='text'&&is_string($value)){$value=self::texto_equivalente($value);}}unset($value);
        if(!$list){ksort($blocks,SORT_STRING);}return $blocks;
    }
    private static function texto_equivalente(string $texto): string {
        // Only Slack's three escapes, once. &quot; and nested escapes remain literal.
        $texto=strtr($texto,array('&amp;'=>'&','&lt;'=>'<','&gt;'=>'>'));
        $texto=str_replace("\r\n","\n",$texto);
        $texto=preg_replace_callback('/<mailto:([^>|]+)(?:\|([^>]+))?>/i',static fn($m)=>!isset($m[2])||$m[2]===$m[1]?$m[1]:$m[0],$texto);
        return preg_replace_callback('/<(https?:[^>|]+)(?:\|([^>]+))?>/',static function($m){
            $url=$m[1];$label=$m[2]??$url;
            if($label===$url){return $url;}
            // Slack's auto-link of bare www retains its visible label.
            if(preg_match('/^www\./i',$label)&&preg_replace('~^https?://~i','',$url)===$label){return $label;}
            return $m[0];
        },$texto);
    }
    private static function equivalente(array $remota,array $local): bool {
        $a=self::blocos($remota['blocks']??array());$b=self::blocos($local['blocks']??array());
        // Com blocos dos dois lados, compare o conteúdo exibido. Slack pode reconstruir o fallback de notificação.
        if($a&&$b){return $a===$b;}
        if(self::texto_equivalente((string)($remota['text']??''))!==self::texto_equivalente((string)($local['text']??''))){return false;}
        if($a===$b){return true;}
        // Slack-generated rich_text is equivalent only for plain text/link sections.
        if($b||!$a){return false;}$partes=array();foreach($a as $bloco){if(($bloco['type']??'')!=='rich_text'){return false;}foreach($bloco['elements']??array() as $section){if(($section['type']??'')!=='rich_text_section'){return false;}$s='';foreach($section['elements']??array() as $e){if(!empty($e['style'])){return false;}if(($e['type']??'')==='text'){$s.=$e['text']??'';}elseif(($e['type']??'')==='link'){$s.=isset($e['text'])&&$e['text']!==$e['url']?'<'.$e['url'].'|'.$e['text'].'>':($e['url']??'');}else{return false;}}$partes[]=$s;}}
        return self::texto_equivalente(implode("\n",$partes))===self::texto_equivalente((string)($local['text']??''));
    }
    private static function propria(array $m,array $r): bool {return ($m['user']??'')===$r['user_id']&&(!isset($m['bot_id'])||$m['bot_id']===$r['bot_id'])&&(!isset($m['team'])||$m['team']===$r['team_id']);}
    public static function ler(array $e): array {
        if(!F3Base_Recuperacao::entrar()){return self::erro('core_em_recuperacao');}try{
            $a=self::alvo((string)($e['id']??''));if(empty($a['ok'])){return $a;}$r=$a['registro'];$thread=!empty($e['incluir_thread']);$cursor=(string)($e['cursor']??'');if(strlen($cursor)>2048||(!$thread&&$cursor!=='')){return self::erro('cursor_invalido');}$x=self::remota($r,$thread,$cursor);
            if(empty($x['ok'])){return $x+array('local'=>self::publico($r),'presenca'=>'nao_verificavel','orientacao'=>($x['codigo']??'')==='slack_missing_scope'?'Autorize channels:history ou groups:history no mesmo aplicativo. A entrega anterior permanece registrada.':'Consulta indisponível; não comprova ausência.');}
            $messages=array();foreach($x['messages'] as $m){$messages[]=array_intersect_key($m,array_flip(array('ts','thread_ts','user','bot_id','text','blocks','reply_count','edited')))+array('horario'=>wp_date('d/m/Y H:i:s',(int)$m['ts']),'propria'=>self::propria($m,$r),'revisao_remota'=>self::hash_remoto($m));}
            $found=array_values(array_filter($x['messages'],static fn($m)=>$m['ts']===$r['ts']));$local=F3Base_Contato_Comunicacao::abrir($r['payload'])['mensagem']??array();$presence=$found&&empty($local)?'confirmada':($found?(self::equivalente($found[0],$local)?'confirmada':'conteudo_divergente'):($thread?'fora_desta_pagina':'ausente'));
            return array('ok'=>true,'id'=>$r['id'],'local'=>self::publico($r),'aceito_pela_api'=>$r['ts']!=='','presenca'=>$presence,'estado_local_contradito'=>$r['estado']==='apagada'&&!empty($found),'conformidade'=>empty($local)?'conteudo_local_indisponivel':$presence,'verificado_em'=>time(),'leitura_humana'=>'não comprovada','mensagens'=>$messages,'cursor'=>$x['cursor'],'parcial'=>$x['parcial'],'cobertura'=>$thread?'Página da thread vinculada; completa somente após percorrer todos os cursores.':'Consulta exata da mensagem registrada.');
        }finally{F3Base_Recuperacao::sair();}
    }
    public static function verificar(array $e): array {
        $r=self::ler($e);if(empty($r['ok'])){return $r;}global $wpdb;$source=self::linha((string)$e['id']);$root=$source['principal']?:$source['id'];$rows=$wpdb->get_results($wpdb->prepare("SELECT id,ts,estado FROM %i WHERE id=%s OR principal=%s ORDER BY criado_em,id",self::tabela(),$root,$root),ARRAY_A)?:array();$seen=array_column($r['mensagens'],'ts');$r['partes_esperadas']=array_map(static fn($p)=>array('id'=>$p['id'],'ts'=>$p['ts'],'estado_local'=>$p['estado'],'presenca_nesta_consulta'=>in_array($p['ts'],$seen,true)?'encontrada':'nao_coberta'),$rows);return $r;
    }
    public static function limpo(string $record): bool {global $wpdb;return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM %i WHERE record_id=%s AND tipo='parte' AND teste=1 AND estado='apagada' AND ausencia_em>0 AND remocao_aceita_em>0 LIMIT 1",self::tabela(),$record));}

    private static function operacao(string $kind,array $e,callable $run): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}if(!F3Base_Recuperacao::entrar()){return self::erro('core_em_recuperacao');}$lock=null;try{
            $sim=($e['simular']??true)!==false;if($sim){return $run(true);}$key=(string)($e['chave_operacao']??'');if(!preg_match('/^[A-Za-z0-9._:-]{8,128}$/D',$key)){return self::erro('chave_operacao_obrigatoria');}$id=hash('sha256',$kind.'|'.self::site().'|'.$key);$hash=hash('sha256',wp_json_encode($e));$lock=F3Base_Trava::adquirir('slack-transporte',45);if(!$lock){return self::erro('slack_transporte_ocupado');}
            $old=self::linha($id);if($old){if($old['revisao']!==$hash){return self::erro('chave_operacao_reutilizada');}$saved=F3Base_Contato_Comunicacao::abrir($old['payload']);return ($saved['resultado']??self::erro('operacao_incerta_consulte_antes_de_repetir'))+array('repetida'=>true,'operacao_id'=>$id);}
            $r=array('id'=>$id,'tipo'=>'operacao','alvo'=>(string)($e['id']??''),'site'=>self::site(),'destino'=>F3Base_Slack::destino(),'estado'=>'iniciada','revisao'=>$hash,'criado_em'=>time(),'atualizado_em'=>time());$data=array('acao'=>$kind,'entrada'=>$e,'autor'=>get_current_user_id());if(!self::gravar($r,$data)){return self::erro('auditoria_previa_falhou');}
            $res=$run(false);$data['resultado']=$res;if(!self::mudar($r,array('estado'=>!empty($res['ok'])?'concluida':'interrompida'),$data)){return self::erro('resultado_incerto_nao_persistido',array('operacao_id'=>$id));}return $res+array('operacao_id'=>$id);
        }finally{if($lock){F3Base_Trava::liberar($lock);}F3Base_Recuperacao::sair();}
    }
    private static function mensagem(array $e,array $r): array {
        if(($e['modo']??'')==='substituir'){$text=$e['texto']??null;if(!is_string($text)||trim($text)===''||mb_strlen($text)>39000){return self::erro('texto_vazio_ou_excede_limite');}$blocks=array();foreach(mb_str_split($text,2800) as $s){$blocks[]=array('type'=>'section','text'=>array('type'=>'plain_text','text'=>$s));}$m=array('text'=>$text,'blocks'=>$blocks);}
        elseif(($e['modo']??'')==='regenerar'){
            if($r['tipo']!=='parte'){return self::erro('teste_sem_contato_para_regenerar');}global $wpdb;$p=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',F3Base_Slack::tabela(),$r['id']),ARRAY_A);$lead=F3Base_Leads_Repositorio::obter($r['record_id']);if(!$p||!$lead||$lead['lixeira']||$lead['eliminacao_pendente']){return self::erro('contato_indisponivel');}if((int)$p['sequencia']<0){return self::erro('resumo_compartilhado_use_substituir');}
            $a=F3Base_Contato_Apresentacao::montar($lead);$notice=F3Base_Avisos::linha($p['aviso']);$meta=$notice?F3Base_Avisos::abrir($notice['payload']):array();$shared=$p['principal']?self::linha($p['principal']):null;
            if($p['tipo']==='complemento'){$m=F3Base_Slack::simples('Atualização do contato',F3Base_Contato_Apresentacao::secoes($a),$a['registro_url']);}else{$summary=$shared?(int)$wpdb->get_var($wpdb->prepare('SELECT sequencia FROM %i WHERE chave=%s',F3Base_Slack::tabela(),$shared['id'])):0;$format=$shared&&$summary<0?'completo':($meta['formato']??'thread');$messages=F3Base_Slack::mensagens($a,$format);$m=$messages[(int)$p['sequencia']]??null;if(!$m){return self::erro('parte_sem_equivalente_use_substituir');}}
        }else{return self::erro('modo_invalido');}
        if(count($m['blocks']??array())>50||mb_strlen($m['text']??'')>39000){return self::erro('correcao_excede_uma_mensagem');}unset($m['channel'],$m['ts'],$m['thread_ts']);return array('ok'=>true,'mensagem'=>array('text'=>$m['text'],'blocks'=>$m['blocks']??array()));
    }
    public static function corrigir(array $e): array {return self::operacao('corrigir',$e,static function(bool $sim)use($e){
        $a=self::alvo((string)($e['id']??''));if(empty($a['ok'])){return $a;}$r=$a['registro'];if(!hash_equals($r['revisao'],(string)($e['revisao']??''))){return self::erro('revisao_divergente',array('revisao'=>$r['revisao']));}$m=self::mensagem($e,$r);if(empty($m['ok'])){return $m;}$old=F3Base_Contato_Comunicacao::abrir($r['payload']);
        if($sim){return array('ok'=>true,'simular'=>true,'id'=>$r['id'],'revisao'=>$r['revisao'],'antes'=>$old['mensagem']??array(),'depois'=>$m['mensagem'],'preserva_ts'=>$r['ts'],'principal'=>$r['principal']);}
        $remote=self::remota($r);if(!empty($remote['ok'])){if(!$remote['messages']){return self::erro('mensagem_ausente');}$msg=$remote['messages'][0];if(!self::propria($msg,$r)){return self::erro('mensagem_de_outro_autor');}if(!empty($e['revisao_remota'])&&!hash_equals(self::hash_remoto($msg),(string)$e['revisao_remota'])){return self::erro('revisao_remota_divergente');}if(!self::equivalente($msg,$old['mensagem']??array())&&empty($e['revisao_remota'])){return self::erro('conteudo_remoto_divergente',array('orientacao'=>'Consulte a mensagem e reconcilie a fonte antes de alterar.'));}}elseif(($remote['codigo']??'')!=='slack_missing_scope'){return $remote;}
        $res=F3Base_Slack::api('chat.update',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),array('channel'=>$r['canal'],'ts'=>$r['ts'],'text'=>$m['mensagem']['text'],'blocks'=>$m['mensagem']['blocks'],'parse'=>'none'));if(empty($res['ok'])){return $res;}
        $rev=hash('sha256',$r['revisao'].'|'.wp_json_encode($m['mensagem']).'|'.($e['chave_operacao']??''));$old['mensagem']=$m['mensagem'];$old['correcao']=array('em'=>time(),'autor'=>get_current_user_id(),'motivo'=>sanitize_textarea_field($e['motivo']??''));$ok=self::mudar($r,array('estado'=>'corrigida','revisao'=>$rev),$old);return array('ok'=>$ok,'codigo'=>$ok?'mensagem_corrigida':'resultado_incerto_nao_persistido','id'=>$r['id'],'ts'=>$r['ts'],'revisao'=>$rev,'anterior'=>$remote['messages'][0]??null,'depois'=>$m['mensagem']);
    });}
    private static function selecao(array $ids): array {if(!$ids||count($ids)>20||count(array_unique($ids))!==count($ids)){return self::erro('selecao_invalida');}$rows=array();foreach($ids as $id){$a=self::alvo((string)$id);if(empty($a['ok'])){return $a;}if(!(int)$a['registro']['teste']){return self::erro('mensagem_de_producao');}$rows[]=$a['registro'];}usort($rows,static fn($a,$b)=>((int)($b['principal']!==''))<=>((int)($a['principal']!=='')));$versions=array();foreach($rows as $r){$versions[$r['id']]=$r['revisao'].'|'.$r['estado'];}ksort($versions);return array('ok'=>true,'linhas'=>$rows,'revisao'=>hash('sha256',wp_json_encode($versions)));}
    private static function principal_livre(array $r): array {
        $cursor='';$seen=array();for($i=0;$i<20;$i++){$x=self::remota($r,true,$cursor);if(empty($x['ok'])){return array('ok'=>true,'thread_nao_verificada'=>$x['codigo']??'consulta_indisponivel');}foreach($x['messages'] as $m){if($m['ts']===$r['ts']){continue;}global $wpdb;$known=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE canal=%s AND ts=%s AND tipo IN ('parte','teste') LIMIT 1",self::tabela(),$r['canal'],$m['ts']),ARRAY_A);if(!$known||!(int)$known['teste']||$known['site']!==self::site()||!self::propria($m,$known)){return self::erro('principal_preservada_resposta_humana_ou_producao',array('resposta_restante'=>array('canal'=>$r['canal'],'ts'=>$m['ts'],'presenca'=>'observada')));}return self::erro('principal_preservada_resposta_ainda_presente',array('resposta_restante'=>array('canal'=>$r['canal'],'ts'=>$m['ts'],'presenca'=>'observada')));}
            if(!$x['parcial']){return array('ok'=>true);}$cursor=$x['cursor'];if($cursor===''||isset($seen[$cursor])){break;}$seen[$cursor]=true;
        }return self::erro('principal_preservada_thread_incompleta');
    }
    public static function apagar(array $e): array {return self::operacao('apagar',$e,static function(bool $sim)use($e){
        $s=self::selecao(is_array($e['ids']??null)?$e['ids']:array());if(empty($s['ok'])){return $s;}if($sim){return array('ok'=>true,'simular'=>true,'revisao'=>$s['revisao'],'alvos'=>array_map(array(__CLASS__,'publico'),$s['linhas']),'regra'=>'Respostas antes da principal. A principal própria pode ser apagada se a consulta da thread falhar; respostas não são apagadas em cascata e a cobertura fica explícita.');}if(!hash_equals($s['revisao'],(string)($e['revisao']??''))){return self::erro('selecao_alterada',array('revisao'=>$s['revisao']));}
        $results=array();$threads=array();foreach($s['linhas'] as $r){
            $base=array('id'=>$r['id'],'canal'=>$r['canal'],'principal'=>$r['principal'],'ts'=>$r['ts']);$remote=self::remota($r);
            if(empty($remote['ok'])){$results[]=$remote+$base+array('presenca'=>'nao_verificavel');continue;}
            $d=F3Base_Contato_Comunicacao::abrir($r['payload']);$accepted=(int)($r['remocao_aceita_em']??0);
            if(!$remote['messages']){
                $code=$accepted?'teste_apagado':'ausente_antes';$state=$accepted?'apagada':'ausente';
            }else{
                if(!self::propria($remote['messages'][0],$r)){$results[]=self::erro('autoria_divergente',$base+array('presenca'=>'confirmada'));continue;}
                if($accepted){$results[]=self::erro('confirmacao_pendente',$base+array('presenca'=>'confirmada','exclusao_aceita'=>true,'aceita_em'=>$accepted));continue;}
                if(!$r['principal']){$safe=self::principal_livre($r);if(!empty($safe['thread_nao_verificada'])){$threads[]=array('canal'=>$r['canal'],'ts'=>$r['ts'],'codigo'=>$safe['thread_nao_verificada']);}if(empty($safe['ok'])){$results[]=$safe+$base+array('presenca'=>'confirmada');continue;}}
                $res=F3Base_Slack::api('chat.delete',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),array('channel'=>$r['canal'],'ts'=>$r['ts']));
                if(empty($res['ok'])){$results[]=$res+$base+array('presenca'=>($res['codigo']??'')==='slack_resultado_incerto'?'nao_verificavel':'confirmada');if(($res['codigo']??'')==='slack_resultado_incerto'){break;}continue;}
                $accepted=time();$d['remocao']=array('versao'=>2,'aceita_em'=>$accepted,'autor'=>get_current_user_id(),'recibo'=>$res);
                if(!self::mudar($r,array('estado'=>'confirmacao_pendente','remocao_aceita_em'=>$accepted,'ausencia_em'=>0),$d)){$results[]=self::erro('resultado_incerto_nao_persistido',$base+array('presenca'=>'nao_verificavel','exclusao_aceita'=>true));break;}
                $remote=self::remota($r);
                if(empty($remote['ok'])||$remote['messages']){$results[]=self::erro('confirmacao_pendente',$base+array('presenca'=>empty($remote['ok'])?'nao_verificavel':'confirmada','exclusao_aceita'=>true,'aceita_em'=>$accepted,'consulta_codigo'=>$remote['codigo']??null));continue;}
                $code='teste_apagado';$state='apagada';
            }
            $at=time();$d['remocao']=array_merge($d['remocao']??array(),array('versao'=>2,'verificada_em'=>$at,'codigo'=>$code,'ausencia_confirmada'=>true));
            $ok=self::mudar($r,array('estado'=>$state,'ausencia_em'=>$at),$d);
            $results[]=$base+array('ok'=>$ok,'codigo'=>$ok?$code:'resultado_incerto_nao_persistido','presenca'=>'ausente','exclusao_aceita'=>$accepted>0,'aceita_em'=>$accepted?:null,'verificado_em'=>$at,'cobertura'=>'alvo_exato');
            if($ok&&$accepted&&$r['tipo']==='parte'){global $wpdb;$p=$wpdb->get_row($wpdb->prepare('SELECT aviso FROM %i WHERE chave=%s',F3Base_Slack::tabela(),$r['id']),ARRAY_A);if($p){$wpdb->query($wpdb->prepare("UPDATE %i SET estado='suprimido',codigo='teste_limpo',proxima=0 WHERE aviso=%s AND estado IN ('pendente','suspenso')",F3Base_Slack::tabela(),$p['aviso']));}}
        }
        $restantes=array();$unknown=array();$indexed=array_column($results,null,'id');foreach($s['linhas'] as $target){$r=$indexed[$target['id']]??array('presenca'=>'nao_verificavel');$ref=array('id'=>$target['id'],'canal'=>$target['canal'],'ts'=>$target['ts']);if(($r['presenca']??'nao_verificavel')==='nao_verificavel'){$unknown[]=$ref;}elseif(($r['presenca']??'')!=='ausente'){$restantes[]=$ref;}}
        $complete=count($results)===count($s['linhas'])&&!array_filter($results,static fn($x)=>empty($x['ok']));return array('ok'=>$complete,'parcial'=>!$complete,'codigo'=>$complete?'limpeza_concluida':'limpeza_parcial','resultados'=>$results,'alvos_restantes'=>$restantes,'alvos_nao_verificaveis'=>$unknown,'respostas_restantes_observadas'=>array_values(array_filter(array_column($results,'resposta_restante'))),'escopo_limpeza'=>'Somente alvos selecionados, com releitura individual após o aceite de exclusão.','threads_nao_verificadas'=>$threads,'cobertura_threads'=>$threads?'incompleta':'verificada_para_as_principais_consultadas','entrega_historica_preservada'=>true,'contatos_eliminados'=>0);
    });}
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static function(){
            $read=array('id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'incluir_thread'=>array('type'=>'boolean'),'cursor'=>array('type'=>'string','maxLength'=>2048));foreach(array('ler','verificar') as $action){F3Base_Servicos::ability('avisos-slack-'.$action,'Consultar presença ou thread de aviso registrado; não comprova leitura humana',array(__CLASS__,$action),$read,array('id'));}
            $write=array('simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string'),'chave_operacao'=>array('type'=>'string','maxLength'=>128),'motivo'=>array('type'=>'string','maxLength'=>500));F3Base_Servicos::ability('avisos-slack-corrigir','Corrigir parte própria registrada, conservando timestamp e thread',array(__CLASS__,'corrigir'),$write+array('id'=>$read['id'],'modo'=>array('type'=>'string','enum'=>array('regenerar','substituir')),'texto'=>array('type'=>'string','maxLength'=>39000),'revisao_remota'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$')),array('id','modo','revisao'),false);
            self::registrar_gestao();
        });
        add_action('admin_post_f3base_slack_manutencao',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão');}check_admin_referer('f3base-slack-manutencao');$e=array('id'=>sanitize_key($_POST['id']??''),'revisao'=>sanitize_text_field($_POST['revisao']??''),'simular'=>!empty($_POST['simular']),'chave_operacao'=>sanitize_text_field($_POST['chave_operacao']??''),'modo'=>sanitize_key($_POST['modo']??'substituir'),'revisao_remota'=>sanitize_text_field($_POST['revisao_remota']??''),'texto'=>sanitize_textarea_field(wp_unslash($_POST['texto']??'')),'motivo'=>sanitize_textarea_field(wp_unslash($_POST['motivo']??'')),'cursor'=>sanitize_text_field($_POST['cursor']??''));$action=sanitize_key($_POST['operacao']??'ler');if($action==='thread'){$e['incluir_thread']=true;$action='ler';}if($action==='apagar'){$e['ids']=array($e['id']);unset($e['id']);}$r=in_array($action,array('ler','verificar','corrigir','apagar'),true)?self::$action($e):self::erro('acao_invalida');echo '<div class="wrap"><h1>Resultado da manutenção do aviso</h1><pre style="white-space:pre-wrap">'.esc_html(wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'</pre><p><a href="'.esc_url(admin_url('admin.php?page=base-site-core-fator3&secao=conexoes&integracao=avisos')).'">Voltar aos avisos</a></p></div>';});
        add_action(F3Base_Leads_Notificacoes::EVENTO,static function(){global $wpdb;$wpdb->query($wpdb->prepare("UPDATE %i SET payload='' WHERE estado NOT IN ('preparado','incerto','iniciada') AND atualizado_em<%d AND payload<>''",self::tabela(),F3Base_Retencao_Prazos::tecnico('avisos')));});
    }
    public static function eliminar(string $id): void {global $wpdb;$ids=$wpdb->get_col($wpdb->prepare("SELECT id FROM %i WHERE record_id=%s AND tipo='parte'",self::tabela(),$id));foreach($ids as $target){$wpdb->query($wpdb->prepare("UPDATE %i SET payload='',estado=IF(estado='apagada','apagada','eliminado') WHERE id=%s OR alvo=%s",self::tabela(),$target,$target));}}
    public static function controles(string $id): void {
        $r=self::linha($id);if(!$r){echo '<p>Manutenção indisponível: emissão anterior sem prova de autoria registrada.</p>';return;}$p=self::publico($r);echo '<p>Entrega: '.esc_html($r['estado']).' · '.esc_html($p['criado_legivel']).'. Presença remota e leitura humana são verificações distintas.</p>';if(!$p['manutencao_disponivel']){return;}
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_slack_manutencao"><input type="hidden" name="id" value="'.esc_attr($id).'"><input type="hidden" name="revisao" value="'.esc_attr($r['revisao']).'"><input type="hidden" name="chave_operacao" value="'.esc_attr(wp_generate_uuid4()).'">';wp_nonce_field('f3base-slack-manutencao');echo '<button class="button" name="operacao" value="verificar">Conferir no Slack</button> <button class="button" name="operacao" value="thread">Ver thread</button><label> Cursor da próxima página <input name="cursor"></label><details><summary>Corrigir mensagem</summary><label>Modo <select name="modo"><option value="substituir">Substituir esta parte</option><option value="regenerar">Regenerar pelo contato</option></select></label><p><textarea name="texto" rows="8" cols="80" placeholder="Texto legível, com quebras de linha"></textarea></p><label>Motivo <input name="motivo"></label><label> Revisão remota conferida (opcional) <input name="revisao_remota"></label><label><input type="checkbox" name="simular" value="1" checked> Mostrar prévia</label> <button class="button" name="operacao" value="corrigir">Aplicar correção</button></details></form>';
        if((int)$r['teste']){$s=array('ok'=>true,'revisao'=>hash('sha256',wp_json_encode(array($id=>$r['revisao'].'|'.$r['estado']))));if(!empty($s['ok'])){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_slack_manutencao"><input type="hidden" name="id" value="'.esc_attr($id).'"><input type="hidden" name="revisao" value="'.esc_attr($s['revisao']).'"><input type="hidden" name="chave_operacao" value="'.esc_attr(wp_generate_uuid4()).'">';wp_nonce_field('f3base-slack-manutencao');echo '<label><input type="checkbox" name="simular" value="1" checked> Mostrar prévia da limpeza</label> <button class="button" name="operacao" value="apagar">Apagar teste</button></form>';}}
    }
    public static function tela(): void {echo '<details><summary>Testes e capacidades de manutenção do Slack</summary><p>Usa o mesmo bot e canal. Ler exige channels:history (público) ou groups:history (privado); editar e apagar mensagens próprias usa chat:write. Ausência de escopo aparece no resultado da consulta. Webhooks não permitem manutenção remota. Não há consultas automáticas ao abrir esta tela.</p>';foreach(self::listar(array('origem'=>'teste_conexao'))['linhas'] as $r){echo '<details><summary>'.esc_html($r['criado_legivel'].' · '.$r['estado']).'</summary>';self::controles($r['id']);echo '</details>';}echo '</details>';}
}
