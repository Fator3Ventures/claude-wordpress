<?php
/** Eliminação remota limitada à autoria e exclusividade comprovadas em nova leitura. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Eliminacao {
 public static function iniciar(): void {add_action(F3Base_Pipedrive_Fila::EVENTO,array(__CLASS__,'processar'),20);}
 public static function prova(string $step,array $data): array {
  $keys=array('pessoa'=>array('id','name','emails','phones','owner_id','org_id','label_ids','custom_fields','add_time'),'lead'=>array('id','title','person_id','organization_id','owner_id','origin_id','label_ids','add_time','is_archived','was_seen','value','currency','expected_close_date','visible_to','custom_fields','source_name'),'organizacao'=>array('id','name','owner_id','address','label_ids','visible_to','custom_fields','add_time'),'nota'=>array('id','content','person_id','lead_id','deal_id','add_time','update_time'),'atividade'=>array('id','subject','type','person_id','lead_id','deal_id','owner_id','note','done','due_date','add_time','update_time'))[$step]??array('id','name','add_time','update_time');
  $v=array_replace(array_fill_keys($keys,null),array_intersect_key($data,array_flip($keys)));foreach($data as $k=>$value){if(preg_match('/^[a-f0-9]{40}$/D',(string)$k)){$v[$k]=$value;}}
  return array('versao'=>3,'campos_hash'=>array_map(static fn($x)=>hash_hmac('sha256',wp_json_encode(F3Base_Auditoria::ordenar(is_array($x)?$x:array('valor'=>$x))),wp_salt('auth')),$v),'hash'=>F3Base_Leads_Repositorio::hash($v),'campos'=>array_keys($v),'em'=>time());
 }
 public static function igual(string $step,array $data,array $proof): bool {
  if(empty($proof['hash'])||empty($proof['campos'])||(in_array($step,array('pessoa','lead','organizacao'),true)&&!in_array($proof['versao']??1,array(2,3),true))){return false;}$selected=array_replace(array_fill_keys($proof['campos'],null),array_intersect_key($data,array_flip($proof['campos'])));
  foreach($data as $k=>$v){if((preg_match('/^[a-f0-9]{40}$/D',(string)$k)||$k==='custom_fields')&&!in_array($k,$proof['campos'],true)&&!empty($v)){return false;}}
  return count($selected)===count($proof['campos'])&&hash_equals($proof['hash'],F3Base_Leads_Repositorio::hash($selected));
 }
 public static function divergencias(string $step,array $data,array $proof): array {
  if(self::igual($step,$data,$proof)){return array();}$out=array();
  foreach($proof['campos_hash']??array() as $key=>$hash){$v=$data[$key]??null;$actual=hash_hmac('sha256',wp_json_encode(F3Base_Auditoria::ordenar(is_array($v)?$v:array('valor'=>$v))),wp_salt('auth'));if(!hash_equals((string)$hash,$actual)){$out[]=$key;}}
  foreach($data as $key=>$v){if((preg_match('/^[a-f0-9]{40}$/D',(string)$key)||$key==='custom_fields')&&!in_array($key,$proof['campos']??array(),true)&&!empty($v)){$out[]=$key;}}
  return $out?:array('prova_de_criacao_ausente_antiga_ou_divergente');
 }
 public static function conferir_objeto(string $step,array $data,array $proof,array $counts,array $state): array {
  $d=array('campos_divergentes'=>self::divergencias($step,$data,$proof),'contagens'=>array(),'seguidores'=>array());
  foreach($counts as $key){if(!array_key_exists($key,$data)||!is_numeric($data[$key])||(int)$data[$key]<0){$d['contagens'][$key]='ausente_ou_invalida';}elseif($key!=='followers_count'&&(int)$data[$key]!==0){$d['contagens'][$key]=(int)$data[$key];}}
  $n=(int)($data['followers_count']??-1);
  if($n>0){
   $path=$step==='pessoa'?'v2/persons/':'v2/organizations/';$r=F3Base_Pipedrive_Api::listar($path.(int)$data['id'].'/followers');
   if(empty($r['ok'])||count($r['data']??array())!==$n){$d['contagens']['followers_count']='cobertura_incompleta';$d['pendente']=empty($r['ok'])&&(!empty($r['pausa'])||!empty($r['temporario']));}
   else{$allowed=array_filter(array((int)($data['owner_id']??0),(int)($state['usuario_id']??0)));$foreign=0;foreach($r['data'] as $f){if(!isset($f['user_id'])||!in_array((int)$f['user_id'],$allowed,true)){++$foreign;}}$d['seguidores']=array('observados'=>$n,'automaticos_permitidos'=>$n-$foreign,'outros'=>$foreign);if($foreign){$d['contagens']['followers_count']=$foreign;}}
  }
  $d['ok']=!$d['campos_divergentes']&&!$d['contagens'];return $d;
 }
 /** IDs/types only: no subject, note, address or message content in the erasure journal. */
 public static function restantes(array $notes,array $activities): array {
  $out=array();foreach(array('nota'=>$notes,'atividade'=>$activities) as $type=>$items){foreach($items as $item){if(isset($item['id'])){$out[]=array('tipo'=>$type,'id'=>(int)$item['id']);}}}return $out;
 }
 private static function email_proprio(array $row,array &$j,array &$clean,bool &$pending,bool &$review): void {
  global $wpdb;$emails=$wpdb->get_results($wpdb->prepare('SELECT atividade_id,atividade_prova,atividade_estado,enviado_em FROM %i WHERE record_id=%s AND conta=%s AND lead_id=%s',F3Base_Email_Novo_Lead::tabela(),$row['record_id'],$row['conta'],$j['criados']['lead']??''),ARRAY_A);
  if($wpdb->last_error){$pending=true;return;}
  foreach($emails as $email){
   if((int)$email['enviado_em']>0){$clean['copias_externas']['email_smart_bcc']=array('tipo'=>'email','estado'=>'copia_externa_restante','motivo'=>'sem_id_da_mensagem_e_sem_rota_de_exclusao_individual_segura','lead_id'=>$j['criados']['lead']??'','enviado_em'=>(int)$email['enviado_em']);}
   $id=(int)$email['atividade_id'];if(!$id){if($email['atividade_estado']==='incerta'){$review=true;$clean['motivos'][]='atividade_email_sem_confirmacao';}continue;}
   $key='atividade_email_'.$id;$proof=json_decode($email['atividade_prova']??'',true)?:array();$j['criados'][$key]=$id;$j['provas_criacao'][$key]=$proof;
   if(in_array($key,$clean['removidos']??array(),true)){continue;}
   $r=F3Base_Pipedrive_Api::pedir('GET','v2/activities/'.$id);
   if(($r['http']??0)===404){$clean['removidos'][]=$key;continue;}if(empty($r['ok'])){$pending=true;continue;}
   if(($r['data']['lead_id']??'')!==($j['criados']['lead']??'')||!self::igual('atividade',$r['data'],$proof)){$review=true;$clean['motivos'][]='atividade_email_alterada_ou_sem_prova';$clean['diagnostico'][$key]=array('id'=>$id,'tipo'=>'atividade','campos_divergentes'=>self::divergencias('atividade',$r['data'],$proof));continue;}
   $r=self::apagar('v2/activities/'.$id);if(!empty($r['ok'])){$clean['removidos'][]=$key;}else{$pending=true;}
  }
 }
 private static function apagar(string $path): array {$r=F3Base_Pipedrive_Api::pedir('DELETE',$path);return !empty($r['ok'])||($r['http']??0)===404?array('ok'=>true):$r;}
 public static function processar(): array {
  global $wpdb;F3Base_Pipedrive_Api::iniciar_lote();$cfg=F3Base_Pipedrive_Api::configuracao_lote();$state=(array)F3Base_Options::fotografia_bruta('f3base_pipedrive_estado')['valor'];if(empty($cfg['ativo'])||!F3Base_Pipedrive_Api::lote_atual()||!F3Base_Integracoes::pipedrive_verificado($state)){return array('ok'=>true,'codigo'=>'aguarda_integracao');}
  $account=$state['dominio'].'|'.$state['conta_id'].'|'.$state['instalacao'];$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE (lease='' OR lease_ate<=UNIX_TIMESTAMP()) AND codigo='eliminacao_remota_pendente' AND estado NOT IN ('enviando','cancelando') ORDER BY atualizado_em LIMIT 3",F3Base_Pipedrive_Fila::tabela()),ARRAY_A);$n=0;
  foreach($rows as $row){if(!F3Base_Pipedrive_Fila::travar_linha($row['chave'])){continue;}try{if($row['conta']!==$account){continue;}$j=json_decode($row['journal'],true)?:array();$clean=$j['eliminacao_remota']??array();$marker='f3base:'.$row['chave'];$pending=false;$review=false;$clean['motivos']=array();$clean['historico_restante']=array();
   self::email_proprio($row,$j,$clean,$pending,$review);
   foreach(array('nota'=>'v1/notes','atividade'=>'v2/activities') as $step=>$path){$id=$j['criados'][$step]??null;if(!$id){if($row['etapa']===$step){$review=true;$clean['motivos'][]=$step.'_sem_confirmacao';}continue;}if(in_array($step,$clean['removidos']??array(),true)){continue;}$r=F3Base_Pipedrive_Api::pedir('GET',$path.'/'.(int)$id);if(($r['http']??0)===404){$clean['removidos'][]=$step;continue;}if(empty($r['ok'])){$pending=true;continue;}$data=$r['data'];$text=$step==='nota'?($data['content']??''):($data['note']??'');
    if((empty($j['vinculos_privados'])&&!str_contains(wp_strip_all_tags($text),$marker.':'.$step))||!self::igual($step,$data,$j['provas_criacao'][$step]??array())){$review=true;$clean['motivos'][]=$step.'_alterada_ou_sem_prova';$clean['diagnostico'][$step]=array('campos_divergentes'=>self::divergencias($step,$data,$j['provas_criacao'][$step]??array()));continue;}
    $r=self::apagar($path.'/'.(int)$id);if(!empty($r['ok'])){$clean['removidos'][]=$step;}else{$pending=true;}
   }
   if($review&&!empty($j['criados']['lead'])){$notes=F3Base_Pipedrive_Api::listar('v1/notes',array('lead_id'=>$j['criados']['lead']));$acts=F3Base_Pipedrive_Api::listar('v2/activities',array('lead_id'=>$j['criados']['lead']));if(!empty($notes['ok'])&&!empty($acts['ok'])){$clean['historico_restante']=self::restantes($notes['data'],$acts['data']);}else{$clean['historico_cobertura']='leitura_pendente';$pending=true;}}
   $person=(int)($j['pessoa']??0);$ownlead=$j['criados']['lead']??'';$leadremoved=in_array('lead',$clean['removidos']??array(),true);
   if(!$pending&&!$review&&$ownlead&&!$leadremoved){
    $shared=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE chave<>%s AND conta=%s AND JSON_UNQUOTE(JSON_EXTRACT(journal,'$.oportunidade.id'))=%s",F3Base_Pipedrive_Fila::tabela(),$row['chave'],$account,$ownlead));if($wpdb->last_error||$shared){$review=true;$clean['motivos'][]='lead_com_outros_contatos_locais';}
   }
   if(!$pending&&!$review&&$ownlead&&!$leadremoved){
    $r=F3Base_Pipedrive_Api::pedir('GET','v1/leads/'.$ownlead);
    if(($r['http']??0)===404){$review=true;$clean['motivos'][]='lead_ausente_ou_convertido';}
    elseif(empty($r['ok'])){$pending=true;}
    elseif(($r['data']['origin_id']??'')!==$marker||!self::igual('lead',$r['data'],$j['provas_criacao']['lead']??array())||!empty($r['data']['is_archived'])||!empty($r['data']['was_seen'])){$review=true;$clean['motivos'][]='lead_alterado_ou_compartilhado';$clean['diagnostico']['lead']=array('campos_divergentes'=>self::divergencias('lead',$r['data'],$j['provas_criacao']['lead']??array()));}
    else {
     $notes=F3Base_Pipedrive_Api::listar('v1/notes',array('lead_id'=>$ownlead));$acts=F3Base_Pipedrive_Api::listar('v2/activities',array('lead_id'=>$ownlead));
     if(empty($notes['ok'])||empty($acts['ok'])){$pending=true;}
     elseif($notes['data']||$acts['data']){$clean['historico_restante']=self::restantes($notes['data'],$acts['data']);$review=true;$clean['motivos'][]='lead_com_historico_independente';}
     else{$r=self::apagar('v1/leads/'.$ownlead);if(!empty($r['ok'])){$clean['removidos'][]='lead';$leadremoved=true;}else{$pending=true;}}
    }
   }
   if(!$pending&&!$review&&$person&&!empty($j['criados']['pessoa'])&&(!$ownlead||$leadremoved)&&!in_array('pessoa',$clean['removidos']??array(),true)){
    $counts=array('open_deals_count','related_open_deals_count','closed_deals_count','related_closed_deals_count','participant_open_deals_count','participant_closed_deals_count','email_messages_count','activities_count','files_count','notes_count','followers_count');
    $r=F3Base_Pipedrive_Api::pedir('GET','v2/persons/'.$person,array('include_fields'=>implode(',',$counts)));
    if(($r['http']??0)===404){$clean['removidos'][]='pessoa';}
    elseif(empty($r['ok'])){$pending=true;}
    elseif(empty(($clean['diagnostico']['pessoa']=self::conferir_objeto('pessoa',$r['data'],$j['provas_criacao']['pessoa']??array(),$counts,$state))['ok'])){if(!empty($clean['diagnostico']['pessoa']['pendente'])){$pending=true;}else{$review=true;}$clean['motivos'][]='pessoa_alterada_compartilhada_ou_cobertura_incompleta';}
    else{$links=F3Base_Pipedrive_Api::listar('v1/leads',array('person_id'=>$person));if(empty($links['ok'])){$pending=true;}elseif($links['data']){$review=true;$clean['motivos'][]='pessoa_com_outro_lead';}else{$r=self::apagar('v2/persons/'.$person);if(!empty($r['ok'])){$clean['removidos'][]='pessoa';}else{$pending=true;}}}
   }
   $org=(int)($j['organizacao']??0);
   if(!$pending&&!$review&&$org&&!empty($j['criados']['organizacao'])&&!in_array('organizacao',$clean['removidos']??array(),true)){
    $counts=array('people_count','open_deals_count','related_open_deals_count','closed_deals_count','related_closed_deals_count','email_messages_count','activities_count','files_count','notes_count','followers_count');
    $r=F3Base_Pipedrive_Api::pedir('GET','v2/organizations/'.$org,array('include_fields'=>implode(',',$counts)));
    if(($r['http']??0)===404){$clean['removidos'][]='organizacao';}
    elseif(empty($r['ok'])){$pending=true;$clean['motivos'][]='organizacao_leitura_pendente';}
    elseif(empty(($clean['diagnostico']['organizacao']=self::conferir_objeto('organizacao',$r['data'],$j['provas_criacao']['organizacao']??array(),$counts,$state))['ok'])){if(!empty($clean['diagnostico']['organizacao']['pendente'])){$pending=true;}else{$review=true;}$clean['motivos'][]='organizacao_alterada_compartilhada_ou_cobertura_incompleta';}
    else{$links=F3Base_Pipedrive_Api::listar('v1/leads',array('organization_id'=>$org));if(empty($links['ok'])){$pending=true;$clean['motivos'][]='organizacao_leads_leitura_pendente';}elseif($links['data']){$review=true;$clean['motivos'][]='organizacao_com_outro_lead';}else{$r=self::apagar('v2/organizations/'.$org);if(!empty($r['ok'])){$clean['removidos'][]='organizacao';}else{$pending=true;$clean['motivos'][]='organizacao_exclusao_pendente';}}}
   }
   foreach(array('pessoa'=>$person,'lead'=>!empty($j['oportunidade']),'organizacao'=>$org) as $object=>$exists){if($exists&&!in_array($object,$clean['removidos']??array(),true)){$review=true;if(!array_filter($clean['motivos'],static fn($m)=>str_starts_with($m,$object.'_'))){$clean['motivos'][]=$object.(empty($j['criados'][$object])?'_preexistente_sem_autoria':'_mantido_por_dependencia');}}}
   if($row['etapa']){$review=true;$clean['motivos'][]=$row['etapa'].'_operacao_sem_confirmacao';}
   $clean['estado']=$pending?'pendente':($review?'revisao_comercial_necessaria':'concluida');$clean['verificada_em']=time();$clean['motivos']=array_values(array_unique($clean['motivos']));$j['eliminacao_remota']=$clean;
   $wpdb->update(F3Base_Pipedrive_Fila::tabela(),array('journal'=>wp_json_encode($j),'codigo'=>$pending?'eliminacao_remota_pendente':($review?'eliminacao_requer_revisao':'eliminacao_remota_concluida'),'atualizado_em'=>time()),array('chave'=>$row['chave'],'atualizado_em'=>$row['atualizado_em'],'lease'=>$row['lease']));++$n;
  }finally{F3Base_Pipedrive_Fila::liberar_linha($row['chave']);}}return array('ok'=>true,'processados'=>$n);
 }
}
