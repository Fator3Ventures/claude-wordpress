# Mudanças vigentes — 1.52.1

- 296: adaptador de e-mail com dados fixos removido; guarda de migração anterior; limpeza explícita com prévia/revisão; CF7 sem chamador e inferência Elementor removidos; documentação substituída fora do instalador.
- 297: orçamento incremental do catálogo, modo por caminho e diagnóstico/nova tentativa.
- 298: histerese de captação, incidentes com abertura/encerramento condicionados, prioridade das capturas e entregas no executor.

Base direta 1.51.0, contrato 8.17.0. Histórico completo de releases anteriores no fonte, em history/. Contratos atuais, mudanças e limites em RELEASE-1.52.1.md; não considerar histórico como instrução operacional.
