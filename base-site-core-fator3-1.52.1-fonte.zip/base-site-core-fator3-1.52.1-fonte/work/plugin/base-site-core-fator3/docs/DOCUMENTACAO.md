# Documentação vigente — Core 1.52.1

Contrato administrativo 8.17.0. Conteúdo instalado, com leitura administrativa pelo f3base/documentacao-ler. Pedidos 296, 297 e 298 em RELEASE-1.52.1.md. Versões substituídas permanecem somente no fonte em history/.

| Necessidade | Documento |
|---|---|
| Especificação e uso | INSTRUCOES-DO-PLUGIN.md, README.md, LEADS-E-FORMULARIOS.md |
| Configuração e descrições por campo | CONFIGURACAO.md, AJUDA-OPCOES.md, dados/configuracao-schema.json |
| Contratos/schemas | CONTRACTS.md, dados/abilities-*.json, schemas/*.json |
| Agentes e release | AGENTES-1.52.1.md, RELEASE-1.52.1.md |
| Operação/recuperação | OPERACAO-E-RECUPERACAO.md, CRON-DIAGNOSTICO-1.31.md |
| Credenciais | CREDENCIAIS-1.51.md |
| Pipedrive | PIPEDRIVE.md, PIPEDRIVE-1.37.md, PIPEDRIVE-OPERACAO.md, ORCAMENTO-PIPEDRIVE.md |
| Meta e LinkedIn | META-ACESSO-1.28.md, META-TRANSPORTE-1.19.md, LINKEDIN-LEAD-SYNC.md |
| Dados, retenção e consentimento | DICIONARIO-DADOS.md, RETENCAO-1.45.md, FORMULARIOS-TENTATIVAS-1.44.md |
| Provas e limitações | VALIDACAO.md e relatório externo da entrega |

O índice retornado pela ability contém a lista exata disponível, inclusive demais guias de domínio vigentes. Nomes versionados de domínio indicam origem do contrato, não uma instalação anterior. Leia todas as páginas (arquivo, linha, limite até 200, proxima_linha); confira hash e versão. Help estático não testa API, não grava opções e não repara cron.
