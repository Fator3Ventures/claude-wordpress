# Validação — Core 1.52.1

Consulte o relatório externo canônico para as provas executadas e os limites. O fonte contém testes e evidências sanitizadas em evidence/1520; evidence de rodadas anteriores é histórica. O instalador não distribui harnesses de laboratório.

Distinguir lint/build, teste nativo com WordPress/banco, HTTP de fornecedor simulado, MCP remoto no Site-Teste e fornecedor real. Renderização DOM não comprova layout em navegador; wp_mail aceito não comprova recebimento. Sete dias de operação na frota não são simulados por repetição local.

Pedidos 296–298 exigem: ausência de dados fixos, atualização com migração concluída e bloqueio sem ela; limpeza simulada/aplicada com divergência e autorização; catálogo acima de 128 MiB de processo, fallback e retomada; alarmes por limiar/incidente e supressão; execução prioritária e tempos por passagem. Instalação limpa e atualização direta 1.51.0 são cenários distintos. Conferir versão, SHA-256 e conteúdo da documentação após a troca.

Testes não autorizam mensagens, publicação, gasto de anúncio ou escrita em CRM real. Use dados sintéticos e bloqueie saídas em laboratório. Limpe somente recursos da própria rodada; backups normais permanecem.
