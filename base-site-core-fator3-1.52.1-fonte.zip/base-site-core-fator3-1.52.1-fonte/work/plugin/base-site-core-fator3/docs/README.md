# Fator3 Site Core 1.52.1

Núcleo do site: medição e consentimento, conteúdo/SEO técnico, formulários e contatos, origem da visita, captação nativa e entregas comerciais opcionais. Não exige os plugins acompanhantes para suas funções locais. Abra Site Core no painel; configuração de conexões exige administrador.

Comece em DOCUMENTACAO.md e AGENTES-1.52.1.md. RELEASE-1.52.1.md descreve pedidos 296–298, limpeza do e-mail antigo, memória do catálogo e prioridade operacional. AJUDA-OPCOES.md e dados/configuracao-schema.json são gerados do registro corrente. Contrato administrativo 8.17.0; cliente Pipedrive pipedrive-api-client/1.0.0.

Atualização direta suportada da 1.51.0 com migração de e-mail concluída; instalação nova sem resíduos. Defaults não habilitam fornecedores nem operação Pipedrive. Configurações, cifra de credenciais, filas e dados existentes são preservados. Remoção de resíduos exige simulação e aplicação explícita da ability administrativa.

Não use o ZIP fonte como instalador. Não coloque tokens ou dados reais em evidências. Desativação interrompe hooks do Core e preserva dados; exclusão de dados usa fluxos explícitos do Core. Consulte OPERACAO-E-RECUPERACAO.md antes de restaurar arquivos/banco.
