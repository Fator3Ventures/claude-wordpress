# Manifesto 1.12.0

Plugin 1.12.0; contrato 1.7.0; schema de leads 2. Consulte `fontes/plugin/DOCUMENTACAO.md` e o manifesto JSON gerado junto do instalador.
