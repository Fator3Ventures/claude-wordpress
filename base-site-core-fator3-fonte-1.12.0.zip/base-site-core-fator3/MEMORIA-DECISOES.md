# Decisões da 1.12.0

- Ignorar o trecho “apagar por padrão”.
- Documentação acompanha o plugin instalado.
- Importador CF7/Flamingo restrito à versão excepcional 1.11.0; reparar apenas o acervo já no Core.
- CRM/webhook em versão posterior; resposta ao visitante opt-in por formulário.
- Teto ausente/zero de anexo significa sem teto do pacote.

Contexto anterior preservado em `docs/historico-ate-1110/`.
