# Base Site Core Fator3 1.12.0

Plugin WordPress para configuração operacional, contatos e formulários próprios, consentimento, medição, publicação, cache e diagnósticos do Método F3.

Leia primeiro [DOCUMENTACAO.md](DOCUMENTACAO.md). A documentação fica instalada junto com o código.

## Instalação e atualização

Faça backup do banco, do plugin anterior e do diretório privado antes de atualizar. Envie `base-site-core-fator3-1.12.0.zip` pela tela Plugins do WordPress e substitua a versão instalada. Verifique a versão em F3 Base e consulte os diagnósticos após a ativação.

Requisitos declarados: WordPress 6.4 ou posterior, PHP 8.1 ou posterior, PHP de 64 bits e instalação individual. Ativação em rede/multisite é recusada. O canal de abilities exige WordPress com Abilities API disponível (6.9 ou posterior). Receber arquivos exige a extensão PHP fileinfo e permissões no diretório privado. Os requisitos mínimos declarados não equivalem à matriz de ambientes testados nesta entrega; veja VALIDACAO.md.

A primeira execução da 1.12.0 habilita a gestão da política pelo canal e a lista explícita de todas as opções operáveis presentes no catálogo. Esse ajuste ocorre uma vez por site, com fotografia anterior e revisão. Restrições feitas depois são respeitadas. O canal continua autenticado e sujeito às permissões de administrador.

O plugin cria e testa a pasta privada durante ativação/atualização. Se o servidor impedir a criação ou o caminho cair dentro de uma raiz pública conhecida, os anexos ficam indisponíveis e o diagnóstico explica o impedimento. Configure um caminho externo permitido e use a operação de preparação documentada.

Não há nova política de apagar por padrão. Os mecanismos de retenção e eliminação explícita já existentes continuam sujeitos às configurações do site. A atualização não elimina acervo nem arquivos.

## Limites desta entrega

CRM e webhook ficam para versão posterior. Resposta automática ao visitante é opcional por formulário, desligada por padrão. A migração excepcional da 1.11.0 não é reaberta. Sites ainda dependentes da ponte legada precisam concluir a transição antes de adotar este pacote.

Não há atualização automática remota (`Update URI: false`). Esta entrega foi validada em bancada local; implantação, SMTP, GA4, PageSpeed e infraestrutura da frota têm verificação própria.
