/*! Base Site Core — formulários próprios. GPL-2.0-or-later. */
(function () {
    'use strict';
    var estados = new WeakMap();
    function estado(f) { var s=estados.get(f); if(!s){s={iniciado:false,enviando:false,token:null};estados.set(f,s);} return s; }
    function id() { var a=new Uint8Array(16); window.crypto.getRandomValues(a); return Array.prototype.map.call(a,function(x){return ('0'+x.toString(16)).slice(-2);}).join(''); }
    function evento(f,n,d) { f.dispatchEvent(new CustomEvent('f3base-formulario-'+n,{bubbles:true,detail:d})); }
    function token(f) {
        var s=estado(f); if(s.token){return s.token;}
        if(!f.elements.submissao.value){ f.elements.submissao.value=id(); }
        s.token=fetch(f.dataset.endpoint+'token',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({formulario:f.dataset.f3baseFormulario,pagina:Number(f.dataset.pagina),submissao:f.elements.submissao.value})}).then(function(r){return r.json();}).then(function(r){if(!r.ok){throw new Error(r.codigo||'Token indisponível');}f.elements.token.value=r.token;return r;}).catch(function(e){s.token=null;throw e;});
        return s.token;
    }
    document.addEventListener('input',function(e){var f=e.target.closest&&e.target.closest('[data-f3base-formulario]');if(!f){return;}var s=estado(f);if(!s.iniciado){s.iniciado=true;evento(f,'inicio',{formulario:f.dataset.f3baseFormulario});token(f).catch(function(){});}});
    document.addEventListener('submit',function(e){
        var f=e.target;if(!f.matches('[data-f3base-formulario]')){return;} e.preventDefault();var s=estado(f);if(s.enviando){return;}if(!f.reportValidity()){return;}
        s.enviando=true;var b=f.querySelector('[type="submit"]'),out=f.querySelector('.f3base-formulario-resultado');b.disabled=true;out.textContent='Enviando…';
        token(f).then(function(){var d=new FormData(f);d.delete('action');var sessao=window.f3baseTracking&&window.f3baseTracking.sessao?window.f3baseTracking.sessao():null;if(sessao){d.set('sessao',sessao);}return fetch(f.dataset.endpoint+'enviar',{method:'POST',credentials:'same-origin',body:d});}).then(function(res){if(res.status===413){throw new Error('O envio excedeu o limite total do servidor.');}return res.json();}).then(function(r){
            if(!r.ok){if(r.codigo==='token_ou_revisao_invalida'){s.token=null;}throw new Error(r.mensagem||r.codigo||'Não foi possível receber o envio.');}
            out.textContent=r.mensagem||'Contato registrado.';
            if(r.url){var a=document.createElement('a');a.href=r.url;a.textContent=r.method==='conteudo'?'Baixar conteúdo':'Continuar no WhatsApp';a.rel='noreferrer noopener';out.appendChild(document.createElement('br'));out.appendChild(a);}
            if(r.aceito){evento(f,'aceito',{formulario:f.dataset.f3baseFormulario,correlacao:r.correlation_id,method:r.method,duplicado:r.duplicado});}
            // The successful key is retained: double clicks and retries do not create a second contact.
        }).catch(function(err){out.textContent=err.message||'Falha de conexão. Tente novamente.';evento(f,'erro',{formulario:f.dataset.f3baseFormulario,codigo:'envio_nao_confirmado'});}).finally(function(){s.enviando=false;b.disabled=false;});
    });
}());
