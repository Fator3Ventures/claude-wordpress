# Contratos — plugin 1.12.0 / configuração 1.7.0

## Descoberta e permissões

Use a Abilities API do WordPress ou o adaptador MCP já instalado no site. O plugin não cria credenciais nem expõe administração anônima. As abilities mantêm metadados de versão do plugin; consulte `f3base/como-usar`, o catálogo e os esquemas antes de uma escrita.

`f3base/documentacao-ler` requer `manage_options`, é somente leitura e aceita `arquivo`, `linha` e `limite` (1–200). O índice inclui nove documentos desta versão. Caminhos não catalogados são recusados.

`f3base/arquivos-privados-preparar` requer `manage_options`. Cria/testa a raiz configurada e grava o diagnóstico; não envia mensagens.

`f3base/leads-registros-reparar` requer `manage_options` ou `f3base_gerir_leads`; é mutação com simulação padrão. Entrada: `cursor` inteiro, `limite` 1–50, `mapas` por slug do canal, `simular`, `revisao_esperada`. A revisão protege o conjunto consultado; cada linha também usa revisão e condição de não exclusão.

`f3base/leads-resposta-reenviar` tem a mesma permissão de gestão de leads. Entrada: `record_id` (32 hex), `simular`, `revisao_esperada`, `aceitar_possivel_duplicacao`. A leitura de simulação não envia e-mail.

`f3base/leads-registros-ler` aceita filtros `metodo`, `formulario`, `captura`, `atendimento`, `email`, `sessao`, `correlacao`, `post_id`, busca e datas, além de limite/cursor. Requer leitura de leads ou administração. Não disponibilize a resposta em páginas públicas.

A política de opções existente mantém simulação e comparação de revisão. Todas as opções operáveis são habilitadas na primeira atualização; o efeito real de cada opção e seu schema continuam individuais. Isso não dá permissão de administrador a contas sem essa capacidade.

## Clique: POST `/wp-json/f3base/v1/lead`

O schema é fechado em `F3Base_Modulo_Endpoint_Leads::campos()`. Permanecem token, honeypot, quotas e deduplicação. Novos campos opcionais: `sessao` (32 hex), `destino` (até 2048 caracteres), `correlacao` (alias coerente com `correlation_id`) e `consentimento_medicao` (booleano restritivo). O registro recebe IP, user agent e post_id do contexto do servidor, não aceita esses campos livres no payload público.

O cliente não envia `method` ao endpoint: o servidor o determina pelo destino. O JS usa a mesma classificação para a conversão. A classificação de WhatsApp exige host exato e URL sem credenciais; porta padrão HTTP/HTTPS é aceita.

O cliente antigo, sem sessão/destino, continua aceito; o armazenamento declara a ausência. O alias `correlation_id` segue sendo o identificador público de idempotência. Token inválido, campos desconhecidos ou sessão malformada não geram sucesso de persistência.

## Formulários

As rotas existentes são POST `/wp-json/f3base/v1/formularios/token` e `/wp-json/f3base/v1/formularios/enviar`; a alternativa sem JS usa `admin-post.php?action=f3base_formulario`. O token vincula ID/revisão/página. Reenvio igual é deduplicado; payload diferente sob mesma chave é conflito.

A configuração do formulário aceita:

```json
{"resposta_visitante":{"ativa":false,"campo_email":"email","remetente":"site@example.test","nome_remetente":"Equipe","assunto":"Recebemos seu contato","corpo":"Obrigado, {{nome}}."}}
```

O remetente precisa ser válido quando a resposta estiver ativa; cabeçalhos não aceitam CR/LF. O campo de e-mail precisa existir, ser obrigatório e ter papel `email`. Anexos, destinatários internos e regimes permanecem nos schemas publicados pelo Core.

## Leituras honestas

`persisted` confirma armazenamento, não entrega SMTP nem medição em terceiro. `verified` na sonda de cache exige corpo completo vazio em status elegível; 403 com HTML é falha da expectativa de corpo, não prova de vazamento. Hash igual ao artefato identifica exposição efetiva. 5xx, redirecionamento, truncamento, timeout e ausência de arquivo são inconclusivos.
