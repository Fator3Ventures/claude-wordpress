<?php
/** Resposta transacional opcional; estado independente do aviso interno. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Resposta_Visitante {
    public static function schema(): array {
        return array( 'type' => 'object', 'additionalProperties' => false, 'properties' => array(
            'ativa' => array( 'type' => 'boolean', 'default' => false ),
            'campo_email' => array( 'type' => 'string', 'maxLength' => 80 ),
            'assunto' => array( 'type' => 'string', 'maxLength' => 200 ),
            'corpo' => array( 'type' => 'string', 'maxLength' => 10000 ),
            'remetente' => array( 'type' => 'string', 'maxLength' => 254 ),
            'nome_remetente' => array( 'type' => 'string', 'maxLength' => 120 ),
        ) );
    }
    public static function validar( array $form ): string {
        $c = $form['resposta_visitante'] ?? array();
        foreach ( array( 'assunto', 'remetente', 'nome_remetente' ) as $k ) {
            if ( preg_match( '/[\r\n]/', (string) ( $c[$k] ?? '' ) ) ) { return 'Cabeçalhos da resposta ao visitante não aceitam quebras de linha.'; }
        }
        if ( empty( $c['ativa'] ) ) { return ''; }
        if ( empty( $c['assunto'] ) || empty( $c['corpo'] ) || ! is_email( $c['remetente'] ?? '' ) ) { return 'Resposta ativa exige assunto, corpo e remetente válido.'; }
        $campos = array_filter( $form['campos'], static fn( $f ) => 'email' === ( $f['papel'] ?? '' ) && 'email' === $f['tipo'] && ! empty( $f['obrigatorio'] ) && ( empty( $c['campo_email'] ) || $c['campo_email'] === $f['nome'] ) );
        return 1 === count( $campos ) ? '' : 'Resposta ativa exige um campo obrigatório com papel e-mail; confira campo_email.';
    }
    private static function revisao( array $r ): string {
        return hash( 'sha256', $r['resposta'] . '|' . $r['resposta_em'] . '|' . $r['revisao'] );
    }
    public static function enviar( string $record ): array {
        global $wpdb;
        $t = F3Base_Leads_Repositorio::tabela(); $r = F3Base_Leads_Repositorio::obter( $record );
        if ( ! $r || 'pendente' !== $r['resposta'] || 'aceito' !== $r['captura'] || $r['lixeira'] || $r['eliminacao_pendente'] || ! is_email( $r['email'] ) || ! empty( $r['origem_chave'] ) ) { return array( 'codigo' => 'nao_elegivel' ); }
        $c = $r['dados']['resposta_visitante'] ?? array();
        if ( empty( $c['ativa'] ) || empty( $c['assunto'] ) || empty( $c['corpo'] ) || ! is_email( $c['remetente'] ?? '' ) ) { return self::finalizar( $record, 'pendente', 'desconfigurada', 'configuracao_incompleta' ); }
        if ( strtotime( $r['criado_em'] . ' UTC' ) < time() - DAY_IN_SECONDS ) { return self::finalizar( $record, 'pendente', 'expirada', 'janela_de_envio_encerrada' ); }
        $hora = (int) floor( time() / HOUR_IN_SECONDS );
        $destino = hash_hmac( 'sha256', strtolower( $r['email'] ), wp_salt( 'auth' ) );
        if ( ! F3Base_Leads_Repositorio::quota( 'resposta-destino:' . $destino . ':' . $hora, 3, ( $hora + 2 ) * HOUR_IN_SECONDS ) || ! F3Base_Leads_Repositorio::quota( 'resposta-site:' . $hora, 30, ( $hora + 2 ) * HOUR_IN_SECONDS ) ) { return array( 'codigo' => 'aguarda_janela' ); }
        if ( 1 !== $wpdb->update( $t, array( 'resposta' => 'enviando', 'resposta_em' => time() ), array( 'record_id' => $record, 'resposta' => 'pendente', 'lixeira' => 0, 'eliminacao_pendente' => 0 ) ) ) { return array( 'codigo' => 'reservada' ); }
        $vars = array( '{{nome}}' => sanitize_text_field( $r['nome'] ), '{{formulario}}' => sanitize_text_field( $r['dados']['assunto'] ?? $r['formulario'] ), '{{site}}' => sanitize_text_field( get_bloginfo( 'name' ) ), '{{record_id}}' => $record );
        $subject = sanitize_text_field( strtr( $c['assunto'], $vars ) );
        $body = strtr( $c['corpo'], $vars );
        $from = sanitize_email( $c['remetente'] );
        $name = preg_replace( '/[\r\n<>"\\\\]/', '', $c['nome_remetente'] ?? get_bloginfo( 'name' ) );
        $headers = array( 'Content-Type: text/plain; charset=UTF-8', 'From: ' . $name . ' <' . $from . '>', 'Auto-Submitted: auto-replied', 'X-Auto-Response-Suppress: All' );
        $timeout = static function ( $mail ): void { $mail->Timeout = 10; $mail->Timelimit = 10; };
        add_action( 'phpmailer_init', $timeout );
        try { $ok = wp_mail( $r['email'], $subject, $body, $headers ); $estado = $ok ? 'processada' : 'falhou'; }
        catch ( Throwable $e ) { $estado = 'incerta'; }
        finally { remove_action( 'phpmailer_init', $timeout ); }
        return self::finalizar( $record, 'enviando', $estado, 'processada' === $estado ? '' : 'transporte_sem_confirmacao' );
    }
    private static function finalizar( string $record, string $anterior, string $estado, string $erro ): array {
        global $wpdb;
        $ok = 1 === $wpdb->update( F3Base_Leads_Repositorio::tabela(), array( 'resposta' => $estado, 'resposta_em' => time(), 'resposta_erro' => $erro ), array( 'record_id' => $record, 'resposta' => $anterior ) );
        return array( 'codigo' => $ok ? $estado : 'estado_sem_confirmacao', 'persisted' => $ok, 'recebimento' => 'nao_comprovado' );
    }
    public static function processar_pendentes(): void {
        if ( ! F3Base_Leads_Repositorio::pronto() ) { return; }
        global $wpdb; $t = F3Base_Leads_Repositorio::tabela();
        $wpdb->query( $wpdb->prepare( 'UPDATE %i SET resposta=%s WHERE resposta=%s AND resposta_em<%d', $t, 'incerta', 'enviando', time() - 300 ) );
        $ids = $wpdb->get_col( $wpdb->prepare( 'SELECT record_id FROM %i WHERE resposta=%s AND lixeira=0 AND eliminacao_pendente=0 ORDER BY id LIMIT 30', $t, 'pendente' ) );
        foreach ( $ids as $id ) { self::enviar( $id ); }
    }
    public static function reenviar( array $e ): array {
        if ( ! F3Base_Leads_Admin::pode( 'f3base_gerir_leads' ) ) { return array( 'ok' => false, 'codigo' => 'sem_permissao' ); }
        $r = F3Base_Leads_Repositorio::obter( $e['record_id'] ?? '' );
        if ( ! $r || $r['lixeira'] || $r['eliminacao_pendente'] || 'aceito' !== $r['captura'] || ! in_array( $r['resposta'], array( 'falhou', 'incerta', 'pendente' ), true ) ) { return array( 'ok' => false, 'codigo' => 'nao_elegivel' ); }
        $rev = self::revisao( $r ); $simular = $e['simular'] ?? true;
        if ( ( ! $simular || isset( $e['revisao_esperada'] ) ) && ! hash_equals( $rev, (string) ( $e['revisao_esperada'] ?? '' ) ) ) { return array( 'ok' => false, 'codigo' => 'conflito' ); }
        if ( $simular ) { return array( 'ok' => true, 'simulado' => true, 'revisao' => $rev, 'estado' => $r['resposta'], 'exige_aceite_duplicacao' => 'incerta' === $r['resposta'] ); }
        if ( 'incerta' === $r['resposta'] && empty( $e['aceitar_possivel_duplicacao'] ) ) { return array( 'ok' => false, 'codigo' => 'aceite_duplicacao_necessario' ); }
        if ( 'pendente' === $r['resposta'] ) { return array( 'ok' => true, 'resultado' => self::enviar( $r['record_id'] ) ); }
        global $wpdb;
        $ok = $wpdb->update( F3Base_Leads_Repositorio::tabela(), array( 'resposta' => 'pendente', 'resposta_em' => time() ), array( 'record_id' => $r['record_id'], 'resposta' => $r['resposta'], 'resposta_em' => $r['resposta_em'], 'revisao' => $r['revisao'] ) );
        return 1 === $ok ? array( 'ok' => true, 'resultado' => self::enviar( $r['record_id'] ) ) : array( 'ok' => false, 'codigo' => 'conflito' );
    }
    public static function registrar(): void {
        F3Base_Release_1103::ability( 'leads-resposta-reenviar', 'Simular e reenviar resposta ao visitante, com revisão e aceite de duplicação quando incerta', array( __CLASS__, 'reenviar' ), array(
            'record_id' => array( 'type' => 'string', 'pattern' => '^[a-f0-9]{32}$' ), 'simular' => array( 'type' => 'boolean', 'default' => true ), 'revisao_esperada' => array( 'type' => 'string' ), 'aceitar_possivel_duplicacao' => array( 'type' => 'boolean', 'default' => false ),
        ), array( 'record_id' ), false, 'f3base_gerir_leads' );
    }
}
