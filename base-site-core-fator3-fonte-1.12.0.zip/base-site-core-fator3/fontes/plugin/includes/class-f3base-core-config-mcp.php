<?php
/** Configuração persistente do Core, com schema, simulação e revisão concorrente. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Core_Config_Mcp {
	/** Canal MCP confirmado na versão do conector; preserva proteções de outros donos. */
	public static function registrar_protecao(): void {
		add_filter( 'wp_mcp_ultimate_protected_options', array( __CLASS__, 'proteger_options' ), 10, 2 );
	}
	public static function proteger_options( $protegidas ): array {
		return array_values( array_unique( array_merge( is_array( $protegidas ) ? $protegidas : array(), F3Base_Options::proprias() ) ) );
	}

	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		$nomes = array_keys( array_filter( F3Base_Options::catalogo(), static fn( $d ) => ! empty( $d['operavel'] ) ) );
		$nome  = array(
			'type' => 'string',
			'enum' => $nomes,
		);
		$comum = array(
			'meta'                => array(
				'show_in_rest' => true,
				'mcp'          => array(
					'public' => true,
					'type'   => 'tool',
				),
			),
			'category'            => F3BASE_PREFIXO,
			'permission_callback' => static fn() => current_user_can( 'manage_options' ),
			'output_schema'       => array( 'type' => 'object' ),
		);
		F3Base_Release_1103::registrar_ability(
			'f3base/config-core-ler',
			array_merge(
				$comum,
				array(
					'label'            => 'Ler configuração persistente do Core',
					'description'      => 'Lê valores operáveis, revisão opaca, origem e schema do próprio Core; segredos são mascarados. Independe do implantador.',
					'input_schema'     => array(
						'type'                 => 'object',
						'properties'           => array( 'nome' => array( 'type' => 'string' ) ),
						'additionalProperties' => false,
					),
					'execute_callback' => array( __CLASS__, 'ler' ),
					'meta'             => array(
						'show_in_rest' => true,
						'mcp'          => array(
							'public' => true,
							'type'   => 'tool',
						),
						'annotations'  => array(
							'readonly'    => true,
							'destructive' => false,
							'idempotent'  => true,
						),
					),
				)
			)
		);
		F3Base_Release_1103::registrar_ability(
			'f3base/config-core-escrever',
			array_merge(
				$comum,
				array(
					'label'            => 'Simular ou aplicar configuração persistente do Core',
					'description'      => 'Grava pela operação do dono (F3Base_Options::gravar). Envie valor completo e revisão; mesclar=true permite alteração parcial tipada de opções compostas. Simular é o padrão. Confira persisted, effect e verification separadamente; ok mantém compatibilidade. A recusa do Core não autoriza escrita direta ou alteração do tema.',
					'output_schema'    => F3Base_Config_Contrato::schema_gravacao(),
					'input_schema'     => array(
						'type'                 => 'object',
						'properties'           => array(
							'nome'             => $nome,
							'valor'            => F3Base_Config_Contrato::schema_dado( 'Valor completo conforme o schema da option.' ),
							'revisao_esperada' => array(
								'type'    => 'string',
								'pattern' => '^[a-f0-9]{64}$',
							),
							'simular'          => array(
								'type'    => 'boolean',
								'default' => true,
							),
							'mesclar'          => array(
								'type'    => 'boolean',
								'default' => false,
							),
						),
						'required'             => array( 'nome', 'valor', 'revisao_esperada' ),
						'additionalProperties' => false,
					),
					'execute_callback' => array( __CLASS__, 'escrever' ),
				)
			)
		);
		F3Base_Release_1103::registrar_ability(
			F3Base_Config_Contrato::HABILIDADE,
			array_merge(
				$comum,
				array(
					'label'            => 'Contrato de configuração do Core — v1',
					'description'      => 'Catálogo versionado do dono: tipos, limites canônicos, aceitação de entrada, valores atuais, padrões, revisão, dependências e operações permitidas. Segredos mascarados. Leitura de estado do site; não edita os JSONs do implantador.',
					'input_schema'     => array(
						'type'                 => 'object',
						'properties'           => array_merge(
							array(
								'nome' => array(
									'type' => 'string',
									'enum' => F3Base_Config_Contrato::nomes(),
								),
							),
							F3Base_Config_Consultas::propriedades()
						),
						'additionalProperties' => false,
					),
					'output_schema'    => F3Base_Config_Contrato::schema_resposta(),
					'execute_callback' => array( 'F3Base_Config_Contrato', 'consultar' ),
					'meta'             => array(
						'show_in_rest' => true,
						'mcp'          => array(
							'public' => true,
							'type'   => 'tool',
						),
						'annotations'  => array(
							'readonly'    => true,
							'destructive' => false,
							'idempotent'  => true,
						),
					),
				)
			)
		);
		F3Base_Release_1103::registrar_ability(
			'f3base/config-core-perfil-avaliar',
			array_merge(
				$comum,
				array(
					'label'            => 'Avaliar perfil de configuração declarado',
					'description'      => 'Consulta valores e evidências existentes contra perfil versionado fornecido. Não grava nem executa sondas. Segredos aceitam somente presença.',
					'input_schema'     => F3Base_Config_Perfil::schema(),
					'execute_callback' => array( 'F3Base_Config_Perfil', 'avaliar' ),
					'meta'             => array(
						'show_in_rest' => true,
						'mcp'          => array(
							'public' => true,
							'type'   => 'tool',
						),
						'annotations'  => array(
							'readonly'    => true,
							'destructive' => false,
							'idempotent'  => true,
						),
					),
				)
			)
		);
		F3Base_Release_1103::registrar_ability(
			F3Base_Config_Contrato::VERIFICAR,
			array_merge(
				$comum,
				array(
					'label'            => 'Consultar ou executar a verificação do Core',
					'description'      => 'Consultar é leitura. verificar_publico faz até sete GETs anônimos: dois da home, dois por rota de token ativa e um do artefato elegível de cache, na mesma cadência limitada por minuto. atualizar_cache solicita limpeza e verifica. Ações ativas exigem revisão e não regravam preferências. ok indica operação recebida; confira sonda.persisted, verification.status, cache.historico, cache.agendamento, cache.tokens e efeito_cache. Consultas não iniciam sondas nem agendamento; execuções independentes registram origem e início/fim.',
					'input_schema'     => array(
						'type'                 => 'object',
						'properties'           => array(
							'acao'             => array(
								'type'    => 'string',
								'enum'    => array( 'consultar', 'verificar_publico', 'atualizar_cache' ),
								'default' => 'consultar',
							),
							'nome'             => array(
								'type' => 'string',
								'enum' => F3Base_Config_Contrato::nomes(),
							),
							'revisao_esperada' => array(
								'type'    => 'string',
								'pattern' => '^[a-f0-9]{64}$',
							),
						),
						'required'             => array( 'nome' ),
						'additionalProperties' => false,
					),
					'output_schema'    => array(
						'type'       => 'object',
						'properties' => array(
							'cache'                 => F3Base_Config_Contrato::schema_cache(),
							'sonda'                 => array(
								'type'       => array( 'object', 'null' ),
								'properties' => F3Base_Config_Contrato::schema_prova_cache()['properties'],
							),
							'efeito_cache'          => array( 'type' => array( 'object', 'null' ) ),
							'ok'                    => array( 'type' => 'boolean' ),
							'codigo'                => array( 'type' => 'string' ),
							'nome'                  => array( 'type' => 'string' ),
							'revisao'               => array( 'type' => 'string' ),
							'existe_no_banco'       => array( 'type' => 'boolean' ),
							'verification'          => F3Base_Config_Contrato::schema_verificacao(),
							'configuracao_alterada' => array( 'type' => 'boolean' ),
							'efeito_repetido'       => array( 'type' => 'boolean' ),
						),
					),
					'execute_callback' => array( 'F3Base_Config_Contrato', 'verificar' ),
					'meta'             => array(
						'show_in_rest' => true,
						'mcp'          => array(
							'public' => true,
							'type'   => 'tool',
						),
						'annotations'  => array(
							'readonly'    => false,
							'destructive' => false,
							'idempotent'  => true,
						),
					),
				)
			)
		);
	}
	public static function ler( $entrada = array() ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'sem_permissao',
			); }
		if ( ! empty( $entrada['nome'] ) && ! F3Base_Options::operavel( (string) $entrada['nome'] ) ) {
			return array(
				'ok'     => false,
				'codigo' => F3Base_Release_1103::motivo_acesso( (string) $entrada['nome'] ),
				'opcoes' => array(),
			);
		}
		$saida  = array();
		$pedido = is_array( $entrada ) ? (string) ( $entrada['nome'] ?? '' ) : '';
		foreach ( F3Base_Options::catalogo() as $nome => $d ) {
			if ( ! F3Base_Options::operavel( $nome ) || ( '' !== $pedido && $pedido !== $nome ) ) {
				continue; }
			$schema = F3Base_Config_Contrato::campos( $d );
			$foto   = F3Base_Options::fotografia( $nome );
			if ( ! empty( $foto['erro'] ) ) {
				return array(
					'ok'     => false,
					'codigo' => 'leitura_falhou',
				); }
			$saida[ $nome ] = array(
				'valor'           => self::visivel( $nome, $foto['valor'] ),
				'revisao'         => $foto['revisao'],
				'origem'          => F3Base_Options::procedencia( $nome, $foto )['origem'],
				'procedencia'     => F3Base_Options::procedencia( $nome, $foto ),
				'schema'          => F3Base_Config_Contrato::schema_valor( $d ),
				'schema_entrada'  => F3Base_Config_Contrato::schema_entrada( $d ),
				'campos'          => $schema,
				'existe_no_banco' => $foto['existe'],
				'verification'    => F3Base_Options::verificar_configuracao( $nome, $foto['valor'] ),
			);
		}
		return array(
			'ok'               => '' === $pedido || isset( $saida[ $pedido ] ),
			'opcoes'           => $saida,
			'contract_version' => F3Base_Config_Contrato::VERSAO,
			'contrato'         => F3Base_Config_Contrato::HABILIDADE,
		);
	}
	private static function visivel( string $nome, $valor ) {
		return F3Base_Config_Contrato::visivel( $nome, $valor );
	}
	public static function escrever( $entrada ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return self::recusa( 'sem_permissao' ); }
		if ( ! is_array( $entrada ) ) {
			return self::recusa( 'entrada_invalida' ); }
		if ( ( array_key_exists( 'simular', $entrada ) && ! is_bool( $entrada['simular'] ) ) || ( array_key_exists( 'mesclar', $entrada ) && ! is_bool( $entrada['mesclar'] ) ) ) {
			return self::recusa( 'entrada_invalida' ); }
		$nome = is_string( $entrada['nome'] ?? null ) ? $entrada['nome'] : '';
		if ( ! F3Base_Options::operavel( $nome ) || ! array_key_exists( 'valor', $entrada ) ) {
			return self::recusa( 'option_nao_operavel' ); }
		if ( 'f3base_redirects' === $nome ) {
			if ( ! empty( $entrada['mesclar'] ) ) {
				return self::recusa( 'mescla_nao_permitida' ); }
			return F3Base_Redirects_Servico::escrever(
				array(
					'operacao'         => 'substituir_lista',
					'pares'            => $entrada['valor'],
					'revisao_esperada' => $entrada['revisao_esperada'] ?? '',
					'simular'          => $entrada['simular'] ?? true,
				)
			);
		}
		$foto = F3Base_Options::fotografia( $nome );
		if ( ! empty( $foto['erro'] ) ) {
			return self::recusa( 'leitura_falhou' );
		} $revisao = $foto['revisao'];
		$esperada  = $entrada['revisao_esperada'] ?? '';
		if ( ! is_string( $esperada ) || ! hash_equals( $revisao, $esperada ) ) {
			if ( false === ( $entrada['simular'] ?? true ) ) {
				F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'conflito' );
			} return self::recusa( 'conflito', 'A configuração mudou; leia novamente antes de aplicar.' ); }
		$d = F3Base_Options::declaracao( $nome );
		if ( ! empty( $entrada['mesclar'] ) ) {
			$mescla = F3Base_Config_Mescla::preparar( $d, $foto['valor'], $entrada['valor'] );
			if ( ! $mescla['ok'] ) {
				if ( false === ( $entrada['simular'] ?? true ) ) {
					F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, $mescla['codigo'] );
				} return self::recusa( $mescla['codigo'], 'A mesclagem foi recusada; consulte os campos declarados e seus tipos.' ); }
			$entrada['valor'] = $mescla['valor'];
		}
		$validacao = rest_validate_value_from_schema( $entrada['valor'], F3Base_Config_Contrato::schema_entrada( $d ), $nome );
		if ( is_wp_error( $validacao ) ) {
			if ( false === ( $entrada['simular'] ?? true ) ) {
				F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'tipo_invalido' ); }
			return self::recusa( 'tipo_invalido', 'Tipo incompatível com o schema de entrada da option.' );
		}
		$recusa = F3Base_Options::recusar( $nome, $entrada['valor'], $d );
		if ( '' !== $recusa ) {
			if ( false === ( $entrada['simular'] ?? true ) ) {
				F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'valor_recusado' ); }
			$r = self::recusa( 'valor_recusado', F3Base_Options::e_segredo( $nome ) ? 'Valor secreto recusado.' : $recusa );
			if ( 'f3base_seo_entidade' === $nome ) {
				$r['validacao'] = F3Base_Seo_Entidade::validar( $entrada['valor'] ); }
			return $r;
		}
		$ajuste = F3Base_Options::ajustar_na_escrita( $nome, F3Base_Options::sanitizar( $nome, $entrada['valor'] ), $d );
		$valor  = $ajuste['valor'];
		if ( $entrada['simular'] ?? true ) {
			return array_replace(
				F3Base_Options::resultado_gravacao( false, self::visivel( $nome, $foto['valor'] ) ),
				array(
					'ok'       => true,
					'simulado' => true,
					'nome'     => $nome,
					'revisao'  => $revisao,
					'antes'    => self::visivel( $nome, $foto['valor'] ),
					'depois'   => self::visivel( $nome, $valor ),
					'motivo'   => F3Base_Options::e_segredo( $nome ) ? 'Valor secreto preservado na simulação.' : trim( implode( ' ', $ajuste['avisos'] ) . ' ' . F3Base_Options::aviso_de_normalizacao( $nome, $entrada['valor'], $valor ) ),
				)
			);
		}
		$r            = F3Base_Options::pelo_canal( 'ability', static fn() => F3Base_Options::gravar( $nome, $entrada['valor'], F3Base_Options::ORIGEM_MANUAL, $esperada ) );
		$r['lido']    = self::visivel( $nome, $r['lido'] );
		$r['revisao'] = $r['revisao'] ?? F3Base_Options::revisao( $nome );
		if ( F3Base_Options::e_segredo( $nome ) && ! empty( $r['ok'] ) ) {
			$r['motivo'] = ''; }
		return $r;
	}
	private static function recusa( string $codigo, string $motivo = '' ): array {
		return F3Base_Options::resultado_gravacao( false, null, $motivo, $codigo ); }
}
