<?php
/** Inspeção administrativa de recursos públicos. Leituras não reconciliam nem publicam arquivos. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Publicacao_Sonda {
	public const OPTION    = 'f3base_publicacao_evidencias';
	public const MAX_BYTES = 1048576;
	public const VALIDADE  = 3600;
	public const INTERVALO = 10;
	public const MAX_ITENS = 12;

	public static function user_agent( string $componente = 'publicacao' ): string {
		return 'F3Base-Sonda/' . F3BASE_PLUGIN_VERSAO . ' (+' . home_url( '/' ) . '; ' . sanitize_key( $componente ) . ')';
	}
	/** Geração calculada por leitura: não semeia transient nem força reindexação. */
	public static function geracao(): string {
		return hash( 'sha256', wp_json_encode( array( F3BASE_PLUGIN_VERSAO, home_url( '/' ), get_option( 'blog_public' ), get_option( 'active_plugins', array() ), get_option( 'wpseo', array() ), F3Base_Options::ler( 'f3base_llms' ), F3Base_Options::ler( 'f3base_robots' ), get_transient( F3Base_Modulo_Cache_Publico::GERACAO ), F3Base_Cache_Pagina::estado()['geracao'] ?? '', self::arquivos_fisicos() ) ) );
	}
	private static function arquivos_fisicos(): array {
		$r = array();
		foreach ( array( 'robots.txt', 'llms.txt', 'llms-full.txt' ) as $nome ) {
			$p = F3Base_Llms::arquivo_publico( $nome );
			if ( '' !== $p ) {
				clearstatcache( true, $p ); }
			$r[ $nome ] = '' === $p ? array( 'existe' => false ) : array(
				'existe' => true,
				'sha256' => is_readable( $p ) && filesize( $p ) <= self::MAX_BYTES ? hash_file( 'sha256', $p ) : '',
				'bytes'  => (int) filesize( $p ),
				'mtime'  => (int) filemtime( $p ),
			);
		}
		return $r;
	}
	public static function sanitizar( $valor, $padrao = null ): array {
		unset( $padrao ); // Contrato comum dos sanitizadores; evidência sempre usa estrutura fechada.
		$v = is_array( $valor ) ? $valor : array();
		$r = array(
			'versao'       => 1,
			'last_attempt' => max( 0, (int) ( $v['last_attempt'] ?? 0 ) ),
			'lease'        => array(
				'id'  => substr( (string) ( $v['lease']['id'] ?? '' ), 0, 64 ),
				'ate' => max( 0, (int) ( $v['lease']['ate'] ?? 0 ) ),
			),
			'itens'        => array(),
		);
		foreach ( array_slice( (array) ( $v['itens'] ?? array() ), -self::MAX_ITENS, null, true ) as $chave => $item ) {
			if ( ! is_string( $chave ) || ! is_array( $item ) ) {
				continue; }
			$p = array();
			foreach ( array( 'url', 'caminho', 'metodo', 'geracao', 'sha256', 'sha256_escopo', 'responsavel_observado', 'codigo', 'redirecionado_para', 'erro', 'cache_expectativa', 'cache_relativo', 'cache_artefato_sha256', 'cache_exposicao' ) as $k ) {
				$p[ $k ] = substr( is_scalar( $item[ $k ] ?? null ) ? (string) $item[ $k ] : '', 0, 2048 ); }
			foreach ( array( 'status', 'checked_at', 'bytes_observados', 'limite_bytes' ) as $k ) {
				$p[ $k ] = max( 0, (int) ( $item[ $k ] ?? 0 ) ); }
			foreach ( array( 'ok', 'completa', 'truncado', 'geracao_atual', 'redirect_permitido' ) as $k ) {
				$p[ $k ] = ! empty( $item[ $k ] ); }
			$p['cabecalhos'] = self::cabecalhos( (array) ( $item['cabecalhos'] ?? array() ) );
			$p['assercoes']  = array();
			foreach ( array_slice( (array) ( $item['assercoes'] ?? array() ), 0, 12 ) as $a ) {
				if ( ! is_array( $a ) ) {
					continue; }
				$p['assercoes'][] = array(
					'tipo'   => substr( (string) ( $a['tipo'] ?? '' ), 0, 32 ),
					'estado' => in_array( $a['estado'] ?? '', array( 'aprovado', 'reprovado', 'inconclusivo' ), true ) ? $a['estado'] : 'inconclusivo',
					'motivo' => substr( (string) ( $a['motivo'] ?? '' ), 0, 512 ),
				);
			}
			$r['itens'][ substr( $chave, 0, 2048 ) ] = $p;
		}
		return $r;
	}
	/** Remove cookies, identificadores e cabeçalhos livres da evidência durável. */
	public static function cabecalhos( array $entrada ): array {
		$r = array();
		foreach ( $entrada as $chave => $valor ) {
			$chave = strtolower( (string) $chave );
			if ( ! in_array( $chave, array( 'content-type', 'content-length', 'cache-control', 'etag', 'last-modified', 'x-robots-tag', 'link', 'x-f3base-mecanismo', 'x-f3base-conversao', 'vary', 'age', 'location' ), true ) ) {
				continue; }
			if ( 'location' === $chave ) {
				$valor = self::location_segura( F3Base_Modulo_Rota_Origem::primeiro_valor( $valor ) ); }
			$r[ $chave ] = is_array( $valor ) ? array_map( static fn( $s ) => substr( (string) $s, 0, 1024 ), array_slice( $valor, 0, 4 ) ) : substr( (string) $valor, 0, 2048 );
		}
		return $r;
	}
	private static function location_segura( string $url ): string {
		$p = wp_parse_url( $url );
		if ( ! is_array( $p ) || isset( $p['user'] ) || isset( $p['pass'] ) ) {
			return '[destino recusado]'; }
		// Não persiste query/fragmento arbitrários devolvidos por terceiros.
		return ( isset( $p['host'] ) ? ( $p['scheme'] ?? 'https' ) . '://' . $p['host'] . ( isset( $p['port'] ) ? ':' . $p['port'] : '' ) : '' ) . ( $p['path'] ?? '/' );
	}
	public static function consultar( array $entrada = array() ): array {
		$caminho = (string) ( $entrada['caminho'] ?? '/llms.txt' );
		$valor   = (array) F3Base_Options::fotografia( self::OPTION )['valor'];
		$e       = (array) ( $valor['itens'][ $caminho ] ?? array() );
		$g       = self::geracao();
		$valida  = ! empty( $e['checked_at'] ) && $e['checked_at'] + self::VALIDADE >= time() && ( $e['geracao'] ?? '' ) === $g && ! empty( $e['geracao_atual'] );
		if ( $valida && ! empty( $e['cache_relativo'] ) ) {
			$atual  = self::resolver_cache( $e['cache_relativo'] );
			$valida = ! empty( $atual['ok'] ) && ( $atual['cache_artefato_sha256'] ?? '' ) === ( $e['cache_artefato_sha256'] ?? '' ); }
		return array(
			'caminho'      => $caminho,
			'geracao'      => $g,
			'evidencia'    => $e,
			'valida'       => $valida,
			'validade_ate' => (int) ( $e['checked_at'] ?? 0 ) + ( $e ? self::VALIDADE : 0 ),
			'motivo'       => ! $e ? 'Sem observação HTTP.' : ( $valida ? 'Observação da geração atual dentro do prazo; avalie status e asserções.' : 'Evidência histórica, vencida ou de outra geração.' ),
		);
	}
	public static function resumo(): array {
		$arquivos = self::arquivos_fisicos();
		$r        = array();
		foreach ( array( 'robots.txt', 'llms.txt', 'llms-full.txt' ) as $nome ) {
			$r[ $nome ] = array_merge( self::consultar( array( 'caminho' => '/' . $nome ) ), array( 'fisico' => $arquivos[ $nome ] ) ); }
		$robots        = (array) F3Base_Options::ler( F3Base_Robots_Arquivo::OPTION );
		$entrega       = (array) ( $robots['entrega'] ?? array() );
		$sincronizado  = ! empty( $entrega['ok'] ) && ( $entrega['assinatura'] ?? '' ) === F3Base_Robots_Entrega::assinatura() && (int) ( $entrega['verificado_em'] ?? 0 ) + F3Base_Robots_Entrega::INTERVALO >= time();
		$r['markdown'] = array();
		foreach ( (array) ( F3Base_Options::fotografia( self::OPTION )['valor']['itens'] ?? array() ) as $caminho => $evidencia ) {
			if ( str_ends_with( (string) $caminho, '.md' ) ) {
				$r['markdown'][] = self::consultar( array( 'caminho' => $caminho ) ); }
		}
		$r['responsaveis'] = F3Base_Llms::responsaveis();
		$observado         = $r['llms.txt'];
		if ( $observado['valida'] ) {
			$r['responsaveis']['llms']['responsavel_observado'] = $observado['evidencia']['responsavel_observado'] ?? 'nao_determinado'; }
		$divergente                = ! empty( $arquivos['robots.txt']['existe'] ) && ! empty( $entrega['esperado_sha256'] ) && ( $arquivos['robots.txt']['sha256'] ?? '' ) !== $entrega['esperado_sha256'];
		$r['robots_reconciliacao'] = array(
			'sincronizacao'    => $divergente ? 'divergente' : ( $sincronizado ? 'confirmada' : ( empty( $entrega ) ? 'desconhecida' : 'verificacao_pendente' ) ),
			'ultima_execucao'  => $entrega,
			'proxima_execucao' => (int) wp_next_scheduled( F3Base_Robots_Entrega::EVENTO ),
			'ressalva'         => 'A reconciliação pode escrever o robots gerenciado. Inspecionar publicação somente observa; o cron depende de um executor.',
		);
		return $r;
	}
	/** Allowlist pública: nenhuma URL arbitrária, credencial, consulta livre ou caminho administrativo. */
	public static function resolver( string $entrada ): array {
		$alvo = F3Base_Modulo_Rota_Origem::resolver_alvo( $entrada );
		if ( empty( $alvo['ok'] ) ) {
			return $alvo; }
		$p       = wp_parse_url( $alvo['url'] );
		$casa    = wp_parse_url( home_url( '/' ) );
		$recusar = static fn( $m ) => array(
			'ok'      => false,
			'url'     => '',
			'caminho' => '',
			'motivo'  => $m,
		);
		if ( isset( $p['query'] ) || isset( $p['fragment'] ) || ( $p['scheme'] ?? '' ) !== ( $casa['scheme'] ?? '' ) ) {
			return $recusar( 'Consulta ou esquema fora da allowlist.' ); }
		$path    = (string) ( $p['path'] ?? '/' );
		$prefixo = rtrim( (string) ( $casa['path'] ?? '' ), '/' );
		$rel     = substr( $path, strlen( $prefixo ) );
		if ( preg_match( '~[\\\\\x00-\x20]|\.\.|%~', rawurldecode( $rel ) ) ) {
			return $recusar( 'Caminho codificado, ambíguo ou inválido.' ); }
		$fixos     = array( '/', '/robots.txt', '/llms.txt', '/llms-full.txt', '/sitemap.xml', '/sitemap_index.xml', '/wp-sitemap.xml', '/wp-json/' );
		$permitido = in_array( $rel, $fixos, true ) || (bool) preg_match( '~^/(?:[a-z0-9_-]+-sitemap[0-9]*|wp-sitemap-[a-z0-9_-]+-[0-9]+)\.xml$~D', $rel );
		if ( ! $permitido ) {
			$markdown  = str_ends_with( $rel, '/index.md' ) || str_ends_with( $rel, '.md' );
			$url       = $markdown ? ( str_ends_with( $alvo['url'], '/index.md' ) ? substr( $alvo['url'], 0, -8 ) : substr( $alvo['url'], 0, -3 ) ) : $alvo['url'];
			$id        = url_to_postid( $url );
			$post      = $id ? get_post( $id ) : null;
			$permitido = $post instanceof WP_Post && is_post_publicly_viewable( $post ) && '' === $post->post_password && ! F3Base_Modulo_Noindex_Honrado::post_e_noindex( $id );
			if ( $permitido && $markdown ) {
				$permitido = false;
				foreach ( F3Base_Modulo_Llms_Txt_Reserva::selecao_sem_cache( (array) F3Base_Options::ler( 'f3base_llms' ) ) as $item ) {
					if ( (int) ( $item['id'] ?? 0 ) === $id && F3Base_Modulo_Llms_Markdown::url_do_item( $item ) === $alvo['url'] ) {
						$permitido = true;
						break; }
				}
			}
		}
		return $permitido ? $alvo : $recusar( 'Destino não pertence à allowlist de recursos públicos.' );
	}
	public static function verificar( $entrada = null ) {
		if ( ! current_user_can( 'manage_options' ) && ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return new WP_Error( 'f3base_sem_permissao', 'A inspeção exige manage_options.', array( 'status' => 403 ) ); }
		$e = is_array( $entrada ) ? $entrada : array();
		if ( 'cobertura' === ( $e['recurso'] ?? '' ) ) {
			return array(
				'ok'        => true,
				'cobertura' => F3Base_Llms_Cobertura::resumo( F3Base_Modulo_Llms_Txt_Reserva::selecao( F3Base_Options::ler( 'f3base_llms' ) ) ),
			); }
		$metodo = strtoupper( (string) ( $e['metodo'] ?? 'GET' ) );
		if ( ! in_array( $metodo, array( 'GET', 'HEAD' ), true ) ) {
			return new WP_Error( 'f3base_metodo_recusado', 'Somente GET e HEAD.' ); }
		$alvo = ! empty( $e['cache_artefato'] ) ? self::resolver_cache( (string) $e['cache_artefato'] ) : self::resolver( (string) ( $e['caminho'] ?? '/llms.txt' ) );
		if ( empty( $alvo['ok'] ) ) {
			return new WP_Error( 'f3base_destino_recusado', $alvo['motivo'] ); }
		$assercoes = (array) ( $e['assercoes'] ?? array() );
		if ( ! self::assercoes_validas( $assercoes ) ) {
			return new WP_Error( 'f3base_assercoes_invalidas', 'Asserções limitadas a status, cabeçalho ou trecho literal.' ); }
		$foto = F3Base_Options::fotografia( self::OPTION );
		$v    = (array) $foto['valor'];
		if ( ! empty( $foto['erro'] ) || (int) ( $v['lease']['ate'] ?? 0 ) > time() || (int) ( $v['last_attempt'] ?? 0 ) + self::INTERVALO > time() ) {
			return new WP_Error( 'f3base_sonda_intervalo', 'Sonda em execução ou intervalo mínimo de 10 segundos; nenhuma requisição iniciada.' ); }
		$id                = wp_generate_uuid4();
		$v['last_attempt'] = time();
		$v['lease']        = array(
			'id'  => $id,
			'ate' => time() + 30,
		);
		$reserva           = F3Base_Options::gravar( self::OPTION, $v, F3Base_Options::ORIGEM_PADRAO, $foto['revisao'] );
		if ( empty( $reserva['persisted'] ) ) {
			return new WP_Error( 'f3base_reserva_recusada', 'Reserva não persistida; nenhuma sonda iniciada.' ); }
		$limite                     = max( 1024, min( self::MAX_BYTES, (int) ( $e['limite_bytes'] ?? self::MAX_BYTES ) ) );
		$geracao                    = self::geracao();
		$r                          = wp_safe_remote_request(
			$alvo['url'],
			array(
				'method'              => $metodo,
				'timeout'             => 8,
				'redirection'         => 0,
				'limit_response_size' => $limite + 1,
				'sslverify'           => true,
				'cookies'             => array(),
				'user-agent'          => self::user_agent(),
				'headers'             => array(
					'Accept'        => 'text/plain,text/markdown,text/html,application/xml,application/json',
					'Cache-Control' => 'no-cache',
				),
			)
		);
		$p                          = self::resultado( $r, $metodo, $limite, $assercoes );
		$p                          = array_merge(
			$p,
			array(
				'url'           => $alvo['url'],
				'caminho'       => $alvo['caminho'],
				'geracao'       => $geracao,
				'geracao_atual' => hash_equals( $geracao, self::geracao() ),
				'checked_at'    => time(),
			)
		);
		$mecanismo                  = $p['cabecalhos']['x-f3base-mecanismo'] ?? '';
		$mecanismo                  = is_string( $mecanismo ) ? $mecanismo : '';
		$p['responsavel_observado'] = 200 === $p['status'] && ! empty( $p['completa'] ) && ( str_starts_with( $mecanismo, 'llms' ) || F3Base_Llms::QUEM_NOSSA_ROTA === $mecanismo ) ? 'core_declarado_no_cabecalho' : 'nao_determinado';
		$p['redirect_permitido']    = false;
		if ( ! is_wp_error( $r ) ) {
			$location = wp_remote_retrieve_header( $r, 'location' );
			if ( is_string( $location ) && '' !== $location ) {
				$destino                 = WP_Http::make_absolute_url( $location, $alvo['url'] );
				$redirect                = self::resolver( $destino );
				$p['redirect_permitido'] = ! empty( $redirect['ok'] );
				$p['redirecionado_para'] = self::location_segura( $destino );
			}
		}
		if ( ! empty( $alvo['cache_expectativa'] ) ) {
			foreach ( array( 'cache_expectativa', 'cache_relativo', 'cache_artefato_sha256' ) as $k ) {
				$p[ $k ] = $alvo[ $k ]; }
			$p['cache_exposicao'] = 'inconclusivo';
			if ( 'protegido' === $alvo['cache_expectativa'] ) {
				$p['cache_exposicao'] = in_array( $p['status'], array( 403, 404, 410 ), true ) ? 'aprovado' : ( $p['completa'] && hash_equals( $alvo['cache_artefato_sha256'], $p['sha256'] ) ? 'reprovado' : 'inconclusivo' ); } elseif ( $p['completa'] ) {
				$p['cache_exposicao'] = hash_equals( $alvo['cache_artefato_sha256'], $p['sha256'] ) ? 'aprovado' : 'reprovado'; }
				// Somente a existência e o hash do artefato são registrados; seu conteúdo nunca é devolvido.
				$e['corpo'] = false;
		}
		$corpo = (string) ( $p['corpo'] ?? '' );
		unset( $p['corpo'] );
		$persisted = false;
		for ( $i = 0; $i < 3; ++$i ) {
			$f = F3Base_Options::fotografia( self::OPTION );
			$v = (array) $f['valor'];
			if ( $f['erro'] || ( $v['lease']['id'] ?? '' ) !== $id ) {
				break; }
			$v['lease'] = array(
				'id'  => '',
				'ate' => 0,
			);
			unset( $v['itens'][ $alvo['caminho'] ] );
			$v['itens'][ $alvo['caminho'] ] = $p;
			if ( ! empty( F3Base_Options::gravar( self::OPTION, $v, F3Base_Options::ORIGEM_PADRAO, $f['revisao'] )['persisted'] ) ) {
				$persisted = true;
				break; }
		}
		$p['persisted'] = $persisted;
		$p['ressalva']  = 'HTTP iniciado pelo servidor pela URL pública. A resposta pode atravessar cache, proxy ou CDN.';
		if ( ! empty( $e['corpo'] ) ) {
			$p['corpo']            = substr( $corpo, 0, 32768 );
			$p['retorno_truncado'] = strlen( $corpo ) > 32768; }
		return $p;
	}
	/** Avaliação pura da resposta: HEAD/304 não fornecem um documento vazio. */
	public static function resultado( $resposta, string $metodo, int $limite, array $assercoes ): array {
		$erro      = is_wp_error( $resposta );
		$status    = $erro ? 0 : (int) wp_remote_retrieve_response_code( $resposta );
		$h         = $erro ? array() : wp_remote_retrieve_headers( $resposta );
		$h         = is_object( $h ) && method_exists( $h, 'getAll' ) ? $h->getAll() : (array) $h;
		$corpo     = $erro ? '' : (string) wp_remote_retrieve_body( $resposta );
		$truncado  = strlen( $corpo ) > $limite;
		$sem_corpo = 'HEAD' === $metodo || 304 === $status || 204 === $status;
		$completa  = ! $erro && ! $truncado && ! $sem_corpo && 200 === $status;
		$h         = self::cabecalhos( $h );
		$body      = substr( $corpo, 0, $limite );
		$resultado = array();
		foreach ( $assercoes as $a ) {
			$tipo   = $a['tipo'];
			$estado = 'inconclusivo';
			$motivo = 'Transporte não concluído.';
			if ( ! $erro ) {
				if ( 'status' === $tipo ) {
					$estado = $status === (int) $a['valor'] ? 'aprovado' : 'reprovado';
					$motivo = 'Status HTTP observado: ' . $status . '.'; } elseif ( 'cabecalho' === $tipo ) {
					$valor  = $h[ strtolower( $a['nome'] ) ] ?? '';
					$valor  = is_array( $valor ) ? implode( ', ', $valor ) : $valor;
					$estado = str_contains( $valor, (string) $a['valor'] ) ? 'aprovado' : 'reprovado';
					$motivo = 'Cabeçalho literal comparado.'; } elseif ( $sem_corpo || 200 !== $status ) {
						$motivo = 'HEAD, 204, 304 sem representação vinculada ou resposta não 200: conteúdo não confirmado.'; } else {
						$contem = str_contains( $body, (string) $a['valor'] );
						$negada = 'nao_contem' === $tipo;
						$estado = $truncado && ! $contem ? 'inconclusivo' : ( $contem !== $negada ? 'aprovado' : 'reprovado' );
						$motivo = $truncado && ! $contem ? 'Corpo truncado; o restante não foi observado.' : 'Trecho literal avaliado nos bytes observados.'; }
			}
			$resultado[] = array(
				'tipo'   => $tipo,
				'estado' => $estado,
				'motivo' => $motivo,
			);
		}
		return array(
			'ok'                 => ! $erro,
			'codigo'             => $erro ? 'transporte_falhou' : ( $sem_corpo ? 'sem_representacao' : ( $truncado ? 'corpo_truncado' : 'observado' ) ),
			'erro'               => $erro ? sanitize_key( $resposta->get_error_code() ) : '',
			'metodo'             => $metodo,
			'status'             => $status,
			'completa'           => $completa,
			'truncado'           => $truncado,
			'bytes_observados'   => strlen( $body ),
			'limite_bytes'       => $limite,
			'sha256'             => ! $erro && ! $sem_corpo ? hash( 'sha256', $body ) : '',
			'sha256_escopo'      => $sem_corpo || $erro ? 'sem_representacao' : ( $truncado ? 'bytes_observados_parciais' : 'bytes_observados' ),
			'cabecalhos'         => $h,
			'redirecionado_para' => F3Base_Modulo_Rota_Origem::primeiro_valor( $h['location'] ?? '' ),
			'assercoes'          => $resultado,
			'corpo'              => $body,
		);
	}
	private static function assercoes_validas( array $itens ): bool {
		if ( count( $itens ) > 12 ) {
			return false; }
		foreach ( $itens as $a ) {
			if ( ! is_array( $a ) || ! in_array( $a['tipo'] ?? '', array( 'status', 'cabecalho', 'contem', 'nao_contem' ), true ) || ! is_scalar( $a['valor'] ?? null ) || strlen( (string) $a['valor'] ) > 512 ) {
				return false; }
			if ( 'status' === $a['tipo'] && ( (int) $a['valor'] < 100 || (int) $a['valor'] > 599 ) ) {
				return false; }
			if ( 'status' !== $a['tipo'] && '' === (string) $a['valor'] ) {
				return false; }
			if ( 'cabecalho' === $a['tipo'] && ! array_key_exists( strtolower( (string) ( $a['nome'] ?? '' ) ), self::cabecalhos( array( strtolower( (string) ( $a['nome'] ?? '' ) ) => '' ) ) ) ) {
				return false; }
		}
		return true;
	}
	/** Artefato de cache já existente, de uma página hoje pública, com expectativa derivada do perfil. */
	public static function resolver_cache( string $relativo ): array {
		$recusa = static fn( $m ) => array(
			'ok'      => false,
			'url'     => '',
			'caminho' => '',
			'motivo'  => $m,
		);
		if ( ! F3Base_Llms::site_publico() || ! defined( 'WP_CONTENT_DIR' ) || strlen( $relativo ) > 1000 || preg_match( '~[^a-zA-Z0-9/_\-.]|\.\.~', $relativo ) || ! preg_match( '~(?:^|/)index(?:-https)?\.html$~D', $relativo ) ) {
			return $recusa( 'Artefato fora da seleção segura de cache público.' ); }
		$perfil = F3Base_Cache_Pagina::perfil();
		if ( 'wp-super-cache' !== $perfil['provedor'] || ! $perfil['ativo'] || ! in_array( $perfil['modo'], array( 'simple', 'expert', 'wp-cache-cabecalhos' ), true ) ) {
			return $recusa( 'Perfil sem expectativa de acesso público definida.' ); }
		$host    = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
		$base    = realpath( WP_CONTENT_DIR . '/cache/supercache/' . $host );
		$arquivo = $base ? realpath( $base . '/' . ltrim( $relativo, '/' ) ) : false;
		if ( ! $base || ! $arquivo || ! str_starts_with( $arquivo, $base . DIRECTORY_SEPARATOR ) || ! is_file( $arquivo ) || ! is_readable( $arquivo ) || filesize( $arquivo ) > self::MAX_BYTES ) {
			return $recusa( 'Nenhum artefato público elegível e existente neste caminho; proteção não avaliada.' ); }
		$pasta  = dirname( ltrim( $relativo, '/' ) );
		$pagina = '.' === $pasta ? '/' : '/' . trim( $pasta, '/' ) . '/';
		if ( '/' === $pagina && 'page' === get_option( 'show_on_front' ) ) {
			$front = get_post( (int) get_option( 'page_on_front' ) );
			if ( ! $front instanceof WP_Post || ! is_post_publicly_viewable( $front ) || '' !== $front->post_password || F3Base_Modulo_Noindex_Honrado::post_e_noindex( (int) $front->ID ) ) {
				return $recusa( 'A página inicial não é elegível para uma sonda de cache público.' ); }
		}
		$alvo_pagina = self::resolver( $pagina );
		if ( empty( $alvo_pagina['ok'] ) || str_contains( $pagina, 'wp-' ) ) {
			return $recusa( 'O artefato não corresponde a uma página hoje publicamente elegível.' ); }
		$url = content_url( '/cache/supercache/' . $host . '/' . ltrim( $relativo, '/' ) );
		$p   = wp_parse_url( $url );
		$c   = wp_parse_url( home_url( '/' ) );
		if ( ( $p['host'] ?? '' ) !== ( $c['host'] ?? '' ) || ( $p['scheme'] ?? '' ) !== ( $c['scheme'] ?? '' ) || (int) ( $p['port'] ?? 0 ) !== (int) ( $c['port'] ?? 0 ) ) {
			return $recusa( 'Diretório de conteúdo em origem distinta; sonda recusada.' ); }
		return array(
			'ok'                    => true,
			'url'                   => $url,
			'caminho'               => (string) $p['path'],
			'motivo'                => '',
			'cache_relativo'        => $relativo,
			'cache_expectativa'     => 'wp-cache-cabecalhos' === $perfil['modo'] ? 'protegido' : 'publico',
			'cache_artefato_sha256' => hash_file( 'sha256', $arquivo ),
		);
	}
	/** Prévia editorial explícita, sem executar o tema e sem publicar/reconciliar arquivos. */
	public static function previa( string $recurso = 'llms', int $post_id = 0 ): array {
		$config  = (array) F3Base_Options::ler( 'f3base_llms' );
		$itens   = F3Base_Modulo_Llms_Txt_Reserva::selecao_sem_cache( $config );
		$erros   = array();
		$avisos  = array();
		$texto   = '';
		$arquivo = '';
		try {
			if ( 'full' === $recurso ) {
				$texto   = F3Base_Modulo_Llms_Full_Txt::montar( $itens, $config );
				$arquivo = 'llms-full.txt'; } elseif ( 'llms' === $recurso ) {
				$texto   = ( new F3Base_Modulo_Llms_Txt_Reserva() )->montar( $itens );
				$arquivo = 'llms.txt'; } elseif ( 'markdown' === $recurso ) {
								$item = null;
					foreach ( $itens as $candidato ) {
						if ( (int) ( $candidato['id'] ?? 0 ) === $post_id ) {
									$item = $candidato;
									break; }
					}
					if ( ! $item ) {
						throw new RuntimeException( 'Conteúdo não integra a seleção pública atual.' ); }
					$r      = F3Base_Llms_Conversor::converter( (string) ( $item['conteudo'] ?? '' ), $item['url'] );
					$texto  = $r['texto'];
					$erros  = $r['erros'];
					$avisos = $r['avisos'];
				} elseif ( 'robots' === $recurso ) {
					// A cadeia de filtros é executada somente na rota pública pela sonda; prévia local não imita is_robots.
					$arquivo = 'robots.txt';
					$fisico  = F3Base_Llms::arquivo_publico( $arquivo );
					if ( '' !== $fisico && is_readable( $fisico ) && filesize( $fisico ) <= self::MAX_BYTES ) {
						$texto    = (string) file_get_contents( $fisico ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Arquivo local conhecido e limitado por MAX_BYTES; não é uma requisição HTTP.
						$avisos[] = 'Prévia do arquivo físico; a resposta virtual exige Verificar publicação.'; } else {
										$avisos[] = 'Rota virtual: consulte a observação HTTP. A prévia não executa reconciliação.'; }
				} else {
					throw new RuntimeException( 'Recurso de prévia desconhecido.' ); }
		} catch ( RuntimeException $erro ) {
			$erros[] = $erro->getMessage();
			$texto   = ''; }
		$comparacao = array(
			'estado'             => 'sem_arquivo_fisico',
			'sha256_fisico'      => '',
			'linhas_adicionadas' => 0,
			'linhas_removidas'   => 0,
		);
		$fisico     = '' !== $arquivo ? F3Base_Llms::arquivo_publico( $arquivo ) : '';
		if ( '' !== $fisico && is_readable( $fisico ) && filesize( $fisico ) <= self::MAX_BYTES && ! $erros ) {
			$antes      = (string) file_get_contents( $fisico ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Arquivo local conhecido e limitado por MAX_BYTES; não é uma requisição HTTP.
			$a          = explode( "\n", $antes );
			$b          = explode( "\n", $texto );
			$comparacao = array(
				'estado'             => $antes === $texto ? 'igual' : 'divergente',
				'sha256_fisico'      => hash( 'sha256', $antes ),
				'linhas_adicionadas' => count( array_diff( $b, $a ) ),
				'linhas_removidas'   => count( array_diff( $a, $b ) ),
				'ressalva'           => 'Comparação editorial por linhas distintas; não é patch de aplicação.',
			);
		}
		$selecionados = array();
		foreach ( $itens as $item ) {
			$selecionados[] = array(
				'id'     => (int) ( $item['id'] ?? 0 ),
				'titulo' => (string) ( $item['titulo'] ?? '' ),
				'origem' => (string) ( $item['origem'] ?? 'curadoria' ),
			); }
		return array(
			'ok'              => ! $erros,
			'completo'        => ! $erros,
			'recurso'         => $recurso,
			'texto'           => substr( $texto, 0, 65536 ),
			'previa_truncada' => strlen( $texto ) > 65536,
			'bytes_documento' => strlen( $texto ),
			'sha256'          => $erros ? '' : hash( 'sha256', $texto ),
			'avisos'          => $avisos,
			'erros'           => $erros,
			'comparacao'      => $comparacao,
			'selecionados'    => $selecionados,
			'explicacao_post' => $post_id ? self::explicar_post( $post_id, $itens, $config ) : array(),
		);
	}
	private static function explicar_post( int $id, array $itens, array $config ): array {
		$post    = get_post( $id );
		$motivos = array();
		if ( ! $post ) {
			return array(
				'id'       => $id,
				'incluido' => false,
				'motivos'  => array( 'Conteúdo inexistente.' ),
			); }
		if ( ! F3Base_Llms::site_publico() ) {
			$motivos[] = 'Site sem visibilidade pública.'; }
		if ( ! is_post_publicly_viewable( $post ) ) {
			$motivos[] = 'Estado ou tipo sem visibilidade pública.'; }
		if ( '' !== $post->post_password ) {
			$motivos[] = 'Protegido por senha.'; }
		if ( F3Base_Modulo_Noindex_Honrado::post_e_noindex( $id ) ) {
			$motivos[] = 'Conteúdo noindex.'; }
		if ( '' === F3Base_Llms::canonical_do_post( $post ) ) {
			$motivos[] = 'Canonical aponta para outro documento.'; }
		$incluido = false;
		foreach ( $itens as $item ) {
			if ( (int) ( $item['id'] ?? 0 ) === $id ) {
				$incluido  = true;
				$motivos[] = 'Selecionado por ' . (string) ( $item['origem'] ?? 'curadoria/enumeração' ) . '.';
				break; }
		}
		if ( (int) get_option( 'wp_page_for_privacy_policy' ) === $id && empty( $config['politica_privacidade']['url'] ) ) {
			$motivos[] = 'Política de privacidade excluída pela configuração.'; }
		if ( ! $incluido && ! F3Base_Llms::modo_enumera( (string) ( $config['modo'] ?? '' ) ) ) {
			$motivos[] = 'Enumeração desativada; somente a curadoria é selecionada.'; }
		if ( ! $incluido && ! $motivos ) {
			$motivos[] = in_array( $post->post_type, $config['tipos'] ?? array(), true ) ? 'Fora da curadoria, excluído na configuração ou além do teto da seleção.' : 'Tipo não enumerado e conteúdo não incluído pela curadoria.'; }
		return array(
			'id'       => $id,
			'incluido' => $incluido,
			'motivos'  => $motivos,
		);
	}
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		$entrada                          = array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'caminho'        => array(
					'type'      => 'string',
					'maxLength' => 2000,
					'default'   => '/llms.txt',
				),
				'metodo'         => array(
					'type'    => 'string',
					'enum'    => array( 'GET', 'HEAD' ),
					'default' => 'GET',
				),
				'corpo'          => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'cache_artefato' => array(
					'type'      => 'string',
					'maxLength' => 1000,
				),
				'limite_bytes'   => array(
					'type'    => 'integer',
					'minimum' => 1024,
					'maximum' => self::MAX_BYTES,
				),
				'assercoes'      => array(
					'type'     => 'array',
					'maxItems' => 12,
					'items'    => array(
						'type'                 => 'object',
						'additionalProperties' => false,
						'required'             => array( 'tipo', 'valor' ),
						'properties'           => array(
							'tipo'  => array(
								'type' => 'string',
								'enum' => array( 'status', 'cabecalho', 'contem', 'nao_contem' ),
							),
							'nome'  => array(
								'type'      => 'string',
								'maxLength' => 64,
							),
							'valor' => array(
								'type'      => array( 'string', 'integer' ),
								'maxLength' => 512,
							),
						),
					),
				),
			),
		);
		$entrada['properties']['recurso'] = array(
			'type' => 'string',
			'enum' => array( 'cobertura' ),
		);
		$base                             = array(
			'category'            => F3BASE_PREFIXO,
			'permission_callback' => static fn(): bool => current_user_can( 'manage_options' ),
			'output_schema'       => array(
				'type'                 => 'object',
				'additionalProperties' => true,
			),
			'meta'                => array(
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
				'annotations'  => array(
					'readonly'    => false,
					'destructive' => false,
					'idempotent'  => false,
				),
			),
		);
		F3Base_Release_1103::registrar_ability(
			'f3base/publicacao-verificar',
			array_merge(
				$base,
				array(
					'label'            => 'Verificar publicação',
					'description'      => 'Sonda administrativa GET/HEAD de recursos permitidos no próprio site, com asserções e evidência datada. Não publica arquivos nem reconcilia robots. Cache: apenas artefato público existente conforme perfil.',
					'input_schema'     => $entrada,
					'execute_callback' => array( __CLASS__, 'verificar' ),
				)
			)
		);
		$base['meta']['annotations'] = array(
			'readonly'    => true,
			'destructive' => false,
			'idempotent'  => true,
		);
		F3Base_Release_1103::registrar_ability(
			'f3base/publicacao-ler',
			array_merge(
				$base,
				array(
					'label'            => 'Ler estado da publicação',
					'description'      => 'Consulta configuração e evidências já armazenadas, sem sondar ou reconciliar.',
					'input_schema'     => array(
						'type'                 => 'object',
						'additionalProperties' => false,
						'properties'           => array(
							'caminho' => array(
								'type'      => 'string',
								'maxLength' => 2000,
							),
						),
					),
					'execute_callback' => static fn( $e = null ) => current_user_can( 'manage_options' ) ? ( ! empty( $e['caminho'] ) ? self::consultar( (array) $e ) : self::resumo() ) : new WP_Error( 'f3base_sem_permissao', 'Sem permissão.' ),
				)
			)
		);
	}
}
