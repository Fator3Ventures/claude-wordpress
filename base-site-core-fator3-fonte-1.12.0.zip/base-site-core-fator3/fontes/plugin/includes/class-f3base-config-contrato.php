<?php
/** Contrato consultável do dono das opções; derivado do catálogo e do registro do Core. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class F3Base_Config_Contrato {
	public const VERSAO     = '1.7.0';
	public const HABILIDADE = 'f3base/config-core-contrato-v1';
	public const VERIFICAR  = 'f3base/config-core-verificar';

	/** Configuração inclui chaves estruturais consultáveis; estado de execução não é uma preferência. */
	public static function nomes(): array {
		return array_keys( array_filter( F3Base_Options::catalogo(), static fn( array $d ) => empty( $d['estado_execucao'] ) ) );
	}

	/** Schema canônico do valor normalizado. Enums dinâmicos vêm dos mesmos callbacks da tela. */
	public static function schema_valor( array $d ): array {
		$tipo   = $d['tipo'] ?? ( $d['campo'] ?? '' );
		$padrao = $d['padrao'] ?? null;
		if ( '' === $tipo ) {
			$tipo = is_bool( $padrao ) ? 'booleano' : ( is_int( $padrao ) ? 'inteiro' : ( is_array( $padrao ) ? 'lista' : 'texto' ) ); }
		if ( 'grupo' === $tipo ) {
			$props  = array();
			$campos = $d['subcampos'] ?? array();
			foreach ( is_array( $padrao ) ? $padrao : array() as $chave => $valor ) {
				$campos[ $chave ] = ( $campos[ $chave ] ?? array() ) + array( 'padrao' => $valor ); }
			foreach ( $campos as $chave => $campo ) {
				$props[ $chave ] = self::schema_valor( $campo ); }
			$s = array(
				'type'                 => 'object',
				'additionalProperties' => true,
			);
			if ( $props ) {
				$s['properties'] = $props; }
		} elseif ( 'booleano' === $tipo ) {
			$s = array( 'type' => 'boolean' ); } elseif ( 'inteiro' === $tipo ) {
			$s = array( 'type' => 'integer' ); } elseif ( in_array( $tipo, array( 'lista', 'lista_texto', 'multiescolha', 'tipos_conteudo', 'multiselect', 'json', 'emails', 'linhas', 'blocos' ), true ) ) {
						$s = array(
							'type'  => 'array',
							'items' => array( 'type' => 'string' ),
						);
			} else {
				$s = array( 'type' => 'string' ); }
			$opcoes = self::opcoes( $d );
			if ( $opcoes ) {
				if ( 'array' === $s['type'] ) {
					$s['items']['enum'] = array_map( 'strval', array_keys( $opcoes ) );
					$s['uniqueItems']   = true; } else {
								$s['enum'] = array_map( 'strval', array_keys( $opcoes ) ); }
			} elseif ( is_callable( $d['opcoes_callback'] ?? null ) ) {
				$s['maxItems'] = 0; }
			foreach ( array(
				'minimo' => 'minimum',
				'maximo' => 'maximum',
			) as $de => $para ) {
				if ( isset( $d[ $de ] ) ) {
						$s[ $para ] = $d[ $de ]; }
			}
			return array_replace_recursive( $s, $d['schema_config'] ?? array() );
	}

	/** Aceitação histórica da entrada MCP: valores fora dos limites seguem a recusa/normalização do dono. */
	public static function schema_entrada( array $d ): array {
		if ( isset( $d['schema_entrada'] ) ) {
			return $d['schema_entrada']; }
		$tipo = $d['tipo'] ?? ( $d['campo'] ?? 'texto' );
		if ( 'grupo' === $tipo ) {
			$s     = array(
				'type'                 => 'object',
				'additionalProperties' => true,
			);
			$props = array();
			foreach ( $d['subcampos'] ?? array() as $k => $campo ) {
				$props[ $k ] = self::schema_entrada( $campo ); }
			if ( $props ) {
				$s['properties'] = $props;
			} return $s;
		}
		if ( 'booleano' === $tipo ) {
			return array( 'type' => 'boolean' ); }
		if ( 'inteiro' === $tipo ) {
			return array( 'type' => 'integer' ); }
		return array( 'type' => in_array( $tipo, array( 'lista', 'lista_texto', 'multiescolha', 'tipos_conteudo', 'multiselect', 'json', 'emails', 'linhas', 'blocos' ), true ) ? 'array' : 'string' );
	}

	private static function opcoes( array $d ): array {
		$r = is_callable( $d['opcoes_callback'] ?? null ) ? call_user_func( $d['opcoes_callback'] ) : ( $d['opcoes'] ?? array() );
		return is_array( $r ) ? $r : array();
	}
	public static function campos( array $d ): array {
		$r      = array_intersect_key( $d, array_flip( array( 'rotulo', 'descricao', 'campo', 'tipo', 'impacto', 'exemplo' ) ) );
		$opcoes = self::opcoes( $d );
		if ( $opcoes ) {
			$r['opcoes'] = $opcoes; }
		if ( ! empty( $d['subcampos'] ) ) {
			foreach ( $d['subcampos'] as $k => $campo ) {
				$r['subcampos'][ $k ] = self::campos( $campo ); }
		}
		return $r;
	}
	public static function visivel( string $nome, $valor ) {
		return F3Base_Options::e_segredo( $nome ) ? array(
			'configurado' => '' !== (string) $valor,
			'mascarado'   => true,
		) : $valor;
	}

	/** Metadados de módulos não são prova de funcionamento no navegador ou no fornecedor. */
	public static function modulos( string $nome ): array {
		$r = array();
		foreach ( F3Base_Registro::modulos() as $modulo ) {
			if ( in_array( $nome, $modulo->options_que_controlam(), true ) ) {
				$r[] = array(
					'id'           => $modulo->id(),
					'nome'         => $modulo->nome(),
					'dependencias' => $modulo->dependencias(),
					'verificacao'  => 'observar_no_contexto_do_modulo',
				);
			}
		}
		return $r;
	}

	public static function consultar( $entrada = null ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'sem_permissao',
			); }
		if ( null !== $entrada && ! is_array( $entrada ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'entrada_invalida',
			); }
		$erro = F3Base_Config_Consultas::validar( $entrada, array( 'nome' ) );
		if ( '' !== $erro ) {
			return array(
				'ok'     => false,
				'codigo' => $erro,
			); }
		$entrada      = $entrada ?? array();
		$selecionadas = F3Base_Config_Consultas::nomes_por_assuntos( $entrada );
		$pedido       = $entrada['nome'] ?? '';
		if ( ! is_string( $pedido ) || ( '' !== $pedido && ! in_array( $pedido, self::nomes(), true ) ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'option_nao_configuravel',
			); }
		$r = array();
		foreach ( self::nomes() as $nome ) {
			if ( ( '' !== $pedido && $pedido !== $nome ) || ( null !== $selecionadas && ! in_array( $nome, $selecionadas, true ) ) ) {
				continue; }
			$d        = F3Base_Options::declaracao( $nome );
			$foto     = F3Base_Options::fotografia( $nome );
			$operavel = F3Base_Options::operavel( $nome );
			if ( ! empty( $foto['erro'] ) ) {
				return array(
					'ok'     => false,
					'codigo' => 'leitura_falhou',
				); }
			$procedencia = F3Base_Options::procedencia( $nome, $foto );
			if ( ! empty( $entrada['compacto'] ) ) {
				$item                 = array(
					'nome'     => $nome,
					'valor'    => self::visivel( $nome, $foto['valor'] ),
					'revisao'  => $foto['revisao'],
					'origem'   => $procedencia['origem'],
					'operavel' => $operavel,
					'contrato' => self::HABILIDADE,
				);
				$item['verification'] = array_intersect_key( F3Base_Options::verificar_configuracao( $nome, $foto['valor'] ), array_flip( array( 'status', 'codigo', 'checked_at', 'scope' ) ) );
				if ( F3Base_Config_Consultas::incluir( $entrada, 'procedencia' ) ) {
					$item['procedencia'] = $procedencia; }
				$r[] = $item;
				continue;
			}
			$r[] = array(
				'nome'                 => $nome,
				'dono'                 => 'base-site-core-fator3',
				'rotulo'               => (string) $d['rotulo'],
				'descricao'            => (string) $d['descricao'],
				'schema'               => self::schema_valor( $d ),
				'schema_entrada'       => self::schema_entrada( $d ),
				'padrao'               => self::visivel( $nome, $d['padrao'] ),
				'valor'                => self::visivel( $nome, $foto['valor'] ),
				'existe_no_banco'      => $foto['existe'],
				'revisao'              => $foto['revisao'],
				'origem'               => $procedencia['origem'],
				'procedencia'          => $procedencia,
				'segredo'              => F3Base_Options::e_segredo( $nome ),
				'operacoes_permitidas' => $operavel ? array( 'consultar', 'ler', 'simular', 'gravar', 'verificar' ) : array( 'consultar', 'verificar' ),
				'escrita'              => array(
					'permitida'              => $operavel,
					'modo'                   => 'valor_completo',
					'mesclar_permitido'      => $operavel && 'grupo' === ( $d['campo'] ?? '' ),
					'revisao_obrigatoria'    => true,
					'origens_php'            => array( F3Base_Options::ORIGEM_IMPLANTADOR, F3Base_Options::ORIGEM_MANUAL ),
					'codigo_recusa'          => $operavel ? '' : 'option_nao_operavel',
					'api_php'                => 'F3Base_Options::gravar',
					'recusa_do_dono_e_final' => true,
				),
				'validacao'            => array(
					'recusa_declarada'  => is_callable( $d['recusa'] ?? null ),
					'normaliza'         => true,
					'ajuste_na_escrita' => is_callable( $d['na_escrita'] ?? null ),
					'regra'             => 'O schema descreve o valor canônico e seus limites. Entradas compatíveis com schema_entrada passam pela recusa e normalização existentes; simule para conferir o valor resultante.',
				),
				'efeito_sincrono'      => isset( $d['apos_escrita'] ),
				'cache_de_pagina'      => F3Base_Cache_Pagina::afeta( $nome ),
				'verification'         => F3Base_Options::verificar_configuracao( $nome, $foto['valor'] ),
				'dependencias'         => $d['dependencias_config'] ?? array(),
				'modulos'              => self::modulos( $nome ),
				'campos'               => self::campos( $d ),
			);
		}
		$resposta = array(
			'ok'                          => true,
			'contract_version'            => self::VERSAO,
			'plugin'                      => 'base-site-core-fator3',
			'plugin_version'              => F3BASE_PLUGIN_VERSAO,
			'scope'                       => 'site_configuration',
			'capability'                  => 'manage_options',
			'operacoes'                   => array(
				'contrato'  => self::HABILIDADE,
				'ler'       => 'f3base/config-core-ler',
				'simular'   => 'f3base/config-core-escrever',
				'gravar'    => 'f3base/config-core-escrever',
				'verificar' => self::VERIFICAR,
			),
			'limites_operacionais'        => array(
				'max_trabalhos'    => F3Base_Operacao::MAX_TRABALHOS,
				'max_segundos'     => F3Base_Operacao::MAX_SEGUNDOS,
				'reserva_segundos' => F3Base_Operacao::LEASE_SEGUNDOS,
				'prazo'            => 'Limite conferido entre lotes; requisição iniciada conserva seu timeout próprio.',
			),
			'opcoes'                      => $r,
			'configuracao_do_implantador' => array(
				'ler'            => 'f3base/config-ler',
				'escrever'       => 'f3base/config-escrever',
				'scope'          => 'installer_json',
				'aplica_no_site' => false,
			),
		);
		if ( F3Base_Config_Consultas::incluir( $entrada, 'integracoes' ) ) {
			$resposta['integracoes'] = F3Base_Config_Consultas::integracoes( ! empty( $entrada['compacto'] ) ); }
		if ( F3Base_Config_Consultas::incluir( $entrada, 'mudancas' ) ) {
			$resposta['mudancas'] = F3Base_Config_Consultas::mudancas( $entrada ); }
		if ( F3Base_Config_Consultas::incluir( $entrada, 'agenda' ) ) {
			$resposta['agenda'] = F3Base_Operacao::agenda(); }
		if ( F3Base_Config_Consultas::incluir( $entrada, 'saude' ) ) {
			$resposta['saude'] = F3Base_Saude::resumo(); }
		return $resposta;
	}

	/** Consulta do comportamento sem regravar a preferência ou repetir seu efeito. */
	public static function verificar( $entrada = null ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'sem_permissao',
			); }
		$nome = is_array( $entrada ) && is_string( $entrada['nome'] ?? null ) ? $entrada['nome'] : '';
		if ( ! in_array( $nome, self::nomes(), true ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'option_nao_configuravel',
			); }
		$foto = F3Base_Options::fotografia( $nome );
		if ( ! empty( $foto['erro'] ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'leitura_falhou',
			); }
		if ( isset( $entrada['revisao_esperada'] ) && ( ! is_string( $entrada['revisao_esperada'] ) || ! hash_equals( $foto['revisao'], $entrada['revisao_esperada'] ) ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'conflito',
			); }
		$acao = $entrada['acao'] ?? 'consultar';
		if ( ! is_string( $acao ) || ! in_array( $acao, array( 'consultar', 'verificar_publico', 'atualizar_cache' ), true ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'acao_invalida',
			); }
		$efeito = null;
		$sonda  = null;
		if ( 'consultar' !== $acao ) {
			if ( ! F3Base_Cache_Pagina::afeta( $nome ) ) {
				return array(
					'ok'     => false,
					'codigo' => 'acao_nao_aplicavel',
				); }
			if ( ! isset( $entrada['revisao_esperada'] ) ) {
				return array(
					'ok'     => false,
					'codigo' => 'revisao_obrigatoria',
				); }
			if ( 'atualizar_cache' === $acao ) {
				if ( ! F3Base_Cache_Pagina::solicitar() ) {
					return array(
						'ok'     => false,
						'codigo' => 'agendamento_falhou',
					); }
				$efeito = F3Base_Cache_Pagina::limpar();
			}
			$sonda = F3Base_Cache_Pagina::verificar_publico( $acao );
		}

		$v = F3Base_Options::verificar_configuracao( $nome, $foto['valor'] );
		if ( ! hash_equals( $foto['revisao'], F3Base_Options::revisao( $nome ) ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'conflito',
				'motivo' => 'A preferência mudou durante a consulta.',
			); }
		return array(
			'ok'                    => true,
			'nome'                  => $nome,
			'revisao'               => $foto['revisao'],
			'existe_no_banco'       => $foto['existe'],
			'verification'          => $v,
			'modulos'               => self::modulos( $nome ),
			'configuracao_alterada' => false,
			'efeito_repetido'       => 'atualizar_cache' === $acao,
			'efeito_cache'          => $efeito,
			'sonda'                 => $sonda,
			'cache'                 => F3Base_Cache_Pagina::resumo(),
		);
	}

	/** Tipos JSON aceitos pelo WordPress, preservando strings numéricas e marcadores de segredo como objetos. */
	public static function schema_dado( string $descricao ): array {
		return array(
			'type'        => array( 'string', 'integer', 'number', 'boolean', 'array', 'object', 'null' ),
			'description' => $descricao,
		);
	}
	public static function schema_resposta(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'ok'                          => array( 'type' => 'boolean' ),
				'codigo'                      => array( 'type' => 'string' ),
				'contract_version'            => array( 'type' => 'string' ),
				'plugin'                      => array( 'type' => 'string' ),
				'plugin_version'              => array( 'type' => 'string' ),
				'scope'                       => array( 'type' => 'string' ),
				'capability'                  => array( 'type' => 'string' ),
				'operacoes'                   => array( 'type' => 'object' ),
				'integracoes'                 => array(
					'type'       => 'object',
					'properties' => array(
						'cache'      => self::schema_cache(),
						'publicacao' => array( 'type' => 'object' ),
					),
				),
				'configuracao_do_implantador' => array( 'type' => 'object' ),
				'opcoes'                      => array(
					'type'  => 'array',
					'items' => array(
						'type'       => 'object',
						'properties' => array(
							'nome'                 => array( 'type' => 'string' ),
							'dono'                 => array( 'type' => 'string' ),
							'schema'               => array( 'type' => 'object' ),
							'schema_entrada'       => array( 'type' => 'object' ),
							'valor'                => self::schema_dado( 'Valor atual normalizado, ou objeto {configurado: boolean, mascarado: true} para segredo.' ),
							'padrao'               => self::schema_dado( 'Padrão do catálogo, ou marcador para segredo.' ),
							'existe_no_banco'      => array( 'type' => 'boolean' ),
							'revisao'              => array( 'type' => 'string' ),
							'origem'               => array( 'type' => 'string' ),
							'operacoes_permitidas' => array(
								'type'  => 'array',
								'items' => array( 'type' => 'string' ),
							),
							'escrita'              => array( 'type' => 'object' ),
							'dependencias'         => array( 'type' => 'array' ),
							'modulos'              => array( 'type' => 'array' ),
							'verification'         => self::schema_verificacao(),
							'efeito_sincrono'      => array( 'type' => 'boolean' ),
							'cache_de_pagina'      => array( 'type' => 'boolean' ),
						),
					),
				),
			),
		);
	}
	public static function schema_prova_cache(): array {
		$p = array();
		foreach ( array( 'id', 'origem', 'geracao', 'contexto', 'plugin_version', 'status', 'codigo', 'motivo', 'url', 'modo', 'scope' ) as $k ) {
			$p[ $k ] = array( 'type' => 'string' ); }
		foreach ( array( 'checked_at', 'iniciado_em', 'concluido_em' ) as $k ) {
			$p[ $k ] = array( 'type' => 'integer' ); }
		foreach ( array( 'hit', 'persisted', 'pending' ) as $k ) {
			$p[ $k ] = array( 'type' => 'boolean' ); }
		$p['cabecalhos'] = array(
			'type'                 => 'object',
			'additionalProperties' => array( 'type' => 'string' ),
		);
		$p['faltantes']  = array(
			'type'  => 'array',
			'items' => array( 'type' => 'string' ),
		);
		$p['tokens']     = array( 'type' => 'object' );
		return array(
			'type'       => 'object',
			'properties' => $p,
		);
	}
	public static function schema_cache(): array {
		$registro = array(
			'type'       => 'object',
			'properties' => array(),
		);
		foreach ( array( 'id', 'origem', 'geracao', 'contexto', 'codigo', 'status' ) as $k ) {
			$registro['properties'][ $k ] = array( 'type' => 'string' ); }
		foreach ( array( 'iniciado_em', 'concluido_em', 'em', 'proxima_tentativa', 'falhas' ) as $k ) {
			$registro['properties'][ $k ] = array( 'type' => 'integer' ); }
		return array(
			'type'       => 'object',
			'properties' => array(
				'perfil'               => array( 'type' => 'object' ),
				'requisitos'           => array( 'type' => 'object' ),
				'estado'               => array( 'type' => 'object' ),
				'tokens'               => array( 'type' => 'object' ),
				'evidencia'            => self::schema_prova_cache(),
				'verification'         => self::schema_verificacao(),
				'historico'            => array(
					'type'       => 'object',
					'properties' => array(
						'ultima_tentativa'                => self::schema_prova_cache(),
						'ultimo_sucesso'                  => self::schema_prova_cache(),
						'ultima_verificacao'              => array( 'type' => 'integer' ),
						'ultima_verificacao_bem_sucedida' => array( 'type' => 'integer' ),
						'valida_geracao_atual'            => array( 'type' => 'boolean' ),
						'migracao'                        => $registro,
						'limpeza'                         => $registro,
					),
				),
				'agendamento'          => array(
					'type'       => 'object',
					'properties' => array(
						'codigo'              => array( 'type' => 'string' ),
						'orientacao'          => array( 'type' => 'string' ),
						'proxima_verificacao' => array( 'type' => 'integer' ),
						'atraso_segundos'     => array( 'type' => 'integer' ),
						'disparo_por_visitas' => array( 'type' => 'boolean' ),
						'ultima_execucao'     => $registro,
						'ultimo_agendamento'  => $registro,
					),
				),
				'exclusoes_requeridas' => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
				'proxima_verificacao'  => array( 'type' => 'integer' ),
				'limite_token'         => array( 'type' => 'object' ),
			),
		);
	}
	public static function schema_verificacao(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'status'     => array(
					'type' => 'string',
					'enum' => array( 'not_attempted', 'not_required', 'pending', 'verified', 'failed' ),
				),
				'pending'    => array( 'type' => 'boolean' ),
				'scope'      => array( 'type' => 'string' ),
				'codigo'     => array( 'type' => 'string' ),
				'motivo'     => array( 'type' => 'string' ),
				'checked_at' => array( 'type' => 'integer' ),
			),
		);
	}
	public static function schema_gravacao(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'validacao'    => array(
					'type'  => 'array',
					'items' => array(
						'type'       => 'object',
						'properties' => array(
							'campo'  => array( 'type' => 'string' ),
							'codigo' => array( 'type' => 'string' ),
							'motivo' => array( 'type' => 'string' ),
						),
					),
				),
				'ok'           => array(
					'type'        => 'boolean',
					'description' => 'Compatibilidade: persistência e efeito síncrono bem-sucedidos. Em simulação, indica somente proposta aceita. Não comprova comportamento público.',
				),
				'persisted'    => array(
					'type'        => 'boolean',
					'description' => 'O valor solicitado, após normalização, foi gravado e confirmado. False na simulação.',
				),
				'effect'       => array(
					'type'       => 'object',
					'properties' => array(
						'status'  => array(
							'type' => 'string',
							'enum' => array( 'not_attempted', 'not_required', 'applied', 'failed' ),
						),
						'applied' => array( 'type' => array( 'boolean', 'null' ) ),
						'codigo'  => array( 'type' => 'string' ),
						'motivo'  => array( 'type' => 'string' ),
					),
				),
				'verification' => self::schema_verificacao(),
				'simulado'     => array( 'type' => 'boolean' ),
				'lido'         => self::schema_dado( 'Leitura após a operação; segredos mascarados.' ),
				'audit'        => array(
					'type'       => 'object',
					'properties' => array(
						'status'    => array( 'type' => 'string' ),
						'persisted' => array( 'type' => array( 'boolean', 'null' ) ),
						'codigo'    => array( 'type' => 'string' ),
						'revisao'   => array( 'type' => 'string' ),
					),
				),
				'codigo'       => array( 'type' => 'string' ),
				'motivo'       => array( 'type' => 'string' ),
				'revisao'      => array( 'type' => 'string' ),
			),
		);
	}
}
