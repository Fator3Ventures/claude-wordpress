<?php
/** Atualização aditiva 1.12.0; não importa CF7/Flamingo. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Release_1120 {
    const OPTION = 'f3base_release_1120';
    public static function iniciar(): void {
        add_action( 'init', array( __CLASS__, 'atualizar' ), 7 );
        add_action( 'init', array( F3Base_Leads_Reparo::class, 'automatico' ), 8 );
        add_action( 'wp_abilities_api_init', array( __CLASS__, 'abilities' ) );
        add_action( 'admin_init', static function (): void {
            if ( ( $_GET['page'] ?? '' ) === 'f3base-operacao' && current_user_can( 'manage_options' ) && 'GET' === ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) {
                wp_safe_redirect( admin_url( 'admin.php?page=' . F3Base_Admin_Tela::SLUG . '&aba=operacao' ) ); exit;
            }
        } );
        add_action( F3Base_Leads_Notificacoes::EVENTO, array( F3Base_Resposta_Visitante::class, 'processar_pendentes' ) );
    }
    public static function catalogo( array $c ): array {
        foreach ( array( self::OPTION, 'f3base_reparo_1120', 'f3base_1120_trava' ) as $n ) {
            $c[$n] = array( 'rotulo' => $n, 'descricao' => 'Estado da atualização 1.12.0; sem importação legada.', 'operavel' => false, 'estado_execucao' => true, 'campo' => 'grupo', 'padrao' => array(), 'autoload' => false, 'sanitiza' => array( F3Base_Release_1103::class, 'identidade' ) );
        }
        $c['f3base_politica_canal']['padrao'] = true;
        $c['f3base_politica_canal']['descricao'] = 'Gestão autenticada da política pelo canal, habilitada por padrão; alterações exigem manage_options e revisão.';
        $c['f3base_contato']['rotulo'] = 'Contato, avisos e WhatsApp';
        $c['f3base_contato']['descricao'] = 'Defina os avisos da equipe, o destino do WhatsApp e a instrumentação dos botões.';
        $labels = array(
            'email_leads' => array( 'Quem recebe os avisos internos (até cinco)', 'E-mails da equipe, um por linha. A lista do formulário prevalece quando definida. Sem destinatário, o contato é salvo e o aviso fica desconfigurado.', 'registro' ),
            'avisar_por_clique' => array( 'Enviar aviso interno de clique', 'Avisa sobre clique registrado, inclusive sem nome/e-mail. Desligar mantém o registro. Até 30 avisos por hora; pendentes entram no resumo horário.', 'registro' ),
            'avisar_por_formulario' => array( 'Enviar aviso interno de formulário recebido', 'Envia aviso após salvar um envio aceito. Falha no e-mail mantém o contato. A lista de destinatários pode ser definida em cada formulário.', 'registro' ),
            'classes_cta' => array( 'Classes adicionais de botões de contato', 'Classes CSS sem ponto, uma por linha; exemplo: f3capital-acao-whatsapp. A marcação não altera o link e o método segue o destino.', 'instrumentacao' ),
        );
        foreach ( $c['f3base_contato']['subcampos'] as $k => &$sub ) {
            $spec = $labels[$k] ?? null;
            $sub['grupo_visual'] = $spec[2] ?? 'whatsapp';
            if ( $spec ) { $sub['rotulo'] = $spec[0]; $sub['descricao'] = $spec[1]; $sub['impacto'] = $spec[1]; }
        } unset( $sub );
        $c['f3base_contato']['subcampos']['email_leads']['tipo'] = 'emails';
        $c['f3base_contato']['subcampos']['classes_cta']['tipo'] = 'linhas';
        $c['f3base_llms']['subcampos']['blocos_interface']['tipo'] = 'blocos';
        $c['f3base_llms']['subcampos']['blocos_interface']['descricao'] = 'Selecione os blocos de interface que serão omitidos na conversão Markdown. Valores já salvos são preservados quando o bloco está indisponível.';
        foreach ( $c as &$declaracao ) {
            foreach ( $declaracao['subcampos'] ?? array() as $k => $sub ) {
                if ( 'select' === ( $sub['tipo'] ?? '' ) ) { $declaracao['subcampos'][$k]['tipo'] = 'enum'; }
            }
        } unset( $declaracao );
        return $c;
    }
    public static function atualizar(): array {
        $estado = F3Base_Options::ler( self::OPTION );
        if ( ! empty( $estado['concluido_em'] ) ) { return array( 'ok' => true, 'codigo' => 'atualizacao_ja_concluida' ); }
        global $wpdb;
        $lock = array( 'id' => wp_generate_uuid4(), 'expira' => time() + 90 );
        $ant = get_option( 'f3base_1120_trava' );
        if ( is_array( $ant ) && ( $ant['expira'] ?? 0 ) < time() ) {
            $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", 'f3base_1120_trava', maybe_serialize( $ant ) ) );
            wp_cache_delete( 'f3base_1120_trava', 'options' );
        }
        if ( ! add_option( 'f3base_1120_trava', $lock, '', false ) ) { return array( 'ok' => false, 'codigo' => 'atualizacao_em_execucao' ); }
        try {
            $estado = F3Base_Options::ler( self::OPTION );
            if ( ! empty( $estado['concluido_em'] ) ) { return array( 'ok' => true ); }
            if ( empty( $estado['passos'] ) ) {
                $lista = array_keys( array_filter( F3Base_Options::catalogo(), static fn( $d ) => ! empty( $d['operavel'] ) ) );
                $passos = array();
                foreach ( array( 'f3base_politica_canal' => true, F3Base_Options::OPTION_OPERAVEIS => $lista ) as $n => $valor ) {
                    $f = F3Base_Options::fotografia( $n );
                    if ( $f['erro'] ) { return array( 'ok' => false, 'codigo' => 'leitura_indisponivel' ); }
                    $passos[$n] = array( 'antes' => $f['valor'], 'revisao_antes' => $f['revisao'], 'depois' => $valor );
                }
                $estado = array( 'versao' => '1.12.0', 'origem' => 'atualizacao_de_versao', 'iniciado_em' => time(), 'passos' => $passos );
                $r = F3Base_Options::atualizar_estado( self::OPTION, static fn() => $estado );
                if ( empty( $r['persisted'] ) ) { return array( 'ok' => false, 'codigo' => 'checkpoint_falhou' ); }
            }
            foreach ( $estado['passos'] as $n => $passo ) {
                if ( ! empty( $passo['confirmado_em'] ) ) { continue; }
                $f = F3Base_Options::fotografia( $n );
                if ( $f['valor'] !== $passo['depois'] ) {
                    if ( ! hash_equals( $passo['revisao_antes'], $f['revisao'] ) ) {
                        F3Base_Options::atualizar_estado( self::OPTION, static function ( $s ) use ( $n ) { $s['codigo'] = 'conflito'; $s['conflito_option'] = $n; return $s; } );
                        return array( 'ok' => false, 'codigo' => 'conflito', 'option' => $n );
                    }
                    $r = F3Base_Options::gravar( $n, $passo['depois'], F3Base_Options::ORIGEM_PADRAO, $f['revisao'] );
                    if ( empty( $r['persisted'] ) ) { return $r; }
                }
                $r = F3Base_Options::atualizar_estado( self::OPTION, static function ( $s ) use ( $n ) { $s['passos'][$n]['confirmado_em'] = time(); return $s; } );
                if ( empty( $r['persisted'] ) ) { return array( 'ok' => false, 'codigo' => 'checkpoint_falhou' ); }
            }
            if ( ! F3Base_Leads_Repositorio::instalar() ) { return array( 'ok' => false, 'codigo' => 'schema_pendente' ); }
            $privado = F3Base_Arquivos_Privados::provisionar();
            return F3Base_Options::atualizar_estado( self::OPTION, static function ( $s ) use ( $privado ) { $s['concluido_em'] = time(); $s['codigo'] = 'atualizacao_concluida'; $s['diretorio'] = $privado; return $s; } );
        } finally {
            $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", 'f3base_1120_trava', maybe_serialize( $lock ) ) );
            wp_cache_delete( 'f3base_1120_trava', 'options' );
        }
    }
    public static function abilities(): void {
        F3Base_Release_1103::ability( 'documentacao-ler', 'Índice e leitura paginada da documentação instalada do Core', array( __CLASS__, 'documentacao' ), array( 'arquivo' => array( 'type' => 'string' ), 'linha' => array( 'type' => 'integer', 'minimum' => 1 ), 'limite' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 200 ) ) );
        F3Base_Leads_Reparo::registrar();
        F3Base_Resposta_Visitante::registrar();
        F3Base_Release_1103::ability( 'arquivos-privados-preparar', 'Criar e testar diretório privado configurado, sem enviar mensagens', static function () { return F3Base_Arquivos_Privados::provisionar(); }, array(), array(), false );
    }
    public static function documentacao( array $e = array() ): array {
        $arquivos = array( 'DOCUMENTACAO.md', 'README.md', 'CHANGELOG.md', 'CONTRACTS.md', 'docs/CONFIGURACAO.md', 'docs/LEADS-E-FORMULARIOS.md', 'docs/OPERACAO-E-RECUPERACAO.md', 'docs/VALIDACAO.md', 'docs/REFERENCIA-CATALOGO.md' );
        if ( empty( $e['arquivo'] ) ) { return array( 'ok' => true, 'versao' => F3BASE_PLUGIN_VERSAO, 'indice' => 'DOCUMENTACAO.md', 'arquivos' => $arquivos, 'base' => plugin_basename( F3BASE_PLUGIN_ARQUIVO ), 'ability' => 'f3base/documentacao-ler' ); }
        if ( ! in_array( $e['arquivo'], $arquivos, true ) ) { return array( 'ok' => false, 'codigo' => 'documento_nao_catalogado' ); }
        $p = F3BASE_PLUGIN_DIR . $e['arquivo'];
        if ( ! is_readable( $p ) || filesize( $p ) > 524288 ) { return array( 'ok' => false, 'codigo' => 'documento_indisponivel' ); }
        $lines = file( $p, FILE_IGNORE_NEW_LINES );
        $inicio = max( 1, (int) ( $e['linha'] ?? 1 ) ); $limite = max( 1, min( 200, (int) ( $e['limite'] ?? 120 ) ) );
        return array( 'ok' => true, 'versao' => F3BASE_PLUGIN_VERSAO, 'arquivo' => $e['arquivo'], 'sha256' => hash_file( 'sha256', $p ), 'linha' => $inicio, 'total_linhas' => count( $lines ), 'texto' => implode( "\n", array_slice( $lines, $inicio - 1, $limite ) ), 'proxima_linha' => $inicio + $limite <= count( $lines ) ? $inicio + $limite : null );
    }
}
