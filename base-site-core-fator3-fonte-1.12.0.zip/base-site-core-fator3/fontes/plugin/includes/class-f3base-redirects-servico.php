<?php
/** One proposal/validation service for administrative and ability writes. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Redirects_Servico {
	const OPTION                     = 'f3base_redirects';
	private static array $historicos = array();
	public static function schema_lista(): array {
		return array(
			'type'     => 'array',
			'maxItems' => 200,
			'items'    => array(
				'type'                 => 'object',
				'required'             => array( 'de' ),
				'properties'           => array(
					'de'     => array(
						'type'      => 'string',
						'maxLength' => 500,
					),
					'para'   => array(
						'type'      => 'string',
						'maxLength' => 500,
					),
					'status' => array(
						'type' => 'integer',
						'enum' => array( 301, 302, 307, 308, 410 ),
					),
				),
				'additionalProperties' => true,
			),
		); }
	public static function registrar(): void {
		$rev   = array(
			'type'    => 'string',
			'pattern' => '^[a-f0-9]{64}$',
		);
		$lista = array(
			'type'     => 'array',
			'items'    => array( 'type' => 'string' ),
			'maxItems' => 200,
		);
		F3Base_Release_1103::ability(
			'redirects-ler',
			'Ler redirects, revisão e restrições sem HTTP',
			array( __CLASS__, 'ler' ),
			array(
				'origens' => $lista,
				'pagina'  => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
				'limite'  => array(
					'type'    => 'integer',
					'minimum' => 1,
					'maximum' => 50,
				),
			)
		);
		F3Base_Release_1103::ability(
			'redirects-escrever',
			'Simular ou aplicar redirects com revisão e validação integral',
			array( __CLASS__, 'escrever' ),
			array(
				'operacao'               => array(
					'type' => 'string',
					'enum' => array( 'adicionar', 'alterar', 'remover', 'substituir_lista' ),
				),
				'pares'                  => self::schema_lista(),
				'origens'                => $lista,
				'revisao_esperada'       => $rev,
				'simular'                => array(
					'type'    => 'boolean',
					'default' => true,
				),
				'sobrepor_conteudo_vivo' => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'adiar_purga'            => array(
					'type'    => 'boolean',
					'default' => false,
				),
			),
			array( 'operacao' ),
			false
		);
		F3Base_Release_1103::ability(
			'redirects-verificar',
			'Consultar ou provar redirects por GET anônimo',
			array( __CLASS__, 'verificar' ),
			array(
				'acao'             => array(
					'type' => 'string',
					'enum' => array( 'consultar', 'verificar_publico' ),
				),
				'origens'          => $lista,
				'revisao_esperada' => $rev,
				'cursor'           => array(
					'type'    => 'integer',
					'minimum' => 0,
				),
			),
			array(),
			false
		);
		F3Base_Release_1103::ability(
			'redirects-planejar-base-taxonomia',
			'Enumerar pares exatos de termos públicos para uma base antiga',
			array( __CLASS__, 'taxonomia' ),
			array(
				'taxonomia'        => array( 'type' => 'string' ),
				'de'               => array( 'type' => 'string' ),
				'para'             => array( 'type' => 'string' ),
				'revisao_esperada' => $rev,
			),
			array( 'taxonomia', 'de', 'para', 'revisao_esperada' )
		);
	}
	public static function caminho( $s ): ?string {
		if ( ! is_string( $s ) || strlen( $s ) > 500 || '' === $s || '/' !== $s[0] || str_starts_with( $s, '//' ) || preg_match( '/%(?![0-9a-f]{2})/i', $s ) ) {
			return null; }
		$dec = rawurldecode( $s );
		foreach ( array( $s, $dec ) as $p ) {
			if ( preg_match( '/[\x00-\x20\x7f\\\\?#]/', $p ) || str_contains( $p, '//' ) || preg_match( '~(?:^|/)[.]{1,2}(?:/|$)~', $p ) || preg_match( '//u', $p ) !== 1 ) {
				return null; }
		}
		// Reject double encoding of delimiters/controls instead of disagreeing with the server.
		if ( preg_match( '/%[0-9a-f]{2}/i', $dec ) || preg_match( '/%(?:2f|5c)/i', $s ) ) {
			return null; }
		return '/' . trim( $dec, '/' );
	}
	public static function destino( $s ): ?string {
		if ( ! is_string( $s ) || strlen( $s ) > 500 || str_contains( $s, '#' ) ) {
			return null; }
		$partes = explode( '?', $s, 2 );
		$path   = self::caminho( $partes[0] );
		if ( null === $path ) {
			return null;
		} if ( '/' !== $path && str_ends_with( $partes[0], '/' ) ) {
			$path .= '/'; }
		if ( isset( $partes[1] ) ) {
			if ( preg_match( '/[\x00-\x20\x7f\\\\]/', $partes[1] ) || preg_match( '/[\x00-\x1f\x7f]/', rawurldecode( $partes[1] ) ) || preg_match( '/%(?![a-f0-9]{2})/i', $partes[1] ) ) {
				return null; }
			return $path . '?' . $partes[1];
		}
		return $path;
	}
	public static function local( string $path ): array {
		$url = home_url( $path );
		$id  = url_to_postid( $url );
		$p   = $id ? get_post( $id ) : null;
		if ( $p && 'publish' === $p->post_status && '' === $p->post_password && is_post_type_viewable( $p->post_type ) && self::caminho( (string) wp_parse_url( get_permalink( $p ), PHP_URL_PATH ) ) === self::caminho( (string) wp_parse_url( $url, PHP_URL_PATH ) ) ) {
			return array(
				'publico' => true,
				'tipo'    => 'post',
				'id'      => $id,
			); }
		if ( '/' === $path && F3Base_Llms::site_publico() ) {
			return array(
				'publico' => true,
				'tipo'    => 'home',
			); }
		foreach ( get_taxonomies( array( 'public' => true ) ) as $tax ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $tax,
					'hide_empty' => false,
					'number'     => 201,
				)
			);
			if ( is_wp_error( $terms ) ) {
				continue; }
			foreach ( $terms as $t ) {
				$u = get_term_link( $t );
				if ( ! is_wp_error( $u ) && untrailingslashit( $u ) === untrailingslashit( $url ) ) {
					return array(
						'publico' => true,
						'tipo'    => 'termo',
						'id'      => $t->term_id,
					); }
			}
		}
		return array(
			'publico' => false,
			'tipo'    => 'nao_identificado',
		);
	}
	/** Snapshot before persistence also covers descendants when an ancestor moves. */
	public static function antes_atualizar( int $id, array $dados ): void {
		$p = get_post( $id );
		if ( ! $p || ! is_post_type_viewable( $p->post_type ) || ( $p->post_name === ( $dados['post_name'] ?? $p->post_name ) && (int) $p->post_parent === (int) ( $dados['post_parent'] ?? $p->post_parent ) ) ) { // phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Comparison of runtime expressions; neither side is an assignable literal.
			return; }
		$posts = array( $p );
		if ( is_post_type_hierarchical( $p->post_type ) ) {
			$todos = get_posts(
				array(
					'post_type'        => $p->post_type,
					'post_status'      => 'any',
					'numberposts'      => -1,
					'orderby'          => 'ID',
					'order'            => 'ASC',
					'suppress_filters' => true,
				)
			);
			foreach ( $todos as $filho ) {
				if ( in_array( $id, array_map( 'intval', get_post_ancestors( $filho ) ), true ) ) {
					$posts[] = $filho; }
			}
		}
		$base = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
		foreach ( $posts as $post ) {
			if ( 'publish' !== $post->post_status || $post->post_password ) {
				continue; }
			$url  = get_permalink( $post );
			$path = (string) wp_parse_url( (string) $url, PHP_URL_PATH );
			if ( $path && ( ! $base || str_starts_with( $path, $base . '/' ) ) ) {
				$normal = self::caminho( substr( $path, strlen( $base ) ) );
				if ( $normal ) {
					self::$historicos[ $id ][ $post->ID ] = $normal; }
			}
		}
	}
	public static function historico( int $id, WP_Post $depois, WP_Post $antes ): void {
		if ( ! is_post_type_viewable( $antes->post_type ) || 'publish' !== $antes->post_status || ( $antes->post_name === $depois->post_name && $antes->post_parent === $depois->post_parent ) ) {
			return; }
		foreach ( self::$historicos[ $id ] ?? array() as $pid => $antigo ) {
			if ( ! in_array( $antigo, get_post_meta( $pid, '_f3base_old_path', false ), true ) ) {
				add_post_meta( $pid, '_f3base_old_path', $antigo, false ); }
		}
		unset( self::$historicos[ $id ] );
		$url  = get_permalink( $antes );
		$base = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
		$path = (string) wp_parse_url( (string) $url, PHP_URL_PATH );
		if ( $path && ( ! $base || str_starts_with( $path, $base . '/' ) ) ) {
			$path = self::caminho( substr( $path, strlen( $base ) ) );
			if ( $path && ! in_array( $path, get_post_meta( $id, '_f3base_old_path', false ), true ) ) {
				add_post_meta( $id, '_f3base_old_path', $path, false ); }
		}
		if ( $antes->post_name !== $depois->post_name && $antes->post_name ) {
			add_post_meta( $id, '_f3base_old_slug', $antes->post_name, false ); }
	}
	public static function validar( $pares ): array {
		$erros  = array();
		$avisos = array();
		$map    = array();
		$lista  = array();
		if ( ! is_array( $pares ) || ! array_is_list( $pares ) || count( $pares ) > 200 || strlen( (string) wp_json_encode( $pares ) ) > 131072 ) {
			return array(
				'ok'     => false,
				'erros'  => array( array( 'codigo' => 'lista_ou_limite_invalido' ) ),
				'avisos' => array(),
				'lista'  => array(),
			); }
		foreach ( $pares as $i => $p ) {
			if ( ! is_array( $p ) ) {
				$erros[] = array(
					'indice' => $i,
					'codigo' => 'par_invalido',
				);
				continue; }
			$de     = self::caminho( $p['de'] ?? null );
			$status = $p['status'] ?? 301;
			$para   = self::destino( $p['para'] ?? ( 410 === $status ? $de : null ) );
			if ( null === $de || null === $para || ! is_int( $status ) || ! in_array( $status, array( 301, 302, 307, 308, 410 ), true ) ) {
				$erros[] = array(
					'indice' => $i,
					'codigo' => 'caminho_ou_status_invalido',
				);
				continue; }
			if ( isset( $map[ $de ] ) ) {
				$erros[] = array(
					'indice' => $i,
					'codigo' => 'origem_duplicada',
					'de'     => $de,
				); }
			$map[ $de ]         = $p + array( 'status' => $status );
			$map[ $de ]['de']   = $de;
			$map[ $de ]['para'] = $para;
			$lista[]            = $map[ $de ];
		}
		foreach ( $map as $de => $p ) {
			$seen   = array();
			$at     = $de;
			$saltos = 0;
			while ( isset( $map[ $at ] ) && 410 !== $map[ $at ]['status'] ) {
				if ( isset( $seen[ $at ] ) ) {
					$erros[] = array(
						'codigo' => 'ciclo',
						'de'     => $de,
					);
					break; }
				if ( ++$saltos > 5 ) {
					$erros[] = array(
						'codigo' => 'cadeia_acima_do_limite',
						'de'     => $de,
					);
					break; }
				$seen[ $at ] = true;
				$at          = self::caminho( (string) wp_parse_url( $map[ $at ]['para'], PHP_URL_PATH ) ) ?? '';
			}
			if ( $saltos > 1 ) {
				$avisos[] = array(
					'codigo'        => 'cadeia',
					'de'            => $de,
					'destino_final' => $at,
					'saltos'        => $saltos,
				); }
		}
		return array(
			'ok'     => ! $erros,
			'lista'  => $lista,
			'erros'  => $erros,
			'avisos' => $avisos,
		);
	}
	public static function ler( $e = array() ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return self::erro( 'sem_permissao' ); }
		$foto  = F3Base_Options::fotografia( self::OPTION );
		$bruto = get_option( self::OPTION, array() );
		$v     = self::validar( $bruto );
		$pares = $v['lista'];
		if ( ! empty( $e['origens'] ) ) {
			$pares = array_values( array_filter( $pares, static fn( $p )=>in_array( $p['de'], $e['origens'], true ) ) ); }
		$limite = max( 1, min( 50, (int) ( $e['limite'] ?? 50 ) ) );
		$pagina = max( 1, (int) ( $e['pagina'] ?? 1 ) );
		return array(
			'ok'              => ! $foto['erro'],
			'pares'           => array_slice( $pares, ( $pagina - 1 ) * $limite, $limite ),
			'total'           => count( $pares ),
			'pagina'          => $pagina,
			'limite'          => $limite,
			'revisao'         => $foto['revisao'],
			'operavel'        => F3Base_Options::operavel( self::OPTION ),
			'motivo'          => F3Base_Release_1103::motivo_acesso( self::OPTION ),
			'diagnostico'     => $v['erros'],
			'avisos'          => $v['avisos'],
			'legado_invalido' => ! $v['ok'] ? $bruto : array(),
			'evidencia'       => self::evidencia(),
		);
	}
	public static function erro( string $codigo, array $mais = array() ): array {
		return array(
			'ok'        => false,
			'persisted' => false,
			'codigo'    => $codigo,
		) + $mais; }
	private static function observar( string $path, float $fim ): array {
		$url = home_url( $path );
		if ( ! wp_http_validate_url( $url ) ) {
			return array(
				'status' => 0,
				'codigo' => 'destino_nao_publico',
			); }
		$tempo = min( 3, $fim - microtime( true ) );
		if ( $tempo <= 0 ) {
			return array(
				'status' => 0,
				'codigo' => 'orcamento_esgotado',
			); }
		$r = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => $tempo,
				'redirection'         => 0,
				'limit_response_size' => 65536,
				'cookies'             => array(),
				'headers'             => array( 'Accept' => 'text/html' ),
			)
		);
		if ( is_wp_error( $r ) ) {
			return array(
				'status' => 0,
				'codigo' => 'http_inconclusivo',
			); }
		return array(
			'status'         => (int) wp_remote_retrieve_response_code( $r ),
			'location'       => (string) wp_remote_retrieve_header( $r, 'location' ),
			'x_redirect_by'  => (string) wp_remote_retrieve_header( $r, 'x-redirect-by' ),
			'em'             => time(),
			'sha256_prefixo' => hash( 'sha256', (string) wp_remote_retrieve_body( $r ) ),
		);
	}
	public static function escrever( $e ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return self::erro( 'sem_permissao' ); }
		if ( ! F3Base_Options::operavel( self::OPTION ) ) {
			return self::erro( F3Base_Release_1103::motivo_acesso( self::OPTION ) ); }
		if ( ! is_array( $e ) || array_diff( array_keys( $e ), array( 'operacao', 'pares', 'origens', 'revisao_esperada', 'simular', 'sobrepor_conteudo_vivo', 'adiar_purga' ) ) ) {
			return self::erro( 'entrada_invalida' ); }
		foreach ( array( 'simular', 'sobrepor_conteudo_vivo', 'adiar_purga' ) as $k ) {
			if ( isset( $e[ $k ] ) && ! is_bool( $e[ $k ] ) ) {
				return self::erro( 'entrada_invalida' ); }
		}
		$foto = F3Base_Options::fotografia( self::OPTION );
		$rev  = $e['revisao_esperada'] ?? ( ( $e['simular'] ?? true ) ? $foto['revisao'] : '' );
		if ( ! is_string( $rev ) || ! preg_match( '/^[a-f0-9]{64}$/D', $rev ) || ! hash_equals( $foto['revisao'], $rev ) ) {
			return self::erro( 'conflito' ); }
		$antes     = get_option( self::OPTION, array() );
		$val_antes = self::validar( $antes );
		$op        = $e['operacao'] ?? '';
		// An explicit full replacement can repair invalid legacy rules; deltas cannot hide them.
		if ( ! $val_antes['ok'] && 'substituir_lista' !== $op ) {
			return self::erro( 'legado_invalido_exige_lista_completa', array( 'diagnostico' => $val_antes['erros'] ) ); }
		$map = array_column( $val_antes['lista'], null, 'de' );
		if ( 'substituir_lista' === $op ) {
			$depois = $e['pares'] ?? null; } elseif ( in_array( $op, array( 'adicionar', 'alterar' ), true ) ) {
			$n = self::validar( $e['pares'] ?? null );
			if ( ! $n['ok'] || count( $n['lista'] ) > 10 ) {
				return self::erro( 'lote_invalido', array( 'validacao' => $n ) ); }
			foreach ( $n['lista'] as $p ) {
				if ( 'adicionar' === $op && isset( $map[ $p['de'] ] ) ) {
					return self::erro( 'origem_ja_declarada' );
				} if ( 'alterar' === $op && ! isset( $map[ $p['de'] ] ) ) {
					return self::erro( 'origem_nao_declarada' );
				} $map[ $p['de'] ] = array_replace( $map[ $p['de'] ] ?? array(), $p ); }
			$depois = array_values( $map );
			} elseif ( 'remover' === $op ) {
				if ( ! is_array( $e['origens'] ?? null ) || count( $e['origens'] ) > 10 ) {
					return self::erro( 'origens_invalidas' ); }
				foreach ( $e['origens'] as $p ) {
					$n = self::caminho( $p );
					if ( null === $n || ! isset( $map[ $n ] ) ) {
								return self::erro( 'origem_nao_declarada' );
					} unset( $map[ $n ] ); }
				$depois = array_values( $map );
			} else {
				return self::erro( 'operacao_invalida' ); }
			$v = self::validar( $depois );
			if ( ! $v['ok'] ) {
				return self::erro( 'validacao_recusada', array( 'validacao' => $v ) ); }
			$depois    = $v['lista'];
			$old       = array_column( $val_antes['lista'], null, 'de' );
			$novo      = array_column( $depois, null, 'de' );
			$alteradas = array();
			foreach ( $novo as $de => $p ) {
				if ( ( $old[ $de ] ?? null ) !== $p ) {
						$alteradas[ $de ] = $p; }
			}
			$removidas = array_diff_key( $old, $novo );
			$delta     = array(
				'alteradas' => array_values( $alteradas ),
				'removidas' => array_keys( $removidas ),
			);
			if ( count( $alteradas ) + count( $removidas ) > 10 ) {
				return self::erro( 'delta_acima_de_10', array( 'delta' => $delta ) ); }
			$provas = array();
			$fim    = microtime( true ) + 20;
			$req    = 0;
			foreach ( $alteradas as $de => $p ) {
				$orig = self::observar( $de, $fim );
				++$req;
				$provas[ $de ]['origem'] = $orig;
				if ( ! $orig['status'] || in_array( $orig['status'], array( 401, 403, 429, 500, 502, 503 ), true ) ) {
					$v['avisos'][] = array(
						'codigo' => 'origem_http_inconclusiva',
						'de'     => $de,
					); }
				if ( ( 200 === $orig['status'] || self::local( $de )['publico'] ) && empty( $e['sobrepor_conteudo_vivo'] ) ) {
					return self::erro( 'origem_viva', array( 'observacoes' => $provas ) ); }
				if ( in_array( $orig['status'], array( 301, 302, 303, 307, 308 ), true ) && ! isset( $old[ $de ] ) && ! in_array( strtolower( $orig['x_redirect_by'] ?? '' ), array( 'wordpress', 'base-site-core-fator3' ), true ) ) {
					return self::erro( 'precedencia_externa_a_resolver', array( 'observacoes' => $provas ) ); }
				if ( 410 === $p['status'] ) {
					continue; }
				$terminal = (string) wp_parse_url( $p['para'], PHP_URL_PATH );
				$saltos   = 0;
				while ( isset( $novo[ self::caminho( $terminal ) ] ) && ++$saltos <= 5 ) {
					if ( 410 === $novo[ self::caminho( $terminal ) ]['status'] ) {
						return self::erro( 'destino_terminal_removido' ); }
					$terminal = (string) wp_parse_url( $novo[ self::caminho( $terminal ) ]['para'], PHP_URL_PATH );
				}
				if ( $req >= 20 ) {
					return self::erro( 'orcamento_esgotado' ); }
				$dest = self::observar( $terminal, $fim );
				++$req;
				$provas[ $de ]['destino'] = $dest;
				if ( in_array( $dest['status'], array( 404, 410, 301, 302, 303, 307, 308 ), true ) ) {
					return self::erro( 'destino_contradiz_validacao_local', array( 'observacoes' => $provas ) ); }
				if ( 200 !== $dest['status'] ) {
					if ( ! self::local( $terminal )['publico'] ) {
								return self::erro( 'destino_sem_identidade_publica', array( 'observacoes' => $provas ) );
					} $v['avisos'][] = array(
						'codigo' => 'http_inconclusivo_persistencia_local',
						'de'     => $de,
					); }
			}
			$comum = array(
				'antes'       => $antes,
				'depois'      => $depois,
				'delta'       => $delta,
				'avisos'      => $v['avisos'],
				'observacoes' => $provas,
				'revisao'     => $foto['revisao'],
				'changed'     => ! empty( $alteradas ) || ! empty( $removidas ) || $antes !== $depois,
			);
			if ( $e['simular'] ?? true ) {
				return array(
					'ok'        => true,
					'simulado'  => true,
					'persisted' => false,
				) + $comum; }
			if ( ! $comum['changed'] ) {
				return array(
					'ok'        => true,
					'persisted' => false,
					'codigo'    => 'sem_alteracao',
				) + $comum; }
			$urls = array_values( array_unique( array_merge( array_keys( $alteradas ), array_keys( $removidas ) ) ) );
			F3Base_Cache_Pagina::contexto_redirects( $urls );
			try {
				$r = F3Base_Options::pelo_canal( 'ability', static fn()=>F3Base_Options::gravar( self::OPTION, $depois, F3Base_Options::ORIGEM_ABILITY, $rev ) );
			} finally {
				F3Base_Cache_Pagina::contexto_redirects( null ); }
			if ( ! empty( $r['persisted'] ) && ! empty( $e['adiar_purga'] ) ) {
				F3Base_Cache_Pagina::adiar(); }
			if ( ! empty( $r['persisted'] ) ) {
				F3Base_Options::atualizar_estado(
					'f3base_redirects_evidencia',
					static fn( $s )=>array(
						'revisao'   => F3Base_Options::revisao( self::OPTION ),
						'status'    => 'pending',
						'alvos'     => array_keys( $alteradas ),
						'removidas' => array_values(
							array_diff_key(
								array_replace(
									array_column( $s['removidas'] ?? array(), null, 'de' ),
									array_combine(
										array_keys( $removidas ),
										array_map(
											static fn( $de )=>array(
												'de'    => $de,
												'antes' => $old[ $de ],
											),
											array_keys( $removidas )
										)
									)
								),
								$novo
							)
						),
						'provas'    => array(),
						'em'        => time(),
						'contexto'  => self::contexto(),
					)
				);
			}
			return $r + $comum;
	}
	private static function contexto(): string {
		return hash( 'sha256', wp_json_encode( array( home_url( '/' ), get_option( 'permalink_structure' ), get_option( 'f3base_cache_estado' ), get_option( 'f3base_llms_revisao' ) ) ) ); }
	public static function evidencia(): array {
		$s          = (array) F3Base_Options::ler( 'f3base_redirects_evidencia' );
		$s['atual'] = ( $s['revisao'] ?? '' ) === F3Base_Options::revisao( self::OPTION ) && ( $s['contexto'] ?? '' ) === self::contexto() && ( $s['em'] ?? 0 ) > time() - DAY_IN_SECONDS;
		if ( ! $s['atual'] ) {
			$s['status'] = 'pending'; }
		return $s;
	}
	public static function verificacao_config( $v = null ): array {
		unset( $v );
		return array(
			'status'    => 'pending',
			'codigo'    => 'usar_redirects_verificar',
			'evidencia' => self::evidencia(),
		); }
	public static function verificar( $e = array() ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return self::erro( 'sem_permissao' ); }
		if ( 'consultar' === ( $e['acao'] ?? 'consultar' ) ) {
			return array(
				'ok'        => true,
				'evidencia' => self::evidencia(),
			); }
		$rev = F3Base_Options::revisao( self::OPTION );
		if ( ! hash_equals( $rev, (string) ( $e['revisao_esperada'] ?? '' ) ) ) {
			return self::erro( 'conflito' ); }
		if ( ! empty( F3Base_Cache_Pagina::estado()['pendente'] ) ) {
			$purga = F3Base_Cache_Pagina::limpar( false, 'redirects_verificar' );
			if ( empty( $purga['ok'] ) ) {
				return array(
					'ok'        => true,
					'evidencia' => self::evidencia(),
					'codigo'    => 'purga_pendente',
					'purga'     => $purga,
				); }
		}
		$val = self::validar( get_option( self::OPTION, array() ) );
		if ( ! $val['ok'] ) {
			return self::erro( 'legado_invalido' ); }
		$map       = array_column( $val['lista'], null, 'de' );
		$s         = self::evidencia();
		$removidas = ( $s['revisao'] ?? '' ) === $rev ? array_column( $s['removidas'] ?? array(), null, 'de' ) : array();
		$todos     = array_values( array_unique( array_merge( array_keys( $map ), array_keys( $removidas ) ) ) );
		$origens   = $e['origens'] ?? $todos;
		if ( ! is_array( $origens ) || array_diff( $origens, $todos ) ) {
			return self::erro( 'origem_nao_declarada' ); }
		$provas = ! empty( $s['atual'] ) ? ( $s['provas'] ?? array() ) : array();
		$cursor = max( 0, (int) ( $e['cursor'] ?? 0 ) );
		$fim    = microtime( true ) + 15;
		foreach ( array_slice( $origens, $cursor, 5 ) as $de ) {
			$r   = self::observar( $de, $fim );
			$loc = $r['location'] ?? '';
			if ( $loc ) {
				$loc = WP_Http::make_absolute_url( $loc, home_url( $de ) ); }
			$inconclusivo = ! $r['status'] || in_array( $r['status'], array( 401, 403, 429 ), true ) || $r['status'] >= 500;
			if ( isset( $map[ $de ] ) ) {
				$p      = $map[ $de ];
				$dest   = 410 === $p['status'] ? '' : home_url( $p['para'] );
				$valido = $r['status'] === $p['status'] && ( 410 === $p['status'] ? '' === $loc : $dest === $loc );
			} else {
				$p                   = $removidas[ $de ]['antes'];
				$valido              = ! ( ( $r['status'] === $p['status'] ) && ( 410 === $p['status'] || $loc === home_url( $p['para'] ) ) ); // phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Comparison of runtime expressions; neither side is an assignable literal.
				$r['regra_removida'] = true;
			}
			$r['status_verificacao'] = $inconclusivo ? 'pending' : ( $valido ? 'verified' : 'failed' );
			$provas[ $de ]           = $r;
		}
		$status = 'verified';
		foreach ( $todos as $de ) {
			$st = $provas[ $de ]['status_verificacao'] ?? 'pending';
			if ( 'failed' === $st ) {
				$status = 'failed';
				break;
			} if ( 'verified' !== $st ) {
				$status = 'pending'; }
		}
		if ( ! hash_equals( $rev, F3Base_Options::revisao( self::OPTION ) ) ) {
			return self::erro( 'configuracao_mudou_durante_verificacao' ); }
		$novo = array(
			'revisao'   => $rev,
			'contexto'  => self::contexto(),
			'em'        => time(),
			'status'    => $status,
			'provas'    => $provas,
			'escopo'    => $todos,
			'removidas' => array_values( $removidas ),
		);
		F3Base_Options::atualizar_estado( 'f3base_redirects_evidencia', static fn( $atual )=>( $atual['revisao'] ?? '' ) === $rev ? $novo : null );
		return array(
			'ok'              => true,
			'evidencia'       => $novo,
			'proximo_cursor'  => $cursor + 5 < count( $origens ) ? $cursor + 5 : null,
			'cobertura_lista' => ! array_diff( $todos, array_keys( $provas ) ),
		);
	}
	public static function taxonomia( $e ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return self::erro( 'sem_permissao' ); }
		if ( ! hash_equals( F3Base_Options::revisao( self::OPTION ), (string) ( $e['revisao_esperada'] ?? '' ) ) ) {
			return self::erro( 'conflito' ); }
		$tax  = get_taxonomy( (string) ( $e['taxonomia'] ?? '' ) );
		$de   = self::caminho( '/' . trim( (string) ( $e['de'] ?? '' ), '/' ) );
		$para = self::caminho( '/' . trim( (string) ( $e['para'] ?? '' ), '/' ) );
		if ( ! $tax || ! $tax->public || ! $de || ! $para || $de === $para || '/' === $de || '/' === $para ) {
			return self::erro( 'base_invalida' ); }
		$terms = get_terms(
			array(
				'taxonomy'   => $tax->name,
				'hide_empty' => false,
				'number'     => 201,
			)
		);
		if ( is_wp_error( $terms ) || count( $terms ) > 200 ) {
			return self::erro( 'termos_acima_do_limite' ); }
		$pares    = array();
		$snapshot = array();
		foreach ( $terms as $t ) {
			$url = get_term_link( $t );
			if ( is_wp_error( $url ) ) {
				return self::erro( 'termo_sem_url' ); }
			$path = wp_parse_url( $url, PHP_URL_PATH );
			$home = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
			$path = substr( $path, strlen( $home ) );
			if ( ! str_starts_with( $path, $para . '/' ) ) {
				return self::erro( 'base_destino_nao_canonica' ); }
			$pares[]    = array(
				'de'     => $de . substr( $path, strlen( $para ) ),
				'para'   => $path,
				'status' => 301,
			);
			$snapshot[] = array( $t->term_id, $t->slug, $t->parent, $url );
		}
		return array(
			'ok'         => true,
			'pares'      => $pares,
			'lotes'      => array_chunk( $pares, 10 ),
			'revisao'    => $e['revisao_esperada'],
			'snapshot'   => hash( 'sha256', wp_json_encode( $snapshot ) ),
			'observacao' => 'Replaneje antes de cada lote se termos ou permalinks mudarem. A aplicação revalida cada URL.',
		);
	}
	public static function tela(): void {
		echo '<h2>Redirects</h2><p>Edite a lista completa e simule. Cada lote pode alterar até dez origens.</p>';
		if ( isset( $_POST['redirects'] ) ) {
			check_admin_referer( 'f3base-operaveis' );
			$e = array(
				'operacao'               => 'substituir_lista',
				'pares'                  => json_decode( wp_unslash( (string) $_POST['redirects'] ), true ),
				'revisao_esperada'       => sanitize_text_field( wp_unslash( (string) ( $_POST['redirects_rev'] ?? '' ) ) ),
				'simular'                => ! isset( $_POST['redirects_aplicar'] ),
				'sobrepor_conteudo_vivo' => isset( $_POST['sobrepor'] ),
			);
			echo '<pre>' . esc_html( wp_json_encode( self::escrever( $e ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre>';
		}
		echo '<form method="post">';
		wp_nonce_field( 'f3base-operaveis' );
		echo '<input type="hidden" name="redirects_rev" value="' . esc_attr( F3Base_Options::revisao( self::OPTION ) ) . '"><textarea name="redirects" rows="14" style="width:100%">' . esc_textarea( wp_json_encode( get_option( self::OPTION, array() ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ) . '</textarea><p><label><input type="checkbox" name="sobrepor"> Confirmo a sobreposição das origens com conteúdo publicado</label></p><button class="button">Simular</button> <button class="button" name="redirects_aplicar">Aplicar redirects</button></form>';
	}
}
