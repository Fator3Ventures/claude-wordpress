<?php
/** Normalização do acervo já pertencente ao Core. Nunca lê fontes CF7 externas. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Leads_Reparo {
    public static function proposta( array $r, array $mapas = array() ): array {
        $d = $r['dados']; $antes = $d;
        $l = (array) ( $d['legado'] ?? array() ); $m = (array) ( $l['meta'] ?? array() );
        $v = static fn( $k, $default = null ) => $m[$k][0] ?? $default;
        $meta = (array) $v( '_meta', array() ); $campos = (array) ( $d['campos'] ?? $v( '_fields', array() ) );
        foreach ( $m as $k => $values ) { if ( str_starts_with( $k, '_field_' ) ) { $campos[substr( $k, 7 )] = $values[0] ?? ''; } }
        $delta = array(); $pendencias = array(); $fontes = array();
        $corr = $d['correlacao'] ?? $d['correlation_id'] ?? $v( '_f3base_correlation_id' );
        if ( empty( $r['correlacao'] ) && is_string( $corr ) && preg_match( '/^[A-Za-z0-9_-]{8,64}$/D', $corr ) ) { $delta['correlacao'] = $corr; $d['correlacao'] = $corr; $fontes['correlacao'] = 'dados_existentes'; }
        $sessao = F3Base_Leads_Contexto::sessao( $d['sessao'] ?? null );
        if ( empty( $r['sessao'] ) && $sessao ) { $delta['sessao'] = $sessao; $fontes['sessao'] = 'dados_existentes'; }
        $ctx = (array) ( $d['contexto'] ?? array() );
        $ip = $ctx['ip'] ?? $meta['remote_ip'] ?? $d['origem']['valor'] ?? null;
        if ( empty( $ctx['ip'] ) && is_string( $ip ) && filter_var( $ip, FILTER_VALIDATE_IP ) ) { $ctx['ip'] = $ip; $ctx['ip_fonte'] = 'snapshot_preservado'; }
        $ua = $d['user_agent'] ?? $meta['user_agent'] ?? null;
        if ( empty( $ctx['user_agent'] ) && is_string( $ua ) ) { $ctx['user_agent'] = substr( sanitize_text_field( $ua ), 0, 500 ); }
        $post_id = $d['post_id'] ?? $ctx['post_id'] ?? $meta['post_id'] ?? null;
        if ( empty( $r['post_id'] ) && is_scalar( $post_id ) && ctype_digit( (string) $post_id ) && (int) $post_id > 0 ) { $delta['post_id'] = (int) $post_id; $ctx['post_id'] = (int) $post_id; $fontes['post_id'] = 'snapshot_preservado'; }
        if ( $ctx ) { $d['contexto'] = $ctx; }
        $mapa = array();
        foreach ( (array) ( $l['termos'] ?? array() ) as $t ) {
            if ( isset( $mapas[$t['slug'] ?? ''] ) ) {
                if ( $mapa && $mapa !== $mapas[$t['slug']] ) { $pendencias[] = 'canais_ambiguos'; $mapa = array(); break; }
                $mapa = $mapas[$t['slug']];
            }
        }
        $cf7 = (int) ( $l['formulario_id'] ?? $v( '_wpcf7', 0 ) );
        if ( ! $cf7 && ! empty( $mapa['cf7_id'] ) ) { $cf7 = (int) $mapa['cf7_id']; }
        if ( $cf7 > 0 ) {
            if ( in_array( $r['metodo'], array( 'legado_desconhecido', '' ), true ) ) { $delta['metodo'] = 'formulario'; $d['metodo'] = 'formulario'; $fontes['metodo'] = $mapa ? 'mapeamento_explicito' : 'id_cf7_preservado'; }
            if ( empty( $r['formulario'] ) ) { $delta['formulario'] = $mapa['formulario'] ?? 'cf7-' . $cf7; $d['formulario'] = $delta['formulario']; }
            $d['formulario_origem'] = array( 'provedor' => 'cf7', 'id' => $cf7 );
        } elseif ( 'legado_desconhecido' === $r['metodo'] ) { $pendencias[] = 'origem_formulario_sem_evidencia'; }
        foreach ( array( 'nome' => '_from_name', 'email' => '_from_email' ) as $k => $meta_key ) {
            $valor = $d[$k] ?? '';
            if ( '' === $valor ) { $valor = $v( $meta_key, '' ); }
            if ( '' === $valor && ! empty( $mapa['campos'][$k] ) ) { $valor = $campos[$mapa['campos'][$k]] ?? ''; }
            if ( empty( $r[$k] ) && is_string( $valor ) && '' !== $valor && ( 'email' !== $k || is_email( $valor ) ) ) { $delta[$k] = 'email' === $k ? strtolower( sanitize_email( $valor ) ) : sanitize_text_field( $valor ); $d[$k] = $delta[$k]; $fontes[$k] = 'metadado_ou_mapa_explicito'; }
        }
        if ( 'clique' === $r['captura'] && ! empty( $d['destino'] ) ) {
            $acao = F3Base_Leads_Contexto::destino( $d['destino'] );
            if ( ! in_array( $acao['tipo'], array( 'invalido', 'indisponivel' ), true ) ) {
                if ( $r['metodo'] !== $acao['metodo'] ) { $delta['metodo'] = $acao['metodo']; }
                $d['metodo'] = $acao['metodo']; $d['destino_tipo'] = $acao['tipo'];
            }
        }
        if ( $delta || $antes !== $d ) {
            $d['reparo_1120'] = array( 'em' => time(), 'origem' => 'normalizacao_acervo_core', 'fontes' => $fontes, 'campos_alterados' => array_keys( $delta ) );
            $delta['dados'] = wp_json_encode( $d );
        }
        return array( 'delta' => $delta, 'pendencias' => array_values( array_unique( $pendencias ) ) );
    }
    private static function aplicar( array $r, array $delta ): bool {
        if ( ! $delta ) { return true; }
        global $wpdb;
        $delta['revisao'] = (int) $r['revisao'] + 1;
        return 1 === $wpdb->update( F3Base_Leads_Repositorio::tabela(), $delta, array( 'record_id' => $r['record_id'], 'revisao' => $r['revisao'], 'lixeira' => 0, 'eliminacao_pendente' => 0 ) );
    }
    private static function lote( int $cursor, int $limite, ?int $fim = null ): array {
        global $wpdb; $t = F3Base_Leads_Repositorio::tabela();
        $ids = $wpdb->get_col( $wpdb->prepare( 'SELECT record_id FROM %i WHERE id>%d AND id<=%d AND lixeira=0 AND eliminacao_pendente=0 ORDER BY id LIMIT %d', $t, $cursor, $fim ?? PHP_INT_MAX, $limite ) );
        return array_values( array_filter( array_map( array( F3Base_Leads_Repositorio::class, 'obter' ), $ids ) ) );
    }
    /** Reparação de campos canônicos em lotes de 50; nenhuma inferência por IP/horário. */
    public static function automatico(): void {
        if ( ! F3Base_Leads_Repositorio::pronto() ) { return; }
        $estado = F3Base_Options::ler( 'f3base_reparo_1120' );
        if ( ! empty( $estado['concluido_em'] ) ) { return; }
        global $wpdb;
        if ( ! isset( $estado['fim'] ) ) {
            $fim = (int) $wpdb->get_var( 'SELECT MAX(id) FROM ' . F3Base_Leads_Repositorio::tabela() );
            F3Base_Options::atualizar_estado( 'f3base_reparo_1120', static fn( $s ) => isset( $s['fim'] ) ? $s : array( 'fim' => $fim, 'cursor' => 0 ) );
            $estado = F3Base_Options::ler( 'f3base_reparo_1120' );
        }
        $cursor = (int) ( $estado['cursor'] ?? 0 ); $conflito = false; $pendentes = 0;
        $rows = self::lote( $cursor, 50, (int) $estado['fim'] );
        foreach ( $rows as $r ) {
            $p = self::proposta( $r );
            if ( ! self::aplicar( $r, $p['delta'] ) ) { $conflito = true; break; }
            $cursor = (int) $r['id']; $pendentes += count( $p['pendencias'] ) > 0 ? 1 : 0;
        }
        F3Base_Options::atualizar_estado( 'f3base_reparo_1120', static function ( $s ) use ( $cursor, $conflito, $pendentes, $rows ) {
            if ( $cursor > ( $s['cursor'] ?? 0 ) ) { $s['cursor'] = $cursor; $s['pendencias'] = ( $s['pendencias'] ?? 0 ) + $pendentes; }
            $s['codigo'] = $conflito ? 'conflito_retomavel' : 'lote_conferido';
            if ( ! $conflito && count( $rows ) < 50 ) { $s['concluido_em'] = time(); } return $s;
        } );
    }
    public static function executar( array $e = array() ): array {
        if ( ! F3Base_Leads_Admin::pode( 'f3base_gerir_leads' ) ) { return array( 'ok' => false, 'codigo' => 'sem_permissao' ); }
        $mapas = (array) ( $e['mapas'] ?? array() );
        $schema = self::schema(); $validacao = rest_validate_value_from_schema( $e, array( 'type' => 'object', 'properties' => $schema, 'additionalProperties' => false ) );
        if ( is_wp_error( $validacao ) ) { return array( 'ok' => false, 'codigo' => 'entrada_invalida' ); }
        $rows = self::lote( max( 0, (int) ( $e['cursor'] ?? 0 ) ), min( 50, max( 1, (int) ( $e['limite'] ?? 50 ) ) ) );
        $rev = F3Base_Leads_Repositorio::hash( array( 'mapas' => $mapas, 'cursor' => $e['cursor'] ?? 0, 'registros' => array_map( static fn( $r ) => array( $r['record_id'], $r['revisao'], $r['dados'] ), $rows ) ) );
        $sim = $e['simular'] ?? true;
        if ( ( ! $sim || isset( $e['revisao_esperada'] ) ) && ! hash_equals( $rev, (string) ( $e['revisao_esperada'] ?? '' ) ) ) { return array( 'ok' => false, 'codigo' => 'conflito', 'revisao' => $rev ); }
        $out = array(); $falhas = 0; $cursor = $e['cursor'] ?? 0;
        foreach ( $rows as $r ) {
            $p = self::proposta( $r, $mapas ); $ok = $sim || self::aplicar( $r, $p['delta'] );
            $out[] = array( 'record_id' => $r['record_id'], 'campos' => array_keys( $p['delta'] ), 'pendencias' => $p['pendencias'], 'persisted' => ! $sim && $ok, 'conflito' => ! $ok );
            if ( ! $ok ) { ++$falhas; break; } $cursor = (int) $r['id'];
        }
        return array( 'ok' => 0 === $falhas, 'simulado' => $sim, 'revisao' => $rev, 'registros' => $out, 'conflitos' => $falhas, 'cursor' => $cursor, 'proximo_cursor' => count( $rows ) === (int) ( $e['limite'] ?? 50 ) || $falhas ? $cursor : null, 'escopo' => 'somente_registros_ja_no_core' );
    }
    private static function schema(): array {
        return array( 'cursor' => array( 'type' => 'integer', 'minimum' => 0 ), 'limite' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 50 ), 'simular' => array( 'type' => 'boolean', 'default' => true ), 'revisao_esperada' => array( 'type' => 'string' ), 'mapas' => array( 'type' => 'object', 'additionalProperties' => array( 'type' => 'object', 'required' => array( 'cf7_id' ), 'additionalProperties' => false, 'properties' => array( 'cf7_id' => array( 'type' => 'integer', 'minimum' => 1 ), 'formulario' => array( 'type' => 'string', 'pattern' => '^[a-z][a-z0-9_-]{0,79}$' ), 'campos' => array( 'type' => 'object', 'additionalProperties' => false, 'properties' => array( 'nome' => array( 'type' => 'string' ), 'email' => array( 'type' => 'string' ) ) ) ) ) ) );
    }
    public static function registrar(): void {
        F3Base_Release_1103::ability( 'leads-registros-reparar', 'Simular ou normalizar registros já copiados; mapeamento explícito por canal, revisão e lotes de 50', array( __CLASS__, 'executar' ), self::schema(), array(), false, 'f3base_gerir_leads' );
    }
}
