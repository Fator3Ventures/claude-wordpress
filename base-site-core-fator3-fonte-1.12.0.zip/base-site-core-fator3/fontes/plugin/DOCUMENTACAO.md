# Base Site Core Fator3 — documentação instalada 1.12.0

Esta documentação acompanha o ZIP e permanece em `wp-content/plugins/base-site-core-fator3/`. É a referência vigente para pessoas e agentes que leem o plugin no WordPress. Não depende de arquivos da operação, conversas anteriores ou acesso ao repositório de desenvolvimento.

## Comece por aqui

- [README.md](README.md): instalação, identificação, compatibilidade e alcance.
- [CONFIGURACAO.md](docs/CONFIGURACAO.md): controles, avisos, WhatsApp, política de gestão.
- [LEADS-E-FORMULARIOS.md](docs/LEADS-E-FORMULARIOS.md): registros, contexto, métodos, anexos, respostas e reparo do acervo.
- [CONTRACTS.md](CONTRACTS.md): rotas, abilities, permissões e exemplos.
- [OPERACAO-E-RECUPERACAO.md](docs/OPERACAO-E-RECUPERACAO.md): atualização, diretório privado, cache, métricas e recuperação.
- [VALIDACAO.md](docs/VALIDACAO.md): evidências locais e verificações ainda dependentes do ambiente real.
- [REFERENCIA-CATALOGO.md](docs/REFERENCIA-CATALOGO.md): todos os módulos, opções operáveis e abilities, derivados das declarações do código.
- [CHANGELOG.md](CHANGELOG.md): alterações desta versão.

## Acesso por um agente no WordPress

Leia este arquivo pela ferramenta de arquivos do ambiente, ou execute a ability autenticada `f3base/documentacao-ler` com `{}` para obter o índice. Exemplo de leitura: `{"arquivo":"docs/LEADS-E-FORMULARIOS.md","linha":1,"limite":120}`. A resposta informa versão, SHA-256, total de linhas e próxima página. O limite é de 200 linhas por chamada. Só os arquivos catalogados são legíveis; a operação não abre caminhos arbitrários, não retorna opções nem segredos. Requer `manage_options`.

`f3base/como-usar` também aponta para este índice. As abilities dependem da Abilities API do WordPress; a leitura dos arquivos instalados permanece disponível mesmo sem esse canal.

## Identidade

Plugin 1.12.0; contrato de configuração 1.7.0; estrutura de leads 2. Instalador: `base-site-core-fator3-1.12.0.zip`. O importador excepcional CF7/Flamingo da 1.11.0 não integra este instalador. A normalização 1.12.0 atua somente em registros que já pertencem ao Core. Nenhum envio histórico gera e-mail ou evento de conversão durante o reparo.

Os documentos históricos do pacote de fontes não substituem esta documentação. O runtime, os esquemas de entrada e a leitura de volta das operações são a confirmação do que o site efetivamente usa.
