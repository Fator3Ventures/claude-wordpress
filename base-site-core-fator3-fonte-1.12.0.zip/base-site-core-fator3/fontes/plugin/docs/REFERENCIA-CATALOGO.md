# Referência do catálogo instalado — 1.12.0

Gerada a partir das declarações do plugin. Não contém valores configurados no site. Defaults e escolhas dinâmicas devem ser conferidos no contrato do WordPress de destino.

## Fluxo de operação

Leia `f3base/como-usar`, `f3base/config-core-contrato-v1` e a opção por `f3base/config-core-ler`. Simule e aplique por `f3base/config-core-escrever` usando a revisão conferida. Leia `persisted`, `effect` e `verification` separadamente. Não contorne recusas com SQL ou update_option. Segredos são mascarados; nunca copie valores de diagnóstico para documentação pública.

## Módulos

### leads-whatsapp — Leads por WhatsApp

Monta a URL wa.me a partir do número de contato e registra a interação por fetch com confirmação, com sendBeacon como reserva. Sem JavaScript, o link profundo continua respondendo com a mensagem padrão.

### endpoint-leads — Endpoint de leads

Rota REST pública endurecida que recebe o beacon do clique: schema fechado com rejeição de campo desconhecido, limites por campo, token efêmero assinado, honeypot, rate limit e deduplicação atômica por chave única. Grava no repositório privado f3base_leads, com sessão quando permitida, correlação e contexto de origem.

### cache-publico — Cache de conteúdo público

Atualiza o índice de caminhos e os textos llms quando conteúdo, visibilidade ou configuração mudam.

### consentimento — Consentimento

Preserva a política legada e oferece modo opcional por categorias. O controle permite revisar e revogar medição e publicidade; decisões de publicidade são verificadas no servidor antes de enviar pela fila.

### tracking — Tracking

Emite as tags de GA4, Google Ads, Meta e LinkedIn a partir dos IDs gravados, sob um único portão de consentimento, e instrumenta o COMPORTAMENTO do visitante pelo mesmo portão: marcos de rolagem, seção vista, clique em link externo, fricção, erro de JavaScript do próprio site e Core Web Vitals de campo, todos com nome, parâmetro e teto por página declarados num arquivo só. Container do GTM preenchido decide o caminho e desliga toda tag direta, para que nada dispare em dobro; slot vazio é inerte e nada é emitido.

### comportamento — Resumo de comportamento no site

Recebe, ao fim de cada visita, os totais agregados daquela página e os soma numa tabela própria — uma linha por dia, caminho, evento e detalhe. É a leitura que o site tem por conta própria, sem depender de conta de fornecedor.

### acessos-servidor — Acessos do servidor

Soma requisições de arquivos datados do servidor por página, família declarada, método e status. Não guarda IP, referer nem User-Agent bruto. Caminhos públicos ainda podem conter dados pessoais; exclua as rotas privadas.

### sessao-de-login — Sessão de login

Define o prazo das novas sessões e mantém o login ao fechar o navegador no formulário nativo.

### meta-capi — Meta — Conversions API

Envia o evento Lead de SERVIDOR para a Conversions API da Meta depois da persistência confirmada do lead, com o MESMO event_id que o navegador já manda no Pixel — é ele que deduplica os dois caminhos. E-mail e telefone saem em SHA-256 sobre o valor normalizado; nada de dado pessoal em claro. O token é option do site e nunca viaja no arquivo de configuração.

### verificacao-dominio — Verificação de domínio

Emite no <head> a metatag de verificação de posse do domínio de cada token gravado — google-site-verification e facebook-domain-verification. Option vazia é inerte: nenhuma tag é emitida por ela. Valor fora da forma esperada é preservado e avisado, nunca apagado.

### rota-origem — Rota de origem

Requisita um caminho do próprio site a partir do servidor e devolve status, cabeçalhos e corpo carimbados com a fase origem. Aceita apenas caminho do próprio home_url, valida o host e não segue redirecionamento para fora.

### llms-txt-reserva — Reserva do llms.txt

Serve /llms.txt por rota virtual quando ela é a responsável pelo endereço: arquivo físico na raiz vence, emissor concorrente medido vem depois, e só então esta rota. A lista junta a seleção curada da configuração com a enumeração do conteúdo publicado, conforme o modo declarado, e exclui o que está em noindex. Registrada em template_redirect prioridade 0 para não receber a barra final de redirect_canonical.

### llms-full-txt — Texto integral em llms-full.txt

Serve /llms-full.txt com o conteúdo integral em Markdown de cada item que o llms.txt lista — mesma seleção, mesmas exclusões e mesma precedência de emissor. Desligado por padrão. Reúne os textos completos dos itens selecionados, sem o corte de palavras usado no índice.

### llms-markdown — Páginas em Markdown e descoberta do llms.txt

Publica alternativas Markdown apenas para conteúdos públicos selecionados no llms.txt e anuncia os endereços no HTML e no cabeçalho Link.

### robots-txt — Robots.txt do site

Publica as regras do WordPress e dos plugins, confirma a resposta HTTP e mantém um arquivo gerenciado quando a hospedagem intercepta a rota virtual. Guarda o original e restaura ao desligar.

### redirects — Redirects de slug

Redireciona slugs antigos de páginas e posts lendo _f3base_old_slug, tratando as query vars pagename e name, e aplica os pares declarados em f3base_redirects antes do 404.

### noindex-honrado — Honra de noindex

Lê o noindex gravado nas chaves do plugin de SEO — meta por conteúdo, padrões por tipo e taxonomia, noindex por termo — e o aplica pelo filtro wp_robots mesmo com o plugin desativado. Arquivo de categoria raso recebe noindex, follow.

### schema-extensao — Extensão de schema

Acrescenta ao grafo do plugin de SEO os nós Service e as propriedades de entidade declaradas na configuração, pelos filtros do próprio plugin. Lê o FAQ dos blocos core/details da página; sameAs sai só com URL declarada.

### retencao-e-eliminacao — Retenção e eliminação

Limpa registros de lead pelo prazo declarado em WP-Cron, medindo o próprio atraso e se recuperando no carregamento seguinte; registra exportador e eraser do core; e expõe a rota de eliminação com journal que separa limpeza operacional reversível de eliminação irreversível a pedido do titular.

### cabecalhos — Cabeçalhos de resposta

Emite no front-end os cabeçalhos de segurança declarados na configuração, cada um com o valor gravado. COOP sai como está gravado, e o estado nomeia a consequência quando não for same-origin-allow-popups; HSTS sai apenas quando ligado por decisão e sobre HTTPS.

### cadencia-relatorio — Cadência do modo somente-relatório

Escuta o evento f3base_cadencia_relatorio que o implantador agenda, registra as recorrências quinzenal e mensal que o núcleo do WordPress não tem, executa a releitura das options gerenciadas e dos módulos, e registra última execução, próxima, duração, resultado, erro e atraso. Conta também os ajustes em option gerenciada e dispara a execução ao alcançar o número declarado.

## Opções operáveis

Os rótulos e tipos abaixo vêm do catálogo. Consulte o schema de entrada do canal antes de enviar os valores.

### `f3base_contato` — Contato, avisos e WhatsApp

Defina os avisos da equipe, o destino do WhatsApp e a instrumentação dos botões.

- `flutuante`: Ativar WhatsApp flutuante (booleano). Ícone fixo no canto inferior direito em todas as páginas públicas.
- `whatsapp_e164`: Número de WhatsApp (texto). Código do país, DDD e número, somente dígitos.
- `mensagem_padrao`: Mensagem que abre a conversa (textarea). Texto já escrito na conversa quando o visitante chega ao WhatsApp.
- `email_leads`: Quem recebe os avisos internos (até cinco) (emails). E-mails da equipe, um por linha. A lista do formulário prevalece quando definida. Sem destinatário, o contato é salvo e o aviso fica desconfigurado.
- `avisar_por_clique`: Enviar aviso interno de clique (booleano). Avisa sobre clique registrado, inclusive sem nome/e-mail. Desligar mantém o registro. Até 30 avisos por hora; pendentes entram no resumo horário.
- `avisar_por_formulario`: Enviar aviso interno de formulário recebido (booleano). Envia aviso após salvar um envio aceito. Falha no e-mail mantém o contato. A lista de destinatários pode ser definida em cada formulário.
- `classes_cta`: Classes adicionais de botões de contato (linhas). Classes CSS sem ponto, uma por linha; exemplo: f3capital-acao-whatsapp. A marcação não altera o link e o método segue o destino.

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "flutuante": {
            "type": "boolean"
        },
        "whatsapp_e164": {
            "type": "string",
            "maxLength": 15,
            "pattern": "^(?:[0-9]{8,15})?$"
        },
        "mensagem_padrao": {
            "type": "string"
        },
        "email_leads": {
            "type": [
                "array",
                "string"
            ],
            "items": {
                "type": "string",
                "format": "email"
            },
            "maxItems": 5
        },
        "avisar_por_clique": {
            "type": "boolean"
        },
        "avisar_por_formulario": {
            "type": "boolean"
        },
        "classes_cta": {
            "type": "array",
            "items": {
                "type": "string",
                "pattern": "^[a-zA-Z][a-zA-Z0-9_-]{0,79}$"
            },
            "maxItems": 20
        }
    }
}
```

### `f3base_ga4_measurement_id` — Google Analytics 4 — ID da métrica

Identificador do fluxo de dados da propriedade do Google Analytics.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "string",
    "maxLength": 40,
    "pattern": "^[A-Za-z0-9_-]*$"
}
```

### `f3base_gtm_container_id` — Google Tag Manager — ID do contêiner

Identificador do contêiner do Gerenciador de Tags.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "string",
    "maxLength": 40,
    "pattern": "^[A-Za-z0-9_-]*$"
}
```

### `f3base_google_ads` — Google Ads — conversão

A conta e a ação de conversão que recebem o clique no botão de contato.

- `conversion_id`: ID de conversão (texto). O identificador da conta de Google Ads que recebe a conversão.
- `conversion_label`: Rótulo da conversão (texto). A segunda metade do endereço da conversão: qual ação da conta recebe o clique.

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "conversion_id": {
            "type": "string",
            "maxLength": 40,
            "pattern": "^[A-Za-z0-9_-]*$"
        },
        "conversion_label": {
            "type": "string",
            "maxLength": 40,
            "pattern": "^[A-Za-z0-9_-]*$"
        }
    }
}
```

### `f3base_meta_pixel_id` — Meta — Pixel

Identificador do Pixel usado por campanhas de Facebook e Instagram.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "string",
    "maxLength": 40,
    "pattern": "^[A-Za-z0-9_-]*$"
}
```

### `f3base_meta_capi_token` — Meta — token do envio de servidor

Credencial do conjunto de dados do Pixel, usada para enviar o contato do servidor.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "string",
    "maxLength": 512,
    "x-maxBytes": 512,
    "writeOnly": true
}
```

### `f3base_linkedin_partner_id` — LinkedIn — identificador de parceiro

Identificador da conta de anúncios do LinkedIn.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "string",
    "maxLength": 20,
    "pattern": "^[0-9]*$"
}
```

### `f3base_linkedin_conversion_id` — LinkedIn — conversão

Identificador da conversão do LinkedIn disparada no clique do botão de contato.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "string",
    "maxLength": 20,
    "pattern": "^[0-9]*$"
}
```

### `f3base_atribuicao` — Origem do contato

Qual campanha leva o crédito pelo contato, e por quanto tempo ela o mantém.

- `modelo`: Campanha que leva o crédito (enum). A primeira que trouxe o visitante, ou a última antes do contato. Valores: `first-touch`, `last-touch`.
- `ttl_dias`: Por quantos dias a origem é lembrada (inteiro). Prazo em que a origem do visitante continua guardada no navegador dele.

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "modelo": {
            "type": "string",
            "enum": [
                "first-touch",
                "last-touch"
            ]
        },
        "ttl_dias": {
            "type": "integer",
            "minimum": 1,
            "maximum": 3650
        }
    }
}
```

### `f3base_verificacao_google` — Verificação de domínio — Google

Código que comprova ao Google que este domínio é seu.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "string",
    "maxLength": 200,
    "x-maxBytes": 200
}
```

### `f3base_verificacao_meta` — Verificação de domínio — Meta

Código que comprova à Meta que este domínio é seu.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "string",
    "maxLength": 200,
    "x-maxBytes": 200
}
```

### `f3base_consentimento` — Consentimento

O que o site faz antes de o visitante decidir, e como ele muda de ideia depois.

- `padrao`: O que vale antes de o visitante decidir (enum). A posição do site na primeira visita, antes de qualquer clique do visitante. Valores: `pre-aprovado`, `negado`.
- `controle_rodape`: Link de revisão no rodapé (booleano). Instrumento permanente para o visitante rever a decisão dele.
- `aviso_primeira_visita`: Aviso na primeira visita (booleano). Faixa não bloqueante exibida a quem chega pela primeira vez.
- `ttl_dias`: Por quantos dias a decisão vale (inteiro). Prazo em que a recusa e o novo aceite continuam guardados no navegador.
- `modo`: Modo de consentimento (enum). Legado preserva a política vigente. Granular solicita decisões separadas de medição e publicidade; cookies antigos não comprovam escolhas granulares. Valores: `legado`, `granular`.
- `politica_versao`: Versão da política (texto). Identifica a política declarada. O runtime combina a versão com a assinatura das regras vigentes; mudanças incompatíveis solicitam nova decisão sem atribuir consentimento retroativo.
- `gtm_separacao_verificada`: Contêiner GTM respeita as categorias (booleano). Marque somente após conferir as regras do contêiner. Sem essa confirmação, o modo granular só carrega GTM com medição e publicidade autorizadas.

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "padrao": {
            "type": "string",
            "enum": [
                "pre-aprovado",
                "negado"
            ]
        },
        "controle_rodape": {
            "type": "boolean"
        },
        "aviso_primeira_visita": {
            "type": "boolean"
        },
        "ttl_dias": {
            "type": "integer",
            "minimum": 1,
            "maximum": 3650
        },
        "modo": {
            "type": "string",
            "enum": [
                "legado",
                "granular"
            ]
        },
        "politica_versao": {
            "type": "string",
            "pattern": "^[A-Za-z0-9._-]{1,64}$"
        },
        "gtm_separacao_verificada": {
            "type": "boolean"
        }
    }
}
```

### `f3base_retencao_meses` — Guarda dos contatos recebidos (meses)

Por quanto tempo os registros de contato ficam no site antes da limpeza automática.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "integer",
    "minimum": 1,
    "maximum": 600
}
```

### `f3base_acessos` — Acessos do servidor

Contagem dos logs fechados em Medição → Acessos.

- `ligado`: Somar acessos do servidor (booleano). Soma logs datados disponíveis e preserva o histórico agregado quando desligado. Não recupera arquivos apagados pelo host.
- `padrao_do_log`: Padrão dos arquivos de log (texto). Use um diretório exclusivo deste site e arquivos access.log.AAAA-MM-DD. O padrão resolve ~ pelo ambiente, usuário do PHP e ascendentes do WordPress. Múltiplos diretórios são recusados; um caminho absoluto define a origem explicitamente.
- `caminhos_excluidos`: Prefixos excluídos do detalhe (lista). Os caminhos correspondentes contam somente no rodapé, sem guardar o caminho. Adicione rotas privadas do seu site. URLs públicas podem conter dados pessoais no caminho. Mudanças reclassificam apenas os arquivos ainda disponíveis.
- `retencao_meses`: Retenção do agregado em meses (inteiro). Apaga agregados mais antigos que o prazo. A tela consulta até noventa dias; o histórico restante fica no banco para consultas futuras.
- `padroes_hospedagem`: Marcadores de agentes da hospedagem (lista). Textos literais presentes no User-Agent identificam tráfego declarado da hospedagem. IP compartilhado não é prova de origem.

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "ligado": {
            "type": "boolean"
        },
        "padrao_do_log": {
            "type": "string",
            "maxLength": 1024,
            "pattern": "^(?!.*\\.\\.)(?:/|~/)[a-zA-Z0-9_./* -]+$",
            "x-maxBytes": 1024
        },
        "caminhos_excluidos": {
            "type": "array",
            "items": {
                "type": "string",
                "maxLength": 191,
                "pattern": "^/[^?\\x00-\\x20#]*$",
                "x-maxBytes": 191
            },
            "maxItems": 100,
            "uniqueItems": true
        },
        "retencao_meses": {
            "type": "integer",
            "minimum": 1,
            "maximum": 120
        },
        "padroes_hospedagem": {
            "type": "array",
            "items": {
                "type": "string",
                "minLength": 3,
                "maxLength": 80
            },
            "maxItems": 8
        }
    }
}
```

### `f3base_sessao` — Sessão de login

Prazo dos novos logins pelo formulário nativo. O diagnóstico informa o valor efetivo.

- `ligado`: Manter login ao fechar o navegador (booleano). Aplica o prazo aos novos logins e marca Lembrar-me no formulário nativo. Desligar não revoga cookies já emitidos.
- `dias`: Duração das novas sessões em dias (inteiro). Aceita de um a trezentos e sessenta e cinco dias. Um cookie roubado permite acesso pelo prazo restante; Sair de todos os outros dispositivos revoga as demais sessões.
- `modo`: Política das sessões (enum). Legado conserva o prazo único e Lembrar-me. Por perfil respeita a escolha de lembrar e usa a regra mais restritiva aplicável. Novas sessões apenas. Valores: `legado`, `por-perfil`.
- `regras`: Regras de duração por perfil (json). Lista de regras com papel ou capacidade, dias e nucleo. A regra mais curta prevalece; manage_options sempre respeita o teto do núcleo. Nenhuma sessão existente é revogada.

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "ligado": {
            "type": "boolean"
        },
        "dias": {
            "type": "integer",
            "minimum": 1,
            "maximum": 365
        },
        "modo": {
            "type": "string",
            "enum": [
                "legado",
                "por-perfil"
            ]
        },
        "regras": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": false,
                "properties": {
                    "papel": {
                        "type": "string"
                    },
                    "capacidade": {
                        "type": "string"
                    },
                    "dias": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 365
                    },
                    "nucleo": {
                        "type": "boolean"
                    }
                }
            },
            "maxItems": 30
        }
    }
}
```

### `f3base_comportamento` — Resumo de comportamento no próprio site

O resumo que o site guarda por conta própria sobre como as páginas são usadas.

- `ligado`: Guardar o resumo no site (booleano). O resumo é somado por dia e por página, sem identificar visitante.
- `retencao_dias`: Por quantos dias o resumo é guardado (inteiro). Prazo depois do qual as linhas antigas do resumo são apagadas pela limpeza automática.
- `retencao_eventos_dias`: Por quantos dias o registro detalhado é guardado (inteiro). Prazo do registro que guarda visitante, sessão e horário de cada acontecimento — mais curto que o do resumo, e nunca maior.
- `dias_no_painel`: Período mostrado no quadro (inteiro). Quantos dias o quadro desta tela soma ao exibir os números.
- `tempo_ativo`: Estimar tempo ativo por bloco (booleano). Conta somente o bloco predominante com página visível e atividade recente. A estimativa não comprova atenção humana.

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "ligado": {
            "type": "boolean"
        },
        "retencao_dias": {
            "type": "integer",
            "minimum": 1,
            "maximum": 730
        },
        "retencao_eventos_dias": {
            "type": "integer",
            "minimum": 1,
            "maximum": 730,
            "x-maximumField": "retencao_dias"
        },
        "dias_no_painel": {
            "type": "integer",
            "minimum": 1,
            "maximum": 730,
            "x-maximumField": "retencao_dias"
        },
        "tempo_ativo": {
            "type": "boolean"
        }
    }
}
```

### `f3base_origem_confiavel` — Como o site descobre o endereço do visitante

Quando o site está atrás de CDN ou proxy, o endereço real chega num cabeçalho.

- `cabecalho`: Cabeçalho em que este site confia (texto). Nome do cabeçalho que a sua CDN ou proxy escreve com o endereço do visitante.
- `saltos`: Em que posição da lista está o endereço do visitante (inteiro). Usado apenas quando o cabeçalho acima está preenchido.
- `redes_confiaveis`: De quais endereços os seus proxies falam com o site (lista). Faixas de IP da sua CDN ou do seu balanceador, uma por linha, em notação de endereço ou de rede.

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "cabecalho": {
            "type": "string"
        },
        "saltos": {
            "type": "integer",
            "minimum": 1,
            "maximum": 10
        },
        "redes_confiaveis": {
            "type": "array",
            "items": {
                "type": "string",
                "description": "IP ou CIDR validado pelo módulo de origem."
            }
        }
    }
}
```

### `f3base_robots` — Robots.txt do plugin

Alterna entre o gerador do plugin e o arquivo físico original, com backup e restauração.

- `ligado`: Utilizar o robots.txt do plugin (booleano). Ligado, guarda o original e verifica a entrega pública. Se a hospedagem interceptar a rota virtual, mantém um arquivo físico gerenciado e atualizado automaticamente.

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "ligado": {
            "type": "boolean"
        }
    }
}
```

### `f3base_llms` — Arquivo llms.txt para leitores automáticos

Índice curto que apresenta o site a assistentes e agentes que o leem.

- `ligado`: Publicar o llms.txt (booleano). Serve o arquivo em /llms.txt quando não existe um arquivo físico na raiz.
- `introducao`: Primeira frase do arquivo (textarea). Uma linha dizendo do que este site trata.
- `apresentacao`: Apresentação do negócio (textarea). Um parágrafo dizendo o que o site é, para quem e com que oferta.
- `modo`: Como a lista é formada (enum). A escolha entre listar só o que foi escolhido na entrega e listar também o que for publicado depois. Valores: `curada`, `automatica`, `curada-mais-automatica`.
- `tipos`: Tipos de conteúdo enumerados (multiescolha). Selecione os tipos públicos disponíveis neste site. Usado nos modos que enumeram o conteúdo publicado.
- `markdown`: Publicar páginas em Markdown (booleano). Disponibiliza versões de leitura das páginas públicas selecionadas e as anuncia no HTML.
- `full`: Publicar também o texto integral (booleano). Serve /llms-full.txt com o conteúdo completo de cada item listado, em Markdown e sem resumo.
- `indexavel`: Deixar o arquivo ser indexado (booleano). Controla o cabeçalho X-Robots-Tag na resposta do arquivo.
- `entrega`: Entrega do índice (enum). Arquivo gerado reduz o trabalho do PHP; requer raiz gravável e cabeçalhos do servidor configurados. Valores: `dinamica`, `arquivo_gerado`.
- `atualizacao_intervalo_segundos`: Intervalo de atualização (inteiro). Atualização periódica. Sem visitas é necessário cron real.
- `atualizar_por_visita`: Verificar atualização nas visitas (booleano). Visitas processadas pelo WordPress agendam atualização vencida. Hits estáticos e de cache não executam PHP.
- `blocos_interface`: Blocos de interface excluídos da conversão (blocos). Selecione os blocos de interface que serão omitidos na conversão Markdown. Valores já salvos são preservados quando o bloco está indisponível.

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "ligado": {
            "type": "boolean"
        },
        "introducao": {
            "type": "string"
        },
        "apresentacao": {
            "type": "string"
        },
        "modo": {
            "type": "string",
            "enum": [
                "curada",
                "automatica",
                "curada-mais-automatica"
            ]
        },
        "tipos": {
            "type": "array",
            "items": {
                "type": "string",
                "enum": [
                    "attachment",
                    "page",
                    "post"
                ]
            },
            "uniqueItems": true
        },
        "markdown": {
            "type": "boolean"
        },
        "full": {
            "type": "boolean"
        },
        "indexavel": {
            "type": "boolean"
        },
        "entrega": {
            "type": "string",
            "enum": [
                "dinamica",
                "arquivo_gerado"
            ]
        },
        "atualizacao_intervalo_segundos": {
            "type": "integer",
            "minimum": 60,
            "maximum": 86400
        },
        "atualizar_por_visita": {
            "type": "boolean"
        },
        "blocos_interface": {
            "type": "array",
            "items": {
                "type": "string",
                "pattern": "^[a-z0-9-]+/[a-z0-9-]+$"
            },
            "maxItems": 50
        },
        "politica_privacidade": {
            "type": [
                "object",
                "array"
            ],
            "items": {
                "type": "string"
            },
            "properties": {
                "id": {
                    "type": "integer",
                    "minimum": 0
                },
                "url": {
                    "type": "string"
                },
                "titulo": {
                    "type": "string"
                },
                "descricao": {
                    "type": "string"
                }
            },
            "maxItems": 0
        },
        "livres": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {
                        "type": "integer",
                        "minimum": 0
                    },
                    "url": {
                        "type": "string"
                    },
                    "titulo": {
                        "type": "string"
                    },
                    "descricao": {
                        "type": "string"
                    }
                },
                "additionalProperties": true
            }
        }
    }
}
```

### `f3base_redirects` — Redirects declarados

Pares origem/destino do próprio site aplicados antes do 404, além do redirecionamento por slug antigo.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "array",
    "additionalProperties": true,
    "maxItems": 200,
    "items": {
        "type": "object",
        "required": [
            "de"
        ],
        "properties": {
            "de": {
                "type": "string",
                "maxLength": 500
            },
            "para": {
                "type": "string",
                "maxLength": 500
            },
            "status": {
                "type": "integer",
                "enum": [
                    301,
                    302,
                    307,
                    308,
                    410
                ]
            }
        },
        "additionalProperties": true
    }
}
```

### `f3base_google_carregamento` — Carregamento das tags Google

Controla a inserção de gtag.js direto; não se aplica ao GTM.

- `modo`: Momento do carregamento (enum). Após interação adia GA4 e Ads; visitas curtas podem terminar antes da entrega. GTM mantém sua própria política. Valores: `imediato`, `apos_interacao`.
- `teto_segundos`: Prazo após load, em segundos (inteiro). Prazo máximo de espera depois do carregamento da página. Interagir antecipa a liberação, sem conceder consentimento.

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "modo": {
            "type": "string",
            "enum": [
                "imediato",
                "apos_interacao"
            ]
        },
        "teto_segundos": {
            "type": "integer",
            "minimum": 1,
            "maximum": 30
        }
    }
}
```

### `f3base_seo_entidade` — Entidade de SEO

Propriedades de entidade e serviços usados para estender o grafo do plugin de SEO. sameAs vazio fica vazio.

- `nome`: Nome (texto). Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.
- `same_as`: Same as (json). Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.
- `area_servida`: Area servida (json). Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.
- `conhece_sobre`: Conhece sobre (json). Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.
- `ponto_de_contato`: Ponto de contato (json). Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.
- `organizacao_mae`: Organizacao mae (json). Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.
- `servicos`: Servicos (json). Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.
- `faq_schema`: Faq schema (booleano). Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.
- `razao_social`: Razão social (texto). Complementa somente propriedades ausentes na organização emitida pelo Yoast.
- `cnpj`: CNPJ (texto). Complementa somente propriedades ausentes na organização emitida pelo Yoast.
- `descricao`: Descrição (texto). Complementa somente propriedades ausentes na organização emitida pelo Yoast.
- `email`: E-mail (texto). Complementa somente propriedades ausentes na organização emitida pelo Yoast.
- `telefone`: Telefone E.164 (texto). Complementa somente propriedades ausentes na organização emitida pelo Yoast.
- `endereco`: Endereço (json). Objeto opcional com logradouro, cidade, uf, cep e pais. BR é a reserva quando há endereço.
- `organizacoes_filhas`: Organizações filhas (json). Relações declaradas: nome, URL HTTPS e ID opcional. Não deduz relações pelo domínio.
- `autoria`: Autoria padrão (enum). Institucional usa a organização existente no grafo. A escolha individual do conteúdo tem precedência. Valores: `usuario`, `organizacao`.
- `pessoas`: Pessoas por página (json). 

Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "nome": {
            "type": "string"
        },
        "same_as": {
            "type": "array",
            "items": {
                "type": "string"
            }
        },
        "area_servida": {
            "type": "array",
            "items": {
                "type": "string"
            }
        },
        "conhece_sobre": {
            "type": "array",
            "items": {
                "type": "string"
            }
        },
        "ponto_de_contato": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": true,
                "properties": {
                    "tipo": {
                        "type": "string"
                    },
                    "telefone": {
                        "type": "string"
                    },
                    "email": {
                        "type": "string"
                    },
                    "idiomas": {
                        "type": "array",
                        "items": {
                            "type": "string"
                        }
                    }
                }
            }
        },
        "organizacao_mae": {
            "type": [
                "string",
                "object"
            ],
            "items": {
                "type": "string"
            },
            "additionalProperties": true,
            "properties": {
                "nome": {
                    "type": "string"
                },
                "url": {
                    "type": "string"
                },
                "id": {
                    "type": "string"
                }
            }
        },
        "servicos": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": true,
                "properties": {
                    "nome": {
                        "type": "string"
                    },
                    "descricao": {
                        "type": "string"
                    },
                    "url": {
                        "type": "string"
                    },
                    "tipo_servico": {
                        "type": "string"
                    },
                    "area_servida": {
                        "type": "array",
                        "items": {
                            "type": "string"
                        }
                    }
                }
            }
        },
        "faq_schema": {
            "type": "boolean"
        },
        "razao_social": {
            "type": "string"
        },
        "cnpj": {
            "type": "string"
        },
        "descricao": {
            "type": "string"
        },
        "email": {
            "type": "string"
        },
        "telefone": {
            "type": "string"
        },
        "endereco": {
            "type": "object",
            "items": {
                "type": "string"
            },
            "additionalProperties": true,
            "properties": {
                "logradouro": {
                    "type": "string"
                },
                "cidade": {
                    "type": "string"
                },
                "uf": {
                    "type": "string"
                },
                "cep": {
                    "type": "string"
                },
                "pais": {
                    "type": "string"
                }
            }
        },
        "organizacoes_filhas": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": true,
                "required": [
                    "nome",
                    "url"
                ],
                "properties": {
                    "nome": {
                        "type": "string"
                    },
                    "url": {
                        "type": "string"
                    },
                    "id": {
                        "type": "string"
                    }
                }
            },
            "maxItems": 50
        },
        "autoria": {
            "type": "string",
            "enum": [
                "usuario",
                "organizacao"
            ]
        },
        "pessoas": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": false,
                "required": [
                    "nome",
                    "paginas"
                ],
                "properties": {
                    "id": {
                        "type": "string",
                        "format": "uri"
                    },
                    "nome": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 200
                    },
                    "cargo": {
                        "type": "string",
                        "maxLength": 200
                    },
                    "descricao": {
                        "type": "string",
                        "maxLength": 2000
                    },
                    "same_as": {
                        "type": "array",
                        "maxItems": 20,
                        "items": {
                            "type": "string",
                            "format": "uri"
                        }
                    },
                    "paginas": {
                        "type": "array",
                        "maxItems": 100,
                        "items": {
                            "type": "integer",
                            "minimum": 1
                        }
                    }
                }
            },
            "maxItems": 50
        }
    }
}
```

### `f3base_cabecalhos` — Cabeçalhos de resposta

Cabeçalhos de segurança emitidos no front-end. O COOP EMITIDO É O VALOR GRAVADO, dentro do vocabulário fechado do cabeçalho: fora de same-origin-allow-popups o navegador corta a relação com a janela que o CTA abre, o módulo fecha degradado NOMEANDO essa consequência, e nada é recusado. HSTS desligado por padrão.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "x_content_type_options": {
            "type": "boolean"
        },
        "x_frame_options": {
            "type": "string",
            "enum": [
                "SAMEORIGIN",
                "DENY",
                ""
            ]
        },
        "csp_frame_ancestors": {
            "type": "string",
            "enum": [
                "'self'",
                "'none'",
                ""
            ]
        },
        "referrer_policy": {
            "type": "string",
            "enum": [
                "no-referrer",
                "no-referrer-when-downgrade",
                "origin",
                "origin-when-cross-origin",
                "same-origin",
                "strict-origin",
                "strict-origin-when-cross-origin",
                "unsafe-url",
                ""
            ]
        },
        "coop": {
            "type": "string",
            "enum": [
                "unsafe-none",
                "same-origin",
                "same-origin-allow-popups",
                "noopener-allow-popups"
            ]
        },
        "permissions_policy": {
            "type": "string",
            "enum": [
                "geolocation=(), camera=(), microphone=()",
                ""
            ]
        },
        "hsts": {
            "type": "boolean"
        },
        "hsts_max_age": {
            "type": "integer",
            "minimum": 0,
            "maximum": 63072000
        }
    }
}
```

### `f3base_nav_id` — ID da navegação

Post wp_navigation gerenciado. Estrutural: quebrar o vínculo derruba o menu do topo.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "integer",
    "minimum": 1
}
```

### `f3base_cadencia` — Cadência do modo somente-relatório

Periodicidade, gatilho por número de ajustes, mecanismo e nome do hook. Gravada pelo implantador e LIDA pelo módulo de cadência do site-core, que é quem engancha o evento e conta os ajustes.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "object",
    "additionalProperties": true,
    "properties": {
        "periodicidade": {
            "type": "string",
            "enum": [
                "nenhuma",
                "semanal",
                "quinzenal",
                "mensal"
            ]
        },
        "apos_n_ajustes": {
            "type": "integer",
            "minimum": 0
        },
        "mecanismo": {
            "type": "string"
        },
        "hook": {
            "type": "string"
        }
    }
}
```

### `f3base_formularios` — Formulários próprios

Definições revisionadas. Editor em Contatos → Formulários.


Schema normalizado (não substitui o schema de entrada específico do canal):

```json
{
    "type": "array",
    "items": {
        "type": "object",
        "required": [
            "id",
            "titulo",
            "campos"
        ],
        "properties": {
            "id": {
                "type": "string",
                "pattern": "^[a-z][a-z0-9_-]{0,79}$"
            },
            "titulo": {
                "type": "string",
                "maxLength": 200
            },
            "resposta_visitante": {
                "type": "object",
                "additionalProperties": false,
                "properties": {
                    "ativa": {
                        "type": "boolean",
                        "default": false
                    },
                    "campo_email": {
                        "type": "string",
                        "maxLength": 80
                    },
                    "assunto": {
                        "type": "string",
                        "maxLength": 200
                    },
                    "corpo": {
                        "type": "string",
                        "maxLength": 10000
                    },
                    "remetente": {
                        "type": "string",
                        "maxLength": 254
                    },
                    "nome_remetente": {
                        "type": "string",
                        "maxLength": 120
                    }
                }
            },
            "regime": {
                "type": "string",
                "enum": [
                    "registro",
                    "whatsapp",
                    "conteudo"
                ]
            },
            "ativo": {
                "type": "string",
                "pattern": "^[a-f0-9]{32}$"
            },
            "validade_dias": {
                "type": "integer",
                "minimum": 1,
                "maximum": 365
            },
            "quota": {
                "type": "integer",
                "minimum": 1,
                "maximum": 1000
            },
            "confirmacao": {
                "type": "string",
                "maxLength": 10000
            },
            "assunto": {
                "type": "string",
                "maxLength": 200
            },
            "destinatarios": {
                "type": "array",
                "maxItems": 5,
                "items": {
                    "type": "string",
                    "format": "email"
                }
            },
            "whatsapp": {
                "type": "string",
                "pattern": "^[0-9]{10,15}$"
            },
            "botao": {
                "type": "string",
                "maxLength": 100
            },
            "ligado": {
                "type": "boolean"
            },
            "campos": {
                "type": "array",
                "minItems": 1,
                "maxItems": 100,
                "items": {
                    "type": "object",
                    "required": [
                        "nome",
                        "tipo",
                        "rotulo"
                    ],
                    "additionalProperties": false,
                    "properties": {
                        "nome": {
                            "type": "string",
                            "pattern": "^[a-z][a-z0-9_-]{0,79}$"
                        },
                        "tipo": {
                            "type": "string",
                            "enum": [
                                "text",
                                "email",
                                "tel",
                                "textarea",
                                "select",
                                "radio",
                                "checkbox",
                                "url",
                                "file",
                                "static"
                            ]
                        },
                        "rotulo": {
                            "type": "string",
                            "maxLength": 200
                        },
                        "obrigatorio": {
                            "type": "boolean"
                        },
                        "ajuda": {
                            "type": "string",
                            "maxLength": 1000
                        },
                        "opcoes": {
                            "type": "array",
                            "maxItems": 100,
                            "items": {
                                "type": "string",
                                "maxLength": 500
                            }
                        },
                        "padrao": {
                            "type": "string",
                            "maxLength": 1000
                        },
                        "placeholder": {
                            "type": "string",
                            "maxLength": 200
                        },
                        "autocomplete": {
                            "type": "string",
                            "maxLength": 100
                        },
                        "largura": {
                            "type": "integer",
                            "enum": [
                                50,
                                100
                            ]
                        },
                        "papel": {
                            "type": "string",
                            "enum": [
                                "nome",
                                "email",
                                "telefone",
                                "mensagem",
                                "outro"
                            ]
                        },
                        "html": {
                            "type": "string",
                            "maxLength": 10000
                        },
                        "max_bytes": {
                            "type": "integer",
                            "minimum": 0
                        },
                        "extensoes": {
                            "type": "array",
                            "items": {
                                "type": "string",
                                "pattern": "^[a-z0-9]+$"
                            }
                        },
                        "max_arquivos": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 5
                        }
                    }
                }
            }
        },
        "additionalProperties": false
    },
    "maxItems": 100
}
```

## Abilities disponíveis nesta versão

A permissão efetiva é conferida pelo runtime. Leia o input_schema pela Abilities API para detalhes.

- `f3base/documentacao-ler`: Índice e leitura paginada da documentação instalada do Core
- `f3base/leads-registros-reparar`: Simular ou normalizar registros já copiados; mapeamento explícito por canal, revisão e lotes de 50
- `f3base/leads-resposta-reenviar`: Simular e reenviar resposta ao visitante, com revisão e aceite de duplicação quando incerta
- `f3base/arquivos-privados-preparar`: Criar e testar diretório privado configurado, sem enviar mensagens
- `f3base/leads-registros-ler`: Ler registros privados de contatos; escolha explícita, sem efeitos
- `f3base/leads-atualizar`: Simular ou atualizar atendimento, suspeita e lixeira com revisão
- `f3base/leads-avisos-reenviar`: Reconciliar ou reenviar aviso interno explicitamente
- `f3base/leads-eliminar-registro`: Eliminar registro privado com journal, anexos e concessões
- `f3base/formularios-diagnosticar`: Estado de armazenamento e definições de formulário
- `f3base/redirects-ler`: Ler redirects, revisão e restrições sem HTTP
- `f3base/redirects-escrever`: Simular ou aplicar redirects com revisão e validação integral
- `f3base/redirects-verificar`: Consultar ou provar redirects por GET anônimo
- `f3base/redirects-planejar-base-taxonomia`: Enumerar pares exatos de termos públicos para uma base antiga
- `f3base/config-core-politica-escrever`: Gerir a lista explícita de opções operáveis; interruptor local já habilitado
- `f3base/llms-cobertura-ler`: Consultar cobertura Markdown por item, sem conversão ou HTTP
- `f3base/como-usar`: O que este plugin já faz, por onde mudar cada coisa e o que NÃO fazer por outro caminho. Leia antes de instalar plugin de medição, editar o tema ou escrever configuração à mão.
- `f3base/config-ler`: Lê os JSONs de entrada do implantador e seus schemas. Estes arquivos descrevem uma implantação futura; o estado aplicado no site é consultado por f3base/config-core-ler e pelo contrato do Core.
- `f3base/config-escrever`: Edita somente o JSON do implantador, após validar o schema. Não aplica opções ao site. A execução do implantador deve usar a API do dono e respeitar sua recusa; para configuração imediata do Core use f3base/config-core-escrever.
- `f3base/config-core-ler`: Lê valores operáveis, revisão opaca, origem e schema do próprio Core; segredos são mascarados. Independe do implantador.
- `f3base/config-core-escrever`: Grava pela operação do dono (F3Base_Options::gravar). Envie valor completo e revisão; mesclar=true permite alteração parcial tipada de opções compostas. Simular é o padrão. Confira persisted, effect e verification separadamente; ok mantém compatibilidade. A recusa do Core não autoriza escrita direta ou alteração do tema.
- `f3base/config-core-contrato-v1`: Catálogo versionado do dono: tipos, limites canônicos, aceitação de entrada, valores atuais, padrões, revisão, dependências e operações permitidas. Segredos mascarados. Leitura de estado do site; não edita os JSONs do implantador.
- `f3base/config-core-perfil-avaliar`: Consulta valores e evidências existentes contra perfil versionado fornecido. Não grava nem executa sondas. Segredos aceitam somente presença.
- `f3base/config-core-verificar`: Consultar é leitura. verificar_publico faz até sete GETs anônimos: dois da home, dois por rota de token ativa e um do artefato elegível de cache, na mesma cadência limitada por minuto. atualizar_cache solicita limpeza e verifica. Ações ativas exigem revisão e não regravam preferências. ok indica operação recebida; confira sonda.persisted, verification.status, cache.historico, cache.agendamento, cache.tokens e efeito_cache. Consultas não iniciam sondas nem agendamento; execuções independentes registram origem e início/fim.
- `f3base/acessos-ler`: Contagens de requisições por caminho, família declarada, status e método. Sem IP ou agente bruto. Não mede visitantes únicos nem confirma identidade dos robôs. Paginação por offset; totais do rodapé independem do filtro de caminho.
- `f3base/comportamento-ler`: Consulta administrativa de medição, limitada e paginada. Não executa coleta nem altera dados. Contagens independentes não representam funil por coorte.
- `f3base/eventos-ler`: Consulta administrativa de medição, limitada e paginada. Não executa coleta nem altera dados. Contagens independentes não representam funil por coorte.
- `f3base/leads-ler`: Consulta administrativa de medição, limitada e paginada. Não executa coleta nem altera dados. Contagens independentes não representam funil por coorte.
- `f3base/publicacao-verificar`: Sonda administrativa GET/HEAD de recursos permitidos no próprio site, com asserções e evidência datada. Não publica arquivos nem reconcilia robots. Cache: apenas artefato público existente conforme perfil.
- `f3base/publicacao-ler`: Consulta configuração e evidências já armazenadas, sem sondar ou reconciliar.
- `f3base/executar-pendentes`: Executa lotes vencidos do Core com reserva e orçamento; não executa tarefas de outros plugins.
- `f3base/saude-ler`: Consulta saúde, agenda e evidências existentes, sem executar verificações ou correções.
- `f3base/schema-verificar`: Consultar lê evidências. Verificar_publico faz HTTP limitado e persiste a prova; não aprova rich results.
- `f3base/llms-arquivo`: Consultar não tem efeitos. Regenerar publica arquivo e verifica HTTP; exige revisão atual.
- `f3base/capi-resolver-destino`: Atribui explicitamente o Pixel atual a um registro legado ainda válido. Não atribui consentimento ausente e não renova a expiração. Exige a revisão retornada pela consulta de pendências.
- `f3base/capi-reconciliar`: Encerra um resultado externo incerto por declaração administrativa: aceita ou encerrada. Não reenvia payload e não substitui evidência do fornecedor.
- `f3base/capi-pendencias-ler`: Lista estados e revisões técnicas sem payload, token, reserva ou dados do visitante. Esta consulta não executa migração, coleta ou envio.
