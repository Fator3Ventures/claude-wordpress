# Configuração — 1.12.0

## Onde operar

O menu **F3 Base** contém Configurações, Informações técnicas e a aba Operação. Contatos e Formulários permanecem nas respectivas telas do plugin. A aba Operação contém a política de opções e as operações já oferecidas pelo Core. O antigo endereço `options-general.php?page=f3base-operacao` encaminha a um GET da nova aba.

A configuração salva por seção usa revisão esperada. Uma escrita concorrente deve ser relida e reaplicada conscientemente; não substitua a revisão pelo valor novo sem conferir as alterações.

## Controles

Entrega do índice e Modo de consentimento usam seletores com os valores do catálogo. Os valores aceitos também são declarados pelo contrato de configuração. Não envie rótulos traduzidos no lugar das chaves.

Blocos de interface excluídos da conversão usam caixas de seleção dos blocos registrados. A busca apenas filtra a exibição e não desmarca valores. Um bloco salvo que esteja temporariamente indisponível continua listado e marcado. É possível acrescentar um identificador `namespace/bloco` registrado apenas na página pública. Desmarcar todos grava lista vazia.

## Contato

| Grupo | Ajuste | Efeito |
|---|---|---|
| Registro e avisos | Quem recebe os avisos internos | Até cinco e-mails da equipe. A lista específica do formulário prevalece quando declarada. |
| Registro e avisos | Enviar aviso interno de clique | Controla o aviso, inclusive de clique sem nome/e-mail; não desliga o registro. |
| Registro e avisos | Enviar aviso interno de formulário recebido | Avisa após persistir um envio aceito; falha de e-mail não perde o registro. |
| WhatsApp | Flutuante, número e mensagem | Configura o destino do WhatsApp e seu botão flutuante. Links próprios dos CTAs são respeitados. |
| Instrumentação | Classes adicionais de botões de contato | Uma classe CSS por linha, sem ponto; instrumenta o clique sem mudar seu destino. |

As chaves existentes continuam `email_leads`, `avisar_por_clique`, `avisar_por_formulario` e `classes_cta`, dentro de `f3base_contato`. As notificações internas continuam limitadas e com resumo de pendências. O estado do aviso é independente da captura e da resposta ao visitante.

## Gestão pelo canal

Na instalação/primeira atualização 1.12.0, `f3base_politica_canal` passa a verdadeiro e `f3base_operaveis` recebe a lista explícita de todas as opções atualmente operáveis. Isso não habilita acesso público nem transforma estado interno ou segredo em configuração aberta: permissões, schema, máscaras e revisão continuam valendo. O marcador `f3base_release_1120` guarda o antes/depois.

Depois dessa atualização, o operador pode restringir novamente a lista. Reativar o plugin não reabre as opções. A semântica histórica de lista vazia permanece no contrato existente; consulte a simulação de `f3base/config-core-politica-escrever` antes de gravar uma lista.

## Resposta automática

Na definição do formulário, a resposta ao visitante começa desligada. Para ativar: marque a opção, escolha um campo obrigatório de e-mail com papel `email`, informe remetente, assunto e corpo. São aceitas as variáveis `{{nome}}`, `{{formulario}}`, `{{site}}`, `{{record_id}}` em texto simples. A configuração é administrativa; o visitante não escolhe assunto, remetente ou destinatários arbitrários. Não há envio automático retroativo ao ativar a opção.
