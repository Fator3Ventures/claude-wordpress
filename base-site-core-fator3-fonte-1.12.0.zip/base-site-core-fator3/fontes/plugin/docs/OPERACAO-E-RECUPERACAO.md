# Operação e recuperação — 1.12.0

## Atualização

1. Confira backup restaurável, versão anterior, configuração de formulários e diretório privado.
2. Se ainda houver migração CF7/Flamingo pendente, conclua a transição na trilha 1.11.0. Esta versão não carrega a ponte/importador.
3. Instale o ZIP e confira `f3base_release_1120`: fotografia anterior, passos confirmados, schema e resultado do diretório.
4. Leia saúde, contrato, diagnóstico privado e um registro novo de cada fluxo. Reaplique restrições de canal desejadas depois do ajuste inicial padrão.
5. Consulte o reparo do acervo; só aplique mapas conferidos. Valide SMTP/medição/infraestrutura no ambiente de destino.

A trava da atualização evita duas execuções concorrentes. Passos confirmados não se repetem. Interrupções antes da conclusão podem ser retomadas; conflito de revisão é registrado, não sobrescrito. O schema é aditivo e conferido antes do marcador. O provisionamento privado registra falha operacional sem apagar dados.

## Pasta privada

O caminho padrão é um diretório irmão da raiz WordPress: `f3-privado-` seguido de hash estável de ABSPATH. Instalações cujo pai também seja público precisam declarar `F3BASE_ARQUIVOS_PRIVADOS` no `wp-config.php`, apontando para uma pasta fora da raiz pública. O diretório pai deve existir e permitir criação/escrita. O caminho não depende do diretório de trabalho do CLI.

O teste de preparação cria um arquivo aleatório, grava, lê, confere, aplica permissão e remove. O diagnóstico distingue `pronto`, `ausente_criavel`, `sem_permissao`, `dentro_da_raiz_publica`, `caminho_invalido`, `espaco_insuficiente` e falha de teste. A leitura do diagnóstico não cria a pasta.

A exclusão das raízes públicas conhecidas não prova ausência de aliases configurados no Apache/Nginx/proxy. A verificação de alias da hospedagem permanece explicitamente pendente até conferência naquele ambiente. Não publique o diretório por alias. Use a ability de preparação após corrigir permissões/caminho.

## Cache

A rotina já usada para `cache.tokens` também pede por HTTP um artefato existente e elegível em `wp-content/cache/supercache/…/index.html` ou `index-https.html`. Não executa PHP do cache, não segue redirecionamentos e não consulta corpos privados. A evidência fica em `artefato_cache`, junto da tentativa durável e do último sucesso.

Sucesso exige resposta completa de zero bytes com HTTP 200, 403, 404 ou 410. Corpo HTML de erro não atende esse aceite. Corpo igual ao hash do arquivo é exposição efetiva. Resposta 5xx, 429, redirecionamento, corpo truncado ou erro de rede deixa a prova pendente. Sem artefato elegível/WP Super Cache compatível não há prova de proteção; o diagnóstico permanece inconclusivo.

A sonda usa a cadência e a trava existentes. Leitura de saúde não faz uma nova requisição HTTP. Prova antiga sem o novo campo não certifica acesso direto. HIT por disco/cabeçalho continua uma prova separada da proteção do diretório.

## Métricas após load

A versão vendorizada conferida é Web Vitals 6.2.1, já minificada na 1.11.0 (11.093 bytes). A 1.12.0 remove seu enqueue antecipado e a carrega assincronamente após `window.load`, respeitando a permissão de medição. Se o tracking for iniciado depois do load, agenda o carregamento imediatamente para a próxima tarefa.

Um observador mínimo guarda interações curtas antes da biblioteca ficar pronta; um patch local faz a transferência sem duplicar entradas do buffer nativo. O relógio do primeiro ocultamento é preservado e coletores iniciados numa página já oculta escoam entradas pendentes. A correção local de máximo de CLS entre janelas permanece. Inicialização duplicada é evitada.

A retenção antecipada é limitada a 2.000 entradas. Em excesso, INP não é relatado como valor parcial; a condição fica em `window.f3baseVitaisAntecipados.overflow`. Falha de rede marca `erro`. Navegação encerrada antes do load/carga da biblioteca pode não produzir métricas: não há como prometer coleta completa depois que o documento deixa de executar. Não são fabricados zeros. bfcache e cobertura em navegadores reais precisam do aceite específico descrito em VALIDACAO.md. Não se alega melhora na nota PageSpeed sem ensaio comparável.

## Retorno e recuperação

Mantenha backup pré-atualização do banco, opções, plugin e arquivos privados. Voltar apenas o código não desfaz as opções padrão, o reparo do acervo ou o schema aditivo; verifique compatibilidade da versão de retorno antes de executar. Restaurar banco antigo perde registros posteriores: exporte/dê destino a esses registros antes de uma restauração.

Não remova manualmente marcadores para repetir migração. Não use reinstalação para eliminar acervo. A rotina de desinstalação continua preservando registros, arquivos e o marcador excepcional, conforme o contrato existente. A opção “apagar por padrão” não foi implementada.
