# Leads, formulários e arquivos — 1.12.0

## Repositório e contexto

O destino dos cliques e envios nativos é a tabela `{prefixo}f3base_leads`. Flamingo não é dependência da captura atual. O schema 2 acrescenta `sessao`, `post_id`, `resposta`, `resposta_em` e `resposta_erro`, preservando as linhas existentes.

| Campo | Origem e significado |
|---|---|
| `record_id` | Identificador próprio do registro, gerado no servidor. |
| `correlacao` | Identificador da ação. O clique transporta `correlation_id`, normalizado para a coluna. Aliases conflitantes são recusados. |
| `sessao` | 32 caracteres hexadecimais, obtidos de `f3baseTracking.sessao()`, sob consentimento de medição. É o mesmo identificador empregado pelo tracking no repositório de eventos. |
| `post_id` | ID da página pública resolvido no servidor pela URL, nunca por um ID livre fornecido no clique. Nulo se não resolvido. |
| `dados.contexto.ip` | Endereço da requisição segundo o resolvedor de origem confiável. Cabeçalhos encaminhados só valem com proxy declarado. |
| `dados.contexto.user_agent` | User agent recebido pelo servidor, sanitizado e limitado. |
| `dados.contexto.sessao_motivo` | Informa sessão recebida, tracking sem sessão ou medição não permitida. |
| `dados.snapshot` | Nome do site, URL e título da página no momento da captura. |

Sessão não é identidade pessoal nem chave deduzida por IP/horário. Sem tracking, sem JS ou sem autorização, a coluna pode ser nula. Dados que a 1.11.0 nunca recebeu não podem ser recuperados por adivinhação. O CSV e a leitura privada expõem o contexto novo mediante permissão; o JSON do registro mantém o snapshot completo.

## Métodos

| Ação | Método |
|---|---|
| Clique para `wa.me`, `api.whatsapp.com`, `web.whatsapp.com` ou `whatsapp://send` | `whatsapp_cta` |
| Clique de contato para destino interno/externo não WhatsApp, telefone ou e-mail | `contato_cta` |
| Envio nativo de registro | `formulario` |
| Envio nativo que abre WhatsApp | `whatsapp_formulario` |
| Envio de conteúdo fechado | `conteudo` |
| Acervo sem origem comprovada | `legado_desconhecido` |

Nome e e-mail não classificam o método. Domínios parecidos ou URLs com credenciais não são reconhecidos como WhatsApp. Abrir um diálogo não é envio; a conversão nativa ocorre após aceite. `generate_lead.method` acompanha a ação. A disponibilidade de um evento em GA4 exige verificação do destino real.

## Reparo do acervo 1.11.0

A atualização normaliza em lotes de 50 os dados canônicos que já possuem evidência em `dados`. Preserva o snapshot original em `dados.legado`, incrementa revisão e ignora registros na lixeira ou em eliminação. Nenhum e-mail ou evento histórico é disparado.

Um canal com nome genérico, como `contato`, não prova sozinho o ID do formulário. Quando faltar essa ligação no snapshot, use `f3base/leads-registros-reparar` com mapa explícito, primeiro em simulação. Para a evidência do formulário 24, um exemplo de mapa é:

```json
{"mapas":{"contato":{"cf7_id":24,"formulario":"cf7-24","campos":{"nome":"seu-nome","email":"seu-email"}}},"simular":true,"limite":50,"cursor":0}
```

Confira a lista de alterações, guarde `revisao` e repita o mesmo lote com `simular:false` e `revisao_esperada`. Use `proximo_cursor` para o lote seguinte. Uma divergência exige nova simulação. Confirme o mapa no site antes de aplicá-lo; o exemplo não é um mapa global da frota. Metadados `_from_name`/`_from_email` são usados quando disponíveis; campos personalizados usam o mapa. Ambiguidades permanecem explícitas.

A 1.12.0 não lê nem reimporta posts CF7/Flamingo e não corrige a ponte ainda em execução em outro pacote. O importador só existia na versão excepcional 1.11.0. Se o site ainda depende dele, conclua aquela transição primeiro.

## Anexos

Sem `max_bytes`, ou com `max_bytes:0`, não existe teto de tamanho do plugin por arquivo. `extensoes:[]` ou ausente não limita extensão. Um valor positivo continua sendo respeitado; a atualização não remove restrições deliberadamente salvas.

Continuam valendo os limites do PHP (`upload_max_filesize`, `post_max_size`, `max_file_uploads`), espaço e tempo de execução, além de servidor/proxy. O diagnóstico lê os valores do PHP, informa se o limite alcança a requisição completa e declara o limite do proxy como desconhecido. Não apresenta um teto inferido como se fosse medido. A quantidade padrão continua sendo até cinco arquivos por campo.

Arquivos ficam fora das raízes públicas conhecidas, recebem nome opaco e permissão restrita e são baixados pelo fluxo autorizado. Não há fallback em uploads públicos. Extensão livre não concede execução no servidor. Conteúdo fechado continua usando concessões com validade/quota, revogadas quando o registro é eliminado.

## Resposta ao visitante

A opção `resposta_visitante.ativa` é falsa por padrão. Um envio novo aceito pode reservar uma resposta independentemente do aviso interno. Suspeitos, duplicados, cliques e registros importados não disparam essa resposta.

Estados: `desligada`, `pendente`, `enviando`, `processada`, `falhou`, `incerta`, `expirada`, `desconfigurada`. `processada` significa que `wp_mail` aceitou o envio; não comprova recebimento na caixa postal. Há limite de 3 respostas por destinatário/hora e 30 por site/hora, com janela de 24 horas. O cron existente trata pendências; uma reserva abandonada por mais de cinco minutos vira `incerta`, sem reenvio automático.

A ability `f3base/leads-resposta-reenviar` exige simulação e revisão. Estado incerto exige `aceitar_possivel_duplicacao:true`; estado processado não é reenviado por ela. Falha de envio não elimina nem invalida o lead. A interface de contatos mostra o estado da resposta; o detalhe do registro contém os campos de acompanhamento.
