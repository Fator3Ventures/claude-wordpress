# Validação e limites — 1.12.0

Data: 24/09/2026. Bancada descartável com dados sintéticos, PHP 8.3.6 e WordPress local identificado como 7.1; banco SQLite com camada de integração WordPress. Nenhum site da frota foi alterado. E-mails interceptados localmente, sem entrega externa.

## Evidências executadas

- 64 verificações novas de integração: configuração, atualização uma vez, restrição posterior, contexto do clique, schema do endpoint, métodos, reparo por mapa, resposta opcional e prova de cache.
- 23 verificações de atualização de schema e documentação: colunas acrescentadas, acervo preservado, resposta histórica desligada, índice e leitura paginada com permissão.
- 33 verificações de formulários: validação, deduplicação, suspeitos, ausência de JS, anexos privados, eliminação e concessões.
- 7 verificações de resposta ao visitante: falha preserva registro, simulação, CAS, retry, estado processado sem repetição, aceite de incerteza e suspeito.
- Upload multipart real de 11 MiB: aceito com limite ausente e zero, recusado com limite positivo de 1.024 bytes; extensão não convencional sem lista de restrição.
- Testes JavaScript em Node VM: biblioteca solicitada somente após load, inicialização única, consentimento, replay de INP curto anterior e CLS local. DOM e PerformanceObserver são simulados; o cálculo usa a biblioteca vendorizada real.
- Regressão de consentimento/tracking anterior passou. Na suíte operacional de 46 verificações, `full_path_resolves` falhou tanto na base 1.11.0 quanto na 1.12.0, no mesmo banco de bancada. Não foi apresentado como teste aprovado nem atribuído à nova release.
- Sintaxe PHP/JavaScript e reconstrução de assets minificados conferidas. O relatório externo ao instalador contém contagens e hashes finais de pacote, sem circularidade com o ZIP.

## Aceites que dependem do ambiente real

Não estão comprovados nesta bancada: MySQL/MariaDB e versões mínimas declaradas; instalação em cada hospedagem; SMTP e recebimento; correspondência de evento efetivamente recebido em GA4; PageSpeed antes/depois; navegação imediata, saída antes de load e bfcache em navegador real; permissões e aliases do diretório privado; HTTP público real do cache/CDN.

A tentativa de disponibilizar Chromium para a bancada não produziu um binário válido; por isso testes VM não são rotulados como testes de navegador. A interface foi verificada por renderização PHP dos controles e gravação de seus valores, sem alegação de revisão visual em navegador.

A existência de código para um requisito não significa homologação de todos os cenários da matriz T01–T22. O pacote é um candidato implementado e testado localmente, com gates externos identificados. A correção da ponte CF7 em sites ainda na transição pertence à trilha excepcional 1.11.0, ausente deste instalador. CRM/webhook continuam fora de escopo.
