# Instruções do plugin 1.12.0

Leia [DOCUMENTACAO.md](DOCUMENTACAO.md). O índice, os contratos e os guias em `docs/` acompanham esta instalação.

A documentação pode ser consultada pela ability autenticada `f3base/documentacao-ler`. A versão 1.12.0 não inclui o importador excepcional CF7/Flamingo.
