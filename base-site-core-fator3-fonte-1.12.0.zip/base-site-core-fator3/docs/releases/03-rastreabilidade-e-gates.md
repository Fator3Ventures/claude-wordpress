# Core — rastreabilidade, testes e gates

Revisão de 24/09/2026. **Candidatos de homologação; nenhum aceite de frota presumido.**

## Bancada e evidências entregues

WordPress 6.9, PHP 8.3.6, SQLite Database Integration, Yoast e WP Super Cache. Dados sintéticos. E-mail substituído por transporte controlado e HTTP externo bloqueado. Testes HTTP locais usam servidor PHP, upload multipart real e requisições anônimas. LiteSpeed foi validado no contrato dos hooks; servidor LiteSpeed real permanece gate do piloto.

- `suite/versao-1103/evidencias/operacoes*.json`: normalização, query, grafo, CAS, política, histórico hierárquico, LLMS, versões e hooks LiteSpeed.
- `suite/versao-1103/evidencias/regressao-base*.json`: regressão dos controles da 1.10.2.
- `suite/versao-1110/evidencias/integracao.json`: schema, formulário, idempotência, avisos simulados, suspeita, acervo, anexos, concessões e migração.
- `suite/versao-1110/evidencias/http.json`: upload real, fluxo sem JS, confirmação, assinatura, HEAD/Range/quota e download privado.
- `suite/versao-1110/evidencias/desinstalacao.json`: dados e marcador conservados.
- `suite/versao-1110/evidencias/proxima-versao.json`: 1.11.1 simulada não carrega importador; funções permanentes continuam.
- Relatórios de lint, análise estática, padrão de código e teste JS controlado acompanham as fontes.

Essas asserções não representam aprovação integral dos 74 cenários de aceitação. A coluna “evidência” distingue cobertura local parcial da prova externa ainda exigida. Nenhum teste usa dados reais de visitantes ou envia e-mail a terceiros.

## Matriz R → T

| R | Release | Cenários T | Executor de conclusão |
|---|---|---|---|
| R01 | 1.10.3 | T01, T02, T03, T04, T07, T08, T09, T10, T14, T22, T25 | Desenvolvedor + implantador no piloto |
| R02 | 1.10.3 | T05, T06, T15, T21 | Desenvolvedor + implantador no piloto |
| R03 | 1.10.3 | T21, T22, T29 | Desenvolvedor + implantador no piloto |
| R04 | 1.10.3 | T16, T17, T28 | Desenvolvedor + implantador no piloto |
| R05 | 1.10.3 | T12, T13, T18, T19, T20 | Desenvolvedor + implantador no piloto |
| R06 | 1.10.3 | T24, T35 | Desenvolvedor + implantador no piloto |
| R07 | 1.10.3 | T22, T27 | Desenvolvedor + implantador no piloto |
| R08 | 1.10.3 | T23, T24, T26, T27 | Desenvolvedor + implantador no piloto |
| R09 | 1.10.3 | T11, T49, T50, T51, T52 | Implantador + responsável pelo site |
| R10 | 1.10.3 | T29, T30 | Desenvolvedor + implantador no piloto |
| R11 | 1.10.3 | T31, T60 | Desenvolvedor + implantador no piloto |
| R12 | 1.10.3 | T32, T33, T34 | Desenvolvedor Core + mantenedor MCP (integração separada) |
| R13 | 1.10.3 | T35, T36, T37 | Desenvolvedor Core + mantenedor MCP (integração separada) |
| R14 | 1.10.3 | T38, T39, T40 | Desenvolvedor + responsável de medição/SEO |
| R15 | 1.10.3 | T41, T42, T43, T44 | Desenvolvedor + responsável de medição/SEO |
| R16 | 1.10.3 | T45, T46, T48 | Desenvolvedor + implantador no piloto |
| R17 | 1.10.3 | T47, T73 | Desenvolvedor + implantador no piloto |
| R18 | 1.10.3 | T49, T50, T51, T52 | Desenvolvedor + implantador no piloto |
| R19 | 1.11.0 | T53, T54, T55 | Desenvolvedor + implantador no piloto |
| R20 | 1.11.0 | T56, T57, T58, T59, T60, T61 | Desenvolvedor + implantador no piloto |
| R21 | 1.11.0 | T62, T63, T64 | Desenvolvedor + hospedagem/SMTP |
| R22 | 1.11.0 | T65, T66 | Desenvolvedor + hospedagem/SMTP |
| R23 | 1.11.0 | T67, T68 | Desenvolvedor + hospedagem/SMTP |
| R24 | 1.11.0 | T69, T70 | Desenvolvedor + implantador no piloto |
| R25 | 1.11.0 | T53, T54, T66, T74 | Desenvolvedor + implantador no piloto |
| R26 | 1.11.0 | T60, T71, T72, T73 | Desenvolvedor + responsável de medição/SEO |

## Cobertura dos 74 cenários

“Local parcial” indica asserções úteis no código/integração, não todo o aceite descrito. Datas são janelas propostas do documento 01. O responsável nominal ainda deve ser designado pelo dono do produto.

| T | R | Aceite atualizado | Nível e evidência | Executor / janela |
|---|---|---|---|---|
| T01 | R01 | `par_gira`; lote inteiro recusado, revisão/valor intactos. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T02 | R01 | Recusa sem sobreposição; com autorização explícita, aceita e avisa. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T03 | R01 | Recusa identificada; nenhum dado privado enviado pela sonda. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T04 | R01 | Destino local público + HTTP inconclusivo persiste com aviso; 404/410/redirect contraditório recusa. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T05 | R02 | Conflito; edição concorrente preservada. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T06 | R02 | Ability recusa revisão velha; nova leitura contém o estado corrente. Não deve inventar o par recusado. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T07 | R01 | Recusa integral com percurso; proteção no runtime para legado cíclico. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T08 | R01 | Aviso de cadeia e sugestão C; prova registra os saltos previstos. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T09 | R01 | Duplicidade recusada; sem condição por query implícita. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T10 | R01 | Recusa explícita; sem descarte silencioso ou conversão para 301. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T11 | R09 | `/category/metodo/` → `/artigos/categoria/metodo/`: 301 e Location esperado; terminal 200 HTML, após confirmar pré-condições. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T12 | R05 | Origem volta a 404 após purga, na URL normal; lista anterior preservada. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T13 | R05 | Provar resultado esperado da fixture, sem exigir 404 universal. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T14 | R01 | 410 sem Location, sem tema; round-trip compatível com a representação persistida. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T15 | R02 | Sem mutação de preferências, política, auditoria de configuração ou cache. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T16 | R04 | Sem capacidade ou option restrita: recusa; interruptor único local permite gestão explícita posterior pelo canal. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T17 | R04 | Ausente/vazia mantém catálogo; restritiva mantém restrição; ability de política com simulação/CAS após interruptor. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T18 | R05 | Persistência verdadeira preservada; cada etapa com seu estado; sem repetir escrita automaticamente. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T19 | R05 | `verification` não aprovada; cobertura/geração identificadas. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T20 | R05 | Evidência invalidada; nenhum resultado antigo valida a nova configuração. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T21 | R02, R03 | Mesmo valor, validação, permissão e efeito; mescla posicional recusada. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T22 | R01, R03, R07 | Consulta preserva histórico; nenhuma perda por normalização; remoção/revisão explícitas. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T23 | R08 | Prova HTTP imediata separada da agregação posterior; conferir 301 no período correto após coleta. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T24 | R06, R08 | Pares, conteúdo, permissões e auditoria histórica preservados; novas rotas descobertas com schemas nativos válidos. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T25 | R01 | Construção com `home_url` e matching coerentes; sem duplicar prefixo do site. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T26 | R08 | Limitação da prova indicada; fixtures conhecidas detectam login/soft 404/canônica divergente. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T27 | R07, R08 | Teclado, foco, mensagens por par, conflito, simulação e confirmação da sobreposição; sem bypass pelo JSON do formulário. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T28 | R04 | Diagnóstico por option; concessão explícita pela ability de política habilitada, sem reset silencioso. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T29 | R03, R10 | Códigos distintos, motivo e caminho suportado; schema aceita nomes catalogados para diagnóstico sem expor valores protegidos. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T30 | R10 | Simulação sem efeitos; escrita inválida integralmente recusada; menu válido e vínculo confirmado; um único cron coerente; cabeçalhos observados por HTTP. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T31 | R11 | Marcação idempotente e um único lead por ação; sem alterar href/número sem o opt-in do contrato; clique por teclado e móvel preservados. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T32 | R12 | Avaliar conforme perfil; não aprovar só por HEAD/corpo vazio; sem arquivo elegível, evidência inconclusiva; agendamento não multiplica a cadência. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T33 | R12 | Resultado por asserção; `nao_contem` inconclusivo se corpo truncado; hash de escopo explícito; HEAD não representa corpo completo; Location sem seguir no modo correspondente. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T34 | R12 | Diagnósticos Core continuam disponíveis; integração usa contrato negociado; uma execução não dispara duas sondas equivalentes; sem quebra silenciosa de clientes. | Pendente: navegador/hospedagem/canal ou operação real | Mantenedor MCP; data própria a confirmar |
| T35 | R06, R13 | meta.fator3.version corresponde ao pacote instalado; contrato 1.6.0 separado; projeção MCP precisa de prova no canal. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T36 | R13 | Ampla mantém compatibilidade; compacta não repete tokens/provas idênticas; referências resolvem; histórias de outra geração permanecem distintas; registrar bytes antes/depois. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T37 | R13 | Consumidor do canal 2 recusa antes da instalação; manifesto Core corresponde ao ZIP; rollback usa pacote conhecido e não presume reversão automática dos dados. | Pendente: navegador/hospedagem/canal ou operação real | Mantenedor MCP; data própria a confirmar |
| T38 | R14 | Relações legítimas aceitas; identidades conflitantes e duplicação da entidade principal identificadas; não exigir um único nó Organization global. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T39 | R14 | Guarda local na escrita, proveniência fundamentada e prova HTTP separada; 301 é revisão, 404 é recurso quebrado, bloqueio/timeout inconclusivo; nada apagado automaticamente. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T40 | R14 | Person só nas páginas declaradas, com identidade estável; `post_author` preservado; aviso fundamentado de conta técnica; tema e Core não duplicam nós. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T41 | R15 | Comprovar entrega/dedup/consentimento; comparação temporal não sustenta causalidade. Experimento por sessão fica para entrega posterior. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Medição + implantador; 01–23/10 |
| T42 | R15 | Comparar `user_engagement`/tempo medido e consentimento com modo imediato; relógio do teto vem do `load`; gatilhos não carregam Google duas vezes. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Medição + implantador; 01–23/10 |
| T43 | R15 | Visual/teclado/CSP válidos; padrão sem folha bloqueante; LCP/CLS/INP não se perdem por uma eventual mudança do momento de coleta. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T44 | R15 | Medir protocolo do §12.6; GET/HEAD, MIME, invalidação e 304 quando aplicável; nenhum arquivo alheio sobrescrito nem conteúdo tornado privado preservado publicamente. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T45 | R16 | Índice aponta inválidos para HTML; full contém somente conversões válidas com cobertura; `.md` indisponível não anunciada; zero conversões tem comportamento explícito do §12.7. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T46 | R16 | Invalidar índice/full/Markdown/alternativas e cópias físicas em conjunto; invalidade não contamina outros itens e correção readmite o item. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T47 | R17 | Callback/shortcode arbitrário não executa; fallback HTML; adaptador só divulga publicações elegíveis dentro dos limites; interface excluída aparece no diagnóstico. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T48 | R16 | Não publicar versão anterior sabidamente inelegível; distinguir pendente, excluído e falha global; sem falso “full completo” nem truncamento silencioso. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T49 | R09, R18 | Capturar caminho completo em mudança de slug/pai, incluindo descendentes; fallback só em 404; não usar último segmento cru como palpite. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador; 25–30/09 |
| T50 | R09, R18 | Não redirecionar por coincidência do último segmento; conflito diagnosticado; regra explícita necessária. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T51 | R09, R18 | Pares completos chegam ao termo correto antes da adivinhação; `slack` não vai para artigo com slug semelhante; `slackware` não casa com `slack`. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T52 | R09, R18 | Snapshot/revisão divergentes recusam aplicação; não sobrescrever pares; replanejar; lotes respeitam limites e mostram cobertura restante. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador; 25–30/09 |
| T53 | R19, R25 | Reconciliação por identidade de origem e campos/hashes, incluindo snapshots; contatos independentes preservados sem virar conversões. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T54 | R19, R25 | Retomada por cursor; unicidade de origem; delta final; nenhuma mensagem perdida, sobrescrita ou contada duas vezes. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T55 | R19 | Sem e-mail/eventos para registros importados; aprovação manual pode gerar aviso único, mas não inventa sessão nem envia GA4 retroativo do navegador do administrador. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T56 | R20 | Estados distintos; registro/deduplicação atômicos; dados suspeitos preservados dentro do schema; falha real de banco não retorna duplicata/sucesso. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T57 | R20 | Mesmos erros por campo, simulação/CAS e permissões; IDs únicos; definição alterada desde o render exige tratamento explícito de revisão. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T58 | R20 | Recusa ou escape conforme contrato; campos estáticos permitidos não executam script; destinatário/arquivo/destino nunca vêm de valor arbitrário do visitante. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T59 | R20 | HTML compartilhado sem ID individual; HMAC por janela; POST/303 sem JS, dedup por payload e teste do TTL do cache. | HTTP local + integração; piloto pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T60 | R11, R20, R26 | Abrir/focar não cria lead; `form_start` uma vez por instância; aceite uma vez por submissão; listener legado não transforma clique em campo em conversão. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T61 | R20 | Persistência precede encaminhamento; URL montada pelo servidor; fallback de link utilizável; nenhum bloqueio de janela causa perda ou duplicação de lead. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T62 | R21 | Sem teto global; novo campo com 10 MiB padrão, removível por max_bytes=0; até cinco por campo e tipos configuráveis. | HTTP local + integração; piloto pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T63 | R21 | Arquivo real inacessível diretamente; capability exigida; sem download por ID/caminho adulterado; upload só habilita depois da prova de proteção. | HTTP local + integração; piloto pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T64 | R21 | Erro claro quando observável; nada de aceite com anexo perdido; arquivos temporários/órfãos reconciliados; sem carregar arquivo inteiro na memória. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T65 | R22 | Lead permanece salvo; estado de processamento separado de entrega observada; nenhuma repetição automática de aviso já confirmado; resumo pendente visível. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T66 | R22, R25 | Detectadas no inventário; textos essenciais migrados para confirmação; nenhum e-mail ao visitante sob a decisão vigente. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T67 | R23 | Nenhum bypass; incremento atômico; HEAD não consome; política de Range definida; sem cache compartilhado ou vazamento do token em analytics. | HTTP local + integração; piloto pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T68 | R23 | Mesma concessão ativa não duplica conversão; cota não é reiniciada silenciosamente; esgotamento permite nova concessão conforme regra explícita, sem revelar dados do contato anterior. | HTTP local + integração; piloto pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T69 | R24 | Dados e anexos protegidos; paginação estável; CSV neutralizado; leitura agregada legada preservada; consulta não muda estado. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T70 | R24 | Retenção com lixeira; eliminação com journal e revogação; cópias legadas e arquivos tratados. Uninstall preserva acervo. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T71 | R26 | Eventos somente em contexto elegível; nenhuma PII como parâmetro GA4; ausência de sessão não bloqueia contato nem vira sessão fabricada; métodos antigos continuam interpretáveis historicamente. | Pendente: navegador/hospedagem/canal ou operação real | Medição + implantador; 01–23/10 |
| T72 | R26 | Sem assets/requisições adicionais do componente onde ausente; comparação controlada de recursos e métricas; não prometer nota ou fim fixo do Lighthouse. | Pendente: navegador/hospedagem/canal ou operação real | Medição + implantador; 01–23/10 |
| T73 | R17, R26 | Conversão referencia formulário público sem renderizar interface/token; e-book/anexos/confirmadores privados nunca entram em índice/full/Markdown. | Local parcial; integração/HTTP/navegador conforme cenário ainda pendente | Desenvolvedor/implantador/hospedagem; 01–23/10 |
| T74 | R25 | Todos os formulários, avisos, histórico, painel, anexos e métricas continuam operacionais; diagnóstico não acusa Flamingo ausente; inventário sem dependências residuais. | Pendente: navegador/hospedagem/canal ou operação real | Desenvolvedor/implantador/hospedagem; 01–23/10 |

## Gates que ainda exigem execução externa

| Gate | Onde / quem | Consequência |
|---|---|---|
| Navegador desktop/móvel, teclado, foco, duas instâncias, diálogo, JS desligado e edição | Site-Teste / desenvolvedor + responsável de sites | Bloqueia publicação estável da 1.11.0; interface de redirects também precisa de aceite do piloto 1.10.3 |
| MySQL/MariaDB, upload concorrente, grants concorrentes, falha real de disco e recuperação | Clone equivalente / desenvolvedor + hospedagem | Bloqueia a 1.11.0 estável; SQLite não encerra o aceite |
| WP Super Cache e LiteSpeed reais, CDN/WAF, cache normal versus diagnóstico | Pilotos / hospedagem + implantador | Bloqueia declarar verificação pública aprovada no site; correção não fica presa ao desenvolvimento dos formulários |
| SMTP, retorno incerto, resumo/cron e recebimento nos destinatários autorizados | Piloto / hospedagem + responsável comercial | Bloqueia retirada de CF7 nesse site |
| GA4/Ads: clique que sai, engajamento de 10 s, consentimento e dedup | Propriedade/piloto autorizado / medição | Bloqueia mudar a política Google com alegação de perda aceitável; não bloqueia instalar a correção de URLs mantendo o modo atual |
| Rich Results e HTML/schema efetivos do tema | Piloto / responsável SEO | Gate do complemento de schema; nenhuma promessa de resultado aprimorado |
| `/llms.txt` físico subsegundo, cache frio/quente, invalidação e arquivos alheios | Cada perfil de hospedagem / implantador | Gate da escolha física e da meta de latência; ausência de prova não vira número estimado |
| Migração e rollback editorial ensaiados com snapshot/delta | Clone + piloto / implantador + responsável editorial | Bloqueia concluir migração/remover CF7/Flamingo |
| Canal 2 e canal 3 MCP | Repositório/versão MCP / mantenedor do canal | Integração externa; o Core não declara a tarefa do MCP entregue |

O navegador disponível neste ambiente não iniciou; isso fica como teste não executado, sem substituir a prova por análise de HTML. O manifest identifica status de candidato. Reprovar integridade de dados/privacidade bloqueia o pacote; pendências opcionais não ressuscitam a exigência genérica “todos P1 Core concluídos”.
