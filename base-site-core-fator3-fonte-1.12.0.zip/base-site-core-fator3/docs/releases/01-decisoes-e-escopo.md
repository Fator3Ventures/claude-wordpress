# Core — decisões, escopo e liberação

Revisão de 24/09/2026. Substitui as decisões conflitantes do plano único 1.10.3. Os ZIPs desta entrega são **candidatos de homologação**, sem implantação na frota. Implementar capacidade não equivale a migrar um site.

## Releases independentes

| Entrega | Conteúdo | Critério de liberação |
|---|---|---|
| **1.10.3** | Correções operacionais R01–R18; sem tabelas novas de contatos, formulários próprios ou importador | Regressão da configuração/redirects/publicação e prova do piloto; formulários não bloqueiam esta entrega |
| **1.11.0** | R19–R26: repositório, formulários, acervo, anexos privados, avisos, concessões e migração excepcional | Gates próprios de formulários, banco, navegador, e-mail, armazenamento, privacidade e recuperação |
| **Posterior** | Experimento de Google sorteado por sessão; melhorias editoriais e integrações MCP ainda independentes | Aceite específico, sem ampliar retroativamente os bloqueadores da correção operacional |

A separação libera a correção de URLs e Markdown sem esperar SMTP, anexos e remoção de CF7. Formulário, repositório e migração permanecem juntos na 1.11.0 porque retirar CF7/Flamingo exige os três. Esta mudança recebe versão minor, schema de dados próprio e contrato explícito no manifesto. O contrato de abilities é 1.6.0 nas duas entregas; inclusão de abilities não implica compatibilidade de downgrade dos dados.

**Migração excepcional:** executa exclusivamente na versão exata **1.11.0**. Importação pode ser retomada em lotes até a conferência e conclusão; uma conclusão por site. Ativação não converte conteúdo nem remove plugins. O marcador sobrevive à desativação, reinstalação e desinstalação. A 1.11.1 e seguintes não carregam o adaptador; podem remover seu arquivo. O repositório, a privacidade e a renderização permanentes não dependem dele.

P0 significa condição de liberação da sua entrega. P1 tem aceite próprio e não é uma condição genérica escondida. Um gate de recurso opcional bloqueia sua habilitação no site; um defeito de integridade, confidencialidade ou regressão comum bloqueia o pacote inteiro.

## Resposta à análise crítica

| Ponto | Decisão verificável |
|---|---|
| Todos os 26 itens bloqueavam tudo | Separação acima; a matriz de testes identifica o bloqueio por pacote e por ativação de recurso |
| Patch escondia schema | Schema de contatos somente na 1.11.0; manifesto distingue versão de pacote, contrato e dados |
| Produção aguardava formulários | A 1.10.3 não contém o importador nem cria o acervo novo |
| Gates antigos acumulados | Browser/GA4 real, Rich Results e hospedagem permanecem pendências explícitas, com executor e janela. Nenhum resultado local os substitui |
| Estimativa única insuficiente | Faixas e premissas por frente abaixo; a estimativa do anexo não é prazo comprovado |
| `_f3base_old_slug` não era mantida | Captura do caminho completo anterior em mudança de slug/pai; snapshot antes da atualização inclui descendentes hierárquicos; fallback somente em 404 |
| LiteSpeed ignorado | Adaptador para `litespeed_purge_url` e `litespeed_purge_all`; prova pública separada. WP Super Cache pode agrupar lotes até a verificação |
| HTTP impedia escrita local legítima | Identidade pública local permite persistência com aviso quando HTTP é inconclusivo. 404/410/redirect contraditório do destino continuam impedindo a proposta |
| Palpite do WordPress bloqueava a correção | Transporte sem seguir captura Location e X-Redirect-By; WordPress/Core substituíveis, precedência externa pede resolução |
| Codificações divergentes | Um normalizador para entrada e matching; destino conserva query codificada; ciclos consideram barra final normalizada |
| Uninstall apagaria histórico | Acervo, contatos, arquivos, concessões e conclusão da migração preservados. Eliminação explícita passa por journal e revogação |
| R16 era P0 indistinto | Índice/`.md` são P0. Agregado é P1 onde `full=false`; gate de operação onde `full=true`. O código de isolamento atende ambos |
| Clique humano em toda mudança de política | Um interruptor inicial por site; depois gestão da lista pela ability, com `manage_options`, simulação e CAS. WP-CLI também habilita o interruptor |
| Alterar um destino exigia 200 pares | `operacao=alterar`, identificada pela origem normalizada |
| Revisão exigida na simulação | Opcional na simulação, obrigatória na aplicação |
| Formulários anulavam cache do site | HTML compartilhado, token HMAC por definição/página/janela, ID criado no navegador; sem JS, ID no recebimento e dedup por payload/origem/janela |
| Arquivos sem teto | Sem teto global. Novos campos de anexo usam 10 MiB por arquivo e até cinco arquivos por campo; `max_bytes=0` remove explicitamente o limite. Tipos continuam configuráveis |
| Aviso por clique excessivo | Mantida a decisão anterior expressa do solicitante: padrão ligado, configurável. A alternativa “só resumo” exige decisão de produto; não foi alterada silenciosamente |
| Definitions em autoload | `f3base_formularios` com autoload desativado |
| R15 não demonstra causalidade | Comparação temporal mede associação. Não afirmar perda causada pelo adiamento. Experimento por sessão identificado fica em entrega posterior; não escolher o modo da frota por uma inferência causal não provada |
| Rollback de conteúdo omitido | Procedimento separado no documento 04; reativar CF7 sozinho é insuficiente |
| Documento monolítico | Quatro documentos: decisões, contratos, rastreabilidade/gates e operação/recuperação |

## Limites e escolhas explícitas

O pacote não executa callbacks arbitrários de blocos/shortcodes para converter Markdown. Há adaptação delimitada de `core/query`, exclusões de interface declaradas e fallback HTML por item. Isso evita executar formulários, tokens ou consultas privadas durante conversão.

A sonda genérica do canal 3 e o consumidor de atualização do canal 2 pertencem ao MCP. O Core entrega diagnósticos e manifestos, com hash do ZIP; não inventa URL de distribuição nem afirma que o outro plugin já os consome.

Notificações usam destinatários internos. `wp_mail=true` significa processamento pelo transporte. Resultado incerto requer reconciliação ou reenvio explícito com aceite de possível duplicação. Sem e-mail ao visitante. A confirmação absorve o texto essencial das respostas antigas após revisão por formulário.

O limite de arquivo não é antivírus. Arquivos são armazenados fora das raízes públicas conhecidas, entregues como anexos e nunca executados pelo Core. Remover o limite é uma escolha explícita do administrador, que assume com o responsável pela hospedagem o risco residual de disco e de abertura do arquivo recebido. CAPTCHA não foi introduzido. Não há aceite nominal de risco inventado neste relatório.

## Estimativas e calendário proposto

Estas são **estimativas de planejamento humano**, não horas medidas de implementação automática nem compromissos de terceiros. Consideram um responsável técnico com aproximadamente seis horas produtivas/dia, acesso ao piloto e dados sintéticos autorizados.

| Frente | Faixa de esforço total para desenvolvimento/revisão/homologação | Janela proposta |
|---|---:|---|
| Redirects, política e cache | 24–40 h | Candidato em 24/09; piloto 25–29/09 |
| LLMS, contrato e complementos de schema | 20–36 h | Candidato em 24/09; validação de hospedagem 25–30/09 |
| Formulários/acervo/migração — anexo | 104–155 h, estimativa recebida | Referência original; não assumir que inclui as ampliações |
| Ampliações: snapshots, ponte, privacidade, grants e recuperação | 24–48 h adicionais | Integradas ao planejamento da 1.11.0 |
| Aceite externo e correções encontradas | 20–40 h, dependente da frota | 01–23/10, proposta condicionada à disponibilidade |

Alvos de decisão: **1.10.3 em 29/09/2026**, **1.11.0 em 23/10/2026**, sujeitos aos gates. Não há implantação nem agendamento automático nessas datas. O dono do produto indica nominalmente o implantador e o responsável pelos sites antes do piloto. O desenvolvedor entrega código, testes locais e correções; o responsável pelos sites confere paridade editorial; a hospedagem confirma isolamento/cache/SMTP; o responsável de medição confirma GA4/Ads. Pendência externa mantém o candidato, em vez de converter teste não executado em “aprovado”.

## Documentos de execução

- [02 — Contratos e comportamento](02-contratos-e-comportamento.md)
- [03 — Rastreabilidade, testes e gates](03-rastreabilidade-e-gates.md)
- [04 — Implantação, migração e recuperação](04-operacao-e-recuperacao.md)
