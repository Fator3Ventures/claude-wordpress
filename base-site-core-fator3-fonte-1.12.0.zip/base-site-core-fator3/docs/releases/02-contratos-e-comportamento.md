# Core — contratos e comportamento

Revisão de 24/09/2026. Implementação candidata: 1.10.3 / 1.11.0; contrato 1.6.0. A instalação não altera sites da frota por iniciativa própria.

## Redirects e política — 1.10.3

Todas as escritas de configuração usam `F3Base_Options::gravar()`. A origem `ability` é reconhecida; autorização e CAS permanecem separados da verificação HTTP. Leitura comum distingue option desconhecida, não operável no catálogo e restrita pelo site.

| Ability | Entrada e resultado |
|---|---|
| `f3base/redirects-ler` | Origens/fatia opcionais; lista, revisão, permissões, diagnóstico do legado e evidência; sem HTTP |
| `f3base/redirects-escrever` | `adicionar`, `alterar`, `remover`, `substituir_lista`; simulação padrão; revisão opcional na simulação e obrigatória na aplicação |
| `f3base/redirects-verificar` | Consulta sem HTTP ou `verificar_publico` com revisão; GET anônimo sem seguir, até cinco origens por lote; cobre regras removidas |
| `f3base/redirects-planejar-base-taxonomia` | Taxonomia pública + bases antiga/atual; enumera pares exatos de termos, snapshot e lotes de dez; não altera permalinks |
| `f3base/config-core-politica-escrever` | Lista explícita de options operáveis, simulação e CAS; disponível somente após interruptor local |
| `f3base/publicacao-verificar` | Sonda especializada existente; `recurso=cobertura` fornece o diagnóstico por item Markdown |
| `f3base/llms-cobertura-ler` | Cobertura por item, sem conversão e sem requisição HTTP |

Para habilitar uma única vez a gestão de política pelo canal: Configurações → Operação Core, ou `wp f3base politica-habilitar`. Depois, o agente administrador pode simular e gravar a lista pela ability. Lista ausente/vazia conserva a semântica atual de permitir o catálogo; lista não vazia restringe. Upgrade não amplia silenciosamente uma restrição intencional.

Exemplo de alteração:

```json
{"operacao":"alterar","pares":[{"de":"/antiga","para":"/nova/?q=a%20b","status":301}],"simular":true}
```

Na aplicação, acrescentar `revisao_esperada` obtida da leitura e `simular=false`. `sobrepor_conteudo_vivo=true` é uma decisão explícita quando a origem identifica conteúdo vivo. O painel e a rota genérica usam o mesmo serviço. Mescla posicional da lista de redirects é recusada.

O limite é 200 pares/128 KiB, até dez origens alteradas por operação e cinco saltos de cadeia. Status aceitos: 301, 302, 307, 308, 410. 410 pode omitir destino e não emite Location. Entradas inválidas recusam o lote integralmente. Leitura do legado não apaga campos extras nem entradas inválidas; lista integral explícita permite repará-las.

Origem é caminho local, sem query, fragmento, barras codificadas, controles, travessia ou dupla codificação ambígua. Unicode válido é comparado após a mesma normalização. Destino é caminho local com query preservada; `?q=a%20b` não vira `?q=ab`. Ciclos e duplicidades usam a origem normalizada.

O destino é identificado por publicação pública sem senha, home pública ou termo canônico. HTTP 200 é evidência adicional. Timeout, 403, 429 e falha de rede não transformam destino local legítimo em inexistente. 404/410 ou redirect contraditório exigem correção. Na origem, WordPress e fallback do Core podem ser substituídos; outro emissor exige resolver precedência. A prova não certifica por si só conteúdo editorial correto ou ausência de soft 404.

O caminho anterior é capturado antes/depois da troca de slug ou pai. Inclui descendentes hierárquicos afetados. `_f3base_old_path` mantém caminho completo; `_f3base_old_slug` é também mantida para interoperabilidade. Fallback por caminho completo só executa em 404, para um único destino público. Conteúdo vivo continua vencendo o histórico. A versão não inventa retroativamente caminhos que nunca foram gravados: mudanças anteriores precisam de evidência do histórico/pares explícitos.

### Purga e evidência

LiteSpeed recebe purga de URLs quando o escopo é conhecido e purga geral para mudanças amplas. WP Super Cache conserva sua API de purga geral. Em lote de taxonomia, `adiar_purga=true` agrupa a limpeza até `redirects-verificar` ou a execução agendada; não aprova entrega pública durante a pendência. Uma indisponibilidade do provedor é declarada como tal. Cache/CDN antes do PHP continua dependendo da hospedagem.

Provas registram status, Location, emissor e hash de prefixo recebido, com revisão/contexto/data. Falha de purga não desfaz configuração já persistida. Remoção de regra não presume 404 universal: verifica se o comportamento da regra anterior deixou de ser observado. Resposta 403/timeout é inconclusiva. Uma prova parcial não marca a lista inteira como verificada.

## LLMS, schema, CTA e desempenho

Conversão ocorre em lotes com cache por item. Enquanto pendente/incompleta, o índice usa HTML; nenhuma alternativa `.md` é anunciada como disponível. Requisição direta de alternativa conhecida indisponível retorna 404 e noindex. O full inclui itens convertidos e informa cobertura. Com zero conversões não há agregado disponível. Mudança de visibilidade revoga a representação pública.

A opção `blocos_interface` declara exclusões por site. `core/query` tem adaptação delimitada a publicações elegíveis, sem executar callbacks arbitrários. Bloco/shortcode de formulário nativo representa um link para a página pública, nunca dados ou tokens.

O modo físico `/llms.txt` continua sendo o da 1.10.2: arquivo próprio, geração controlada, prova de propriedade e retirada em mudança de visibilidade. Não sobrepor arquivo alheio. A entrega subsegundo é meta da hospedagem, a medir com cache frio/quente; o ZIP não garante essa latência.

CTAs da classe de contrato recebem `data-f3base-lead` no pacote. Aliases são configuráveis em `f3base_contato.classes_cta`; JS cobre inserção dinâmica e wrappers. Marcação é idempotente. Formulários nativos não se tornam cliques de WhatsApp por estarem dentro de um ancestral marcado.

Identidade legal, relações organizacionais e autoria institucional da 1.10.2 permanecem. A coleção `f3base_seo_entidade.pessoas` relaciona Person às páginas declaradas; mantém `post_author`. Diagnóstico informa `sameAs` configurado pelo Core/Yoast/ambos, e origem desconhecida de terceiros; não atribui a terceiros uma origem sem evidência. Rich Results não substitui verificação de duplicidade/logo/links pelo pacote.

Google imediato/adiado e teto contado de `load` permanecem optativos, sem troca automática da frota. A comparação causal por sessão não está implementada neste candidato. A matriz separa o teste do mecanismo da recepção real de GA4/Ads. `web-vitals.js` já era minificado/deferido; não foi descrito como nova otimização.

## Formulários e acervo — 1.11.0

Cinco tabelas permanentes: `f3base_leads`, `f3base_contatos_legados`, `f3base_arquivos_leads`, `f3base_concessoes`, `f3base_leads_janelas`. Schema inicial 1. O índice de concessões usa `lead_record_id`; índices únicos protegem record_id, idempotência e origem. Importar nunca envia aviso/conversão histórica.

`f3base_formularios` é uma lista revisionada, `autoload=false`, editável por serviço/painel e rota de configuração. Editor permite campos/ordem/configurações, JSON avançado e prévia simulada. Exclusão de definição referenciada é recusada; retirada de publicação é explícita. Bloco: `f3base/formulario`; shortcode: `[f3base_formulario id="contato"]`.

Regimes: registro, WhatsApp e conteúdo. Tipos: text, email, tel, textarea, select, radio, checkbox, url, file e static. Os campos têm nomes únicos, rótulo, obrigatório, ajuda, placeholder, autocomplete, largura e papel. Dados do visitante não escolhem destinatário, regime, caminho de arquivo ou número de WhatsApp. Conteúdo exige ativo privado e e-mail obrigatório.

O HTML tem token HMAC compartilhável por formulário/revisão/página/janela, sem ID individual. O cliente gera a chave de submissão e renova token na primeira interação. Sem JS, o servidor gera ID e deduplica payload/origem/janela de cinco minutos, respondendo por 303 e confirmação privada. Token tem validade de duas horas: **no piloto conferir TTL do HTML inferior a essa janela no fluxo sem JS**. Token vencido retorna erro explícito; não há promessa de POST aceito indefinidamente em HTML congelado.

Campo-isca e preenchimento abaixo de três segundos do token de interação classificam suspeita; campos válidos permanecem para revisão, sem aviso comercial, concessão ou conversão. Abrir diálogo não produz lead. Validação, upload e persistência precedem notificação e encaminhamento. Falha de e-mail não faz o registro desaparecer. Reenvio com a mesma chave/payload não duplica; a mesma chave com outro payload é conflito.

Eventos DOM emitidos: `f3base-formulario-inicio`, `f3base-formulario-aceito`, `f3base-formulario-erro`, com identificação mínima. Conversão reutiliza consentimento e transporte existentes, após aceite novo. Métodos: `whatsapp_cta`, `whatsapp_formulario`, `formulario`, `conteudo`; sem mudança do nome da dimensão `method`. Sem JS não há evento de navegador GA4. Importação/aprovação administrativa não fabricam eventos retroativos.

### Arquivos e concessões

Diretório estável entre CLI/HTTP, fora das raízes públicas conhecidas. `F3BASE_ARQUIVOS_PRIVADOS` permite caminho absoluto externo explícito. Instalação em subdiretório cuja pasta-pai continue pública precisa dessa configuração. Não há fallback automático para diretório web com `.htaccess` presumido seguro.

Anexo novo: limite padrão de 10 MiB por arquivo, até cinco por campo; `max_bytes=0` libera explicitamente o limite daquele campo, `extensoes=[]` aceita qualquer extensão. Limites PHP/proxy/disco continuam existindo e são diagnosticados. IDs são aleatórios, arquivos sem extensão física, metadados de MIME/bytes/SHA-256, leitura em fluxo e download como `application/octet-stream`/attachment/nosniff. MIME não comprova inocuidade.

Conteúdo privado concede link assinado, padrão sete dias/cinco tentativas GET. HEAD não gasta quota; Range é recusado. Consumo de quota é atômico. A mesma combinação e-mail/ativo/versão reaproveita concessão válida; isso não autentica titularidade do e-mail nem prova conclusão do download. Alterar hash do ativo invalida concessões antigas. Eliminar lead revoga acesso e preserva o ativo editorial.

### Avisos, acesso e privacidade

Avisos internos: até cinco destinatários, opção por formulário, padrão de clique e formulário ligado conforme decisão anterior. Até 30 avisos individuais/hora; resumo adicional para pendentes, dependente de executor. Resultados: pendente, enviando, processado, falhou, incerto, desconfigurado. Não confundir processado com recebido. Resultado incerto não repete automaticamente; ability de reenvio exige revisão e aceite de possível duplicação quando aplicável.

Abilities permanentes: `leads-registros-ler`, `leads-atualizar`, `leads-eliminar-registro`, `leads-avisos-reenviar`, `formularios-diagnosticar`. A leitura agregada antiga continua agregada; inclui repositório novo e exclui cópias de origem já importadas. Registros pessoais exigem escolha e capacidade própria; `manage_options` conserva acesso administrativo.

CSV é privado e neutraliza fórmula. O painel permite exportar registro/anexos em ZIP privado autenticado, gerado fora da raiz pública e removido ao terminar. Exportador WordPress inclui dados e metadados, inclusive contatos independentes; a cópia de anexos é atendida pelo ZIP privado do painel, sem criar mídia pública.

Retenção aplica o corte em meses de calendário; respeita a janela `EMPTY_TRASH_DAYS` antes da eliminação operacional. Pedido definitivo revoga concessões, cancela conversões pendentes, remove anexos e originais legados relacionados, preserva tombstone de origem e journal sem cópia dos campos pessoais. Falha física fica pendente, bloqueando acesso. **Uninstall conserva histórico, acervo, arquivos, concessões e marcador da migração.**

## Fontes técnicas conferidas

- [LiteSpeed — API de purga](https://docs.litespeedtech.com/lscache/lscwp/api/)
- [Contact Form 7 — integração Flamingo](https://github.com/rocklobster-in/contact-form-7/blob/trunk/modules/flamingo.php)
- Código WordPress 6.9 usado na bancada; implementação e fixtures da entrega.
