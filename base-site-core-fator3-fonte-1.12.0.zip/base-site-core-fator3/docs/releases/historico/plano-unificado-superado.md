> HISTÓRICO SUPERADO: decisões atuais nos quatro documentos de docs/releases/. Este texto conserva o pedido anterior, não os gates atuais.

# Plano da release 1.10.3 — operação, publicação, desempenho e formulários próprios

Data: 24/09/2026. Base: código entregue da 1.10.2, contrato descritivo 1.5.0.
Status: planejamento. Versão proposta: 1.10.3; contrato descritivo proposto: 1.6.0, mantendo a rota `f3base/config-core-contrato-v1`.

Revisão: incorpora os 15 pedidos recebidos em 24/09 e a especificação `pedido2(1).md`, para substituir Contact Form 7 (CF7) e Flamingo. Este documento define trabalho futuro; não afirma que a 1.10.3 foi implementada ou instalada.

## 1. Decisão e objetivo

Priorizar redirects pelo canal oficial e a política que os torna utilizáveis em cada site; corrigir a interrupção de llms/Markdown causada por um único conteúdo; incorporar o carimbo dos CTAs ao pacote. Acrescentar diagnóstico de permissões, complementos de schema, provas de cache, identificação das abilities e respostas compactas. Recursos já entregues na 1.10.2 entram como regressão e homologação, sem serem apresentados como implementação nova.

Incluir também o registrador próprio de contatos, editor/bloco de formulários, anexos privados, notificação interna, conteúdo para download e migração conferida de CF7/Flamingo (§14). O objetivo desta ampliação é permitir retirar os dois plugins nos sites migrados. O anexo propõe entregas separadas em 1.11 e 1.12; neste plano elas se tornam etapas internas da próxima release proposta, atualmente identificada como 1.10.3. Entregar só a tabela e o aviso não satisfaz a substituição do CF7. CRM/webhooks permanecem para versão posterior.

O objetivo é viabilizar mudanças de URL sem escrita direta em options/SQL e sem perda de regras concorrentes. A publicação da versão não cria redirects nem muda páginas ou permissões dos sites automaticamente.

A gestão de redirects é procedente. A implementação exige mais que acrescentar `f3base_redirects` ao enum: a 1.10.2 conserva restrições de acesso, um sanitizador permissivo e ajuste de escrita que permite resultado parcial. Esses pontos precisam ser tratados juntos.

Fontes: os pedidos desta conversa, `pedido1.md` (SHA-256 `ba44ac9030a1fd69d12f56303738966acc285232243cd58a38af960f15434742`), documentos locais de schema/PageSpeed, `pedido2(1).md` e código da 1.10.2. Contagens de sites, tempos, falhas e pendências da frota são relatos do responsável, não novas medições. A ampliação de formulários incluiu consulta somente de leitura ao inventário e ao código de CF7 6.1.7/Flamingo 2.6.4 no Site-Teste; não incluiu mensagens, anexos de visitantes ou alteração de sites.

### 1.1 Avaliação dos pedidos

| Pedido | Avaliação na base 1.10.2 | Inclusão na 1.10.3 e responsável |
|---|---|---|
| 1 — Seis options e redirects primeiro | Parcialmente atual: robots e SEO já são elegíveis no catálogo; redirects, cabeçalhos, navegação e cadência continuam fechados. | **P0 Core:** redirects e habilitação utilizável juntos. **P1 Core:** abrir os demais campos com validação específica, conforme §12.1. Nada de SQL ou contorno pelo MCP. |
| 2 — Lista operável legada | Confirmado: lista não vazia restringe o catálogo; leitura de option excluída pode retornar `ok=false` sem motivo. | **P0 Core + implantador:** diagnóstico e migração assistida com delta/revisão. Não apagar uma lista restritiva nem acrescentar todo o catálogo automaticamente. |
| 3 — Carimbo de CTA | Confirmado: o pacote carimba o flutuante; a classe contratual dos demais CTAs depende do tema. | **P0 Core:** carimbo idempotente, classe contratual e aliases declarados por site; migração dos filtros de tema após prova. |
| 4 — Diretório de cache | Já existe sonda manual de artefato em `publicacao-verificar`; falta integrá-la à cadência. Corpo vazio sozinho não comprova proteção. | **P1 Core:** GET de artefato elegível na cadência de `cache.tokens`, com expectativa conforme perfil e evidência conjunta. |
| 5 — Sonda como ability | Já existe `f3base/publicacao-verificar` com GET/HEAD, asserções e hash; faltam cabeçalhos de requisição e convergência entre transportes. | **P1 MCP, canal 3:** sonda genérica única. **Core:** avaliações de publicação/cache/schema/redirects e adaptação compatível. Não criar outra sonda genérica no Core. |
| 6 — Manifesto de atualização | `Update URI: false` está no pacote; o manifesto operacional por pacote é pertinente. | **P1 conjunto:** Core publica manifesto e ZIP; canal 2/MCP consome, confere e aplica. Não é entrega exclusivamente do Core. |
| 7 — `version` vazio | Metadados das abilities Core não declaram `meta.fator3.version`. | **P0 Core:** incluir versão do pacote em todas as abilities; **MCP:** conferir projeção em `discover-abilities`. |
| 8 — Respostas pesadas | `compacto`/`incluir` já existem. Projeção ampla inclui integrações por padrão e `cache.tokens` também aparece dentro de `cache.evidencia`. | **P1 Core:** eliminar repetição na projeção compacta, documentar consulta mínima e preservar compatibilidade da forma ampla. |
| 9 — Schema | Identidade legal, relações, autoria institucional, guarda de `same_as` e `schema-verificar` já existem. A coleção declarada de pessoas por página e a origem de cada `sameAs` ainda faltam; alguns avisos são parciais. | **P1 Core:** completar diagnósticos e pessoa por página; homologar o entregue. Uma organização principal coerente, sem proibir organizações relacionadas legítimas. |
| 10 — Google após interação | Já entregue: `imediato`/`apos_interacao`, teto configurável de 1–30 s, padrão 5 s contado do `load`. | **P0 homologação:** clique com saída, GA4/Ads, consentimento e engajamento; **implantador:** escolher modo por site. Não alterar o padrão da frota no upgrade. |
| 11 — Consentimento inline | Já entregue; CSS inline por padrão, com opção de folha externa por filtro. | **Regressão:** ausência de folha bloqueante no modo padrão e compatibilidade visual/CSP. |
| 12 — llms < 1 s; web-vitals | Modo físico gerenciado já existe, mas homologação da hospedagem ficou pendente. `assets/vendor/web-vitals.js` já está minificado e é enfileirado com `defer`. | **P1 Core + hospedagem:** validar entrega física/cache/invalidação e medir latência. Não repetir minificação; avaliar custo e momento de execução com evidência. |
| 13 — Um item interrompe o full | Confirmado: erro de conversão lança exceção no agregado; índice/alternativas podem anunciar representações indisponíveis. | **P0 Core:** isolamento por item, fallback HTML, cobertura explícita e diagnóstico em `publicacao-verificar`. |
| 14 — Blocos dinâmicos | Confirmado: blocos não suportados, inclusive dinâmicos, tornam a conversão incompleta. Sanitizar HTML depois não elimina efeitos de executar callbacks. | **P0:** comportamento resiliente do item 13. **P1:** adaptadores delimitados para consultas e blocos de interface. Não executar indiscriminadamente `render_block()`/shortcodes. |
| 15 — Slug antigo/base de taxonomia | Confirmado no algoritmo: a busca de slug histórico depende de `name`/`pagename`; falta tratamento explícito para base antiga. | **P0 Core:** fallback restrito em 404 e planejamento de mudança de base por pares exatos, cobrindo termos hierárquicos, antes da adivinhação canônica. |
| Novo — Substituição de CF7 e Flamingo | Procedente; o endpoint atual ainda depende de Flamingo/CPT e aceita um conjunto limitado de campos. Código dos dois plugins confirma dados históricos e catálogo de contatos além da tabela proposta no anexo. | **P0 Core:** armazenamento, formulário/editor, anexos, aviso, painel, privacidade e migração. **P1 Core:** regime conteúdo. **Implantador/temas:** padrões e remoção das dependências depois da homologação. Detalhes e correções em §14. |

P0 bloqueia a liberação; P1 integra a versão após os bloqueadores. A convergência genérica de transporte e a instalação pelo canal 2 têm aceite próprio no MCP: o ZIP Core não será apresentado como se implementasse essas funções no outro plugin. O Core mantém funcionamento compatível enquanto essa integração não estiver disponível.

As referências cruzadas do relato foram normalizadas: os pedidos 1 e 15 dependem da política do pedido 2; 13 e 14 formam uma única frente de conversão. O “item 16” mencionado no pedido 1 não está nesta lista; não foi criado requisito para ele.

## 2. Confronto do pedido com a base atual

| Ponto | Constatação na 1.10.2 | Decisão |
|---|---|---|
| Rota genérica recusa redirects | Confirmado: catálogo com `operavel=false`; enum de leitura/escrita deriva do catálogo. | Tornar elegível no catálogo e aplicar a política efetiva de cada site. |
| Leitura exige contrato completo de 118 KB | A versão atual já filtra por `nome`, aceita `compacto` e `incluir`. | Documentar a consulta curta existente e acrescentar leitura especializada. |
| Tela permite editar redirects | Não se confirma na base entregue: renderização e envio aplicam `operavel()`; a entrada não declara seção editável. | Implementar a superfície administrativa nesta release. Revalidar separadamente qualquer instalação que apresente comportamento diferente. |
| Gravador já recusa o par que gira | Ele remove pares que giram e pode gravar os demais, com aviso. O sanitizador também elimina entradas inválidas e converte status desconhecido em 301. | Validar antes desses ajustes; falha em qualquer par recusa o lote inteiro. |
| Sanitização protege caminhos | Existe validação local e limite de 500 caracteres, com decodificação posterior à primeira checagem. | Validar entrada e forma decodificada; recusar truncamento/transformação perigosa e testar caminhos codificados. |
| Canal deve ter origem própria | A 1.10.2 já registra `canal=ability`, mas usa a categoria histórica `edicao-manual`; origem desconhecida é convertida para essa categoria. | Acrescentar suporte explícito a `origem=ability` nas novas escritas de redirects, preservando o histórico. |
| Ignorar `f3base_operaveis` resolve instalações antigas | A lista é um limite de acesso ativo. Ausência de um nome não demonstra que sua omissão foi acidental. | Habilitação explícita por site; nenhuma exceção oculta na rota. |
| `url_to_postid()` basta para provar destino | Identifica posts quando consegue; não comprova a resposta anônima e não cobre por si só arquivos de taxonomia. [E2] | Separar identificação local de observação HTTP. |
| Cadeia gera só aviso, mas todo destino imediato precisa responder 200 | As duas regras entram em conflito quando o destino é outra origem declarada. | Validar grafo e terminal 200; admitir cadeia declarada acíclica com aviso e sugestão de destino final. |
| Toda resposta deve ter Location igual ao destino | 410 representa remoção e tem tratamento próprio no runtime. [E3] | 410 sem destino navegável e sem Location. |
| Parâmetro de diagnóstico prova cache limpo | Um parâmetro pode mudar o caminho do cache ou ser ignorado pelo provedor. | Prova obrigatória na URL normal; consulta de diagnóstico separada. |
| Remover faz a origem voltar a 404 | Depende de conteúdo, canonical e outros redirects existentes. | Comparar ao comportamento anterior conhecido. Exigir 404 apenas na fixture criada com essa condição. |

Consulta que já pode reduzir a leitura do contrato na 1.10.2:

```json
{
  "nome": "f3base_redirects",
  "compacto": true,
  "incluir": []
}
```

Habilidade: `f3base/config-core-contrato-v1`. Essa consulta não abre a escrita.

A justificativa para usar um par explícito na mudança de pai é consistente com o Core e com o WordPress: o registro de slug antigo retorna sem ação quando o slug não muda e exclui tipos hierárquicos. Isso sustenta o risco técnico; a resposta HTTP específica de fator3capital.com.br continua dependendo de uma prova no momento da operação. [E1]

## 3. Escopo e ordem de implementação

| ID | Prioridade | Entrega | Dependência/resultado obrigatório |
|---|---|---|---|
| R01 | P0 | Serviço único de redirects: normalização, grafo, proposta e validação | Usado pelo painel, abilities e configuração genérica. |
| R02 | P0 | `redirects-ler` e `redirects-escrever` | Operações tipadas, simulação padrão e persistência integral com CAS. |
| R03 | P0 | Integração de `config-core-ler/escrever` | Lista completa usa R01; `mesclar=true` recusado para redirects. |
| R04 | P0 | Política de acesso e habilitação administrativa explícita | Respeita catálogo e restrições de cada instalação. |
| R05 | P0 | `redirects-verificar`, cache e evidências | Persistência, purga, auditoria e HTTP apresentados separadamente. |
| R06 | P0 | Auditoria e contrato 1.6.0 | Nova origem reconhecida; canal registrado; schemas e ajuda coerentes. |
| R07 | P0 | Interface administrativa e diagnóstico do legado | Mesmo validador e revisão; nenhuma regra removida em simples consulta. |
| R08 | P0 | Regressão, bancada e homologação escalonada | Aceites positivos/negativos e cenários com WP Super Cache/Yoast. |
| R09 | P1 | Roteiro operacional da pendência 47 e demais migrações | Executado somente após disponibilidade da versão e autorização de cada site. |
| R10 | P1 | Demais options e diagnóstico de acesso | §12.1; caminhos tipados e habilitação assistida R04. |
| R11 | P0 | Marcação de CTAs no pacote | §12.2; sem dependência de filtro do tema e sem dupla conversão. |
| R12 | P1 | Cache e convergência de sonda HTTP | §12.3; aproveita a sonda existente, com dependência MCP explícita. |
| R13 | P0/P1 | Versão das abilities, projeções e manifesto | §12.4; versão P0, projeções/manifesto P1; consumidor no canal 2. |
| R14 | P1 | Complementos e homologação de schema | §12.5; não duplicar o que a 1.10.2 já entregou. |
| R15 | P0/P1 | Homologação Google e entrega rápida de llms | §12.6; eventos P0, latência e hospedagem P1. |
| R16 | P0 | Isolamento de conversão e publicação coerente | §12.7; índice, full, `.md`, alternativas e arquivos físicos concordantes. |
| R17 | P1 | Adaptadores delimitados de blocos | §12.7; sem execução irrestrita de callbacks. |
| R18 | P0 | Slug histórico e mudança de base de taxonomia | §12.8; depende de R01–R06, não de uma escrita por fora. |
| R19 | P0 | Repositório próprio de leads e importação do legado | §14.3/14.9; migração idempotente de Flamingo e CPT, preservando histórico e contatos independentes. |
| R20 | P0 | Definições, editor, bloco/shortcode e validação de formulários | §14.4; regimes registro/WhatsApp, campos completos, múltiplas instâncias, POST sem JS. |
| R21 | P0 | Anexos privados e entrega autenticada | §14.5; proteção comprovada, metadados, retenção e limites efetivos da hospedagem. |
| R22 | P0 | Notificação interna por `wp_mail` | §14.6; padrão ligado para clique/formulário, destinatários, idempotência e estado independente da gravação. |
| R23 | P1 | Regime conteúdo e download com autorização temporária | §14.7; e-book privado, token, validade, concorrência e cache. |
| R24 | P0 | Painel, abilities, CSV e privacidade | §14.8; permissões próprias, consulta paginada e preservação da leitura agregada existente. |
| R25 | P0 | Migração de formulários e retirada de CF7/Flamingo | §14.9; ponte transitória, delta de novos envios, conferência por registro e recuperação sem perda. |
| R26 | P0 | Medição e regressão de desempenho da substituição | §14.10; um evento por aceite, consentimento, Google adiado, formulário nativo reconhecido pelo conversor llms. |

Sequência de redirects: R01/R04/R06 → R02/R03/R07 → R05/R18 → R08 → R09. R11/R16 e metadados de R13 podem ser desenvolvidos independentemente; R17 usa o isolamento de R16. Homologação de R15 ocorre antes de ampliar a escolha de Google na frota. Formulários: contratos/R19 → R20/R21/R22/R24 → R23/R26 → R25, com ensaio de migração desde R19. R11/R16/R17 precisam contemplar o bloco nativo. Integrações R12/R13 não condicionam correções locais à disponibilidade de uma versão futura do MCP.

Ficam fora do escopo: regex/curingas e prefixos arbitrários, redirects externos, migração automática de páginas, execução irrestrita de shortcodes e mudança automática da configuração do servidor. A antiga base de taxonomia passa a ter uma operação declarativa que gera pares exatos para os termos conhecidos (§12.8); não é uma regra textual ampla que capture qualquer URL sob o prefixo.

## 4. Contratos propostos

Todos os nomes e campos desta seção são propostas, ainda não entregues. Acesso administrativo exige `manage_options`. As rotas de escrita e simulação exigem também a permissão efetiva da option.

### 4.1 `f3base/redirects-ler`

Entrada: `origens` opcional, `pagina` (padrão 1) e `limite` (padrão 50, máximo 50).

Saída: lista normalizada, revisão opaca da lista inteira, total, paginação, permissões efetivas e, por par:

- chave da origem normalizada, status e destino;
- diagnóstico estático: par que gira, ciclo, duplicidade, cadeia e destino final sugerido;
- identificação local da origem/destino e última observação HTTP disponível;
- estado da evidência: `nao_verificado`, `atual` ou `desatualizado`, com data, revisão e contexto;
- motivos e campos afetados.

A resposta também apresenta a última atividade e o total registrado em `REDIRECTS_SERVIDOS`, identificando que são execuções observadas pelo Core. Hits servidos antes do PHP podem não incrementar esse contador.

Consulta não inicia HTTP, não limpa cache e não grava estado. `origem_viva`/`destino_vivo` não serão booleanos presumidos: devem indicar fonte, estado e instante. Leitura administrativa especializada continua possível quando a edição estiver restrita, como já ocorre no contrato; devolve claramente `operavel=false`.

### 4.2 `f3base/redirects-escrever`

| Campo | Regra |
|---|---|
| `operacao` | `adicionar`, `remover` ou `substituir_lista`. |
| `pares` | Obrigatório em adicionar/substituir; lista de objetos com `de`, `para` e `status`. `[]` permitido para substituir a lista por vazia. |
| `origens` | Obrigatório em remover; lista de caminhos. Não exigir um destino fictício para remover. |
| `revisao_esperada` | Obrigatória, 64 caracteres hexadecimais; obtida na leitura da lista. |
| `simular` | Booleano; padrão `true`. |
| `sobrepor_conteudo_vivo` | Booleano; padrão `false`; aplica-se apenas às origens criadas/alteradas. |

Regras:

1. `adicionar` recusa origem já existente após normalização, inclusive duplicidade dentro do próprio lote. Não há upsert implícito.
2. `remover` identifica pela origem normalizada; inexistente retorna `origem_nao_declarada` sem salvar parte do lote.
3. `substituir_lista` calcula e mostra o delta completo. É o caminho explícito para trocar um destino existente.
4. Campos desconhecidos já existentes permanecem preservados nas regras não alteradas. Uma operação não pode apagar registros legados omitidos pela leitura normalizada.
5. A entrada declarada recebe validação estrita de tipos/status/caminhos antes da sanitização. Status informado fora de 301/302/307/308/410 é erro; 301 é padrão somente quando omitido.
6. Simulação devolve `antes`, `depois`, delta, erros e avisos, sem alterar options, auditoria de configuração, permissões ou cache.
7. A simulação faz observações HTTP limitadas. Elas podem aparecer nos logs/contadores do servidor; não é uma promessa de ausência de todo efeito observacional.
8. Na aplicação, refazer validações dependentes do estado atual e usar CAS na gravação final. Uma simulação anterior não reserva páginas nem garante o mesmo resultado.
9. A origem de auditoria é determinada pelo ponto de entrada; o cliente não pode escolher ou falsificar `origem`/`canal`.
10. Operação sem delta não regrava procedência nem purga cache; devolve `changed=false`. Timeout da aplicação exige reler revisão/valor antes de reenviar.

Para 410, `para` pode ser omitido. A representação persistida mantém compatibilidade com o consumidor da 1.10.2 usando `para=de` quando faltar; o destino é ignorado no serviço HTTP. Um 410 legado com outro `para` continua legível, com aviso de campo sem efeito. A nova escrita não exige destino vivo para 410.

### 4.3 Integração com configuração genérica

`f3base_redirects` entra nos schemas nativos de `config-core-ler/escrever`. A permissão efetiva continua sendo conferida em execução.

A escrita genérica equivale a `substituir_lista`, com a mesma recusa integral, revisão, limites e prova. Proibir mescla genérica de arrays por posição, mesmo que o catálogo mantenha `campo=grupo`. Não deixar a simulação genérica aprovar um lote que a rota especializada recusaria.

A sobreposição de origem viva exige a operação especializada ou a confirmação correspondente no painel. O caminho genérico usa `sobrepor_conteudo_vivo=false`; não introduz uma autorização implícita.

### 4.4 `f3base/redirects-verificar`

Entrada proposta: `acao=consultar|verificar_publico` (padrão consultar), `origens`, `revisao_esperada` nas ações ativas e cursor de continuação quando necessário.

- `consultar`: lê evidência existente, sem HTTP/efeitos.
- `verificar_publico`: executa sondas limitadas e registra prova vinculada à revisão e ao contexto.
- Aceitar somente origens da lista atual ou removidas pela operação registrada correspondente; não criar um proxy HTTP arbitrário.
- Após escrita, a verificação é agendada ou iniciada somente depois da conclusão efetiva da purga. O retorno pode permanecer `pending`.
- Mudança de revisão, host/base, permalinks, conteúdo relevante ou geração de cache invalida a prova. Evidência expira após 24 horas.
- Falha/indisponibilidade de rede resulta em `status=pending` com código de verificação inconclusiva; resposta observada divergente resulta em `failed`. Preservar o enum de estados do contrato atual.
- `verified` exige cobertura de todos os alvos obrigatórios daquele lote. Informar escopo e não promover prova parcial a aprovação da lista inteira.

## 5. Validação e limites

### 5.1 Regras da proposta

| Código | Regra planejada |
|---|---|
| `caminho_invalido` | Somente caminho local. Validar antes/depois de decodificar; recusar esquema/host, barras que criem URL de rede, segmentos de travessia, controles, CR/LF e forma ambígua. Não truncar silenciosamente. |
| `status_invalido` | Tipo/status explícito incompatível. |
| `origem_duplicada` | Duas origens equivalentes no resultado ou adição sobre origem existente. |
| `par_gira` | Origem/destino equivalentes pelo mesmo comparador do runtime, exceto 410. |
| `ciclo` | Ciclo na lista resultante, inclusive com mais de dois nós. Erro informa o percurso. |
| `cadeia` | Cadeia declarada acíclica: aviso com percurso e terminal sugerido; terminal deve ser público e responder 200. Não achatar automaticamente nem apagar regras intermediárias. |
| `destino_nao_vivo` | Destino terminal observado em 404/410 ou identificado como conteúdo não público. |
| `destino_redireciona` | Destino retorna redirect fora da cadeia declarada analisada; exigir destino final explícito e nova simulação. |
| `origem_viva` | Origem identifica conteúdo público ou responde 200; recusa sem autorização explícita de sobreposição. |
| `origem_ja_redireciona` | Redirect de outro mecanismo na origem: recusa até resolver a precedência. O sinalizador de sobreposição de conteúdo não autoriza sobrescrever outro mecanismo. |
| `sobreposicao_autorizada` | Aviso obrigatório, com origem/identidade afetada, quando a sobreposição é permitida. O destino continua precisando ser válido. |
| `sem_barra_final` | Aviso de diferença em relação ao permalink canônico. Se causar um salto HTTP não declarado, aplicar também `destino_redireciona`. |
| `query_na_origem_ignorada` | O comparador atual remove a query da origem. Avisar que a regra vale para todo o caminho; não criar a falsa expectativa de condição por query. |
| `verificacao_inconclusiva` | DNS, TLS, timeout, acesso restrito ou orçamento insuficiente. Não classificar como destino inexistente; não persistir adição/alteração sem a validação obrigatória. |
| `conflito` | Revisão divergente antes da operação; nenhuma regra gravada. A corrida no CAS final também impede sobrescrita. |
| `limite` | Entrada/resultado excede teto; nenhuma redução automática da lista. |
| `legado_invalido` | Lista bruta contém informação que seria perdida pela normalização; exigir revisão explícita, sem “reparar” durante leitura. |

Grafo, duplicidade e par que gira devem usar uma única função de equivalência, compartilhada com a entrega pública. Preservar maiúsculas/minúsculas e a query do destino conforme o comportamento atual. Não introduzir propagação automática da query recebida.

Identificação de post publicado auxilia a análise, mas a prova de entrega exige GET anônimo. Um 200 HTTP isolado não comprova identidade editorial nem exclui todos os casos de soft 404. Para posts conhecidos, confrontar também estado público, ausência de senha, permalink e canônica; taxonomias e rotas públicas usam a prova HTTP correspondente.

Na remoção, não exigir que o destino antigo continue funcionando. O operador deve conseguir retirar uma regra quebrada. Registros legados inválidos permanecem visíveis; remoção explícita de defeitos deve ser possível sem acrescentar novas regras nem normalizar silenciosamente o restante.

A validação estrutural percorre a lista resultante inteira. A observação HTTP obrigatória na escrita cobre o delta e as cadeias afetadas; regras inalteradas não recebem uma nova aprovação por consequência. A inspeção completa usa a rota de verificação em lotes. Distinguir conflito de revisão comprovado de falha de banco quando o diagnóstico permitir; não atribuir toda recusa de persistência à concorrência.

### 5.2 Orçamentos iniciais propostos

Os tetos desta seção são do serviço de redirects. Não constituem limites globais do componente de formulários ou dos anexos tratados em §14.

- Lista ativa: até 200 pares. Listas legadas maiores continuam legíveis/ativas; permitir redução controlada, sem corte automático.
- Até 10 regras alteradas por escrita, incluindo exclusões. A substituição completa calcula esse limite pelo delta; operações maiores são divididas explicitamente.
- Caminho: até 500 caracteres, respeitando também o limite em bytes usado pela persistência atual; recusar excesso antes de truncar.
- Payload de escrita: até 128 KiB.
- Grafo local completo limitado à lista; profundidade de cadeia permitida: até 5 saltos.
- Validação HTTP: até 20 requisições, timeout máximo de 3 segundos por requisição e orçamento total de 20 segundos.
- Verificação pública: até 5 origens por lote, com continuação vinculada à revisão; até 20 requisições e 20 segundos por lote.
- Limitar corpo observado a 64 KiB. Truncamento impede afirmações sobre o corpo completo; não invalida automaticamente uma observação de status/cabeçalhos.
- Nenhuma ação HTTP no caminho normal do visitante. Sem cookies, credenciais do usuário ou redirecionamento automático da sonda.
- URL construída a partir de `home_url()`, com validação do destino público e dos limites do site; não aceitar hosts informados pelo cliente nem desabilitar validação TLS.

Esses tetos são decisões de projeto a confirmar na bancada, não capacidades já medidas. Se o orçamento impedir concluir a validação, devolver escopo pendente; nunca aprovar pelo simples esgotamento do tempo.

O transporte HTTP introduzido na 1.10.2 segue alguns redirecionamentos e não coleta todos os campos necessários. Deve receber um modo explícito e testado de “sem seguir”, com captura de Location, sem mudar os consumidores existentes de schema/llms.

## 6. Permissões: resolver a dependência sem abrir exceção

A 1.10.2 usa o catálogo como teto. Uma `f3base_operaveis` preenchida restringe esse teto; ausência ou lista vazia atualmente permite as options marcadas operáveis. Essa semântica deve permanecer documentada e testada.

Plano:

1. Marcar redirects como elegível no catálogo da 1.10.3.
2. Preservar integralmente as listas já persistidas; não acrescentar redirects durante o upgrade.
3. Exibir diagnóstico objetivo: permitido pelo pacote, permitido/restrito neste site e caminho oficial de habilitação.
4. Disponibilizar no painel uma ação administrativa separada para habilitar as options selecionadas, com `manage_options`, nonce, prévia do delta e revisão da política. O primeiro fluxo habilita somente redirects; acessos, sessão, SEO e outras escolhas exigem seleção explícita. A ação registra a decisão do administrador autorizado.
5. A ação passa por serviço proprietário do Core, com persistência/auditoria verificadas, preservando todas as demais permissões. Não expor uma ability que se autoautorize quando a opção está restrita.
6. O implantador deve respeitar a escolha e não reaplicar uma lista antiga durante futuras execuções. Antes da expansão na frota, confirmar o comportamento da versão efetivamente usada do implantador.
7. Para automação futura dessa habilitação, exigir contrato próprio de gestão de permissões e autorização explícita por site. Não usar SQL, `options/update`, alteração de arquivo ou exceção na rota de redirects.

Registrar a versão do catálogo e a procedência da política a partir desta release. Só uma linha de base identificada permite distinguir uma lista produzida pelo implantador de uma restrição deliberada. Em instalações sem essa informação, mostrar as diferenças e aplicar a seleção autorizada; não tratar a versão antiga como lista ausente. Nomes desconhecidos ou não elegíveis são diagnosticados e não concedem acesso. Preservar restrições explícitas e os dados originais até uma revisão autorizada.

Consequência para o aceite 8 do pedido original: conselar e ctooffice devem funcionar **após atualização e habilitação autorizada**, se a lista atual ainda os restringir. A release entrega rota e fluxo de habilitação juntos; a implantação em cada site só termina quando uma leitura/simulação real comprova o acesso solicitado. Instalar o ZIP e deixar a rota inacessível não fecha a pendência.

Não inferir que listas com 16 ou 18 nomes são erros. As quantidades e os oito sites citados precisam ser relidos no levantamento da implantação. A mesma solução não habilita automaticamente Google/SEO, que também permaneceram restritos no teste da 1.10.2.

## 7. Persistência, auditoria, cache e prova pública

### Persistência e auditoria

Preparar a proposta → validar integralmente → conferir revisão → gravar uma vez por `F3Base_Options::gravar()` com CAS → confirmar leitura → auditar → purgar → verificar.

A atomicidade cobre a lista de redirects. Ela não cobre conjuntamente conteúdo WordPress, cache, auditoria e rede. Falha posterior não deve converter `persisted=true` em “nada foi gravado”, nem provocar rollback automático sobre uma revisão mais nova.

Acrescentar `ability` ao modelo de origem suportado nas futuras escritas de redirects realizadas pelo canal, inclusive pela rota genérica delegada. Manter `canal=ability`; painel usa sua origem/canal próprios. Atualizar gravador, leitor de procedência, rótulos, enums/schemas, contrato e testes. Não mudar a autoria dos registros históricos nem inferir uma pessoa pela autenticação do conector.

### Resultado uniforme

| Campo | Significado |
|---|---|
| `persisted` | Lista pedida, validada e confirmada na persistência. |
| `changed` | Houve mudança efetiva. |
| `effect` | Limpeza aplicada, agendada, falhou ou não necessária. |
| `audit` | Registro de procedência confirmado ou pendente. |
| `verification` | Estado da observação pública, escopo, cobertura e motivo. |
| `revisao`/`lido` | Revisão e valor correspondentes à gravação confirmada. |
| `validacao`/`avisos` | Código, índice/origem, campo e descrição. |
| `ok` | Preservar semântica de compatibilidade do Core; não usar como sinônimo de aprovação HTTP. |

### Prova após purga

Para 301/302/307/308, consultar a origem sem sessão e sem seguir o redirect; conferir status e Location para o destino declarado, incluindo query e barra final. Consultar separadamente o destino/terminal e exigir 200; nas páginas e categorias do aceite, exigir também `text/html`.

Para 410, exigir status 410, ausência de Location, corpo mínimo apropriado e ausência do conteúdo do tema. HEAD não deve conter corpo.

Registrar duas observações quando houver diagnóstico de cache: URL normal e consulta diagnóstica. Um parâmetro aleatório, sozinho, não comprova BYPASS. Se só a consulta diagnóstica funcionar, a publicação normal não está verificada.

Usar o mecanismo de purga existente e aguardar seu efeito antes da prova. A purga local não comprova invalidação de CDN nem remove cópias já armazenadas em navegadores. Redirects permanentes podem ser armazenados por caches; ensaiar remoção/alteração com cliente novo e cache público real. [E3]

Guardar evidência limitada: status, Location, tipo de conteúdo, cabeçalhos relevantes, data, revisão, contexto, geração de cache e hash quando necessário. Não persistir HTML, cookies ou credenciais. Consultas exibem evidência antiga como histórica.

## 8. Aceite e testes

| ID | Cenário | Resultado esperado |
|---|---|---|
| T01 | `/x/` → `/x`, inclusive junto de par válido | `par_gira`; lote inteiro recusado, revisão/valor intactos. |
| T02 | Origem publicada → destino válido | Recusa sem sobreposição; com autorização explícita, aceita e avisa. |
| T03 | Destino inexistente, privado, com senha ou com login obrigatório | Recusa identificada; nenhum dado privado enviado pela sonda. |
| T04 | Timeout/DNS/TLS/orçamento | Inconclusivo, sem persistir adição/alteração; não rotular como 404. |
| T05 | Revisão antiga e corrida entre validação/CAS | Conflito; edição concorrente preservada. |
| T06 | Painel grava um par depois da leitura pela ability | Ability recusa revisão velha; nova leitura contém o estado corrente. Não deve inventar o par recusado. |
| T07 | A→B→A e ciclo de três nós | Recusa integral com percurso; proteção no runtime para legado cíclico. |
| T08 | A→B→C, terminal 200 | Aviso de cadeia e sugestão C; prova registra os saltos previstos. |
| T09 | Origem duplicada após normalização; query na origem | Duplicidade recusada; sem condição por query implícita. |
| T10 | Status inválido, truncamento, CR/LF, URL externa, caminhos codificados perigosos | Recusa explícita; sem descarte silencioso ou conversão para 301. |
| T11 | Par de taxonomia do Site-Teste | `/category/metodo/` → `/artigos/categoria/metodo/`: 301 e Location esperado; terminal 200 HTML, após confirmar pré-condições. |
| T12 | Remover regra de fixture criada sobre origem 404 | Origem volta a 404 após purga, na URL normal; lista anterior preservada. |
| T13 | Remover regra sobre outro comportamento anterior | Provar resultado esperado da fixture, sem exigir 404 universal. |
| T14 | 410 sem `para`, GET e HEAD | 410 sem Location, sem tema; round-trip compatível com a representação persistida. |
| T15 | Simulação, leitura e consulta de evidência | Sem mutação de preferências, política, auditoria de configuração ou cache. |
| T16 | Usuário sem capacidade e site com option restrita | Recusa; habilitação só pelo fluxo administrativo autorizado. |
| T17 | Política ausente, vazia, restritiva; habilitação/revogação explícitas | Semântica atual preservada; delta restrito e auditado; sem perda de outros nomes. |
| T18 | Falha de auditoria, falha de purga ou verificação | Persistência verdadeira preservada; cada etapa com seu estado; sem repetir escrita automaticamente. |
| T19 | Cache antigo, diagnóstico funciona e URL normal falha | `verification` não aprovada; cobertura/geração identificadas. |
| T20 | Prova antiga e mudança de revisão/contexto | Evidência invalidada; nenhum resultado antigo valida a nova configuração. |
| T21 | Paridades painel/rotas genéricas/especializadas | Mesmo valor, validação, permissão e efeito; mescla posicional recusada. |
| T22 | Legado com extras, entradas inválidas e lista acima do teto | Consulta preserva histórico; nenhuma perda por normalização; remoção/revisão explícitas. |
| T23 | Contagem de redirects e coleta de acessos | Prova HTTP imediata separada da agregação posterior; conferir 301 no período correto após coleta. |
| T24 | Upgrade 1.10.2 → 1.10.3 | Pares, conteúdo, permissões e auditoria histórica preservados; novas rotas descobertas com schemas nativos válidos. |
| T25 | Site em subdiretório, query de destino e variação de barra | Construção com `home_url` e matching coerentes; sem duplicar prefixo do site. |
| T26 | Content-Type/status válidos com resposta editorial errada | Limitação da prova indicada; fixtures conhecidas detectam login/soft 404/canônica divergente. |
| T27 | Interface | Teclado, foco, mensagens por par, conflito, simulação e confirmação da sobreposição; sem bypass pelo JSON do formulário. |
| T28 | Listas legadas com acessos/sessão/SEO ausentes, nomes desconhecidos e restrição intencional | Diagnóstico individual; nenhuma concessão por simples upgrade; habilitação selecionada com CAS/auditoria, sem reintrodução da lista antiga pelo implantador. |
| T29 | Leitura de option inexistente, estrutural e restrita pelo site | Códigos distintos, motivo e caminho suportado; schema aceita nomes catalogados para diagnóstico sem expor valores protegidos. |
| T30 | Cabeçalhos, navegação e cadência pelo canal | Simulação sem efeitos; escrita inválida integralmente recusada; menu válido e vínculo confirmado; um único cron coerente; cabeçalhos observados por HTTP. |
| T31 | CTA canônico, alias de tema, marcação preexistente e inserção dinâmica | Marcação idempotente e um único lead por ação; sem alterar href/número sem o opt-in do contrato; clique por teclado e móvel preservados. |
| T32 | Artefato de cache protegido, público, inexistente e resposta de erro com corpo | Avaliar conforme perfil; não aprovar só por HEAD/corpo vazio; sem arquivo elegível, evidência inconclusiva; agendamento não multiplica a cadência. |
| T33 | Sonda GET/HEAD, cabeçalhos permitidos, truncamento e redirecionamento | Resultado por asserção; `nao_contem` inconclusivo se corpo truncado; hash de escopo explícito; HEAD não representa corpo completo; Location sem seguir no modo correspondente. |
| T34 | MCP ausente/antigo/compatível e chamadas REST legadas | Diagnósticos Core continuam disponíveis; integração usa contrato negociado; uma execução não dispara duas sondas equivalentes; sem quebra silenciosa de clientes. |
| T35 | Descoberta de todas as abilities Core | `meta.fator3.version=1.10.3`, constante do pacote; contrato 1.6.0 separado; projeção MCP não vazia; todos os schemas válidos. |
| T36 | Consulta ampla, compacta e `incluir=[]` | Ampla mantém compatibilidade; compacta não repete tokens/provas idênticas; referências resolvem; histórias de outra geração permanecem distintas; registrar bytes antes/depois. |
| T37 | Manifesto e pacote divergentes, versão incompatível ou hash incorreto | Consumidor do canal 2 recusa antes da instalação; manifesto Core corresponde ao ZIP; rollback usa pacote conhecido e não presume reversão automática dos dados. |
| T38 | Schema com organização principal, controladora, filhas e dois emissores | Relações legítimas aceitas; identidades conflitantes e duplicação da entidade principal identificadas; não exigir um único nó Organization global. |
| T39 | `sameAs` Core/Yoast/ambos/terceiro; HTTPS inválido; 301/404/403 | Guarda local na escrita, proveniência fundamentada e prova HTTP separada; 301 é revisão, 404 é recurso quebrado, bloqueio/timeout inconclusivo; nada apagado automaticamente. |
| T40 | Pessoa por página, autoria institucional e conta técnica | Person só nas páginas declaradas, com identidade estável; `post_author` preservado; aviso fundamentado de conta técnica; tema e Core não duplicam nós. |
| T41 | Google nos dois modos, clique antes do script, saída rápida, CF7 e consentimento | Medir recebimento real de GA4/Ads sem duplicação e perda atribuível ao adiamento; comportamento e perda residual documentados antes de escolher modo por site. |
| T42 | Visita de 10 s, interação tardia e timeout Google | Comparar `user_engagement`/tempo medido e consentimento com modo imediato; relógio do teto vem do `load`; gatilhos não carregam Google duas vezes. |
| T43 | CSS inline/externo e métricas web-vitals | Visual/teclado/CSP válidos; padrão sem folha bloqueante; LCP/CLS/INP não se perdem por uma eventual mudança do momento de coleta. |
| T44 | llms dinâmico/físico com cache frio/quente e atualização de conteúdo | Medir protocolo do §12.6; GET/HEAD, MIME, invalidação e 304 quando aplicável; nenhum arquivo alheio sobrescrito nem conteúdo tornado privado preservado publicamente. |
| T45 | Um item inválido entre válidos e todos os itens inválidos | Índice aponta inválidos para HTML; full contém somente conversões válidas com cobertura; `.md` indisponível não anunciada; zero conversões tem comportamento explícito do §12.7. |
| T46 | Alterar item válido para inválido/privado e corrigir novamente | Invalidar índice/full/Markdown/alternativas e cópias físicas em conjunto; invalidade não contamina outros itens e correção readmite o item. |
| T47 | Bloco dinâmico desconhecido, shortcode com efeito e consulta com conteúdo protegido | Callback/shortcode arbitrário não executa; fallback HTML; adaptador só divulga publicações elegíveis dentro dos limites; interface excluída aparece no diagnóstico. |
| T48 | Conteúdo excede orçamento ou trabalho de conversão ainda não terminou | Não publicar versão anterior sabidamente inelegível; distinguir pendente, excluído e falha global; sem falso “full completo” nem truncamento silencioso. |
| T49 | Permalink `/artigos/%postname%/`, URL antiga de um nível e query vars vazias | Slug histórico exato e único chega ao conteúdo público correto; sem histórico, mantém 404. |
| T50 | Slug repetido, conteúdo privado, URL de vários níveis e caminho malformado | Não redirecionar por coincidência do último segmento; conflito diagnosticado; regra explícita necessária. |
| T51 | Base antiga de categoria, hierarquia e post com prefixo semelhante | Pares completos chegam ao termo correto antes da adivinhação; `slack` não vai para artigo com slug semelhante; `slackware` não casa com `slack`. |
| T52 | Taxonomia muda entre planejamento e aplicação; regra existente conflita | Snapshot/revisão divergentes recusam aplicação; não sobrescrever pares; replanejar; lotes respeitam limites e mostram cobertura restante. |
| T53 | Migração Flamingo/CPT com inbox, spam, lixeira, `_field_*`, contatos e etiquetas | Reconciliação por identidade de origem e campos/hashes, incluindo snapshots; contatos independentes preservados sem virar conversões. |
| T54 | Migração interrompida, repetida e com novos envios durante o processo | Retomada por cursor; unicidade de origem; delta final; nenhuma mensagem perdida, sobrescrita ou contada duas vezes. |
| T55 | Importação e restauração de suspeito | Sem e-mail/eventos para registros importados; aprovação manual pode gerar aviso único, mas não inventa sessão nem envia GA4 retroativo do navegador do administrador. |
| T56 | Clique WhatsApp, formulário válido, inválido, suspeito e duplo envio | Estados distintos; registro/deduplicação atômicos; dados suspeitos preservados dentro do schema; falha real de banco não retorna duplicata/sucesso. |
| T57 | Editor e rota de `f3base_formularios` | Mesmos erros por campo, simulação/CAS e permissões; IDs únicos; definição alterada desde o render exige tratamento explícito de revisão. |
| T58 | Campo desconhecido, opções adulteradas, cabeçalho injetado e HTML malicioso | Recusa ou escape conforme contrato; campos estáticos permitidos não executam script; destinatário/arquivo/destino nunca vêm de valor arbitrário do visitante. |
| T59 | Sem JS, HTML em cache, token vencido e duas instâncias | POST comum com resposta legível/303; nenhum ID de submissão reutilizado entre visitantes por causa do cache; nomes/labels por instância; repetição controlada. |
| T60 | Abrir diálogo, focar campo, submit inválido e submit aceito | Abrir/focar não cria lead; `form_start` uma vez por instância; aceite uma vez por submissão; listener legado não transforma clique em campo em conversão. |
| T61 | Formulário WhatsApp com resposta assíncrona e pop-up bloqueado | Persistência precede encaminhamento; URL montada pelo servidor; fallback de link utilizável; nenhum bloqueio de janela causa perda ou duplicação de lead. |
| T62 | Upload PDF/ZIP/extensão arbitrária e MIME divergente | Sem teto/tipos globais impostos pelo pacote; observar configuração opcional do formulário; alertar divergência e nunca executar/descompactar conteúdo. |
| T63 | Pasta privada, leitura sem login, symlink/travessia e proteção inconclusiva | Arquivo real inacessível diretamente; capability exigida; sem download por ID/caminho adulterado; upload só habilita depois da prova de proteção. |
| T64 | Upload excede PHP/proxy, mais arquivos que o permitido, disco cheio e interrupção | Erro claro quando observável; nada de aceite com anexo perdido; arquivos temporários/órfãos reconciliados; sem carregar arquivo inteiro na memória. |
| T65 | Falha `wp_mail`, retorno verdadeiro, repetição e teto horário | Lead permanece salvo; estado de processamento separado de entrega observada; nenhuma repetição automática de aviso já confirmado; resumo pendente visível. |
| T66 | Quatro respostas automáticas legadas ao visitante | Detectadas no inventário; textos essenciais migrados para confirmação; nenhum e-mail ao visitante sob a decisão vigente. |
| T67 | Token de conteúdo inválido/vencido, GETs concorrentes, HEAD e quota | Nenhum bypass; incremento atômico; HEAD não consome; política de Range definida; sem cache compartilhado ou vazamento do token em analytics. |
| T68 | Mesmo e-mail/conteúdo, token esgotado e nova solicitação válida | Mesma concessão ativa não duplica conversão; cota não é reiniciada silenciosamente; esgotamento permite nova concessão conforme regra explícita, sem revelar dados do contato anterior. |
| T69 | Painel/canal/exportação, permissões insuficientes e CSV com fórmula | Dados e anexos protegidos; paginação estável; CSV neutralizado; leitura agregada legada preservada; consulta não muda estado. |
| T70 | Retenção, eliminação, restauração e registro de arquivo com remoção falha | Registro, anexo, tokens e cópias legadas tratados; falha de arquivo fica pendente e sem acesso; dado eliminado não reaparece ao repetir importação. |
| T71 | GA4 nos quatro métodos, consentimento negado, JS desligado e sessão ausente | Eventos somente em contexto elegível; nenhuma PII como parâmetro GA4; ausência de sessão não bloqueia contato nem vira sessão fabricada; métodos antigos continuam interpretáveis historicamente. |
| T72 | Página sem formulário, com formulário/CF7 e Google imediato/adiado | Sem assets/requisições adicionais do componente onde ausente; comparação controlada de recursos e métricas; não prometer nota ou fim fixo do Lighthouse. |
| T73 | Bloco/shortcode nativo no llms e diálogo com conteúdo privado | Conversão referencia formulário público sem renderizar interface/token; e-book/anexos/confirmadores privados nunca entram em índice/full/Markdown. |
| T74 | CF7 e Flamingo desativados e depois removidos no piloto | Todos os formulários, avisos, histórico, painel, anexos e métricas continuam operacionais; diagnóstico não acusa Flamingo ausente; inventário sem dependências residuais. |

Aplicar unitários para regras puras, integração real para options/CAS/abilities, HTTP controlado para falhas e hospedagem para cache/entrega. Validar detectores com variantes que falhem pela causa esperada. Falha de infraestrutura não conta como detecção de defeito.

Executar a suíte principal e as regressões existentes de schema, llms, consentimento e Google. Os gates de navegador que ficaram pendentes na 1.10.2 permanecem pendentes até uma execução válida; a nova versão não herda uma aprovação inexistente.

## 9. Implantação e uso nos casos citados

### Implantação da versão

Ordem proposta no pedido: Site-Teste → korvena.net.br → piloto fator3.com.br/korvena.com.br → frota. Confirmar ambiente, responsável e autorização antes de cada etapa. Esse roteiro não constitui autorização para alterar esses sites agora.

No Site-Teste: levantar lista/revisão/permissões e resposta anterior das URLs; habilitar pela via autorizada quando necessário; simular, aplicar, verificar, remover fixture e confirmar restauração. Em conselar/ctooffice, validar a política efetiva após habilitação e demonstrar que o restante da lista foi preservado.

Parar expansão se houver perda de pares, ampliação indevida de acesso, laço, publicação divergente, ou falha de cache sem prova conclusiva. Guardar pacote anterior e snapshot da configuração; rollback da lista sempre com revisão atual e autorização, sem restaurar banco inteiro.

### Pendência 47 — fator3capital.com.br

Pré-condições: reler página 15 e revisão, lista de redirects, política de acesso, pai atual, URL canônica atual/nova e conflitos. Os dados de 24/09 do pedido são ponto de partida.

1. Confirmar que a nova rota está operacional e que há capacidade de reverter a mudança de pai.
2. Ler o schema efetivo de `content/update-page`; o pedido relata divergência `parent`/`parent_id` no MCP 0.12.1. Correção dessa descrição pertence ao plugin MCP, não ao Core.
3. Atualizar o pai pelo contrato de conteúdo com revisão esperada.
4. Concluir a purga relacionada à alteração de conteúdo e confirmar novo permalink e destino anônimo 200. Conferir também que um 200 antigo em cache não está sendo confundido com conteúdo ainda publicado na origem. Se o destino não estiver válido, interromper e restaurar o pai mediante revisão atual e ausência de conflito.
5. Simular e aplicar imediatamente o par antigo → novo. Esse processo tem uma janela de 404; duas chamadas seguidas não formam uma transação atômica.
6. Se o par persistiu e a purga/prova falhou, tratar o efeito pendente. Não repetir a escrita nem reverter conteúdo supondo que nada foi salvo.
7. Se a escrita do par falhar sem persistir, executar a recuperação planejada da página, desde que sua revisão ainda seja a esperada. Conflito exige reavaliação; não sobrescrever edição concorrente.
8. Verificar nova URL 200/canônica própria; antiga 301 com Location correto; menu/rodapé/404; sitemap do Yoast; llms e Markdown quando habilitados.
9. Consultar Search Console posteriormente, registrando `lastCrawlTime`. Dados de rastreamento anteriores à mudança não demonstram seu resultado atual.

Os demais casos seguem depois, com inventário e autorização por site. Não colar uma lista de um único par sobre uma lista existente: usar adicionar ou substituir com delta explícito.

Manter redirects permanentes por prazo duradouro; o Google orienta, em geral, pelo menos um ano. Ausência recente de impressões não justifica removê-los enquanto existirem links/acessos relevantes. Essa orientação complementa a regra do pedido de manter enquanto houver impressões. [E4]

## 10. Documentação, arquivos e pendências herdadas

Principais pontos de implementação:

- `class-f3base-modulo-redirects.php`: comparador/grafo, proteção do legado, 410, atividade e avisos.
- `class-f3base-options.php` e traits de catálogo, validação e persistência: schema correto de lista, recusa integral, CAS, nova origem e preservação.
- `class-f3base-core-config-mcp.php` / `class-f3base-config-contrato.php`: rotas, enum, paridade, mescla recusada e contrato 1.6.0.
- Novos serviços específicos de proposta/sonda, com responsabilidade explícita e orçamento.
- `class-f3base-cache-pagina.php` / módulo de cache público: reaproveitar invalidação e efeitos, sem modificar a configuração do provedor.
- `class-f3base-http-publico.php`: modo sem seguir redirecionamento e Location; regressão dos consumidores atuais.
- Painel, `como-usar`, `docs/OPERACAO.md`, instruções geradas, changelog, inventário, manifesto e lista explícita de fontes.
- Novos estados de verificação: propriedade do Core, tamanho/expiração limitados, proteção contra escrita genérica e limpeza na desinstalação.

O `como-usar` deve mostrar número de pares, problemas, limite efetivo de acesso, consulta curta, sequência ler/simular/aplicar/verificar, tratamento de `persisted=true` com efeito pendente e restauração com CAS.

Preservar as pendências reais da 1.10.2 no relatório da próxima versão:

| Pendência | Tratamento |
|---|---|
| Navegador: homologação parcial | Reexecutar gates em ambiente funcional; não declarar aprovação por testes de API. |
| PageSpeed e recebimento Google real | Manter como validação pendente; sem prometer ganho de nota/conversões. |
| llms físico: cache de dois dias e 304 não confirmado | Manter modo dinâmico até ajuste/verificação HTTP na hospedagem; não alterar regras do servidor automaticamente nesta release. |
| Rich Results Test e temas completos | Completar conforme escopo original; inspeção do grafo pelo Core não equivale à aprovação do Google. |
| Google/SEO fora da lista operável do Site-Teste | Permissões preservadas; habilitação não é consequência da nova rota de redirects. |

Entrega final da implementação: ZIP instalável com link de download, ZIP de fontes reproduzível, manifesto do pacote, contrato e documentação atualizados, relatório com versão/ambiente/hash e matriz de evidências. Identificar claramente gates aprovados, falhos, pendentes e não aplicáveis. O download da futura implementação não é substituído por este plano.

## 11. Fontes e limites da análise

Fontes locais efetivamente lidas:

- Pedido anexado `pedido1.md` (base remota relatada: 1.10.1/contrato 1.4.0).
- Código entregue da 1.10.2: arquivos citados na seção 10, `class-f3base-config-consultas.php`, `class-f3base-publicacao-sonda.php` e trechos de auditoria/admin.
- Plano consolidado e relatório/evidências da 1.10.2 produzidos nesta conversa.
- Lista de 15 pedidos desta conversa; `site-core(1).md` e `pagespeed.txt` já disponíveis localmente.
- Conversor e módulos de llms/Markdown/full, `class-f3base-seo-entidade.php`, `class-f3base-autoria.php`, verificador de schema, módulo de CTAs, cadência, CSS/JS de consentimento/tracking e `assets/vendor/web-vitals.js` da 1.10.2.
- `pedido2(1).md`, código local de endpoint/retenção/consultas e código de CF7/Flamingo consultado no Site-Teste; escopo, constatações e referências adicionais em §14.

Referências primárias consultadas em 24/09/2026:

- **E1 — WordPress:** [wp_check_for_changed_slugs](https://developer.wordpress.org/reference/functions/wp_check_for_changed_slugs/).
- **E2 — WordPress:** [url_to_postid](https://developer.wordpress.org/reference/functions/url_to_postid/).
- **E3 — IETF:** [RFC 9110 — semântica HTTP, redirects e 410](https://www.rfc-editor.org/rfc/rfc9110.html).
- **E4 — Google:** [Mudanças de URL e migrações](https://developers.google.com/search/docs/crawling-indexing/site-move-with-url-changes).
- **E5 — Google:** [Organization: propriedades e imagens](https://developers.google.com/search/docs/appearance/structured-data/organization).
- **E6 — Chrome/Lighthouse:** [Auditoria llms.txt](https://developer.chrome.com/docs/lighthouse/agentic-browsing/llms-txt).
- **E7 — WordPress:** [render_block: filtros, contexto e execução](https://developer.wordpress.org/reference/functions/render_block/).
- **E8 — WordPress:** [Update URI no cabeçalho de plugins](https://make.wordpress.org/core/2021/06/29/introducing-update-uri-plugin-header-in-wordpress-5-8/).

As referências ao “Padrão”, “Conector”, “Orientação” e ao backlog de frota foram recebidas por meio do pedido. Não foi realizada nesta análise uma auditoria das versões integrais desses documentos ou das catorze instalações. Antes da implementação/implantação, confirmar regras vigentes que afetem autorização, sequência de frota e retenção de redirects.

O link do artifact Claude indicado no pedido 9 não pôde ser recuperado nesta revisão. A avaliação usa o detalhamento fornecido na mensagem e o documento local de schema; não se presume que o artifact remoto tenha conteúdo idêntico ou nenhuma revisão adicional. O arquivo `claude/redirects-2026-09-24-pedido-rota.md` e o estado da frota não foram recuperados por esse caminho; a proposta detalhada local de redirects e a mensagem são as fontes disponíveis. O código do MCP e do implantador não foi auditado nesta revisão: suas entregas abaixo são contratos de integração propostos, não capacidades verificadas.

## 12. Detalhamento das inclusões

### 12.1 Options e permissões — pedidos 1 e 2

Separar no contrato `elegivel_no_catalogo`, `permitida_no_site`, `gravavel_agora`, `motivo` e `caminho_suportado`. Os nomes são propostos. Não usar `option_nao_operavel` como única explicação para desconhecido, estrutural ou bloqueado pela lista.

`config-core-ler` deve aceitar no schema os nomes conhecidos do catálogo, mesmo quando não graváveis, para devolver diagnóstico preciso. Isso não autoriza revelar valores de options internas/sensíveis. Consulta sem nome deve poder listar exclusões e motivos de forma compacta. Leitura de configuração não habilita permissões nem executa migração.

| Option | Caminho planejado | Guardas e efeitos específicos |
|---|---|---|
| `f3base_redirects` | Rotas especializadas e genérica delegada (§4) | P0; lista atômica, CAS, grafo, origem/destino e prova por origem. |
| `f3base_robots` | Manter `config-core-ler/escrever` existente | Resolver acesso do site; preservar dono do arquivo, geração e verificação já existentes. |
| `f3base_seo_entidade` | Manter `config-core-ler/escrever` existente | Simulação/CAS e guarda local de `same_as`; complementar §12.5. |
| `f3base_cabecalhos` | Tornar elegível na rota genérica depois da validação estrita | Somente chaves/vocabulários declarados; rejeitar CR/LF e CSP inválida com recusa integral. Não “aceitar” enquanto preserva silenciosamente um campo antigo. Mostrar impacto de COOP/popups e HSTS na simulação; confirmar entrega HTTP após purga. |
| `f3base_nav_id` | Tornar elegível para vínculo com navegação existente | É ID de post `wp_navigation`, não ID HTML. Exigir inteiro positivo, post do tipo correto, publicado e vínculo compatível com o contrato do tema. Não criar/apagar menus nessa chamada; recusar zerar/desvincular pela rota genérica. Provar menu no front-end e permitir restauração com revisão atual. |
| `f3base_cadencia` | Tornar elegíveis `periodicidade` e `apos_n_ajustes` | `hook` e `mecanismo` definidos pelo serviço e somente leitura para o agente; rejeitar tentativa de alterá-los. Reagendar só após persistir, sem duplicar cron nem apagar histórico. `f3base_cadencia_estado` continua interna. |

Todas as novas escritas usam `F3Base_Options::gravar()`, revisão, simulação sem efeitos e auditoria do canal. A abertura só ocorre depois de validar tipos estritamente, antes dos sanitizadores atuais; permissões R04 continuam aplicáveis. Contrato/painel devem declarar os campos bloqueados e a forma de restauração, evitando uma mensagem genérica sem saída.

Para as seis instalações relatadas com acessos/sessão ausentes, preparar a prévia específica de habilitação e verificar leitura/simulação após a aplicação autorizada. Em philon, mostrar separadamente os três nomes que o catálogo não abre; tê-los na lista não os torna operáveis. A implantação deve registrar versão e decisão de política para que o implantador não volte a gravar o conjunto antigo.

### 12.2 CTAs e contrato de marcação — pedido 3

O Core passa a reconhecer `f3base-acao-contato` e a aplicar a marcação contratual no elemento acionável, usando processamento de tags, sem regex sobre HTML inteiro. Declarar aliases de classe exatos por site, incluindo a possibilidade de `f3capital-acao-whatsapp`; validar lista curta de tokens de classe, sem seletores ou JavaScript livres.

Com a inclusão do formulário nativo (§14), distinguir CTA que inicia contato de botão que apenas abre o contêiner. A abertura de diálogo não recebe carimbo de lead. O listener legado de cliques deve ignorar o contêiner do formulário nativo e seus campos; a aceitação da submissão é que dispara o lead. Não aplicar marcação por classe de aparência sem essa distinção de ação.

Carimbar saída de blocos/conteúdo sob controle do WordPress e contemplar CTAs já presentes ou inseridos dinamicamente via inicialização idempotente do módulo. A leitura do clique deve resolver o link correto mesmo quando a classe está no invólucro do botão. Não marcar todos os links de contato indiscriminadamente.

Preservar `data-f3base-lead` já declarado e os identificadores do CTA. Alterar número/href continua exigindo `data-f3base-numero` conforme o contrato atual; o carimbo de medição não concede essa autorização. Não instalar um segundo listener nem duplicar o evento quando o tema já carimba. Confirmar clique, teclado, nova aba, consentimento e canais de destino.

O implantador configura aliases e só retira filtros redundantes dos temas depois da comparação funcional. A atualização do pacote não edita `functions.php` dos sites.

### 12.3 Cache e sonda única — pedidos 4 e 5

Reaproveitar `F3Base_Publicacao_Sonda`: a 1.10.2 já aceita GET/HEAD, asserções de status/cabeçalho/conteúdo, hash e inspeção de um artefato elegível do WP Super Cache. A lacuna não é ausência total de ability.

Integrar a prova do artefato à mesma execução/cadência de `cache.tokens`, com geração, perfil, data e orçamento compartilhados. Selecionar arquivo público existente e elegível dentro do diretório permitido; não aceitar caminho arbitrário fornecido pelo cliente, travessia ou arquivo de outro site.

- Perfil protegido: GET não deve entregar o artefato. 403/404/410 podem ter uma página de erro com corpo e ainda impedir a exposição. Um 200 vazio isolado não basta para aprovar.
- Perfil público deliberado: entrega do cache pode ser esperada; conferir o conteúdo público correto e ausência de dados privados, em vez de exigir corpo vazio.
- Sem artefato elegível, timeout ou resposta ambígua: inconclusivo com motivo. Uma URL de arquivo que nunca existiu não prova proteção do diretório.
- HEAD não substitui GET nessa prova. Uma amostra aprovada comprova o alvo/perfil observado, não todos os arquivos do diretório.

Destino arquitetural: uma sonda genérica no canal 3/MCP, com GET/HEAD, cabeçalhos de requisição permitidos, modo explícito de seguir/não seguir, limites, SHA-256 e resultado por asserção. Cabeçalhos como `Accept` e condicionais são tipados; não encaminhar cookies, credenciais, `Host` arbitrário ou cabeçalhos de autenticação. Outros métodos não entram sem caso de uso e contrato de efeitos próprios.

O Core mantém os verificadores de domínio: eles escolhem alvos e avaliam schema, publicação, redirects e cache. Reutilizar transporte compatível do canal quando houver integração local versionada; não criar dependência de uma sessão remota de agente para o cron. Até isso existir, preservar transporte local, sem executar os dois na mesma prova. Rota REST antiga fica como adaptador de compatibilidade, com depreciação documentada antes de retirada.

`sha256` identifica os bytes efetivamente lidos, com tamanho e indicador de truncamento; não é hash do corpo completo quando a leitura foi limitada. Asserção `contem` pode ser confirmada se encontrou o trecho; `nao_contem` exige corpo completo. HEAD torna asserções de corpo não aplicáveis. Leituras de evidência não geram nova rede.

### 12.4 Metadados, respostas e atualização — pedidos 6, 7 e 8

**Versão:** centralizar registro de `meta.fator3.version` usando a constante do pacote em todas as abilities `f3base/*`. A versão descritiva do contrato continua separada. Validar a saída nativa e sua exposição pelo MCP, sem inventar uma versão no consumidor para ocultar metadado ausente.

**Projeções:** na forma compacta, manter um único objeto de tokens em `cache.evidencia.tokens` e uma referência documentada em `cache.tokens`, ou omitir a duplicata quando o schema da projeção permitir. Comparar ID/geração e conteúdo antes de deduplicar; histórico distinto não é cópia. A forma ampla atual preserva seus campos durante a compatibilidade de v1. Documentar `compacto=true`, `incluir=[]` e inclusão seletiva; não afirmar que todas as rotas de configuração anexavam integrações, pois as projeções diferem. Medir bytes da mesma consulta antes/depois.

**Manifesto:** publicar por pacote identificador estável, versão, requisitos WordPress/PHP, compatibilidade de contrato/MCP, URL HTTPS do ZIP, tamanho, SHA-256 e notas da versão. Gerar a partir do ZIP final e verificar correspondência com cabeçalho/constantes. O consumidor do canal 2 é responsável por catálogo de origem confiável, obtenção, comparação, autorização de aplicação e rollback do pacote. Hash recebido de uma origem não confiável não autentica o fornecedor.

Manter `Update URI: false` enquanto o canal oficial não estiver integrado; retirar o cabeçalho não cria um canal de atualização e pode reabrir colisões com o diretório público. O WordPress documenta esse uso e a integração de provedores próprios. [E8] Não declarar atualização automática pronta apenas porque um manifesto foi gerado. A versão Core pode ser distribuída por ZIP enquanto o aceite do consumidor MCP está pendente, com essa limitação explícita.

### 12.5 Schema — pedido 9

Preservar os campos da 1.10.2: identidade legal/CNPJ, endereço, descrição/contato, relações com identificadores, autoria institucional e guarda local de `same_as`. A política de autoria por post já permite usuário ou organização; isso **não equivale** à coleção declarada de pessoas do pedido original.

Completar nesta versão:

1. Coleção `pessoas` com nome, cargo, descrição, `same_as`, páginas públicas associadas e `id` opcional, preservando leitura compatível da chave legada `pessoa`. Emitir Person apenas nas páginas declaradas e quando houver informação correspondente no conteúdo; deduplicar por identidade e não inventar credenciais, cargo ou vínculo. `post_author` permanece como responsável editorial do WordPress.
2. Aviso de possível conta técnica quando houver evidência, incluindo o caso existente de nome igual ao login. Permitir classificação explícita no contrato; não concluir que toda conta administradora/agência é um autor inválido, nem trocar autoria automaticamente.
3. Diagnóstico do Yoast em modo organização sem logo/Organization e em modo pessoa. Informar a configuração e o grafo observados, sem afirmar comportamento idêntico em toda versão do Yoast.
4. Origem de cada `sameAs`: `yoast`, `f3base`, `ambos` ou origem não determinada/terceiro, com base nas listas e no grafo efetivos. Se um filtro alterou o valor, não atribuí-lo ao Yoast por adivinhação. Remoção deve indicar todas as fontes que o reintroduzem.
5. Avisos coerentes para contato ausente, endereço sem CEP e autor sem URL resolvida por referência. Não promover automaticamente todos esses avisos a erro obrigatório do Google: a documentação de Organization recomenda propriedades aplicáveis, sem conjunto universal de campos obrigatórios. O mínimo do logo é 112 × 112 px. [E5]
6. Diagnóstico de organização principal ausente/conflitante, JSON inválido e referência órfã; distinguir organização principal de controladora/filhas. Vários blocos JSON-LD merecem identificar emissores, mas não são inválidos apenas pela contagem. Preferência da frota por um emissor é política operacional separada.

`sameAs` precisa representar a mesma identidade; HTTP 200 não comprova esse significado. Guarda sintática continua local e determinística na escrita. Redirecionamento é aviso para usar URL final, 404/410 é recurso quebrado e bloqueio de robô/timeout é inconclusivo; não apagar perfil nem impedir toda gravação por indisponibilidade remota. A política de frota pode exigir 200 direto para concluir sua homologação, sem apresentá-la como regra universal do Schema.org.

Manter o Yoast como dono do grafo-base; migrar dados dos temas antes de remover seus filtros, em tarefa do implantador. Conferir resultado publicado e Teste de pesquisa aprimorada manualmente; o verificador próprio não promete rich results nem substitui a avaliação do Google. Nenhum dado específico de empresa é embutido no pacote.

### 12.6 Desempenho e llms físico — pedidos 10, 11 e 12

O modo Google e o CSS inline já estão implementados. O trabalho é provar comportamento, corrigir defeitos encontrados e decidir configuração por site. Manter as treze instalações com GA4 conforme a decisão recebida; bloquear `gtag.js` serviu como experimento, não como proposta de retirar medição.

Comparar modo imediato com interação/teto de 5 s após `load`, em home sem formulário e com CF7. Medir TBT/LCP/INP e recebimento real de `generate_lead`, conversões Ads e engajamento GA4. O teste de clique que navega antes de o script carregar é gate: fila local por si só não prova recebimento após a saída. Não atrasar a navegação indefinidamente para melhorar a medição; perda residual e mudança do relógio de engajamento precisam aparecer no relatório.

Não escolher o teto só para ultrapassar o fim do Lighthouse: o mesmo comportamento deve valer para visitantes e testes, sem detecção de PSI/user-agent. Os tempos de 2,3–2,4 s e 7,3 s foram observações relatadas de páginas específicas, não garantia do término futuro da auditoria. Um teto de 5 s pode ocorrer durante a medição com CF7.

Para `/llms.txt`, preferir a entrega física gerenciada já existente quando a hospedagem cumprir o contrato. Gerar na alteração relevante e na rotina de manutenção; atualizar apenas quando bytes mudarem. Não reescrever nem reconstruir todo o conteúdo a cada visita. Atualização oportunista deve ser limitada, com trava e verificação de vencimento. Respeitar arquivo preexistente de outro dono, escrita atômica e modo dinâmico de fallback.

Pendência concreta da homologação 1.10.2: arquivo físico servido com cache de dois dias e resposta condicional 304 não confirmada; por isso foi mantido o modo dinâmico no teste. O ajuste de hospedagem é definir política apropriada para o arquivo exato, revalidação por ETag/Last-Modified e purga efetiva quando mudar, comprovando GET/HEAD e pedido condicional. Não aplicar regra global no servidor ou alterar `robots.txt` para resolver llms. Se o servidor/CDN continuar servindo bytes antigos, manter modo dinâmico/cache controlado até a correção.

Aceite de desempenho: em cada piloto, registrar cliente/local de medição, versão, modo, headers, tamanho, TTFB e tempo total de 20 GETs sem sessão na URL normal, incluindo primeira resposta e série quente. Meta operacional proposta: p95 do tempo total ≤ 1 s; registrar máximo e repetir sob cache frio controlado. Não prometer ≤ 1 s para toda rede/hospedagem. PSI continua evidência complementar. A documentação atual do Lighthouse diz que erro de servidor reprova e 404 é não aplicável; o prazo exato de 2 s/versão 13.5 relatado deve ser conferido no relatório usado, não tratado como garantia contratual. [E6]

`web-vitals.js` já está minificado; conferir a versão realmente servida, cache e dependências antes de abrir defeito de build. Qualquer adiamento adicional precisa preservar eventos e métricas, inclusive páginas de vida curta; não mover cegamente a biblioteca para depois da interação. CSS inline deve manter fallback externo quando a política CSP do site exigir.

### 12.7 Conversão resiliente — pedidos 13 e 14

**Correção P0:** manter um resultado por item com revisão de conteúdo, estado de conversão, avisos/erros, URL HTML e elegibilidade para representação Markdown. Um item não convertido deixa de invalidar todos os demais.

| Superfície | Comportamento planejado |
|---|---|
| `/llms.txt` | Item convertido pode apontar para `.md`; item elegível em HTML mas não convertível aponta para o HTML canônico, sem anunciar `.md` quebrada. |
| `/llms-full.txt` | Agregar somente conversões completas dos itens elegíveis. Declarar cobertura parcial e contagem de omitidos, com referência às alternativas HTML públicas; não chamar o resultado de conversão editorial integral. |
| `.md` individual e negociação Markdown | Representação indisponível não é anunciada. Pedido explícito à `.md` conhecida mas não convertível recebe 404; negociação deve seguir a política HTTP existente para oferecer HTML, sem rotulá-lo como Markdown. |
| Alternativas em HTML/cabeçalhos | Só anunciar `.md` quando a representação correspondente estiver disponível e atual. |
| `publicacao-verificar` | Resultado por item, erro, bloco responsável, revisão, totais selecionados/convertidos/omitidos/pendentes e efeito sobre índice/full; consulta de evidência sem reconverter. |
| Arquivos físicos e caches | Usar a mesma seleção, revisão e geração; invalidar ou substituir cópias anteriores para não continuar anunciando `.md` indisponível. |

Se nenhum item selecionado for convertível, não anunciar o full: o endpoint fica 404 com diagnóstico administrativo `representacao_indisponivel`, enquanto o índice preserva as URLs HTML públicas. Reservar 503 para falha transitória/global de geração/armazenamento; não para um tipo de bloco determinístico sem suporte. Se há ao menos um item convertível, a falha dos outros não provoca 503 do agregado. No relatório, `HTTP 200` e `cobertura_completa` são dimensões distintas.

Essa é uma alteração intencional do contrato de completude do full: registrar em 1.6.0, no changelog e nas evidências. A saída pública informa o alcance sem stack trace, detalhes de configuração interna ou URL privada. Exceder limites globais de tamanho/tempo não autoriza cortar texto silenciosamente e declará-lo completo.

Calcular/conservar resultados por revisão, com invalidação de conteúdo, privacidade/senha/noindex, permalinks, blocos reutilizáveis, configuração e versão do conversor. Dependências de consultas dinâmicas também invalidam o resultado. Não fazer conversão integral de todo o site no caminho quente de `/llms.txt`; usar trabalho incremental com limites e fallback HTML para itens ainda não avaliados. Ao tornar uma página privada, remover sua publicação imediatamente; uma cópia antiga não pode continuar pública até o cron seguinte.

**Adaptadores P1:** oferecer suporte delimitado a `core/query` para produzir lista finita de links públicos, com atributos aceitos, ordenação determinística, limite de itens, exclusão de senha/noindex/não publicados e invalidação quando a consulta mudar. Para blocos de formulário/interface conhecidos, permitir exclusão declarada por nome exato e registrar a omissão; não descartar conteúdo editorial silenciosamente. Excluir um bloco não torna completo um artigo que dependia editorialmente dele.

Não executar qualquer bloco só porque foi registrado, nem qualquer shortcode existente. `render_block()` aciona filtros e renderização; limpar HTML depois não desfaz efeitos da execução. [E7] Um adaptador que precise renderizar um bloco específico exige lista permitida, contexto público, limites e teste de efeitos, mantendo fallback quando falhar. A correção P0 não fica bloqueada pela implementação de todos os adaptadores de temas.

As correções de conteúdo já realizadas em korvena.net.br e ctooffice não anulam o defeito de isolamento. Usar fixtures com `core/shortcode`, `core/query` e bloco de tema equivalente a `twinia-blocks/lead-form`, sem depender de manter conteúdo quebrado em produção.

### 12.8 Slug histórico e base antiga — pedido 15

**Fallback de 404:** acrescentar candidato obtido do caminho normalizado de `REQUEST_URI` quando `name`/`pagename` não vierem preenchidos, limitado ao caso de URL antiga de um nível relativo a `home_url()`. Exigir correspondência histórica exata e única em `_f3base_old_slug`, destino público sem senha e permalink diferente. Não usar busca por prefixo nem escolher o primeiro resultado entre vários.

Para caminhos de vários níveis, o último segmento sozinho não comprova identidade; exigir par declarado ou histórico de caminho completo. Normalizar uma vez, remover query para comparação de origem, validar codificação/travessia e respeitar instalação em subdiretório. Não sobrepor conteúdo vivo. Revisar também a busca existente para não retornar conteúdo privado ou resolver colisões arbitrariamente. A correção não altera globalmente o canonical do WordPress.

**Base de taxonomia:** acrescentar operação de planejamento, proposta `f3base/redirects-planejar-base-taxonomia`, com taxonomia conhecida, `base_antiga`, `base_nova`, revisão de redirects e snapshot de termos/permalinks. Exemplo: `artigos/category` → `artigos/categoria`.

O Core enumera os termos públicos existentes e seus caminhos completos, inclusive hierarquia, e devolve pares exatos com destino obtido por `get_term_link()`, conflitos e cobertura. Validar que a base nova coincide com a estrutura canônica efetiva; a chamada não muda a configuração de permalinks. Provar que o destino é o arquivo do termo correto, não apenas um 200.

Aplicar os pares por `redirects-escrever`, com simulação, revisão e os mesmos limites; plano maior que um lote exibe lotes e cobertura restante, sem promessa de transação entre lotes. O snapshot muda se termos/permalinks mudarem; exigir replanejamento. Não sobrescrever regra explícita existente. Depois de aplicados, os pares exatos rodam antes da tentativa de adivinhação de artigo pelo WordPress.

Essa solução atende os termos conhecidos sem um prefixo aberto que capture anexos, posts ou URLs inexistentes. Termos novos ou mudança posterior de hierarquia exigem novo planejamento; isso fica explícito no contrato. No cenário `slack`, aceitar apenas o destino do termo correspondente, nunca um artigo cujo slug comece igual. O fluxo depende da habilitação do pedido 2 e não usa SQL.

## 13. Fechamento e responsabilidades

| Responsável | Entregas |
|---|---|
| Core 1.10.3 | R01–R26 nas partes proprietárias do pacote; contrato 1.6.0, ZIP/manifesto, diagnóstico, provas, formulários/armazenamento e documentação. |
| MCP / canal 3 | Contrato da sonda genérica e integração local negociada; projeção da versão das abilities; compatibilidade dos clientes. |
| Canal 2 / distribuição | Consumidor do manifesto, origem confiável, validação do pacote, aplicação autorizada e recuperação do pacote. |
| Implantador / agente da frota | Atualizar a política com escolha explícita por site; não regravar lista antiga; configurar Google/aliases/dados SEO, remover filtros redundantes após prova, aplicar migrações de URLs/formulários e retirar CF7/Flamingo após os gates. O template deixa de reinstalá-los. |
| Hospedagem | Ajustes específicos de cache/revalidação e entrega de llms físico quando necessários; sem presumir que o PHP controle resposta de arquivo servido diretamente. |

O plano não encerra pendências de frota por inclusão no backlog. Cada implantação registra acesso efetivo, simulação, aplicação quando autorizada e evidência pública. Manter as pendências 8/46/47, 39 e 45 vinculadas às respectivas frentes, sem marcá-las resolvidas apenas pela publicação do pacote.

Liberação do Core: P0 aprovado, P1 Core concluído conforme escopo, documentação e pacote reproduzível disponíveis; qualquer gate não executado aparece nominalmente como pendente. Liberação das integrações MCP/canal 2 tem aceite próprio, sem impedir correções Core compatíveis. A decisão de instalar na frota continua separada desta revisão de planejamento.

## 14. Substituição de Contact Form 7 e Flamingo

### 14.1 Decisão, escopo e base examinada

O pedido é pertinente e fica incluído na próxima release. “WP7” foi interpretado como **Contact Form 7 (CF7)**, identificado nominalmente no documento e no inventário do Site-Teste. O Core passa a ser responsável pelo formulário, registro, arquivos, painel, notificação e medição; os temas continuam responsáveis pela apresentação e pelo contêiner, inclusive diálogo/pop-up.

Fonte do pedido: `pedido2(1).md`, SHA-256 `fdc817ce3f79ea368b277211de78cfb7d982528c90b763f802ef26c2f314d173`. A análise confrontou o documento com o Core 1.10.2 local e com arquivos dos plugins instalados no Site-Teste, sem consultar contatos reais:

| Código examinado | Constatação e aproveitamento no projeto |
|---|---|
| CF7 6.1.7, `modules/flamingo.php` | Integração após submissão grava `spam`, `mail_sent` e `mail_failed`; preserva campos, remetente, assunto, consentimentos, hash e snapshots de página/site/usuário. Usar esse mapeamento no importador e na ponte temporária. |
| Flamingo 2.6.4, `includes/class-inbound-message.php` | Guarda metadados adicionais, canal, estado, spam e consentimentos. `_field_*` pode prevalecer sobre `_fields` na leitura. Copiar só `_fields` pode perder alterações efetivas. |
| Flamingo, `includes/class-contact.php` | Contatos têm nome/e-mail, propriedades, etiquetas e última interação próprios. Um agrupamento sobre mensagens não preserva necessariamente esse catálogo. |
| CF7, `includes/submission.php` | Separa validação, aceite, spam, upload e resultado de e-mail; remove uploads temporários no destrutor. Há verificações antispam nativas mesmo sem integração externa. |
| CF7, `includes/file.php` e `modules/file.php` | Conferem erros PHP, schema e arquivo recebido por upload; usam movimentação controlada, nomes tratados, permissões e limpeza. A nova persistência de anexos exige ciclo de vida próprio, pois o temporário do CF7 é eliminado. |
| CF7, `includes/controller.php` e `load.php` | Há fluxo sem Ajax e mecanismos de carregamento de assets. Servem de referência para paridade, sem manter o plugin como dependência do novo componente. |
| Core, endpoint/leads JS, retenção e consultas de medição | Destino ainda é Flamingo/CPT; `email_leads` não é consumida; clique converte pelo navegador; `leads-ler` entrega agregados; exportação/eliminação e coleta precisam aprender o novo repositório. |

Os arquivos principais confirmam CF7 6.1.7 e Flamingo 2.6.4. Números de mensagens, formulários, versões dos temas e uso de `_mail_2` nos demais sites continuam sendo inventário relatado no anexo; a migração os confirma por instalação. Código eventualmente reaproveitado conserva a identificação e a licença de origem; a solução final funciona com CF7/Flamingo removidos.

### 14.2 Correções necessárias na especificação

| Ponto do documento | Decisão aplicada ao plano |
|---|---|
| §2 pede lista fechada de tipos; decisão 8/§4.3 permitem qualquer extensão | Prevalece a decisão explícita posterior: sem lista/teto global do pacote. Restrições por formulário são opcionais e vazias por padrão. Corrigir o aceite que ainda manda recusar todo tipo fora de lista. |
| §9 manda descartar envio abaixo de 3 s; §3/§4.2 mandam guardar suspeito | Guardar submissão estruturalmente válida como suspeita, com motivo. Recusar payload inválido, token inválido e limite excedido; não guardar arbitrariamente qualquer corpo hostil. |
| “Tudo que o Flamingo guarda” representado só por IDs atuais | Acrescentar snapshots históricos e metadados de origem. ID de página/usuário não substitui nome, título, URL e identidade registrados na ocasião. |
| “Catálogo de endereços” reduzido a agrupamento por e-mail | Preservar contatos independentes, propriedades e etiquetas em acervo próprio. Não criar leads fictícios para representar contatos. |
| Canal `f3base-lead` sempre inferido como clique | O endpoint também recebe formulário de WhatsApp nesse canal. Classificar pela evidência disponível, conservar método original e marcar inferência; usar indeterminado quando não houver base suficiente. |
| Contagem antes = depois encerra migração | Exigir identidade de origem, comparação dos campos efetivos e reconciliação de estados, além das contagens. Incluir CPT de contingência, spam, lixeira e novos envios durante a migração. |
| Atualização migra tudo na ativação | Atualização instala schema e prepara migração retomável; importação pode ser executada em lotes pelo serviço do pacote, sem depender exclusivamente do activation hook ou estourar a requisição de upgrade. |
| Restaurar suspeito envia automaticamente `generate_lead` | Aprovação administrativa muda estado e pode notificar. Não há navegador/sessão do visitante naquele momento; não fabricar evento GA4 no navegador do administrador. |
| `wp_mail=true` comprova recebimento em até 1 min | Retorno comprova processamento pelo transporte, não entrega ao destinatário. Provar recebimento separadamente na homologação. [E9] |
| Beacon torna o envio síncrono de e-mail sem custo | A navegação pode continuar, mas o servidor continua ocupado e os formulários aguardam resposta. Medir/limitar o transporte e separar persistência de notificação. |
| Arquivo sem extensão/0700 elimina risco do servidor | Não comprova bloqueio HTTP nem impede esgotamento de disco/processos. Exigir armazenamento privado verificável; proteção inconclusiva impede habilitar upload. |
| `sessao` sempre preenchida e unida ao comportamento | Sem JS, coleta desligada, consentimento/política restritiva ou coletor indisponível podem deixar sessão ausente. Contato continua válido; registrar ausência e não fabricar rastreamento. |
| Auto-resposta descrita como decisão pendente | Aplicar a decisão explícita do anexo: nenhum e-mail ao visitante. Migrar conteúdo essencial das quatro respostas relatadas para a confirmação e registrar essa mudança funcional. A recomendação de exceção não é autorização para criá-la. |
| Nota PSI ≥ 90 e fim da medição até 2,5 s depois do load | Manter metas de melhoria e ensaio controlado. Essas medidas dependem da página, terceiros e ambiente; não são garantias que o componente pode oferecer isoladamente. |

O código confirma parte dessas lacunas; a conclusão de que a migração exige mais dados e estados é uma inferência de projeto baseada nos campos efetivamente persistidos. As estimativas de 104–155 h são do documento, não uma medição validada desta implementação. Reestimar após o ensaio de migração/armazenamento, incluindo os ajustes acima, homologação e trabalho por site.

### 14.3 Repositório e contrato de registro

Criar `<prefixo>f3base_leads` como destino único dos novos registros. Preservar o contrato de clique existente durante a transição e separar validação, persistência, anexos, notificação e medição. A presença de Flamingo deixa de decidir o destino e sua ausência deixa de degradar a saúde do Core.

Manter os campos propostos: IDs/correlação, horários de servidor e cliente, método, estado, formulário, página, IP/IP hash, user agent, usuário, hash dos campos, sessão, campos completos, atribuição, consentimento, anexos e estado de aviso. Acrescentar:

- Origem legada (`tipo`, `id`, canal, versão do importador, data e checksum), com unicidade por instalação/origem. `record_id` é único e gerado pelo servidor. Correlação ausente no legado permanece nula; não apresentá-la como evento de navegador real.
- Snapshots do contexto no envio: título/nome/URL da página, dados do site e identificação do usuário existentes na fonte. IDs atuais são referências complementares. Preservar os valores históricos de remetente, assunto, estado de submissão, hash, consentimentos e spam, inclusive `_meta`, `_consent`, `_spam_log` e propriedades existentes de integrações legadas.
- Estados separados para captura (`clique`, `aceito`, `suspeito`), atendimento (`novo`, `respondido`, `spam`), lixeira e notificação. `aviso_em` sozinho não distingue tentativa, processamento e entrega observada.
- Revisão da definição do formulário e das mensagens/avisos usados; erros e decisões de moderação com ator/data. Consentimentos específicos de campos têm finalidade/versão próprias; não se confundem com consentimento para analytics.
- Método legado indeterminado quando a fonte não permite classificação; conservar valor original e regra da inferência. Os quatro métodos fechados aplicam-se aos novos registros.

Usar schema de banco versionado, charset do WordPress e JSON validado em armazenamento compatível com os bancos suportados. Índices atendem período, método, formulário, estado, sessão, e-mail pesquisável e cursor `(criado_em,id)`. Acrescentar acervo privado de contatos legados com propriedades/etiquetas para preservar registros que não podem ser reconstituídos de mensagens; a UI pode apresentar ambos em uma visão de contatos, sem inflar a contagem de leads.

Deduplicação é idempotência de submissão, não remoção indiscriminada de contatos parecidos. A chave de correlação do clique mantém a janela de um minuto; formulários usam chave de submissão própria, vinculada ao formulário e ao payload. Replay idêntico devolve o mesmo resultado; mesma chave com conteúdo diferente acusa conflito. Hash de campos auxilia diagnóstico e não deve suprimir sozinho um segundo contato intencional.

Persistir lead e intenção de aviso de forma consistente; uma reserva existente sem registro confirmado nunca vira “duplicado com sucesso”. Banco indisponível retorna falha recuperável. Arquivos ficam em estágio até a aceitação; compensar/limpar estágios incompletos e registrar falhas de remoção. Importação e reconstrução de agregados não disparam mensagens, GA4, Ads ou CAPI.

IP e user agent são mantidos conforme a decisão do pedido, com acesso e retenção do contato. A origem do IP usa a política de proxies confiáveis já existente, sem confiar cegamente em `X-Forwarded-For`. Esses dados não transformam um clique em identificação do nome/e-mail do visitante.

### 14.4 Definição e execução dos formulários

Adicionar `f3base_formularios`, operável via `config-core-ler/escrever`, com revisão, simulação, substituição de listas documentada e mesma validação no editor administrativo. A habilitação da option segue R04 e faz parte do aceite por site. Acesso à definição não concede acesso aos leads ou aos arquivos privados.

Cobrir o conjunto do anexo: ID estável, regime, botão, campos/ordem, confirmação, mensagens, destinatários/assunto/anexo do aviso; tipos texto, e-mail, telefone, texto longo, lista, escolha única, caixa de marcar, URL, arquivo e texto estático. Incluir rótulo, obrigatório, limites do campo, opções com rótulo vazio, padrão, placeholder, autocomplete, ajuda, largura e papel nome/e-mail/telefone. Validar nomes únicos, opções permitidas e marcadores conhecidos; rejeitar injeção em cabeçalhos e HTML fora da lista permitida. Metadados técnicos ocultos do pacote são permitidos; não expor campos ocultos livres para duplicar atribuição.

O editor precisa pré-visualizar, simular e explicar erros por campo. Mudanças em formulário usado por conteúdo devem mostrar os locais afetados. Não apagar silenciosamente definição referenciada; retirar/publicar é ação explícita. Render identifica revisão da definição; envio de versão antiga não é validado silenciosamente contra regras novas.

Entregar bloco `f3base/formulario` e shortcode equivalente, renderizados pelo servidor, com CSS restrito, variáveis `--f3base-form-*`, mensagens acessíveis, rótulos/IDs únicos por instância e navegação por teclado. O formulário funciona embutido ou dentro de contêiner oculto, inclusive mais de uma instância com o mesmo ID lógico.

Assets do componente são registrados globalmente e carregados somente quando ele é renderizado, incluindo templates, shortcodes e diálogos. Nenhuma busca de schema/refill no carregamento. A meta de 2–4 KB de JS deve ser medida indicando minificação/compressão; não é justificativa para remover validação acessível. Os módulos existentes de tracking/CTA mantêm seus próprios critérios de carregamento.

Fluxo único no servidor: identificar formulário/revisão → validar token/escopo e limites de requisição → validar todos os campos → classificar suspeita → preparar anexos → persistir → tratar notificação → devolver resultado. Regime e destinatários vêm da definição confiável, não de campos enviados pelo visitante. CAPTCHA externo não é dependência desta entrega.

Campo-isca/tempo abaixo de 3 s são sinais de suspeita, não prova de robô. Guardar campos válidos e motivo para revisão, sem notificação comercial, entrega de conteúdo ou conversão automática. Payload desconhecido, formato inválido, falta de campo obrigatório, token inválido e excesso de taxa têm respostas/códigos próprios. O contador de recusas guarda razões/agregados, sem copiar dados pessoais de corpos rejeitados.

JS usa `fetch`/`FormData` normal para arquivos; beacon/keepalive fica no clique leve. Sem JS, aceitar POST comum e usar resposta HTML privada/redirect 303 conforme o caso; nunca colocar os campos pessoais na URL. No regime WhatsApp, montar destino no servidor depois de persistir; tratar perda do gesto de usuário em abertura assíncrona com link de continuidade, sem registrar novamente o lead.

**Cache e tokens são gate de arquitetura:** não reutilizar em HTML compartilhado um ID de submissão individual, nem interpretar hora de geração do cache como início real de preenchimento. Prever renovação de token somente na interação/envio. Para o caminho sem JS, começar com exclusão do cache integral das páginas que necessitem emitir IDs/tokens por visitante, incluindo formulário em template; reabilitar cache apenas com mecanismo comprovadamente compatível. Essa escolha tem custo de TTFB e entra na comparação de desempenho. Cookies funcionais/idempotência, quando necessários, são separados da sessão de analytics.

Eventos `f3base:formulario:inicio`, `aceito` e `erro` nascem no bloco e borbulham, com metadados mínimos; não transportar campos pessoais completos no evento DOM. Abrir diálogo é ação do tema e não gera lead. O template do implantador entrega padrão com botão, `<dialog>` e fallback acessível sem JS; abertura automática e efeitos visuais continuam decisões do tema.

### 14.5 Anexos e isolamento de arquivos

Preservar a decisão: **qualquer extensão e nenhum teto global de bytes imposto pelo pacote**. Cada formulário pode declarar restrições; padrão vazio, até cinco arquivos por campo. Corrigir a redação antiga de lista fechada/20 MB e os testes que a contradizem.

Ler tipo por conteúdo e guardar também nome original, extensão declarada, tamanho e SHA-256; divergência vira alerta, sem rejeição automática quando o formulário aceita qualquer tipo. Detecção de MIME não é antivírus nem prova de inocuidade. Arquivos não são executados, extraídos, convertidos ou incluídos pelo PHP.

Preferir diretório fora da raiz pública quando a hospedagem permitir. O caminho proposto `wp-content/f3-leads-privado/` só é aceitável após prova de bloqueio de arquivo-canário existente e configuração de servidor compatível. `0700`, nome aleatório sem extensão e `index.php` não demonstram essa proteção; `.htaccess`/`php_flag` não são portáveis para todos os servidores/handlers. Exigir 403/404 efetivo sem corpo do canário e proibição de execução; 500 ou timeout são inconclusivos. Revalidar quando o contexto da hospedagem mudar. Até passar, informar upload indisponível e impedir formulário obrigatório de fingir sucesso. [E10]

Usar nomes aleatórios de 32 hex, criação sem sobreposição, validação de arquivo realmente recebido via upload, caminhos internos resolvidos pelo servidor e rejeição de travessia/symlinks. Arquivos individuais recebem permissões mínimas. Download exige login/capability sobre o registro, resolve ID de arquivo internamente e usa `attachment`, `nosniff`, política sem cache compartilhado e leitura em blocos; para tipos ativos/desconhecidos, entregar como `application/octet-stream`. Exibir MIME detectado como metadado, sem renderizar conteúdo ativo no wp-admin.

Expor limites conhecidos por arquivo e por requisição: PHP, número máximo de uploads, formulário, tempo de entrada e espaço disponível. `post_max_size` inclui o conjunto multipart, não é sinônimo de limite de cada arquivo. Proxy/CDN/servidor também podem rejeitar antes do PHP; quando o limite não for conhecido, identificá-lo como tal, sem exibir um máximo garantido. Tratar erros `UPLOAD_ERR_*`, envio cortado, 413 e indisponibilidade de disco com diagnóstico verificável. [E11]

Limite por IP não impede esgotamento por origens distribuídas e não limita bytes que chegaram ao servidor antes da aplicação. Manter o alerta de ocupação configurável, padrão 1 GB, como alerta e não como cota escondida. Registrar esse risco residual da decisão de arquivos sem teto. Interromper escrita quando não houver capacidade real de persistir; nunca aceitar lead com anexo obrigatório perdido.

Anexar ao e-mail continua desligado por padrão; link autenticado é o caminho padrão. Se o transporte recusar anexação com resultado conhecido, tentar aviso com link conforme a política de notificação. Timeout com resultado incerto não autoriza duplicar automaticamente. Falha de aviso não elimina arquivo nem lead.

### 14.6 Avisos internos

Ativar por padrão `avisar_por_clique` e `avisar_por_formulario`. Fazer `email_leads` funcionar, aceitando até cinco destinatários e preservando configuração legada de endereço único. Definição por formulário pode fornecer destinatário/assunto específicos. Prévia de migração identifica os destinatários efetivos; lista vazia mantém registro e diagnóstico de aviso desconfigurado.

Emitir via `wp_mail`, usando o transporte já configurado na instalação. Remetente coerente com o domínio; Reply-To do visitante somente após validação. Assunto com marcadores declarados; headers `X-F3base-Formulario` e `X-F3base-Metodo`, sem interpolar CR/LF. Aviso de clique informa intenção/CTA/página/origem, sem inventar dados de contato. IP/campanha/identificadores ainda podem conter dados pessoais; não classificar automaticamente o aviso como isento deles.

Persistir intenção de aviso junto do lead. A primeira tentativa pode ocorrer na mesma requisição após a gravação, conforme o pedido, com timeout do transporte controlado onde suportado e medição do impacto. A falha do e-mail produz `persisted=true` com notificação falha/pendente, e não erro que induza novo formulário. Se o transporte não permitir orçamento confiável, seu uso síncrono precisa ser revisto antes da homologação de latência.

Registrar tentativa, resultado do transporte, erro, próxima ação e chave idempotente. `wp_mail=true` significa processado pelo transporte; entrega ao destinatário é prova separada. [E9] Não prometer “exatamente uma entrega” diante de timeout após aceite remoto; resultado incerto exige reconciliação/reenvio explícito.

Adotar até 30 avisos individuais/hora por site e, adicionalmente, no máximo um resumo para a janela encerrada, com registros pendentes agregados. A geração horária exige um executor: configurar cron real da hospedagem ou assumir execução oportunista e mostrar atraso. Não prometer resumo pontual sem tráfego nem executor. WP-Cron pode ser fallback, sem apagar a pendência ou fingir execução. Tentativas e resumos não refazem a gravação do lead.

Nenhum e-mail ao visitante nesta release. As quatro auto-respostas relatadas entram no inventário de migração, com texto essencial apresentado na confirmação; ctooffice exige conferir prazo, conteúdo da devolutiva e ressalva já usados. Uma futura exceção por formulário é mudança de produto separada. Configuração de SPF/DKIM/DMARC/relay e recebimento efetivo pertencem à homologação de cada domínio; não enviar testes a terceiros durante o planejamento.

### 14.7 Conteúdo para download

Incluir regime `conteudo` no mesmo formulário. Editor administrativo gerencia arquivo privado, ID estável, título, tipo, validade (padrão sete dias) e quota de downloads (padrão cinco). E-books são arquivos administrados pelo site e não se confundem com anexos recebidos de visitantes; os tipos de publicação desse catálogo podem ser limitados conforme o pedido.

Arquivo é enviado/registrado por serviço proprietário do Core, com capacidade administrativa e conferência de hash, sem depender de escrita arbitrária em caminho interno. Não usar URL pública da biblioteca de mídia. A pasta `f3-conteudo-privado` segue a mesma comprovação de isolamento dos anexos; a definição guarda ID de ativo, não caminho livre informado pelo cliente.

Aceite cria concessão de acesso vinculada ao registro, ativo/versão, expiração e quota. Token usa identificador opaco, finalidade específica e HMAC derivado do segredo do endpoint, sem expor dado pessoal. Validar assinatura, concessão ativa, registro não eliminado, versão do ativo, prazo e saldo em toda entrega. Comparações e consumo de quota precisam ser atômicos para GETs concorrentes.

Definir download como tentativa autorizada iniciada, pois o servidor não comprova que a pessoa salvou/leu o arquivo. HEAD não consome quota; na primeira entrega, não suportar Range com múltiplas requisições sem um protocolo de contagem próprio. Guardar primeira/última tentativa e contagem, com falhas conhecidas separadas. Não chamar esse número de download concluído.

Deduplicar nova submissão por e-mail normalizado/conteúdo enquanto houver concessão ativa e utilizável, conservando um lead/conversão. E-mail igual não autentica a pessoa: a resposta nunca revela dados ou histórico anteriores. Não reiniciar quota silenciosamente. Concessão expirada ou esgotada deixa de bloquear nova solicitação válida; preservar vínculo histórico e gerar nova correlação/concessão, sem reutilizar a chave única anterior.

Link aparece na confirmação; não é enviado ao visitante. Isso não verifica a titularidade do e-mail e não impede compartilhamento do material já baixado. A confirmação não é publicada em cache, índices ou analytics. A entrega usa `attachment`, `nosniff`, `Cache-Control: private, no-store`, `Referrer-Policy: no-referrer` e `X-Robots-Tag` apropriado; excluir rota/query de todos os caches antes do PHP. Provar isso com parâmetros em ordens diferentes. `robots.txt` é orientação de rastreamento, não controle de acesso.

Tokens/URLs assinadas não entram em eventos, logs de aplicação, llms ou metadados públicos. Testar também logs da hospedagem. Exclusão do contato revoga acesso; alteração do ativo tem regra explícita para concessões existentes. O e-book administrado não é removido pela retenção de um lead.

### 14.8 Painel, canal e privacidade

Entregar caixa de entrada com filtros, busca em campos declarados, agrupamento por e-mail, suspeitos, atendimento, lixeira/restauração, detalhes e downloads. Preservar etiquetas/propriedades dos contatos importados. Capabilities propostas: ler leads, gerir leads e gerir formulários; `manage_options` mantém acesso administrativo. Definir separadamente exportação e acesso a arquivos; usar nonce nas mutações do painel.

Manter o comportamento agregado padrão de `f3base/leads-ler`; acrescentar projeção explícita `modo=registros`, cursor estável e filtros por período/método/formulário/estado, ou uma ability versionada equivalente se o schema atual não comportar a extensão. Não trocar uma resposta agregada por dados pessoais sem escolha do chamador. Leitura individual retorna metadados de anexo, nunca bytes, caminho interno ou link assinado de visitante.

Operações propostas de gestão (`leads-atualizar`, simulação/revisão para estado e lixeira; migração consultar/simular/aplicar/verificar) usam serviço próprio. A análise pelo agente prioriza essas rotas; consultas SQL de leitura autorizadas continuam possíveis, mas não são o contrato operacional nem caminho de gravação. Unir eventos/leads respeitando a granularidade para não multiplicar contagens por vários eventos da mesma sessão.

CSV deve neutralizar fórmulas e escapar corretamente campos. Exportação grande é paginada/por fluxo e protegida; não criar download público duradouro. Todas as telas escapam conteúdo recebido, inclusive nome de arquivo, campos de spam e valores legados.

Expandir os exportadores/eliminadores do WordPress e a retenção por `f3base_retencao_meses` para registros, anexos, contatos legados pertinentes, intenções de aviso e concessões. Distinguir lixeira operacional reversível de eliminação definitiva solicitada pelo titular. Incluir arquivos no procedimento de exportação protegido, sem transformá-los em mídia pública.

Ao eliminar, revogar downloads antes de remover o arquivo; remoção física falha fica pendente e visível, com nova tentativa controlada. Não declarar conclusão enquanto existir cópia sob gestão do pacote que deveria ter sido removida. Marcar origens já eliminadas para impedir reimportação; resolver também cópias legadas conservadas durante a migração. Journal guarda resultado e identificadores necessários, sem duplicar conteúdo pessoal eliminado.

### 14.9 Migração e retirada dos plugins

1. **Inventário e simulação:** localizar CF7 em páginas, posts, blocos reutilizáveis, templates, widgets e código de tema; mapear sete formulários relatados e eventuais divergências. Ler `_form`, `_mail`, `_mail_2`, mensagens, configurações adicionais e ganchos. Identificar registros Flamingo/CPT e contatos por estado, inclusive lixeira. Formulário de fábrica sem uso não bloqueia a migração, mas fica inventariado.
2. **Preparar destino:** instalar schema, verificar gravação/leitura, capacidades, destinatários, políticas de acesso, arquivos privados e retenção. Manter originais recuperáveis. A ausência dos plugins depois deve ser estado suportado pelo Core.
3. **Importar em lotes:** chave única de origem, checkpoint e relatório por registro; copiar os campos efetivos, snapshots, metadados, canais, estados, datas e catálogo. Respeitar `_field_*` quando existir. Método inferido tem justificativa; dado ausente continua ausente. Não emitir notificações/conversões históricas. Reexecução compara checksum; se origem e destino foram alterados depois da cópia, registrar conflito em vez de sobrescrever o destino. O corte por ID não detecta sozinho mudança posterior em metadado/estado: a reconciliação final inclui esses campos.
4. **Tratar convivência:** enquanto houver CF7 em uso, manter ponte temporária pelo hook `wpcf7_submit` para o novo repositório, usando mapeamento de formulário; o CF7 continua responsável pelo aviso daquele formulário e o Core não o duplica. Coletar arquivos antes da limpeza temporária quando essa ponte precisar preservá-los. Registros sem mapeamento ficam como pendência explícita. Capturar delta de envios que chegaram durante a importação e reconciliar por origem/hash; instalar a ponte sem uma janela silenciosa de perda.
5. **Migrar formulário por formulário:** converter definição para `f3base_formularios`, apresentar prévia e substituir referência no conteúdo com revisão/backup. Migração automática não transforma HTML/PHP arbitrário em bloco sem conferir paridade. Primeiro registro de teste usa dados sintéticos e destinatário de teste autorizado. Comparar todos os campos, anexos, mensagens, confirmação, atribuição e medição.
6. **Migrar integrações de tema:** ctooffice substitui redirect, anexos e `wpcf7mailsent`/gtag direto pelos contratos Core. Remover filtros/scripts só após comparação; preservar conteúdo essencial da confirmação. Temas de WhatsApp mantêm compatibilidade durante a transição, mas o encerramento da promessa de campos completos exige mapear seus campos/definições; não deixar essa lacuna escondida como “sem prazo”.
7. **Reconciliar:** contagens por fonte/estado, conjunto de IDs de origem, hashes/valores, totais de contatos e campos especiais, incluindo últimas entradas e alterações ocorridas no intervalo. A simples igualdade de contagem não aprova. Diagnóstico informa pendentes/falhas e impede marcar migração completa.
8. **Desativar e provar:** CF7/Flamingo desativados no piloto; submeter todos os regimes, consultar histórico, moderar, restaurar, exportar, baixar anexos e conferir aviso/GA4 elegível. Verificar ausência de shortcodes/ganchos/recursos dependentes e de fatal/degradação do Core.
9. **Remover e atualizar template:** retirar os plugins após os gates e a reconciliação final. Implantador deixa de instalá-los e passa a usar bloco/padrão de diálogo. Remoção de `korvena-shortcodes` não é consequência automática deste pedido.
10. **Recuperação:** manter pacote/definições anteriores durante a janela definida, com inventário do legado e dos novos registros. Reativar CF7/Flamingo sozinho não leva os novos leads de volta; rollback deve manter o repositório novo legível ou exportar/importar o delta por caminho testado. Não restaurar banco antigo sobre envios novos. Limpeza final do acervo original é operação separada, auditada e reconciliada com retenção/eliminações.

Ordem: Site-Teste → korvena.net.br → fator3.com.br/korvena.com.br → demais sites. Migração dos cinco sites com CF7 e ajustes do implantador são trabalho de implantação após disponibilidade do pacote, não alterações antecipadas por contorno no canal. O fluxo não exige SQL manual nem edição improvisada do Core instalado.

### 14.10 Medição, desempenho e critérios de conclusão

Preservar `method` e emitir `whatsapp_cta`, `whatsapp_formulario`, `formulario` e `conteudo`. Não renomear a dimensão. O histórico `cta`/`formulario` anterior à migração continua documentado; `formulario` antigo não demonstra, sozinho, que o contato era formulário nativo sem WhatsApp.

CTA registra intenção no clique; formulário converte só depois do aceite persistido, uma vez por submissão nova. `form_start` nasce na primeira interação do formulário; abrir diálogo não o substitui. O listener antigo que procura ancestrais com `data-f3base-lead` precisa ignorar o bloco nativo, para não converter foco/clique em campo ou submit inválido.

Reutilizar o portão de consentimento e o transporte central de GA4/Ads/Meta/LinkedIn. Não enviar nome, e-mail, telefone, mensagem, IP bruto, nome de arquivo ou token de download como parâmetro GA4. Sessão de comportamento é opcional e validada no formato, sem fabricar histórico quando a coleta estiver indisponível. Dados de atribuição vindos do navegador são informação declarada, não prova autenticada da origem do contato.

Aceite sem JS continua gravando e notificando, mas não produz evento de navegador GA4. Aprovação manual de suspeito também não produz esse evento. Uma futura integração de medição servidor exigiria identidade de medição, consentimento, janela e deduplicação próprios; não faz parte desta substituição. Meta CAPI existente continua subordinada ao consentimento e à persistência, sem reenvio na importação.

Homologar junto de R15: Google imediato/adiado, envio seguido de navegação, formulário WhatsApp e CF7 durante convivência. Medir recebimento, duplicação e perdas, sem tratar a presença em `dataLayer` como entrega. No Site-Teste sem GA4, marcar a prova externa como não aplicável; executá-la no piloto com propriedade configurada, usando apenas testes autorizados.

No conversor llms, tratar bloco/shortcode nativo como interface conhecida, retornando referência à página pública para preenchimento. Não chamar renderização de formulário nem incluir token, campos preenchidos, confirmação, arquivos ou catálogo privado. Esse ajuste integra R16/R17 e evita que a retirada de CF7 reintroduza a falha de conversão.

Comparar páginas equivalentes antes/depois, em dispositivo/rede definidos, com número de execuções, mediana/dispersão, TTFB, LCP, TBT, recursos e requisições. Componente ausente não adiciona seus assets/API; componente presente não faz refill/schema no load. Nota ≥ 90 permanece meta de página, não garantia isolada do plugin. Distinguir custo do formulário, cache e Google.

Conclusão desta frente exige T53–T74 e os gates compartilhados de R11/R15/R16, pacote/documentação e operação provada com os dois plugins desligados. O importador pronto ou a tabela preenchida não encerra a substituição. O relatório final distingue capacidade entregue no ZIP de formulários/sites efetivamente migrados.

### 14.11 Documentação e fontes complementares

Atualizar catálogo de options/abilities, schemas, saúde, instruções, contratos DOM, política de cache, medição, retenção, descrição de dependências, scripts da suíte e documentação gerada. `f3base_formularios` e as novas chaves de contato entram nas instruções do agente; secrets/estado interno ficam protegidos. O relato do anexo sobre `method` já criado nas treze propriedades orienta a compatibilidade, sem recriar dimensões automaticamente.

O implantador e o Padrão recebem suas alterações na entrega correspondente: bloco na página de contato, padrão de diálogo, retirada de CF7/Flamingo da lista instalável, tabela/rotas novas e regra de que abertura de formulário não é lead. O plugin Google e o MCP podem transportar operações já autorizadas, mas o componente e seus dados pertencem ao Core.

Referências primárias consultadas em 24/09/2026:

- **E9 — WordPress:** [wp_mail: retorno e processamento do envio](https://developer.wordpress.org/reference/functions/wp_mail/).
- **E10 — OWASP:** [File Upload Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html). Referência para isolamento/entrega; a decisão de aceitar qualquer extensão e não fixar teto global mantém riscos residuais expressamente descritos acima.
- **E11 — PHP:** [Limitações e cuidados no upload](https://www.php.net/manual/en/features.file-upload.common-pitfalls.php).

Limites: esta revisão analisou código e especificação; não comprovou os ~40 registros, as configurações dos cinco sites, recepção de e-mails, proteção de novas pastas ou resultados do componente ainda não implementado. Essas provas estão nos gates, com dados sintéticos e preservação do acervo real.
