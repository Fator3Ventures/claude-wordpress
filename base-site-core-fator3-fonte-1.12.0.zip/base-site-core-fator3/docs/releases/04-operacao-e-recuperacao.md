# Core — implantação, migração e recuperação

Revisão de 24/09/2026. Roteiro para o implantador autorizado. Nenhuma etapa foi executada nos sites de produção nesta entrega.

## 1. Operação independente com 1.10.3

1. Guardar ZIP e backup do banco/configuração atuais. Conferir manifesto e SHA-256; validar a versão lida do cabeçalho do ZIP. A origem de distribuição deve ser aprovada pelo operador; `distribution_url=null` não é autorização para inventar um servidor de atualização.
2. Homologar primeiro em Site-Teste, com fixtures de Unicode, query, origem viva, destino privado, ciclo, cadeia, palpite WordPress, regra removida e 410. Em fator3.com.br, repetir a prova com LiteSpeed real. O teste de hook da bancada não comprova cache do servidor.
3. Habilitar uma única vez o interruptor de gestão de política pelo canal. Ler lista/revisão; simular acréscimos explícitos de redirects e demais options necessárias; aplicar com CAS. Sem SQL de contorno e sem substituir uma lista restritiva por acesso irrestrito.
4. Para mudança nova de slug/pai, usar a operação normal de conteúdo. O Core grava o caminho completo anterior. Provar 404 → redirect e confirmar que conteúdo vivo não é sobreposto pelo fallback. Na pendência 47 já existente, verificar se há caminho histórico confiável: a versão nova não recupera automaticamente um caminho perdido no passado.
5. Para taxonomia, planejar pares exatos com a base canônica atual. Replanejar se termos/permalinks mudarem. Aplicar lotes de dez com revisão atual e, se necessário, `adiar_purga=true`; ao final pedir `redirects-verificar`. Fazer prova anônima também de origens removidas. Guardar revisão, Location, emissor, contexto e data.
6. No llms, executar o lote de conversão e consultar cobertura. Confirmar índice com fallback HTML e ausência de `.md` anunciada sem representação. Testar conteúdo tornado privado, corrigido e reconvertido. Com `full=false`, o aceite do agregado não bloqueia a correção do índice.
7. Manter o modo Google atual do site enquanto não houver recepção real comprovada; não associar a instalação da correção de redirects a uma troca automática de analytics.

## 2. Preparação da 1.11.0

- Clone fiel com MySQL/MariaDB equivalente ao site, mesmo tema, cache e versões de CF7/Flamingo. A bancada automatizada desta entrega usa WordPress 6.9/PHP 8.3.6/SQLite e não certifica todos os motores de produção.
- Backups de banco, conteúdo, configurações, código de tema, plugins atuais e anexos; incluir inventário de identidade dos arquivos e teste de restauração. Guardar um ponto de recuperação sem sobrescrever envios posteriores.
- Definir destinatários internos de teste autorizados e janela de teste por formulário. Comparar confirmação e mensagens; quatro auto-respostas legadas relatadas exigem revisão editorial. Nenhum e-mail ao visitante será criado pela migração.
- Configurar diretório privado externo. Exemplo em `wp-config.php`: `define('F3BASE_ARQUIVOS_PRIVADOS', '/caminho/privado-do-site');`. Usar caminho real específico da hospedagem. Confirmar ausência de aliases públicos, CDN/media mapping e execução de arquivos. Nome aleatório e permissões Unix não substituem essa verificação.
- Conferir PHP `upload_max_filesize`, `post_max_size`, quantidade de uploads, espaço e restrições do proxy. Campo novo usa 10 MiB, removível explicitamente. Homologar arquivo de extensão arbitrária sem executá-lo e download forçado.
- Excluir endpoints POST, confirmação, anexos e `admin-post.php?action=f3base_conteudo` dos caches que possam responder antes do PHP; repetir com parâmetros reordenados. HTML com formulário permanece compartilhável. TTL do HTML usado sem JS deve caber na validade do token; testar página envelhecida.
- Habilitar `f3base_formularios` pela gestão de política, revisar permissões próprias e manter CF7/Flamingo enquanto os formulários ainda dependerem deles.

## 3. Migração única, exclusiva da 1.11.0

| Etapa | Operação | Evidência de saída |
|---|---|---|
| Inventário | `leads-migracao-1110` com `consultar`/`simular` | Fontes por estado, formulários, referências em conteúdo/widgets/tema, revisão; não importar |
| Proposta de formulário | `formularios-cf7-planejar` por ID | Proposta inativa + `_form`, mail/mail_2, mensagens, settings e avisos; revisão humana |
| Definição nativa | Configuração própria com simulação/CAS | Campos, regras, destino, confirmação e assunto conferidos; teste por formulário |
| Importação | `leads-migracao-1110` com `aplicar` e revisão atual | Lotes de 50; checkpoint, origem única, hashes e conflitos; sem e-mail/conversão histórica |
| Referência | `formularios-migrar-referencia`, simular e depois aplicar com hash atual | Conteúdo com shortcode nativo e backup `_f3base_backup_cf7_1110`; blocos/temas arbitrários são revisão explícita |
| Convivência | Ponte temporária CF7/Flamingo, somente nesta versão | Novos registros copiados; arquivos copiados antes da limpeza temporária; aviso continua sob responsabilidade do CF7 |
| Reconciliação | Reiniciar varredura e `verificar` por lotes | Conjunto de fontes + metadados/termos e hashes, não só contagens; nenhum conflito/falha de ponte |
| Desativação | Operação autorizada do implantador | CF7 e Flamingo desligados; todos os fluxos funcionando no piloto; nenhuma referência residual ativa |
| Conclusão | `concluir` com revisão e aceites explícitos de operação/formulários/recuperação | Marcador permanente por site; importador deixa de executar |
| Remoção | Retirar plugins após conclusão e backup | Operação permanece; implantador passa a usar o componente nativo |

`reiniciar_varredura` reinicia a conferência de um processo ainda aberto, não desfaz conclusão. Se uma importação falhar, retomar no checkpoint após corrigir a causa. Se origem e destino foram editados, resolver conflito sem sobrescrever a moderação. A ponte respeita campos `do-not-store` e não duplica a notificação do CF7.

Falha da ponte bloqueia conclusão. `resolver_ponte` exige evidência de resolução e nova reconciliação; o operador não deve registrar resolução sem recuperar/conferir o material afetado. Originais já eliminados por pedido de privacidade deixam tombstone para não reaparecer na importação.

A conclusão exige inventário sem plugins legados ativos, referências, widgets ou dependências de tema e a confirmação recente do conjunto de origem. A varredura de tema é conservadora: menção em código/comentário pode exigir revisão/limpeza. Formulários de fábrica sem uso são inventariados, mas não equivalem a uma referência ativa no conteúdo.

Ordem proposta de frota: Site-Teste → korvena.net.br → fator3.com.br/korvena.com.br → demais. Relatos de quantidade de formulários/sites não substituem o inventário no momento da operação. A remoção de outro plugin de shortcodes não é consequência automática desta migração.

## 4. Recuperação após a conversão

**Padrão: corrigir por nova versão conservando o acervo.** Um downgrade do ZIP não reverte conteúdo, schema, avisos ou arquivos.

Se o operador decidir voltar ao CF7:

1. Suspender temporariamente novos envios na janela acordada; manter o acervo novo e seus arquivos íntegros.
2. Exportar/conferir o delta de contatos recebido desde o backup. Reativar CF7/Flamingo em clone ou piloto antes da troca de conteúdo. Reativação sozinha não recria a renderização dos blocos/shortcodes nativos.
3. Conferir hash atual de cada conteúdo alterado. Restaurar o backup `_f3base_backup_cf7_1110` somente se não sobrescrever edição editorial posterior; em conflito, fazer merge revisado. Converter referências de blocos e tema pelo registro de alterações do rollout.
4. Repor integrações de tema e definições CF7 verificadas, testar envio/avisos e só então retirar o renderizador nativo. Preservar os contatos novos por exportação privada ou manter o Core compatível para leitura.
5. Não restaurar um banco antigo por cima dos envios novos. O rollback de dados é uma conciliação por identidade; não existe promessa de desfazer uma migração apagando tabelas.
6. Provar os fluxos com CF7 antes de instalar versão de Core que não registra o formulário nativo. Registrar o responsável, horários, revisões, arquivos e testes.

O marcador de conclusão não é apagado para “tentar de novo”. Se uma recuperação posterior exigir importação adicional, ela é operação excepcional nova com ferramenta específica e revisão; a próxima versão não reabre o importador legado.

## 5. Desinstalação e eliminação

Desinstalar preserva leads, contatos independentes, arquivos, concessões, configurações e marcador de migração. O teste com dados reais da fixture verificou esse comportamento. Preservar uma tabela sem conservar o diretório privado não basta: ele entra no backup do operador.

Eliminação de registro usa a ability própria/pedido de privacidade: simular → conferir revisão → aplicar → confirmar journal, revogação, arquivo e origem legada. Falha fica pendente e sem acesso. Retenção operacional usa lixeira e janela do site; eliminar definitivamente não se confunde com desinstalar.

## 6. Versão seguinte

A guarda do bootstrap carrega `includes/migrations/class-f3base-migracao-1110.php` apenas quando a versão é exatamente 1.11.0. O ensaio com cabeçalho 1.11.1 confirmou ausência da classe e funcionamento independente de formulário/repositório. Na próxima manutenção, retirar o arquivo, suas rotas e a ponte; conservar a definição do marcador e as funções permanentes do acervo/privacidade. Sites que não concluíram no momento apropriado permanecem com os plugins antigos até um procedimento explícito; não recebem importação implícita da 1.11.1.
