# Próximas releases do Core — plano revisado

A análise crítica foi incorporada à implementação. Os pacotes são **candidatos de homologação**; nenhuma mudança foi aplicada aos sites.

| Versão | Entrega | Migração |
|---|---|---|
| **1.10.3** | Correções de redirects, política, cache, Markdown, contrato e complementos de schema | Sem tabelas novas de formulários ou importador |
| **1.11.0** | Formulários próprios, repositório, contatos, anexos privados e downloads | Somente nesta versão exata, com conclusão única por site |

A 1.11.0 inclui as correções da 1.10.3. Não é necessário instalar ambas em sequência. CF7 e Flamingo só podem ser retirados depois da conferência de conteúdo, acervo, envios e recuperação no site.

## Documentos que substituem o plano único

1. [Decisões, escopo, estimativas e liberação](01-decisoes-e-escopo.md).
2. [Contratos e comportamento implementado](02-contratos-e-comportamento.md).
3. [Rastreabilidade R → T, evidências e gates](03-rastreabilidade-e-gates.md).
4. [Operação, migração e recuperação](04-operacao-e-recuperacao.md).

O plano anterior permanece no histórico das fontes. As capacidades do MCP — sonda genérica do canal 3 e consumidor do manifesto no canal 2 — continuam fora deste pacote Core.

## Pontos de aceite ainda abertos

Homologação com MySQL/MariaDB e versões reais de CF7/Flamingo; navegador e acessibilidade; SMTP; armazenamento privado e cache no servidor; GA4/Ads, PageSpeed e Rich Results reais. A bancada local usa WordPress, SQLite, HTTP local e transporte de e-mail controlado. Os testes locais não aprovam esses gates externos.

O teste causal do adiamento do Google fica para uma entrega posterior. O aviso por clique conserva a configuração anterior; sua mudança para resumo exclusivo requer decisão de produto. As datas da documentação são propostas, sem agendamento ou implantação automática.
