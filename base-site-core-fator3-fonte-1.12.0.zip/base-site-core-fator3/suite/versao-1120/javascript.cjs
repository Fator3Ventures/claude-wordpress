'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assets = path.resolve(__dirname, '../../fontes/plugin/assets');
function ambiente(cookie = '', dados = {}) {
 const handlers={},whandlers={},scripts={}; let jar=cookie; const storage = new Map();
 const document = {readyState:'loading',visibilityState:'visible',addEventListener:(e,f)=>(handlers[e] ||= []).push(f),dispatchEvent:e=>(handlers[e.type]||[]).forEach(f=>f(e)),getElementById:id=>scripts[id],getElementsByTagName:()=>[],head:{appendChild:el=>{scripts[el.id]=el}},createElement:()=>({}),removeEventListener:()=>{},querySelectorAll:()=>[],documentElement:{},body:{}};
 Object.defineProperty(document,'cookie',{get:()=>jar,set:v=>{jar=v.split(';')[0]}});
 const window = {document,location:{protocol:'https:',hostname:'example.test',pathname:'/',href:'https://example.test/'},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k)},addEventListener:(e,f)=>(whandlers[e] ||= []).push(f),dataLayer:[],performance:{now:()=>0,timeOrigin:Date.now()},setTimeout,clearTimeout,f3baseConsentimentoDados:{padrao:'pre-aprovado',controleRodape:false,avisoPrimeiraVisita:false,...dados}};
 const ctx = vm.createContext({window,document,CustomEvent:class{constructor(type,o){this.type=type;this.detail=o.detail}},URL,Date,Promise,setTimeout,clearTimeout,Uint8Array,console});
 vm.runInContext(fs.readFileSync(path.join(assets,'f3base-consentimento.js'),'utf8'),ctx);
 return {window,document,ctx,handlers,whandlers,scripts,storage,load:()=>document.dispatchEvent({type:'DOMContentLoaded'})};
}
function tracking(a, caminho='direto', overrides={}) {
 a.window.f3baseTrackingDados={caminho,ga4:'G-TEST',ads:{id:'AW-TEST'},meta:{pixelId:'42',origem:'https://meta.test/pixel'},linkedin:{partnerId:'42',origem:'https://linkedin.test/script'},gtm:'GTM-TEST',origemGoogle:'https://google.test/',resumo:{ativo:false},comportamento:{eventos:{f3base_pagina_vista:{gatilho:'pagina',parametros:[],teto:1,limiar:{}}}}};
 Object.assign(a.window.f3baseTrackingDados,overrides);
 vm.runInContext(fs.readFileSync(path.join(assets,'f3base-tracking.js'),'utf8'),a.ctx);a.load();
}
function commands(a,n) { return a.window.dataLayer.filter(c=>c[0]===n); }
(async()=>{
 const checks={};const ck=(n,v)=>{checks[n]=!!v;assert.ok(v,n)};
 const a=ambiente();let requests=[],calls=[];a.document.head.appendChild=el=>requests.push(el);
 class Observer{constructor(cb){this.cb=cb;} observe(){}takeRecords(){return []}disconnect(){}};Observer.supportedEntryTypes=['event'];a.ctx.PerformanceObserver=Observer;
 const options={vitaisUrl:'https://example.test/web-vitals.js',vitaisMaxAtualizacoes:20,comportamento:{eventos:{f3base_desempenho:{gatilho:'desempenho',parametros:['vital','valor'],teto:20,limiar:{vitais:['CLS','INP','LCP','TTFB']}}}}};
 tracking(a,'direto',options);ck('no_library_before_load',!requests.find(x=>x.src===options.vitaisUrl));
 (a.whandlers.load||[]).forEach(fn=>fn());await new Promise(r=>setTimeout(r,5));let lib=requests.find(x=>x.src===options.vitaisUrl);ck('library_requested_after_load',!!lib);
 a.window.webVitals=Object.fromEntries(['CLS','INP','LCP','TTFB'].map(x=>['on'+x,()=>calls.push(x)]));lib.onload();lib.onload();ck('collectors_initialize_once',calls.length===4);
 a.window.f3baseTracking.carregar();ck('no_second_request',requests.filter(x=>x.src===options.vitaisUrl).length===1);
 const denied=ambiente('f3base_consentimento=denied');let deniedReq=[];denied.document.head.appendChild=e=>deniedReq.push(e);denied.ctx.PerformanceObserver=Observer;tracking(denied,'direto',options);(denied.whandlers.load||[]).forEach(fn=>fn());await new Promise(r=>setTimeout(r,5));ck('denied_no_library',!deniedReq.find(x=>x.src===options.vitaisUrl));
 // Real vendored calculations on synthetic PerformanceEntry/Observer input.
 function vendor(hidden){const hs={},obs=[];class PO{constructor(cb){this.cb=cb;this.types=[];obs.push(this)}observe(o){this.types.push(o.type)}disconnect(){}takeRecords(){return []}};PO.supportedEntryTypes=['event','first-input','paint','layout-shift','largest-contentful-paint','navigation'];class PET{}PET.prototype.interactionId=0;
 const nav={entryType:'navigation',name:'https://example.test/',startTime:0,duration:400,responseStart:80,activationStart:0,type:'navigate',domInteractive:200,domContentLoadedEventStart:200,loadEventStart:400};
 const short={entryType:'event',name:'click',interactionId:7,startTime:150,duration:40,processingStart:151,processingEnd:178};
 const g={document:{visibilityState:hidden?'hidden':'visible',readyState:'complete',prerendering:false},performance:{now:()=>1000,getEntriesByType:t=>t==='navigation'?[nav]:[],interactionCount:1},PerformanceObserver:PO,PerformanceEventTiming:PET,addEventListener:(e,f)=>(hs[e] ||= []).push(f),removeEventListener:()=>{},queueMicrotask,setTimeout:(f,t)=>setTimeout(f,typeof t==='number'?t:0),clearTimeout,requestAnimationFrame:f=>setTimeout(f,0),f3baseVitaisAntecipados:{eventos:[short],primeiroOculto:hidden?500:Infinity},console};g.window=g;g.location={href:'https://example.test/'};const c=vm.createContext(g);vm.runInContext(fs.readFileSync(path.join(assets,'vendor/web-vitals.js'),'utf8'),c);return {g,c,obs,short,hs};}
 for(const hidden of [false,true]){const v=vendor(hidden),metrics=[];v.c.webVitals.onINP(m=>metrics.push(m.value),{reportAllChanges:true,durationThreshold:16});await new Promise(r=>setTimeout(r,10));ck('short_preload_inp_'+hidden,metrics.includes(40));const target=v.obs.find(x=>x.types.includes('first-input'));target.cb({getEntries:()=>[v.short]});await new Promise(r=>setTimeout(r,10));ck('replay_not_double_counted_'+hidden,metrics.length===1);}
 const v=vendor(false),values=[];v.c.webVitals.onCLS(m=>values.push(m.value),{reportAllChanges:true});const paint=v.obs.find(x=>x.types.includes('paint'));paint.cb({getEntries:()=>[{entryType:'paint',name:'first-contentful-paint',startTime:10,duration:0}]});await new Promise(r=>setTimeout(r,2));const cls=v.obs.find(x=>x.types.includes('layout-shift'));cls.cb({getEntries:()=>[{entryType:'layout-shift',startTime:100,value:.5,hadRecentInput:false},{entryType:'layout-shift',startTime:1200,value:.4,hadRecentInput:false},{entryType:'layout-shift',startTime:1500,value:5,hadRecentInput:true}]});await new Promise(r=>setTimeout(r,10));ck('cls_local_patch_preserved',Math.max(...values)===.5);
 console.log(JSON.stringify({ambiente:'Node VM; DOM/PerformanceObserver simulados; cálculos da biblioteca vendorizada real',checks},null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
