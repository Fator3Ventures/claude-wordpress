#!/usr/bin/env python3
"""Reproducible 1.12.0 installer; installed documentation is mandatory."""
from pathlib import Path
import json,hashlib,zipfile,re,subprocess,sys
root=Path(__file__).resolve().parents[2];plugin=root/'fontes/plugin';out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/'dist/releases';out.mkdir(parents=True,exist_ok=True)
version='1.12.0';assert re.search(r'^ \* Version:\s+1\.12\.0$',(plugin/'base-site-core-fator3.php').read_text(),re.M)
for name in ['DOCUMENTACAO.md','README.md','INSTRUCOES-DO-PLUGIN.md','CHANGELOG.md','CONTRACTS.md','docs/CONFIGURACAO.md','docs/LEADS-E-FORMULARIOS.md','docs/OPERACAO-E-RECUPERACAO.md','docs/VALIDACAO.md','docs/REFERENCIA-CATALOGO.md']:
 assert (plugin/name).is_file(),name
assert not (plugin/'includes/migrations/class-f3base-migracao-1110.php').exists()
subprocess.run(['node',str(root/'suite/build-assets/build.cjs'),str(plugin),'--check'],check=True)
archive=out/f'base-site-core-fator3-{version}.zip';files=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(plugin.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(plugin).as_posix();data=p.read_bytes();info=zipfile.ZipInfo('base-site-core-fator3/'+rel,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data);files.append({'arquivo':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'plugin':'base-site-core-fator3','versao':version,'contrato':'1.7.0','schema_leads':2,'status':'implementado_validado_localmente_homologacao_externa_pendente','zip':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'documentacao_instalada':True,'importador_cf7_flamingo':False,'wordpress_bancada':'7.1','php_bancada':'8.3.6','banco_bancada':'SQLite com integração WordPress','arquivos':files}
(out/f'manifesto-core-{version}.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='arquivos'},ensure_ascii=False))
