<?php
$site=getenv('F3BASE_SITE');if(!$site||!is_file($site.'/.f3base-bancada-110'))exit(2);require $site.'/wp-load.php';wp_set_current_user(1);global $wpdb;
$c=[];function check($n,$v){global $c;$c[$n]=(bool)$v;}
$t=F3Base_Leads_Repositorio::tabela();$r=F3Base_Leads_Repositorio::guardar(['nome'=>'Preservar 1120','email'=>'preservar@example.test','metodo'=>'formulario']);$before=F3Base_Leads_Repositorio::obter($r['record_id']);
foreach(['sessao','post_id'] as $key){$wpdb->query("ALTER TABLE $t DROP INDEX $key");}
foreach(['sessao','post_id','resposta','resposta_em','resposta_erro'] as $col){check('remove_fixture_'.$col,$wpdb->query("ALTER TABLE $t DROP COLUMN $col")!==false);}
F3Base_Options::atualizar_estado('f3base_leads_estrutura',static fn()=>['schema'=>1]);check('old_schema_detected',!F3Base_Leads_Repositorio::pronto());check('upgrade_schema',F3Base_Leads_Repositorio::instalar());$after=F3Base_Leads_Repositorio::obter($r['record_id']);check('existing_row_preserved',$before['record_id']===$after['record_id']&&$before['dados']===$after['dados']&&$before['payload_hash']===$after['payload_hash']);check('old_session_not_invented',$after['sessao']===null);check('old_reply_off',$after['resposta']==='desligada');check('second_install_idempotent',F3Base_Leads_Repositorio::instalar());
$index=F3Base_Release_1120::documentacao();foreach($index['arquivos'] as $file){$d=F3Base_Release_1120::documentacao(['arquivo'=>$file,'linha'=>1,'limite'=>2]);check('document_'.$file,$d['ok']&&$d['sha256']===hash_file('sha256',F3BASE_PLUGIN_DIR.$file)&&$d['total_linhas']>2);}
check('doc_traversal_refused',!F3Base_Release_1120::documentacao(['arquivo'=>'../../wp-config.php'])['ok']);check('doc_pagination',F3Base_Release_1120::documentacao(['arquivo'=>'DOCUMENTACAO.md','limite'=>2])['proxima_linha']===3);
$ab=wp_get_ability('f3base/documentacao-ler');wp_set_current_user(0);check('doc_ability_requires_admin',is_wp_error($ab->execute([])));wp_set_current_user(1);
echo wp_json_encode(['checks'=>$c,'failures'=>array_keys(array_filter($c,fn($v)=>!$v))],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);exit(in_array(false,$c,true)?1:0);
