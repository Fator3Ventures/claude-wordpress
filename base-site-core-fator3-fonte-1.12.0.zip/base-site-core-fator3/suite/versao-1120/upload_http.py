import urllib.request as u,os,json,time,uuid,urllib.error
base=os.environ.get('F3BASE_URL','http://127.0.0.1:8120'); results={}
def request(path,body,ctype):
 try:r=u.urlopen(u.Request(base+path,data=body,headers={'Content-Type':ctype}),timeout=30)
 except urllib.error.HTTPError as e:r=e
 return r.status,json.loads(r.read())
for name in ['sem-teto','zero','teto-explicito']:
 sid=uuid.uuid4().hex
 _,token=request('/?rest_route=/f3base/v1/formularios/token',json.dumps({'formulario':name,'submissao':sid}).encode(),'application/json')
 time.sleep(3.1)
 fields={'formulario':name,'submissao':sid,'token':token['token'],'website':''};boundary='----F3test'+uuid.uuid4().hex
 parts=[]
 for k,v in fields.items():parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
 parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="campos[arquivo][]"; filename="anexo.semrestricao"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()+b'x'*(11*1024*1024)+b'\r\n')
 parts.append(f'--{boundary}--\r\n'.encode())
 code,d=request('/?rest_route=/f3base/v1/formularios/enviar',b''.join(parts),'multipart/form-data; boundary='+boundary)
 results[name]={'http':code,'persisted':d.get('persisted'),'codigo':d.get('codigo'),'aceito':d.get('aceito')}
results['checks']={'11MiB_ausente_aceito':results['sem-teto']['persisted'] is True and results['sem-teto']['aceito'] is True,'11MiB_zero_aceito':results['zero']['persisted'] is True and results['zero']['aceito'] is True,'limite_explicito_recusa':results['teto-explicito']['persisted'] is False}
print(json.dumps(results,indent=2));assert all(results['checks'].values())
