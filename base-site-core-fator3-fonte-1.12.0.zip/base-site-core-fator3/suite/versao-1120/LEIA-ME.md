# Bancada 1.12.0

Execute somente em WordPress descartável marcado por `.f3base-bancada-110`. Os testes gravam configurações e registros sintéticos. Não use em produção. Configure `F3BASE_SITE` para o caminho desse WordPress e intercepte todos os e-mails/requisições externos.

- `regressao.php`: novos contratos. `php regressao.php` com o plugin 1.12.0 ativo.
- `formularios.php`: 33 contratos nativos extraídos da suíte anterior; o trecho exclusivo do importador 1.11.0 permanece na suíte histórica, não é executado nesta versão.
- `upgrade.php`: remove as novas colunas na bancada para reconstruir schema 1, executa atualização e testa a documentação/permissionamento.
- `respostas.php`: falha de transporte, retry explícito, estado incerto, duplicação e suspeito.
- `javascript.cjs`: Node VM com DOM/PerformanceObserver simulados e cálculos reais da biblioteca local. Não substitui o navegador.
- `upload_http.py`: stdlib Python e HTTP local, três definições prévias: `sem-teto`, `zero`, `teto-explicito`; campo obrigatório `arquivo` do tipo file, extensões `[]`, limite ausente/0/1024 respectivamente. PHP deve aceitar 11 MiB por arquivo e por POST. Mantém e-mail interceptado.
- `router.php`: router somente para bancada marcada. Sirva com PHP e execute cliente na mesma sessão de rede.
- `empacotar.py`: verifica assets, documentação, versão e ausência do importador antes de montar ZIP determinístico; aceita diretório de saída opcional.

As evidências JSON identificam o ambiente e os resultados. `comparacao-base.json` registra uma falha operacional que também existe na 1.11.0 com o mesmo banco, não uma aprovação daquele caso. Consulte os gates externos na documentação instalada.
