# Entrega Core 1.12.0

Implementação concluída em 24/09/2026, com validação local e pacote instalável. Nenhum site da frota foi alterado. A orientação “apagar por padrão” foi descartada.

## Arquivos

- Instalador: `base-site-core-fator3-1.12.0.zip` (681,597 bytes).
- Fontes e suíte: `base-site-core-fator3-fonte-1.12.0.zip`.
- Manifesto: `manifesto-core-1.12.0.json`, com SHA-256 de cada arquivo instalado.
- Contrato: 1.7.0. Schema de leads: 2.
- SHA-256 do instalador: `f1da572955e8568817dde73de5ecdc94f9e673c1dc4211a421c0bbfb9f714dde`.

## O que mudou

| Frente | Entrega |
|---|---|
| Configuração | Selects/enums, checkbox de blocos com busca e preservação; destinatários, avisos e classes explicados e separados do WhatsApp. |
| Operação | Aba dentro de F3 Base; endereço antigo encaminhado; política e catálogo operável habilitados uma vez, com fotografia/revisão. |
| Leads | Sessão canônica e motivo de ausência, correlação preenchida, IP/UA de origem e post_id resolvido no servidor; contexto consultável/exportável. |
| Métodos | CTA interno/telefone/e-mail como contato_cta; WhatsApp por destino exato; método compartilhado semanticamente com a conversão. |
| Acervo CF7 já copiado | Reparo por evidência preservada ou mapa explícito de canal/formulário/campos, sem reimportar e sem mensagens retroativas. |
| Anexos | Sem teto implícito quando max_bytes está ausente ou zero; extensões livres por padrão; limites explícitos preservados. |
| Pasta privada | Criada/testada na ativação e atualização; diagnóstico distingue ausência criável, falha de permissão e caminho público. |
| Cache | Sonda HTTP com expectativa de zero bytes; prova persistida e considerada no sucesso, na cadência já existente. |
| Web Vitals | Biblioteca 6.2.1 após load; retenção de interações curtas anteriores, deduplicação e estado de ocultamento; patch CLS mantido. |
| Resposta ao visitante | Opt-in por formulário, desligada por padrão, com estado independente, quota, reserva, retry e tratamento de incerteza. |
| Documentação | Nove documentos mais instrução de entrada dentro do plugin, incluindo referência completa do catálogo; leitura autenticada por ability. |

## Evidências

Bancada isolada: PHP 8.3.6, WordPress identificado localmente como 7.1, SQLite com integração WordPress. Todos os dados são sintéticos. Envio de e-mail interceptado localmente.

| Conjunto | Resultado |
|---|---|
| Novos contratos de integração | 64/64 |
| Formulários nativos | 33/33 |
| Atualização de schema e documentação | 23/23 |
| Respostas e retentativas | 7/7 |
| JavaScript / VM | 10/10 |
| Upload HTTP real | 3/3 |
| Sintaxe | 88 PHP e 15 JavaScript, sem erros |
| Assets | Reconstrução idêntica; ausência, fonte alterada e minificado corrompido recusados |
| Regressão anterior de consentimento/tracking | Passou |
| Suíte operacional anterior | 45/46 em ambas as versões; full_path_resolves falha também na base 1.11.0 no mesmo banco |

São 140 verificações aprovadas nos seis conjuntos específicos acima. Os testes VM não são ensaios de navegador. O upload multipart aceitou 11 MiB com limite ausente e zero, e recusou o mesmo arquivo com teto explícito de 1.024 bytes. O teste de upgrade reconstruiu o schema anterior, acrescentou as colunas e preservou os dados. A documentação foi lida por ability no WordPress e a permissão de administrador foi conferida.

Os JSONs de evidência, os testes reproduzíveis e o gerador de pacote acompanham as fontes em `suite/versao-1120/`. O build foi conferido contra os hashes dos arquivos entregues. O instalador foi extraído e carregado no WordPress isolado, incluindo leitura da documentação; os hashes finais também foram conferidos.

## Limites e próximos aceites

- Homologação no servidor real: MySQL/MariaDB, permissões/aliases, limites PHP/proxy e HTTP público do cache/CDN.
- SMTP/recebimento, GA4 e correspondência com evento efetivamente recebido, PageSpeed comparável.
- Navegador real: navegação imediata, hidden, saída antes do load e bfcache. A tentativa de obter Chromium para a bancada não produziu um binário válido; nenhum resultado VM foi promovido a resultado de navegador.
- O carregamento após load não garante métricas em uma visita encerrada antes desse ponto. A biblioteca não fabrica zeros e a retenção antecipada tem limite de 2.000 entradas, com INP omitido em overflow.
- A falha operacional preexistente full_path_resolves permanece registrada para a homologação; não foi corrigida silenciosamente dentro deste escopo.
- Se ainda houver migração CF7/Flamingo aberta, a ponte deve ser concluída na trilha excepcional 1.11.0 antes de atualizar. Este instalador não contém importador. Canal genérico sem evidência de formulário exige mapa conferido por site.
- CRM/webhook continuam posteriores. Respostas ao visitante existentes em CF7 não foram copiadas nem ativadas na frota.

## Onde o agente encontra a documentação

Abra `wp-content/plugins/base-site-core-fator3/DOCUMENTACAO.md`, ou use `f3base/documentacao-ler` com `{}` para o índice. A leitura pagina até 200 linhas e retorna SHA-256 e versão. `f3base/como-usar` aponta para a mesma referência. Os textos incluem configuração, todos os módulos/opções/abilities declarados, contratos, contexto, reparo, armazenamento, métricas, recuperação e resultados reais.
