/* Build somente de desenvolvimento. Nenhuma dependência Node é instalada no WordPress. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const { createRequire } = require('node:module');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');

async function main() {
  const root = path.resolve(process.argv[2] || '');
  const check = process.argv.includes('--check');
  if (!process.argv[2] || !fs.existsSync(path.join(root, 'base-site-core-fator3.php'))) throw Error('Informe a raiz completa do plugin.');
  const lock = fs.readFileSync(path.join(__dirname, 'package-lock.json'));
  const deps = JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8'));
  const version = deps.dependencies.terser;
  if (!/^\d+\.\d+\.\d+$/.test(version)) throw Error('A versão do minificador precisa estar fixada.');
  const cache = process.env.F3BASE_BUILD_CACHE || path.join(os.homedir(), '.cache', 'f3base-build', sha(lock));
  fs.mkdirSync(cache, {recursive: true});
  const stamp = path.join(cache, '.f3base-lock');
  if (!fs.existsSync(stamp) || fs.readFileSync(stamp, 'utf8') !== sha(lock) || !fs.existsSync(path.join(cache, 'node_modules/terser/package.json'))) {
    fs.copyFileSync(path.join(__dirname, 'package.json'), path.join(cache, 'package.json'));
    fs.writeFileSync(path.join(cache, 'package-lock.json'), lock);
    execFileSync('npm', ['ci', '--ignore-scripts', '--no-audit', '--no-fund', '--prefix', cache], {stdio: 'pipe', timeout: 120000});
    fs.writeFileSync(stamp, sha(lock));
  }
  const req = createRequire(path.join(cache, 'package.json'));
  if (req('terser/package.json').version !== version) throw Error('Versão instalada do minificador diverge do lock.');
  const options = {ecma: 5, compress: {passes: 2, unsafe: false}, mangle: true, format: {comments: /^!|@license|@preserve|SPDX-License-Identifier/}};
  const manifest = {schema_version: 1, minificador: 'terser', versao: version, lock_sha256: sha(lock), opcoes: {ecma: 5, passes: 2, unsafe: false, mangle: true, licencas_preservadas: true}, arquivos: []};
  const writes = [];
  for (const name of ['tracking', 'leads', 'consentimento', 'tempo-ativo', 'formularios'].filter(n => fs.existsSync(path.join(root, `assets/f3base-${n}.js`)))) {
    const source = `assets/f3base-${name}.js`, out = source.replace(/\.js$/, '.min.js');
    const content = fs.readFileSync(path.join(root, source), 'utf8');
    const result = await req('terser').minify({[source]: content}, options);
    if (!result.code) throw Error(`Minificador não produziu ${out}.`);
    const code = result.code + '\n';
    manifest.arquivos.push({fonte: source, minificado: out, fonte_sha256: sha(content), minificado_sha256: sha(code), fonte_bytes: Buffer.byteLength(content), minificado_bytes: Buffer.byteLength(code)});
    writes.push([path.join(root, out), code]);
  }
  writes.push([path.join(root, 'assets/manifesto-assets.json'), JSON.stringify(manifest, null, 2) + '\n']);
  // Só publica após gerar todos; a conferência recompõe os resultados sem reescrevê-los.
  for (const [file, value] of writes) {
    if (check) {
      if (!fs.existsSync(file) || fs.readFileSync(file, 'utf8') !== value) throw Error(`Asset ausente ou desatualizado: ${path.basename(file)}`);
    } else {
      const temp = file + '.tmp-' + process.pid;
      fs.writeFileSync(temp, value);
      fs.renameSync(temp, file);
    }
  }
  process.stdout.write(JSON.stringify({ok: true, modo: check ? 'conferencia' : 'geracao', arquivos: manifest.arquivos.length}) + '\n');
}
main().catch(error => { process.stderr.write(`BUILD ASSETS: ${error.message}\n`); process.exitCode = 1; });
