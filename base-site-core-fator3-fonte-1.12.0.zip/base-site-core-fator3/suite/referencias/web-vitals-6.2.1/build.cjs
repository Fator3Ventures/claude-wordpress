/* Reproduzir: npm install esbuild@0.25.12; node build.cjs [destino.js]
 * ESBUILD_MODULE pode apontar a instalação já disponível de esbuild.
 */
const fs = require('node:fs'), path = require('node:path'), os = require('node:os');
const esbuild = require(process.env.ESBUILD_MODULE || 'esbuild');
const destino = process.argv[2] || path.resolve(__dirname,'../../../fontes/plugin/assets/vendor/web-vitals.js');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'f3base-vitais-'));
try {
 fs.cpSync(path.join(__dirname,'src'),path.join(temp,'src'),{recursive:true});
 const arquivo=path.join(temp,'src/onCLS.ts'); const antes=fs.readFileSync(arquivo,'utf8');
 const ancora='          layoutShiftManager._processEntry(entry as LayoutShift);';
 if(!antes.includes(ancora)) throw new Error('Fonte divergente; não aplique o patch automaticamente.');
 fs.writeFileSync(arquivo,antes.replace(ancora,ancora+'\n          updateAndReportMetric(); // F3: preservar máximo ao cruzar janelas no mesmo lote.'));
 esbuild.buildSync({entryPoints:[path.join(temp,'src/index.ts')],outfile:destino,bundle:true,format:'iife',globalName:'webVitals',minify:true,target:'es2020',legalComments:'none',banner:{js:'/*! web-vitals 6.2.1; Copyright Google LLC; Apache-2.0. F3 local patch: preserve CLS maximum; replay short pre-load interactions and hidden lifecycle. See web-vitals-LICENSE.txt and source bundle. */'}});
} finally { fs.rmSync(temp,{recursive:true,force:true}); }
