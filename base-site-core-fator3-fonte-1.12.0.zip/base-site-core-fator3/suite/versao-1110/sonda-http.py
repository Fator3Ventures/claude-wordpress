"""Real anonymous HTTP on disposable local WordPress; no browser/email delivery claims."""
import json,sys,re,html,io,urllib.request,urllib.error,urllib.parse,uuid
class Response:
 def __init__(self,r):
  self.status_code=r.code;self.headers=r.headers;self.content=r.read();self.text=self.content.decode('utf-8','replace')
 def json(self):return json.loads(self.text)
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**k):return None
class Client:
 def request(self,method,url,data=None,files=None,headers=None,allow_redirects=True):
  headers=dict(headers or {});body=None
  if files:
   boundary='----'+uuid.uuid4().hex;body=b''
   for k,v in (data or {}).items():body+=('--'+boundary+'\r\nContent-Disposition: form-data; name="'+k+'"\r\n\r\n'+str(v)+'\r\n').encode()
   for k,(name,buf,mime) in files.items():body+=('--'+boundary+'\r\nContent-Disposition: form-data; name="'+k+'"; filename="'+name+'"\r\nContent-Type: '+mime+'\r\n\r\n').encode()+buf.read()+b'\r\n'
   body+=('--'+boundary+'--\r\n').encode();headers['Content-Type']='multipart/form-data; boundary='+boundary
  elif data:body=urllib.parse.urlencode(data).encode()
  op=urllib.request.build_opener(urllib.request.ProxyHandler({}),*([] if allow_redirects else [NoRedirect()]))
  try:r=op.open(urllib.request.Request(url,data=body,headers=headers,method=method),timeout=20)
  except urllib.error.HTTPError as e:r=e
  return Response(r)
 def get(self,u,**k):return self.request('GET',u,**k)
 def post(self,u,**k):return self.request('POST',u,**k)
 def head(self,u,**k):return self.request('HEAD',u,**k)
from pathlib import Path
f=json.loads(Path(sys.argv[1]).read_text());s=Client();checks={}
def ck(k,v):checks[k]=bool(v)
r=s.get(f['url']);ck('public_form_html',r.status_code==200 and 'data-f3base-formulario' in r.text)
token=re.search(r'name="token" value="([^"]+)"',r.text);token=html.unescape(token[1]) if token else ''
ck('html_no_set_cookie',not r.headers.get('Set-Cookie'));ck('html_has_shared_empty_submission','name="submissao" value=""' in r.text)
base=f['url'].split('/formulario-')[0]
payload={'formulario':f['form'],'token':token,'submissao':'','campos[nome]':'Visitante sintético','campos[email]':'http-person@example.test'}
def upload(path,data):return s.post(path,data=data,files={'campos[anexo][]':('arquivo.php',io.BytesIO(b'<?php echo "NEVER_EXECUTE";'),'application/x-php')},allow_redirects=False)
r=upload(base+'/wp-json/f3base/v1/formularios/enviar',payload);d=r.json();ck('multipart_saved',r.status_code==201 and d.get('persisted'));ck('rest_no_store','no-store' in r.headers.get('Cache-Control',''))
r2=upload(base+'/wp-json/f3base/v1/formularios/enviar',payload);ck('multipart_nojs_dedup',r2.json().get('duplicado'))
payload['action']='f3base_formulario';r=upload(base+'/wp-admin/admin-post.php',payload);ck('nojs_303',r.status_code==303);loc=r.headers.get('Location','');ck('nojs_url_without_pii','http-person' not in loc and 'Visitante' not in loc)

if loc:
 r=s.get(loc);ck('confirmation_private',r.status_code==200 and 'no-store' in r.headers.get('Cache-Control',''))
else:
 ck('confirmation_private',False);print('nojs status='+str(r.status_code)+' body='+r.text[:1300],file=sys.stderr)
u=f['download'];bad=s.get(u+'0');ck('bad_grant_404',bad.status_code==404)
h=s.head(u);ck('head_authorized',h.status_code==200 and not h.content)
range_r=s.get(u,headers={'Range':'bytes=0-1'});ck('range_rejected',range_r.status_code==416)
a=s.get(u);b=s.get(u);c=s.get(u);ck('head_range_dont_spend_quota',a.status_code==200 and b.status_code==200 and c.status_code==410);ck('download_exact_bytes',a.content==b'Arquivo privado de teste');ck('download_private_nosniff_attachment','no-store' in a.headers.get('Cache-Control','') and a.headers.get('X-Content-Type-Options')=='nosniff' and a.headers.get('Content-Disposition','').startswith('attachment'))
r=s.get(base+'/wp-admin/admin-post.php?action=f3base_anexo&id='+'a'*32);ck('anonymous_attachment_denied',r.status_code==400 or r.status_code==403)
print(json.dumps({'checks':checks,'failures':[k for k,v in checks.items() if not v]},indent=2));sys.exit(0 if all(checks.values()) else 1)
