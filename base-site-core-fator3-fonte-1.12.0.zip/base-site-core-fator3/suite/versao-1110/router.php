<?php
/** Router only for the explicitly marked disposable WordPress fixture. */
$site = getenv('F3BASE_SITE');
if (!$site || !is_file($site.'/.f3base-bancada-110')) { http_response_code(503); exit; }
$path = realpath($site.(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH) ?: '/'));
if ($path && str_starts_with($path,realpath($site).DIRECTORY_SEPARATOR) && is_file($path)) { return false; }
require $site.'/index.php';
