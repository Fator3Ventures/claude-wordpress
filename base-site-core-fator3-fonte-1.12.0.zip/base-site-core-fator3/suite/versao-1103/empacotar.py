#!/usr/bin/env python3
"""Build independently deployable operational and forms packages from shared source."""
from pathlib import Path
import zipfile,shutil,re,json,hashlib,subprocess
root=Path(__file__).resolve().parents[2]
out=root/'dist/releases';out.mkdir(parents=True,exist_ok=True)
forms=['leads-repositorio','formularios','arquivos-privados','leads-notificacoes','leads-admin','conteudo-privado']
for ver in ['1.10.3','1.11.0']:
 stage=out/('stage-'+ver)/'base-site-core-fator3'
 if stage.exists():shutil.rmtree(stage)
 shutil.copytree(root/'fontes/plugin',stage)
 (stage/'INSTRUCOES-DO-PLUGIN.md').unlink(missing_ok=True)
 main=stage/'base-site-core-fator3.php';main.write_text(re.sub(r'(?m)^( \* Version:\s*)\S+',r'\g<1>'+ver,main.read_text()))
 if ver=='1.10.3':
  for name in forms:(stage/'includes'/('class-f3base-'+name+'.php')).unlink()
  shutil.rmtree(stage/'includes/migrations')
  for p in (stage/'assets').glob('f3base-formular*'):p.unlink()
  changes=stage/'dados/mudancas.json'
  changes.write_text(json.dumps([x for x in json.loads(changes.read_text()) if x['versao']!='1.11.0'],ensure_ascii=False,indent=2)+'\n')
 subprocess.run(['node',str(root/'suite/build-assets/build.cjs'),str(stage)],check=True,capture_output=True)
 archive=out/('base-site-core-fator3-'+ver+'.zip')
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(stage.rglob('*')):
   if p.is_file():
    info=zipfile.ZipInfo('base-site-core-fator3/'+p.relative_to(stage).as_posix(),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes())
 manifest={'manifest_version':1,'package':'base-site-core-fator3','version':ver,'status':'candidato_homologacao','contract_version':'1.6.0','zip':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'requires_php':'8.1','requires_wp':'6.4','requires_wp_abilities':'6.9','tested_wp':'6.9','data_schema':1 if ver=='1.11.0' else 'sem_novo_schema_de_leads','exceptional_migration':{'version':'1.11.0','once_per_site':True,'completion_marker':'f3base_migracao_1110','automatic_cutover':False} if ver=='1.11.0' else None,'downgrade': 'reverter_conteudo_e_reativar_cf7_antes_de_downgrade; preservar_acervo' if ver=='1.11.0' else 'restaurar_pacote_e_options_do_backup','update_uri':False,'distribution_url':None,'channel_2_consumer':'integracao_externa_pendente'}
 (out/('manifesto-'+ver+'.json')).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'version':ver,'path':str(archive),'bytes':archive.stat().st_size}))
