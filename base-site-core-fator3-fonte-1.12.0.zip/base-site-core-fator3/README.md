# Fontes — Base Site Core Fator3 1.12.0

Código instalável: `fontes/plugin`. Documentação vigente: `fontes/plugin/DOCUMENTACAO.md`. Testes e evidências desta versão: `suite/versao-1120/`.

Construa os assets com `node suite/build-assets/build.cjs /caminho/absoluto/fontes/plugin` (Terser fixado no lock). O vendor Web Vitals usa esbuild 0.25.12 e `suite/referencias/web-vitals-6.2.1/build.cjs`. Gere o instalador com `python suite/versao-1120/empacotar.py`.

Documentos em `docs/historico-ate-1110` e suítes de versões anteriores são históricos. Não certificam os aceites da 1.12.0. Runtime, banco, credenciais e dependências node_modules não integram este pacote.
