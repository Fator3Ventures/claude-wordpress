"""Confere a árvore de runtime contra o manifesto da rodada e roda php -l em todos os PHP.

Uso:
  python3 tests/verificar-entrega.py                     confere contra evidence/1900/runtime-manifest.json
  python3 tests/verificar-entrega.py --gravar-manifesto  gera o manifesto a partir da árvore (fechamento da rodada)
"""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, concurrent.futures

RODADA = '1900'
root = Path(__file__).resolve().parents[1]
plugin = root / 'work/plugin/base-site-core-fator3'
manifesto = root / 'evidence' / RODADA / 'runtime-manifest.json'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def arquivos():
    # Mesma ordem de build/reproduzir-instalador.py: sorted(Path.rglob).
    return {'base-site-core-fator3/' + p.relative_to(plugin).as_posix(): p for p in sorted(plugin.rglob('*')) if p.is_file()}


def gravar():
    atual = arquivos()
    for nome, p in atual.items():
        if p.is_symlink():
            raise SystemExit('symlink: ' + nome)
    dados = [{'name': n, 'bytes': p.stat().st_size, 'sha256': sha(p)} for n, p in atual.items()]
    manifesto.parent.mkdir(parents=True, exist_ok=True)
    manifesto.write_text(json.dumps(dados, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'manifesto_gravado': str(manifesto), 'arquivos': len(dados)}))


def lint(php, p):
    r = subprocess.run([php, '-n', '-l', str(p)], capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(r.stdout + r.stderr)
    return str(p)


def conferir():
    if not manifesto.is_file():
        raise SystemExit('manifesto ausente: %s (rode com --gravar-manifesto no fechamento)' % manifesto)
    esperado = {x['name']: x for x in json.loads(manifesto.read_text())}
    atual = arquivos()
    if set(atual) != set(esperado):
        raise SystemExit('inventario diverge: faltam %s; sobram %s' % (sorted(set(esperado) - set(atual))[:10], sorted(set(atual) - set(esperado))[:10]))
    for nome, p in atual.items():
        assert not p.is_symlink(), nome
        if sha(p) != esperado[nome]['sha256']:
            raise SystemExit('bytes divergem: ' + nome)
    php = os.environ.get('F3BASE_PHP', 'php')
    lista = sorted(plugin.rglob('*.php'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as e:
        list(e.map(lambda p: lint(php, p), lista))
    print(json.dumps({'manifesto': str(manifesto.relative_to(root)), 'runtime_files_verified': len(atual), 'php_lint_passed': len(lista)}))


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--gravar-manifesto', action='store_true')
    a = ap.parse_args()
    gravar() if a.gravar_manifesto else conferir()
