# Fator3 Site Core 1.90.0

Versão 1.90.0. O catálogo inclui o LG Q60 e consulta localmente o Google Play. As seis filas do Core conciliam a mesma ocorrência entre WP-Cron e WP-CLI. Consulte docs/RELEASE-1.90.0.md.

Instalação nova ou atualização da 1.89.2. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.42.0.

Índice de operação em docs/DOCUMENTACAO.md.
