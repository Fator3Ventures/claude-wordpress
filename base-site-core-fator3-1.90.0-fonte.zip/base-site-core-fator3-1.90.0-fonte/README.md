# Fonte do Fator3 Site Core 1.90.0

Runtime em work/plugin/base-site-core-fator3. Instalador para instalação nova ou troca direta da 1.89.2. Pesquisa LG e CSV final em reference/419. A base congelada do Google Play, UTF-16 de quatro colunas, está em reference/417/supported_devices.csv. O arquivo integral fica no fonte. O instalador contém o índice comprimido e o catálogo curado.

## Reprodução local

Execute na raiz deste fonte. Para trocar a base, substitua a referência congelada, informe sua data de publicação e reveja as fichas e as ambiguidades antes de fechar nova versão. O resultado de QA desta versão está em evidence/1900. Os manifestos descrevem exatamente os arquivos publicados.

```sh
python3 build/gerar-catalogo-aparelhos.py
python3 build/gerar-google-play.py --google-play reference/417/supported_devices.csv --data 2026-11-15
python3 tests/google-play-integridade.py
python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.90.0-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.90.0-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.90.0-fonte.zip
```

Use F3BASE_PHP para selecionar PHP 8.3+. O ensaio de filas está em tests/420. Os testes de catálogo incluem catalogo-google-419.php, projecao-google-419.php e catalogo-precos-413.php. O limite do fonte é 100.000.000 bytes.
